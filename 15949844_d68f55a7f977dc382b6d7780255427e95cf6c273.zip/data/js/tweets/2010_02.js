Grailbird.data.tweets_2010_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9600515807",
  "text" : "Request: Microsoft Office Real-Time Collaboration | commadot.com http:\/\/bit.ly\/aMswhO",
  "id" : 9600515807,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "formerly Dimdim",
      "screen_name" : "dimdim",
      "indices" : [ 0, 7 ],
      "id_str" : "17388929",
      "id" : 17388929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9609224824",
  "in_reply_to_user_id" : 17388929,
  "text" : "@dimdim Love the new myscreen sharing feature in 5.5! Is it possible to make an attendee a presenter via the new myscreen software?",
  "id" : 9609224824,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "dimdim",
  "in_reply_to_user_id_str" : "17388929",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flavors.me\" rel=\"nofollow\"\u003EFlavors.me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flavorsme",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9610380945",
  "text" : "I connected Twitter to my Flavors.me page - http:\/\/flavors.me\/paulhibbitts #flavorsme",
  "id" : 9610380945,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "formerly Dimdim",
      "screen_name" : "dimdim",
      "indices" : [ 0, 7 ],
      "id_str" : "17388929",
      "id" : 17388929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9610600625",
  "in_reply_to_user_id" : 17388929,
  "text" : "@dimdim Thanks for the prompt response! Being able to make someone else the presenter with just the myscreen app could be a great feature...",
  "id" : 9610600625,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "dimdim",
  "in_reply_to_user_id_str" : "17388929",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smashing Magazine",
      "screen_name" : "smashingmag",
      "indices" : [ 61, 73 ],
      "id_str" : "15736190",
      "id" : 15736190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9634600516",
  "text" : "Designing User Interfaces For Business Web Applications (via @smashingmag) http:\/\/tinyurl.com\/ybma4n6",
  "id" : 9634600516,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Goddard",
      "screen_name" : "matthew_goddard",
      "indices" : [ 0, 16 ],
      "id_str" : "722808926",
      "id" : 722808926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9570013348",
  "geo" : { },
  "id_str" : "9580354419",
  "in_reply_to_user_id" : 1272891,
  "text" : "@matthew_goddard I'd recommend ScreenFlow for more elaborate full-screen captures, and S\u00E9quence for shorter, partial-screen captures",
  "id" : 9580354419,
  "in_reply_to_status_id" : 9570013348,
  "created_at" : "2010-02-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "godd4rd",
  "in_reply_to_user_id_str" : "1272891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNET",
      "screen_name" : "CNET",
      "indices" : [ 3, 8 ],
      "id_str" : "30261067",
      "id" : 30261067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9146295342",
  "text" : "RT @cnet Windows Phone 7 at a glance | 3GSM blog - CNET Reviews http:\/\/bit.ly\/aQuaPW",
  "id" : 9146295342,
  "created_at" : "2010-02-15 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TweetMeme",
      "screen_name" : "tweetmeme",
      "indices" : [ 3, 13 ],
      "id_str" : "11883132",
      "id" : 11883132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8969864536",
  "text" : "RT @tweetmeme Can we trust data from professional usability test-takers?: Measuring Usability http:\/\/bit.ly\/8Xb7Yj",
  "id" : 8969864536,
  "created_at" : "2010-02-12 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Zmijewski",
      "screen_name" : "bryanzmijewski",
      "indices" : [ 104, 119 ],
      "id_str" : "15078004",
      "id" : 15078004
    }, {
      "name" : "LukeW",
      "screen_name" : "lukewdesign",
      "indices" : [ 126, 138 ],
      "id_str" : "330617103",
      "id" : 330617103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8653861859",
  "text" : "\"Become a student of change. It is the only thing that will remain constant.\"\u2014 Anthony J. D\u2019Angelo (via @bryanzmijewski) (via @lukewdesign)",
  "id" : 8653861859,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8527716921",
  "text" : "Another good article on Agile + UCD: Bringing User Centered Design to the Agile Environment http:\/\/boxesandarrows.com\/view\/bringing-user",
  "id" : 8527716921,
  "created_at" : "2010-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]