Grailbird.data.tweets_2016_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Finck",
      "screen_name" : "nickf",
      "indices" : [ 3, 9 ],
      "id_str" : "45733",
      "id" : 45733
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uxforchange",
      "indices" : [ 128, 140 ]
    }, {
      "text" : "ux",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/ErHfsGKXAP",
      "expanded_url" : "http:\/\/bit.ly\/1Uo6BSF",
      "display_url" : "bit.ly\/1Uo6BSF"
    } ]
  },
  "geo" : { },
  "id_str" : "715749223732477952",
  "text" : "RT @nickf: You may have heard that I launched a new project for a good cause. Here is my post about it: https:\/\/t.co\/ErHfsGKXAP #uxforchang\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "uxforchange",
        "indices" : [ 117, 129 ]
      }, {
        "text" : "ux",
        "indices" : [ 130, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/ErHfsGKXAP",
        "expanded_url" : "http:\/\/bit.ly\/1Uo6BSF",
        "display_url" : "bit.ly\/1Uo6BSF"
      } ]
    },
    "geo" : { },
    "id_str" : "710954278786043904",
    "text" : "You may have heard that I launched a new project for a good cause. Here is my post about it: https:\/\/t.co\/ErHfsGKXAP #uxforchange #ux",
    "id" : 710954278786043904,
    "created_at" : "2016-03-18 22:21:23 +0000",
    "user" : {
      "name" : "Nick Finck",
      "screen_name" : "nickf",
      "protected" : false,
      "id_str" : "45733",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/58550215\/nickfinck_square_normal.jpg",
      "id" : 45733,
      "verified" : false
    }
  },
  "id" : 715749223732477952,
  "created_at" : "2016-04-01 03:54:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/sczxkfZsrM",
      "expanded_url" : "https:\/\/workflowy.com\/s\/cxAg2TgP9b",
      "display_url" : "workflowy.com\/s\/cxAg2TgP9b"
    } ]
  },
  "geo" : { },
  "id_str" : "715662683421343744",
  "text" : "UPDATE #3: Are you an instructor or student with a minute to spare? Are these online course tasks relatable to you? https:\/\/t.co\/sczxkfZsrM",
  "id" : 715662683421343744,
  "created_at" : "2016-03-31 22:10:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Robinson",
      "screen_name" : "krob",
      "indices" : [ 0, 5 ],
      "id_str" : "1069802168",
      "id" : 1069802168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715658937509548032",
  "geo" : { },
  "id_str" : "715660087272968192",
  "in_reply_to_user_id" : 1069802168,
  "text" : "@krob Another key aspect of my work is trying to create a sustainable open design practice, open source but $ from institutions\/companies.",
  "id" : 715660087272968192,
  "in_reply_to_status_id" : 715658937509548032,
  "created_at" : "2016-03-31 22:00:35 +0000",
  "in_reply_to_screen_name" : "krob",
  "in_reply_to_user_id_str" : "1069802168",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Robinson",
      "screen_name" : "krob",
      "indices" : [ 0, 5 ],
      "id_str" : "1069802168",
      "id" : 1069802168
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 39, 46 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 87, 95 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715658937509548032",
  "geo" : { },
  "id_str" : "715659741121290240",
  "in_reply_to_user_id" : 1069802168,
  "text" : "@krob Cool. I see you've also run into @btopro and I'd also suggest you check out what @drchuck is up too.",
  "id" : 715659741121290240,
  "in_reply_to_status_id" : 715658937509548032,
  "created_at" : "2016-03-31 21:59:13 +0000",
  "in_reply_to_screen_name" : "krob",
  "in_reply_to_user_id_str" : "1069802168",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Robinson",
      "screen_name" : "krob",
      "indices" : [ 0, 5 ],
      "id_str" : "1069802168",
      "id" : 1069802168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715652621873319938",
  "geo" : { },
  "id_str" : "715655568816406530",
  "in_reply_to_user_id" : 1069802168,
  "text" : "@krob Is the flipped LMS approach and\/or open source Grav CMS Course Hub something of specific interest to you? Happy to share!",
  "id" : 715655568816406530,
  "in_reply_to_status_id" : 715652621873319938,
  "created_at" : "2016-03-31 21:42:38 +0000",
  "in_reply_to_screen_name" : "krob",
  "in_reply_to_user_id_str" : "1069802168",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Robinson",
      "screen_name" : "krob",
      "indices" : [ 0, 5 ],
      "id_str" : "1069802168",
      "id" : 1069802168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715652621873319938",
  "geo" : { },
  "id_str" : "715654625743867904",
  "in_reply_to_user_id" : 1069802168,
  "text" : "@krob It's a good point - always on the look out to lower the barrier of use (re: setup).",
  "id" : 715654625743867904,
  "in_reply_to_status_id" : 715652621873319938,
  "created_at" : "2016-03-31 21:38:53 +0000",
  "in_reply_to_screen_name" : "krob",
  "in_reply_to_user_id_str" : "1069802168",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Robinson",
      "screen_name" : "krob",
      "indices" : [ 0, 5 ],
      "id_str" : "1069802168",
      "id" : 1069802168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715650668753776640",
  "geo" : { },
  "id_str" : "715652159019192320",
  "in_reply_to_user_id" : 1069802168,
  "text" : "@krob I think too much \"guesswork\" would be needed to be really useful - an interesting idea though re: term to term (i.e. updating links)!",
  "id" : 715652159019192320,
  "in_reply_to_status_id" : 715650668753776640,
  "created_at" : "2016-03-31 21:29:05 +0000",
  "in_reply_to_screen_name" : "krob",
  "in_reply_to_user_id_str" : "1069802168",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Robinson",
      "screen_name" : "krob",
      "indices" : [ 0, 5 ],
      "id_str" : "1069802168",
      "id" : 1069802168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "715650668753776640",
  "geo" : { },
  "id_str" : "715651865061433344",
  "in_reply_to_user_id" : 1069802168,
  "text" : "@krob No, but for my courses + other instructor feedback I have created a \"starter kit\" for any LMS (via deep links) https:\/\/t.co\/VgQsw7bHP4",
  "id" : 715651865061433344,
  "in_reply_to_status_id" : 715650668753776640,
  "created_at" : "2016-03-31 21:27:55 +0000",
  "in_reply_to_screen_name" : "krob",
  "in_reply_to_user_id_str" : "1069802168",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/w5AvBBh745",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/flipped-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715649290689863685",
  "text" : "Limited by a closed LMS? Don't wait until the contract ends - flip your LMS with an open and collaborative platform https:\/\/t.co\/w5AvBBh745",
  "id" : 715649290689863685,
  "created_at" : "2016-03-31 21:17:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Robinson",
      "screen_name" : "krob",
      "indices" : [ 0, 5 ],
      "id_str" : "1069802168",
      "id" : 1069802168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715647482768859136",
  "geo" : { },
  "id_str" : "715647959187062785",
  "in_reply_to_user_id" : 1069802168,
  "text" : "@krob I usually develop the Canvas elements first, or in parallel with the Grav site.",
  "id" : 715647959187062785,
  "in_reply_to_status_id" : 715647482768859136,
  "created_at" : "2016-03-31 21:12:24 +0000",
  "in_reply_to_screen_name" : "krob",
  "in_reply_to_user_id_str" : "1069802168",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Robinson",
      "screen_name" : "krob",
      "indices" : [ 0, 5 ],
      "id_str" : "1069802168",
      "id" : 1069802168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715647044145311744",
  "geo" : { },
  "id_str" : "715647679783522304",
  "in_reply_to_user_id" : 1069802168,
  "text" : "@krob Yes, for elements\/activities within Canvas I just copy and paste them as needed into the Markdown files for Grav.",
  "id" : 715647679783522304,
  "in_reply_to_status_id" : 715647044145311744,
  "created_at" : "2016-03-31 21:11:17 +0000",
  "in_reply_to_screen_name" : "krob",
  "in_reply_to_user_id_str" : "1069802168",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Robinson",
      "screen_name" : "krob",
      "indices" : [ 0, 5 ],
      "id_str" : "1069802168",
      "id" : 1069802168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715646828906213376",
  "geo" : { },
  "id_str" : "715647476313686018",
  "in_reply_to_user_id" : 1069802168,
  "text" : "@krob Thanks very much, always looking for feedback too.",
  "id" : 715647476313686018,
  "in_reply_to_status_id" : 715646828906213376,
  "created_at" : "2016-03-31 21:10:29 +0000",
  "in_reply_to_screen_name" : "krob",
  "in_reply_to_user_id_str" : "1069802168",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ownCloud community",
      "screen_name" : "ownClouders",
      "indices" : [ 0, 12 ],
      "id_str" : "361140100",
      "id" : 361140100
    }, {
      "name" : "ownCloud",
      "screen_name" : "ownCloud",
      "indices" : [ 13, 22 ],
      "id_str" : "431454954",
      "id" : 431454954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715446849029713921",
  "geo" : { },
  "id_str" : "715557750902624256",
  "in_reply_to_user_id" : 361140100,
  "text" : "@ownClouders @ownCloud Thanks very much, very helpful info!",
  "id" : 715557750902624256,
  "in_reply_to_status_id" : 715446849029713921,
  "created_at" : "2016-03-31 15:13:56 +0000",
  "in_reply_to_screen_name" : "ownClouders",
  "in_reply_to_user_id_str" : "361140100",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 0, 8 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 9, 16 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715297018059612162",
  "geo" : { },
  "id_str" : "715298818640588800",
  "in_reply_to_user_id" : 10185562,
  "text" : "@drchuck @btopro \uD83D\uDC4DI think the key now is the open and collaborative ecosystem we can plug into.",
  "id" : 715298818640588800,
  "in_reply_to_status_id" : 715297018059612162,
  "created_at" : "2016-03-30 22:05:02 +0000",
  "in_reply_to_screen_name" : "drchuck",
  "in_reply_to_user_id_str" : "10185562",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Royal Roads",
      "screen_name" : "RoyalRoads",
      "indices" : [ 3, 14 ],
      "id_str" : "19550956",
      "id" : 19550956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/ZAItEB60iu",
      "expanded_url" : "http:\/\/ow.ly\/106skW",
      "display_url" : "ow.ly\/106skW"
    } ]
  },
  "geo" : { },
  "id_str" : "715293816438149120",
  "text" : "RT @RoyalRoads: We're hiring a casual, on-call Instructional Designer. Apply by April 12: \nhttps:\/\/t.co\/ZAItEB60iu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/ZAItEB60iu",
        "expanded_url" : "http:\/\/ow.ly\/106skW",
        "display_url" : "ow.ly\/106skW"
      } ]
    },
    "geo" : { },
    "id_str" : "715286656379699200",
    "text" : "We're hiring a casual, on-call Instructional Designer. Apply by April 12: \nhttps:\/\/t.co\/ZAItEB60iu",
    "id" : 715286656379699200,
    "created_at" : "2016-03-30 21:16:42 +0000",
    "user" : {
      "name" : "Royal Roads",
      "screen_name" : "RoyalRoads",
      "protected" : false,
      "id_str" : "19550956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461912055604183040\/0dfDf2hp_normal.png",
      "id" : 19550956,
      "verified" : true
    }
  },
  "id" : 715293816438149120,
  "created_at" : "2016-03-30 21:45:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ownCloud",
      "screen_name" : "ownCloud",
      "indices" : [ 0, 9 ],
      "id_str" : "431454954",
      "id" : 431454954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715278839128018945",
  "in_reply_to_user_id" : 431454954,
  "text" : "@ownCloud With an ownCloud install, could I run a PHP flat-file (no database) CMS and then edit its files via ownCloud UI?",
  "id" : 715278839128018945,
  "created_at" : "2016-03-30 20:45:39 +0000",
  "in_reply_to_screen_name" : "ownCloud",
  "in_reply_to_user_id_str" : "431454954",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715236046091386880",
  "text" : "A flipped-LMS redistributes control: online UX moves to the hands of course participants while student admin remains in university's domain.",
  "id" : 715236046091386880,
  "created_at" : "2016-03-30 17:55:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lea Verou",
      "screen_name" : "LeaVerou",
      "indices" : [ 3, 12 ],
      "id_str" : "22199970",
      "id" : 22199970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715235665886072832",
  "text" : "RT @LeaVerou: Fascinating how computers started with command line UIs, then we got GUIs, and now we're going back to commands, but with nat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "715231587550371840",
    "text" : "Fascinating how computers started with command line UIs, then we got GUIs, and now we're going back to commands, but with natural language.",
    "id" : 715231587550371840,
    "created_at" : "2016-03-30 17:37:53 +0000",
    "user" : {
      "name" : "Lea Verou",
      "screen_name" : "LeaVerou",
      "protected" : false,
      "id_str" : "22199970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/584963092120899586\/TxkxQ7Y5_normal.png",
      "id" : 22199970,
      "verified" : true
    }
  },
  "id" : 715235665886072832,
  "created_at" : "2016-03-30 17:54:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/S5fkjUEjFc",
      "expanded_url" : "https:\/\/twitter.com\/btopro\/status\/715220013578227712",
      "display_url" : "twitter.com\/btopro\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715223067564187648",
  "text" : "Automation is insightfully highlighted as a means to support a more decentralized approach to Faculty edtech use. \uD83D\uDC4D https:\/\/t.co\/S5fkjUEjFc",
  "id" : 715223067564187648,
  "created_at" : "2016-03-30 17:04:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714944195660615681",
  "text" : "I've found keeping track of things that energize you is one of the best things you can do work-wise. \u2764 building an open design practice.",
  "id" : 714944195660615681,
  "created_at" : "2016-03-29 22:35:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/ccEOUE1eUO",
      "expanded_url" : "https:\/\/getgrav.org\/blog\/version-1.1-coming-soon",
      "display_url" : "getgrav.org\/blog\/version-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714932745965678592",
  "text" : "RT @getgrav: Find out what's coming in Grav Core + Admin Plugin v1.1 and when you can get your hands on it! https:\/\/t.co\/ccEOUE1eUO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/ccEOUE1eUO",
        "expanded_url" : "https:\/\/getgrav.org\/blog\/version-1.1-coming-soon",
        "display_url" : "getgrav.org\/blog\/version-1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "714924446683766784",
    "text" : "Find out what's coming in Grav Core + Admin Plugin v1.1 and when you can get your hands on it! https:\/\/t.co\/ccEOUE1eUO",
    "id" : 714924446683766784,
    "created_at" : "2016-03-29 21:17:25 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 714932745965678592,
  "created_at" : "2016-03-29 21:50:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jqQHqddup9",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-18-flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714906212735647745",
  "text" : "Change your LMS from a leading character to a supporting one by flipping it with an open and collaborative platform: https:\/\/t.co\/jqQHqddup9",
  "id" : 714906212735647745,
  "created_at" : "2016-03-29 20:04:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/sczxkfZsrM",
      "expanded_url" : "https:\/\/workflowy.com\/s\/cxAg2TgP9b",
      "display_url" : "workflowy.com\/s\/cxAg2TgP9b"
    } ]
  },
  "geo" : { },
  "id_str" : "714889582777491456",
  "text" : "UPDATE #2: Are you an instructor or students with a minute to spare? Are these online course tasks relatable to you? https:\/\/t.co\/sczxkfZsrM",
  "id" : 714889582777491456,
  "created_at" : "2016-03-29 18:58:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Hill",
      "screen_name" : "PhilOnEdTech",
      "indices" : [ 0, 13 ],
      "id_str" : "17997570",
      "id" : 17997570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/jqQHqddup9",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-18-flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "714524691193573377",
  "geo" : { },
  "id_str" : "714859783786876928",
  "in_reply_to_user_id" : 17997570,
  "text" : "@PhilOnEdTech Do you think a flipped-LMS approach could also be a means to support different types of professors? https:\/\/t.co\/jqQHqddup9",
  "id" : 714859783786876928,
  "in_reply_to_status_id" : 714524691193573377,
  "created_at" : "2016-03-29 17:00:28 +0000",
  "in_reply_to_screen_name" : "PhilOnEdTech",
  "in_reply_to_user_id_str" : "17997570",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/jqQHqddup9",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-18-flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714857499187290112",
  "text" : "Updated Post: https:\/\/t.co\/jqQHqddup9 Does this revised blog post better communicate what flipping your LMS is all about?",
  "id" : 714857499187290112,
  "created_at" : "2016-03-29 16:51:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aleksander Ku\u015B",
      "screen_name" : "Kivlov84",
      "indices" : [ 0, 9 ],
      "id_str" : "224202618",
      "id" : 224202618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714719969569849348",
  "geo" : { },
  "id_str" : "714855368380166144",
  "in_reply_to_user_id" : 224202618,
  "text" : "@Kivlov84 Thanks very much, all is going well so far and I hope to dig deeper into things soon.",
  "id" : 714855368380166144,
  "in_reply_to_status_id" : 714719969569849348,
  "created_at" : "2016-03-29 16:42:55 +0000",
  "in_reply_to_screen_name" : "Kivlov84",
  "in_reply_to_user_id_str" : "224202618",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Buxton",
      "screen_name" : "wasbuxton",
      "indices" : [ 0, 10 ],
      "id_str" : "57046779",
      "id" : 57046779
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/714634654880403456\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/NirJkoQvI0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CerigyPW8AA0iKR.jpg",
      "id_str" : "714632543761526784",
      "id" : 714632543761526784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CerigyPW8AA0iKR.jpg",
      "sizes" : [ {
        "h" : 248,
        "resize" : "fit",
        "w" : 370
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 370
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 370
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NirJkoQvI0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714634654880403456",
  "in_reply_to_user_id" : 57046779,
  "text" : "@wasbuxton Does this HC Stack ring a bell? In early 90's you kindly provided me advice - I never forgot, thank you. https:\/\/t.co\/NirJkoQvI0",
  "id" : 714634654880403456,
  "created_at" : "2016-03-29 02:05:53 +0000",
  "in_reply_to_screen_name" : "wasbuxton",
  "in_reply_to_user_id_str" : "57046779",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/714617259763699714\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/slVVHTDgsa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CerUC1WWEAArpVe.jpg",
      "id_str" : "714616636037271552",
      "id" : 714616636037271552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CerUC1WWEAArpVe.jpg",
      "sizes" : [ {
        "h" : 248,
        "resize" : "fit",
        "w" : 370
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 370
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 370
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/slVVHTDgsa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714617259763699714",
  "text" : "Monday night stroll down memory lane with my interactive HyperCard personal profile, circa early 1990's. https:\/\/t.co\/slVVHTDgsa",
  "id" : 714617259763699714,
  "created_at" : "2016-03-29 00:56:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "512pixels.net",
      "screen_name" : "512px",
      "indices" : [ 3, 9 ],
      "id_str" : "62113055",
      "id" : 62113055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/YhxXIXRol0",
      "expanded_url" : "http:\/\/www.512pixels.net\/blog\/2016\/3\/simple-beep-35-hypercard",
      "display_url" : "512pixels.net\/blog\/2016\/3\/si\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714616267995373568",
  "text" : "RT @512px: Simple Beep #35: HyperCard \u2192 https:\/\/t.co\/YhxXIXRol0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/feed.press\" rel=\"nofollow\"\u003EFeedPress Publisher\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/YhxXIXRol0",
        "expanded_url" : "http:\/\/www.512pixels.net\/blog\/2016\/3\/simple-beep-35-hypercard",
        "display_url" : "512pixels.net\/blog\/2016\/3\/si\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "713818372358610944",
    "text" : "Simple Beep #35: HyperCard \u2192 https:\/\/t.co\/YhxXIXRol0",
    "id" : 713818372358610944,
    "created_at" : "2016-03-26 20:02:16 +0000",
    "user" : {
      "name" : "512pixels.net",
      "screen_name" : "512px",
      "protected" : false,
      "id_str" : "62113055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649062185067409408\/KHGJnnKz_normal.png",
      "id" : 62113055,
      "verified" : false
    }
  },
  "id" : 714616267995373568,
  "created_at" : "2016-03-29 00:52:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexey Zagalsky",
      "screen_name" : "alexeyzagalsky",
      "indices" : [ 0, 15 ],
      "id_str" : "597572114",
      "id" : 597572114
    }, {
      "name" : "Buddy",
      "screen_name" : "BuddyGit",
      "indices" : [ 16, 25 ],
      "id_str" : "3055936108",
      "id" : 3055936108
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 101, 109 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714563461812985856",
  "geo" : { },
  "id_str" : "714571461021810689",
  "in_reply_to_user_id" : 597572114,
  "text" : "@alexeyzagalsky @BuddyGit Thanks for sharing this Alexey, BuddyGit looks very promising for use with @getgrav and my Grav Course Hub users.",
  "id" : 714571461021810689,
  "in_reply_to_status_id" : 714563461812985856,
  "created_at" : "2016-03-28 21:54:47 +0000",
  "in_reply_to_screen_name" : "alexeyzagalsky",
  "in_reply_to_user_id_str" : "597572114",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 34, 42 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714563766709592064",
  "text" : "Well-designed flexibility is what @getgrav is all about. For example you can store your entire site, user folder or only content on GitHub.",
  "id" : 714563766709592064,
  "created_at" : "2016-03-28 21:24:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Gothelf",
      "screen_name" : "jboogie",
      "indices" : [ 3, 11 ],
      "id_str" : "9384812",
      "id" : 9384812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714311657665658881",
  "text" : "RT @jboogie: I know it seems like a shared machine improves the conference experience but in reality it compromises the quality of the pres\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "714064900973322241",
    "text" : "I know it seems like a shared machine improves the conference experience but in reality it compromises the quality of the presentations.",
    "id" : 714064900973322241,
    "created_at" : "2016-03-27 12:21:53 +0000",
    "user" : {
      "name" : "Jeff Gothelf",
      "screen_name" : "jboogie",
      "protected" : false,
      "id_str" : "9384812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725599999644602368\/W95reVDZ_normal.jpg",
      "id" : 9384812,
      "verified" : true
    }
  },
  "id" : 714311657665658881,
  "created_at" : "2016-03-28 04:42:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 72, 80 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "D2L",
      "indices" : [ 105, 109 ]
    }, {
      "text" : "Blackboard",
      "indices" : [ 110, 121 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 122, 132 ]
    }, {
      "text" : "Moodle",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713805829388906496",
  "text" : "Course Hub Getting Started Guide for instructors to flip their LMS with @getgrav https:\/\/t.co\/VgQsw7bHP4 #D2L #Blackboard #CanvasLMS #Moodle",
  "id" : 713805829388906496,
  "created_at" : "2016-03-26 19:12:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/Wv6LaP2r1e",
      "expanded_url" : "http:\/\/questbe.at\/pophub\/",
      "display_url" : "questbe.at\/pophub\/"
    } ]
  },
  "geo" : { },
  "id_str" : "713785443163111424",
  "text" : "PopHub GitHub Feed Reader is a great companion to GitHub Desktop on the Mac. https:\/\/t.co\/Wv6LaP2r1e",
  "id" : 713785443163111424,
  "created_at" : "2016-03-26 17:51:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maureen Mackey",
      "screen_name" : "maureenamackey",
      "indices" : [ 0, 15 ],
      "id_str" : "43961502",
      "id" : 43961502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713411058967273476",
  "geo" : { },
  "id_str" : "713413092063875072",
  "in_reply_to_user_id" : 43961502,
  "text" : "@maureenamackey Thanks very much for your feedback Maureen, greatly appreciated!",
  "id" : 713413092063875072,
  "in_reply_to_status_id" : 713411058967273476,
  "created_at" : "2016-03-25 17:11:50 +0000",
  "in_reply_to_screen_name" : "maureenamackey",
  "in_reply_to_user_id_str" : "43961502",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/sczxkfZsrM",
      "expanded_url" : "https:\/\/workflowy.com\/s\/cxAg2TgP9b",
      "display_url" : "workflowy.com\/s\/cxAg2TgP9b"
    } ]
  },
  "geo" : { },
  "id_str" : "713407622561472512",
  "text" : "UPDATED: Are you an instructor or student with a minute to spare? Do these online course tasks seem relatable to you?https:\/\/t.co\/sczxkfZsrM",
  "id" : 713407622561472512,
  "created_at" : "2016-03-25 16:50:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 13, 20 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 21, 35 ],
      "id_str" : "41268670",
      "id" : 41268670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/5YbJIEv9gr",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "713103431074914304",
  "geo" : { },
  "id_str" : "713104414421069824",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @btopro @_mike_collins I've been working on a series of workshops to help tech-savvy Faculty get going https:\/\/t.co\/5YbJIEv9gr",
  "id" : 713104414421069824,
  "in_reply_to_status_id" : 713103431074914304,
  "created_at" : "2016-03-24 20:45:15 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 13, 20 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 21, 35 ],
      "id_str" : "41268670",
      "id" : 41268670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "713102089786777601",
  "geo" : { },
  "id_str" : "713103538486816768",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @btopro @_mike_collins Starter kit for instructors to use Grav at https:\/\/t.co\/VgQsw7bHP4 Grav has been a game changer for me!",
  "id" : 713103538486816768,
  "in_reply_to_status_id" : 713102089786777601,
  "created_at" : "2016-03-24 20:41:47 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 13, 20 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 21, 35 ],
      "id_str" : "41268670",
      "id" : 41268670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/Q6kKV4cPSv",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-153\/",
      "display_url" : "paulhibbitts.net\/cmpt-363-153\/"
    } ]
  },
  "in_reply_to_status_id_str" : "713102089786777601",
  "geo" : { },
  "id_str" : "713103258642882564",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @btopro @_mike_collins \uD83D\uDC4D You can see a live course, with full GitHub editing ability, at https:\/\/t.co\/Q6kKV4cPSv",
  "id" : 713103258642882564,
  "in_reply_to_status_id" : 713102089786777601,
  "created_at" : "2016-03-24 20:40:40 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 12, 19 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/xky1rbWLdt",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-07-using-grav-as-a-simple-open-publishing-tool",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713102965557432323",
  "text" : "Inspired by @btopro (as I often am), here is a goodie from the past: https:\/\/t.co\/xky1rbWLdt Collaboration and simple archiving key issues.",
  "id" : 713102965557432323,
  "created_at" : "2016-03-24 20:39:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 8, 22 ],
      "id_str" : "41268670",
      "id" : 41268670
    }, {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 33, 45 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/xky1rbWLdt",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-07-using-grav-as-a-simple-open-publishing-tool",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "713099036157427712",
  "geo" : { },
  "id_str" : "713100708195622912",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @_mike_collins Good read @billymeinke! You might be interested in how flat-file CMS's work with GitHub too https:\/\/t.co\/xky1rbWLdt",
  "id" : 713100708195622912,
  "in_reply_to_status_id" : 713099036157427712,
  "created_at" : "2016-03-24 20:30:32 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SourceLair",
      "screen_name" : "sourcelair",
      "indices" : [ 3, 14 ],
      "id_str" : "244491121",
      "id" : 244491121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/yJk07LyBwS",
      "expanded_url" : "https:\/\/www.sourcelair.com\/blog\/articles\/106\/browsersync",
      "display_url" : "sourcelair.com\/blog\/articles\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712817862860115968",
  "text" : "RT @sourcelair: Introducing Browsersync: Develop your websites rapidly without refreshing your browser window. https:\/\/t.co\/yJk07LyBwS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/yJk07LyBwS",
        "expanded_url" : "https:\/\/www.sourcelair.com\/blog\/articles\/106\/browsersync",
        "display_url" : "sourcelair.com\/blog\/articles\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712669819166973952",
    "text" : "Introducing Browsersync: Develop your websites rapidly without refreshing your browser window. https:\/\/t.co\/yJk07LyBwS",
    "id" : 712669819166973952,
    "created_at" : "2016-03-23 15:58:20 +0000",
    "user" : {
      "name" : "SourceLair",
      "screen_name" : "sourcelair",
      "protected" : false,
      "id_str" : "244491121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/418847702856630272\/Qr4UI20Z_normal.png",
      "id" : 244491121,
      "verified" : false
    }
  },
  "id" : 712817862860115968,
  "created_at" : "2016-03-24 01:46:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712804402453565440",
  "text" : "(3\/3) Estimated Grav Course Hub 'development' activities (Jan-Mar):\n10% Presentation materials\n10% Social media sharing\/engagement\n#GravEdu",
  "id" : 712804402453565440,
  "created_at" : "2016-03-24 00:53:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712804371939987456",
  "text" : "(2\/3) Estimated Grav Course Hub 'development' activities (Jan-Mar):\n15% Documentation\n10% Usability assessments\n#GravEdu",
  "id" : 712804371939987456,
  "created_at" : "2016-03-24 00:53:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712804343896903682",
  "text" : "(1\/3) Estimated Grav Course Hub 'development' activities (Jan-Mar):\n25% Prototyping\/development\n15% Research\n15% Design\n#GravEdu",
  "id" : 712804343896903682,
  "created_at" : "2016-03-24 00:52:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pedago.me",
      "screen_name" : "pedagome",
      "indices" : [ 3, 12 ],
      "id_str" : "707149866095345664",
      "id" : 707149866095345664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/6s05HH3GFx",
      "expanded_url" : "http:\/\/bit.ly\/22EW3jL",
      "display_url" : "bit.ly\/22EW3jL"
    } ]
  },
  "geo" : { },
  "id_str" : "712795464697913345",
  "text" : "RT @pedagome: User Experience Design &amp; Research Jargons \n https:\/\/t.co\/6s05HH3GFx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/6s05HH3GFx",
        "expanded_url" : "http:\/\/bit.ly\/22EW3jL",
        "display_url" : "bit.ly\/22EW3jL"
      } ]
    },
    "geo" : { },
    "id_str" : "712608677119860736",
    "text" : "User Experience Design &amp; Research Jargons \n https:\/\/t.co\/6s05HH3GFx",
    "id" : 712608677119860736,
    "created_at" : "2016-03-23 11:55:22 +0000",
    "user" : {
      "name" : "pedago.me",
      "screen_name" : "pedagome",
      "protected" : false,
      "id_str" : "707149866095345664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756141627161182208\/8R-s8dnN_normal.jpg",
      "id" : 707149866095345664,
      "verified" : false
    }
  },
  "id" : 712795464697913345,
  "created_at" : "2016-03-24 00:17:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Baxley",
      "screen_name" : "bbaxley",
      "indices" : [ 0, 8 ],
      "id_str" : "14161605",
      "id" : 14161605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712786047197966337",
  "geo" : { },
  "id_str" : "712787602726760448",
  "in_reply_to_user_id" : 14161605,
  "text" : "@bbaxley Risk vs. reward ratio involved (as in authoritarian decision-making also supports the highest risk)?",
  "id" : 712787602726760448,
  "in_reply_to_status_id" : 712786047197966337,
  "created_at" : "2016-03-23 23:46:22 +0000",
  "in_reply_to_screen_name" : "bbaxley",
  "in_reply_to_user_id_str" : "14161605",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/IOaA4vQTvb",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/etug-tell-2016-flipping-the-lms-with-an-open-and-collaborative-platform",
      "display_url" : "slides.com\/paulhibbitts\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712762460369911808",
  "text" : "In case you missed it yesterday, here are my 'Flipping the LMS with an Open and Collaborative Web Platform' slides https:\/\/t.co\/IOaA4vQTvb",
  "id" : 712762460369911808,
  "created_at" : "2016-03-23 22:06:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darren Hood, MSIME",
      "screen_name" : "darrenhood",
      "indices" : [ 3, 14 ],
      "id_str" : "14921648",
      "id" : 14921648
    }, {
      "name" : "Louis Rosenfeld",
      "screen_name" : "louisrosenfeld",
      "indices" : [ 104, 119 ],
      "id_str" : "1760431",
      "id" : 1760431
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UTWebinar",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712757803396390913",
  "text" : "RT @darrenhood: Many people are gaining knowledge of UX... just enough, in some cases, to be dangerous. @louisrosenfeld #UTWebinar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Louis Rosenfeld",
        "screen_name" : "louisrosenfeld",
        "indices" : [ 88, 103 ],
        "id_str" : "1760431",
        "id" : 1760431
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UTWebinar",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "712708921400627201",
    "text" : "Many people are gaining knowledge of UX... just enough, in some cases, to be dangerous. @louisrosenfeld #UTWebinar",
    "id" : 712708921400627201,
    "created_at" : "2016-03-23 18:33:43 +0000",
    "user" : {
      "name" : "Darren Hood, MSIME",
      "screen_name" : "darrenhood",
      "protected" : false,
      "id_str" : "14921648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000676420821\/684639e20ad82f4abd0b10ac1e30d858_normal.png",
      "id" : 14921648,
      "verified" : false
    }
  },
  "id" : 712757803396390913,
  "created_at" : "2016-03-23 21:47:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/ccS9DeV8ou",
      "expanded_url" : "http:\/\/www.ibm.com\/design\/thinking\/loop\/",
      "display_url" : "ibm.com\/design\/thinkin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712748696425750529",
  "text" : "I am really tempted to use this model for my next introductory UX course. https:\/\/t.co\/ccS9DeV8ou Fellow UX'ers, what do you think?",
  "id" : 712748696425750529,
  "created_at" : "2016-03-23 21:11:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ccS9DeV8ou",
      "expanded_url" : "http:\/\/www.ibm.com\/design\/thinking\/loop\/",
      "display_url" : "ibm.com\/design\/thinkin\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "712706912446361602",
  "geo" : { },
  "id_str" : "712747919581908992",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco In terms of process I quite like IBM's recent Design Thinking model as a framework and applicable to LX: https:\/\/t.co\/ccS9DeV8ou",
  "id" : 712747919581908992,
  "in_reply_to_status_id" : 712706912446361602,
  "created_at" : "2016-03-23 21:08:40 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristina Halvorson",
      "screen_name" : "halvorson",
      "indices" : [ 3, 13 ],
      "id_str" : "14335160",
      "id" : 14335160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/Tm4RWKGmGM",
      "expanded_url" : "http:\/\/www.bland.ly\/#blandly",
      "display_url" : "bland.ly\/#blandly"
    } ]
  },
  "geo" : { },
  "id_str" : "712745871335501824",
  "text" : "RT @halvorson: Pretty much the most brilliant parody agency site you have ever seen. https:\/\/t.co\/Tm4RWKGmGM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/Tm4RWKGmGM",
        "expanded_url" : "http:\/\/www.bland.ly\/#blandly",
        "display_url" : "bland.ly\/#blandly"
      } ]
    },
    "geo" : { },
    "id_str" : "712731168278323204",
    "text" : "Pretty much the most brilliant parody agency site you have ever seen. https:\/\/t.co\/Tm4RWKGmGM",
    "id" : 712731168278323204,
    "created_at" : "2016-03-23 20:02:07 +0000",
    "user" : {
      "name" : "Kristina Halvorson",
      "screen_name" : "halvorson",
      "protected" : false,
      "id_str" : "14335160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554377526860976128\/_CYBcpTq_normal.jpeg",
      "id" : 14335160,
      "verified" : false
    }
  },
  "id" : 712745871335501824,
  "created_at" : "2016-03-23 21:00:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Warunika Ranaweera",
      "screen_name" : "WarunikaR",
      "indices" : [ 0, 10 ],
      "id_str" : "773940438",
      "id" : 773940438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712721260006903809",
  "geo" : { },
  "id_str" : "712729878173364224",
  "in_reply_to_user_id" : 773940438,
  "text" : "@WarunikaR Marika loved your photo!",
  "id" : 712729878173364224,
  "in_reply_to_status_id" : 712721260006903809,
  "created_at" : "2016-03-23 19:56:59 +0000",
  "in_reply_to_screen_name" : "WarunikaR",
  "in_reply_to_user_id_str" : "773940438",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Szymon Fiedler",
      "screen_name" : "fidelski",
      "indices" : [ 3, 12 ],
      "id_str" : "90142584",
      "id" : 90142584
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/fidelski\/status\/712703358222667781\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/j0wqSggGWq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeQH6WNW8AI1IlS.jpg",
      "id_str" : "712703340006797314",
      "id" : 712703340006797314,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeQH6WNW8AI1IlS.jpg",
      "sizes" : [ {
        "h" : 1344,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1344,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/j0wqSggGWq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712729588648923136",
  "text" : "RT @fidelski: Finally! https:\/\/t.co\/j0wqSggGWq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/fidelski\/status\/712703358222667781\/photo\/1",
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/j0wqSggGWq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeQH6WNW8AI1IlS.jpg",
        "id_str" : "712703340006797314",
        "id" : 712703340006797314,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeQH6WNW8AI1IlS.jpg",
        "sizes" : [ {
          "h" : 1344,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1344,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 788,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/j0wqSggGWq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "712703358222667781",
    "text" : "Finally! https:\/\/t.co\/j0wqSggGWq",
    "id" : 712703358222667781,
    "created_at" : "2016-03-23 18:11:36 +0000",
    "user" : {
      "name" : "Szymon Fiedler",
      "screen_name" : "fidelski",
      "protected" : false,
      "id_str" : "90142584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540209237394092032\/Wb05Bbvc_normal.jpeg",
      "id" : 90142584,
      "verified" : false
    }
  },
  "id" : 712729588648923136,
  "created_at" : "2016-03-23 19:55:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712706912446361602",
  "geo" : { },
  "id_str" : "712727775874981888",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Also, 6 core UX techniques I often apply to LX:\nContextual Inquiry\nEmpathy Maps\nFive W's\nJob Stories\nPrototyping\nUsability Tests",
  "id" : 712727775874981888,
  "in_reply_to_status_id" : 712706912446361602,
  "created_at" : "2016-03-23 19:48:38 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/DpQ3fvB4NZ",
      "expanded_url" : "http:\/\/shop.oreilly.com\/product\/0636920035084.do?cmp=tw-design-books-videos-product-lgen_ux_for_beginners__jj#PowerReview",
      "display_url" : "shop.oreilly.com\/product\/063692\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "712706912446361602",
  "geo" : { },
  "id_str" : "712715200063901697",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco There is a new UX book that could be great for LX folks, have a peek and let me know your thoughts https:\/\/t.co\/DpQ3fvB4NZ",
  "id" : 712715200063901697,
  "in_reply_to_status_id" : 712706912446361602,
  "created_at" : "2016-03-23 18:58:39 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712703169654947840",
  "geo" : { },
  "id_str" : "712705533778595840",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco In terms of related UX techniques?",
  "id" : 712705533778595840,
  "in_reply_to_status_id" : 712703169654947840,
  "created_at" : "2016-03-23 18:20:15 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712697304017276928",
  "geo" : { },
  "id_str" : "712699049720176640",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Love this Holly! I am also a big fan of the 5 moments of need model \uD83D\uDE42",
  "id" : 712699049720176640,
  "in_reply_to_status_id" : 712697304017276928,
  "created_at" : "2016-03-23 17:54:29 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 3, 14 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/sparkandco\/status\/712697304017276928\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/BiiCsNUFaH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeQCa7yUIAAenUv.png",
      "id_str" : "712697302779961344",
      "id" : 712697302779961344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeQCa7yUIAAenUv.png",
      "sizes" : [ {
        "h" : 350,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BiiCsNUFaH"
    } ],
    "hashtags" : [ {
      "text" : "LX",
      "indices" : [ 47, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/U5IU8jTE1Q",
      "expanded_url" : "https:\/\/sparkyourinterest.wordpress.com\/2016\/03\/23\/designing-a-learning-journey-lx",
      "display_url" : "sparkyourinterest.wordpress.com\/2016\/03\/23\/des\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712698649189306368",
  "text" : "RT @sparkandco: Designing a \u201CLearning Journey\u201D\u00A0#LX https:\/\/t.co\/U5IU8jTE1Q https:\/\/t.co\/BiiCsNUFaH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/sparkandco\/status\/712697304017276928\/photo\/1",
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/BiiCsNUFaH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeQCa7yUIAAenUv.png",
        "id_str" : "712697302779961344",
        "id" : 712697302779961344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeQCa7yUIAAenUv.png",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 597,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 597,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/BiiCsNUFaH"
      } ],
      "hashtags" : [ {
        "text" : "LX",
        "indices" : [ 31, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/U5IU8jTE1Q",
        "expanded_url" : "https:\/\/sparkyourinterest.wordpress.com\/2016\/03\/23\/designing-a-learning-journey-lx",
        "display_url" : "sparkyourinterest.wordpress.com\/2016\/03\/23\/des\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712697304017276928",
    "text" : "Designing a \u201CLearning Journey\u201D\u00A0#LX https:\/\/t.co\/U5IU8jTE1Q https:\/\/t.co\/BiiCsNUFaH",
    "id" : 712697304017276928,
    "created_at" : "2016-03-23 17:47:33 +0000",
    "user" : {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "protected" : false,
      "id_str" : "47105948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656831720809889792\/aQbeijGD_normal.png",
      "id" : 47105948,
      "verified" : false
    }
  },
  "id" : 712698649189306368,
  "created_at" : "2016-03-23 17:52:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olark Live Chat",
      "screen_name" : "olark",
      "indices" : [ 31, 37 ],
      "id_str" : "21672965",
      "id" : 21672965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712698119775850496",
  "text" : "Thumbs up to the great team at @olark for diagnosing and fixing a long-standing security certificate issue I was having on my end. \uD83D\uDC4D",
  "id" : 712698119775850496,
  "created_at" : "2016-03-23 17:50:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SourceLair",
      "screen_name" : "sourcelair",
      "indices" : [ 0, 11 ],
      "id_str" : "244491121",
      "id" : 244491121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712678071497801728",
  "geo" : { },
  "id_str" : "712679249077870592",
  "in_reply_to_user_id" : 244491121,
  "text" : "@sourcelair Ah, makes sense :-) As my projects are PHP-based (using Grav CMS) I guess then using BrowserSync is not possible at this time?",
  "id" : 712679249077870592,
  "in_reply_to_status_id" : 712678071497801728,
  "created_at" : "2016-03-23 16:35:48 +0000",
  "in_reply_to_screen_name" : "sourcelair",
  "in_reply_to_user_id_str" : "244491121",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SourceLair",
      "screen_name" : "sourcelair",
      "indices" : [ 0, 11 ],
      "id_str" : "244491121",
      "id" : 244491121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712669819166973952",
  "geo" : { },
  "id_str" : "712674436038561792",
  "in_reply_to_user_id" : 244491121,
  "text" : "@sourcelair This looks amazing! Where could I learn how to get this going with sourceLair?",
  "id" : 712674436038561792,
  "in_reply_to_status_id" : 712669819166973952,
  "created_at" : "2016-03-23 16:16:41 +0000",
  "in_reply_to_screen_name" : "sourcelair",
  "in_reply_to_user_id_str" : "244491121",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SourceLair",
      "screen_name" : "sourcelair",
      "indices" : [ 16, 27 ],
      "id_str" : "244491121",
      "id" : 244491121
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 85, 93 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/zyzIpo0Bre",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-03-22-using-sourcelair-with-grav-and-github",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712662731665453057",
  "text" : "New Post: Using @sourcelair online integrated development environment (IDE) with the @getgrav CMS and GitHub. https:\/\/t.co\/zyzIpo0Bre",
  "id" : 712662731665453057,
  "created_at" : "2016-03-23 15:30:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SitePoint",
      "screen_name" : "sitepointdotcom",
      "indices" : [ 87, 103 ],
      "id_str" : "15743570",
      "id" : 15743570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/3tkQL0YaIt",
      "expanded_url" : "http:\/\/www.sitepoint.com\/building-faster-websites-with-grav-a-modern-flat-file-cms\/",
      "display_url" : "sitepoint.com\/building-faste\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712655316907724802",
  "text" : "Building Faster Websites with Grav, a Modern Flat-file CMS https:\/\/t.co\/3tkQL0YaIt via @sitepointdotcom",
  "id" : 712655316907724802,
  "created_at" : "2016-03-23 15:00:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Haw",
      "screen_name" : "andrewhawr",
      "indices" : [ 0, 11 ],
      "id_str" : "742214790",
      "id" : 742214790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712441463146033152",
  "geo" : { },
  "id_str" : "712444974093049861",
  "in_reply_to_user_id" : 742214790,
  "text" : "@andrewhawr Perhaps :-) I think you could slice and dice with HTML, CSS, Twig, Git, and perhaps Server setup being a nice subset too!",
  "id" : 712444974093049861,
  "in_reply_to_status_id" : 712441463146033152,
  "created_at" : "2016-03-23 01:04:53 +0000",
  "in_reply_to_screen_name" : "andrewhawr",
  "in_reply_to_user_id_str" : "742214790",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Haw",
      "screen_name" : "andrewhawr",
      "indices" : [ 0, 11 ],
      "id_str" : "742214790",
      "id" : 742214790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712437538560970752",
  "geo" : { },
  "id_str" : "712440715859496964",
  "in_reply_to_user_id" : 742214790,
  "text" : "@andrewhawr Will do! Perhaps in the future add a module about Twig? I have found it sooo much easier than PHP when used for templating.",
  "id" : 712440715859496964,
  "in_reply_to_status_id" : 712437538560970752,
  "created_at" : "2016-03-23 00:47:57 +0000",
  "in_reply_to_screen_name" : "andrewhawr",
  "in_reply_to_user_id_str" : "742214790",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/GNnOAnpSKm",
      "expanded_url" : "https:\/\/twitter.com\/drubeli\/status\/712418964123492353",
      "display_url" : "twitter.com\/drubeli\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712421772805558272",
  "text" : "And to riff on that, LX (Learner Experience) is not a subset of UX either. https:\/\/t.co\/GNnOAnpSKm",
  "id" : 712421772805558272,
  "created_at" : "2016-03-22 23:32:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712415210166812672",
  "text" : "Grav Course Hub skills?\n\u2713Code editor usage\n\u2713Markdown or HTML basics\n\u2713Understanding folder hierarchies\n\u2713Web server access\n\u2713GitHub basics",
  "id" : 712415210166812672,
  "created_at" : "2016-03-22 23:06:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/Z274jPWpSK",
      "expanded_url" : "https:\/\/atom.io\/docs\/latest\/",
      "display_url" : "atom.io\/docs\/latest\/"
    } ]
  },
  "geo" : { },
  "id_str" : "712408608705654784",
  "text" : "Atom Flight Manual\nhttps:\/\/t.co\/Z274jPWpSK",
  "id" : 712408608705654784,
  "created_at" : "2016-03-22 22:40:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/GeRQNuQeF5",
      "expanded_url" : "http:\/\/tv.adobe.com\/watch\/adc-presents\/getting-started-with-brackets\/",
      "display_url" : "tv.adobe.com\/watch\/adc-pres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712395857723719680",
  "text" : "Getting Started with Brackets | ADC Presents | Adobe TV https:\/\/t.co\/GeRQNuQeF5",
  "id" : 712395857723719680,
  "created_at" : "2016-03-22 21:49:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Haw",
      "screen_name" : "andrewhawr",
      "indices" : [ 0, 11 ],
      "id_str" : "742214790",
      "id" : 742214790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712386606880006145",
  "in_reply_to_user_id" : 742214790,
  "text" : "@andrewhawr Awesome to see you are involved with SFU's Future Savvy! Looking forward to exploring the course.",
  "id" : 712386606880006145,
  "created_at" : "2016-03-22 21:12:57 +0000",
  "in_reply_to_screen_name" : "andrewhawr",
  "in_reply_to_user_id_str" : "742214790",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 3, 14 ],
      "id_str" : "1983141",
      "id" : 1983141
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 139, 140 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/5XLwzvkigL",
      "expanded_url" : "http:\/\/www.sfu.ca\/sfunews\/stories\/2016\/new-self-paced-coding-program-offers-full-stack-of-benefits.html?utm_source=hmpgfeat",
      "display_url" : "sfu.ca\/sfunews\/storie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712383240552644608",
  "text" : "RT @okalrelsrv: New self-paced coding program offers full stack of benefits - SFU News - Simon Fraser University https:\/\/t.co\/5XLwzvkigL vi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 125, 135 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/5XLwzvkigL",
        "expanded_url" : "http:\/\/www.sfu.ca\/sfunews\/stories\/2016\/new-self-paced-coding-program-offers-full-stack-of-benefits.html?utm_source=hmpgfeat",
        "display_url" : "sfu.ca\/sfunews\/storie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712362510423207936",
    "text" : "New self-paced coding program offers full stack of benefits - SFU News - Simon Fraser University https:\/\/t.co\/5XLwzvkigL via @sharethis",
    "id" : 712362510423207936,
    "created_at" : "2016-03-22 19:37:12 +0000",
    "user" : {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "protected" : false,
      "id_str" : "1983141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739951680591040512\/HosITGfQ_normal.jpg",
      "id" : 1983141,
      "verified" : false
    }
  },
  "id" : 712383240552644608,
  "created_at" : "2016-03-22 20:59:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maureen Mackey",
      "screen_name" : "maureenamackey",
      "indices" : [ 0, 15 ],
      "id_str" : "43961502",
      "id" : 43961502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712355959343976449",
  "geo" : { },
  "id_str" : "712356519732334592",
  "in_reply_to_user_id" : 43961502,
  "text" : "@maureenamackey Thanks very much, it was my pleasure!",
  "id" : 712356519732334592,
  "in_reply_to_status_id" : 712355959343976449,
  "created_at" : "2016-03-22 19:13:23 +0000",
  "in_reply_to_screen_name" : "maureenamackey",
  "in_reply_to_user_id_str" : "43961502",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 42, 47 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/4pcVXCEXW8",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/etug-tell-2016-flipping-the-lms-with-an-open-and-collaborative-platform#\/",
      "display_url" : "slides.com\/paulhibbitts\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712355284107137024",
  "text" : "Thanks to everyone who participated in my @etug 'Flip it Good!' session today. The slides are now available at https:\/\/t.co\/4pcVXCEXW8",
  "id" : 712355284107137024,
  "created_at" : "2016-03-22 19:08:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ari W",
      "screen_name" : "TravelingRE",
      "indices" : [ 3, 15 ],
      "id_str" : "234640581",
      "id" : 234640581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/sHKSHKbjKd",
      "expanded_url" : "http:\/\/bit.ly\/1ZmFua4",
      "display_url" : "bit.ly\/1ZmFua4"
    } ]
  },
  "geo" : { },
  "id_str" : "712322130709327872",
  "text" : "RT @TravelingRE: \u201CSUStisfied? Little-Known System Usability Scale Facts\n\u201D https:\/\/t.co\/sHKSHKbjKd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/sHKSHKbjKd",
        "expanded_url" : "http:\/\/bit.ly\/1ZmFua4",
        "display_url" : "bit.ly\/1ZmFua4"
      } ]
    },
    "geo" : { },
    "id_str" : "712285973384716288",
    "text" : "\u201CSUStisfied? Little-Known System Usability Scale Facts\n\u201D https:\/\/t.co\/sHKSHKbjKd",
    "id" : 712285973384716288,
    "created_at" : "2016-03-22 14:33:04 +0000",
    "user" : {
      "name" : "Ari W",
      "screen_name" : "TravelingRE",
      "protected" : false,
      "id_str" : "234640581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522141887117799424\/dF1puwnB_normal.jpeg",
      "id" : 234640581,
      "verified" : false
    }
  },
  "id" : 712322130709327872,
  "created_at" : "2016-03-22 16:56:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Il9Bj4pqW0",
      "expanded_url" : "https:\/\/etug.ca\/2016\/02\/09\/t-e-l-l-march-flip-it-good-flipping-the-lms-with-an-open-and-collaborative-platform\/",
      "display_url" : "etug.ca\/2016\/02\/09\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712310676773974017",
  "text" : "At 11:00 am I'll be sharing my experiences of flipping the LMS and an open source project to help others do the same https:\/\/t.co\/Il9Bj4pqW0",
  "id" : 712310676773974017,
  "created_at" : "2016-03-22 16:11:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 3, 15 ],
      "id_str" : "6271482",
      "id" : 6271482
    }, {
      "name" : "Tim Klapdor",
      "screen_name" : "timklapdor",
      "indices" : [ 119, 130 ],
      "id_str" : "174124175",
      "id" : 174124175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IndieEdTech",
      "indices" : [ 41, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/pArpKfH99U",
      "expanded_url" : "https:\/\/timklapdor.wordpress.com\/2016\/03\/22\/a-journey-to-discover-what-is-indie-ed-tech\/",
      "display_url" : "timklapdor.wordpress.com\/2016\/03\/22\/a-j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712294903644954624",
  "text" : "RT @grantpotter: https:\/\/t.co\/pArpKfH99U #IndieEdTech is \"infrastructure plus scholarship, agency, and autonomy.\"  via @timklapdor",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim Klapdor",
        "screen_name" : "timklapdor",
        "indices" : [ 102, 113 ],
        "id_str" : "174124175",
        "id" : 174124175
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IndieEdTech",
        "indices" : [ 24, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/pArpKfH99U",
        "expanded_url" : "https:\/\/timklapdor.wordpress.com\/2016\/03\/22\/a-journey-to-discover-what-is-indie-ed-tech\/",
        "display_url" : "timklapdor.wordpress.com\/2016\/03\/22\/a-j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712293410200276992",
    "text" : "https:\/\/t.co\/pArpKfH99U #IndieEdTech is \"infrastructure plus scholarship, agency, and autonomy.\"  via @timklapdor",
    "id" : 712293410200276992,
    "created_at" : "2016-03-22 15:02:37 +0000",
    "user" : {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "protected" : false,
      "id_str" : "6271482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639833921228640256\/S63CDenk_normal.jpg",
      "id" : 6271482,
      "verified" : false
    }
  },
  "id" : 712294903644954624,
  "created_at" : "2016-03-22 15:08:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Andreessen",
      "screen_name" : "pmarca",
      "indices" : [ 3, 10 ],
      "id_str" : "5943622",
      "id" : 5943622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712086072881061888",
  "text" : "RT @pmarca: RIP Andy Grove. The best company builder Silicon Valley has ever seen, and likely will ever see.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "712075953803907072",
    "text" : "RIP Andy Grove. The best company builder Silicon Valley has ever seen, and likely will ever see.",
    "id" : 712075953803907072,
    "created_at" : "2016-03-22 00:38:31 +0000",
    "user" : {
      "name" : "Marc Andreessen",
      "screen_name" : "pmarca",
      "protected" : false,
      "id_str" : "5943622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649108987128868864\/rWnwMe55_normal.jpg",
      "id" : 5943622,
      "verified" : true
    }
  },
  "id" : 712086072881061888,
  "created_at" : "2016-03-22 01:18:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barish Golland",
      "screen_name" : "BarishGolland",
      "indices" : [ 10, 24 ],
      "id_str" : "32352319",
      "id" : 32352319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/1C3J6flpV5",
      "expanded_url" : "http:\/\/wiki.ubc.ca\/Elearning:NewLMS\/Creating_Direct_Links",
      "display_url" : "wiki.ubc.ca\/Elearning:NewL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712068691618177024",
  "text" : "Thanks to @BarishGolland for pointing out this article to create deep-links for Blackboard re: flipping your LMS \uD83D\uDC4D  https:\/\/t.co\/1C3J6flpV5",
  "id" : 712068691618177024,
  "created_at" : "2016-03-22 00:09:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SourceLair",
      "screen_name" : "sourcelair",
      "indices" : [ 40, 51 ],
      "id_str" : "244491121",
      "id" : 244491121
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/712033967797641217\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ABk0ynQ7h8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeGnG-1WIAAqKGa.png",
      "id_str" : "712033954489049088",
      "id" : 712033954489049088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeGnG-1WIAAqKGa.png",
      "sizes" : [ {
        "h" : 814,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 947,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ABk0ynQ7h8"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/712033967797641217\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ABk0ynQ7h8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeGnHjMWoAEh9_h.png",
      "id_str" : "712033964249227265",
      "id" : 712033964249227265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeGnHjMWoAEh9_h.png",
      "sizes" : [ {
        "h" : 814,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 947,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ABk0ynQ7h8"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/712033967797641217\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ABk0ynQ7h8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeGnHp5WEAAlrcu.png",
      "id_str" : "712033966048546816",
      "id" : 712033966048546816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeGnHp5WEAAlrcu.png",
      "sizes" : [ {
        "h" : 814,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 947,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ABk0ynQ7h8"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/712033967797641217\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ABk0ynQ7h8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeGnHdAXIAEs5hw.png",
      "id_str" : "712033962588315649",
      "id" : 712033962588315649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeGnHdAXIAEs5hw.png",
      "sizes" : [ {
        "h" : 814,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 947,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ABk0ynQ7h8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712033967797641217",
  "text" : "Here's a look at how easy it is to have @sourcelair setup an online dev environ for your Grav sites stored on GitHub https:\/\/t.co\/ABk0ynQ7h8",
  "id" : 712033967797641217,
  "created_at" : "2016-03-21 21:51:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 50, 58 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/Il9Bj4pqW0",
      "expanded_url" : "https:\/\/etug.ca\/2016\/02\/09\/t-e-l-l-march-flip-it-good-flipping-the-lms-with-an-open-and-collaborative-platform\/",
      "display_url" : "etug.ca\/2016\/02\/09\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712019883152662528",
  "text" : "My @etug session about flipping your LMS with the @getgrav CMS is tomorrow at 11am PDT, hope to see you there! https:\/\/t.co\/Il9Bj4pqW0",
  "id" : 712019883152662528,
  "created_at" : "2016-03-21 20:55:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SourceLair",
      "screen_name" : "sourcelair",
      "indices" : [ 10, 21 ],
      "id_str" : "244491121",
      "id" : 244491121
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 60, 68 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712016812670496768",
  "text" : "Exploring @sourcelair for a cloud-based IDE for use with my @getgrav sites that use GitHub repositories. I like a lot of what I see so far \uD83D\uDC4D",
  "id" : 712016812670496768,
  "created_at" : "2016-03-21 20:43:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AppleEvent",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711977191685246977",
  "text" : "#AppleEvent Thud.",
  "id" : 711977191685246977,
  "created_at" : "2016-03-21 18:06:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Thurrott",
      "screen_name" : "thurrott",
      "indices" : [ 3, 12 ],
      "id_str" : "14964767",
      "id" : 14964767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711959493714706432",
  "text" : "RT @thurrott: Nothing quite like being forced to listen to Beats 1. It's like an Apple Watch ad that never ends.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "711959181633392640",
    "text" : "Nothing quite like being forced to listen to Beats 1. It's like an Apple Watch ad that never ends.",
    "id" : 711959181633392640,
    "created_at" : "2016-03-21 16:54:31 +0000",
    "user" : {
      "name" : "Paul Thurrott",
      "screen_name" : "thurrott",
      "protected" : false,
      "id_str" : "14964767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718435052779151360\/s1niU-q7_normal.jpg",
      "id" : 14964767,
      "verified" : false
    }
  },
  "id" : 711959493714706432,
  "created_at" : "2016-03-21 16:55:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EdMedia @SFU",
      "screen_name" : "EdMediaSFU",
      "indices" : [ 3, 14 ],
      "id_str" : "1428999450",
      "id" : 1428999450
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/EdMediaSFU\/status\/711952768332726272\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/V9zYTbMTCu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeFdO7-UEAAT-Jo.jpg",
      "id_str" : "711952727299854336",
      "id" : 711952727299854336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeFdO7-UEAAT-Jo.jpg",
      "sizes" : [ {
        "h" : 779,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 795,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 795,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/V9zYTbMTCu"
    } ],
    "hashtags" : [ {
      "text" : "EdMedia",
      "indices" : [ 20, 28 ]
    }, {
      "text" : "Typography",
      "indices" : [ 58, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711954117149597696",
  "text" : "RT @EdMediaSFU: The #EdMedia Monday for today is Everyday #Typography! Come join us at the TLC! https:\/\/t.co\/V9zYTbMTCu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/EdMediaSFU\/status\/711952768332726272\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/V9zYTbMTCu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeFdO7-UEAAT-Jo.jpg",
        "id_str" : "711952727299854336",
        "id" : 711952727299854336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeFdO7-UEAAT-Jo.jpg",
        "sizes" : [ {
          "h" : 779,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 795,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 795,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/V9zYTbMTCu"
      } ],
      "hashtags" : [ {
        "text" : "EdMedia",
        "indices" : [ 4, 12 ]
      }, {
        "text" : "Typography",
        "indices" : [ 42, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "711952768332726272",
    "text" : "The #EdMedia Monday for today is Everyday #Typography! Come join us at the TLC! https:\/\/t.co\/V9zYTbMTCu",
    "id" : 711952768332726272,
    "created_at" : "2016-03-21 16:29:02 +0000",
    "user" : {
      "name" : "EdMedia @SFU",
      "screen_name" : "EdMediaSFU",
      "protected" : false,
      "id_str" : "1428999450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604344596206768129\/ZQq4-HyL_normal.jpg",
      "id" : 1428999450,
      "verified" : false
    }
  },
  "id" : 711954117149597696,
  "created_at" : "2016-03-21 16:34:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 23, 31 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/711953915839787008\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/GU9T8eApaJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeFeUEBUIAA0Grk.jpg",
      "id_str" : "711953914870898688",
      "id" : 711953914870898688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeFeUEBUIAA0Grk.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GU9T8eApaJ"
    } ],
    "hashtags" : [ {
      "text" : "IndieEdTech",
      "indices" : [ 91, 103 ]
    }, {
      "text" : "GravEdu",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/9PFedwpqcF",
      "expanded_url" : "https:\/\/getgrav.org\/downloads\/skeletons",
      "display_url" : "getgrav.org\/downloads\/skel\u2026"
    }, {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711953915839787008",
  "text" : "A Spring update for my @getgrav Course Hub https:\/\/t.co\/9PFedwpqcF https:\/\/t.co\/VgQsw7bHP4 #IndieEdTech #GravEdu https:\/\/t.co\/GU9T8eApaJ",
  "id" : 711953915839787008,
  "created_at" : "2016-03-21 16:33:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hope Miller",
      "screen_name" : "aHEMpublishing",
      "indices" : [ 0, 15 ],
      "id_str" : "1299940627",
      "id" : 1299940627
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 16, 21 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Academic Technology",
      "screen_name" : "ATS_Douglas",
      "indices" : [ 22, 34 ],
      "id_str" : "2666730674",
      "id" : 2666730674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711945190177505280",
  "geo" : { },
  "id_str" : "711947911865565184",
  "in_reply_to_user_id" : 1299940627,
  "text" : "@aHEMpublishing @etug @ATS_Douglas Awesome to hear and greatly appreciated! Hope the new open source project might be of use too \uD83D\uDE42",
  "id" : 711947911865565184,
  "in_reply_to_status_id" : 711945190177505280,
  "created_at" : "2016-03-21 16:09:44 +0000",
  "in_reply_to_screen_name" : "aHEMpublishing",
  "in_reply_to_user_id_str" : "1299940627",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 67, 72 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/IOaA4vQTvb",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/etug-tell-2016-flipping-the-lms-with-an-open-and-collaborative-platform",
      "display_url" : "slides.com\/paulhibbitts\/e\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Il9Bj4pqW0",
      "expanded_url" : "https:\/\/etug.ca\/2016\/02\/09\/t-e-l-l-march-flip-it-good-flipping-the-lms-with-an-open-and-collaborative-platform\/",
      "display_url" : "etug.ca\/2016\/02\/09\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711699584909598720",
  "text" : "Late Sunday afternoon sneak-peek at this Tuesday's \"Flip it Good!\" @etug presentation: https:\/\/t.co\/IOaA4vQTvb Info: https:\/\/t.co\/Il9Bj4pqW0",
  "id" : 711699584909598720,
  "created_at" : "2016-03-20 23:42:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy L. Bissette",
      "screen_name" : "TLBissette",
      "indices" : [ 3, 14 ],
      "id_str" : "204032180",
      "id" : 204032180
    }, {
      "name" : "Jane Hart",
      "screen_name" : "C4LPT",
      "indices" : [ 19, 25 ],
      "id_str" : "14192174",
      "id" : 14192174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/8eC5mASlUn",
      "expanded_url" : "http:\/\/ow.ly\/3cE43q",
      "display_url" : "ow.ly\/3cE43q"
    } ]
  },
  "geo" : { },
  "id_str" : "711619649251639296",
  "text" : "RT @TLBissette: Fm @C4LPT: Supporting all the ways people learn at work https:\/\/t.co\/8eC5mASlUn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jane Hart",
        "screen_name" : "C4LPT",
        "indices" : [ 3, 9 ],
        "id_str" : "14192174",
        "id" : 14192174
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/8eC5mASlUn",
        "expanded_url" : "http:\/\/ow.ly\/3cE43q",
        "display_url" : "ow.ly\/3cE43q"
      } ]
    },
    "geo" : { },
    "id_str" : "711613844385300480",
    "text" : "Fm @C4LPT: Supporting all the ways people learn at work https:\/\/t.co\/8eC5mASlUn",
    "id" : 711613844385300480,
    "created_at" : "2016-03-20 18:02:16 +0000",
    "user" : {
      "name" : "Tracy L. Bissette",
      "screen_name" : "TLBissette",
      "protected" : false,
      "id_str" : "204032180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410924455\/d736a7d934b7b10b3199fe9dc6e2dfdf_normal.png",
      "id" : 204032180,
      "verified" : false
    }
  },
  "id" : 711619649251639296,
  "created_at" : "2016-03-20 18:25:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/zQN8ep6G4Z",
      "expanded_url" : "https:\/\/onedrive.live.com\/redir?resid=74D2D06DCB0AFD88!283380&authkey=!AJauXmUbMOnSuZ4&ithint=folder%2cpng",
      "display_url" : "onedrive.live.com\/redir?resid=74\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Il9Bj4pqW0",
      "expanded_url" : "https:\/\/etug.ca\/2016\/02\/09\/t-e-l-l-march-flip-it-good-flipping-the-lms-with-an-open-and-collaborative-platform\/",
      "display_url" : "etug.ca\/2016\/02\/09\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711324734617559040",
  "text" : "Here are the latest flipped-LMS diagrams, which will be part of my online session this Tues. https:\/\/t.co\/zQN8ep6G4Z https:\/\/t.co\/Il9Bj4pqW0",
  "id" : 711324734617559040,
  "created_at" : "2016-03-19 22:53:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/AwhgiMo3ak",
      "expanded_url" : "https:\/\/soundcloud.com\/githubcommunitycast\/episode1",
      "display_url" : "soundcloud.com\/githubcommunit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710955735853608960",
  "text" : "RT @getgrav: Our own Andy Miller recently talked Grav with the folks from the GitHub Community Cast podcast. https:\/\/t.co\/AwhgiMo3ak Enjoy!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/AwhgiMo3ak",
        "expanded_url" : "https:\/\/soundcloud.com\/githubcommunitycast\/episode1",
        "display_url" : "soundcloud.com\/githubcommunit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "710955570451206145",
    "text" : "Our own Andy Miller recently talked Grav with the folks from the GitHub Community Cast podcast. https:\/\/t.co\/AwhgiMo3ak Enjoy!",
    "id" : 710955570451206145,
    "created_at" : "2016-03-18 22:26:31 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 710955735853608960,
  "created_at" : "2016-03-18 22:27:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Il9Bj4pqW0",
      "expanded_url" : "https:\/\/etug.ca\/2016\/02\/09\/t-e-l-l-march-flip-it-good-flipping-the-lms-with-an-open-and-collaborative-platform\/",
      "display_url" : "etug.ca\/2016\/02\/09\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710955270373974016",
  "text" : "Are you a tech-savvy educator who wants control of an open platform to reach unmet pedagogical goals w. LMS backend? https:\/\/t.co\/Il9Bj4pqW0",
  "id" : 710955270373974016,
  "created_at" : "2016-03-18 22:25:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/RxNYHosh14",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/etug-tell-2016-flipping-the-lms-with-an-open-and-collaborative-platform#\/8",
      "display_url" : "slides.com\/paulhibbitts\/e\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "710934034008956932",
  "geo" : { },
  "id_str" : "710935712900653058",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro \uD83D\uDC4D  BTW, your super-awesome 'Back to the Dungeon' Tweet will be making an appearance in a preso on Tuesday https:\/\/t.co\/RxNYHosh14",
  "id" : 710935712900653058,
  "in_reply_to_status_id" : 710934034008956932,
  "created_at" : "2016-03-18 21:07:37 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 4, 12 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710932658864271361",
  "text" : "The @getgrav Course Hub audience? Tech-savvy educators needing control of an open platform to reach unmet pedagogical goals w. LMS backend.\uD83D\uDE4C",
  "id" : 710932658864271361,
  "created_at" : "2016-03-18 20:55:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 53, 58 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/710921275489648640\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/h1HkN6sdyU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cd2zIfDUAAADdR9.jpg",
      "id_str" : "710921274550124544",
      "id" : 710921274550124544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cd2zIfDUAAADdR9.jpg",
      "sizes" : [ {
        "h" : 658,
        "resize" : "fit",
        "w" : 1243
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 542,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/h1HkN6sdyU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/IOaA4vQTvb",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/etug-tell-2016-flipping-the-lms-with-an-open-and-collaborative-platform",
      "display_url" : "slides.com\/paulhibbitts\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710921275489648640",
  "text" : "Close to finishing the slides for my \"Flip It Good!\" @etug TELL session Mar 22 at 11am PDT https:\/\/t.co\/IOaA4vQTvb https:\/\/t.co\/h1HkN6sdyU",
  "id" : 710921275489648640,
  "created_at" : "2016-03-18 20:10:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 3, 15 ],
      "id_str" : "6271482",
      "id" : 6271482
    }, {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 92, 104 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcpse",
      "indices" : [ 119, 125 ]
    }, {
      "text" : "highered",
      "indices" : [ 126, 135 ]
    }, {
      "text" : "opensource",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/XX1cheQ8y4",
      "expanded_url" : "http:\/\/oet.sandcats.io",
      "display_url" : "oet.sandcats.io"
    } ]
  },
  "geo" : { },
  "id_str" : "710862888370483201",
  "text" : "RT @grantpotter: 89 users with 309 app grains at https:\/\/t.co\/XX1cheQ8y4 - come explore how @sandstormio can meet your #bcpse #highered #op\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/known.networkeffects.ca\" rel=\"nofollow\"\u003Eknown-twitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sandstorm.IO",
        "screen_name" : "SandstormIO",
        "indices" : [ 75, 87 ],
        "id_str" : "2476570038",
        "id" : 2476570038
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bcpse",
        "indices" : [ 102, 108 ]
      }, {
        "text" : "highered",
        "indices" : [ 109, 118 ]
      }, {
        "text" : "opensource",
        "indices" : [ 119, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/XX1cheQ8y4",
        "expanded_url" : "http:\/\/oet.sandcats.io",
        "display_url" : "oet.sandcats.io"
      } ]
    },
    "geo" : { },
    "id_str" : "710472038759141376",
    "text" : "89 users with 309 app grains at https:\/\/t.co\/XX1cheQ8y4 - come explore how @sandstormio can meet your #bcpse #highered #opensource needs",
    "id" : 710472038759141376,
    "created_at" : "2016-03-17 14:25:08 +0000",
    "user" : {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "protected" : false,
      "id_str" : "6271482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639833921228640256\/S63CDenk_normal.jpg",
      "id" : 6271482,
      "verified" : false
    }
  },
  "id" : 710862888370483201,
  "created_at" : "2016-03-18 16:18:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710623375350042624",
  "text" : "When Doc Searls said \"You don\u2019t make money with Open Source. You make money because of Open Source.\" he was, well, right on the money.",
  "id" : 710623375350042624,
  "created_at" : "2016-03-18 00:26:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/710591033873072132\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/hk3NB4Kz1a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdyGx4fUUAEWnPT.jpg",
      "id_str" : "710591032753147905",
      "id" : 710591032753147905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdyGx4fUUAEWnPT.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hk3NB4Kz1a"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/UDkA52gP6f",
      "expanded_url" : "https:\/\/getgrav.org\/downloads\/themes",
      "display_url" : "getgrav.org\/downloads\/them\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710591033873072132",
  "text" : "It's a green 1-dot-oh! My Bootstrap-based Course Hub theme for Grav CMS is now available at https:\/\/t.co\/UDkA52gP6f https:\/\/t.co\/hk3NB4Kz1a",
  "id" : 710591033873072132,
  "created_at" : "2016-03-17 22:17:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/tv9q3n8Pxr",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/",
      "display_url" : "hibbittsdesign.org\/blog\/"
    } ]
  },
  "geo" : { },
  "id_str" : "710563565439098880",
  "text" : "For the next hour you can chat 1-on-1 with me about flipping your LMS with the open Web platform Grav https:\/\/t.co\/tv9q3n8Pxr",
  "id" : 710563565439098880,
  "created_at" : "2016-03-17 20:28:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "indices" : [ 37, 51 ],
      "id_str" : "3296136369",
      "id" : 3296136369
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 107, 115 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/tv9q3n8Pxr",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/",
      "display_url" : "hibbittsdesign.org\/blog\/"
    } ]
  },
  "geo" : { },
  "id_str" : "710551388317569024",
  "text" : "I'll be online in one hour using the @RocketChatApp livechat beta to talk 1-on-1 about flipping your LMS w @getgrav https:\/\/t.co\/tv9q3n8Pxr",
  "id" : 710551388317569024,
  "created_at" : "2016-03-17 19:40:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "indices" : [ 51, 65 ],
      "id_str" : "3296136369",
      "id" : 3296136369
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 108, 116 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/tv9q3nqqW1",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/",
      "display_url" : "hibbittsdesign.org\/blog\/"
    } ]
  },
  "geo" : { },
  "id_str" : "710494838857330691",
  "text" : "I'll be online 1:30pm-2:30pm (PDT) today using the @RocketChatApp livechat beta to talk flipping your LMS w @getgrav https:\/\/t.co\/tv9q3nqqW1",
  "id" : 710494838857330691,
  "created_at" : "2016-03-17 15:55:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 20, 25 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Il9Bj4pqW0",
      "expanded_url" : "https:\/\/etug.ca\/2016\/02\/09\/t-e-l-l-march-flip-it-good-flipping-the-lms-with-an-open-and-collaborative-platform\/",
      "display_url" : "etug.ca\/2016\/02\/09\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710255003563200512",
  "text" : "Six sleeps until my @etug flip your LMS session, which is really about choice + control for course participants. \uD83D\uDC4D  https:\/\/t.co\/Il9Bj4pqW0",
  "id" : 710255003563200512,
  "created_at" : "2016-03-17 00:02:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/710240424921735169\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/Qc5wDaIHsw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdtH5yRUEAEpDuh.jpg",
      "id_str" : "710240424313491457",
      "id" : 710240424313491457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdtH5yRUEAEpDuh.jpg",
      "sizes" : [ {
        "h" : 619,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 778
      } ],
      "display_url" : "pic.twitter.com\/Qc5wDaIHsw"
    } ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 58, 61 ]
    }, {
      "text" : "SFU",
      "indices" : [ 97, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710240424921735169",
  "text" : "Let's try that again with the right file... update of the #UX design process\/toolkit diagram for #SFU CMPT 363 . https:\/\/t.co\/Qc5wDaIHsw",
  "id" : 710240424921735169,
  "created_at" : "2016-03-16 23:04:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/710231267858513924\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/EQgxaAFD58",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cds_kxiUMAAAfjG.jpg",
      "id_str" : "710231267246092288",
      "id" : 710231267246092288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cds_kxiUMAAAfjG.jpg",
      "sizes" : [ {
        "h" : 619,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 778
      } ],
      "display_url" : "pic.twitter.com\/EQgxaAFD58"
    } ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 28, 31 ]
    }, {
      "text" : "SFU",
      "indices" : [ 70, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710231267858513924",
  "text" : "Working on an update of the #UX design process\/toolkit diagram for my #SFU CMPT 363 course, CC-licensed to boot. https:\/\/t.co\/EQgxaAFD58",
  "id" : 710231267858513924,
  "created_at" : "2016-03-16 22:28:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 3, 14 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 80, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/XMq11pXW8p",
      "expanded_url" : "http:\/\/www.sfu.ca\/tlc\/blog\/a-growing-number-of-inquiries-about-learning-technology.html",
      "display_url" : "sfu.ca\/tlc\/blog\/a-gro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709912952049041408",
  "text" : "RT @okalrelsrv: A growing number of inquiries about learning technology - TLC - #SFU https:\/\/t.co\/XMq11pXW8p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SFU",
        "indices" : [ 64, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/XMq11pXW8p",
        "expanded_url" : "http:\/\/www.sfu.ca\/tlc\/blog\/a-growing-number-of-inquiries-about-learning-technology.html",
        "display_url" : "sfu.ca\/tlc\/blog\/a-gro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "709908773922414592",
    "text" : "A growing number of inquiries about learning technology - TLC - #SFU https:\/\/t.co\/XMq11pXW8p",
    "id" : 709908773922414592,
    "created_at" : "2016-03-16 01:06:55 +0000",
    "user" : {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "protected" : false,
      "id_str" : "1983141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739951680591040512\/HosITGfQ_normal.jpg",
      "id" : 1983141,
      "verified" : false
    }
  },
  "id" : 709912952049041408,
  "created_at" : "2016-03-16 01:23:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/QV19NlL9T2",
      "expanded_url" : "https:\/\/hack.chat\/?flipped-lms-chat",
      "display_url" : "hack.chat\/?flipped-lms-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709847607271534592",
  "text" : "I'll be online at https:\/\/t.co\/QV19NlL9T2 for the next hour (3:00PM PDT) to chat about flipping your LMS with my Grav Course Hub",
  "id" : 709847607271534592,
  "created_at" : "2016-03-15 21:03:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 37, 45 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/709843646929969152\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/NN9Oe6EWRi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdnfCQ8UAAAs0Pj.jpg",
      "id_str" : "709843646288232448",
      "id" : 709843646288232448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdnfCQ8UAAAs0Pj.jpg",
      "sizes" : [ {
        "h" : 466,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 741
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 741
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NN9Oe6EWRi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709843646929969152",
  "text" : "Interested in flipping your LMS with @getgrav CMS?\nGrav Course Hub Getting Started Guide: https:\/\/t.co\/VgQsw7bHP4 https:\/\/t.co\/NN9Oe6EWRi",
  "id" : 709843646929969152,
  "created_at" : "2016-03-15 20:48:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709842889283481600",
  "text" : "Instructor choice and control when flipping the LMS can then result in ALL course participants having choice and control. \u2764 #GravEdu",
  "id" : 709842889283481600,
  "created_at" : "2016-03-15 20:45:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709842358230102017",
  "text" : "Two key aspects of flipping the LMS with an open platform are instructor control AND choice, with everything else being secondary. #GravEdu",
  "id" : 709842358230102017,
  "created_at" : "2016-03-15 20:43:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/709778702331043840\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/8hrCIbbQS9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cdmj9-cUYAEeE_x.jpg",
      "id_str" : "709778701416685569",
      "id" : 709778701416685569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cdmj9-cUYAEeE_x.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8hrCIbbQS9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/UDkA52gP6f",
      "expanded_url" : "https:\/\/getgrav.org\/downloads\/themes",
      "display_url" : "getgrav.org\/downloads\/them\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709778702331043840",
  "text" : "It's now a 1-dot-oh! My Foundation-based Course Hub theme for Grav CMS is available at https:\/\/t.co\/UDkA52gP6f https:\/\/t.co\/8hrCIbbQS9",
  "id" : 709778702331043840,
  "created_at" : "2016-03-15 16:30:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709529572140683264",
  "geo" : { },
  "id_str" : "709534451718488064",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro \uD83D\uDE09  Indeed, Learning Locker looks quite promising! Have you seen integrations with university Student Information Systems? ELMSLN?",
  "id" : 709534451718488064,
  "in_reply_to_status_id" : 709529572140683264,
  "created_at" : "2016-03-15 00:19:30 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709525104288337920",
  "text" : "In many ways, flipping an LMS changes it from a monolithic app (likely to fail as such) to more of a Learning Records System (LRS). #GravEdu",
  "id" : 709525104288337920,
  "created_at" : "2016-03-14 23:42:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 18, 26 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709507874104291331",
  "text" : "When creating the @getgrav CMS Course Hub, I viewed it as a 'process', and not a 'thing', that all participants would experience. #GravEdu",
  "id" : 709507874104291331,
  "created_at" : "2016-03-14 22:33:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709486203637092352",
  "text" : "(2\/2) In terms of unmet pedagogical goals, I also view increased access, sharing, and collaboration within that outcome.",
  "id" : 709486203637092352,
  "created_at" : "2016-03-14 21:07:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 10, 18 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709486157868826625",
  "text" : "(1\/2) The @getgrav Course Hub was created to achieve 2 key outcomes:\n\uD83C\uDFAFFacilitate unmet pedagogical goals\n\uD83C\uDFAFA better student + instructor UX",
  "id" : 709486157868826625,
  "created_at" : "2016-03-14 21:07:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Ev4VE4yP2F",
      "expanded_url" : "https:\/\/twitter.com\/etug\/status\/709464035490529280",
      "display_url" : "twitter.com\/etug\/status\/70\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709478595693903873",
  "text" : "This event will include an overview of my open source project to help others flip their LMS https:\/\/t.co\/VgQsw7bHP4 https:\/\/t.co\/Ev4VE4yP2F",
  "id" : 709478595693903873,
  "created_at" : "2016-03-14 20:37:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SmartGravity",
      "screen_name" : "smartgravity",
      "indices" : [ 28, 41 ],
      "id_str" : "46856872",
      "id" : 46856872
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 82, 90 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/qTgCdG6ZPM",
      "expanded_url" : "http:\/\/demo.hibbittsdesign.org\/grav-course-hub\/",
      "display_url" : "demo.hibbittsdesign.org\/grav-course-hu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709439265688522752",
  "text" : "Thanks to the great work by @smartgravity I'll soon be releasing an update for my @getgrav Course Hub default theme https:\/\/t.co\/qTgCdG6ZPM",
  "id" : 709439265688522752,
  "created_at" : "2016-03-14 18:01:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 80, 92 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/LYt2lgPhaP",
      "expanded_url" : "http:\/\/kck.st\/1U128pm",
      "display_url" : "kck.st\/1U128pm"
    } ]
  },
  "geo" : { },
  "id_str" : "709407915505889281",
  "text" : "I just backed Draft Evidence: Essays About Design &amp; Independent Business on @Kickstarter https:\/\/t.co\/LYt2lgPhaP",
  "id" : 709407915505889281,
  "created_at" : "2016-03-14 15:56:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher S. Rice",
      "screen_name" : "ricetopher",
      "indices" : [ 3, 14 ],
      "id_str" : "9686792",
      "id" : 9686792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/8Qcnr3ABKO",
      "expanded_url" : "https:\/\/twitter.com\/barster1\/status\/709122207192981504",
      "display_url" : "twitter.com\/barster1\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709168237053804544",
  "text" : "RT @ricetopher: Absolutely. Learning Experience Design a multidisciplinary, wholistic effort requiring systems-thinking leadership. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/8Qcnr3ABKO",
        "expanded_url" : "https:\/\/twitter.com\/barster1\/status\/709122207192981504",
        "display_url" : "twitter.com\/barster1\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "709165037785579520",
    "text" : "Absolutely. Learning Experience Design a multidisciplinary, wholistic effort requiring systems-thinking leadership. https:\/\/t.co\/8Qcnr3ABKO",
    "id" : 709165037785579520,
    "created_at" : "2016-03-13 23:51:35 +0000",
    "user" : {
      "name" : "Christopher S. Rice",
      "screen_name" : "ricetopher",
      "protected" : false,
      "id_str" : "9686792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713415153492959234\/Jj7Ur2mO_normal.jpg",
      "id" : 9686792,
      "verified" : false
    }
  },
  "id" : 709168237053804544,
  "created_at" : "2016-03-14 00:04:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 3, 15 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    }, {
      "name" : "Michael",
      "screen_name" : "michaeln3",
      "indices" : [ 123, 133 ],
      "id_str" : "688143",
      "id" : 688143
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SandstormIO\/status\/709158708924776448\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Nm03MM9nZb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CddwFosVIAAEzNc.jpg",
      "id_str" : "709158708459151360",
      "id" : 709158708459151360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CddwFosVIAAEzNc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Nm03MM9nZb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/Lcc53vyimI",
      "expanded_url" : "http:\/\/ow.ly\/ZpqVl",
      "display_url" : "ow.ly\/ZpqVl"
    } ]
  },
  "geo" : { },
  "id_str" : "709162345809838085",
  "text" : "RT @SandstormIO: See how visitors are interacting with your website in real time with Hummingbird: https:\/\/t.co\/Lcc53vyimI @michaeln3 https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael",
        "screen_name" : "michaeln3",
        "indices" : [ 106, 116 ],
        "id_str" : "688143",
        "id" : 688143
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SandstormIO\/status\/709158708924776448\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Nm03MM9nZb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CddwFosVIAAEzNc.jpg",
        "id_str" : "709158708459151360",
        "id" : 709158708459151360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CddwFosVIAAEzNc.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Nm03MM9nZb"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/Lcc53vyimI",
        "expanded_url" : "http:\/\/ow.ly\/ZpqVl",
        "display_url" : "ow.ly\/ZpqVl"
      } ]
    },
    "geo" : { },
    "id_str" : "709158708924776448",
    "text" : "See how visitors are interacting with your website in real time with Hummingbird: https:\/\/t.co\/Lcc53vyimI @michaeln3 https:\/\/t.co\/Nm03MM9nZb",
    "id" : 709158708924776448,
    "created_at" : "2016-03-13 23:26:26 +0000",
    "user" : {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "protected" : false,
      "id_str" : "2476570038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463413707150589952\/s17ccuOO_normal.png",
      "id" : 2476570038,
      "verified" : false
    }
  },
  "id" : 709162345809838085,
  "created_at" : "2016-03-13 23:40:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UX Links",
      "screen_name" : "uxlinks",
      "indices" : [ 3, 11 ],
      "id_str" : "21915540",
      "id" : 21915540
    }, {
      "name" : "UX Book Reviews",
      "screen_name" : "uxbookreviews",
      "indices" : [ 82, 96 ],
      "id_str" : "2984274233",
      "id" : 2984274233
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/uxlinks\/status\/709111845970427905\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/kiW9cxfN0D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CddFd2BXEAAwsI9.jpg",
      "id_str" : "709111845353885696",
      "id" : 709111845353885696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CddFd2BXEAAwsI9.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kiW9cxfN0D"
    } ],
    "hashtags" : [ {
      "text" : "ui",
      "indices" : [ 62, 65 ]
    }, {
      "text" : "ux",
      "indices" : [ 66, 69 ]
    }, {
      "text" : "bookreview",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/halhBoruFc",
      "expanded_url" : "http:\/\/ow.ly\/ZoWG2",
      "display_url" : "ow.ly\/ZoWG2"
    } ]
  },
  "geo" : { },
  "id_str" : "709144653568675840",
  "text" : "RT @uxlinks: UI IS COMMUNICATION &gt; https:\/\/t.co\/halhBoruFc #ui #ux #bookreview @uxbookreviews https:\/\/t.co\/kiW9cxfN0D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UX Book Reviews",
        "screen_name" : "uxbookreviews",
        "indices" : [ 69, 83 ],
        "id_str" : "2984274233",
        "id" : 2984274233
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/uxlinks\/status\/709111845970427905\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/kiW9cxfN0D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CddFd2BXEAAwsI9.jpg",
        "id_str" : "709111845353885696",
        "id" : 709111845353885696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CddFd2BXEAAwsI9.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1500,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kiW9cxfN0D"
      } ],
      "hashtags" : [ {
        "text" : "ui",
        "indices" : [ 49, 52 ]
      }, {
        "text" : "ux",
        "indices" : [ 53, 56 ]
      }, {
        "text" : "bookreview",
        "indices" : [ 57, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/halhBoruFc",
        "expanded_url" : "http:\/\/ow.ly\/ZoWG2",
        "display_url" : "ow.ly\/ZoWG2"
      } ]
    },
    "geo" : { },
    "id_str" : "709111845970427905",
    "text" : "UI IS COMMUNICATION &gt; https:\/\/t.co\/halhBoruFc #ui #ux #bookreview @uxbookreviews https:\/\/t.co\/kiW9cxfN0D",
    "id" : 709111845970427905,
    "created_at" : "2016-03-13 20:20:13 +0000",
    "user" : {
      "name" : "UX Links",
      "screen_name" : "uxlinks",
      "protected" : false,
      "id_str" : "21915540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575600342747848704\/5cUy9u_D_normal.png",
      "id" : 21915540,
      "verified" : false
    }
  },
  "id" : 709144653568675840,
  "created_at" : "2016-03-13 22:30:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 18, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jBKKf43xLc",
      "expanded_url" : "https:\/\/workflowy.com\/s\/2JGLyhUYyT",
      "display_url" : "workflowy.com\/s\/2JGLyhUYyT"
    } ]
  },
  "geo" : { },
  "id_str" : "708405522899206144",
  "text" : "If I was to teach #SFU CMPT 363 again, I would consider smaller topic chunks to better mix and match learning needs: https:\/\/t.co\/jBKKf43xLc",
  "id" : 708405522899206144,
  "created_at" : "2016-03-11 21:33:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette Priest",
      "screen_name" : "AnnettePriest",
      "indices" : [ 41, 55 ],
      "id_str" : "885321",
      "id" : 885321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/CGTskm1HvB",
      "expanded_url" : "https:\/\/twitter.com\/AnnettePriest\/status\/694647776617992192",
      "display_url" : "twitter.com\/AnnettePriest\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708040459226980352",
  "text" : "A slight riff on this excellent Tweet by @AnnettePriest\nPeople first. \nThen goals.\nThen tasks.\nAnd finally tech. https:\/\/t.co\/CGTskm1HvB",
  "id" : 708040459226980352,
  "created_at" : "2016-03-10 21:22:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenEducationWk",
      "indices" : [ 124, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "708037754026741760",
  "text" : "Is an LMS really \"open\" when course participants cannot actively contribute to it, both in terms of content + functionality?#OpenEducationWk",
  "id" : 708037754026741760,
  "created_at" : "2016-03-10 21:12:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNIE-RCI\u00C9",
      "screen_name" : "CNIE_RCIE",
      "indices" : [ 3, 13 ],
      "id_str" : "244782783",
      "id" : 244782783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/EADgGTEMu5",
      "expanded_url" : "http:\/\/fb.me\/70yAM0sAD",
      "display_url" : "fb.me\/70yAM0sAD"
    } ]
  },
  "geo" : { },
  "id_str" : "708016672888651776",
  "text" : "RT @CNIE_RCIE: Day 3 of Knocking Down the Walls is about to begin - hope to see you there! https:\/\/t.co\/EADgGTEMu5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/EADgGTEMu5",
        "expanded_url" : "http:\/\/fb.me\/70yAM0sAD",
        "display_url" : "fb.me\/70yAM0sAD"
      } ]
    },
    "geo" : { },
    "id_str" : "708016414980878336",
    "text" : "Day 3 of Knocking Down the Walls is about to begin - hope to see you there! https:\/\/t.co\/EADgGTEMu5",
    "id" : 708016414980878336,
    "created_at" : "2016-03-10 19:47:22 +0000",
    "user" : {
      "name" : "CNIE-RCI\u00C9",
      "screen_name" : "CNIE_RCIE",
      "protected" : false,
      "id_str" : "244782783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1232433922\/CNIE_RCIE_text_square_normal.jpg",
      "id" : 244782783,
      "verified" : false
    }
  },
  "id" : 708016672888651776,
  "created_at" : "2016-03-10 19:48:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/wuoitfhetB",
      "expanded_url" : "https:\/\/twitter.com\/btopro\/status\/649655781902680064",
      "display_url" : "twitter.com\/btopro\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708008708693831680",
  "text" : "Still the best tweet out there regarding what flipping your LMS really means... https:\/\/t.co\/wuoitfhetB",
  "id" : 708008708693831680,
  "created_at" : "2016-03-10 19:16:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "708003060002361344",
  "text" : "The moment you realize that Daylight Saving Time is starting this weekend. Yes, I just had that moment.",
  "id" : 708003060002361344,
  "created_at" : "2016-03-10 18:54:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 54, 59 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/708002625300467712\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/7CvX911d6D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdNUomYUMAA4m7M.jpg",
      "id_str" : "708002622901334016",
      "id" : 708002622901334016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdNUomYUMAA4m7M.jpg",
      "sizes" : [ {
        "h" : 180,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 657,
        "resize" : "fit",
        "w" : 1239
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7CvX911d6D"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Il9Bj4pqW0",
      "expanded_url" : "https:\/\/etug.ca\/2016\/02\/09\/t-e-l-l-march-flip-it-good-flipping-the-lms-with-an-open-and-collaborative-platform\/",
      "display_url" : "etug.ca\/2016\/02\/09\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708002625300467712",
  "text" : "The slides are starting to gel for my \"Flip It Good!\" @etug TELL session Mar 22 at 11am PDT https:\/\/t.co\/Il9Bj4pqW0 https:\/\/t.co\/7CvX911d6D",
  "id" : 708002625300467712,
  "created_at" : "2016-03-10 18:52:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "indices" : [ 3, 17 ],
      "id_str" : "1236101",
      "id" : 1236101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707998149067939840",
  "text" : "RT @BenedictEvans: It is as wrong to think of 'mobile' as meaning 'a device in your pocket' as it is to think of a 'PC' as a 'personal comp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "707990800823508992",
    "text" : "It is as wrong to think of 'mobile' as meaning 'a device in your pocket' as it is to think of a 'PC' as a 'personal computer'.",
    "id" : 707990800823508992,
    "created_at" : "2016-03-10 18:05:35 +0000",
    "user" : {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "protected" : false,
      "id_str" : "1236101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544407411193163776\/vGSguvLd_normal.jpeg",
      "id" : 1236101,
      "verified" : false
    }
  },
  "id" : 707998149067939840,
  "created_at" : "2016-03-10 18:34:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Mosher",
      "screen_name" : "bmosh",
      "indices" : [ 3, 9 ],
      "id_str" : "21192677",
      "id" : 21192677
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "5mon",
      "indices" : [ 104, 109 ]
    }, {
      "text" : "epss",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "performanesupport",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707991583732269056",
  "text" : "RT @bmosh: Does your training group have a design for \"performance\" first or \"training\" first mindset?  #5mon #epss #performanesupport",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "5mon",
        "indices" : [ 93, 98 ]
      }, {
        "text" : "epss",
        "indices" : [ 99, 104 ]
      }, {
        "text" : "performanesupport",
        "indices" : [ 105, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "707990264669999104",
    "text" : "Does your training group have a design for \"performance\" first or \"training\" first mindset?  #5mon #epss #performanesupport",
    "id" : 707990264669999104,
    "created_at" : "2016-03-10 18:03:27 +0000",
    "user" : {
      "name" : "Bob Mosher",
      "screen_name" : "bmosh",
      "protected" : false,
      "id_str" : "21192677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1411067474\/Bob_Mosher_photo_-_Web_normal.jpg",
      "id" : 21192677,
      "verified" : false
    }
  },
  "id" : 707991583732269056,
  "created_at" : "2016-03-10 18:08:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 10, 18 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/753qpCWnKz",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators#\/",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707978131781476352",
  "text" : "My 3-hour @getgrav for Educators Workshop is now split into two 2-hour sessions\n\u2713Hello Grav\n\u2713Flip your LMS with Grav\nhttps:\/\/t.co\/753qpCWnKz",
  "id" : 707978131781476352,
  "created_at" : "2016-03-10 17:15:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Brown \u26A1\uFE0F",
      "screen_name" : "timbdesignmpls",
      "indices" : [ 3, 18 ],
      "id_str" : "878172186",
      "id" : 878172186
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/timbdesignmpls\/status\/707390685910069248\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/dAY97L9az9",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CdEoBOoUYAA8rO4.jpg",
      "id_str" : "707390618046062592",
      "id" : 707390618046062592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CdEoBOoUYAA8rO4.jpg",
      "sizes" : [ {
        "h" : 224,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/dAY97L9az9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/DAlc5BFr7x",
      "expanded_url" : "https:\/\/timbdesign.com\/15-user-experience-reaction-gifs-and-memes\/",
      "display_url" : "timbdesign.com\/15-user-experi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707941101190000640",
  "text" : "RT @timbdesignmpls: When your boss and the client are setting unrealistic goals &amp; youre responsible for the work https:\/\/t.co\/DAlc5BFr7x ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/timbdesignmpls\/status\/707390685910069248\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/dAY97L9az9",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CdEoBOoUYAA8rO4.jpg",
        "id_str" : "707390618046062592",
        "id" : 707390618046062592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CdEoBOoUYAA8rO4.jpg",
        "sizes" : [ {
          "h" : 224,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/dAY97L9az9"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/DAlc5BFr7x",
        "expanded_url" : "https:\/\/timbdesign.com\/15-user-experience-reaction-gifs-and-memes\/",
        "display_url" : "timbdesign.com\/15-user-experi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "707390685910069248",
    "text" : "When your boss and the client are setting unrealistic goals &amp; youre responsible for the work https:\/\/t.co\/DAlc5BFr7x https:\/\/t.co\/dAY97L9az9",
    "id" : 707390685910069248,
    "created_at" : "2016-03-09 02:20:56 +0000",
    "user" : {
      "name" : "Tim Brown \u26A1\uFE0F",
      "screen_name" : "timbdesignmpls",
      "protected" : false,
      "id_str" : "878172186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720732488675520512\/ApwwU3mZ_normal.jpg",
      "id" : 878172186,
      "verified" : false
    }
  },
  "id" : 707941101190000640,
  "created_at" : "2016-03-10 14:48:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Lyons",
      "screen_name" : "bestpoutine",
      "indices" : [ 73, 85 ],
      "id_str" : "65663104",
      "id" : 65663104
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActiveLearningClassroom",
      "indices" : [ 48, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/eo5JRaJhAq",
      "expanded_url" : "https:\/\/storify.com\/paulhibbitts\/activelearningclassroom-carletonu",
      "display_url" : "storify.com\/paulhibbitts\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707710553829998592",
  "text" : "Thanks for sharing those fantastic Tweets about #ActiveLearningClassroom @bestpoutine, here is a Storify of them: https:\/\/t.co\/eo5JRaJhAq",
  "id" : 707710553829998592,
  "created_at" : "2016-03-09 23:31:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BCcampus\/status\/707677072756498433\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/RIB7NEO5P8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdIsjEiW0AAIFW1.jpg",
      "id_str" : "707677072475475968",
      "id" : 707677072475475968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdIsjEiW0AAIFW1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 913
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 913
      }, {
        "h" : 169,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 96,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RIB7NEO5P8"
    } ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/nCzImJdfc5",
      "expanded_url" : "http:\/\/ow.ly\/ZgUYD",
      "display_url" : "ow.ly\/ZgUYD"
    } ]
  },
  "geo" : { },
  "id_str" : "707692953871908864",
  "text" : "RT @BCcampus: This just in! Registration for the Festival of Learning is now open!! https:\/\/t.co\/nCzImJdfc5 #FoL16 https:\/\/t.co\/RIB7NEO5P8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BCcampus\/status\/707677072756498433\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/RIB7NEO5P8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdIsjEiW0AAIFW1.jpg",
        "id_str" : "707677072475475968",
        "id" : 707677072475475968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdIsjEiW0AAIFW1.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 913
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 913
        }, {
          "h" : 169,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 96,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RIB7NEO5P8"
      } ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 94, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/nCzImJdfc5",
        "expanded_url" : "http:\/\/ow.ly\/ZgUYD",
        "display_url" : "ow.ly\/ZgUYD"
      } ]
    },
    "geo" : { },
    "id_str" : "707677072756498433",
    "text" : "This just in! Registration for the Festival of Learning is now open!! https:\/\/t.co\/nCzImJdfc5 #FoL16 https:\/\/t.co\/RIB7NEO5P8",
    "id" : 707677072756498433,
    "created_at" : "2016-03-09 21:18:56 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 707692953871908864,
  "created_at" : "2016-03-09 22:22:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 84, 92 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/707685467941023744\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/H4rHAVSy7N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdI0LsDUEAADRBe.jpg",
      "id_str" : "707685466858852352",
      "id" : 707685466858852352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdI0LsDUEAADRBe.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/H4rHAVSy7N"
    } ],
    "hashtags" : [ {
      "text" : "OpenEducationWk",
      "indices" : [ 5, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707685467941023744",
  "text" : "Mark #OpenEducationWk by flipping your LMS with the open and collaborative platform @getgrav https:\/\/t.co\/VgQsw7bHP4 https:\/\/t.co\/H4rHAVSy7N",
  "id" : 707685467941023744,
  "created_at" : "2016-03-09 21:52:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/N7e2KDq8d3",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-03-09-a-few-more-thoughts-about-sustainable-open-design-practice",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707649717275000836",
  "text" : "New post: A Few More Thoughts About... Sustainable Open Design Practice https:\/\/t.co\/N7e2KDq8d3",
  "id" : 707649717275000836,
  "created_at" : "2016-03-09 19:30:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tim malbon",
      "screen_name" : "malbonster",
      "indices" : [ 3, 14 ],
      "id_str" : "10040",
      "id" : 10040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/voeILY7GEo",
      "expanded_url" : "https:\/\/medium.com\/the-many\/the-solution-to-design-thinking-42e8f1b59022#.x8nnfuetg",
      "display_url" : "medium.com\/the-many\/the-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707635040809648128",
  "text" : "RT @malbonster: I just published a follow-up to 'The Problem with Design Thinking' called 'The Solution To Design Thinking' https:\/\/t.co\/vo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/voeILY7GEo",
        "expanded_url" : "https:\/\/medium.com\/the-many\/the-solution-to-design-thinking-42e8f1b59022#.x8nnfuetg",
        "display_url" : "medium.com\/the-many\/the-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "707628598635663360",
    "text" : "I just published a follow-up to 'The Problem with Design Thinking' called 'The Solution To Design Thinking' https:\/\/t.co\/voeILY7GEo",
    "id" : 707628598635663360,
    "created_at" : "2016-03-09 18:06:19 +0000",
    "user" : {
      "name" : "tim malbon",
      "screen_name" : "malbonster",
      "protected" : false,
      "id_str" : "10040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/483758625169887233\/vwuIdKEY_normal.jpeg",
      "id" : 10040,
      "verified" : false
    }
  },
  "id" : 707635040809648128,
  "created_at" : "2016-03-09 18:31:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/jqQHqddup9",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-18-flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/7ksRxpu0A0",
      "expanded_url" : "https:\/\/twitter.com\/kiwafruit\/status\/707358115247759360",
      "display_url" : "twitter.com\/kiwafruit\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707380959625109504",
  "text" : "Flipping the LMS with an open + collaborative platform moves control to course participants. https:\/\/t.co\/jqQHqddup9 https:\/\/t.co\/7ksRxpu0A0",
  "id" : 707380959625109504,
  "created_at" : "2016-03-09 01:42:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707348672661458945",
  "text" : "(3\/3) potential value propositions for one or more specific groups of the audience for that product\". Thoughts and comments Twitterverse?",
  "id" : 707348672661458945,
  "created_at" : "2016-03-08 23:34:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707348641988476928",
  "text" : "(2\/3) underlying design process is available for all to use and contribute to, and because of the existence of that open product there are",
  "id" : 707348641988476928,
  "created_at" : "2016-03-08 23:33:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707348606584401920",
  "text" : "(1\/3) What is a\"sustainable open design practice\"? My first attempt of a definition is \"where the creation of an open product and it's",
  "id" : 707348606584401920,
  "created_at" : "2016-03-08 23:33:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 103, 112 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/P9w2iHFYWl",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B01CBYFU3O",
      "display_url" : "amazon.com\/dp\/B01CBYFU3O"
    } ]
  },
  "geo" : { },
  "id_str" : "707340694243774464",
  "text" : "Every educator should deeply consider the Bill of Rights for Learners in the new book School of You by @m_travin https:\/\/t.co\/P9w2iHFYWl",
  "id" : 707340694243774464,
  "created_at" : "2016-03-08 23:02:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707337992835170304",
  "text" : "As I refine my sustainable open design practice, workshops + on-going priority support look promising as edu institution value propositions.",
  "id" : 707337992835170304,
  "created_at" : "2016-03-08 22:51:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 3, 10 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "highered",
      "indices" : [ 28, 37 ]
    }, {
      "text" : "edtech",
      "indices" : [ 125, 132 ]
    }, {
      "text" : "bcpse",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707297290109603840",
  "text" : "RT @tanbob: I'm looking for #highered project plans\/biz cases for Kaltura that I could read. Does anybody have one to share? #edtech #bcpse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "highered",
        "indices" : [ 16, 25 ]
      }, {
        "text" : "edtech",
        "indices" : [ 113, 120 ]
      }, {
        "text" : "bcpse",
        "indices" : [ 121, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "707291808087146497",
    "text" : "I'm looking for #highered project plans\/biz cases for Kaltura that I could read. Does anybody have one to share? #edtech #bcpse",
    "id" : 707291808087146497,
    "created_at" : "2016-03-08 19:48:02 +0000",
    "user" : {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "protected" : false,
      "id_str" : "10817782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530559772\/twitterProfilePhoto_normal.jpg",
      "id" : 10817782,
      "verified" : false
    }
  },
  "id" : 707297290109603840,
  "created_at" : "2016-03-08 20:09:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 14, 19 ]
    }, {
      "text" : "FoL16",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/FAOgaO5Mzs",
      "expanded_url" : "http:\/\/ow.ly\/YrUk0",
      "display_url" : "ow.ly\/YrUk0"
    } ]
  },
  "geo" : { },
  "id_str" : "707289053373181953",
  "text" : "RT @BCcampus: #ETUG Spring 2016 Call for Proposals: Education &amp; Technology Studio https:\/\/t.co\/FAOgaO5Mzs #FoL16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ETUG",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "FoL16",
        "indices" : [ 96, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/FAOgaO5Mzs",
        "expanded_url" : "http:\/\/ow.ly\/YrUk0",
        "display_url" : "ow.ly\/YrUk0"
      } ]
    },
    "geo" : { },
    "id_str" : "707287816330461184",
    "text" : "#ETUG Spring 2016 Call for Proposals: Education &amp; Technology Studio https:\/\/t.co\/FAOgaO5Mzs #FoL16",
    "id" : 707287816330461184,
    "created_at" : "2016-03-08 19:32:10 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 707289053373181953,
  "created_at" : "2016-03-08 19:37:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 3, 15 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    }, {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 79, 91 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SandstormIO\/status\/707273582641070080\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/hy1YmF4zpf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdC9k2VUEAAjvER.jpg",
      "id_str" : "707273582255017984",
      "id" : 707273582255017984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdC9k2VUEAAjvER.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hy1YmF4zpf"
    } ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 92, 99 ]
    }, {
      "text" : "highered",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/t0gmNlOO7z",
      "expanded_url" : "http:\/\/ow.ly\/Z5XiL",
      "display_url" : "ow.ly\/Z5XiL"
    } ]
  },
  "geo" : { },
  "id_str" : "707284715602976769",
  "text" : "RT @SandstormIO: Stay anonymous (or not). Use Sandstorm apps w\/o logging in by @grantpotter #edtech #highered https:\/\/t.co\/t0gmNlOO7z https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grant Potter",
        "screen_name" : "grantpotter",
        "indices" : [ 62, 74 ],
        "id_str" : "6271482",
        "id" : 6271482
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SandstormIO\/status\/707273582641070080\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/hy1YmF4zpf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdC9k2VUEAAjvER.jpg",
        "id_str" : "707273582255017984",
        "id" : 707273582255017984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdC9k2VUEAAjvER.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hy1YmF4zpf"
      } ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 75, 82 ]
      }, {
        "text" : "highered",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/t0gmNlOO7z",
        "expanded_url" : "http:\/\/ow.ly\/Z5XiL",
        "display_url" : "ow.ly\/Z5XiL"
      } ]
    },
    "geo" : { },
    "id_str" : "707273582641070080",
    "text" : "Stay anonymous (or not). Use Sandstorm apps w\/o logging in by @grantpotter #edtech #highered https:\/\/t.co\/t0gmNlOO7z https:\/\/t.co\/hy1YmF4zpf",
    "id" : 707273582641070080,
    "created_at" : "2016-03-08 18:35:37 +0000",
    "user" : {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "protected" : false,
      "id_str" : "2476570038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463413707150589952\/s17ccuOO_normal.png",
      "id" : 2476570038,
      "verified" : false
    }
  },
  "id" : 707284715602976769,
  "created_at" : "2016-03-08 19:19:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CanadianPM",
      "screen_name" : "CanadianPM",
      "indices" : [ 3, 14 ],
      "id_str" : "14713787",
      "id" : 14713787
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CanadianPM\/status\/707202920417251328\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/R4xdqVXyMc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdB9TwXUIAAejDJ.jpg",
      "id_str" : "707202919850844160",
      "id" : 707202919850844160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdB9TwXUIAAejDJ.jpg",
      "sizes" : [ {
        "h" : 378,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 566
      } ],
      "display_url" : "pic.twitter.com\/R4xdqVXyMc"
    } ],
    "hashtags" : [ {
      "text" : "InternationalWomensDay",
      "indices" : [ 75, 98 ]
    }, {
      "text" : "YouAreEmpowerment",
      "indices" : [ 100, 118 ]
    }, {
      "text" : "IWD2016",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707272842396639232",
  "text" : "RT @CanadianPM: Let\u2019s work together for a Canada where equality is a norm. #InternationalWomensDay. #YouAreEmpowerment #IWD2016 https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CanadianPM\/status\/707202920417251328\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/R4xdqVXyMc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdB9TwXUIAAejDJ.jpg",
        "id_str" : "707202919850844160",
        "id" : 707202919850844160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdB9TwXUIAAejDJ.jpg",
        "sizes" : [ {
          "h" : 378,
          "resize" : "fit",
          "w" : 566
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 566
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 566
        } ],
        "display_url" : "pic.twitter.com\/R4xdqVXyMc"
      } ],
      "hashtags" : [ {
        "text" : "InternationalWomensDay",
        "indices" : [ 59, 82 ]
      }, {
        "text" : "YouAreEmpowerment",
        "indices" : [ 84, 102 ]
      }, {
        "text" : "IWD2016",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "707202920417251328",
    "text" : "Let\u2019s work together for a Canada where equality is a norm. #InternationalWomensDay. #YouAreEmpowerment #IWD2016 https:\/\/t.co\/R4xdqVXyMc",
    "id" : 707202920417251328,
    "created_at" : "2016-03-08 13:54:50 +0000",
    "user" : {
      "name" : "CanadianPM",
      "screen_name" : "CanadianPM",
      "protected" : false,
      "id_str" : "14713787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661752246095474688\/GUa8Oxuy_normal.jpg",
      "id" : 14713787,
      "verified" : true
    }
  },
  "id" : 707272842396639232,
  "created_at" : "2016-03-08 18:32:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNIE-RCI\u00C9",
      "screen_name" : "CNIE_RCIE",
      "indices" : [ 3, 13 ],
      "id_str" : "244782783",
      "id" : 244782783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/TBxc4V6BYk",
      "expanded_url" : "http:\/\/fb.me\/PWAvLw9s",
      "display_url" : "fb.me\/PWAvLw9s"
    } ]
  },
  "geo" : { },
  "id_str" : "707264337639907328",
  "text" : "RT @CNIE_RCIE: Don't miss Day 2 of Knocking Down the Walls! You can still register for today's and Thursday's sessions. https:\/\/t.co\/TBxc4V\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/TBxc4V6BYk",
        "expanded_url" : "http:\/\/fb.me\/PWAvLw9s",
        "display_url" : "fb.me\/PWAvLw9s"
      } ]
    },
    "geo" : { },
    "id_str" : "707243871558701056",
    "text" : "Don't miss Day 2 of Knocking Down the Walls! You can still register for today's and Thursday's sessions. https:\/\/t.co\/TBxc4V6BYk",
    "id" : 707243871558701056,
    "created_at" : "2016-03-08 16:37:33 +0000",
    "user" : {
      "name" : "CNIE-RCI\u00C9",
      "screen_name" : "CNIE_RCIE",
      "protected" : false,
      "id_str" : "244782783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1232433922\/CNIE_RCIE_text_square_normal.jpg",
      "id" : 244782783,
      "verified" : false
    }
  },
  "id" : 707264337639907328,
  "created_at" : "2016-03-08 17:58:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Katrina Wehr",
      "screen_name" : "katrinamwehr",
      "indices" : [ 8, 21 ],
      "id_str" : "1380932875",
      "id" : 1380932875
    }, {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 22, 29 ],
      "id_str" : "236846178",
      "id" : 236846178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707262040084185088",
  "geo" : { },
  "id_str" : "707262721507471360",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @katrinamwehr @elmsln Awesome to connect!",
  "id" : 707262721507471360,
  "in_reply_to_status_id" : 707262040084185088,
  "created_at" : "2016-03-08 17:52:27 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/jqQHqddup9",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-18-flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    }, {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/wmuypCpvIP",
      "expanded_url" : "https:\/\/twitter.com\/katrinamwehr\/status\/707252696630169600",
      "display_url" : "twitter.com\/katrinamwehr\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707261615419236352",
  "text" : "Flip your LMS to use only what you want while improving the student &amp; instructor experience. https:\/\/t.co\/jqQHqddup9 https:\/\/t.co\/wmuypCpvIP",
  "id" : 707261615419236352,
  "created_at" : "2016-03-08 17:48:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 0, 9 ],
      "id_str" : "837060721",
      "id" : 837060721
    }, {
      "name" : "Statesman Ed Board",
      "screen_name" : "aasviewpoints",
      "indices" : [ 10, 24 ],
      "id_str" : "40351413",
      "id" : 40351413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707191036875943936",
  "geo" : { },
  "id_str" : "707256299101102080",
  "in_reply_to_user_id" : 837060721,
  "text" : "@m_travin @aasviewpoints Great article Myra, best of luck with your session today!",
  "id" : 707256299101102080,
  "in_reply_to_status_id" : 707191036875943936,
  "created_at" : "2016-03-08 17:26:56 +0000",
  "in_reply_to_screen_name" : "m_travin",
  "in_reply_to_user_id_str" : "837060721",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Statesman Ed Board",
      "screen_name" : "aasviewpoints",
      "indices" : [ 3, 17 ],
      "id_str" : "40351413",
      "id" : 40351413
    }, {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 51, 60 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSXedu2016",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/qYLf6WIuM8",
      "expanded_url" : "http:\/\/atxne.ws\/1QIxR8B",
      "display_url" : "atxne.ws\/1QIxR8B"
    } ]
  },
  "geo" : { },
  "id_str" : "707256098219122688",
  "text" : "RT @aasviewpoints: Special contributor Myra Travin @m_travin: Saying goodbye to the future https:\/\/t.co\/qYLf6WIuM8 #SXSXedu2016",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Myra T Travin",
        "screen_name" : "m_travin",
        "indices" : [ 32, 41 ],
        "id_str" : "837060721",
        "id" : 837060721
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SXSXedu2016",
        "indices" : [ 96, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/qYLf6WIuM8",
        "expanded_url" : "http:\/\/atxne.ws\/1QIxR8B",
        "display_url" : "atxne.ws\/1QIxR8B"
      } ]
    },
    "geo" : { },
    "id_str" : "707190473476218880",
    "text" : "Special contributor Myra Travin @m_travin: Saying goodbye to the future https:\/\/t.co\/qYLf6WIuM8 #SXSXedu2016",
    "id" : 707190473476218880,
    "created_at" : "2016-03-08 13:05:22 +0000",
    "user" : {
      "name" : "Statesman Ed Board",
      "screen_name" : "aasviewpoints",
      "protected" : false,
      "id_str" : "40351413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433631758467076098\/iAKuqgIc_normal.jpeg",
      "id" : 40351413,
      "verified" : false
    }
  },
  "id" : 707256098219122688,
  "created_at" : "2016-03-08 17:26:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 22, 29 ],
      "id_str" : "236846178",
      "id" : 236846178
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "git",
      "indices" : [ 33, 37 ]
    }, {
      "text" : "edtech",
      "indices" : [ 83, 90 ]
    }, {
      "text" : "redecentralize",
      "indices" : [ 91, 106 ]
    }, {
      "text" : "drupal",
      "indices" : [ 107, 114 ]
    }, {
      "text" : "Github",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/ZkQmU5K8TI",
      "expanded_url" : "https:\/\/drupal.psu.edu\/blog\/post\/elmsln-git-fun-git-book",
      "display_url" : "drupal.psu.edu\/blog\/post\/elms\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706965434013081600",
  "text" : "RT @btopro: New Post: @ELMSLN is #git'in fun with Git Book https:\/\/t.co\/ZkQmU5K8TI #edtech #redecentralize #drupal #Github",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ELMS:LN",
        "screen_name" : "elmsln",
        "indices" : [ 10, 17 ],
        "id_str" : "236846178",
        "id" : 236846178
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "git",
        "indices" : [ 21, 25 ]
      }, {
        "text" : "edtech",
        "indices" : [ 71, 78 ]
      }, {
        "text" : "redecentralize",
        "indices" : [ 79, 94 ]
      }, {
        "text" : "drupal",
        "indices" : [ 95, 102 ]
      }, {
        "text" : "Github",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/ZkQmU5K8TI",
        "expanded_url" : "https:\/\/drupal.psu.edu\/blog\/post\/elmsln-git-fun-git-book",
        "display_url" : "drupal.psu.edu\/blog\/post\/elms\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "706954019164577792",
    "text" : "New Post: @ELMSLN is #git'in fun with Git Book https:\/\/t.co\/ZkQmU5K8TI #edtech #redecentralize #drupal #Github",
    "id" : 706954019164577792,
    "created_at" : "2016-03-07 21:25:47 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 706965434013081600,
  "created_at" : "2016-03-07 22:11:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNIE-RCI\u00C9",
      "screen_name" : "CNIE_RCIE",
      "indices" : [ 0, 10 ],
      "id_str" : "244782783",
      "id" : 244782783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706952889743372288",
  "geo" : { },
  "id_str" : "706953248058380288",
  "in_reply_to_user_id" : 244782783,
  "text" : "@CNIE_RCIE It was my pleasure, thanks very much!",
  "id" : 706953248058380288,
  "in_reply_to_status_id" : 706952889743372288,
  "created_at" : "2016-03-07 21:22:43 +0000",
  "in_reply_to_screen_name" : "CNIE_RCIE",
  "in_reply_to_user_id_str" : "244782783",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNIE-RCI\u00C9",
      "screen_name" : "CNIE_RCIE",
      "indices" : [ 58, 68 ],
      "id_str" : "244782783",
      "id" : 244782783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/6vpLTHBD4A",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/cnie-2016-flipping-the-lms-with-an-open-and-collaborative-platform",
      "display_url" : "slides.com\/paulhibbitts\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706952730674204672",
  "text" : "Thanks to everyone who participated in my 'Flip it Good!' @CNIE_RCIE session today! Slides are now available at https:\/\/t.co\/6vpLTHBD4A",
  "id" : 706952730674204672,
  "created_at" : "2016-03-07 21:20:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup Nexus",
      "screen_name" : "startupnexus",
      "indices" : [ 3, 16 ],
      "id_str" : "196793532",
      "id" : 196793532
    }, {
      "name" : "UXPin",
      "screen_name" : "uxpin",
      "indices" : [ 43, 49 ],
      "id_str" : "211100214",
      "id" : 211100214
    }, {
      "name" : "UX Speakeasy",
      "screen_name" : "UXSpeakeasy",
      "indices" : [ 50, 62 ],
      "id_str" : "352761306",
      "id" : 352761306
    }, {
      "name" : "UX Mastery",
      "screen_name" : "uxmastery",
      "indices" : [ 63, 73 ],
      "id_str" : "631741925",
      "id" : 631741925
    }, {
      "name" : "HFI",
      "screen_name" : "humanfactors",
      "indices" : [ 74, 87 ],
      "id_str" : "16874616",
      "id" : 16874616
    }, {
      "name" : "Material Design Blog",
      "screen_name" : "materialdesignB",
      "indices" : [ 88, 104 ],
      "id_str" : "2988420298",
      "id" : 2988420298
    }, {
      "name" : "Co.Design",
      "screen_name" : "FastCoDesign",
      "indices" : [ 105, 118 ],
      "id_str" : "158865339",
      "id" : 158865339
    }, {
      "name" : "Work Design Magazine",
      "screen_name" : "workdesignmag",
      "indices" : [ 119, 133 ],
      "id_str" : "187604037",
      "id" : 187604037
    }, {
      "name" : "UX Magazine",
      "screen_name" : "uxmag",
      "indices" : [ 134, 140 ],
      "id_str" : "15056788",
      "id" : 15056788
    }, {
      "name" : "MaterialUp",
      "screen_name" : "MaterialUp",
      "indices" : [ 139, 140 ],
      "id_str" : "2884717841",
      "id" : 2884717841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706918233304006657",
  "text" : "RT @startupnexus: UXer approved resources:\n@uxpin\n@UXSpeakeasy\n@uxmastery\n@humanfactors\n@materialdesignB\n@FastCoDesign\n@workdesignmag\n@uxma\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UXPin",
        "screen_name" : "uxpin",
        "indices" : [ 25, 31 ],
        "id_str" : "211100214",
        "id" : 211100214
      }, {
        "name" : "UX Speakeasy",
        "screen_name" : "UXSpeakeasy",
        "indices" : [ 32, 44 ],
        "id_str" : "352761306",
        "id" : 352761306
      }, {
        "name" : "UX Mastery",
        "screen_name" : "uxmastery",
        "indices" : [ 45, 55 ],
        "id_str" : "631741925",
        "id" : 631741925
      }, {
        "name" : "HFI",
        "screen_name" : "humanfactors",
        "indices" : [ 56, 69 ],
        "id_str" : "16874616",
        "id" : 16874616
      }, {
        "name" : "Material Design Blog",
        "screen_name" : "materialdesignB",
        "indices" : [ 70, 86 ],
        "id_str" : "2988420298",
        "id" : 2988420298
      }, {
        "name" : "Co.Design",
        "screen_name" : "FastCoDesign",
        "indices" : [ 87, 100 ],
        "id_str" : "158865339",
        "id" : 158865339
      }, {
        "name" : "Work Design Magazine",
        "screen_name" : "workdesignmag",
        "indices" : [ 101, 115 ],
        "id_str" : "187604037",
        "id" : 187604037
      }, {
        "name" : "UX Magazine",
        "screen_name" : "uxmag",
        "indices" : [ 116, 122 ],
        "id_str" : "15056788",
        "id" : 15056788
      }, {
        "name" : "MaterialUp",
        "screen_name" : "MaterialUp",
        "indices" : [ 124, 135 ],
        "id_str" : "2884717841",
        "id" : 2884717841
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "706235542829191168",
    "text" : "UXer approved resources:\n@uxpin\n@UXSpeakeasy\n@uxmastery\n@humanfactors\n@materialdesignB\n@FastCoDesign\n@workdesignmag\n@uxmag \n@MaterialUp \n#UX",
    "id" : 706235542829191168,
    "created_at" : "2016-03-05 21:50:49 +0000",
    "user" : {
      "name" : "Startup Nexus",
      "screen_name" : "startupnexus",
      "protected" : false,
      "id_str" : "196793532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690954489617059840\/JXt__azq_normal.png",
      "id" : 196793532,
      "verified" : false
    }
  },
  "id" : 706918233304006657,
  "created_at" : "2016-03-07 19:03:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNIE-RCI\u00C9",
      "screen_name" : "CNIE_RCIE",
      "indices" : [ 36, 46 ],
      "id_str" : "244782783",
      "id" : 244782783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706893841962434560",
  "text" : "Looking forward to the start of the @CNIE_RCIE virtual conference today! I will be presenting my flipped-LMS approach at ~12:55PM PST. \u23F0",
  "id" : 706893841962434560,
  "created_at" : "2016-03-07 17:26:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 3, 14 ],
      "id_str" : "91634720",
      "id" : 91634720
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kenjeffery\/status\/706883199675326464\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/VczyRG47qK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cc9ahlNWEAAjBbh.jpg",
      "id_str" : "706883199490723840",
      "id" : 706883199490723840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cc9ahlNWEAAjBbh.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/VczyRG47qK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/3A2yzfA4t2",
      "expanded_url" : "http:\/\/bit.ly\/1QErXoQ",
      "display_url" : "bit.ly\/1QErXoQ"
    } ]
  },
  "geo" : { },
  "id_str" : "706886582981124096",
  "text" : "RT @kenjeffery: Open Education Week is here! What are you doing to promote open access to education? https:\/\/t.co\/3A2yzfA4t2 https:\/\/t.co\/V\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kenjeffery\/status\/706883199675326464\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/VczyRG47qK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cc9ahlNWEAAjBbh.jpg",
        "id_str" : "706883199490723840",
        "id" : 706883199490723840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cc9ahlNWEAAjBbh.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/VczyRG47qK"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/3A2yzfA4t2",
        "expanded_url" : "http:\/\/bit.ly\/1QErXoQ",
        "display_url" : "bit.ly\/1QErXoQ"
      } ]
    },
    "geo" : { },
    "id_str" : "706883199675326464",
    "text" : "Open Education Week is here! What are you doing to promote open access to education? https:\/\/t.co\/3A2yzfA4t2 https:\/\/t.co\/VczyRG47qK",
    "id" : 706883199675326464,
    "created_at" : "2016-03-07 16:44:22 +0000",
    "user" : {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "protected" : false,
      "id_str" : "91634720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444954820244275200\/ojUn8z4n_normal.jpeg",
      "id" : 91634720,
      "verified" : false
    }
  },
  "id" : 706886582981124096,
  "created_at" : "2016-03-07 16:57:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 0, 14 ],
      "id_str" : "41268670",
      "id" : 41268670
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 15, 22 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706660786148487168",
  "geo" : { },
  "id_str" : "706661056442081281",
  "in_reply_to_user_id" : 41268670,
  "text" : "@_mike_collins @btopro Thanks for sharing your thoughts!",
  "id" : 706661056442081281,
  "in_reply_to_status_id" : 706660786148487168,
  "created_at" : "2016-03-07 02:01:39 +0000",
  "in_reply_to_screen_name" : "_mike_collins",
  "in_reply_to_user_id_str" : "41268670",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 0, 14 ],
      "id_str" : "41268670",
      "id" : 41268670
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 15, 22 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706658013256355840",
  "geo" : { },
  "id_str" : "706658319742537728",
  "in_reply_to_user_id" : 41268670,
  "text" : "@_mike_collins @btopro Do you think it is a reasonable interface for students to edit content?",
  "id" : 706658319742537728,
  "in_reply_to_status_id" : 706658013256355840,
  "created_at" : "2016-03-07 01:50:47 +0000",
  "in_reply_to_screen_name" : "_mike_collins",
  "in_reply_to_user_id_str" : "41268670",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 8, 22 ],
      "id_str" : "41268670",
      "id" : 41268670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/15M3eMm1qi",
      "expanded_url" : "http:\/\/prose.io\/",
      "display_url" : "prose.io"
    } ]
  },
  "in_reply_to_status_id_str" : "706653276729643008",
  "geo" : { },
  "id_str" : "706654336739184640",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @_mike_collins Nice find! Have you also run across https:\/\/t.co\/15M3eMm1qi?",
  "id" : 706654336739184640,
  "in_reply_to_status_id" : 706653276729643008,
  "created_at" : "2016-03-07 01:34:57 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCIT",
      "screen_name" : "bcit",
      "indices" : [ 48, 53 ],
      "id_str" : "19372538",
      "id" : 19372538
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/706651574081183746\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/7mGCBahWbL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cc6H3HvUEAAkxKU.jpg",
      "id_str" : "706651572583796736",
      "id" : 706651572583796736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cc6H3HvUEAAkxKU.jpg",
      "sizes" : [ {
        "h" : 466,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 741
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 741
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7mGCBahWbL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706651574081183746",
  "text" : "Based on an informative session with a group of @bcit educators yesterday, I've revised my basic flipped-LMS diagram https:\/\/t.co\/7mGCBahWbL",
  "id" : 706651574081183746,
  "created_at" : "2016-03-07 01:23:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706647972096798720",
  "geo" : { },
  "id_str" : "706648564634521600",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Gotcha! Great idea - with Grav being a flat-file CMS could be as simple as copying a Grav Skeleton folder and then naming it \uD83D\uDE00",
  "id" : 706648564634521600,
  "in_reply_to_status_id" : 706647972096798720,
  "created_at" : "2016-03-07 01:12:01 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706647020941869056",
  "geo" : { },
  "id_str" : "706647813673750530",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro \uD83D\uDC4D Had a great session with a group of educators yesterday and that helped further refine position of approach.",
  "id" : 706647813673750530,
  "in_reply_to_status_id" : 706647020941869056,
  "created_at" : "2016-03-07 01:09:02 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706646815160963072",
  "geo" : { },
  "id_str" : "706647291730341888",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Could you expand a bit on what you are thinking of?",
  "id" : 706647291730341888,
  "in_reply_to_status_id" : 706646815160963072,
  "created_at" : "2016-03-07 01:06:57 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/6vpLTHBD4A",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/cnie-2016-flipping-the-lms-with-an-open-and-collaborative-platform",
      "display_url" : "slides.com\/paulhibbitts\/c\u2026"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/JPMe4Y723e",
      "expanded_url" : "https:\/\/twitter.com\/DonaldClark\/status\/706599106806988800",
      "display_url" : "twitter.com\/DonaldClark\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706628186797248512",
  "text" : "Could flipping your LMS with an open + collaborative platform help shift the pros and cons? https:\/\/t.co\/6vpLTHBD4A https:\/\/t.co\/JPMe4Y723e",
  "id" : 706628186797248512,
  "created_at" : "2016-03-06 23:51:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNIE-RCI\u00C9",
      "screen_name" : "CNIE_RCIE",
      "indices" : [ 28, 38 ],
      "id_str" : "244782783",
      "id" : 244782783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/ppU2Br8eeu",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/cnie-2016-flipping-the-lms-with-an-open-and-collaborative-platform#\/",
      "display_url" : "slides.com\/paulhibbitts\/c\u2026"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/9PFedwpqcF",
      "expanded_url" : "https:\/\/getgrav.org\/downloads\/skeletons",
      "display_url" : "getgrav.org\/downloads\/skel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706619175981035520",
  "text" : "Busy bee Sunday: finalizing @CNIE_RCIE presentation slides https:\/\/t.co\/ppU2Br8eeu and new Grav Course Hub release https:\/\/t.co\/9PFedwpqcF \uD83D\uDCE3",
  "id" : 706619175981035520,
  "created_at" : "2016-03-06 23:15:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Greco",
      "screen_name" : "grecasaurus",
      "indices" : [ 3, 15 ],
      "id_str" : "106276113",
      "id" : 106276113
    }, {
      "name" : "IxD Education Summit",
      "screen_name" : "ixdaEducation",
      "indices" : [ 37, 51 ],
      "id_str" : "2834909746",
      "id" : 2834909746
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ixd16",
      "indices" : [ 84, 90 ]
    }, {
      "text" : "ixdes16",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/SeSw1qyMLY",
      "expanded_url" : "http:\/\/www.slideshare.net\/grecasaurus\/teaching-by-proxy",
      "display_url" : "slideshare.net\/grecasaurus\/te\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706614801401655296",
  "text" : "RT @grecasaurus: Slides from my talk @ixdaEducation are up: https:\/\/t.co\/SeSw1qyMLY #ixd16 #ixdes16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IxD Education Summit",
        "screen_name" : "ixdaEducation",
        "indices" : [ 20, 34 ],
        "id_str" : "2834909746",
        "id" : 2834909746
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ixd16",
        "indices" : [ 67, 73 ]
      }, {
        "text" : "ixdes16",
        "indices" : [ 74, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/SeSw1qyMLY",
        "expanded_url" : "http:\/\/www.slideshare.net\/grecasaurus\/teaching-by-proxy",
        "display_url" : "slideshare.net\/grecasaurus\/te\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "706605586838896641",
    "text" : "Slides from my talk @ixdaEducation are up: https:\/\/t.co\/SeSw1qyMLY #ixd16 #ixdes16",
    "id" : 706605586838896641,
    "created_at" : "2016-03-06 22:21:14 +0000",
    "user" : {
      "name" : "Jess Greco",
      "screen_name" : "grecasaurus",
      "protected" : false,
      "id_str" : "106276113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649640255893598212\/QyV04WK0_normal.jpg",
      "id" : 106276113,
      "verified" : false
    }
  },
  "id" : 706614801401655296,
  "created_at" : "2016-03-06 22:57:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 26, 34 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Andrew Haw",
      "screen_name" : "andrewhawr",
      "indices" : [ 128, 139 ],
      "id_str" : "742214790",
      "id" : 742214790
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/5n7H50C2Go",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-11-16-running-grav-locally-with-mamp",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705910438999883776",
  "text" : "Updated post: Running the @getgrav CMS Locally with MAMP (w. more step-by-step screenshots) https:\/\/t.co\/5n7H50C2Go #GravEdu HT @andrewhawr",
  "id" : 705910438999883776,
  "created_at" : "2016-03-05 00:18:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Haw",
      "screen_name" : "andrewhawr",
      "indices" : [ 0, 11 ],
      "id_str" : "742214790",
      "id" : 742214790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/d7uCbuRZpZ",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-22-using-github-desktop-and-beanstalk-with-Grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "705887313910321152",
  "geo" : { },
  "id_str" : "705892876757000193",
  "in_reply_to_user_id" : 742214790,
  "text" : "@andrewhawr I am also thinking of doing more posts in the style of a step-by-step walkthrough like this https:\/\/t.co\/d7uCbuRZpZ",
  "id" : 705892876757000193,
  "in_reply_to_status_id" : 705887313910321152,
  "created_at" : "2016-03-04 23:09:11 +0000",
  "in_reply_to_screen_name" : "andrewhawr",
  "in_reply_to_user_id_str" : "742214790",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Haw",
      "screen_name" : "andrewhawr",
      "indices" : [ 0, 11 ],
      "id_str" : "742214790",
      "id" : 742214790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705887313910321152",
  "geo" : { },
  "id_str" : "705891645972066304",
  "in_reply_to_user_id" : 742214790,
  "text" : "@andrewhawr Thanks for the feedback, some sort of a standalone walkthrough is a good idea. Do the steps in the guide seem reasonable?",
  "id" : 705891645972066304,
  "in_reply_to_status_id" : 705887313910321152,
  "created_at" : "2016-03-04 23:04:17 +0000",
  "in_reply_to_screen_name" : "andrewhawr",
  "in_reply_to_user_id_str" : "742214790",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 3, 10 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "\u26A1\uFE0F Samuel Hulick \u26A1\uFE0F",
      "screen_name" : "SamuelHulick",
      "indices" : [ 49, 62 ],
      "id_str" : "58961325",
      "id" : 58961325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/8HCeC8iUiP",
      "expanded_url" : "https:\/\/medium.com\/better-people\/slack-i-m-breaking-up-with-you-54600ace03ea",
      "display_url" : "medium.com\/better-people\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705841250684018688",
  "text" : "RT @Medium: \u201CSlack, I\u2019m Breaking Up with You\u201D by @SamuelHulick https:\/\/t.co\/8HCeC8iUiP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u26A1\uFE0F Samuel Hulick \u26A1\uFE0F",
        "screen_name" : "SamuelHulick",
        "indices" : [ 37, 50 ],
        "id_str" : "58961325",
        "id" : 58961325
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/8HCeC8iUiP",
        "expanded_url" : "https:\/\/medium.com\/better-people\/slack-i-m-breaking-up-with-you-54600ace03ea",
        "display_url" : "medium.com\/better-people\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704299758341398528",
    "text" : "\u201CSlack, I\u2019m Breaking Up with You\u201D by @SamuelHulick https:\/\/t.co\/8HCeC8iUiP",
    "id" : 704299758341398528,
    "created_at" : "2016-02-29 13:38:42 +0000",
    "user" : {
      "name" : "Medium",
      "screen_name" : "Medium",
      "protected" : false,
      "id_str" : "571202103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752641363548581888\/fY6c3yTR_normal.jpg",
      "id" : 571202103,
      "verified" : true
    }
  },
  "id" : 705841250684018688,
  "created_at" : "2016-03-04 19:44:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    }, {
      "name" : "Stephen Downes",
      "screen_name" : "oldaily",
      "indices" : [ 8, 16 ],
      "id_str" : "96139902",
      "id" : 96139902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705837580168798209",
  "geo" : { },
  "id_str" : "705839633586753536",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob @oldaily So much great insight, but this one gem stood out for me the most: 'See students as partners, not customers'.",
  "id" : 705839633586753536,
  "in_reply_to_status_id" : 705837580168798209,
  "created_at" : "2016-03-04 19:37:37 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 91, 99 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LMS",
      "indices" : [ 49, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705829357005070336",
  "text" : "Are you a Web-savvy educator constrained by your #LMS? Put it in its place by flipping it! @getgrav CMS Course Hub https:\/\/t.co\/VgQsw7bHP4",
  "id" : 705829357005070336,
  "created_at" : "2016-03-04 18:56:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 0, 8 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 9, 17 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705514629963845632",
  "geo" : { },
  "id_str" : "705518442615451648",
  "in_reply_to_user_id" : 10185562,
  "text" : "@drchuck @getgrav The use of GitHub for community editing of docs is also really sweet!",
  "id" : 705518442615451648,
  "in_reply_to_status_id" : 705514629963845632,
  "created_at" : "2016-03-03 22:21:19 +0000",
  "in_reply_to_screen_name" : "drchuck",
  "in_reply_to_user_id_str" : "10185562",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 0, 8 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 9, 17 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/JpIqcFK3QO",
      "expanded_url" : "http:\/\/docs.reclaimhosting.com\/",
      "display_url" : "docs.reclaimhosting.com"
    } ]
  },
  "in_reply_to_status_id_str" : "705514629963845632",
  "geo" : { },
  "id_str" : "705518159780929536",
  "in_reply_to_user_id" : 10185562,
  "text" : "@drchuck @getgrav Also see https:\/\/t.co\/JpIqcFK3QO, which was done with Grav using the same Skeleton.",
  "id" : 705518159780929536,
  "in_reply_to_status_id" : 705514629963845632,
  "created_at" : "2016-03-03 22:20:11 +0000",
  "in_reply_to_screen_name" : "drchuck",
  "in_reply_to_user_id_str" : "10185562",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 0, 8 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 9, 17 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/jK9PBZIQWm",
      "expanded_url" : "http:\/\/learn.getgrav.org",
      "display_url" : "learn.getgrav.org"
    } ]
  },
  "in_reply_to_status_id_str" : "705514629963845632",
  "geo" : { },
  "id_str" : "705517559374749696",
  "in_reply_to_user_id" : 10185562,
  "text" : "@drchuck @getgrav At first glance both look like a good fit. You should check out the Grav docs at https:\/\/t.co\/jK9PBZIQWm, built with Grav!",
  "id" : 705517559374749696,
  "in_reply_to_status_id" : 705514629963845632,
  "created_at" : "2016-03-03 22:17:48 +0000",
  "in_reply_to_screen_name" : "drchuck",
  "in_reply_to_user_id_str" : "10185562",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 8, 16 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705515921268281344",
  "geo" : { },
  "id_str" : "705516742479466496",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @drchuck I am up for something like that!",
  "id" : 705516742479466496,
  "in_reply_to_status_id" : 705515921268281344,
  "created_at" : "2016-03-03 22:14:33 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705516281185771520",
  "geo" : { },
  "id_str" : "705516586732384256",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Nice! Awesome to see more GitHub integration \uD83D\uDC4D",
  "id" : 705516586732384256,
  "in_reply_to_status_id" : 705516281185771520,
  "created_at" : "2016-03-03 22:13:56 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 8, 16 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705515435307839489",
  "geo" : { },
  "id_str" : "705516329814503424",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @drchuck I'll do my best \uD83D\uDE09",
  "id" : 705516329814503424,
  "in_reply_to_status_id" : 705515435307839489,
  "created_at" : "2016-03-03 22:12:55 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 0, 8 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 9, 16 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 74, 82 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705509539475546113",
  "geo" : { },
  "id_str" : "705510726585053185",
  "in_reply_to_user_id" : 10185562,
  "text" : "@drchuck @btopro Thanks very much, any and all feedback very welcome. The @getgrav CMS is a real game changer to me, and is just at 1.0!",
  "id" : 705510726585053185,
  "in_reply_to_status_id" : 705509539475546113,
  "created_at" : "2016-03-03 21:50:39 +0000",
  "in_reply_to_screen_name" : "drchuck",
  "in_reply_to_user_id_str" : "10185562",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Haw",
      "screen_name" : "andrewhawr",
      "indices" : [ 0, 11 ],
      "id_str" : "742214790",
      "id" : 742214790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/qTgCdG6ZPM",
      "expanded_url" : "http:\/\/demo.hibbittsdesign.org\/grav-course-hub\/",
      "display_url" : "demo.hibbittsdesign.org\/grav-course-hu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705507952002641920",
  "in_reply_to_user_id" : 742214790,
  "text" : "@andrewhawr My Grav Course Hub package is close to a v1.0, any thoughts on what you see? https:\/\/t.co\/VgQsw7bHP4 https:\/\/t.co\/qTgCdG6ZPM",
  "id" : 705507952002641920,
  "created_at" : "2016-03-03 21:39:38 +0000",
  "in_reply_to_screen_name" : "andrewhawr",
  "in_reply_to_user_id_str" : "742214790",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 0, 8 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 9, 16 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705488681205964800",
  "geo" : { },
  "id_str" : "705495993400168448",
  "in_reply_to_user_id" : 10185562,
  "text" : "@drchuck @btopro I certainly admire the vision that both of you share as well.",
  "id" : 705495993400168448,
  "in_reply_to_status_id" : 705488681205964800,
  "created_at" : "2016-03-03 20:52:06 +0000",
  "in_reply_to_screen_name" : "drchuck",
  "in_reply_to_user_id_str" : "10185562",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 0, 8 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 9, 16 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705488681205964800",
  "geo" : { },
  "id_str" : "705495727342891008",
  "in_reply_to_user_id" : 10185562,
  "text" : "@drchuck @btopro I agree\/like a lot of the viewpoints expressed, very well stated! For myself, I am taking a more micro approach vs. macro.",
  "id" : 705495727342891008,
  "in_reply_to_status_id" : 705488681205964800,
  "created_at" : "2016-03-03 20:51:03 +0000",
  "in_reply_to_screen_name" : "drchuck",
  "in_reply_to_user_id_str" : "10185562",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 30, 38 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Gravstrap",
      "screen_name" : "gravstrap",
      "indices" : [ 43, 53 ],
      "id_str" : "701343168558669824",
      "id" : 701343168558669824
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Markdown",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "GravEdu",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/lCSCj6mt2l",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-03-03-a-quick-look-at-the-gravstrap-plugin",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705481510539780096",
  "text" : "New Post: A Quick Look at the @getgrav CMS @gravstrap Shortcodes Plugin https:\/\/t.co\/lCSCj6mt2l #Markdown #GravEdu",
  "id" : 705481510539780096,
  "created_at" : "2016-03-03 19:54:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Rieger",
      "screen_name" : "stephanierieger",
      "indices" : [ 3, 19 ],
      "id_str" : "6868612",
      "id" : 6868612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/GuzLAenTSs",
      "expanded_url" : "https:\/\/twitter.com\/kennethlove\/status\/705201765084336129",
      "display_url" : "twitter.com\/kennethlove\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705205548250112001",
  "text" : "RT @stephanierieger: Wonder if Android will become a platform of choice of a whole new generation simply because it enables user choice.  h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/GuzLAenTSs",
        "expanded_url" : "https:\/\/twitter.com\/kennethlove\/status\/705201765084336129",
        "display_url" : "twitter.com\/kennethlove\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "705205323057922050",
    "text" : "Wonder if Android will become a platform of choice of a whole new generation simply because it enables user choice.  https:\/\/t.co\/GuzLAenTSs",
    "id" : 705205323057922050,
    "created_at" : "2016-03-03 01:37:05 +0000",
    "user" : {
      "name" : "Stephanie Rieger",
      "screen_name" : "stephanierieger",
      "protected" : false,
      "id_str" : "6868612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1581672007\/stephanie-rieger_normal.png",
      "id" : 6868612,
      "verified" : false
    }
  },
  "id" : 705205548250112001,
  "created_at" : "2016-03-03 01:37:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 33, 41 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Gravstrap",
      "screen_name" : "gravstrap",
      "indices" : [ 42, 52 ],
      "id_str" : "701343168558669824",
      "id" : 701343168558669824
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/705184550691823616\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/aYM99hDbGT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CclRnIdUcAAIbJF.jpg",
      "id_str" : "705184549387399168",
      "id" : 705184549387399168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CclRnIdUcAAIbJF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aYM99hDbGT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705184550691823616",
  "text" : "Working on a blog post about the @getgrav @gravstrap plugin for use with the Grav Course Hub \u27A4Bootstrap in Markdown! https:\/\/t.co\/aYM99hDbGT",
  "id" : 705184550691823616,
  "created_at" : "2016-03-03 00:14:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yyj",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/6hkyzC8OXO",
      "expanded_url" : "https:\/\/urls.bccampus.ca\/61x",
      "display_url" : "urls.bccampus.ca\/61x"
    } ]
  },
  "geo" : { },
  "id_str" : "705181688104550402",
  "text" : "RT @clintlalonde: We're looking for a Technical Analyst \/ DevOps. Appreciate a r\/t for this BCcampus job posting https:\/\/t.co\/6hkyzC8OXO #y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "yyj",
        "indices" : [ 119, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/6hkyzC8OXO",
        "expanded_url" : "https:\/\/urls.bccampus.ca\/61x",
        "display_url" : "urls.bccampus.ca\/61x"
      } ]
    },
    "geo" : { },
    "id_str" : "705176771855908866",
    "text" : "We're looking for a Technical Analyst \/ DevOps. Appreciate a r\/t for this BCcampus job posting https:\/\/t.co\/6hkyzC8OXO #yyj",
    "id" : 705176771855908866,
    "created_at" : "2016-03-02 23:43:38 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 705181688104550402,
  "created_at" : "2016-03-03 00:03:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 52, 59 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/ggaA7IsRJm",
      "expanded_url" : "http:\/\/wp.me\/pxfFe-cU",
      "display_url" : "wp.me\/pxfFe-cU"
    } ]
  },
  "geo" : { },
  "id_str" : "705148466360520704",
  "text" : "Who else is doing this? https:\/\/t.co\/ggaA7IsRJm via @btopro",
  "id" : 705148466360520704,
  "created_at" : "2016-03-02 21:51:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/v3pEYGfZQi",
      "expanded_url" : "https:\/\/www.eventbrite.ca\/e\/knocking-down-the-walls-tickets-22174716173",
      "display_url" : "eventbrite.ca\/e\/knocking-dow\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705147524307267585",
  "text" : "In 15 minutes Jamie Oliver can make a great meal, and you can learn how to flip your LMS using an open Web platform. https:\/\/t.co\/v3pEYGfZQi",
  "id" : 705147524307267585,
  "created_at" : "2016-03-02 21:47:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705136417676988416",
  "text" : "Interested in time travel dirt cheap? Just use Blackboard Collaborate to take you back at least a decade.",
  "id" : 705136417676988416,
  "created_at" : "2016-03-02 21:03:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Demmel",
      "screen_name" : "daaain",
      "indices" : [ 3, 10 ],
      "id_str" : "18846827",
      "id" : 18846827
    }, {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 33, 45 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    }, {
      "name" : "Etherpad Foundation",
      "screen_name" : "EtherpadOrg",
      "indices" : [ 107, 119 ],
      "id_str" : "135634231",
      "id" : 135634231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705114058559651840",
  "text" : "RT @daaain: This is really cool, @SandstormIO is a Google Drive like collection of open source tools (like @EtherpadOrg), handling the stor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sandstorm.IO",
        "screen_name" : "SandstormIO",
        "indices" : [ 21, 33 ],
        "id_str" : "2476570038",
        "id" : 2476570038
      }, {
        "name" : "Etherpad Foundation",
        "screen_name" : "EtherpadOrg",
        "indices" : [ 95, 107 ],
        "id_str" : "135634231",
        "id" : 135634231
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "705077900941336576",
    "text" : "This is really cool, @SandstormIO is a Google Drive like collection of open source tools (like @EtherpadOrg), handling the storage &amp; sharing",
    "id" : 705077900941336576,
    "created_at" : "2016-03-02 17:10:45 +0000",
    "user" : {
      "name" : "Daniel Demmel",
      "screen_name" : "daaain",
      "protected" : false,
      "id_str" : "18846827",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1605082139\/Gottwood-7_normal.png",
      "id" : 18846827,
      "verified" : false
    }
  },
  "id" : 705114058559651840,
  "created_at" : "2016-03-02 19:34:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNIE-RCI\u00C9",
      "screen_name" : "CNIE_RCIE",
      "indices" : [ 24, 34 ],
      "id_str" : "244782783",
      "id" : 244782783
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/705099211608489985\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/0sJguqPwfE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CckD_yZUMAIEBFI.jpg",
      "id_str" : "705099211054788610",
      "id" : 705099211054788610,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CckD_yZUMAIEBFI.jpg",
      "sizes" : [ {
        "h" : 284,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 161,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 634,
        "resize" : "fit",
        "w" : 1341
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/0sJguqPwfE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/v3pEYGfZQi",
      "expanded_url" : "https:\/\/www.eventbrite.ca\/e\/knocking-down-the-walls-tickets-22174716173",
      "display_url" : "eventbrite.ca\/e\/knocking-dow\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705099211608489985",
  "text" : "A bird's eye view of my @CNIE_RCIE 'Flip it Good!' Mar 7th 15 min. flipping the LMS session. https:\/\/t.co\/v3pEYGfZQi https:\/\/t.co\/0sJguqPwfE",
  "id" : 705099211608489985,
  "created_at" : "2016-03-02 18:35:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/805Hn09CDM",
      "expanded_url" : "http:\/\/cnie-rcie.ca\/index.php\/conference-virtuelle-2016-virtual-conference\/",
      "display_url" : "cnie-rcie.ca\/index.php\/conf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705088329243439104",
  "text" : "15 minutes can not only save you on car insurance, but introduce you to flipping your LMS with an open Web platform. https:\/\/t.co\/805Hn09CDM",
  "id" : 705088329243439104,
  "created_at" : "2016-03-02 17:52:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 0, 9 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705073248229195776",
  "geo" : { },
  "id_str" : "705078392689852416",
  "in_reply_to_user_id" : 837060721,
  "text" : "@m_travin Thanks very much for the kind words Myra. Good luck with your session at EDUSXSW next week! \uD83D\uDC4D",
  "id" : 705078392689852416,
  "in_reply_to_status_id" : 705073248229195776,
  "created_at" : "2016-03-02 17:12:43 +0000",
  "in_reply_to_screen_name" : "m_travin",
  "in_reply_to_user_id_str" : "837060721",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gravstrap",
      "screen_name" : "gravstrap",
      "indices" : [ 35, 45 ],
      "id_str" : "701343168558669824",
      "id" : 701343168558669824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/FCOgNe7TjW",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-course-hub-bootstrap",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704809193908281344",
  "text" : "Pretty excited about combining the @gravstrap Bootstrap shortcodes plugin with my Grav Course Hub Bootstrap theme \uD83D\uDC4D https:\/\/t.co\/FCOgNe7TjW",
  "id" : 704809193908281344,
  "created_at" : "2016-03-01 23:23:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/NGSGvjhovE",
      "expanded_url" : "http:\/\/cnie-rcie.ca\/index.php\/2016\/03\/01\/conference-virtuelle-2016-virtual-conference-schedule-posted\/",
      "display_url" : "cnie-rcie.ca\/index.php\/2016\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704759609005740032",
  "text" : "What can flipping the LMS with an open and collaborative platform do for students and instructors? Join me Mar 7th \uD83D\uDCBB https:\/\/t.co\/NGSGvjhovE",
  "id" : 704759609005740032,
  "created_at" : "2016-03-01 20:05:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNIE-RCI\u00C9",
      "screen_name" : "CNIE_RCIE",
      "indices" : [ 19, 29 ],
      "id_str" : "244782783",
      "id" : 244782783
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 83, 88 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704741199052050432",
  "text" : "My 'Flip it Good!' @CNIE_RCIE presentation on Mar 7 is like a snack pack, while my @ETUG TELL session on Mar 22 will be the full meal deal.",
  "id" : 704741199052050432,
  "created_at" : "2016-03-01 18:52:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/71p46eyUfy",
      "expanded_url" : "https:\/\/twitter.com\/CNIE_RCIE\/status\/704712788317446144",
      "display_url" : "twitter.com\/CNIE_RCIE\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704737689614966784",
  "text" : "My 15 min. 'Flip it Good! Flipping the LMS with an Open and Collaborative Platform' presentation will be on Mar 7th. https:\/\/t.co\/71p46eyUfy",
  "id" : 704737689614966784,
  "created_at" : "2016-03-01 18:38:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 0, 11 ],
      "id_str" : "28429477",
      "id" : 28429477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704722956648189952",
  "geo" : { },
  "id_str" : "704728923007901696",
  "in_reply_to_user_id" : 28429477,
  "text" : "@chadleaman You made me blush \uD83D\uDE0A Right back atcha!",
  "id" : 704728923007901696,
  "in_reply_to_status_id" : 704722956648189952,
  "created_at" : "2016-03-01 18:04:03 +0000",
  "in_reply_to_screen_name" : "chadleaman",
  "in_reply_to_user_id_str" : "28429477",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Kelly",
      "screen_name" : "trass",
      "indices" : [ 0, 6 ],
      "id_str" : "16785883",
      "id" : 16785883
    }, {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 124, 133 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704460393758855168",
  "geo" : { },
  "id_str" : "704726659233001473",
  "in_reply_to_user_id" : 16785883,
  "text" : "@trass Thanks very much for the kind words Tracy, glad you are enjoying my new blog. I am always inspired by the great work @BCcampus does!",
  "id" : 704726659233001473,
  "in_reply_to_status_id" : 704460393758855168,
  "created_at" : "2016-03-01 17:55:03 +0000",
  "in_reply_to_screen_name" : "trass",
  "in_reply_to_user_id_str" : "16785883",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]