Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Status Code",
      "screen_name" : "TheStatusCode",
      "indices" : [ 3, 17 ],
      "id_str" : "958587877",
      "id" : 958587877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 114 ],
      "url" : "https:\/\/t.co\/XOg7bHgi",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=aZOxtURhfEU",
      "display_url" : "youtube.com\/watch?v=aZOxtU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "241674524247093248",
  "text" : "RT @theStatusCode: The inimitable Grace Hopper being interviewed by David Letterman in 1986: https:\/\/t.co\/XOg7bHgi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 95 ],
        "url" : "https:\/\/t.co\/XOg7bHgi",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=aZOxtURhfEU",
        "display_url" : "youtube.com\/watch?v=aZOxtU\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "241670173147406336",
    "text" : "The inimitable Grace Hopper being interviewed by David Letterman in 1986: https:\/\/t.co\/XOg7bHgi",
    "id" : 241670173147406336,
    "created_at" : "2012-08-31 22:53:53 +0000",
    "user" : {
      "name" : "Status Code",
      "screen_name" : "statuscode",
      "protected" : false,
      "id_str" : "100387585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729983599601176576\/UcKUxsJ4_normal.jpg",
      "id" : 100387585,
      "verified" : false
    }
  },
  "id" : 241674524247093248,
  "created_at" : "2012-08-31 23:11:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Gray",
      "screen_name" : "davegray",
      "indices" : [ 53, 62 ],
      "id_str" : "456",
      "id" : 456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/sEUVIs61",
      "expanded_url" : "http:\/\/www.amazon.com\/The-Connected-Company-ebook\/dp\/144931905X\/",
      "display_url" : "amazon.com\/The-Connected-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "241667179622313985",
  "text" : "Favorite tidbit so far from The Connected Company by @davegray is \"A connected company is a learning company.\" Love it! http:\/\/t.co\/sEUVIs61",
  "id" : 241667179622313985,
  "created_at" : "2012-08-31 22:42:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker Collective",
      "screen_name" : "HackrCollective",
      "indices" : [ 0, 16 ],
      "id_str" : "755949428",
      "id" : 755949428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240228223059910657",
  "in_reply_to_user_id" : 755949428,
  "text" : "@HackrCollective Thanks for the RT!",
  "id" : 240228223059910657,
  "created_at" : "2012-08-27 23:24:06 +0000",
  "in_reply_to_screen_name" : "HackrCollective",
  "in_reply_to_user_id_str" : "755949428",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlearning",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/Gp1vNnPd",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/mobilelearningux-demo\/",
      "display_url" : "hibbittsdesign.com\/courses\/mobile\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "240218851361558529",
  "text" : "Interested in mobile learning UX design? Explore the mobile-friendly companion for my upcoming workshops http:\/\/t.co\/Gp1vNnPd #mlearning",
  "id" : 240218851361558529,
  "created_at" : "2012-08-27 22:46:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240187149230673921",
  "geo" : { },
  "id_str" : "240188577441529857",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Thanks for sharing your thoughts Tannis! I found it insightful that you included simplicity.",
  "id" : 240188577441529857,
  "in_reply_to_status_id" : 240187149230673921,
  "created_at" : "2012-08-27 20:46:34 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240186488288059392",
  "text" : "What problem is mobile learning trying to solve? Is it merely access to the right info at the time\/place of need - what are your thoughts?",
  "id" : 240186488288059392,
  "created_at" : "2012-08-27 20:38:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitch Kapor",
      "screen_name" : "mkapor",
      "indices" : [ 3, 10 ],
      "id_str" : "2730791",
      "id" : 2730791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239455530156949504",
  "text" : "RT @mkapor: Wake up policymakers, the patent system is broken.  No way UI gestures should be patentable.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "239446464915464193",
    "text" : "Wake up policymakers, the patent system is broken.  No way UI gestures should be patentable.",
    "id" : 239446464915464193,
    "created_at" : "2012-08-25 19:37:40 +0000",
    "user" : {
      "name" : "Mitch Kapor",
      "screen_name" : "mkapor",
      "protected" : false,
      "id_str" : "2730791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2980368237\/711ec3a016b6aaf3d6ec98e14ec145aa_normal.jpeg",
      "id" : 2730791,
      "verified" : true
    }
  },
  "id" : 239455530156949504,
  "created_at" : "2012-08-25 20:13:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indi Young",
      "screen_name" : "indiyoung",
      "indices" : [ 3, 13 ],
      "id_str" : "816841",
      "id" : 816841
    }, {
      "name" : "Peter Merholz",
      "screen_name" : "peterme",
      "indices" : [ 32, 40 ],
      "id_str" : "1154",
      "id" : 1154
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uxweek",
      "indices" : [ 15, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239142838238068736",
  "text" : "RT @indiyoung: #uxweek Thrilled @peterme defines UX as coordinator, orchestrator, &amp; keeping details true to vision. Can also draw, l ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Merholz",
        "screen_name" : "peterme",
        "indices" : [ 17, 25 ],
        "id_str" : "1154",
        "id" : 1154
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "uxweek",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "239141951805480960",
    "text" : "#uxweek Thrilled @peterme defines UX as coordinator, orchestrator, &amp; keeping details true to vision. Can also draw, like director can write",
    "id" : 239141951805480960,
    "created_at" : "2012-08-24 23:27:39 +0000",
    "user" : {
      "name" : "Indi Young",
      "screen_name" : "indiyoung",
      "protected" : false,
      "id_str" : "816841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699722060994449408\/eSfWKrGz_normal.jpg",
      "id" : 816841,
      "verified" : false
    }
  },
  "id" : 239142838238068736,
  "created_at" : "2012-08-24 23:31:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/Inxd2iT9",
      "expanded_url" : "http:\/\/finance.yahoo.com\/blogs\/breakout\/facebook-worst-ipo-ever-144321373.html",
      "display_url" : "finance.yahoo.com\/blogs\/breakout\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "236511839394099200",
  "text" : "RT @lukew \"$60 billion evaporated inside of 3 months; it's staggering\"\nhttp:\/\/t.co\/Inxd2iT9 &lt;- In no way surprising\u2026",
  "id" : 236511839394099200,
  "created_at" : "2012-08-17 17:16:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtain Revenue",
      "screen_name" : "corvustweets",
      "indices" : [ 0, 13 ],
      "id_str" : "2503692858",
      "id" : 2503692858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235874665988509696",
  "text" : "@corvustweets Thanks for your feedback! Yes, I would consider timely as a part of relevance as well. Could be its own attribute though\u2026",
  "id" : 235874665988509696,
  "created_at" : "2012-08-15 23:04:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235867317383348224",
  "text" : "Working on a set of design attributes for mobile learning UX; relevant, iterative, clear, engaging, structured, and empathetic. Comments?",
  "id" : 235867317383348224,
  "created_at" : "2012-08-15 22:35:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "indices" : [ 3, 15 ],
      "id_str" : "730373",
      "id" : 730373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/fBCPWmxn",
      "expanded_url" : "http:\/\/bradfrostweb.com\/blog\/mobile\/the-many-faces-of-mobile-first\/",
      "display_url" : "bradfrostweb.com\/blog\/mobile\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "235400029697871872",
  "text" : "RT @scottjenson: Excellent discussion of the 'mobile first' mantra and what it actually means.  http:\/\/t.co\/fBCPWmxn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/fBCPWmxn",
        "expanded_url" : "http:\/\/bradfrostweb.com\/blog\/mobile\/the-many-faces-of-mobile-first\/",
        "display_url" : "bradfrostweb.com\/blog\/mobile\/th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "235394640063369216",
    "text" : "Excellent discussion of the 'mobile first' mantra and what it actually means.  http:\/\/t.co\/fBCPWmxn",
    "id" : 235394640063369216,
    "created_at" : "2012-08-14 15:17:10 +0000",
    "user" : {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "protected" : false,
      "id_str" : "730373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576892785149628416\/FiovXOSs_normal.jpeg",
      "id" : 730373,
      "verified" : true
    }
  },
  "id" : 235400029697871872,
  "created_at" : "2012-08-14 15:38:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BraveNewCode",
      "screen_name" : "BraveNewCode",
      "indices" : [ 10, 23 ],
      "id_str" : "89039840",
      "id" : 89039840
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 126, 129 ]
    }, {
      "text" : "mlearning",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/m1EjRKq0",
      "expanded_url" : "http:\/\/www.bravenewcode.com\/2012\/08\/wptouch-pro-tips-central-spotlight-on-mobile-learning-ux\/",
      "display_url" : "bravenewcode.com\/2012\/08\/wptouc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "235076647555067904",
  "text" : "Thanks to @bravenewcode for including my mobile learning UX site in their Tips Central Spotlight series! http:\/\/t.co\/m1EjRKq0 #ux #mlearning",
  "id" : 235076647555067904,
  "created_at" : "2012-08-13 18:13:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baldwin",
      "screen_name" : "benry",
      "indices" : [ 3, 9 ],
      "id_str" : "1969441",
      "id" : 1969441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/GPELnLOS",
      "expanded_url" : "http:\/\/www.bctechnology.com\/job.cfm?id=95346&r=1&keyword=&searchin=jobdesc",
      "display_url" : "bctechnology.com\/job.cfm?id=953\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "231468706939678720",
  "text" : "RT @benry: We're hiring for an Interaction Designer (w00t) http:\/\/t.co\/GPELnLOS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/GPELnLOS",
        "expanded_url" : "http:\/\/www.bctechnology.com\/job.cfm?id=95346&r=1&keyword=&searchin=jobdesc",
        "display_url" : "bctechnology.com\/job.cfm?id=953\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "231432200401326081",
    "text" : "We're hiring for an Interaction Designer (w00t) http:\/\/t.co\/GPELnLOS",
    "id" : 231432200401326081,
    "created_at" : "2012-08-03 16:51:51 +0000",
    "user" : {
      "name" : "Scott Baldwin",
      "screen_name" : "benry",
      "protected" : false,
      "id_str" : "1969441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573733440186511360\/TYW5qsNh_normal.png",
      "id" : 1969441,
      "verified" : false
    }
  },
  "id" : 231468706939678720,
  "created_at" : "2012-08-03 19:16:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]