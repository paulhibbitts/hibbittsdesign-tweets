Grailbird.data.tweets_2011_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtain Revenue",
      "screen_name" : "corvustweets",
      "indices" : [ 0, 13 ],
      "id_str" : "2503692858",
      "id" : 2503692858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75591485671743489",
  "text" : "@corvustweets I think there's a message for all of us in that one :-)",
  "id" : 75591485671743489,
  "created_at" : "2011-05-31 15:56:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 54 ],
      "url" : "http:\/\/t.co\/Kjggm67",
      "expanded_url" : "http:\/\/spyrestudios.com\/android-vs-ios-a-usability-battle\/",
      "display_url" : "spyrestudios.com\/android-vs-ios\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "75355565546668032",
  "text" : "Android vs iOS; A Usability Battle http:\/\/t.co\/Kjggm67 &lt;- Android's Menu and Back buttons certainly offer a lot in terms of usability to me!",
  "id" : 75355565546668032,
  "created_at" : "2011-05-31 00:19:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Alfbo",
      "screen_name" : "janalfbo",
      "indices" : [ 0, 9 ],
      "id_str" : "205605184",
      "id" : 205605184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74103855574556673",
  "geo" : { },
  "id_str" : "74132164769366016",
  "in_reply_to_user_id" : 205605184,
  "text" : "@janalfbo Thanks very much for the kind words! I hope you find the UX resource collection helpful.",
  "id" : 74132164769366016,
  "in_reply_to_status_id" : 74103855574556673,
  "created_at" : "2011-05-27 15:17:40 +0000",
  "in_reply_to_screen_name" : "janalfbo",
  "in_reply_to_user_id_str" : "205605184",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clark",
      "screen_name" : "globalmoxie",
      "indices" : [ 3, 15 ],
      "id_str" : "2733270440",
      "id" : 2733270440
    }, {
      "name" : "Jared Spool",
      "screen_name" : "jmspool",
      "indices" : [ 139, 140 ],
      "id_str" : "849101",
      "id" : 849101
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uiewamt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73169072929505280",
  "text" : "RT @globalmoxie: Microsoft developed actionable set of design principles for Windows 7: http:\/\/j.mp\/kQsMTx Focused on solving Vista prob ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jared Spool",
        "screen_name" : "jmspool",
        "indices" : [ 122, 130 ],
        "id_str" : "849101",
        "id" : 849101
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "uiewamt",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73166924695080960",
    "text" : "Microsoft developed actionable set of design principles for Windows 7: http:\/\/j.mp\/kQsMTx Focused on solving Vista probs. @jmspool #uiewamt",
    "id" : 73166924695080960,
    "created_at" : "2011-05-24 23:22:08 +0000",
    "user" : {
      "name" : "Josh Clark",
      "screen_name" : "bigmediumjosh",
      "protected" : false,
      "id_str" : "7552082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/581098479298084864\/4LiXBCy4_normal.jpg",
      "id" : 7552082,
      "verified" : false
    }
  },
  "id" : 73169072929505280,
  "created_at" : "2011-05-24 23:30:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "frog design",
      "screen_name" : "frogdesign",
      "indices" : [ 60, 71 ],
      "id_str" : "11512342",
      "id" : 11512342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 55 ],
      "url" : "http:\/\/t.co\/Ng2BibQ",
      "expanded_url" : "http:\/\/designmind.frogdesign.com\/blog\/the-ux-of-data.html",
      "display_url" : "designmind.frogdesign.com\/blog\/the-ux-of\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "71302942405308416",
  "text" : "The UX of Data | Blog | design mind http:\/\/t.co\/Ng2BibQ via @frogdesign &lt;-State as data - often underutilized but holds great potential",
  "id" : 71302942405308416,
  "created_at" : "2011-05-19 19:55:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70983515566645248",
  "text" : "Teaching tip: Try to group topics in a learner-centered manner. E.g. how those topics solve a problem, help make better decisions, etc.",
  "id" : 70983515566645248,
  "created_at" : "2011-05-18 22:46:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Petherbridge",
      "screen_name" : "mgpwr",
      "indices" : [ 3, 9 ],
      "id_str" : "18223772",
      "id" : 18223772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FOWD",
      "indices" : [ 87, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70872141993738240",
  "text" : "RT @mgpwr: I hate the iPads back button with the heat of a million suns via Josh Clark #FOWD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FOWD",
        "indices" : [ 76, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70802741756309504",
    "text" : "I hate the iPads back button with the heat of a million suns via Josh Clark #FOWD",
    "id" : 70802741756309504,
    "created_at" : "2011-05-18 10:47:43 +0000",
    "user" : {
      "name" : "Mark Petherbridge",
      "screen_name" : "mgpwr",
      "protected" : false,
      "id_str" : "18223772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000711074084\/0b03714cfcdb424c9a547e6bb7a5c00f_normal.jpeg",
      "id" : 18223772,
      "verified" : false
    }
  },
  "id" : 70872141993738240,
  "created_at" : "2011-05-18 15:23:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/HU7gI3G",
      "expanded_url" : "http:\/\/research.microsoft.com\/en-us\/um\/people\/bibuxton\/buxtoncollection\/",
      "display_url" : "research.microsoft.com\/en-us\/um\/peopl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "68333527124549632",
  "text" : "Found Bill Buxton\u2019s walkthrough of his collection of interactive devices at CHI2011 very inspiring and entertaining! http:\/\/t.co\/HU7gI3G",
  "id" : 68333527124549632,
  "created_at" : "2011-05-11 15:15:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67999282418036736",
  "text" : "WPtouch Pro + Headway Framework is making WordPress more interesting as a virtual learning environment \u2013 customized mobile and desktop UI's!",
  "id" : 67999282418036736,
  "created_at" : "2011-05-10 17:07:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smashing Magazine",
      "screen_name" : "smashingmag",
      "indices" : [ 82, 94 ],
      "id_str" : "15736190",
      "id" : 15736190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http:\/\/t.co\/mT526i4",
      "expanded_url" : "http:\/\/www.smashingmagazine.com\/2011\/05\/02\/a-user-centered-approach-to-mobile-design\/",
      "display_url" : "smashingmagazine.com\/2011\/05\/02\/a-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "65171686089166848",
  "text" : "A User-Centered Approach To Web Design For Mobile Devices http:\/\/t.co\/mT526i4 via @smashingmag Solid article combining UCD w mobile design!",
  "id" : 65171686089166848,
  "created_at" : "2011-05-02 21:51:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]