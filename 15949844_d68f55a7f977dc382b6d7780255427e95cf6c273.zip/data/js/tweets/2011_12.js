Grailbird.data.tweets_2011_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nico Haitas",
      "screen_name" : "handmadecss",
      "indices" : [ 0, 12 ],
      "id_str" : "40861762",
      "id" : 40861762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149820930812678145",
  "geo" : { },
  "id_str" : "149979577647759361",
  "in_reply_to_user_id" : 40861762,
  "text" : "@handmadecss Thanks for the kind words, I hope you find the UX resources helpful!",
  "id" : 149979577647759361,
  "in_reply_to_status_id" : 149820930812678145,
  "created_at" : "2011-12-22 22:28:12 +0000",
  "in_reply_to_screen_name" : "handmadecss",
  "in_reply_to_user_id_str" : "40861762",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HFI",
      "screen_name" : "humanfactors",
      "indices" : [ 3, 16 ],
      "id_str" : "16874616",
      "id" : 16874616
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 51, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/Xfx9cwJP",
      "expanded_url" : "http:\/\/ow.ly\/7UGMz",
      "display_url" : "ow.ly\/7UGMz"
    } ]
  },
  "geo" : { },
  "id_str" : "146085890299658240",
  "text" : "RT @humanfactors: Eleven free use experience books #UX\nhttp:\/\/t.co\/Xfx9cwJP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 33, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/Xfx9cwJP",
        "expanded_url" : "http:\/\/ow.ly\/7UGMz",
        "display_url" : "ow.ly\/7UGMz"
      } ]
    },
    "geo" : { },
    "id_str" : "146076875528216577",
    "text" : "Eleven free use experience books #UX\nhttp:\/\/t.co\/Xfx9cwJP",
    "id" : 146076875528216577,
    "created_at" : "2011-12-12 04:00:15 +0000",
    "user" : {
      "name" : "HFI",
      "screen_name" : "humanfactors",
      "protected" : false,
      "id_str" : "16874616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752497708620013568\/Yk8zOZ-b_normal.jpg",
      "id" : 16874616,
      "verified" : false
    }
  },
  "id" : 146085890299658240,
  "created_at" : "2011-12-12 04:36:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]