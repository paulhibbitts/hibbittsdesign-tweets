Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 12, 25 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274552484322750464",
  "geo" : { },
  "id_str" : "274625126199357440",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard @clintlalonde Thanks Glen. Working on preso outline + theming and would appreciate any feedback! Will share when ready for sure.",
  "id" : 274625126199357440,
  "in_reply_to_status_id" : 274552484322750464,
  "created_at" : "2012-11-30 21:25:07 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 119 ],
      "url" : "https:\/\/t.co\/22NjVqFi",
      "expanded_url" : "https:\/\/github.com\/bmbrands\/theme_bootstrap",
      "display_url" : "github.com\/bmbrands\/theme\u2026"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/sm8C9SOX",
      "expanded_url" : "http:\/\/jtemas.com.br\/en\/documentation\/category\/moodle-theme-jcopabana",
      "display_url" : "jtemas.com.br\/en\/documentati\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "274550165401128960",
  "geo" : { },
  "id_str" : "274623953350324224",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Thanks Clint. Looking at customizing either open source or commercial Moodle theme. https:\/\/t.co\/22NjVqFi http:\/\/t.co\/sm8C9SOX",
  "id" : 274623953350324224,
  "in_reply_to_status_id" : 274550165401128960,
  "created_at" : "2012-11-30 21:20:27 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274397594694844416",
  "geo" : { },
  "id_str" : "274549461924052992",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde I plan to demo a Twitter Bootstrap Moodle theme in my mobile learning UX preso at Canada MoodleMoot in Feb - are you going?",
  "id" : 274549461924052992,
  "in_reply_to_status_id" : 274397594694844416,
  "created_at" : "2012-11-30 16:24:27 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/yklXlxUy",
      "expanded_url" : "http:\/\/vitamintalent.com\/vitabites\/five-secrets-to-successful-collaborative-design-critiques",
      "display_url" : "vitamintalent.com\/vitabites\/five\u2026"
    }, {
      "indices" : [ 118, 139 ],
      "url" : "https:\/\/t.co\/9BtmWD1E",
      "expanded_url" : "https:\/\/speakerdeck.com\/hibbittsdesign\/agile-vancouver-involving-stakeholders-in-user-experience-ux-design",
      "display_url" : "speakerdeck.com\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273920730440269824",
  "text" : "Some great stakeholder involvement tips at http:\/\/t.co\/yklXlxUy Nice complement with my earlier Agile Vancouver preso https:\/\/t.co\/9BtmWD1E",
  "id" : 273920730440269824,
  "created_at" : "2012-11-28 22:46:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UBC CTLT",
      "screen_name" : "UBC_CTLT",
      "indices" : [ 3, 12 ],
      "id_str" : "16368476",
      "id" : 16368476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/JbODsoGV",
      "expanded_url" : "http:\/\/dlvr.it\/2Wrd1H",
      "display_url" : "dlvr.it\/2Wrd1H"
    } ]
  },
  "geo" : { },
  "id_str" : "271735717133176835",
  "text" : "RT @UBC_CTLT: News Item: Insights: Formal courses are not dead, just different http:\/\/t.co\/JbODsoGV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/JbODsoGV",
        "expanded_url" : "http:\/\/dlvr.it\/2Wrd1H",
        "display_url" : "dlvr.it\/2Wrd1H"
      } ]
    },
    "geo" : { },
    "id_str" : "271732294400761856",
    "text" : "News Item: Insights: Formal courses are not dead, just different http:\/\/t.co\/JbODsoGV",
    "id" : 271732294400761856,
    "created_at" : "2012-11-22 21:50:02 +0000",
    "user" : {
      "name" : "UBC CTLT",
      "screen_name" : "UBC_CTLT",
      "protected" : false,
      "id_str" : "16368476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669315281815105536\/xJtGMvol_normal.jpg",
      "id" : 16368476,
      "verified" : false
    }
  },
  "id" : 271735717133176835,
  "created_at" : "2012-11-22 22:03:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krista Lambert",
      "screen_name" : "contentkrista",
      "indices" : [ 0, 14 ],
      "id_str" : "166647816",
      "id" : 166647816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269207133696974848",
  "in_reply_to_user_id" : 166647816,
  "text" : "@contentkrista Thanks very much for the RT Krista!",
  "id" : 269207133696974848,
  "created_at" : "2012-11-15 22:35:56 +0000",
  "in_reply_to_screen_name" : "contentkrista",
  "in_reply_to_user_id_str" : "166647816",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Cooper",
      "screen_name" : "MrAlanCooper",
      "indices" : [ 3, 16 ],
      "id_str" : "103920270",
      "id" : 103920270
    }, {
      "name" : "Christina Wodtke",
      "screen_name" : "cwodtke",
      "indices" : [ 33, 41 ],
      "id_str" : "1763261",
      "id" : 1763261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267009574467411969",
  "text" : "RT @MrAlanCooper Not me!--&gt;RT @cwodtke: Anyone LOVE the title User Experience Designer? +1 Hardly ever a single person and meaningless title",
  "id" : 267009574467411969,
  "created_at" : "2012-11-09 21:03:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266961548386369537",
  "geo" : { },
  "id_str" : "266963856839028736",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Overall yes! Loved fluid Start screen, edge-based gestures, touch cover, and aspect ratio. Buggy though, but will still be using it.",
  "id" : 266963856839028736,
  "in_reply_to_status_id" : 266961548386369537,
  "created_at" : "2012-11-09 18:01:58 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266947185587937280",
  "text" : "After less than two weeks of using the Surface I am welcomed back to the iPad by a download of 53 app updates - YAY!",
  "id" : 266947185587937280,
  "created_at" : "2012-11-09 16:55:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266326726802558977",
  "geo" : { },
  "id_str" : "266331001066770434",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Thanks very much for the mention Holly!",
  "id" : 266331001066770434,
  "in_reply_to_status_id" : 266326726802558977,
  "created_at" : "2012-11-08 00:07:13 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266324955434741761",
  "geo" : { },
  "id_str" : "266328445821284352",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Thanks very much for your kind words Clint!",
  "id" : 266328445821284352,
  "in_reply_to_status_id" : 266324955434741761,
  "created_at" : "2012-11-07 23:57:04 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Currie",
      "screen_name" : "Currie",
      "indices" : [ 0, 7 ],
      "id_str" : "1282151",
      "id" : 1282151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266312975785279488",
  "geo" : { },
  "id_str" : "266315781426511872",
  "in_reply_to_user_id" : 1282151,
  "text" : "@Currie Thanks very much for the kind words and for retweeting the slides. It was my pleasure to be part of the workshop!",
  "id" : 266315781426511872,
  "in_reply_to_status_id" : 266312975785279488,
  "created_at" : "2012-11-07 23:06:44 +0000",
  "in_reply_to_screen_name" : "Currie",
  "in_reply_to_user_id_str" : "1282151",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlearning",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 127 ],
      "url" : "https:\/\/t.co\/NfvTT7Hc",
      "expanded_url" : "https:\/\/speakerdeck.com\/hibbittsdesign\/etug-fall-2012-mobile-learning-an-evolving-user-experience-perspective",
      "display_url" : "speakerdeck.com\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "266239696340918273",
  "text" : "If you missed it earlier, slides from my \"Mobile Learning \u2013 An Evolving User Experience Perspective\" talk https:\/\/t.co\/NfvTT7Hc #mlearning",
  "id" : 266239696340918273,
  "created_at" : "2012-11-07 18:04:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jetstrap",
      "screen_name" : "jetstrap",
      "indices" : [ 3, 12 ],
      "id_str" : "723443490",
      "id" : 723443490
    }, {
      "name" : "jetstrap",
      "screen_name" : "jetstrap",
      "indices" : [ 72, 81 ],
      "id_str" : "723443490",
      "id" : 723443490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/eZI7v9T0",
      "expanded_url" : "http:\/\/www.webdistortion.com\/2012\/11\/06\/resources-twitter-bootstrap\/",
      "display_url" : "webdistortion.com\/2012\/11\/06\/res\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265926374898937856",
  "text" : "RT @jetstrap: 38 Useful Resources for Twitter Bootstrap Fans (including @jetstrap) - http:\/\/t.co\/eZI7v9T0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jetstrap",
        "screen_name" : "jetstrap",
        "indices" : [ 58, 67 ],
        "id_str" : "723443490",
        "id" : 723443490
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/eZI7v9T0",
        "expanded_url" : "http:\/\/www.webdistortion.com\/2012\/11\/06\/resources-twitter-bootstrap\/",
        "display_url" : "webdistortion.com\/2012\/11\/06\/res\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "265912529702760448",
    "text" : "38 Useful Resources for Twitter Bootstrap Fans (including @jetstrap) - http:\/\/t.co\/eZI7v9T0",
    "id" : 265912529702760448,
    "created_at" : "2012-11-06 20:24:22 +0000",
    "user" : {
      "name" : "jetstrap",
      "screen_name" : "jetstrap",
      "protected" : false,
      "id_str" : "723443490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3690688418\/5eaaddd2783f9884cd308b3edd10a837_normal.png",
      "id" : 723443490,
      "verified" : false
    }
  },
  "id" : 265926374898937856,
  "created_at" : "2012-11-06 21:19:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinforest",
      "screen_name" : "tinforest",
      "indices" : [ 0, 10 ],
      "id_str" : "7337252",
      "id" : 7337252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265664117640146944",
  "geo" : { },
  "id_str" : "265665172755058688",
  "in_reply_to_user_id" : 7337252,
  "text" : "@tinforest That would be a great combo for sure - hope you enjoy it! Very nice to cross paths once again at ETUG.",
  "id" : 265665172755058688,
  "in_reply_to_status_id" : 265664117640146944,
  "created_at" : "2012-11-06 04:01:27 +0000",
  "in_reply_to_screen_name" : "tinforest",
  "in_reply_to_user_id_str" : "7337252",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 0, 8 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265615316577574912",
  "geo" : { },
  "id_str" : "265664560097271809",
  "in_reply_to_user_id" : 1550251,
  "text" : "@dmitryn A tough call - for me it is a working example of multi-touch + desktops\/laptops. For many people v 2.0 might be the better path...",
  "id" : 265664560097271809,
  "in_reply_to_status_id" : 265615316577574912,
  "created_at" : "2012-11-06 03:59:01 +0000",
  "in_reply_to_screen_name" : "dmitryn",
  "in_reply_to_user_id_str" : "1550251",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clark",
      "screen_name" : "globalmoxie",
      "indices" : [ 93, 105 ],
      "id_str" : "2733270440",
      "id" : 2733270440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/EcWsNXfj",
      "expanded_url" : "http:\/\/globalmoxie.com\/blog\/desktop-touch-design.shtml",
      "display_url" : "globalmoxie.com\/blog\/desktop-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265569007476813825",
  "text" : "New Rule: Every Desktop Design Has To Go Finger-Friendly (Global Moxie) http:\/\/t.co\/EcWsNXfj @globalmoxie &lt;- 100% agree after 1 wk w Surface",
  "id" : 265569007476813825,
  "created_at" : "2012-11-05 21:39:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/7OPhX1qF",
      "expanded_url" : "http:\/\/www.tracsoft.com\/blogpost\/blog_blog\/howtomakeyourwebsitetouchfriendly.aspx",
      "display_url" : "tracsoft.com\/blogpost\/blog_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "265559977412939777",
  "geo" : { },
  "id_str" : "265561162723237888",
  "in_reply_to_user_id" : 478963764,
  "text" : "@langilj2012 Here is an article with some more info http:\/\/t.co\/7OPhX1qF",
  "id" : 265561162723237888,
  "in_reply_to_status_id" : 265559977412939777,
  "created_at" : "2012-11-05 21:08:09 +0000",
  "in_reply_to_screen_name" : "ECFjournal",
  "in_reply_to_user_id_str" : "478963764",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265559977412939777",
  "geo" : { },
  "id_str" : "265560879561588737",
  "in_reply_to_user_id" : 478963764,
  "text" : "@langilj2012 Think thumbs :-)  Example #1: add more padding between lists of links Example #2: btns should not be right next to other btns",
  "id" : 265560879561588737,
  "in_reply_to_status_id" : 265559977412939777,
  "created_at" : "2012-11-05 21:07:02 +0000",
  "in_reply_to_screen_name" : "ECFjournal",
  "in_reply_to_user_id_str" : "478963764",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265558857881907200",
  "geo" : { },
  "id_str" : "265559974585958400",
  "in_reply_to_user_id" : 478963764,
  "text" : "@langilj2012 Perhaps less so, but it would depend on how you use it. I've been using it as a laptop + iPad replacement.",
  "id" : 265559974585958400,
  "in_reply_to_status_id" : 265558857881907200,
  "created_at" : "2012-11-05 21:03:26 +0000",
  "in_reply_to_screen_name" : "ECFjournal",
  "in_reply_to_user_id_str" : "478963764",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265559495290269696",
  "text" : "Surface lessons: it's not touch OR desktop, it is touch AND desktop. Laptops w\/o touch are antiques. Design for touch on all websites\u2026 now.",
  "id" : 265559495290269696,
  "created_at" : "2012-11-05 21:01:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265558322164408321",
  "text" : "One week with Surface: -'s initial configuration, switching back-and-forth to desktop mode, unexpected pauses, non-lap friendly, and cameras",
  "id" : 265558322164408321,
  "created_at" : "2012-11-05 20:56:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265557662345875456",
  "text" : "One week with Surface: +'s fluid start screen (iPad seems static now), edge gestures, touch cover, high build quality, and aspect ratio",
  "id" : 265557662345875456,
  "created_at" : "2012-11-05 20:54:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Lee",
      "screen_name" : "riacale",
      "indices" : [ 0, 8 ],
      "id_str" : "15093343",
      "id" : 15093343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264509398376919041",
  "geo" : { },
  "id_str" : "264512797541539842",
  "in_reply_to_user_id" : 15093343,
  "text" : "@riacale Thanks for the clarification. Unfortunately, I do not know of any plugin that would do that at this time.",
  "id" : 264512797541539842,
  "in_reply_to_status_id" : 264509398376919041,
  "created_at" : "2012-11-02 23:42:20 +0000",
  "in_reply_to_screen_name" : "riacale",
  "in_reply_to_user_id_str" : "15093343",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy Underhill",
      "screen_name" : "cindyu",
      "indices" : [ 3, 10 ],
      "id_str" : "5540542",
      "id" : 5540542
    }, {
      "name" : "Giulia Forsythe",
      "screen_name" : "giuliaforsythe",
      "indices" : [ 64, 79 ],
      "id_str" : "17620729",
      "id" : 17620729
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/kOLTJ6LV",
      "expanded_url" : "http:\/\/flic.kr\/p\/dq6CWf",
      "display_url" : "flic.kr\/p\/dq6CWf"
    } ]
  },
  "geo" : { },
  "id_str" : "264503185073377280",
  "text" : "RT @cindyu: ETUG Fall Session 2012 http:\/\/t.co\/kOLTJ6LV. I'm no @giuliaforsythe but here's my stream of consciousness in visual form. #etug",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Giulia Forsythe",
        "screen_name" : "giuliaforsythe",
        "indices" : [ 52, 67 ],
        "id_str" : "17620729",
        "id" : 17620729
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 122, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/kOLTJ6LV",
        "expanded_url" : "http:\/\/flic.kr\/p\/dq6CWf",
        "display_url" : "flic.kr\/p\/dq6CWf"
      } ]
    },
    "geo" : { },
    "id_str" : "264499408744374272",
    "text" : "ETUG Fall Session 2012 http:\/\/t.co\/kOLTJ6LV. I'm no @giuliaforsythe but here's my stream of consciousness in visual form. #etug",
    "id" : 264499408744374272,
    "created_at" : "2012-11-02 22:49:07 +0000",
    "user" : {
      "name" : "Cindy Underhill",
      "screen_name" : "cindyu",
      "protected" : false,
      "id_str" : "5540542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767585476010061824\/dhNOzUpb_normal.jpg",
      "id" : 5540542,
      "verified" : false
    }
  },
  "id" : 264503185073377280,
  "created_at" : "2012-11-02 23:04:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Lee",
      "screen_name" : "riacale",
      "indices" : [ 0, 8 ],
      "id_str" : "15093343",
      "id" : 15093343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264451265562558464",
  "geo" : { },
  "id_str" : "264501334651318272",
  "in_reply_to_user_id" : 15093343,
  "text" : "@riacale By \"forks\" posts what exactly do you mean?",
  "id" : 264501334651318272,
  "in_reply_to_status_id" : 264451265562558464,
  "created_at" : "2012-11-02 22:56:47 +0000",
  "in_reply_to_screen_name" : "riacale",
  "in_reply_to_user_id_str" : "15093343",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 119, 124 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 101 ],
      "url" : "https:\/\/t.co\/NfvTT7Hc",
      "expanded_url" : "https:\/\/speakerdeck.com\/hibbittsdesign\/etug-fall-2012-mobile-learning-an-evolving-user-experience-perspective",
      "display_url" : "speakerdeck.com\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "264445980374622210",
  "text" : "Slides from my \"Mobile Learning \u2013 An Evolving User Experience Perspective\" talk https:\/\/t.co\/NfvTT7Hc Thanks very much @etug and attendees!",
  "id" : 264445980374622210,
  "created_at" : "2012-11-02 19:16:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Lee",
      "screen_name" : "riacale",
      "indices" : [ 0, 8 ],
      "id_str" : "15093343",
      "id" : 15093343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/FGboMeie",
      "expanded_url" : "http:\/\/en.bainternet.info\/2011\/user-specific-content-plugin",
      "display_url" : "en.bainternet.info\/2011\/user-spec\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "264409070147080193",
  "geo" : { },
  "id_str" : "264442419993509888",
  "in_reply_to_user_id" : 15093343,
  "text" : "@riacale The WP plugin is \"User Specific Content\" and the plugin site is at http:\/\/t.co\/FGboMeie Thanks for being part of today's session!",
  "id" : 264442419993509888,
  "in_reply_to_status_id" : 264409070147080193,
  "created_at" : "2012-11-02 19:02:40 +0000",
  "in_reply_to_screen_name" : "riacale",
  "in_reply_to_user_id_str" : "15093343",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/RoEHxUYx",
      "expanded_url" : "http:\/\/www.codinghorror.com\/blog\/2012\/11\/do-you-wanna-touch.html",
      "display_url" : "codinghorror.com\/blog\/2012\/11\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "264165339552686080",
  "text" : "RT @lukew: \"typing and touching are spectacularly compatible, at least for laptops.\"\nhttp:\/\/t.co\/RoEHxUYx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/RoEHxUYx",
        "expanded_url" : "http:\/\/www.codinghorror.com\/blog\/2012\/11\/do-you-wanna-touch.html",
        "display_url" : "codinghorror.com\/blog\/2012\/11\/d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "264149390757867520",
    "text" : "\"typing and touching are spectacularly compatible, at least for laptops.\"\nhttp:\/\/t.co\/RoEHxUYx",
    "id" : 264149390757867520,
    "created_at" : "2012-11-01 23:38:17 +0000",
    "user" : {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "protected" : false,
      "id_str" : "13889622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477610446917103616\/_cjU3_ga_normal.png",
      "id" : 13889622,
      "verified" : false
    }
  },
  "id" : 264165339552686080,
  "created_at" : "2012-11-02 00:41:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/Q9tZmzY6",
      "expanded_url" : "http:\/\/www.mindmeister.com\/216442353\/etug-fall-2012-mobile-learning-an-evolving-user-experience-perspective",
      "display_url" : "mindmeister.com\/216442353\/etug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "264048427342651392",
  "text" : "Presenting \"Mobile Learning \u2013 An Evolving User Experience Perspective\" at #etug tomorrow. http:\/\/t.co\/Q9tZmzY6 Will share slides afterwards.",
  "id" : 264048427342651392,
  "created_at" : "2012-11-01 16:57:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]