Grailbird.data.tweets_2015_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeopardy Jackie",
      "screen_name" : "JeopardyJackie",
      "indices" : [ 0, 15 ],
      "id_str" : "1687114014",
      "id" : 1687114014
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571399675535884288",
  "geo" : { },
  "id_str" : "571408329840291840",
  "in_reply_to_user_id" : 1687114014,
  "text" : "@JeopardyJackie Indeed, I remember you being a long-time fan too.",
  "id" : 571408329840291840,
  "in_reply_to_status_id" : 571399675535884288,
  "created_at" : "2015-02-27 20:35:36 +0000",
  "in_reply_to_screen_name" : "JeopardyJackie",
  "in_reply_to_user_id_str" : "1687114014",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonard Nimoy",
      "screen_name" : "TheRealNimoy",
      "indices" : [ 1, 14 ],
      "id_str" : "128956175",
      "id" : 128956175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571382348060561409",
  "text" : "\u201C@TheRealNimoy: A life is like a garden. Perfect moments can be had, but not preserved, except in memory.  LLAP\u201D RIP Mr. Nimoy",
  "id" : 571382348060561409,
  "created_at" : "2015-02-27 18:52:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jisc",
      "screen_name" : "Jisc",
      "indices" : [ 3, 8 ],
      "id_str" : "18829580",
      "id" : 18829580
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 118, 125 ]
    }, {
      "text" : "digifest15",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/9eCL6KFGP7",
      "expanded_url" : "http:\/\/bit.ly\/1DZEGk3",
      "display_url" : "bit.ly\/1DZEGk3"
    } ]
  },
  "geo" : { },
  "id_str" : "571007314334846976",
  "text" : "RT @Jisc: 45% students say technology provision now plays a part in their choice of university http:\/\/t.co\/9eCL6KFGP7 #edtech #digifest15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 108, 115 ]
      }, {
        "text" : "digifest15",
        "indices" : [ 116, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/9eCL6KFGP7",
        "expanded_url" : "http:\/\/bit.ly\/1DZEGk3",
        "display_url" : "bit.ly\/1DZEGk3"
      } ]
    },
    "geo" : { },
    "id_str" : "571006964102139905",
    "text" : "45% students say technology provision now plays a part in their choice of university http:\/\/t.co\/9eCL6KFGP7 #edtech #digifest15",
    "id" : 571006964102139905,
    "created_at" : "2015-02-26 18:00:43 +0000",
    "user" : {
      "name" : "Jisc",
      "screen_name" : "Jisc",
      "protected" : false,
      "id_str" : "18829580",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000659448543\/e7bbeb0b7a35fc45a48bdd76b5b491fd_normal.png",
      "id" : 18829580,
      "verified" : false
    }
  },
  "id" : 571007314334846976,
  "created_at" : "2015-02-26 18:02:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 66, 76 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/7bwEn9j2R2",
      "expanded_url" : "http:\/\/shar.es\/1WJN1L",
      "display_url" : "shar.es\/1WJN1L"
    } ]
  },
  "geo" : { },
  "id_str" : "570723635821826048",
  "text" : "Review: Online UX Courses :: UXmatters http:\/\/t.co\/7bwEn9j2R2 via @sharethis",
  "id" : 570723635821826048,
  "created_at" : "2015-02-25 23:14:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clark",
      "screen_name" : "globalmoxie",
      "indices" : [ 3, 15 ],
      "id_str" : "2733270440",
      "id" : 2733270440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570722776534790144",
  "text" : "RT @globalmoxie: As interfaces spread everywhere, quick experiences are likely to be better than \"engaging\" ones.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570611482280513536",
    "text" : "As interfaces spread everywhere, quick experiences are likely to be better than \"engaging\" ones.",
    "id" : 570611482280513536,
    "created_at" : "2015-02-25 15:49:13 +0000",
    "user" : {
      "name" : "Josh Clark",
      "screen_name" : "bigmediumjosh",
      "protected" : false,
      "id_str" : "7552082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/581098479298084864\/4LiXBCy4_normal.jpg",
      "id" : 7552082,
      "verified" : false
    }
  },
  "id" : 570722776534790144,
  "created_at" : "2015-02-25 23:11:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570336624757706752",
  "text" : "When defining a digital learning experience think less about specific user interface features and more about desired outcomes.",
  "id" : 570336624757706752,
  "created_at" : "2015-02-24 21:37:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/Cl0WBDnuBr",
      "expanded_url" : "http:\/\/twig.sensiolabs.org\/",
      "display_url" : "twig.sensiolabs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "569980229256523776",
  "text" : "Have any other Web-savvy educators used the Twig language (http:\/\/t.co\/Cl0WBDnuBr ), and if so how user-friendly do you think it is?",
  "id" : 569980229256523776,
  "created_at" : "2015-02-23 22:00:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "indices" : [ 3, 16 ],
      "id_str" : "35943",
      "id" : 35943
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/karenmcgrane\/status\/569888770893328385\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/EEO8sVPRN2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-im0MhCUAA4zuT.jpg",
      "id_str" : "569888768505565184",
      "id" : 569888768505565184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-im0MhCUAA4zuT.jpg",
      "sizes" : [ {
        "h" : 209,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/EEO8sVPRN2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/vPlNmbUqrY",
      "expanded_url" : "http:\/\/responsivewebdesign.com\/podcast\/expedia.html",
      "display_url" : "responsivewebdesign.com\/podcast\/expedi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569895554508926976",
  "text" : "RT @karenmcgrane: Expedia puts this argument to rest: mobile users just need the same stuff. Even travelers. http:\/\/t.co\/vPlNmbUqrY http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/karenmcgrane\/status\/569888770893328385\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/EEO8sVPRN2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-im0MhCUAA4zuT.jpg",
        "id_str" : "569888768505565184",
        "id" : 569888768505565184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-im0MhCUAA4zuT.jpg",
        "sizes" : [ {
          "h" : 209,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/EEO8sVPRN2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/vPlNmbUqrY",
        "expanded_url" : "http:\/\/responsivewebdesign.com\/podcast\/expedia.html",
        "display_url" : "responsivewebdesign.com\/podcast\/expedi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "569888770893328385",
    "text" : "Expedia puts this argument to rest: mobile users just need the same stuff. Even travelers. http:\/\/t.co\/vPlNmbUqrY http:\/\/t.co\/EEO8sVPRN2",
    "id" : 569888770893328385,
    "created_at" : "2015-02-23 15:57:25 +0000",
    "user" : {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "protected" : false,
      "id_str" : "35943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720948130867449857\/DR8tPuqM_normal.jpg",
      "id" : 35943,
      "verified" : false
    }
  },
  "id" : 569895554508926976,
  "created_at" : "2015-02-23 16:24:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Meyer",
      "screen_name" : "meyerweb",
      "indices" : [ 0, 9 ],
      "id_str" : "646533",
      "id" : 646533
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 47, 55 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/YBuziAlJu7",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/iy103-w15-prototype\/fundamentals",
      "display_url" : "hibbittsdesign.com\/courses\/iy103-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "569682568452272128",
  "geo" : { },
  "id_str" : "569685239259275265",
  "in_reply_to_user_id" : 646533,
  "text" : "@meyerweb Great to see. I've been pleased with @getgrav for developing multi-device course companions like this one http:\/\/t.co\/YBuziAlJu7",
  "id" : 569685239259275265,
  "in_reply_to_status_id" : 569682568452272128,
  "created_at" : "2015-02-23 02:28:39 +0000",
  "in_reply_to_screen_name" : "meyerweb",
  "in_reply_to_user_id_str" : "646533",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Meyer",
      "screen_name" : "meyerweb",
      "indices" : [ 0, 9 ],
      "id_str" : "646533",
      "id" : 646533
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 40, 48 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569614803611725824",
  "geo" : { },
  "id_str" : "569682273236176896",
  "in_reply_to_user_id" : 646533,
  "text" : "@meyerweb I'd also suggest checking out @getgrav, with it not only being open source but also with Markdown, YAML, &amp; Twig - all with no DB.",
  "id" : 569682273236176896,
  "in_reply_to_status_id" : 569614803611725824,
  "created_at" : "2015-02-23 02:16:52 +0000",
  "in_reply_to_screen_name" : "meyerweb",
  "in_reply_to_user_id_str" : "646533",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HeyAvailable",
      "screen_name" : "HeyAvailable",
      "indices" : [ 0, 13 ],
      "id_str" : "599987583",
      "id" : 599987583
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YVR",
      "indices" : [ 119, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568572514261012480",
  "in_reply_to_user_id" : 599987583,
  "text" : "@HeyAvailable Mentor: Looking for a UX career chat or have design challenges in digital learning experiences? Downtown #YVR or Skype.",
  "id" : 568572514261012480,
  "created_at" : "2015-02-20 00:47:05 +0000",
  "in_reply_to_screen_name" : "HeyAvailable",
  "in_reply_to_user_id_str" : "599987583",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HeyAvailable",
      "screen_name" : "HeyAvailable",
      "indices" : [ 3, 16 ],
      "id_str" : "599987583",
      "id" : 599987583
    }, {
      "name" : "Denim & Steel",
      "screen_name" : "DenimAndSteel",
      "indices" : [ 50, 64 ],
      "id_str" : "386399234",
      "id" : 386399234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/mAR3Idg5jY",
      "expanded_url" : "http:\/\/kthx.ca\/mi",
      "display_url" : "kthx.ca\/mi"
    } ]
  },
  "geo" : { },
  "id_str" : "568182344265240578",
  "text" : "RT @HeyAvailable: I just got a little update from @DenimAndSteel. Refinements + a new category called Spot Mentors. \n\nRead about it http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Denim & Steel",
        "screen_name" : "DenimAndSteel",
        "indices" : [ 32, 46 ],
        "id_str" : "386399234",
        "id" : 386399234
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/mAR3Idg5jY",
        "expanded_url" : "http:\/\/kthx.ca\/mi",
        "display_url" : "kthx.ca\/mi"
      } ]
    },
    "geo" : { },
    "id_str" : "567831041865490432",
    "text" : "I just got a little update from @DenimAndSteel. Refinements + a new category called Spot Mentors. \n\nRead about it http:\/\/t.co\/mAR3Idg5jY",
    "id" : 567831041865490432,
    "created_at" : "2015-02-17 23:40:44 +0000",
    "user" : {
      "name" : "HeyAvailable",
      "screen_name" : "HeyAvailable",
      "protected" : false,
      "id_str" : "599987583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000679178408\/eb1134a698a94e96fe1b3244663dcfe2_normal.png",
      "id" : 599987583,
      "verified" : false
    }
  },
  "id" : 568182344265240578,
  "created_at" : "2015-02-18 22:56:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 9, 17 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/gc276X7vdE",
      "expanded_url" : "https:\/\/github.com\/paulhibbitts\/grav-skeleton-workshop-companion-prototype",
      "display_url" : "github.com\/paulhibbitts\/g\u2026"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6OdSc6aWBT",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/iy103-w15-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/iy103-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567753082353803264",
  "text" : "Download @getgrav skeleton of a workshop companion at https:\/\/t.co\/gc276X7vdE Demo w. Olark\/IntenseDebate\/Bootswatch http:\/\/t.co\/6OdSc6aWBT",
  "id" : 567753082353803264,
  "created_at" : "2015-02-17 18:30:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 92, 100 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6OdSc6aWBT",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/iy103-w15-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/iy103-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567445053530861570",
  "text" : "Fellow instructors\/EdTech folks - I've been creating a workshop companion site skeleton for @GetGrav - any interest? http:\/\/t.co\/6OdSc6aWBT",
  "id" : 567445053530861570,
  "created_at" : "2015-02-16 22:06:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 92, 100 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/6OdSc6aWBT",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/iy103-w15-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/iy103-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566017866701344769",
  "text" : "What can an instructor do with some basic markdown, YAML, and Twig skills in ~2 weeks? With @getgrav quite a bit... http:\/\/t.co\/6OdSc6aWBT",
  "id" : 566017866701344769,
  "created_at" : "2015-02-12 23:35:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/6WKlBup84G",
      "expanded_url" : "http:\/\/bywordapp.com\/markdown\/syntax.html",
      "display_url" : "bywordapp.com\/markdown\/synta\u2026"
    }, {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/R7nqhsfRQU",
      "expanded_url" : "http:\/\/www.yaml.org\/start.html",
      "display_url" : "yaml.org\/start.html"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/u56E1PsTOl",
      "expanded_url" : "https:\/\/knpuniversity.com\/screencast\/twig\/basics",
      "display_url" : "knpuniversity.com\/screencast\/twi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566014025058623488",
  "text" : "Markdown syntax guide: http:\/\/t.co\/6WKlBup84G\nYAML - Get Started : http:\/\/t.co\/R7nqhsfRQU\nTwig overview (video): https:\/\/t.co\/u56E1PsTOl",
  "id" : 566014025058623488,
  "created_at" : "2015-02-12 23:20:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566010472629948417",
  "text" : "Markdown, YAML, and (maybe) Twig are quickly becoming essential tools for instructors to better shape technology for their students.",
  "id" : 566010472629948417,
  "created_at" : "2015-02-12 23:06:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/6OdSc6aWBT",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/iy103-w15-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/iy103-\u2026"
    }, {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/YBuziAlJu7",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/iy103-w15-prototype\/fundamentals",
      "display_url" : "hibbittsdesign.com\/courses\/iy103-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "565418203565019136",
  "geo" : { },
  "id_str" : "565529822705623040",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Thanks for considering it! For example, here are 4 embeded Slides http:\/\/t.co\/6OdSc6aWBT vs 4 YouTubes http:\/\/t.co\/YBuziAlJu7",
  "id" : 565529822705623040,
  "in_reply_to_status_id" : 565418203565019136,
  "created_at" : "2015-02-11 15:16:31 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565281384055726081",
  "text" : "In addition to the learner experience, here are my criteria for the CMS aspects of a course companion:\nStructured\nModular\nReusable\nAdaptable",
  "id" : 565281384055726081,
  "created_at" : "2015-02-10 22:49:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 51, 59 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/6OdSc6aWBT",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/iy103-w15-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/iy103-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565227006338408448",
  "text" : "Prototype of a multi-device course companion using @getgrav, with a design supporting modular and reusable content. http:\/\/t.co\/6OdSc6aWBT",
  "id" : 565227006338408448,
  "created_at" : "2015-02-10 19:13:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ceVwmSgw03",
      "expanded_url" : "http:\/\/www.labnol.org\/internet\/light-youtube-embeds\/27941\/",
      "display_url" : "labnol.org\/internet\/light\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565213730909085696",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp For use cases of embedding multiple slide decks on a page, has anything like this been considered? http:\/\/t.co\/ceVwmSgw03",
  "id" : 565213730909085696,
  "created_at" : "2015-02-10 18:20:29 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eLearn Magazine",
      "screen_name" : "eLearnMag",
      "indices" : [ 3, 13 ],
      "id_str" : "48439456",
      "id" : 48439456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/AKAVDFyva3",
      "expanded_url" : "http:\/\/elearnmag.acm.org\/archive.cfm?aid=2724693",
      "display_url" : "elearnmag.acm.org\/archive.cfm?ai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563566041456836610",
  "text" : "RT @eLearnMag: The mentor-mentee relationship is as old as time, but can it be successfully replicated online? http:\/\/t.co\/AKAVDFyva3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/AKAVDFyva3",
        "expanded_url" : "http:\/\/elearnmag.acm.org\/archive.cfm?aid=2724693",
        "display_url" : "elearnmag.acm.org\/archive.cfm?ai\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "559801365577601024",
    "text" : "The mentor-mentee relationship is as old as time, but can it be successfully replicated online? http:\/\/t.co\/AKAVDFyva3",
    "id" : 559801365577601024,
    "created_at" : "2015-01-26 19:53:40 +0000",
    "user" : {
      "name" : "eLearn Magazine",
      "screen_name" : "eLearnMag",
      "protected" : false,
      "id_str" : "48439456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588371262260535296\/nKFj3DnM_normal.jpg",
      "id" : 48439456,
      "verified" : false
    }
  },
  "id" : 563566041456836610,
  "created_at" : "2015-02-06 05:13:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563472453020561408",
  "text" : "I've got to say, using Azure w. Dropbox (versioning) for multi-device course companion prototypes has been pretty smooth. 10&lt; sites are free",
  "id" : 563472453020561408,
  "created_at" : "2015-02-05 23:01:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "indices" : [ 3, 15 ],
      "id_str" : "19812150",
      "id" : 19812150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/NbRRFkSR1d",
      "expanded_url" : "http:\/\/opentextbc.ca\/teachinginadigitalage\/part\/9-pedagogical-differences-between-media\/",
      "display_url" : "opentextbc.ca\/teachinginadig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563446666246619136",
  "text" : "RT @drtonybates: Chapter 9 on Choosing and Using New Media now published here: http:\/\/t.co\/NbRRFkSR1d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/NbRRFkSR1d",
        "expanded_url" : "http:\/\/opentextbc.ca\/teachinginadigitalage\/part\/9-pedagogical-differences-between-media\/",
        "display_url" : "opentextbc.ca\/teachinginadig\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563438532966883331",
    "text" : "Chapter 9 on Choosing and Using New Media now published here: http:\/\/t.co\/NbRRFkSR1d",
    "id" : 563438532966883331,
    "created_at" : "2015-02-05 20:46:29 +0000",
    "user" : {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "protected" : false,
      "id_str" : "19812150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2563456751\/wicaixr93w2lri2wsarw_normal.jpeg",
      "id" : 19812150,
      "verified" : false
    }
  },
  "id" : 563446666246619136,
  "created_at" : "2015-02-05 21:18:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 3, 11 ],
      "id_str" : "10675",
      "id" : 10675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 120, 123 ]
    }, {
      "text" : "jobs",
      "indices" : [ 124, 129 ]
    }, {
      "text" : "vancouver",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/VNnaechEfL",
      "expanded_url" : "https:\/\/www.openroad.ca\/about\/careers\/senior-ux-designer\/",
      "display_url" : "openroad.ca\/about\/careers\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563156719308521473",
  "text" : "RT @gordonr: User experience designer? Looking for challenging work with a great team? Join us: https:\/\/t.co\/VNnaechEfL #ux #jobs #vancouver",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ux",
        "indices" : [ 107, 110 ]
      }, {
        "text" : "jobs",
        "indices" : [ 111, 116 ]
      }, {
        "text" : "vancouver",
        "indices" : [ 117, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/VNnaechEfL",
        "expanded_url" : "https:\/\/www.openroad.ca\/about\/careers\/senior-ux-designer\/",
        "display_url" : "openroad.ca\/about\/careers\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563140638980317184",
    "text" : "User experience designer? Looking for challenging work with a great team? Join us: https:\/\/t.co\/VNnaechEfL #ux #jobs #vancouver",
    "id" : 563140638980317184,
    "created_at" : "2015-02-05 01:02:45 +0000",
    "user" : {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "protected" : false,
      "id_str" : "10675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723725303218991104\/GhSmJXhv_normal.jpg",
      "id" : 10675,
      "verified" : false
    }
  },
  "id" : 563156719308521473,
  "created_at" : "2015-02-05 02:06:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/anildash\/status\/562323778525728770\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/oH28FHDUda",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B83GfzUCcAABZQc.jpg",
      "id_str" : "562323778143678464",
      "id" : 562323778143678464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B83GfzUCcAABZQc.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/oH28FHDUda"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/A2Ux0k6stF",
      "expanded_url" : "http:\/\/www.bloomberg.com\/news\/articles\/2015-02-02\/radioshack-is-said-to-discuss-liquidation-as-part-of-sprint-deal",
      "display_url" : "bloomberg.com\/news\/articles\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562383652508557313",
  "text" : "RT @anildash: Sad: Radio Shack's going away http:\/\/t.co\/A2Ux0k6stF Had hoped they'd evolve into \"Maker Shack\"; I loved these kits. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/anildash\/status\/562323778525728770\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/oH28FHDUda",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B83GfzUCcAABZQc.jpg",
        "id_str" : "562323778143678464",
        "id" : 562323778143678464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B83GfzUCcAABZQc.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 1136
        } ],
        "display_url" : "pic.twitter.com\/oH28FHDUda"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/A2Ux0k6stF",
        "expanded_url" : "http:\/\/www.bloomberg.com\/news\/articles\/2015-02-02\/radioshack-is-said-to-discuss-liquidation-as-part-of-sprint-deal",
        "display_url" : "bloomberg.com\/news\/articles\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "562323778525728770",
    "text" : "Sad: Radio Shack's going away http:\/\/t.co\/A2Ux0k6stF Had hoped they'd evolve into \"Maker Shack\"; I loved these kits. http:\/\/t.co\/oH28FHDUda",
    "id" : 562323778525728770,
    "created_at" : "2015-02-02 18:56:50 +0000",
    "user" : {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725706637248368641\/YoilUS58_normal.jpg",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 562383652508557313,
  "created_at" : "2015-02-02 22:54:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft OneNote",
      "screen_name" : "msonenote",
      "indices" : [ 0, 10 ],
      "id_str" : "23735316",
      "id" : 23735316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/0It1OLefqt",
      "expanded_url" : "https:\/\/onenote.uservoice.com\/forums\/256328-onenote-users\/suggestions\/5776804-embed-video-webpages-and-other-live-content-in-o",
      "display_url" : "onenote.uservoice.com\/forums\/256328-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562365578334072832",
  "in_reply_to_user_id" : 23735316,
  "text" : "@msonenote I still dream of the day that this feature request becomes real https:\/\/t.co\/0It1OLefqt Anything you can share on this one?",
  "id" : 562365578334072832,
  "created_at" : "2015-02-02 21:42:56 +0000",
  "in_reply_to_screen_name" : "msonenote",
  "in_reply_to_user_id_str" : "23735316",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]