Grailbird.data.tweets_2016_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 31, 39 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693948190563762177",
  "text" : "As I inch closer to v1.0 of my @getgrav Course Companion, it's time to review the 'why?':\n\u2713User Experience\n\u2713Openness\n\u2713Control\n\u2713Flexibility",
  "id" : 693948190563762177,
  "created_at" : "2016-02-01 00:05:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 3, 12 ],
      "id_str" : "13046992",
      "id" : 13046992
    }, {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "indices" : [ 15, 27 ],
      "id_str" : "19812150",
      "id" : 19812150
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "altc",
      "indices" : [ 102, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/lRU6DbnqfH",
      "expanded_url" : "http:\/\/www.tonybates.ca\/2016\/01\/30\/why-digital-technology-is-not-necessarily-the-answer-to-your-problem\/",
      "display_url" : "tonybates.ca\/2016\/01\/30\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693941124545708032",
  "text" : "RT @mhawksey: .@drtonybates on 'Why digital technology is not necessarily the answer to your problem' #altc https:\/\/t.co\/lRU6DbnqfH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tony Bates",
        "screen_name" : "drtonybates",
        "indices" : [ 1, 13 ],
        "id_str" : "19812150",
        "id" : 19812150
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "altc",
        "indices" : [ 88, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/lRU6DbnqfH",
        "expanded_url" : "http:\/\/www.tonybates.ca\/2016\/01\/30\/why-digital-technology-is-not-necessarily-the-answer-to-your-problem\/",
        "display_url" : "tonybates.ca\/2016\/01\/30\/why\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "693735242297954304",
    "text" : ".@drtonybates on 'Why digital technology is not necessarily the answer to your problem' #altc https:\/\/t.co\/lRU6DbnqfH",
    "id" : 693735242297954304,
    "created_at" : "2016-01-31 09:59:05 +0000",
    "user" : {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "protected" : false,
      "id_str" : "13046992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390851993\/xu6aptqy6a8rb2h2w5by_normal.jpeg",
      "id" : 13046992,
      "verified" : false
    }
  },
  "id" : 693941124545708032,
  "created_at" : "2016-01-31 23:37:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giansimon Diblas",
      "screen_name" : "giansi72",
      "indices" : [ 0, 9 ],
      "id_str" : "3230477368",
      "id" : 3230477368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693522899131461632",
  "geo" : { },
  "id_str" : "693830307426897920",
  "in_reply_to_user_id" : 15949844,
  "text" : "@giansi72 Thanks again for the helpful script, I've been able to include the required plugins via blueprints within my inherited theme.",
  "id" : 693830307426897920,
  "in_reply_to_status_id" : 693522899131461632,
  "created_at" : "2016-01-31 16:16:50 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giansimon Diblas",
      "screen_name" : "giansi72",
      "indices" : [ 0, 9 ],
      "id_str" : "3230477368",
      "id" : 3230477368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686788222165381120",
  "geo" : { },
  "id_str" : "693522899131461632",
  "in_reply_to_user_id" : 3230477368,
  "text" : "@giansi72 Finding your skeleton maker script super helpful! My plugins are not being added though, where should they be indicated? Thank you",
  "id" : 693522899131461632,
  "in_reply_to_status_id" : 686788222165381120,
  "created_at" : "2016-01-30 19:55:18 +0000",
  "in_reply_to_screen_name" : "giansi72",
  "in_reply_to_user_id_str" : "3230477368",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gitter",
      "screen_name" : "gitchat",
      "indices" : [ 110, 118 ],
      "id_str" : "2195724427",
      "id" : 2195724427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/NS9tBrWdC8",
      "expanded_url" : "https:\/\/gitter.im\/hibbitts-design\/grav-skeleton-course-companion",
      "display_url" : "gitter.im\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693187536454168576",
  "text" : "Join me in the hibbitts-design\/grav-skeleton-course-companion chat room on Gitter https:\/\/t.co\/NS9tBrWdC8 via @gitchat",
  "id" : 693187536454168576,
  "created_at" : "2016-01-29 21:42:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 66, 74 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/zeRpRmRdRS",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-course-companion",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693136432353816576",
  "text" : "Working on the final touches of the GitHub readme for my upcoming @getgrav Course Companion website release #edtech\nhttps:\/\/t.co\/zeRpRmRdRS",
  "id" : 693136432353816576,
  "created_at" : "2016-01-29 18:19:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 3, 14 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/SXJlQzJzv1",
      "expanded_url" : "https:\/\/reclaimhosting.com\/free-ssl-certificates-now-available\/",
      "display_url" : "reclaimhosting.com\/free-ssl-certi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693109940018282496",
  "text" : "RT @timmmmyboy: Free SSL for everyone at Reclaim Hosting! https:\/\/t.co\/SXJlQzJzv1 Very stoked to make this happen.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/SXJlQzJzv1",
        "expanded_url" : "https:\/\/reclaimhosting.com\/free-ssl-certificates-now-available\/",
        "display_url" : "reclaimhosting.com\/free-ssl-certi\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 38.22454382018187, -77.49023552688764 ]
    },
    "id_str" : "693109280191418369",
    "text" : "Free SSL for everyone at Reclaim Hosting! https:\/\/t.co\/SXJlQzJzv1 Very stoked to make this happen.",
    "id" : 693109280191418369,
    "created_at" : "2016-01-29 16:31:44 +0000",
    "user" : {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "protected" : false,
      "id_str" : "185375498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568657249413767168\/lnu_2bhL_normal.jpeg",
      "id" : 185375498,
      "verified" : false
    }
  },
  "id" : 693109940018282496,
  "created_at" : "2016-01-29 16:34:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McConnell",
      "screen_name" : "netjmc",
      "indices" : [ 3, 10 ],
      "id_str" : "15127258",
      "id" : 15127258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "digitalworkplace",
      "indices" : [ 43, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/FEA0gH2gdg",
      "expanded_url" : "https:\/\/twitter.com\/mitsmr\/status\/693073877275058176",
      "display_url" : "twitter.com\/mitsmr\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693107423704281089",
  "text" : "RT @netjmc: There goes the generation gap! #digitalworkplace https:\/\/t.co\/FEA0gH2gdg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "digitalworkplace",
        "indices" : [ 31, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/FEA0gH2gdg",
        "expanded_url" : "https:\/\/twitter.com\/mitsmr\/status\/693073877275058176",
        "display_url" : "twitter.com\/mitsmr\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "693097819377422336",
    "text" : "There goes the generation gap! #digitalworkplace https:\/\/t.co\/FEA0gH2gdg",
    "id" : 693097819377422336,
    "created_at" : "2016-01-29 15:46:11 +0000",
    "user" : {
      "name" : "Jane McConnell",
      "screen_name" : "netjmc",
      "protected" : false,
      "id_str" : "15127258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/495478529572630530\/zdUKCSTj_normal.jpeg",
      "id" : 15127258,
      "verified" : false
    }
  },
  "id" : 693107423704281089,
  "created_at" : "2016-01-29 16:24:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hybrid Pedagogy",
      "screen_name" : "HybridPed",
      "indices" : [ 3, 13 ],
      "id_str" : "416608920",
      "id" : 416608920
    }, {
      "name" : "Jonathan Rees",
      "screen_name" : "jhrees",
      "indices" : [ 119, 126 ],
      "id_str" : "227708559",
      "id" : 227708559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/KHBG5DGGRy",
      "expanded_url" : "http:\/\/www.digitalpedagogylab.com\/hybridped\/long-will-class-remain-academic-freedom-control-classroom\/",
      "display_url" : "digitalpedagogylab.com\/hybridped\/long\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692899088447070212",
  "text" : "RT @HybridPed: \u201CAn LMS \u2026 represents a teaching worldview all by itself.\u201D\u00A0\n\nHow Long Will Your Class Remain Yours? from @jhrees \nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Rees",
        "screen_name" : "jhrees",
        "indices" : [ 104, 111 ],
        "id_str" : "227708559",
        "id" : 227708559
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/KHBG5DGGRy",
        "expanded_url" : "http:\/\/www.digitalpedagogylab.com\/hybridped\/long-will-class-remain-academic-freedom-control-classroom\/",
        "display_url" : "digitalpedagogylab.com\/hybridped\/long\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "692089676476354562",
    "text" : "\u201CAn LMS \u2026 represents a teaching worldview all by itself.\u201D\u00A0\n\nHow Long Will Your Class Remain Yours? from @jhrees \nhttps:\/\/t.co\/KHBG5DGGRy",
    "id" : 692089676476354562,
    "created_at" : "2016-01-26 21:00:11 +0000",
    "user" : {
      "name" : "Hybrid Pedagogy",
      "screen_name" : "HybridPed",
      "protected" : false,
      "id_str" : "416608920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683733989576802304\/gcJHTp8O_normal.jpg",
      "id" : 416608920,
      "verified" : false
    }
  },
  "id" : 692899088447070212,
  "created_at" : "2016-01-29 02:36:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 0, 9 ],
      "id_str" : "180743261",
      "id" : 180743261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692844113046024193",
  "geo" : { },
  "id_str" : "692845342044192770",
  "in_reply_to_user_id" : 180743261,
  "text" : "@deployhq Thanks very much! Deploy itself and customer support are always awesome \uD83D\uDC4D",
  "id" : 692845342044192770,
  "in_reply_to_status_id" : 692844113046024193,
  "created_at" : "2016-01-28 23:02:56 +0000",
  "in_reply_to_screen_name" : "deployhq",
  "in_reply_to_user_id_str" : "180743261",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 0, 9 ],
      "id_str" : "180743261",
      "id" : 180743261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692829596031385600",
  "in_reply_to_user_id" : 180743261,
  "text" : "@deployhq Would you know if anyone has used Gogs with Deploy? I am trying to add a repo and keep getting errors - I am still a Git newbie \uD83D\uDE00",
  "id" : 692829596031385600,
  "created_at" : "2016-01-28 22:00:22 +0000",
  "in_reply_to_screen_name" : "deployhq",
  "in_reply_to_user_id_str" : "180743261",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Lebson",
      "screen_name" : "CoryLebson",
      "indices" : [ 3, 14 ],
      "id_str" : "23367786",
      "id" : 23367786
    }, {
      "name" : "UX Movement",
      "screen_name" : "uxmovement",
      "indices" : [ 98, 109 ],
      "id_str" : "199168582",
      "id" : 199168582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/iQxeWjHkkG",
      "expanded_url" : "http:\/\/uxmovement.com\/navigation\/where-to-place-your-accordion-menu-icons",
      "display_url" : "uxmovement.com\/navigation\/whe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692810097077067778",
  "text" : "RT @CoryLebson: Valuable considerations when creating accordion menus &amp; associated icons from @uxmovement (hint \"+\" goes left) https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UX Movement",
        "screen_name" : "uxmovement",
        "indices" : [ 82, 93 ],
        "id_str" : "199168582",
        "id" : 199168582
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 139, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/iQxeWjHkkG",
        "expanded_url" : "http:\/\/uxmovement.com\/navigation\/where-to-place-your-accordion-menu-icons",
        "display_url" : "uxmovement.com\/navigation\/whe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "692809608226824193",
    "text" : "Valuable considerations when creating accordion menus &amp; associated icons from @uxmovement (hint \"+\" goes left) https:\/\/t.co\/iQxeWjHkkG #UX",
    "id" : 692809608226824193,
    "created_at" : "2016-01-28 20:40:57 +0000",
    "user" : {
      "name" : "Cory Lebson",
      "screen_name" : "CoryLebson",
      "protected" : false,
      "id_str" : "23367786",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583701400854536192\/nxIMA4ji_normal.png",
      "id" : 23367786,
      "verified" : false
    }
  },
  "id" : 692810097077067778,
  "created_at" : "2016-01-28 20:42:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 49, 57 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/8ThZgaVfkJ",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/a-brief-presentation-about-flipping-the-lms",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/a-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692788782186106880",
  "text" : "A Brief Presentation about Flipping the LMS with @getgrav... Flip it Good! https:\/\/t.co\/8ThZgaVfkJ #GravEdu",
  "id" : 692788782186106880,
  "created_at" : "2016-01-28 19:18:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Book Apart",
      "screen_name" : "abookapart",
      "indices" : [ 3, 14 ],
      "id_str" : "106418338",
      "id" : 106418338
    }, {
      "name" : "David Demaree",
      "screen_name" : "ddemaree",
      "indices" : [ 69, 78 ],
      "id_str" : "16683",
      "id" : 16683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/4YiZ4iDVTE",
      "expanded_url" : "http:\/\/abookapart.com\/products\/git-for-humans",
      "display_url" : "abookapart.com\/products\/git-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692745023251591168",
  "text" : "RT @abookapart: He had us at \u201CHumans, meet Git.\u201D Excited to announce @ddemaree\u2019s new book! https:\/\/t.co\/4YiZ4iDVTE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Demaree",
        "screen_name" : "ddemaree",
        "indices" : [ 53, 62 ],
        "id_str" : "16683",
        "id" : 16683
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/4YiZ4iDVTE",
        "expanded_url" : "http:\/\/abookapart.com\/products\/git-for-humans",
        "display_url" : "abookapart.com\/products\/git-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "692737974056935424",
    "text" : "He had us at \u201CHumans, meet Git.\u201D Excited to announce @ddemaree\u2019s new book! https:\/\/t.co\/4YiZ4iDVTE",
    "id" : 692737974056935424,
    "created_at" : "2016-01-28 15:56:18 +0000",
    "user" : {
      "name" : "A Book Apart",
      "screen_name" : "abookapart",
      "protected" : false,
      "id_str" : "106418338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675371036255240192\/_nuE4IC2_normal.png",
      "id" : 106418338,
      "verified" : false
    }
  },
  "id" : 692745023251591168,
  "created_at" : "2016-01-28 16:24:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Irvine",
      "screen_name" : "_valeriei",
      "indices" : [ 0, 10 ],
      "id_str" : "40426722",
      "id" : 40426722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692527567815983105",
  "geo" : { },
  "id_str" : "692528246945136640",
  "in_reply_to_user_id" : 40426722,
  "text" : "@_valeriei Thanks Valerie! I am looking for something similar for any web page (well, in this case Grav CMS). Will explore further &amp; share.",
  "id" : 692528246945136640,
  "in_reply_to_status_id" : 692527567815983105,
  "created_at" : "2016-01-28 02:02:55 +0000",
  "in_reply_to_screen_name" : "_valeriei",
  "in_reply_to_user_id_str" : "40426722",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Irvine",
      "screen_name" : "_valeriei",
      "indices" : [ 0, 10 ],
      "id_str" : "40426722",
      "id" : 40426722
    }, {
      "name" : "feedly",
      "screen_name" : "feedly",
      "indices" : [ 11, 18 ],
      "id_str" : "14485018",
      "id" : 14485018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692525468151627777",
  "geo" : { },
  "id_str" : "692526985248120833",
  "in_reply_to_user_id" : 40426722,
  "text" : "@_valeriei @feedly How are you planning to create the aggregated feed, Valerie? I'd like to learn more \uD83D\uDE00",
  "id" : 692526985248120833,
  "in_reply_to_status_id" : 692525468151627777,
  "created_at" : "2016-01-28 01:57:54 +0000",
  "in_reply_to_screen_name" : "_valeriei",
  "in_reply_to_user_id_str" : "40426722",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 0, 12 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692522636409204736",
  "geo" : { },
  "id_str" : "692522979570388992",
  "in_reply_to_user_id" : 6271482,
  "text" : "@grantpotter Emphasis on 'significant' I would say",
  "id" : 692522979570388992,
  "in_reply_to_status_id" : 692522636409204736,
  "created_at" : "2016-01-28 01:41:59 +0000",
  "in_reply_to_screen_name" : "grantpotter",
  "in_reply_to_user_id_str" : "6271482",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNIE-RCI\u00C9",
      "screen_name" : "CNIE_RCIE",
      "indices" : [ 3, 13 ],
      "id_str" : "244782783",
      "id" : 244782783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/pE75fGKGoL",
      "expanded_url" : "http:\/\/cnie-rcie.ca\/index.php\/2016\/01\/11\/conference-virtuelle-2016-virtual-conference\/",
      "display_url" : "cnie-rcie.ca\/index.php\/2016\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692467153623187456",
  "text" : "RT @CNIE_RCIE: Seeking presentation proposals for our upcoming Virtual Conference in March, hosted by Cape Breton University\n\nhttps:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/pE75fGKGoL",
        "expanded_url" : "http:\/\/cnie-rcie.ca\/index.php\/2016\/01\/11\/conference-virtuelle-2016-virtual-conference\/",
        "display_url" : "cnie-rcie.ca\/index.php\/2016\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "686607304914014209",
    "text" : "Seeking presentation proposals for our upcoming Virtual Conference in March, hosted by Cape Breton University\n\nhttps:\/\/t.co\/pE75fGKGoL",
    "id" : 686607304914014209,
    "created_at" : "2016-01-11 17:55:12 +0000",
    "user" : {
      "name" : "CNIE-RCI\u00C9",
      "screen_name" : "CNIE_RCIE",
      "protected" : false,
      "id_str" : "244782783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1232433922\/CNIE_RCIE_text_square_normal.jpg",
      "id" : 244782783,
      "verified" : false
    }
  },
  "id" : 692467153623187456,
  "created_at" : "2016-01-27 22:00:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "indices" : [ 101, 112 ],
      "id_str" : "27633854",
      "id" : 27633854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/f86rLCe8lB",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/flipping-the-lms-with-an-open-and-collaborative-platform#\/",
      "display_url" : "slides.com\/paulhibbitts\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692464604648202241",
  "text" : "Draft slides for my Flip it Good! presentation https:\/\/t.co\/f86rLCe8lB HT to the wonderfully awesome @JustStormy and DEVO for the title. \uD83C\uDFBC",
  "id" : 692464604648202241,
  "created_at" : "2016-01-27 21:50:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "indices" : [ 0, 11 ],
      "id_str" : "27633854",
      "id" : 27633854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692454756187529216",
  "geo" : { },
  "id_str" : "692457730594971648",
  "in_reply_to_user_id" : 27633854,
  "text" : "@JustStormy Of course, and the Devo reference is fully appreciated \uD83D\uDE09. Thanks!",
  "id" : 692457730594971648,
  "in_reply_to_status_id" : 692454756187529216,
  "created_at" : "2016-01-27 21:22:42 +0000",
  "in_reply_to_screen_name" : "JustStormy",
  "in_reply_to_user_id_str" : "27633854",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "indices" : [ 0, 11 ],
      "id_str" : "27633854",
      "id" : 27633854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/xnqOghgnvB",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1JIVWqmObf3gy-mOXvZFEm599xAw0F4ZC_0eKPTZUK1c\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1JI\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "684554713275170816",
  "geo" : { },
  "id_str" : "692444989335457792",
  "in_reply_to_user_id" : 27633854,
  "text" : "@JustStormy I really love your \"Flip it Good!\" line, would you mind if I used it for an upcoming presentation? https:\/\/t.co\/xnqOghgnvB",
  "id" : 692444989335457792,
  "in_reply_to_status_id" : 684554713275170816,
  "created_at" : "2016-01-27 20:32:05 +0000",
  "in_reply_to_screen_name" : "JustStormy",
  "in_reply_to_user_id_str" : "27633854",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/xnqOghgnvB",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1JIVWqmObf3gy-mOXvZFEm599xAw0F4ZC_0eKPTZUK1c\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1JI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692411177629016065",
  "text" : "Second iteration of a virtual presentation\/demo (~15 minutes long) about flipping your LMS. https:\/\/t.co\/xnqOghgnvB Comments? Suggestions?",
  "id" : 692411177629016065,
  "created_at" : "2016-01-27 18:17:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 25, 33 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692174350108213250",
  "text" : "Like so many things with @getgrav CMS, the theme and skeleton package release process is really nicely designed, and frankly, a joy to do. \uD83D\uDC4D",
  "id" : 692174350108213250,
  "created_at" : "2016-01-27 02:36:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/xnqOghxYn9",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1JIVWqmObf3gy-mOXvZFEm599xAw0F4ZC_0eKPTZUK1c\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1JI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692099823491649536",
  "text" : "Draft description of a virtual preso\/demo (15 minutes) about flipping your LMS - comments\/suggestions appreciated. https:\/\/t.co\/xnqOghxYn9",
  "id" : 692099823491649536,
  "created_at" : "2016-01-26 21:40:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/692094123990355969\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/uVHVt1nDZZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZrP8DJUMAAylTq.png",
      "id_str" : "692094123298271232",
      "id" : 692094123298271232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZrP8DJUMAAylTq.png",
      "sizes" : [ {
        "h" : 467,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 797,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1012,
        "resize" : "fit",
        "w" : 1300
      } ],
      "display_url" : "pic.twitter.com\/uVHVt1nDZZ"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692094123990355969",
  "text" : "It's finally official... next up is the official Grav Course Companion Skeleton Package! #GravEdu https:\/\/t.co\/uVHVt1nDZZ",
  "id" : 692094123990355969,
  "created_at" : "2016-01-26 21:17:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691824407761850368",
  "geo" : { },
  "id_str" : "692022510905331712",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Thanks so much Glen, I appreciate it! Looking forward to any comments you might have once you get a chance to check things out.",
  "id" : 692022510905331712,
  "in_reply_to_status_id" : 691824407761850368,
  "created_at" : "2016-01-26 16:33:18 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 66, 74 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/AfqoI4f6Ju",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/grav-course-companion-early-release-now-available",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691787433063636994",
  "text" : "Flip your LMS with this ready-to-run Course Companion, built with @getgrav. Early release now available at https:\/\/t.co\/AfqoI4f6Ju #GravEdu",
  "id" : 691787433063636994,
  "created_at" : "2016-01-26 00:59:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/AfqoI4f6Ju",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/grav-course-companion-early-release-now-available",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691786501865246721",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Finally got a complete early release of the Grav Course Companion out into the world https:\/\/t.co\/AfqoI4f6Ju \uD83D\uDE00",
  "id" : 691786501865246721,
  "created_at" : "2016-01-26 00:55:29 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/AfqoI4f6Ju",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/grav-course-companion-early-release-now-available",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/gra\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "691491869570830337",
  "geo" : { },
  "id_str" : "691777322458968065",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy Ok, I think it's reasonably presentable now https:\/\/t.co\/AfqoI4f6Ju \uD83D\uDE00 (old URL still works too...)",
  "id" : 691777322458968065,
  "in_reply_to_status_id" : 691491869570830337,
  "created_at" : "2016-01-26 00:19:00 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/oZR2IyxRcV",
      "expanded_url" : "https:\/\/twitter.com\/CNIE_RCIE\/status\/686607304914014209",
      "display_url" : "twitter.com\/CNIE_RCIE\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691751054623420416",
  "text" : "Looks interesting, thinking about submitting a proposal about flipping the LMS with an open &amp; collaborative platform https:\/\/t.co\/oZR2IyxRcV",
  "id" : 691751054623420416,
  "created_at" : "2016-01-25 22:34:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 66, 74 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/AfqoI3XvkU",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/grav-course-companion-early-release-now-available",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691696221040193536",
  "text" : "Flip your LMS with this ready-to-run Course Companion, built with @getgrav. Early release now available at https:\/\/t.co\/AfqoI3XvkU #GravEdu",
  "id" : 691696221040193536,
  "created_at" : "2016-01-25 18:56:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Porter",
      "screen_name" : "dendroglyph",
      "indices" : [ 0, 12 ],
      "id_str" : "15170764",
      "id" : 15170764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691680436683051008",
  "geo" : { },
  "id_str" : "691685025796849664",
  "in_reply_to_user_id" : 15170764,
  "text" : "@dendroglyph Thanks for sharing David, looks interesting!",
  "id" : 691685025796849664,
  "in_reply_to_status_id" : 691680436683051008,
  "created_at" : "2016-01-25 18:12:15 +0000",
  "in_reply_to_screen_name" : "dendroglyph",
  "in_reply_to_user_id_str" : "15170764",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691491869570830337",
  "geo" : { },
  "id_str" : "691655733151080448",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy Thanks very much Tim, greatly appreciated! I'll keep working on improving that introductory blog post too.",
  "id" : 691655733151080448,
  "in_reply_to_status_id" : 691491869570830337,
  "created_at" : "2016-01-25 16:15:51 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/HfYphykZLQ",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/grav-course-companion-prototype-now-available",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691449279496359936",
  "text" : "Sunday night sneak peek of my upcoming new post: Grav Course Companion Prototype Now Available https:\/\/t.co\/HfYphykZLQ #GravEdu",
  "id" : 691449279496359936,
  "created_at" : "2016-01-25 02:35:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/HfYphykZLQ",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/grav-course-companion-prototype-now-available",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/gra\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "691421482497527810",
  "geo" : { },
  "id_str" : "691445842494918657",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy Would this post be suitable to share with the contacts you have in mind? https:\/\/t.co\/HfYphykZLQ  Critical feedback welcome!",
  "id" : 691445842494918657,
  "in_reply_to_status_id" : 691421482497527810,
  "created_at" : "2016-01-25 02:21:49 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/QYEZCoTAvO",
      "expanded_url" : "http:\/\/hibbittsdesign.org",
      "display_url" : "hibbittsdesign.org"
    } ]
  },
  "in_reply_to_status_id_str" : "691421482497527810",
  "geo" : { },
  "id_str" : "691427307047682048",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy Thanks very much Tim! If I wrote up a brief overview\/intro post on https:\/\/t.co\/QYEZCoTAvO might you then consider sharing that?",
  "id" : 691427307047682048,
  "in_reply_to_status_id" : 691421482497527810,
  "created_at" : "2016-01-25 01:08:10 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/5YbJIEv9gr",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "691400945440296962",
  "geo" : { },
  "id_str" : "691408209882411013",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy I've also got this slide deck that has an overview of Grav in general and for educators specifically https:\/\/t.co\/5YbJIEv9gr",
  "id" : 691408209882411013,
  "in_reply_to_status_id" : 691400945440296962,
  "created_at" : "2016-01-24 23:52:17 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691400945440296962",
  "geo" : { },
  "id_str" : "691406988383641600",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy Thanks very much Tim! Almost ready I think... would you know anyone Web-savvy who might be interested in trying it out first?",
  "id" : 691406988383641600,
  "in_reply_to_status_id" : 691400945440296962,
  "created_at" : "2016-01-24 23:47:26 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/tlx2uoVSqK",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-bones-vanilla-course-companion-prototype",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    }, {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/eFQluerhfZ",
      "expanded_url" : "http:\/\/demo.hibbittsdesign.org\/grav-course-companion-bones-vanilla\/",
      "display_url" : "demo.hibbittsdesign.org\/grav-course-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691398765773590528",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy As a new Grav user, does this ReadMe &amp; demo seem approachable? Any suggestions? https:\/\/t.co\/tlx2uoVSqK https:\/\/t.co\/eFQluerhfZ",
  "id" : 691398765773590528,
  "created_at" : "2016-01-24 23:14:45 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/tlx2uoVSqK",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-bones-vanilla-course-companion-prototype",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    }, {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/tgSWQVXJs3",
      "expanded_url" : "http:\/\/demo.hibbittsdesign.org\/grav-course-companion-bones-vanilla",
      "display_url" : "demo.hibbittsdesign.org\/grav-course-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691396539533520896",
  "text" : "Just updated my Grav course companion prototype - download and install info: https:\/\/t.co\/tlx2uoVSqK, demo: https:\/\/t.co\/tgSWQVXJs3 #GravEdu",
  "id" : 691396539533520896,
  "created_at" : "2016-01-24 23:05:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691341598827888640",
  "geo" : { },
  "id_str" : "691342520589025280",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy Nice work! I am really impressed with Twig overall \uD83D\uDE00",
  "id" : 691342520589025280,
  "in_reply_to_status_id" : 691341598827888640,
  "created_at" : "2016-01-24 19:31:16 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691332862784708609",
  "geo" : { },
  "id_str" : "691341396528082944",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy Try this? Change '|replace(\u007B'\/user\/':''\u007D)' to '|replace(\u007B'\/user\/pages\/':''\u007D)'",
  "id" : 691341396528082944,
  "in_reply_to_status_id" : 691332862784708609,
  "created_at" : "2016-01-24 19:26:48 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691332862784708609",
  "geo" : { },
  "id_str" : "691338331192320000",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy You may also need to adjust the base URL in learn2.yaml but my hunch is the former",
  "id" : 691338331192320000,
  "in_reply_to_status_id" : 691332862784708609,
  "created_at" : "2016-01-24 19:14:37 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691332862784708609",
  "geo" : { },
  "id_str" : "691338093715042305",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy Find github_link.html.twig file in Learn2 \/templates\/partials to tweak that link",
  "id" : 691338093715042305,
  "in_reply_to_status_id" : 691332862784708609,
  "created_at" : "2016-01-24 19:13:40 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691297424652959744",
  "text" : "To me the phrase \"The Access Economy\" is more accurate (and less misleading) than the over-used and misapplied term \"The Sharing Economy\".",
  "id" : 691297424652959744,
  "created_at" : "2016-01-24 16:32:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691069551799304194",
  "geo" : { },
  "id_str" : "691071145307582466",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy For me the ecosystem (i.e. version control, GitHub Desktop, etc) that you can plug into is the sleeper feature of flat-file CMSs",
  "id" : 691071145307582466,
  "in_reply_to_status_id" : 691069551799304194,
  "created_at" : "2016-01-24 01:32:55 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/Qwo3MEart9",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-theme-course-companion-bones-vanilla\/blob\/master\/templates\/partials\/github_menu_link.html.twig",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    }, {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/L2HIRNAES8",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-theme-course-companion-bones-vanilla\/blob\/master\/templates\/partials\/github_page_link.html.twig",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "691069551799304194",
  "geo" : { },
  "id_str" : "691070745892384769",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy https:\/\/t.co\/Qwo3MEart9 https:\/\/t.co\/L2HIRNAES8",
  "id" : 691070745892384769,
  "in_reply_to_status_id" : 691069551799304194,
  "created_at" : "2016-01-24 01:31:19 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/S73N7PmkYQ",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-course-companion-bones-vanilla\/blob\/master\/config\/site.yaml",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/CW4e4knAsD",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-theme-course-companion-bones-vanilla\/blob\/master\/templates\/partials\/navigation.html.twig",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "691069551799304194",
  "geo" : { },
  "id_str" : "691070564916572161",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy You'll find it a breeze - in the RTFM skeleton and my course companion source https:\/\/t.co\/S73N7PmkYQ https:\/\/t.co\/CW4e4knAsD",
  "id" : 691070564916572161,
  "in_reply_to_status_id" : 691069551799304194,
  "created_at" : "2016-01-24 01:30:36 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691057890023608321",
  "geo" : { },
  "id_str" : "691065678225235970",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy Great to hear! So now that you've gotten to use Grav more what are your thoughts?",
  "id" : 691065678225235970,
  "in_reply_to_status_id" : 691057890023608321,
  "created_at" : "2016-01-24 01:11:11 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 3, 14 ],
      "id_str" : "185375498",
      "id" : 185375498
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 47, 62 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 72, 80 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/xqbQs8ov2J",
      "expanded_url" : "http:\/\/docs.reclaimhosting.com\/",
      "display_url" : "docs.reclaimhosting.com"
    } ]
  },
  "geo" : { },
  "id_str" : "691065300905660416",
  "text" : "RT @timmmmyboy: Spent the afternoon converting @ReclaimHosting to using @getgrav https:\/\/t.co\/xqbQs8ov2J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reclaim Hosting",
        "screen_name" : "ReclaimHosting",
        "indices" : [ 31, 46 ],
        "id_str" : "1602053274",
        "id" : 1602053274
      }, {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 56, 64 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/xqbQs8ov2J",
        "expanded_url" : "http:\/\/docs.reclaimhosting.com\/",
        "display_url" : "docs.reclaimhosting.com"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 38.22444165604353, -77.49017398217892 ]
    },
    "id_str" : "691057890023608321",
    "text" : "Spent the afternoon converting @ReclaimHosting to using @getgrav https:\/\/t.co\/xqbQs8ov2J",
    "id" : 691057890023608321,
    "created_at" : "2016-01-24 00:40:14 +0000",
    "user" : {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "protected" : false,
      "id_str" : "185375498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568657249413767168\/lnu_2bhL_normal.jpeg",
      "id" : 185375498,
      "verified" : false
    }
  },
  "id" : 691065300905660416,
  "created_at" : "2016-01-24 01:09:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arq Backup",
      "screen_name" : "arqbackup",
      "indices" : [ 0, 10 ],
      "id_str" : "76699143",
      "id" : 76699143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690951480447242242",
  "geo" : { },
  "id_str" : "690955968318836736",
  "in_reply_to_user_id" : 76699143,
  "text" : "@arqbackup Thanks for getting back to me, I've just sent an email to support.",
  "id" : 690955968318836736,
  "in_reply_to_status_id" : 690951480447242242,
  "created_at" : "2016-01-23 17:55:14 +0000",
  "in_reply_to_screen_name" : "arqbackup",
  "in_reply_to_user_id_str" : "76699143",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oer",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "open",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/95Il9ztOco",
      "expanded_url" : "http:\/\/ow.ly\/XnKRt",
      "display_url" : "ow.ly\/XnKRt"
    } ]
  },
  "geo" : { },
  "id_str" : "690686696287940608",
  "text" : "RT @BCcampus: The nominations for the 2016 Open Education Awards are now OPEN! Add your submissions before Jan 29: https:\/\/t.co\/95Il9ztOco \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oer",
        "indices" : [ 125, 129 ]
      }, {
        "text" : "open",
        "indices" : [ 130, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/95Il9ztOco",
        "expanded_url" : "http:\/\/ow.ly\/XnKRt",
        "display_url" : "ow.ly\/XnKRt"
      } ]
    },
    "geo" : { },
    "id_str" : "690685731321290752",
    "text" : "The nominations for the 2016 Open Education Awards are now OPEN! Add your submissions before Jan 29: https:\/\/t.co\/95Il9ztOco #oer #open",
    "id" : 690685731321290752,
    "created_at" : "2016-01-23 00:01:25 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 690686696287940608,
  "created_at" : "2016-01-23 00:05:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arq Backup",
      "screen_name" : "arqbackup",
      "indices" : [ 0, 10 ],
      "id_str" : "76699143",
      "id" : 76699143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690686614725525504",
  "in_reply_to_user_id" : 76699143,
  "text" : "@arqbackup If I backup files on a Mac using Arq can I then restore files on my Surface (with Arq)?",
  "id" : 690686614725525504,
  "created_at" : "2016-01-23 00:04:55 +0000",
  "in_reply_to_screen_name" : "arqbackup",
  "in_reply_to_user_id_str" : "76699143",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/4IVouwxzX1",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/grav-cms-install-checklists-and-steps",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690650743590678528",
  "text" : "Friday afternoon sneak peek at a new post on my blog: Grav CMS Install Checklist and Steps https:\/\/t.co\/4IVouwxzX1 #GravEdu",
  "id" : 690650743590678528,
  "created_at" : "2016-01-22 21:42:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 10, 22 ],
      "id_str" : "6271482",
      "id" : 6271482
    }, {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 23, 30 ],
      "id_str" : "745903",
      "id" : 745903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/nKjKzxOkie",
      "expanded_url" : "http:\/\/oet.tru.ca\/",
      "display_url" : "oet.tru.ca"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/dfLKEJcwXO",
      "expanded_url" : "https:\/\/twitter.com\/SandstormIO\/status\/690608730602364928",
      "display_url" : "twitter.com\/SandstormIO\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690628173663350784",
  "text" : "Thanks to @grantpotter @brlamb BC educators can try these apps, incl. Gogs for use w. Grav \uD83D\uDC4D https:\/\/t.co\/nKjKzxOkie https:\/\/t.co\/dfLKEJcwXO",
  "id" : 690628173663350784,
  "created_at" : "2016-01-22 20:12:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yummy Software",
      "screen_name" : "YummySoftware",
      "indices" : [ 0, 14 ],
      "id_str" : "81888130",
      "id" : 81888130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690444924202934272",
  "geo" : { },
  "id_str" : "690581571955331072",
  "in_reply_to_user_id" : 81888130,
  "text" : "@YummySoftware Thanks for the info, I missed that the first time round \uD83D\uDE00.",
  "id" : 690581571955331072,
  "in_reply_to_status_id" : 690444924202934272,
  "created_at" : "2016-01-22 17:07:31 +0000",
  "in_reply_to_screen_name" : "YummySoftware",
  "in_reply_to_user_id_str" : "81888130",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brent Toderian",
      "screen_name" : "BrentToderian",
      "indices" : [ 3, 17 ],
      "id_str" : "480196886",
      "id" : 480196886
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BrentToderian\/status\/690406763208785920\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/7joLkWmI9E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZTRR4fWAAA6oGo.jpg",
      "id_str" : "690406748046360576",
      "id" : 690406748046360576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZTRR4fWAAA6oGo.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7joLkWmI9E"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/BrentToderian\/status\/690406763208785920\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/7joLkWmI9E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZTRR4gXEAEhCFH.jpg",
      "id_str" : "690406748050624513",
      "id" : 690406748050624513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZTRR4gXEAEhCFH.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7joLkWmI9E"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/BrentToderian\/status\/690406763208785920\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/7joLkWmI9E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZTRR4nWcAEaXjT.jpg",
      "id_str" : "690406748079943681",
      "id" : 690406748079943681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZTRR4nWcAEaXjT.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7joLkWmI9E"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/BrentToderian\/status\/690406763208785920\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/7joLkWmI9E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZTRR6EWcAAiooS.jpg",
      "id_str" : "690406748470013952",
      "id" : 690406748470013952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZTRR6EWcAAiooS.jpg",
      "sizes" : [ {
        "h" : 201,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 606,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 606,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7joLkWmI9E"
    } ],
    "hashtags" : [ {
      "text" : "Dutch",
      "indices" : [ 82, 88 ]
    }, {
      "text" : "woonerfs",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690572147677265920",
  "text" : "RT @BrentToderian: I'm working on a project where we aspire to build Canada's 1st #Dutch-style #woonerfs (living lanes), like these: https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BrentToderian\/status\/690406763208785920\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/7joLkWmI9E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZTRR4fWAAA6oGo.jpg",
        "id_str" : "690406748046360576",
        "id" : 690406748046360576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZTRR4fWAAA6oGo.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7joLkWmI9E"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/BrentToderian\/status\/690406763208785920\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/7joLkWmI9E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZTRR4gXEAEhCFH.jpg",
        "id_str" : "690406748050624513",
        "id" : 690406748050624513,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZTRR4gXEAEhCFH.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7joLkWmI9E"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/BrentToderian\/status\/690406763208785920\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/7joLkWmI9E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZTRR4nWcAEaXjT.jpg",
        "id_str" : "690406748079943681",
        "id" : 690406748079943681,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZTRR4nWcAEaXjT.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7joLkWmI9E"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/BrentToderian\/status\/690406763208785920\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/7joLkWmI9E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZTRR6EWcAAiooS.jpg",
        "id_str" : "690406748470013952",
        "id" : 690406748470013952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZTRR6EWcAAiooS.jpg",
        "sizes" : [ {
          "h" : 201,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 606,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 606,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7joLkWmI9E"
      } ],
      "hashtags" : [ {
        "text" : "Dutch",
        "indices" : [ 63, 69 ]
      }, {
        "text" : "woonerfs",
        "indices" : [ 76, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690406763208785920",
    "text" : "I'm working on a project where we aspire to build Canada's 1st #Dutch-style #woonerfs (living lanes), like these: https:\/\/t.co\/7joLkWmI9E",
    "id" : 690406763208785920,
    "created_at" : "2016-01-22 05:32:54 +0000",
    "user" : {
      "name" : "Brent Toderian",
      "screen_name" : "BrentToderian",
      "protected" : false,
      "id_str" : "480196886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586276903641726976\/Fq1YytyN_normal.jpg",
      "id" : 480196886,
      "verified" : true
    }
  },
  "id" : 690572147677265920,
  "created_at" : "2016-01-22 16:30:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 44, 52 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/eFQlue9Gor",
      "expanded_url" : "http:\/\/demo.hibbittsdesign.org\/grav-course-companion-bones-vanilla\/",
      "display_url" : "demo.hibbittsdesign.org\/grav-course-co\u2026"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/lIciCFiPiS",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-course-companion-bones-vanilla",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690373963529195521",
  "text" : "Cool bananas. The demo site for my upcoming @getgrav Course Companion package is now live: https:\/\/t.co\/eFQlue9Gor https:\/\/t.co\/lIciCFiPiS",
  "id" : 690373963529195521,
  "created_at" : "2016-01-22 03:22:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Bovis",
      "screen_name" : "PaulBovis",
      "indices" : [ 3, 13 ],
      "id_str" : "1004346642",
      "id" : 1004346642
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 41, 49 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/fKLUn3VB19",
      "expanded_url" : "http:\/\/flip.it\/06C_i",
      "display_url" : "flip.it\/06C_i"
    } ]
  },
  "geo" : { },
  "id_str" : "690369013625548802",
  "text" : "RT @PaulBovis: For those getting started @getgrav  - Write Faster: Your Manual to Markdown, the Web's Simplest Plain-Text Syntax https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 26, 34 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/fKLUn3VB19",
        "expanded_url" : "http:\/\/flip.it\/06C_i",
        "display_url" : "flip.it\/06C_i"
      } ]
    },
    "geo" : { },
    "id_str" : "690368673865949188",
    "text" : "For those getting started @getgrav  - Write Faster: Your Manual to Markdown, the Web's Simplest Plain-Text Syntax https:\/\/t.co\/fKLUn3VB19",
    "id" : 690368673865949188,
    "created_at" : "2016-01-22 03:01:32 +0000",
    "user" : {
      "name" : "Paul Bovis",
      "screen_name" : "PaulBovis",
      "protected" : false,
      "id_str" : "1004346642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2979990175\/b7845035adfa0bf87f7521f05c550356_normal.jpeg",
      "id" : 1004346642,
      "verified" : false
    }
  },
  "id" : 690369013625548802,
  "created_at" : "2016-01-22 03:02:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yummy Software",
      "screen_name" : "YummySoftware",
      "indices" : [ 0, 14 ],
      "id_str" : "81888130",
      "id" : 81888130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690313084418686976",
  "in_reply_to_user_id" : 81888130,
  "text" : "@YummySoftware Trying out Yummy FTP Watcher, is there a trick to select which Local Folder to sync?",
  "id" : 690313084418686976,
  "created_at" : "2016-01-21 23:20:39 +0000",
  "in_reply_to_screen_name" : "YummySoftware",
  "in_reply_to_user_id_str" : "81888130",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 37, 45 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/8ajhIGRhj1",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/grav-course-companion-workflow-videos",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690237104836575232",
  "text" : "Web-savvy instructor? Here are a few @getgrav Course Companion workflow videos to check out: https:\/\/t.co\/8ajhIGRhj1 #GravEdu",
  "id" : 690237104836575232,
  "created_at" : "2016-01-21 18:18:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moodle News",
      "screen_name" : "moodlenews",
      "indices" : [ 122, 133 ],
      "id_str" : "96450920",
      "id" : 96450920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/mbh2kXZbma",
      "expanded_url" : "http:\/\/www.moodlenews.com\/2016\/check-out-the-new-editing-features-for-the-upcoming-moodlerooms-2-9-release-of-the-snap-theme\/",
      "display_url" : "moodlenews.com\/2016\/check-out\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690195736194072576",
  "text" : "Check Out The New Editing Features For The Upcoming Moodlerooms 2.9 Release Of The Snap Theme https:\/\/t.co\/mbh2kXZbma via @moodlenews",
  "id" : 690195736194072576,
  "created_at" : "2016-01-21 15:34:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 0, 14 ],
      "id_str" : "41268670",
      "id" : 41268670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689992437796835328",
  "geo" : { },
  "id_str" : "689995874383089665",
  "in_reply_to_user_id" : 41268670,
  "text" : "@_mike_collins Interesting! I've found Grav to be an easier method of site building with Markdown than Jekyll (never could get it going...).",
  "id" : 689995874383089665,
  "in_reply_to_status_id" : 689992437796835328,
  "created_at" : "2016-01-21 02:20:10 +0000",
  "in_reply_to_screen_name" : "_mike_collins",
  "in_reply_to_user_id_str" : "41268670",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/689991524495548417\/video\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/CWPrfZMNqC",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/689991224686678016\/pu\/img\/Hh8eMrxVBtSEQxdn.jpg",
      "id_str" : "689991224686678016",
      "id" : 689991224686678016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/689991224686678016\/pu\/img\/Hh8eMrxVBtSEQxdn.jpg",
      "sizes" : [ {
        "h" : 405,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/CWPrfZMNqC"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689991524495548417",
  "text" : "How fast can you install and get the Grav-based Course Companion up and running? Oh, in about 30 seconds... #GravEdu https:\/\/t.co\/CWPrfZMNqC",
  "id" : 689991524495548417,
  "created_at" : "2016-01-21 02:02:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 8, 22 ],
      "id_str" : "41268670",
      "id" : 41268670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689961542243217408",
  "geo" : { },
  "id_str" : "689965196748705792",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @_mike_collins I'd love to see more if possible! I am only using Grav + GitHub + GitHub Desktop at this point.",
  "id" : 689965196748705792,
  "in_reply_to_status_id" : 689961542243217408,
  "created_at" : "2016-01-21 00:18:16 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/689960947352539136\/video\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/HzByOuL4uk",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/689960616610676739\/pu\/img\/g6X_TqBh52aTLXbe.jpg",
      "id_str" : "689960616610676739",
      "id" : 689960616610676739,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/689960616610676739\/pu\/img\/g6X_TqBh52aTLXbe.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HzByOuL4uk"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689960947352539136",
  "text" : "What does the workflow for reviewing student changes of their Grav-based Course Companion look like? This! #GravEdu https:\/\/t.co\/HzByOuL4uk",
  "id" : 689960947352539136,
  "created_at" : "2016-01-21 00:01:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/689946012941549568\/video\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/0jwaiDvZH5",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/689945514498850816\/pu\/img\/BE4IjYk7yi_EG3Ss.jpg",
      "id_str" : "689945514498850816",
      "id" : 689945514498850816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/689945514498850816\/pu\/img\/BE4IjYk7yi_EG3Ss.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0jwaiDvZH5"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689946012941549568",
  "text" : "What does the workflow of a student's change of their Grav-based Course Companion look like? Here you go! #GravEdu https:\/\/t.co\/0jwaiDvZH5",
  "id" : 689946012941549568,
  "created_at" : "2016-01-20 23:02:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/689929660826693632\/video\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/XX9cxpxf3L",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/689928925426757633\/pu\/img\/DeGwaGvw1JAH3ts7.jpg",
      "id_str" : "689928925426757633",
      "id" : 689928925426757633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/689928925426757633\/pu\/img\/DeGwaGvw1JAH3ts7.jpg",
      "sizes" : [ {
        "h" : 372,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XX9cxpxf3L"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689929660826693632",
  "text" : "What does the workflow of an instructor updating their Grav-based Course Companion look like? Here you go! #GravEdu https:\/\/t.co\/XX9cxpxf3L",
  "id" : 689929660826693632,
  "created_at" : "2016-01-20 21:57:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 96, 104 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/NCIGT5jnAz",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/grav-cms-for-educators-outline",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689877330789928960",
  "text" : "Moving Beyond the LMS with Grav: Flipping Your LMS With the Open and Collaborative Web Platform @getgrav https:\/\/t.co\/NCIGT5jnAz #GravEdu",
  "id" : 689877330789928960,
  "created_at" : "2016-01-20 18:29:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 134, 142 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689874829143441408",
  "text" : "My goal? To create an (open source) course companion that delivers a better experience for BOTH students &amp; web-savvy instructors. #GravEdu",
  "id" : 689874829143441408,
  "created_at" : "2016-01-20 18:19:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689622898139467776",
  "geo" : { },
  "id_str" : "689638068005957633",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc No worries, sounds like you've got a full plate! If you get a chance at a later time I'd always welcome your comments. \uD83D\uDE00",
  "id" : 689638068005957633,
  "in_reply_to_status_id" : 689622898139467776,
  "created_at" : "2016-01-20 02:38:22 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/689585463133274112\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/j3D7HEVWtl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZHmUv6VIAAsKV6.png",
      "id_str" : "689585462097289216",
      "id" : 689585462097289216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZHmUv6VIAAsKV6.png",
      "sizes" : [ {
        "h" : 844,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/j3D7HEVWtl"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/689585463133274112\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/j3D7HEVWtl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZHmUwUUMAANN8Y.png",
      "id_str" : "689585462206279680",
      "id" : 689585462206279680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZHmUwUUMAANN8Y.png",
      "sizes" : [ {
        "h" : 425,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 844,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/j3D7HEVWtl"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/689585463133274112\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/j3D7HEVWtl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZHmUxXUgAAYXoE.png",
      "id_str" : "689585462487318528",
      "id" : 689585462487318528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZHmUxXUgAAYXoE.png",
      "sizes" : [ {
        "h" : 425,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 844,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/j3D7HEVWtl"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/689585463133274112\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/j3D7HEVWtl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZHmUkSVAAACUFI.png",
      "id_str" : "689585458976718848",
      "id" : 689585458976718848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZHmUkSVAAACUFI.png",
      "sizes" : [ {
        "h" : 635,
        "resize" : "fit",
        "w" : 1012
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 635,
        "resize" : "fit",
        "w" : 1012
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/j3D7HEVWtl"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689585463133274112",
  "text" : "Inching closer to 1st release of Grav Course Companion Website package (easily installed, just copy files) #GravEdu https:\/\/t.co\/j3D7HEVWtl",
  "id" : 689585463133274112,
  "created_at" : "2016-01-19 23:09:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689520834612858880",
  "text" : "Working on a set of 4 items to capture the benefits of my Grav course companion package:\nFlexibility | User Experience | Openness | Control",
  "id" : 689520834612858880,
  "created_at" : "2016-01-19 18:52:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/689251289809604608\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/6bCCKlh1rd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZC2ZU5VAAA-F_k.png",
      "id_str" : "689251289209831424",
      "id" : 689251289209831424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZC2ZU5VAAA-F_k.png",
      "sizes" : [ {
        "h" : 346,
        "resize" : "fit",
        "w" : 779
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 151,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 779
      } ],
      "display_url" : "pic.twitter.com\/6bCCKlh1rd"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689251289809604608",
  "text" : "So, what's this \"Moving Beyond the LMS with Grav\" workshop about? Is this of interest my fellow instructors?#GravEdu https:\/\/t.co\/6bCCKlh1rd",
  "id" : 689251289809604608,
  "created_at" : "2016-01-19 01:01:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rock Leung PhD",
      "screen_name" : "rockleung",
      "indices" : [ 3, 13 ],
      "id_str" : "257694380",
      "id" : 257694380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/6H6JBCKSry",
      "expanded_url" : "http:\/\/www.measuringu.com\/blog\/discovering-problems.php",
      "display_url" : "measuringu.com\/blog\/discoveri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689161633017413632",
  "text" : "RT @rockleung: 7 Methods for Discovering Usability Problems: MeasuringU https:\/\/t.co\/6H6JBCKSry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/6H6JBCKSry",
        "expanded_url" : "http:\/\/www.measuringu.com\/blog\/discovering-problems.php",
        "display_url" : "measuringu.com\/blog\/discoveri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "689161257920811008",
    "text" : "7 Methods for Discovering Usability Problems: MeasuringU https:\/\/t.co\/6H6JBCKSry",
    "id" : 689161257920811008,
    "created_at" : "2016-01-18 19:03:42 +0000",
    "user" : {
      "name" : "Rock Leung PhD",
      "screen_name" : "rockleung",
      "protected" : false,
      "id_str" : "257694380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661236757103448064\/n7gr8y1e_normal.jpg",
      "id" : 257694380,
      "verified" : false
    }
  },
  "id" : 689161633017413632,
  "created_at" : "2016-01-18 19:05:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/rbXdHZUmIi",
      "expanded_url" : "https:\/\/twitter.com\/uxpin\/status\/689155426638770176",
      "display_url" : "twitter.com\/uxpin\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689156596052541440",
  "text" : "I've been using empathy maps rather than personas for the past few years and have found them quite effective. https:\/\/t.co\/rbXdHZUmIi",
  "id" : 689156596052541440,
  "created_at" : "2016-01-18 18:45:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 71, 79 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/753qpCWnKz",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators#\/",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689147992134139908",
  "text" : "So stoked to now share the full slide deck!\nMoving Beyond the LMS with @getgrav\nCapabilities | Openness | Experience\nhttps:\/\/t.co\/753qpCWnKz",
  "id" : 689147992134139908,
  "created_at" : "2016-01-18 18:10:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris AdeB",
      "screen_name" : "adbchris",
      "indices" : [ 0, 9 ],
      "id_str" : "1094814522",
      "id" : 1094814522
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 10, 18 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 19, 34 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/JiN48IYPBJ",
      "expanded_url" : "http:\/\/learn.getgrav.org\/basics\/requirements",
      "display_url" : "learn.getgrav.org\/basics\/require\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "688669611752058880",
  "geo" : { },
  "id_str" : "688765046046900229",
  "in_reply_to_user_id" : 1094814522,
  "text" : "@adbchris @getgrav @ReclaimHosting You can manually install Grav on any Webserver running 5.5.9 or higher. https:\/\/t.co\/JiN48IYPBJ",
  "id" : 688765046046900229,
  "in_reply_to_status_id" : 688669611752058880,
  "created_at" : "2016-01-17 16:49:18 +0000",
  "in_reply_to_screen_name" : "adbchris",
  "in_reply_to_user_id_str" : "1094814522",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/753qpCWnKz",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators#\/",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688501476725899264",
  "text" : "My Grav CMS for Educators workshop is starting to come together. Now includes an open and collaborative workflow \uD83D\uDC4D https:\/\/t.co\/753qpCWnKz",
  "id" : 688501476725899264,
  "created_at" : "2016-01-16 23:21:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/753qpCWnKz",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators#\/",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688437642891902976",
  "text" : "Grav CMS for Educators workshop update #3:\n\u2713 An Open and Collaborative Workflow\n\u2713 Course Companion Package\nhttps:\/\/t.co\/753qpCWnKz\n#GravEdu",
  "id" : 688437642891902976,
  "created_at" : "2016-01-16 19:08:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/753qpCWnKz",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators#\/",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688126431251976194",
  "text" : "Grav CMS for Educators workshop update #2:\n\u2713 The Basics of Grav\n\u2713 Flipping your LMS with Grav\nhttps:\/\/t.co\/753qpCWnKz \u2026\n#GravEdu",
  "id" : 688126431251976194,
  "created_at" : "2016-01-15 22:31:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/753qpCWnKz",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators#\/",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688072970917392384",
  "text" : "Grav CMS for Educators workshop update #1:\n\u2713 What is a Modern Flat-file CMS?\n\u2713 Getting Grav Up and Running\nhttps:\/\/t.co\/753qpCWnKz\n#GravEdu",
  "id" : 688072970917392384,
  "created_at" : "2016-01-15 18:59:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687826604798513154",
  "geo" : { },
  "id_str" : "687828461100994560",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Thanks very much Clint, looking forward to hearing your thoughts!",
  "id" : 687828461100994560,
  "in_reply_to_status_id" : 687826604798513154,
  "created_at" : "2016-01-15 02:47:39 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/753qpCWnKz",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators#\/",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687817118939652096",
  "text" : "Not to (overly) repeat myself, but everything starts with a placeholder. https:\/\/t.co\/753qpCWnKz #GravEdu",
  "id" : 687817118939652096,
  "created_at" : "2016-01-15 02:02:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tracey",
      "screen_name" : "ryantracey",
      "indices" : [ 3, 14 ],
      "id_str" : "15490522",
      "id" : 15490522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lrnchat",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687814710146666498",
  "text" : "RT @ryantracey: I've heard 70:20:10 reframed as Experience, Exposure, Education. I like it. #lrnchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tchat.io\" rel=\"nofollow\"\u003Etchat.io\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lrnchat",
        "indices" : [ 76, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "687813508474486784",
    "text" : "I've heard 70:20:10 reframed as Experience, Exposure, Education. I like it. #lrnchat",
    "id" : 687813508474486784,
    "created_at" : "2016-01-15 01:48:14 +0000",
    "user" : {
      "name" : "Ryan Tracey",
      "screen_name" : "ryantracey",
      "protected" : false,
      "id_str" : "15490522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733253168239284224\/6Kgg8cPb_normal.jpg",
      "id" : 15490522,
      "verified" : false
    }
  },
  "id" : 687814710146666498,
  "created_at" : "2016-01-15 01:53:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 87, 95 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/NCIGT5jnAz",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/grav-cms-for-educators-outline",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687740335145930753",
  "text" : "Grav CMS for Educators: Flipping Your LMS With the Open and Collaborative Web Platform @getgrav https:\/\/t.co\/NCIGT5jnAz #GravEdu",
  "id" : 687740335145930753,
  "created_at" : "2016-01-14 20:57:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "indices" : [ 29, 43 ],
      "id_str" : "3296136369",
      "id" : 3296136369
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/687721888278134784\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/D3wPhcpB7o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYtHab0UwAABVj3.png",
      "id_str" : "687721887573524480",
      "id" : 687721887573524480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYtHab0UwAABVj3.png",
      "sizes" : [ {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/D3wPhcpB7o"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687721888278134784",
  "text" : "Super pleased w. open source @RocketChatApp livechat beta on my CMPT 363 test site. Lots of potential for educators! https:\/\/t.co\/D3wPhcpB7o",
  "id" : 687721888278134784,
  "created_at" : "2016-01-14 19:44:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687698472334680064",
  "geo" : { },
  "id_str" : "687699296657870848",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro facepalm x 2 \uD83D\uDE09",
  "id" : 687699296657870848,
  "in_reply_to_status_id" : 687698472334680064,
  "created_at" : "2016-01-14 18:14:23 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/TcYeCT7bgi",
      "expanded_url" : "https:\/\/community.canvaslms.com\/ideas\/4221#.VpfjzZ2Jet5.twitter",
      "display_url" : "community.canvaslms.com\/ideas\/4221#.Vp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687697712959991808",
  "text" : "Allow designers to designate links opening in Browser for mobile app | Canvas Community #CanvasLMS https:\/\/t.co\/TcYeCT7bgi",
  "id" : 687697712959991808,
  "created_at" : "2016-01-14 18:08:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 136, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/JfnoOeBEcH",
      "expanded_url" : "https:\/\/workflowy.com\/s\/VkrEHlv9rC",
      "display_url" : "workflowy.com\/s\/VkrEHlv9rC"
    } ]
  },
  "geo" : { },
  "id_str" : "687693784415506432",
  "text" : "'Grav CMS for Educators: Flipping Your LMS With an Open &amp; Collaborative Platform' outline. Ebook? Workshop? https:\/\/t.co\/JfnoOeBEcH #GravEdu",
  "id" : 687693784415506432,
  "created_at" : "2016-01-14 17:52:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "indices" : [ 3, 15 ],
      "id_str" : "730373",
      "id" : 730373
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/scottjenson\/status\/683771717022396416\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/nhaUUGP0ic",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CX0-wOZUMAAYXTw.png",
      "id_str" : "683771716649103360",
      "id" : 683771716649103360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX0-wOZUMAAYXTw.png",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 736
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 736
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nhaUUGP0ic"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/YfH2Cg7gTq",
      "expanded_url" : "https:\/\/jenson.org\/small\/",
      "display_url" : "jenson.org\/small\/"
    } ]
  },
  "geo" : { },
  "id_str" : "687652699769147393",
  "text" : "RT @scottjenson: My latest blog post: Small is Beautiful: Why Desktop UX still has something to teach Mobile https:\/\/t.co\/YfH2Cg7gTq https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/scottjenson\/status\/683771717022396416\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/nhaUUGP0ic",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX0-wOZUMAAYXTw.png",
        "id_str" : "683771716649103360",
        "id" : 683771716649103360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX0-wOZUMAAYXTw.png",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 611,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/nhaUUGP0ic"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/YfH2Cg7gTq",
        "expanded_url" : "https:\/\/jenson.org\/small\/",
        "display_url" : "jenson.org\/small\/"
      } ]
    },
    "geo" : { },
    "id_str" : "683771717022396416",
    "text" : "My latest blog post: Small is Beautiful: Why Desktop UX still has something to teach Mobile https:\/\/t.co\/YfH2Cg7gTq https:\/\/t.co\/nhaUUGP0ic",
    "id" : 683771717022396416,
    "created_at" : "2016-01-03 22:07:35 +0000",
    "user" : {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "protected" : false,
      "id_str" : "730373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576892785149628416\/FiovXOSs_normal.jpeg",
      "id" : 730373,
      "verified" : true
    }
  },
  "id" : 687652699769147393,
  "created_at" : "2016-01-14 15:09:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687484873276129280",
  "geo" : { },
  "id_str" : "687486922390769664",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Thanks for taking a look Christina, whenever convenient please feel free to share any candid thoughts you may have. Cheers!",
  "id" : 687486922390769664,
  "in_reply_to_status_id" : 687484873276129280,
  "created_at" : "2016-01-14 04:10:29 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687437341942624256",
  "geo" : { },
  "id_str" : "687438681846722560",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv I think I next need to create a single guide with all steps... basically a combination of the two you see there already.",
  "id" : 687438681846722560,
  "in_reply_to_status_id" : 687437341942624256,
  "created_at" : "2016-01-14 00:58:48 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/WrMHEkvIfl",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/running-grav-locally-with-mamp",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/run\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/X6esyeQUM5",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/using-grav-with-github-and-deploy",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/usi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "687435983994929152",
  "geo" : { },
  "id_str" : "687437087591694336",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv Thank you very much for taking a look! Also working on some step-by-step guides https:\/\/t.co\/WrMHEkvIfl  https:\/\/t.co\/X6esyeQUM5",
  "id" : 687437087591694336,
  "in_reply_to_status_id" : 687435983994929152,
  "created_at" : "2016-01-14 00:52:28 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/32Kh7b8p72",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/prototypes\/bones-vanilla-course-companion\/",
      "display_url" : "hibbittsdesign.com\/prototypes\/bon\u2026"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/tlx2uoEhzc",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-bones-vanilla-course-companion-prototype",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687427109644550144",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv HNY Lynda! Any thoughts on this early prototype Grav CMS course companion+docs? https:\/\/t.co\/32Kh7b8p72 https:\/\/t.co\/tlx2uoEhzc",
  "id" : 687427109644550144,
  "created_at" : "2016-01-14 00:12:49 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 0, 8 ],
      "id_str" : "5690792",
      "id" : 5690792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/32Kh7b8p72",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/prototypes\/bones-vanilla-course-companion\/",
      "display_url" : "hibbittsdesign.com\/prototypes\/bon\u2026"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/tlx2uoEhzc",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-bones-vanilla-course-companion-prototype",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687426633632985090",
  "in_reply_to_user_id" : 5690792,
  "text" : "@draggin HNY Mr. Toal! Any thoughts on this early prototype Grav CMS course companion+docs? https:\/\/t.co\/32Kh7b8p72 https:\/\/t.co\/tlx2uoEhzc",
  "id" : 687426633632985090,
  "created_at" : "2016-01-14 00:10:55 +0000",
  "in_reply_to_screen_name" : "draggin",
  "in_reply_to_user_id_str" : "5690792",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/32Kh7b8p72",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/prototypes\/bones-vanilla-course-companion\/",
      "display_url" : "hibbittsdesign.com\/prototypes\/bon\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/tlx2uoEhzc",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-bones-vanilla-course-companion-prototype",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687425014346420225",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde HNY Clint! Any thoughts on this early prototype Grav CMS course companion+docs?https:\/\/t.co\/32Kh7b8p72 https:\/\/t.co\/tlx2uoEhzc",
  "id" : 687425014346420225,
  "created_at" : "2016-01-14 00:04:29 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/32Kh7b8p72",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/prototypes\/bones-vanilla-course-companion\/",
      "display_url" : "hibbittsdesign.com\/prototypes\/bon\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/tlx2uoEhzc",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-bones-vanilla-course-companion-prototype",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687422733328723968",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc HNY Christina! Any thoughts on this prototype Grav CMS course companion+docs? https:\/\/t.co\/32Kh7b8p72 https:\/\/t.co\/tlx2uoEhzc",
  "id" : 687422733328723968,
  "created_at" : "2016-01-13 23:55:25 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 0, 7 ],
      "id_str" : "745903",
      "id" : 745903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/32Kh7b8p72",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/prototypes\/bones-vanilla-course-companion\/",
      "display_url" : "hibbittsdesign.com\/prototypes\/bon\u2026"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/tlx2uoEhzc",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-bones-vanilla-course-companion-prototype",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687421835428913152",
  "in_reply_to_user_id" : 745903,
  "text" : "@brlamb HNY Brian! Any thoughts on this early prototype Grav CMS course companion + docs? https:\/\/t.co\/32Kh7b8p72 https:\/\/t.co\/tlx2uoEhzc",
  "id" : 687421835428913152,
  "created_at" : "2016-01-13 23:51:51 +0000",
  "in_reply_to_screen_name" : "brlamb",
  "in_reply_to_user_id_str" : "745903",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenna Clarke Gray",
      "screen_name" : "brennacgray",
      "indices" : [ 0, 12 ],
      "id_str" : "14109848",
      "id" : 14109848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687420114212401153",
  "geo" : { },
  "id_str" : "687421181696294914",
  "in_reply_to_user_id" : 14109848,
  "text" : "@brennacgray I think next is a complete tutorial iand see how that looks. Maybe a local workshop too? What do you prefer re: tutorials?",
  "id" : 687421181696294914,
  "in_reply_to_status_id" : 687420114212401153,
  "created_at" : "2016-01-13 23:49:16 +0000",
  "in_reply_to_screen_name" : "brennacgray",
  "in_reply_to_user_id_str" : "14109848",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenna Clarke Gray",
      "screen_name" : "brennacgray",
      "indices" : [ 0, 12 ],
      "id_str" : "14109848",
      "id" : 14109848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687420114212401153",
  "geo" : { },
  "id_str" : "687420737146253312",
  "in_reply_to_user_id" : 14109848,
  "text" : "@brennacgray Sounds promising \uD83D\uDE00 As an instructor I found the most benefit with local copy + GitHub for student collab + auto-deploy to FTP.",
  "id" : 687420737146253312,
  "in_reply_to_status_id" : 687420114212401153,
  "created_at" : "2016-01-13 23:47:30 +0000",
  "in_reply_to_screen_name" : "brennacgray",
  "in_reply_to_user_id_str" : "14109848",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenna Clarke Gray",
      "screen_name" : "brennacgray",
      "indices" : [ 0, 12 ],
      "id_str" : "14109848",
      "id" : 14109848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/X6esyezjUx",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/using-grav-with-github-and-deploy",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/usi\u2026"
    }, {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/WrMHEke7nN",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/running-grav-locally-with-mamp",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/run\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "687416751101972480",
  "geo" : { },
  "id_str" : "687419393798705154",
  "in_reply_to_user_id" : 14109848,
  "text" : "@brennacgray Do these step-by-step tutorials look reasonable? https:\/\/t.co\/X6esyezjUx https:\/\/t.co\/WrMHEke7nN",
  "id" : 687419393798705154,
  "in_reply_to_status_id" : 687416751101972480,
  "created_at" : "2016-01-13 23:42:09 +0000",
  "in_reply_to_screen_name" : "brennacgray",
  "in_reply_to_user_id_str" : "14109848",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenna Clarke Gray",
      "screen_name" : "brennacgray",
      "indices" : [ 0, 12 ],
      "id_str" : "14109848",
      "id" : 14109848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687416751101972480",
  "geo" : { },
  "id_str" : "687419020379828225",
  "in_reply_to_user_id" : 14109848,
  "text" : "@brennacgray Thanks very much for the feedback. Works best for students\/instructors w. Grav site open\/public with links to LMS elements.",
  "id" : 687419020379828225,
  "in_reply_to_status_id" : 687416751101972480,
  "created_at" : "2016-01-13 23:40:40 +0000",
  "in_reply_to_screen_name" : "brennacgray",
  "in_reply_to_user_id_str" : "14109848",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenna Clarke Gray",
      "screen_name" : "brennacgray",
      "indices" : [ 0, 12 ],
      "id_str" : "14109848",
      "id" : 14109848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687414261547708416",
  "geo" : { },
  "id_str" : "687415893752721408",
  "in_reply_to_user_id" : 14109848,
  "text" : "@brennacgray Those comments truly warm my heart \uD83D\uDE00 Thank you. Does the format you see seem suitable for your needs? I can take the truth.",
  "id" : 687415893752721408,
  "in_reply_to_status_id" : 687414261547708416,
  "created_at" : "2016-01-13 23:28:15 +0000",
  "in_reply_to_screen_name" : "brennacgray",
  "in_reply_to_user_id_str" : "14109848",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenna Clarke Gray",
      "screen_name" : "brennacgray",
      "indices" : [ 0, 12 ],
      "id_str" : "14109848",
      "id" : 14109848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/32Kh7b8p72",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/prototypes\/bones-vanilla-course-companion\/",
      "display_url" : "hibbittsdesign.com\/prototypes\/bon\u2026"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/tlx2uoEhzc",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-bones-vanilla-course-companion-prototype",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687412926077120513",
  "in_reply_to_user_id" : 14109848,
  "text" : "@brennacgray HNY! Any thoughts on this early prototype Grav CMS course companion + docs? https:\/\/t.co\/32Kh7b8p72 https:\/\/t.co\/tlx2uoEhzc",
  "id" : 687412926077120513,
  "created_at" : "2016-01-13 23:16:27 +0000",
  "in_reply_to_screen_name" : "brennacgray",
  "in_reply_to_user_id_str" : "14109848",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 0, 13 ],
      "id_str" : "91939908",
      "id" : 91939908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/U5l2WY2g65",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/prototypes\/bones-vanilla-course-companion\/",
      "display_url" : "hibbittsdesign.org\/prototypes\/bon\u2026"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/tlx2uoEhzc",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-bones-vanilla-course-companion-prototype",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687411068390510592",
  "in_reply_to_user_id" : 91939908,
  "text" : "@davidnwright HNY! Any thoughts on this early prototype Grav CMS course companion + docs? https:\/\/t.co\/U5l2WY2g65 https:\/\/t.co\/tlx2uoEhzc",
  "id" : 687411068390510592,
  "created_at" : "2016-01-13 23:09:04 +0000",
  "in_reply_to_screen_name" : "davidnwright",
  "in_reply_to_user_id_str" : "91939908",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "roadmap",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/oGXejrVZ5M",
      "expanded_url" : "http:\/\/getgrav.org\/blog\/plans-for-2016",
      "display_url" : "getgrav.org\/blog\/plans-for\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687369858648944640",
  "text" : "RT @getgrav: Want to see what we have planned for 2016? Check out all the details! https:\/\/t.co\/oGXejrVZ5M #roadmap",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "roadmap",
        "indices" : [ 94, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/oGXejrVZ5M",
        "expanded_url" : "http:\/\/getgrav.org\/blog\/plans-for-2016",
        "display_url" : "getgrav.org\/blog\/plans-for\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "687363599514218496",
    "text" : "Want to see what we have planned for 2016? Check out all the details! https:\/\/t.co\/oGXejrVZ5M #roadmap",
    "id" : 687363599514218496,
    "created_at" : "2016-01-13 20:00:27 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 687369858648944640,
  "created_at" : "2016-01-13 20:25:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 3, 14 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BCTECH",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687341993601531904",
  "text" : "RT @sparkandco: I'll be at #BCTECH Summit Mon\/Tues - if you want to talk about training for your product or company, get in touch.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BCTECH",
        "indices" : [ 11, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "687315900500840449",
    "text" : "I'll be at #BCTECH Summit Mon\/Tues - if you want to talk about training for your product or company, get in touch.",
    "id" : 687315900500840449,
    "created_at" : "2016-01-13 16:50:55 +0000",
    "user" : {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "protected" : false,
      "id_str" : "47105948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656831720809889792\/aQbeijGD_normal.png",
      "id" : 47105948,
      "verified" : false
    }
  },
  "id" : 687341993601531904,
  "created_at" : "2016-01-13 18:34:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/x1RW34Wokq",
      "expanded_url" : "https:\/\/gitter.im\/hibbitts-design\/grav-skeleton-bones-vanilla-course-companion-prototype",
      "display_url" : "gitter.im\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687337306089328642",
  "text" : "Join the chat room on Gitter for hibbitts-design\/grav-skeleton-bones-vanilla-course-companion-prototype: https:\/\/t.co\/x1RW34Wokq #GravEdu",
  "id" : 687337306089328642,
  "created_at" : "2016-01-13 18:15:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 31, 39 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/tlx2uoVSqK",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-bones-vanilla-course-companion-prototype",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687336298147778560",
  "text" : "Prototype course companion for @getgrav to support a flipped-LMS approach available for the adventurous at https:\/\/t.co\/tlx2uoVSqK #GravEdu",
  "id" : 687336298147778560,
  "created_at" : "2016-01-13 18:11:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/687100257587466240\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/VLXWahdmJ8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYkSCxNUQAA2BRn.png",
      "id_str" : "687100256928940032",
      "id" : 687100256928940032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYkSCxNUQAA2BRn.png",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 843,
        "resize" : "fit",
        "w" : 1192
      } ],
      "display_url" : "pic.twitter.com\/VLXWahdmJ8"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/tlx2uoVSqK",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-bones-vanilla-course-companion-prototype",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687100257587466240",
  "text" : "Tuesday night course companion sneak peek. If your adventurous, download package at https:\/\/t.co\/tlx2uoVSqK #GravEdu https:\/\/t.co\/VLXWahdmJ8",
  "id" : 687100257587466240,
  "created_at" : "2016-01-13 02:34:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687036482184298496",
  "geo" : { },
  "id_str" : "687066902556901378",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Actually, if you were to throw caution to the wind you could even download the entire skeleton and see if it works \uD83D\uDE00",
  "id" : 687066902556901378,
  "in_reply_to_status_id" : 687036482184298496,
  "created_at" : "2016-01-13 00:21:29 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/tlx2uoVSqK",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-bones-vanilla-course-companion-prototype",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "687036482184298496",
  "geo" : { },
  "id_str" : "687064365279744000",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Template readme taking shape now... https:\/\/t.co\/tlx2uoVSqK",
  "id" : 687064365279744000,
  "in_reply_to_status_id" : 687036482184298496,
  "created_at" : "2016-01-13 00:11:24 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687036482184298496",
  "geo" : { },
  "id_str" : "687039825107496960",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Awesome, thanks! Hope to have an initial alpha with some documentation by end of this week...",
  "id" : 687039825107496960,
  "in_reply_to_status_id" : 687036482184298496,
  "created_at" : "2016-01-12 22:33:53 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 6, 14 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/687032243240321024\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/6KEME3PYxc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYjUL0DVAAE1sye.png",
      "id_str" : "687032242590253057",
      "id" : 687032242590253057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYjUL0DVAAE1sye.png",
      "sizes" : [ {
        "h" : 814,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 947,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6KEME3PYxc"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/687032243240321024\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/6KEME3PYxc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYjULnlUQAAR6h9.png",
      "id_str" : "687032239243149312",
      "id" : 687032239243149312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYjULnlUQAAR6h9.png",
      "sizes" : [ {
        "h" : 406,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1341,
        "resize" : "fit",
        "w" : 1122
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6KEME3PYxc"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687032243240321024",
  "text" : "Using @getgrav as a flipped-LMS you can have a course on your own desktop AND on GitHub for student collab. #GravEdu https:\/\/t.co\/6KEME3PYxc",
  "id" : 687032243240321024,
  "created_at" : "2016-01-12 22:03:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 0, 15 ],
      "id_str" : "1122631",
      "id" : 1122631
    }, {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 16, 32 ],
      "id_str" : "17349291",
      "id" : 17349291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686754167713472512",
  "geo" : { },
  "id_str" : "686771438523531264",
  "in_reply_to_user_id" : 1122631,
  "text" : "@MalloryOConnor @HabaneroConsult That's fantastic Mallory, congratulations!",
  "id" : 686771438523531264,
  "in_reply_to_status_id" : 686754167713472512,
  "created_at" : "2016-01-12 04:47:25 +0000",
  "in_reply_to_screen_name" : "MalloryOConnor",
  "in_reply_to_user_id_str" : "1122631",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 3, 14 ],
      "id_str" : "185375498",
      "id" : 185375498
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 67, 82 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/p5vZ92splM",
      "expanded_url" : "https:\/\/blog.timowens.io\/get-your-grav-on\/",
      "display_url" : "blog.timowens.io\/get-your-grav-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686770058320711680",
  "text" : "RT @timmmmyboy: New Post: Get Your Grav On https:\/\/t.co\/p5vZ92splM @hibbittsdesign",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 51, 66 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/p5vZ92splM",
        "expanded_url" : "https:\/\/blog.timowens.io\/get-your-grav-on\/",
        "display_url" : "blog.timowens.io\/get-your-grav-\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 38.22459264470472, -77.49031643147431 ]
    },
    "id_str" : "686764873779404800",
    "text" : "New Post: Get Your Grav On https:\/\/t.co\/p5vZ92splM @hibbittsdesign",
    "id" : 686764873779404800,
    "created_at" : "2016-01-12 04:21:20 +0000",
    "user" : {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "protected" : false,
      "id_str" : "185375498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568657249413767168\/lnu_2bhL_normal.jpeg",
      "id" : 185375498,
      "verified" : false
    }
  },
  "id" : 686770058320711680,
  "created_at" : "2016-01-12 04:41:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 3, 15 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AaronSwartz",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/0jxXonQ79i",
      "expanded_url" : "https:\/\/medium.com\/the-coffeelicious\/how-to-honor-aaron-swartz-33a2ae09598a#.nfe4o28oa",
      "display_url" : "medium.com\/the-coffeelici\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686641716669988864",
  "text" : "RT @grantpotter: How to honor Aaron Swartz\u2019s life #AaronSwartz https:\/\/t.co\/0jxXonQ79i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/known.networkeffects.ca\" rel=\"nofollow\"\u003Eknown-twitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AaronSwartz",
        "indices" : [ 33, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/0jxXonQ79i",
        "expanded_url" : "https:\/\/medium.com\/the-coffeelicious\/how-to-honor-aaron-swartz-33a2ae09598a#.nfe4o28oa",
        "display_url" : "medium.com\/the-coffeelici\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "686641233092034560",
    "text" : "How to honor Aaron Swartz\u2019s life #AaronSwartz https:\/\/t.co\/0jxXonQ79i",
    "id" : 686641233092034560,
    "created_at" : "2016-01-11 20:10:01 +0000",
    "user" : {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "protected" : false,
      "id_str" : "6271482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639833921228640256\/S63CDenk_normal.jpg",
      "id" : 6271482,
      "verified" : false
    }
  },
  "id" : 686641716669988864,
  "created_at" : "2016-01-11 20:11:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/U5l2WYjQXD",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/prototypes\/bones-vanilla-course-companion\/",
      "display_url" : "hibbittsdesign.org\/prototypes\/bon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686634167208022016",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Happy New Year! Getting close to a GravCMS course companion template alpha - any interest trying it out? https:\/\/t.co\/U5l2WYjQXD",
  "id" : 686634167208022016,
  "created_at" : "2016-01-11 19:41:57 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686622550449758208",
  "text" : "A core part of a flipped-LMS approach is to work with the LMS and not against it, while still improving the student &amp; instructor experience.",
  "id" : 686622550449758208,
  "created_at" : "2016-01-11 18:55:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 24, 32 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/aQ9FgTIALn",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/prototypes\/bones-vanilla-course-companion\/blog\/week-03\/",
      "display_url" : "hibbittsdesign.org\/prototypes\/bon\u2026"
    }, {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Tenp8QwQup",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/prototypes\/bones-vanilla-course-companion\/blog\/week-03\/onlydisplaypagecontent:true",
      "display_url" : "hibbittsdesign.org\/prototypes\/bon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686619858046332928",
  "text" : "For instructors needing @getgrav pages in an LMS, a nav chrome flag can be set. https:\/\/t.co\/aQ9FgTIALn vs. https:\/\/t.co\/Tenp8QwQup #GravEdu",
  "id" : 686619858046332928,
  "created_at" : "2016-01-11 18:45:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 80, 95 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 124, 132 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686605281090879488",
  "text" : "And let's not even start to talk about PHP versions on most university servers, @reclaimhosting has the new 7.0 release and @getgrav flies!",
  "id" : 686605281090879488,
  "created_at" : "2016-01-11 17:47:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 21, 36 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 55, 63 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/686599327502872576\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/SQ9ux4rWAD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYdKb87UoAA_GsC.png",
      "id_str" : "686599312269156352",
      "id" : 686599312269156352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYdKb87UoAA_GsC.png",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1139
      }, {
        "h" : 527,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 899,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 299,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SQ9ux4rWAD"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/686599327502872576\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/SQ9ux4rWAD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYdKcyfUQAAA-2u.png",
      "id_str" : "686599326647205888",
      "id" : 686599326647205888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYdKcyfUQAAA-2u.png",
      "sizes" : [ {
        "h" : 644,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1137,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2159,
        "resize" : "fit",
        "w" : 1139
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1941,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/SQ9ux4rWAD"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/686599327502872576\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/SQ9ux4rWAD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYdKcDOUEAIWJ56.png",
      "id_str" : "686599313959424002",
      "id" : 686599313959424002,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYdKcDOUEAIWJ56.png",
      "sizes" : [ {
        "h" : 656,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 1139
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/SQ9ux4rWAD"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/686599327502872576\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/SQ9ux4rWAD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYdKcXUUAAABEJY.png",
      "id_str" : "686599319353294848",
      "id" : 686599319353294848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYdKcXUUAAABEJY.png",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 758,
        "resize" : "fit",
        "w" : 1144
      } ],
      "display_url" : "pic.twitter.com\/SQ9ux4rWAD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686599327502872576",
  "text" : "In less than one day @reclaimhosting created the first @getgrav auto-install on the Web, WITH skeleton selection. \uD83D\uDCE3 https:\/\/t.co\/SQ9ux4rWAD",
  "id" : 686599327502872576,
  "created_at" : "2016-01-11 17:23:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 46, 54 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 78, 93 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686597658392170496",
  "text" : "After a frustrating 3 weeks of trying to host @getgrav at a local university, @reclaimhosting is a breath of fresh air - amazing experience!",
  "id" : 686597658392170496,
  "created_at" : "2016-01-11 17:16:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 12, 27 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/kCiTpDtNnq",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/my-dream-workflow-as-an-instructor",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/my-\u2026"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/GVhm1yLWxW",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/fli\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "686381175955451904",
  "geo" : { },
  "id_str" : "686383688163012609",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy @ReclaimHosting The workflow alone is a game changer to me re: standard LMSs https:\/\/t.co\/kCiTpDtNnq https:\/\/t.co\/GVhm1yLWxW",
  "id" : 686383688163012609,
  "in_reply_to_status_id" : 686381175955451904,
  "created_at" : "2016-01-11 03:06:38 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 12, 27 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/VTJbAs2YuX",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/prototypes\/bootstrap-course-companion",
      "display_url" : "hibbittsdesign.org\/prototypes\/boo\u2026"
    }, {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/Suvvt9ApMH",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/coursecompanionstarterkit\/",
      "display_url" : "hibbittsdesign.org\/coursecompanio\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "686381175955451904",
  "geo" : { },
  "id_str" : "686382726019022848",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy @ReclaimHosting Wow, that would be really great\uD83D\uDC4D Early example prototype https:\/\/t.co\/VTJbAs2YuX &amp; docs https:\/\/t.co\/Suvvt9ApMH",
  "id" : 686382726019022848,
  "in_reply_to_status_id" : 686381175955451904,
  "created_at" : "2016-01-11 03:02:48 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 12, 27 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686374064898895872",
  "geo" : { },
  "id_str" : "686379999285227521",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy @ReclaimHosting Awesome!! I am also working on a prototype Grav skeleton for instructors and lots more. \uD83D\uDE00",
  "id" : 686379999285227521,
  "in_reply_to_status_id" : 686374064898895872,
  "created_at" : "2016-01-11 02:51:58 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686369304422424576",
  "text" : "The word \"disruption\" is such an overused and meaningless word at this point, and seldom really true.",
  "id" : 686369304422424576,
  "created_at" : "2016-01-11 02:09:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Buxton",
      "screen_name" : "wasbuxton",
      "indices" : [ 3, 13 ],
      "id_str" : "57046779",
      "id" : 57046779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686284717516144640",
  "text" : "RT @wasbuxton: My take is that \"Learn early, learn often\" is a far more positive and effective alternative to, and superset of, \"Fail early\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "684732526250868736",
    "text" : "My take is that \"Learn early, learn often\" is a far more positive and effective alternative to, and superset of, \"Fail early, fail often\".",
    "id" : 684732526250868736,
    "created_at" : "2016-01-06 13:45:30 +0000",
    "user" : {
      "name" : "Bill Buxton",
      "screen_name" : "wasbuxton",
      "protected" : false,
      "id_str" : "57046779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1295268556\/Bill_TN_normal.jpg",
      "id" : 57046779,
      "verified" : false
    }
  },
  "id" : 686284717516144640,
  "created_at" : "2016-01-10 20:33:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Buxton",
      "screen_name" : "wasbuxton",
      "indices" : [ 3, 13 ],
      "id_str" : "57046779",
      "id" : 57046779
    }, {
      "name" : "albert shum",
      "screen_name" : "alshumdesign",
      "indices" : [ 30, 43 ],
      "id_str" : "2374870609",
      "id" : 2374870609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686284409939443713",
  "text" : "RT @wasbuxton: Post CES 1: as @alshumdesign says, design HAS to expand beyond architecture of individual \"buildings\" to urban design (commu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "albert shum",
        "screen_name" : "alshumdesign",
        "indices" : [ 15, 28 ],
        "id_str" : "2374870609",
        "id" : 2374870609
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "686204529226874884",
    "text" : "Post CES 1: as @alshumdesign says, design HAS to expand beyond architecture of individual \"buildings\" to urban design (communities) of tech.",
    "id" : 686204529226874884,
    "created_at" : "2016-01-10 15:14:43 +0000",
    "user" : {
      "name" : "Bill Buxton",
      "screen_name" : "wasbuxton",
      "protected" : false,
      "id_str" : "57046779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1295268556\/Bill_TN_normal.jpg",
      "id" : 57046779,
      "verified" : false
    }
  },
  "id" : 686284409939443713,
  "created_at" : "2016-01-10 20:32:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Groom",
      "screen_name" : "jimgroom",
      "indices" : [ 3, 12 ],
      "id_str" : "3362981",
      "id" : 3362981
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 68, 83 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jimgroom\/status\/686244334233120768\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/9QuFA1vEGo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYYHRJFWYAASEdx.png",
      "id_str" : "686243984298106880",
      "id" : 686243984298106880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYYHRJFWYAASEdx.png",
      "sizes" : [ {
        "h" : 266,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 892,
        "resize" : "fit",
        "w" : 1142
      } ],
      "display_url" : "pic.twitter.com\/9QuFA1vEGo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686275058403180544",
  "text" : "RT @jimgroom: Compiling list of institutions we're working with for @reclaimhosting's homepage. Been an awesome year! Thank you! https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reclaim Hosting",
        "screen_name" : "ReclaimHosting",
        "indices" : [ 54, 69 ],
        "id_str" : "1602053274",
        "id" : 1602053274
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jimgroom\/status\/686244334233120768\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/9QuFA1vEGo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYYHRJFWYAASEdx.png",
        "id_str" : "686243984298106880",
        "id" : 686243984298106880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYYHRJFWYAASEdx.png",
        "sizes" : [ {
          "h" : 266,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 469,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 892,
          "resize" : "fit",
          "w" : 1142
        } ],
        "display_url" : "pic.twitter.com\/9QuFA1vEGo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "686244334233120768",
    "text" : "Compiling list of institutions we're working with for @reclaimhosting's homepage. Been an awesome year! Thank you! https:\/\/t.co\/9QuFA1vEGo",
    "id" : 686244334233120768,
    "created_at" : "2016-01-10 17:52:53 +0000",
    "user" : {
      "name" : "Jim Groom",
      "screen_name" : "jimgroom",
      "protected" : false,
      "id_str" : "3362981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626944793302581248\/TxzPTAYL_normal.jpg",
      "id" : 3362981,
      "verified" : false
    }
  },
  "id" : 686275058403180544,
  "created_at" : "2016-01-10 19:54:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 0, 15 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/mDJ9E4VNAs",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/",
      "display_url" : "hibbittsdesign.org"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Q6kKV4cPSv",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-153\/",
      "display_url" : "paulhibbitts.net\/cmpt-363-153\/"
    } ]
  },
  "in_reply_to_status_id_str" : "685974760828866560",
  "geo" : { },
  "id_str" : "685976318664511488",
  "in_reply_to_user_id" : 1602053274,
  "text" : "@ReclaimHosting Thanks! Grav is full of potential for educators https:\/\/t.co\/mDJ9E4VNAs. I've got my site running https:\/\/t.co\/Q6kKV4cPSv \uD83D\uDC4D",
  "id" : 685976318664511488,
  "in_reply_to_status_id" : 685974760828866560,
  "created_at" : "2016-01-10 00:07:53 +0000",
  "in_reply_to_screen_name" : "ReclaimHosting",
  "in_reply_to_user_id_str" : "1602053274",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 11, 26 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685972754173014016",
  "text" : "Trying out @ReclaimHosting - looks very promising to help other instructors flip their LMS. FTP servers @ institutions appear problematic.",
  "id" : 685972754173014016,
  "created_at" : "2016-01-09 23:53:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 22, 30 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/685608028079403008\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/269xMdKmnM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYPE3dBUoAE4VUZ.png",
      "id_str" : "685608025252470785",
      "id" : 685608025252470785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYPE3dBUoAE4VUZ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 784,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 936,
        "resize" : "fit",
        "w" : 1222
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/269xMdKmnM"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/685608028079403008\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/269xMdKmnM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYPE3eIUwAAIXuN.png",
      "id_str" : "685608025550274560",
      "id" : 685608025550274560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYPE3eIUwAAIXuN.png",
      "sizes" : [ {
        "h" : 784,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 936,
        "resize" : "fit",
        "w" : 1222
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/269xMdKmnM"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685608028079403008",
  "text" : "Late Friday afternoon @getgrav course companion prototype w. collab GitHub editing, using Zurb Foundation. #GravEdu https:\/\/t.co\/269xMdKmnM",
  "id" : 685608028079403008,
  "created_at" : "2016-01-08 23:44:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/zHYKN1rRk8",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/grav-as-a-simple-open-publishing-tool",
      "display_url" : "hibbittsdesign.org\/blog\/grav-as-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685573020962836480",
  "text" : "Using Grav as a GitHub-powered Open Publishing Tool https:\/\/t.co\/zHYKN1rRk8 #GravEdu",
  "id" : 685573020962836480,
  "created_at" : "2016-01-08 21:25:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 5, 13 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/685509042362384385\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ZiZ7nc7Zep",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYNq1p-UAAAdsBO.png",
      "id_str" : "685509038323269632",
      "id" : 685509038323269632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYNq1p-UAAAdsBO.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 846,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 985,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZiZ7nc7Zep"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/685509042362384385\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ZiZ7nc7Zep",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYNq1ivUsAMR8SU.png",
      "id_str" : "685509036381351939",
      "id" : 685509036381351939,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYNq1ivUsAMR8SU.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 753,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 441,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 876,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZiZ7nc7Zep"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/685509042362384385\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ZiZ7nc7Zep",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYNq1wGUEAApG5U.png",
      "id_str" : "685509039967440896",
      "id" : 685509039967440896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYNq1wGUEAApG5U.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 846,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 985,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZiZ7nc7Zep"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/685509042362384385\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ZiZ7nc7Zep",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYNq12XUsAExmgW.png",
      "id_str" : "685509041649397761",
      "id" : 685509041649397761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYNq12XUsAExmgW.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 846,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 985,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZiZ7nc7Zep"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685509042362384385",
  "text" : "With @getgrav you can choose how to work with your content; Web admin, favorite desktop editor, or GitHub. #GravEdu https:\/\/t.co\/ZiZ7nc7Zep",
  "id" : 685509042362384385,
  "created_at" : "2016-01-08 17:11:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/QYEZCoTAvO",
      "expanded_url" : "http:\/\/hibbittsdesign.org",
      "display_url" : "hibbittsdesign.org"
    }, {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/ChDmQGRhJh",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/my-dream-workflow-as-an-instructor",
      "display_url" : "hibbittsdesign.org\/blog\/my-dream-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685230212666109952",
  "text" : "My first blog post on https:\/\/t.co\/QYEZCoTAvO - My Dream Workflow as an Instructor https:\/\/t.co\/ChDmQGRhJh #GravEdu",
  "id" : 685230212666109952,
  "created_at" : "2016-01-07 22:43:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stuart lamour",
      "screen_name" : "stuartlamour",
      "indices" : [ 3, 16 ],
      "id_str" : "8075672",
      "id" : 8075672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Moodle",
      "indices" : [ 99, 106 ]
    }, {
      "text" : "snapmoodletheme",
      "indices" : [ 113, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/n3UuyXtzCF",
      "expanded_url" : "http:\/\/snapmoodletheme.tumblr.com\/",
      "display_url" : "snapmoodletheme.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "685212147173818368",
  "text" : "RT @stuartlamour: https:\/\/t.co\/n3UuyXtzCF - a Tumblr showing some of the nice features of the Snap #Moodle Theme #snapmoodletheme",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Moodle",
        "indices" : [ 81, 88 ]
      }, {
        "text" : "snapmoodletheme",
        "indices" : [ 95, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/n3UuyXtzCF",
        "expanded_url" : "http:\/\/snapmoodletheme.tumblr.com\/",
        "display_url" : "snapmoodletheme.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "684410727227109376",
    "text" : "https:\/\/t.co\/n3UuyXtzCF - a Tumblr showing some of the nice features of the Snap #Moodle Theme #snapmoodletheme",
    "id" : 684410727227109376,
    "created_at" : "2016-01-05 16:26:47 +0000",
    "user" : {
      "name" : "stuart lamour",
      "screen_name" : "stuartlamour",
      "protected" : false,
      "id_str" : "8075672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684922682886995968\/GvEbcsPG_normal.jpg",
      "id" : 8075672,
      "verified" : false
    }
  },
  "id" : 685212147173818368,
  "created_at" : "2016-01-07 21:31:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/XIxaEWIW5C",
      "expanded_url" : "https:\/\/twitter.com\/stuartlamour\/status\/684761331849904128",
      "display_url" : "twitter.com\/stuartlamour\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685211976528564224",
  "text" : "If your institution is using Moodle you should really check out what Snap can bring to your Moodle courses. https:\/\/t.co\/XIxaEWIW5C",
  "id" : 685211976528564224,
  "created_at" : "2016-01-07 21:30:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaryTreseler",
      "screen_name" : "MaryTreseler",
      "indices" : [ 3, 16 ],
      "id_str" : "14208458",
      "id" : 14208458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uxdesign",
      "indices" : [ 116, 125 ]
    }, {
      "text" : "oreillydesign",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/gBTk4eWP1r",
      "expanded_url" : "https:\/\/www.oreilly.com\/topics\/design",
      "display_url" : "oreilly.com\/topics\/design"
    } ]
  },
  "geo" : { },
  "id_str" : "685202321983197184",
  "text" : "RT @MaryTreseler: Designers, plenty of new and free content just posted to our site https:\/\/t.co\/gBTk4eWP1r. Enjoy. #uxdesign #oreillydesign",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "uxdesign",
        "indices" : [ 98, 107 ]
      }, {
        "text" : "oreillydesign",
        "indices" : [ 108, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/gBTk4eWP1r",
        "expanded_url" : "https:\/\/www.oreilly.com\/topics\/design",
        "display_url" : "oreilly.com\/topics\/design"
      } ]
    },
    "geo" : { },
    "id_str" : "685113944592093186",
    "text" : "Designers, plenty of new and free content just posted to our site https:\/\/t.co\/gBTk4eWP1r. Enjoy. #uxdesign #oreillydesign",
    "id" : 685113944592093186,
    "created_at" : "2016-01-07 15:01:07 +0000",
    "user" : {
      "name" : "MaryTreseler",
      "screen_name" : "MaryTreseler",
      "protected" : false,
      "id_str" : "14208458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730352019219877894\/zdU7xoK-_normal.jpg",
      "id" : 14208458,
      "verified" : false
    }
  },
  "id" : 685202321983197184,
  "created_at" : "2016-01-07 20:52:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685194863730544640",
  "text" : "(2\/2) In particular, exploring feasibility of student-choice group projects (open source?) &amp; prototyping tool usage.",
  "id" : 685194863730544640,
  "created_at" : "2016-01-07 20:22:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/685194844860354560\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/YWh41e4cen",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYJNE44VAAAgniZ.jpg",
      "id_str" : "685194839697195008",
      "id" : 685194839697195008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYJNE44VAAAgniZ.jpg",
      "sizes" : [ {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1275,
        "resize" : "fit",
        "w" : 1650
      }, {
        "h" : 791,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YWh41e4cen"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/685194844860354560\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/YWh41e4cen",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYJNFKAUoAAxZSZ.jpg",
      "id_str" : "685194844294127616",
      "id" : 685194844294127616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYJNFKAUoAAxZSZ.jpg",
      "sizes" : [ {
        "h" : 1275,
        "resize" : "fit",
        "w" : 1650
      }, {
        "h" : 791,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YWh41e4cen"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/685194844860354560\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/YWh41e4cen",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYJNFIeUMAAc4CM.jpg",
      "id_str" : "685194843883057152",
      "id" : 685194843883057152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYJNFIeUMAAc4CM.jpg",
      "sizes" : [ {
        "h" : 1275,
        "resize" : "fit",
        "w" : 1650
      }, {
        "h" : 791,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YWh41e4cen"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/685194844860354560\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/YWh41e4cen",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYJNFI7UQAAyDMv.jpg",
      "id_str" : "685194844004696064",
      "id" : 685194844004696064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYJNFI7UQAAyDMv.jpg",
      "sizes" : [ {
        "h" : 1275,
        "resize" : "fit",
        "w" : 1650
      }, {
        "h" : 791,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YWh41e4cen"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 89, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685194844860354560",
  "text" : "(1\/2) Is it openness or transparency? Not sure, but already considering changes based on #SFU CMPT 363 course evals. https:\/\/t.co\/YWh41e4cen",
  "id" : 685194844860354560,
  "created_at" : "2016-01-07 20:22:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 3, 15 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/openroadies\/status\/677194760587636737\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/KrJdO17lP8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWXhC9OVEAANMbm.png",
      "id_str" : "677194759899779072",
      "id" : 677194759899779072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWXhC9OVEAANMbm.png",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 127,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 780
      } ],
      "display_url" : "pic.twitter.com\/KrJdO17lP8"
    } ],
    "hashtags" : [ {
      "text" : "hiring",
      "indices" : [ 78, 85 ]
    }, {
      "text" : "yvr",
      "indices" : [ 127, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/wU3k4faGLF",
      "expanded_url" : "https:\/\/www.openroad.ca\/about\/careers\/art-director\/",
      "display_url" : "openroad.ca\/about\/careers\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684972113241886721",
  "text" : "RT @openroadies: Want to help us make new digital experiences possible? We're #hiring an Art Director: https:\/\/t.co\/wU3k4faGLF #yvr https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/openroadies\/status\/677194760587636737\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/KrJdO17lP8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWXhC9OVEAANMbm.png",
        "id_str" : "677194759899779072",
        "id" : 677194759899779072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWXhC9OVEAANMbm.png",
        "sizes" : [ {
          "h" : 225,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 127,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 780
        } ],
        "display_url" : "pic.twitter.com\/KrJdO17lP8"
      } ],
      "hashtags" : [ {
        "text" : "hiring",
        "indices" : [ 61, 68 ]
      }, {
        "text" : "yvr",
        "indices" : [ 110, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/wU3k4faGLF",
        "expanded_url" : "https:\/\/www.openroad.ca\/about\/careers\/art-director\/",
        "display_url" : "openroad.ca\/about\/careers\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677194760587636737",
    "text" : "Want to help us make new digital experiences possible? We're #hiring an Art Director: https:\/\/t.co\/wU3k4faGLF #yvr https:\/\/t.co\/KrJdO17lP8",
    "id" : 677194760587636737,
    "created_at" : "2015-12-16 18:33:07 +0000",
    "user" : {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "protected" : false,
      "id_str" : "66913866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554783440747237376\/HA2Svg4h_normal.png",
      "id" : 66913866,
      "verified" : false
    }
  },
  "id" : 684972113241886721,
  "created_at" : "2016-01-07 05:37:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 16, 21 ]
    }, {
      "text" : "etugspringideas",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684909110144311297",
  "text" : "RT @etug: Hello #etug! What would you like to learn\/do\/talk about at the next Spring workshop? Let us know! Let's make it happen! #etugspri\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 6, 11 ]
      }, {
        "text" : "etugspringideas",
        "indices" : [ 120, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "684515782592565248",
    "text" : "Hello #etug! What would you like to learn\/do\/talk about at the next Spring workshop? Let us know! Let's make it happen! #etugspringideas",
    "id" : 684515782592565248,
    "created_at" : "2016-01-05 23:24:14 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 684909110144311297,
  "created_at" : "2016-01-07 01:27:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 9, 17 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/684894725187371008\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/0wJTOUJ5Uu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYE8HjCUAAAWd5W.png",
      "id_str" : "684894718698717184",
      "id" : 684894718698717184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYE8HjCUAAAWd5W.png",
      "sizes" : [ {
        "h" : 412,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 1076
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0wJTOUJ5Uu"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/684894725187371008\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/0wJTOUJ5Uu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYE8HzYUAAA9m93.png",
      "id_str" : "684894723085959168",
      "id" : 684894723085959168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYE8HzYUAAA9m93.png",
      "sizes" : [ {
        "h" : 412,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 1076
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0wJTOUJ5Uu"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684894725187371008",
  "text" : "By using @getgrav to build a course companion site, content and code are stored as simple (editable) files. #GravEdu https:\/\/t.co\/0wJTOUJ5Uu",
  "id" : 684894725187371008,
  "created_at" : "2016-01-07 00:30:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Kelly",
      "screen_name" : "trass",
      "indices" : [ 3, 9 ],
      "id_str" : "16785883",
      "id" : 16785883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/aGY3f4CVik",
      "expanded_url" : "https:\/\/lnkd.in\/bVHYDtr",
      "display_url" : "lnkd.in\/bVHYDtr"
    } ]
  },
  "geo" : { },
  "id_str" : "684884022711848960",
  "text" : "RT @trass: The Impact of ETUG: First-time attendee, Daniel Reeve, shares his experiences https:\/\/t.co\/aGY3f4CVik",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/aGY3f4CVik",
        "expanded_url" : "https:\/\/lnkd.in\/bVHYDtr",
        "display_url" : "lnkd.in\/bVHYDtr"
      } ]
    },
    "geo" : { },
    "id_str" : "684882238836609024",
    "text" : "The Impact of ETUG: First-time attendee, Daniel Reeve, shares his experiences https:\/\/t.co\/aGY3f4CVik",
    "id" : 684882238836609024,
    "created_at" : "2016-01-06 23:40:24 +0000",
    "user" : {
      "name" : "Tracy Kelly",
      "screen_name" : "trass",
      "protected" : false,
      "id_str" : "16785883",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701514035120906240\/gKy5QnIp_normal.jpg",
      "id" : 16785883,
      "verified" : false
    }
  },
  "id" : 684884022711848960,
  "created_at" : "2016-01-06 23:47:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/684882132888518656\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Iz3rHPnEQD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYEwq2PUoAAzMks.png",
      "id_str" : "684882131009445888",
      "id" : 684882131009445888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYEwq2PUoAAzMks.png",
      "sizes" : [ {
        "h" : 664,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Iz3rHPnEQD"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/684882132888518656\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Iz3rHPnEQD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYEwq5iUQAEoReo.png",
      "id_str" : "684882131894419457",
      "id" : 684882131894419457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYEwq5iUQAEoReo.png",
      "sizes" : [ {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Iz3rHPnEQD"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/684882132888518656\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Iz3rHPnEQD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYEwqxwUAAAW59t.png",
      "id_str" : "684882129805639680",
      "id" : 684882129805639680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYEwqxwUAAAW59t.png",
      "sizes" : [ {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Iz3rHPnEQD"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/684882132888518656\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Iz3rHPnEQD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYEwq7BUEAEH6AD.png",
      "id_str" : "684882132292866049",
      "id" : 684882132292866049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYEwq7BUEAEH6AD.png",
      "sizes" : [ {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 1012
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 1012
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Iz3rHPnEQD"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684882132888518656",
  "text" : "It's rough, it's basic, it's a prototype! Course companion is editable locally + collaboratively on GitHub. #GravEdu https:\/\/t.co\/Iz3rHPnEQD",
  "id" : 684882132888518656,
  "created_at" : "2016-01-06 23:39:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 41, 49 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/684831371324305408\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/cLhWCEMkTo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYECgMUWwAE7elO.png",
      "id_str" : "684831370422697985",
      "id" : 684831370422697985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYECgMUWwAE7elO.png",
      "sizes" : [ {
        "h" : 1298,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 772,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1298,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cLhWCEMkTo"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/684831371324305408\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/cLhWCEMkTo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYECgMWW8AA_fRc.png",
      "id_str" : "684831370431098880",
      "id" : 684831370431098880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYECgMWW8AA_fRc.png",
      "sizes" : [ {
        "h" : 1298,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 772,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1298,
        "resize" : "fit",
        "w" : 1009
      } ],
      "display_url" : "pic.twitter.com\/cLhWCEMkTo"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684831371324305408",
  "text" : "With a flipped-LMS you may want to embed @getgrav pages within your LMS. Testing URL flag to hide site nav. #GravEdu https:\/\/t.co\/cLhWCEMkTo",
  "id" : 684831371324305408,
  "created_at" : "2016-01-06 20:18:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 66, 74 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Suvvt9ApMH",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/coursecompanionstarterkit\/",
      "display_url" : "hibbittsdesign.org\/coursecompanio\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "684632139640487936",
  "geo" : { },
  "id_str" : "684784717888008192",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Indeed! For 2016 I plan a course companion starter kit w. @getgrav, including ready-to-use template and docs https:\/\/t.co\/Suvvt9ApMH",
  "id" : 684784717888008192,
  "in_reply_to_status_id" : 684632139640487936,
  "created_at" : "2016-01-06 17:12:54 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/w5AvBBh745",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/flipped-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684561191297925120",
  "text" : "Flipped-LMS Approach Using an Open and Collaborative Web Platform https:\/\/t.co\/w5AvBBh745 #GravEdu",
  "id" : 684561191297925120,
  "created_at" : "2016-01-06 02:24:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "indices" : [ 3, 14 ],
      "id_str" : "27633854",
      "id" : 27633854
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lms",
      "indices" : [ 30, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/s9VCXG8628",
      "expanded_url" : "https:\/\/twitter.com\/btopro\/status\/684547002927984640",
      "display_url" : "twitter.com\/btopro\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684560146861694976",
  "text" : "RT @JustStormy: Flip it good! #lms https:\/\/t.co\/s9VCXG8628",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lms",
        "indices" : [ 14, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/s9VCXG8628",
        "expanded_url" : "https:\/\/twitter.com\/btopro\/status\/684547002927984640",
        "display_url" : "twitter.com\/btopro\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "684554713275170816",
    "text" : "Flip it good! #lms https:\/\/t.co\/s9VCXG8628",
    "id" : 684554713275170816,
    "created_at" : "2016-01-06 01:58:56 +0000",
    "user" : {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "protected" : false,
      "id_str" : "27633854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766452852248109056\/nnq9NFSH_normal.jpg",
      "id" : 27633854,
      "verified" : false
    }
  },
  "id" : 684560146861694976,
  "created_at" : "2016-01-06 02:20:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684547759211335680",
  "geo" : { },
  "id_str" : "684558596932157440",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro You are awesomely macro (i.e. institution-wide) while I am micro (i.e. individual instructors) \u263A\uFE0F.",
  "id" : 684558596932157440,
  "in_reply_to_status_id" : 684547759211335680,
  "created_at" : "2016-01-06 02:14:22 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 12, 27 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LMSflip",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/kjJTcGXnVD",
      "expanded_url" : "http:\/\/information.altruism.network\/blog\/post\/organic-deployment-architecture",
      "display_url" : "information.altruism.network\/blog\/post\/orga\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684555502135558145",
  "text" : "RT @btopro: @hibbittsdesign if #LMSflip is your blog post \/ diagram baby then I'm pushing to make this 1 mine :) \u2014 https:\/\/t.co\/kjJTcGXnVD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 0, 15 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LMSflip",
        "indices" : [ 19, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/kjJTcGXnVD",
        "expanded_url" : "http:\/\/information.altruism.network\/blog\/post\/organic-deployment-architecture",
        "display_url" : "information.altruism.network\/blog\/post\/orga\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "684547759211335680",
    "in_reply_to_user_id" : 15949844,
    "text" : "@hibbittsdesign if #LMSflip is your blog post \/ diagram baby then I'm pushing to make this 1 mine :) \u2014 https:\/\/t.co\/kjJTcGXnVD",
    "id" : 684547759211335680,
    "created_at" : "2016-01-06 01:31:18 +0000",
    "in_reply_to_screen_name" : "hibbittsdesign",
    "in_reply_to_user_id_str" : "15949844",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 684555502135558145,
  "created_at" : "2016-01-06 02:02:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684544569082527744",
  "geo" : { },
  "id_str" : "684546118785470465",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Please keep me posted on any student feedback as well.",
  "id" : 684546118785470465,
  "in_reply_to_status_id" : 684544569082527744,
  "created_at" : "2016-01-06 01:24:47 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684544569082527744",
  "geo" : { },
  "id_str" : "684545933766340608",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Thanks, awesome to see! \uD83D\uDC4D",
  "id" : 684545933766340608,
  "in_reply_to_status_id" : 684544569082527744,
  "created_at" : "2016-01-06 01:24:03 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/w5AvBBh745",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/flipped-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684094661477044224",
  "text" : "Flipped-LMS Approach Using an Open and Collaborative Web Platform https:\/\/t.co\/w5AvBBh745 #GravEdu",
  "id" : 684094661477044224,
  "created_at" : "2016-01-04 19:30:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 130, 138 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 10, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684087346132697088",
  "text" : "What will #GravEdu be all about? Helping fellow educators reach unmet pedagogical\/UX goals by leveraging the modern flat-file CMS @getgrav.",
  "id" : 684087346132697088,
  "created_at" : "2016-01-04 19:01:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 110, 120 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/qf8XL8wJN8",
      "expanded_url" : "https:\/\/shar.es\/16tUx9",
      "display_url" : "shar.es\/16tUx9"
    } ]
  },
  "geo" : { },
  "id_str" : "684074605909164032",
  "text" : "How Focusing on User Experience Helped GOV.UK Win Design of the Year :: UXmatters https:\/\/t.co\/qf8XL8wJN8 via @sharethis",
  "id" : 684074605909164032,
  "created_at" : "2016-01-04 18:11:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Rossett",
      "screen_name" : "arossett",
      "indices" : [ 3, 12 ],
      "id_str" : "14745283",
      "id" : 14745283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/eq2bhTQcsF",
      "expanded_url" : "https:\/\/shar.es\/16g9FR",
      "display_url" : "shar.es\/16g9FR"
    } ]
  },
  "geo" : { },
  "id_str" : "683441935181152256",
  "text" : "RT @arossett: Professors Know About High-Tech Teaching Methods, but Few Use Them https:\/\/t.co\/eq2bhTQcsF via chronicle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/eq2bhTQcsF",
        "expanded_url" : "https:\/\/shar.es\/16g9FR",
        "display_url" : "shar.es\/16g9FR"
      } ]
    },
    "geo" : { },
    "id_str" : "683439450257408000",
    "text" : "Professors Know About High-Tech Teaching Methods, but Few Use Them https:\/\/t.co\/eq2bhTQcsF via chronicle",
    "id" : 683439450257408000,
    "created_at" : "2016-01-03 00:07:17 +0000",
    "user" : {
      "name" : "Allison Rossett",
      "screen_name" : "arossett",
      "protected" : false,
      "id_str" : "14745283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663982912\/allison_green_chin_normal.jpg",
      "id" : 14745283,
      "verified" : false
    }
  },
  "id" : 683441935181152256,
  "created_at" : "2016-01-03 00:17:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bhooshan Pandya",
      "screen_name" : "Bhooshan",
      "indices" : [ 0, 9 ],
      "id_str" : "6135062",
      "id" : 6135062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683432187031519232",
  "geo" : { },
  "id_str" : "683433990200492032",
  "in_reply_to_user_id" : 6135062,
  "text" : "@Bhooshan Likewise \u263A",
  "id" : 683433990200492032,
  "in_reply_to_status_id" : 683432187031519232,
  "created_at" : "2016-01-02 23:45:35 +0000",
  "in_reply_to_screen_name" : "Bhooshan",
  "in_reply_to_user_id_str" : "6135062",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "markusmind",
      "screen_name" : "mdeimann",
      "indices" : [ 3, 12 ],
      "id_str" : "20503420",
      "id" : 20503420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/Brc2O3ZqXU",
      "expanded_url" : "http:\/\/bryanalexander.org\/2015\/12\/29\/trends-to-watch-in-2015-education-and-technology\/",
      "display_url" : "bryanalexander.org\/2015\/12\/29\/tre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683430680634634241",
  "text" : "RT @mdeimann: Trends to watch in 2016: education and technology https:\/\/t.co\/Brc2O3ZqXU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweedleapp.com\/\" rel=\"nofollow\"\u003E Tweedle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/Brc2O3ZqXU",
        "expanded_url" : "http:\/\/bryanalexander.org\/2015\/12\/29\/trends-to-watch-in-2015-education-and-technology\/",
        "display_url" : "bryanalexander.org\/2015\/12\/29\/tre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "683392669637283841",
    "text" : "Trends to watch in 2016: education and technology https:\/\/t.co\/Brc2O3ZqXU",
    "id" : 683392669637283841,
    "created_at" : "2016-01-02 21:01:23 +0000",
    "user" : {
      "name" : "markusmind",
      "screen_name" : "mdeimann",
      "protected" : false,
      "id_str" : "20503420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705476396815130627\/7tPTiauv_normal.jpg",
      "id" : 20503420,
      "verified" : false
    }
  },
  "id" : 683430680634634241,
  "created_at" : "2016-01-02 23:32:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683427809704804352",
  "text" : "A flipped-LMS is an approach that uses an LMS for student data\/assessment while empowering instructors with an open &amp; collaborative platform",
  "id" : 683427809704804352,
  "created_at" : "2016-01-02 23:21:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/w5AvBBh745",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/flipped-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683421455653048320",
  "text" : "Shackled by an LMS? Don't wait until the contract ends - flip your LMS with an open &amp; collaborative platform in 2016 https:\/\/t.co\/w5AvBBh745",
  "id" : 683421455653048320,
  "created_at" : "2016-01-02 22:55:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683009616024702976",
  "text" : "My mission in 2016? To help fellow educators reach unmet pedagogical\/UX goals by leveraging a modern, open and collaborative Web platform.\uD83D\uDE80",
  "id" : 683009616024702976,
  "created_at" : "2016-01-01 19:39:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]