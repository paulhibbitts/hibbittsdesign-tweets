Grailbird.data.tweets_2015_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Cooper",
      "screen_name" : "MrAlanCooper",
      "indices" : [ 3, 16 ],
      "id_str" : "103920270",
      "id" : 103920270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593905383229370368",
  "text" : "RT @MrAlanCooper: Empathy is understanding what another person is experiencing. That doesn't say anything about your ability to improve tha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593904876272230400",
    "text" : "Empathy is understanding what another person is experiencing. That doesn't say anything about your ability to improve that experience.",
    "id" : 593904876272230400,
    "created_at" : "2015-04-30 22:28:51 +0000",
    "user" : {
      "name" : "Alan Cooper",
      "screen_name" : "MrAlanCooper",
      "protected" : false,
      "id_str" : "103920270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1470274107\/Alan_Avatar_normal.jpg",
      "id" : 103920270,
      "verified" : false
    }
  },
  "id" : 593905383229370368,
  "created_at" : "2015-04-30 22:30:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/talfZ0rEiG",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/from-mobile-access-multi-device-learning-ecologies-case-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/from-mob\u2026"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/w5rfYqskKp",
      "expanded_url" : "https:\/\/twitter.com\/tomwhitby\/status\/593517958304894976",
      "display_url" : "twitter.com\/tomwhitby\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593819083461632000",
  "text" : "This is an excellent article in itself, and relates well to my learning ecology experiences https:\/\/t.co\/talfZ0rEiG https:\/\/t.co\/w5rfYqskKp",
  "id" : 593819083461632000,
  "created_at" : "2015-04-30 16:47:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "frank fucile",
      "screen_name" : "frankfucile",
      "indices" : [ 0, 12 ],
      "id_str" : "153586453",
      "id" : 153586453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593579191943041024",
  "geo" : { },
  "id_str" : "593593326902771712",
  "in_reply_to_user_id" : 153586453,
  "text" : "@frankfucile It was great to see you again!",
  "id" : 593593326902771712,
  "in_reply_to_status_id" : 593579191943041024,
  "created_at" : "2015-04-30 01:50:52 +0000",
  "in_reply_to_screen_name" : "frankfucile",
  "in_reply_to_user_id_str" : "153586453",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593543179158196224",
  "text" : "RT @lukew: \"UX controls automatically adapt to different screen sizes &amp; [you can] tailor applications to capabilities of each device\" -Wind\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593542084654542849",
    "text" : "\"UX controls automatically adapt to different screen sizes &amp; [you can] tailor applications to capabilities of each device\" -Windows 10",
    "id" : 593542084654542849,
    "created_at" : "2015-04-29 22:27:15 +0000",
    "user" : {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "protected" : false,
      "id_str" : "13889622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477610446917103616\/_cjU3_ga_normal.png",
      "id" : 13889622,
      "verified" : false
    }
  },
  "id" : 593543179158196224,
  "created_at" : "2015-04-29 22:31:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Thurrott",
      "screen_name" : "thurrott",
      "indices" : [ 3, 12 ],
      "id_str" : "14964767",
      "id" : 14964767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593493651071901696",
  "text" : "RT @thurrott: With Continuum for Phones, any screen can be your PC.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593475723265998849",
    "text" : "With Continuum for Phones, any screen can be your PC.",
    "id" : 593475723265998849,
    "created_at" : "2015-04-29 18:03:33 +0000",
    "user" : {
      "name" : "Paul Thurrott",
      "screen_name" : "thurrott",
      "protected" : false,
      "id_str" : "14964767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718435052779151360\/s1niU-q7_normal.jpg",
      "id" : 14964767,
      "verified" : false
    }
  },
  "id" : 593493651071901696,
  "created_at" : "2015-04-29 19:14:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlearn",
      "indices" : [ 76, 83 ]
    }, {
      "text" : "edtech",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Uf8swsK5La",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/model-learner-needs-experience-design-technology-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/model-le\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593468144271917056",
  "text" : "\"A Model for Learner Needs, Experience Design &amp; Technology Development\" #mlearn #edtech https:\/\/t.co\/Uf8swsK5La",
  "id" : 593468144271917056,
  "created_at" : "2015-04-29 17:33:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 11, 19 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/2VslFHNsyt",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/canvas-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/canvas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593463512325816320",
  "text" : "Explore my @getgrav multi-device course companion prototype at http:\/\/t.co\/2VslFHNsyt Includes direct links to needed #CanvasLMS functions.",
  "id" : 593463512325816320,
  "created_at" : "2015-04-29 17:15:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/593462246497386496\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/vZy3SDAvIj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDxmxKqUMAA81AD.png",
      "id_str" : "593462245767524352",
      "id" : 593462245767524352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDxmxKqUMAA81AD.png",
      "sizes" : [ {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 559,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vZy3SDAvIj"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/593462246497386496\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/vZy3SDAvIj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDxmxLEUsAELUSY.png",
      "id_str" : "593462245876609025",
      "id" : 593462245876609025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDxmxLEUsAELUSY.png",
      "sizes" : [ {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 559,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vZy3SDAvIj"
    } ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 12, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593462246497386496",
  "text" : "Streamlined #CanvasLMS homepage to provide quick access to multi-device course companion and needed Canvas functions. http:\/\/t.co\/vZy3SDAvIj",
  "id" : 593462246497386496,
  "created_at" : "2015-04-29 17:10:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BCNET2015",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/7wiO09C8CH",
      "expanded_url" : "http:\/\/bit.ly\/1JwOowA",
      "display_url" : "bit.ly\/1JwOowA"
    } ]
  },
  "geo" : { },
  "id_str" : "593156399837806593",
  "text" : "RT @clintlalonde: Slidedeck from #BCNET2015 presentation on open textbooks http:\/\/t.co\/7wiO09C8CH Thanks all who came out to hear about the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BCNET2015",
        "indices" : [ 15, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/7wiO09C8CH",
        "expanded_url" : "http:\/\/bit.ly\/1JwOowA",
        "display_url" : "bit.ly\/1JwOowA"
      } ]
    },
    "geo" : { },
    "id_str" : "593115993020305409",
    "text" : "Slidedeck from #BCNET2015 presentation on open textbooks http:\/\/t.co\/7wiO09C8CH Thanks all who came out to hear about the project",
    "id" : 593115993020305409,
    "created_at" : "2015-04-28 18:14:06 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 593156399837806593,
  "created_at" : "2015-04-28 20:54:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BCNET2015",
      "indices" : [ 17, 27 ]
    }, {
      "text" : "CapUStudentUX",
      "indices" : [ 51, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593155126812020736",
  "text" : "Great sessions @ #BCNET2015 this morning, kudos to #CapUStudentUX and the Bring Ed Tech into the Light: Engaging the Campus Community teams.",
  "id" : 593155126812020736,
  "created_at" : "2015-04-28 20:49:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Lee",
      "screen_name" : "heli_tomato",
      "indices" : [ 3, 15 ],
      "id_str" : "26872162",
      "id" : 26872162
    }, {
      "name" : "Douglas College",
      "screen_name" : "douglascollege",
      "indices" : [ 93, 108 ],
      "id_str" : "18194015",
      "id" : 18194015
    }, {
      "name" : "TELT JIBC",
      "screen_name" : "TELTJIBC",
      "indices" : [ 129, 138 ],
      "id_str" : "462494966",
      "id" : 462494966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BCNET2015",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593153691101696000",
  "text" : "RT @heli_tomato: Sir Peter blake \"New technology is common, new thinking is rare\" #BCNET2015 @douglascollege session, same quote @TELTJIBC \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Douglas College",
        "screen_name" : "douglascollege",
        "indices" : [ 76, 91 ],
        "id_str" : "18194015",
        "id" : 18194015
      }, {
        "name" : "TELT JIBC",
        "screen_name" : "TELTJIBC",
        "indices" : [ 112, 121 ],
        "id_str" : "462494966",
        "id" : 462494966
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BCNET2015",
        "indices" : [ 65, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593119920403025920",
    "text" : "Sir Peter blake \"New technology is common, new thinking is rare\" #BCNET2015 @douglascollege session, same quote @TELTJIBC office :)",
    "id" : 593119920403025920,
    "created_at" : "2015-04-28 18:29:43 +0000",
    "user" : {
      "name" : "Helen Lee",
      "screen_name" : "heli_tomato",
      "protected" : false,
      "id_str" : "26872162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524671122982195200\/z_WPB4by_normal.jpeg",
      "id" : 26872162,
      "verified" : false
    }
  },
  "id" : 593153691101696000,
  "created_at" : "2015-04-28 20:43:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "frank fucile",
      "screen_name" : "frankfucile",
      "indices" : [ 3, 15 ],
      "id_str" : "153586453",
      "id" : 153586453
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/frankfucile\/status\/593114193626300416\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/z9GZPbehHo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDsqNhRUEAEwb5o.jpg",
      "id_str" : "593114187687006209",
      "id" : 593114187687006209,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDsqNhRUEAEwb5o.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/z9GZPbehHo"
    } ],
    "hashtags" : [ {
      "text" : "BCNET2015",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593116331794268160",
  "text" : "RT @frankfucile: Does this thing clean carpets! #BCNET2015 http:\/\/t.co\/z9GZPbehHo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/frankfucile\/status\/593114193626300416\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/z9GZPbehHo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDsqNhRUEAEwb5o.jpg",
        "id_str" : "593114187687006209",
        "id" : 593114187687006209,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDsqNhRUEAEwb5o.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/z9GZPbehHo"
      } ],
      "hashtags" : [ {
        "text" : "BCNET2015",
        "indices" : [ 31, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593114193626300416",
    "text" : "Does this thing clean carpets! #BCNET2015 http:\/\/t.co\/z9GZPbehHo",
    "id" : 593114193626300416,
    "created_at" : "2015-04-28 18:06:57 +0000",
    "user" : {
      "name" : "frank fucile",
      "screen_name" : "frankfucile",
      "protected" : false,
      "id_str" : "153586453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1686358335\/new_hat_normal.png",
      "id" : 153586453,
      "verified" : false
    }
  },
  "id" : 593116331794268160,
  "created_at" : "2015-04-28 18:15:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592721979221909504",
  "geo" : { },
  "id_str" : "592723121813254145",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Hope to run into today, I am here as well",
  "id" : 592723121813254145,
  "in_reply_to_status_id" : 592721979221909504,
  "created_at" : "2015-04-27 16:12:59 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 3, 17 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/5bHMC3cSp4",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2015\/apr\/26\/facebook-isnt-charity-poor-pay-by-surrending-their-data",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592150363131629569",
  "text" : "RT @evgenymorozov: My latest: \"Facebook isn\u2019t a charity. The poor will pay by surrendering their data\" http:\/\/t.co\/5bHMC3cSp4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/5bHMC3cSp4",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2015\/apr\/26\/facebook-isnt-charity-poor-pay-by-surrending-their-data",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "592118295538577408",
    "text" : "My latest: \"Facebook isn\u2019t a charity. The poor will pay by surrendering their data\" http:\/\/t.co\/5bHMC3cSp4",
    "id" : 592118295538577408,
    "created_at" : "2015-04-26 00:09:37 +0000",
    "user" : {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "protected" : false,
      "id_str" : "30331417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640536915477794816\/u9TxNsKI_normal.jpg",
      "id" : 30331417,
      "verified" : false
    }
  },
  "id" : 592150363131629569,
  "created_at" : "2015-04-26 02:17:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Irwin DeVries",
      "screen_name" : "IrwinDev",
      "indices" : [ 3, 12 ],
      "id_str" : "120194872",
      "id" : 120194872
    }, {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 41, 50 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oeglobal",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592005511031066624",
  "text" : "RT @IrwinDev: Three cheers for award for @BCcampus open textbooks #oeglobal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BCcampus",
        "screen_name" : "BCcampus",
        "indices" : [ 27, 36 ],
        "id_str" : "93710949",
        "id" : 93710949
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oeglobal",
        "indices" : [ 52, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "591448257714212864",
    "text" : "Three cheers for award for @BCcampus open textbooks #oeglobal",
    "id" : 591448257714212864,
    "created_at" : "2015-04-24 03:47:07 +0000",
    "user" : {
      "name" : "Irwin DeVries",
      "screen_name" : "IrwinDev",
      "protected" : false,
      "id_str" : "120194872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718662718132064258\/jmAsqZvL_normal.jpg",
      "id" : 120194872,
      "verified" : false
    }
  },
  "id" : 592005511031066624,
  "created_at" : "2015-04-25 16:41:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 76, 84 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/590986803059888128\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/9xaXZ1cx7b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDObXVNUUAAH-hp.png",
      "id_str" : "590986801247965184",
      "id" : 590986801247965184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDObXVNUUAAH-hp.png",
      "sizes" : [ {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 559,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9xaXZ1cx7b"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/590986803059888128\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/9xaXZ1cx7b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDObXZpVEAA0qW9.png",
      "id_str" : "590986802439196672",
      "id" : 590986802439196672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDObXZpVEAA0qW9.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 559,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      } ],
      "display_url" : "pic.twitter.com\/9xaXZ1cx7b"
    } ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590986803059888128",
  "text" : "Work continues on my next course companion combining #CanvasLMS and the CMS @getgrav for speed and modular content. http:\/\/t.co\/9xaXZ1cx7b",
  "id" : 590986803059888128,
  "created_at" : "2015-04-22 21:13:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 71, 79 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/OcwwWhcmuX",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/canvas-prototype-test\/",
      "display_url" : "hibbittsdesign.com\/courses\/canvas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590588866249240576",
  "text" : "Multi-device prototype combining #CanvasLMS for student assessment and @getgrav for modular content and presentation: http:\/\/t.co\/OcwwWhcmuX",
  "id" : 590588866249240576,
  "created_at" : "2015-04-21 18:52:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rohit sharma",
      "screen_name" : "rohit_x_",
      "indices" : [ 3, 12 ],
      "id_str" : "156407255",
      "id" : 156407255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/3NtGQbWCKH",
      "expanded_url" : "http:\/\/Internet.org",
      "display_url" : "Internet.org"
    }, {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/z0QM7epX74",
      "expanded_url" : "http:\/\/www.hindustantimes.com\/technology-topstories\/mr-zuckerberg-facebook-is-not-and-should-not-be-the-internet\/article1-1337944.aspx",
      "display_url" : "hindustantimes.com\/technology-top\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "589922782495944704",
  "text" : "RT @rohit_x_: Nikhil Pahwa responds to Mr Zuckerberg on http:\/\/t.co\/3NtGQbWCKH vs. Internet in India http:\/\/t.co\/z0QM7epX74",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/3NtGQbWCKH",
        "expanded_url" : "http:\/\/Internet.org",
        "display_url" : "Internet.org"
      }, {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/z0QM7epX74",
        "expanded_url" : "http:\/\/www.hindustantimes.com\/technology-topstories\/mr-zuckerberg-facebook-is-not-and-should-not-be-the-internet\/article1-1337944.aspx",
        "display_url" : "hindustantimes.com\/technology-top\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "589914424078508032",
    "text" : "Nikhil Pahwa responds to Mr Zuckerberg on http:\/\/t.co\/3NtGQbWCKH vs. Internet in India http:\/\/t.co\/z0QM7epX74",
    "id" : 589914424078508032,
    "created_at" : "2015-04-19 22:12:13 +0000",
    "user" : {
      "name" : "rohit sharma",
      "screen_name" : "rohit_x_",
      "protected" : false,
      "id_str" : "156407255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716742195257090048\/ZBvNYwAE_normal.jpg",
      "id" : 156407255,
      "verified" : false
    }
  },
  "id" : 589922782495944704,
  "created_at" : "2015-04-19 22:45:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/WvXOnaredA",
      "expanded_url" : "http:\/\/internet.org",
      "display_url" : "internet.org"
    } ]
  },
  "geo" : { },
  "id_str" : "589257685213679618",
  "text" : "What a crock those http:\/\/t.co\/WvXOnaredA videos are.",
  "id" : 589257685213679618,
  "created_at" : "2015-04-18 02:42:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 87, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/8gF4Q2T81H",
      "expanded_url" : "http:\/\/etug.ca\/2015\/04\/13\/spring-workshop-2015-schedule\/",
      "display_url" : "etug.ca\/2015\/04\/13\/spr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "589116512759222272",
  "text" : "Looks like it is official now, very excited to present the closing plenary session for #etug Spring Workshop! http:\/\/t.co\/8gF4Q2T81H",
  "id" : 589116512759222272,
  "created_at" : "2015-04-17 17:21:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588955409718910976",
  "geo" : { },
  "id_str" : "589062526861611008",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Thanks so much, that is exactly what I was looking for!",
  "id" : 589062526861611008,
  "in_reply_to_status_id" : 588955409718910976,
  "created_at" : "2015-04-17 13:47:05 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/VKY35zk6ER",
      "expanded_url" : "https:\/\/twitter.com\/dazgm\/status\/585724119901024256",
      "display_url" : "twitter.com\/dazgm\/status\/5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588875869382279168",
  "text" : "Wow, it's 2015 and this still needs to be said. Kudos to companies making usable, useful, and enjoyable software! https:\/\/t.co\/VKY35zk6ER",
  "id" : 588875869382279168,
  "created_at" : "2015-04-17 01:25:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588835973548544000",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp I am just now trying the new editor (great work!), but I was wondering - is there a supported method to embed Tweets in a slide?",
  "id" : 588835973548544000,
  "created_at" : "2015-04-16 22:46:50 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Ridden",
      "screen_name" : "EduRidden",
      "indices" : [ 0, 10 ],
      "id_str" : "9198142",
      "id" : 9198142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586664215265484800",
  "geo" : { },
  "id_str" : "588491627489927169",
  "in_reply_to_user_id" : 15949844,
  "text" : "@EduRidden Thanks for sharing the Canvas LMS learning ecology article Julian. Any feedback (positive\/negative) would be more than welcome.",
  "id" : 588491627489927169,
  "in_reply_to_status_id" : 586664215265484800,
  "created_at" : "2015-04-15 23:58:32 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 121, 129 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588475809033232384",
  "text" : "Super stoked about my current multi-device course companion project combining #CanvasLMS with the super-fast and modular @getgrav CMS.",
  "id" : 588475809033232384,
  "created_at" : "2015-04-15 22:55:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenEd15",
      "indices" : [ 122, 131 ]
    }, {
      "text" : "bcpse",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/pxRgHWsX84",
      "expanded_url" : "http:\/\/ow.ly\/LEmZC",
      "display_url" : "ow.ly\/LEmZC"
    } ]
  },
  "geo" : { },
  "id_str" : "588421791250386945",
  "text" : "RT @BCcampus: Submit your proposals! The OpenEd15 Call for Proposals closes this Friday, April 17. http:\/\/t.co\/pxRgHWsX84 #OpenEd15 #bcpse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenEd15",
        "indices" : [ 108, 117 ]
      }, {
        "text" : "bcpse",
        "indices" : [ 118, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/pxRgHWsX84",
        "expanded_url" : "http:\/\/ow.ly\/LEmZC",
        "display_url" : "ow.ly\/LEmZC"
      } ]
    },
    "geo" : { },
    "id_str" : "588415270852624384",
    "text" : "Submit your proposals! The OpenEd15 Call for Proposals closes this Friday, April 17. http:\/\/t.co\/pxRgHWsX84 #OpenEd15 #bcpse",
    "id" : 588415270852624384,
    "created_at" : "2015-04-15 18:55:07 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 588421791250386945,
  "created_at" : "2015-04-15 19:21:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/icpy3zKROu",
      "expanded_url" : "http:\/\/disq.us\/8my5xe",
      "display_url" : "disq.us\/8my5xe"
    } ]
  },
  "geo" : { },
  "id_str" : "587759780229320704",
  "text" : "RT @getgrav: New Blog Post: \"The State of Grav - April 2015\" - Find out what we have done, and where we are going... http:\/\/t.co\/icpy3zKROu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/icpy3zKROu",
        "expanded_url" : "http:\/\/disq.us\/8my5xe",
        "display_url" : "disq.us\/8my5xe"
      } ]
    },
    "geo" : { },
    "id_str" : "587754284495704064",
    "text" : "New Blog Post: \"The State of Grav - April 2015\" - Find out what we have done, and where we are going... http:\/\/t.co\/icpy3zKROu",
    "id" : 587754284495704064,
    "created_at" : "2015-04-13 23:08:36 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 587759780229320704,
  "created_at" : "2015-04-13 23:30:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kato.im",
      "screen_name" : "kato_im",
      "indices" : [ 34, 42 ],
      "id_str" : "1026990656",
      "id" : 1026990656
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 20, 30 ]
    }, {
      "text" : "bootstrap",
      "indices" : [ 44, 54 ]
    }, {
      "text" : "edtech",
      "indices" : [ 124, 131 ]
    }, {
      "text" : "mlearn",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/talfZ0rEiG",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/from-mobile-access-multi-device-learning-ecologies-case-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/from-mob\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "586664215265484800",
  "text" : "Case study of using #CanvasLMS w. @kato_im, #bootstrap and other tools to create a learning ecology https:\/\/t.co\/talfZ0rEiG #edtech #mlearn",
  "id" : 586664215265484800,
  "created_at" : "2015-04-10 22:57:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Hart",
      "screen_name" : "C4LPT",
      "indices" : [ 3, 9 ],
      "id_str" : "14192174",
      "id" : 14192174
    }, {
      "name" : "Sahana Chattopadhyay",
      "screen_name" : "sahana2802",
      "indices" : [ 105, 116 ],
      "id_str" : "17641725",
      "id" : 17641725
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MWL",
      "indices" : [ 118, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/bXi7QrcYEI",
      "expanded_url" : "http:\/\/www.worklearnmobile.org\/articles\/why-linkedin-buying-lynda-is-good-for-mobile-but-scary-for-ld\/",
      "display_url" : "worklearnmobile.org\/articles\/why-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "586529365833293824",
  "text" : "RT @C4LPT: Why LinkedIn buying Lynda is good for mobile, but scary for L&amp;D http:\/\/t.co\/bXi7QrcYEI HT @sahana2802  #MWL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sahana Chattopadhyay",
        "screen_name" : "sahana2802",
        "indices" : [ 94, 105 ],
        "id_str" : "17641725",
        "id" : 17641725
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MWL",
        "indices" : [ 107, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/bXi7QrcYEI",
        "expanded_url" : "http:\/\/www.worklearnmobile.org\/articles\/why-linkedin-buying-lynda-is-good-for-mobile-but-scary-for-ld\/",
        "display_url" : "worklearnmobile.org\/articles\/why-l\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "586456639038849025",
    "text" : "Why LinkedIn buying Lynda is good for mobile, but scary for L&amp;D http:\/\/t.co\/bXi7QrcYEI HT @sahana2802  #MWL",
    "id" : 586456639038849025,
    "created_at" : "2015-04-10 09:12:13 +0000",
    "user" : {
      "name" : "Jane Hart",
      "screen_name" : "C4LPT",
      "protected" : false,
      "id_str" : "14192174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635396281641340928\/qOqqMYNe_normal.jpg",
      "id" : 14192174,
      "verified" : false
    }
  },
  "id" : 586529365833293824,
  "created_at" : "2015-04-10 14:01:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586335739106869248",
  "text" : "Honoured to have my proposed #STLHE2015 session accepted: From Mobile Access to Multi-device Learning Ecologies: A Case Study",
  "id" : 586335739106869248,
  "created_at" : "2015-04-10 01:11:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586013555725443073",
  "geo" : { },
  "id_str" : "586208095505747968",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Thanks very much Tannis, so glad the learning ecology framework looks helpful!",
  "id" : 586208095505747968,
  "in_reply_to_status_id" : 586013555725443073,
  "created_at" : "2015-04-09 16:44:35 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 73, 88 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 92, 101 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/talfZ0rEiG",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/from-mobile-access-multi-device-learning-ecologies-case-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/from-mob\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "585996718996467713",
  "text" : "\"From Mobile Access to Multi-device Learning Ecologies: A Case Study\" by @hibbittsdesign on @LinkedIn https:\/\/t.co\/talfZ0rEiG",
  "id" : 585996718996467713,
  "created_at" : "2015-04-09 02:44:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Known",
      "screen_name" : "withknown",
      "indices" : [ 0, 10 ],
      "id_str" : "227050193",
      "id" : 227050193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585199756772679680",
  "geo" : { },
  "id_str" : "585199877778493440",
  "in_reply_to_user_id" : 227050193,
  "text" : "@withknown Perfect, thanks for the info!",
  "id" : 585199877778493440,
  "in_reply_to_status_id" : 585199756772679680,
  "created_at" : "2015-04-06 21:58:18 +0000",
  "in_reply_to_screen_name" : "withknown",
  "in_reply_to_user_id_str" : "227050193",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 41, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585197743871787008",
  "text" : "Design without constraints is not design #UX",
  "id" : 585197743871787008,
  "created_at" : "2015-04-06 21:49:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Known",
      "screen_name" : "withknown",
      "indices" : [ 0, 10 ],
      "id_str" : "227050193",
      "id" : 227050193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585172370962292736",
  "geo" : { },
  "id_str" : "585195920725270528",
  "in_reply_to_user_id" : 227050193,
  "text" : "@withknown Thanks for the quick reply! BTW, if you upgrade to Pro does your original &lt;name&gt;.withknown.com link work plus custom domain URL?",
  "id" : 585195920725270528,
  "in_reply_to_status_id" : 585172370962292736,
  "created_at" : "2015-04-06 21:42:34 +0000",
  "in_reply_to_screen_name" : "withknown",
  "in_reply_to_user_id_str" : "227050193",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 92, 96 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/D5GUDcNAFj",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/17482",
      "display_url" : "canvas.sfu.ca\/courses\/17482"
    } ]
  },
  "geo" : { },
  "id_str" : "585181988237246465",
  "text" : "Just about finished the learning ecology case study about my CMPT 363 (UI Design) course at #SFU using #CanvasLMS https:\/\/t.co\/D5GUDcNAFj",
  "id" : 585181988237246465,
  "created_at" : "2015-04-06 20:47:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Known",
      "screen_name" : "withknown",
      "indices" : [ 0, 10 ],
      "id_str" : "227050193",
      "id" : 227050193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585161805481185280",
  "geo" : { },
  "id_str" : "585163462759809025",
  "in_reply_to_user_id" : 227050193,
  "text" : "@withknown Thank you, thank you, thank you!!! I did not realize that would be the case but I understand why. All back to normal now :-)",
  "id" : 585163462759809025,
  "in_reply_to_status_id" : 585161805481185280,
  "created_at" : "2015-04-06 19:33:35 +0000",
  "in_reply_to_screen_name" : "withknown",
  "in_reply_to_user_id_str" : "227050193",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Known",
      "screen_name" : "withknown",
      "indices" : [ 0, 10 ],
      "id_str" : "227050193",
      "id" : 227050193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585161568566059008",
  "in_reply_to_user_id" : 227050193,
  "text" : "@withknown When I create a new post I no longer see any formatting tools in the edit box, is this an intentional change?",
  "id" : 585161568566059008,
  "created_at" : "2015-04-06 19:26:04 +0000",
  "in_reply_to_screen_name" : "withknown",
  "in_reply_to_user_id_str" : "227050193",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Pasquini",
      "screen_name" : "laurapasquini",
      "indices" : [ 73, 87 ],
      "id_str" : "16708242",
      "id" : 16708242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/InpVZTmG4m",
      "expanded_url" : "http:\/\/wp.me\/plPK6-SJ",
      "display_url" : "wp.me\/plPK6-SJ"
    } ]
  },
  "geo" : { },
  "id_str" : "584434894819889152",
  "text" : "Checklist: Selecting Technology for Learning: http:\/\/t.co\/InpVZTmG4m via @laurapasquini",
  "id" : 584434894819889152,
  "created_at" : "2015-04-04 19:18:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Pasquini",
      "screen_name" : "laurapasquini",
      "indices" : [ 0, 14 ],
      "id_str" : "16708242",
      "id" : 16708242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583840163262033920",
  "geo" : { },
  "id_str" : "584054603693428736",
  "in_reply_to_user_id" : 16708242,
  "text" : "@laurapasquini Thanks for sharing the learning + technology development model, looking forward to subsequent comments and discussion.",
  "id" : 584054603693428736,
  "in_reply_to_status_id" : 583840163262033920,
  "created_at" : "2015-04-03 18:07:23 +0000",
  "in_reply_to_screen_name" : "laurapasquini",
  "in_reply_to_user_id_str" : "16708242",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]