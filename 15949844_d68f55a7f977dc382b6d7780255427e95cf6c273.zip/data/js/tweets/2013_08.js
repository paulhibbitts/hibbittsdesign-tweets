Grailbird.data.tweets_2013_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/Sl5IEloVnx",
      "expanded_url" : "http:\/\/www.gliffy.com\/go\/publish\/4842756",
      "display_url" : "gliffy.com\/go\/publish\/484\u2026"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/lKNWfvj1SO",
      "expanded_url" : "http:\/\/cmpt-363-133.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-133.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "373499172948680704",
  "text" : "Final week of my open course development experiment\u2026 design process + toolkit http:\/\/t.co\/Sl5IEloVnx live course URL http:\/\/t.co\/lKNWfvj1SO",
  "id" : 373499172948680704,
  "created_at" : "2013-08-30 17:35:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372854023834968064",
  "text" : "The start of September, and with it the new school year, always energizes me much more than a new calendar year. The trend continues\u2026",
  "id" : 372854023834968064,
  "created_at" : "2013-08-28 22:51:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RPM Ltd",
      "screen_name" : "rpmltd",
      "indices" : [ 3, 10 ],
      "id_str" : "90609058",
      "id" : 90609058
    }, {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "indices" : [ 41, 53 ],
      "id_str" : "730373",
      "id" : 730373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/IVcz9QN9Fc",
      "expanded_url" : "http:\/\/bit.ly\/16Rx5O8",
      "display_url" : "bit.ly\/16Rx5O8"
    } ]
  },
  "geo" : { },
  "id_str" : "372778576598155264",
  "text" : "RT @rpmltd: More inspiring thinking from @scottjenson - willing the tech world to realise the potential of connected devices http:\/\/t.co\/IV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott JensOn",
        "screen_name" : "scottjenson",
        "indices" : [ 29, 41 ],
        "id_str" : "730373",
        "id" : 730373
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/IVcz9QN9Fc",
        "expanded_url" : "http:\/\/bit.ly\/16Rx5O8",
        "display_url" : "bit.ly\/16Rx5O8"
      } ]
    },
    "geo" : { },
    "id_str" : "372760088215552000",
    "text" : "More inspiring thinking from @scottjenson - willing the tech world to realise the potential of connected devices http:\/\/t.co\/IVcz9QN9Fc",
    "id" : 372760088215552000,
    "created_at" : "2013-08-28 16:38:25 +0000",
    "user" : {
      "name" : "RPM Ltd",
      "screen_name" : "rpmltd",
      "protected" : false,
      "id_str" : "90609058",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000405960477\/555a176ed87497dafdc9e39ca332c455_normal.png",
      "id" : 90609058,
      "verified" : false
    }
  },
  "id" : 372778576598155264,
  "created_at" : "2013-08-28 17:51:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 0, 9 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/DiYVqZijN0",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "370964675640320000",
  "geo" : { },
  "id_str" : "370969096210219009",
  "in_reply_to_user_id" : 93710949,
  "text" : "@BCcampus Inspired by the Open Textbook Movement, I have been publicly preparing my SFU course for the Fall term http:\/\/t.co\/DiYVqZijN0",
  "id" : 370969096210219009,
  "in_reply_to_status_id" : 370964675640320000,
  "created_at" : "2013-08-23 18:01:39 +0000",
  "in_reply_to_screen_name" : "BCcampus",
  "in_reply_to_user_id_str" : "93710949",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/DiYVqZijN0",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370934632893521920",
  "text" : "Week 11 of my open course development\u2026support for personalized learning resources and updated weekly prep &amp; summaries http:\/\/t.co\/DiYVqZijN0",
  "id" : 370934632893521920,
  "created_at" : "2013-08-23 15:44:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370692857016745984",
  "text" : "My fav quote to help sell personas: \"I don\u2019t know the key to success, but the key to failure is trying to please everybody.\" - Bill Cosby",
  "id" : 370692857016745984,
  "created_at" : "2013-08-22 23:43:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ViyeSXtxSG",
      "expanded_url" : "http:\/\/bit.ly\/1d41Fg6",
      "display_url" : "bit.ly\/1d41Fg6"
    } ]
  },
  "geo" : { },
  "id_str" : "370238981633363968",
  "text" : "http:\/\/t.co\/ViyeSXtxSG \"Mobile is not a device. It's not a channel. It's not a strategy. It's a given.\" &lt;- I love this quote.",
  "id" : 370238981633363968,
  "created_at" : "2013-08-21 17:40:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/vbkiPYCUAd",
      "expanded_url" : "http:\/\/support.balsamiq.com\/customer\/portal\/articles\/105924#edu",
      "display_url" : "support.balsamiq.com\/customer\/porta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368417537790193664",
  "text" : "Week 10 of my open course development\u2026 emailed enrolled students for feedback and qualified for free myBalsamiq usage http:\/\/t.co\/vbkiPYCUAd",
  "id" : 368417537790193664,
  "created_at" : "2013-08-16 17:02:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367394002607149058",
  "text" : "Lean UX tip: When you feel like it is too early to test your hypothesis, it is likely the perfect time to test your hypothesis!",
  "id" : 367394002607149058,
  "created_at" : "2013-08-13 21:15:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/bTPiW3Tg7F",
      "expanded_url" : "http:\/\/on.mash.to\/1cgTz44",
      "display_url" : "on.mash.to\/1cgTz44"
    } ]
  },
  "geo" : { },
  "id_str" : "367046958801620992",
  "text" : "I'm 13 and None of My Friends Use Facebook http:\/\/t.co\/bTPiW3Tg7F \"Facebook was just this thing all our parents seemed to have\" &lt;- Love this",
  "id" : 367046958801620992,
  "created_at" : "2013-08-12 22:16:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sync.com",
      "screen_name" : "Sync",
      "indices" : [ 0, 5 ],
      "id_str" : "551224728",
      "id" : 551224728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367021808622374913",
  "geo" : { },
  "id_str" : "367022063145332736",
  "in_reply_to_user_id" : 551224728,
  "text" : "@Sync Awesome, will do. Thanks!",
  "id" : 367022063145332736,
  "in_reply_to_status_id" : 367021808622374913,
  "created_at" : "2013-08-12 20:37:33 +0000",
  "in_reply_to_screen_name" : "Sync",
  "in_reply_to_user_id_str" : "551224728",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sync.com",
      "screen_name" : "Sync",
      "indices" : [ 0, 5 ],
      "id_str" : "551224728",
      "id" : 551224728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367015646808125442",
  "geo" : { },
  "id_str" : "367016115806814208",
  "in_reply_to_user_id" : 551224728,
  "text" : "@Sync Hoping to get my Beta invite soon :-)",
  "id" : 367016115806814208,
  "in_reply_to_status_id" : 367015646808125442,
  "created_at" : "2013-08-12 20:13:55 +0000",
  "in_reply_to_screen_name" : "Sync",
  "in_reply_to_user_id_str" : "551224728",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367012402585276417",
  "text" : "Social is not a feature, but a (sometimes large\/challenging) cultural change. If you are selling \"social _\" are you selling cultural change?",
  "id" : 367012402585276417,
  "created_at" : "2013-08-12 19:59:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BI Tech",
      "screen_name" : "SAI",
      "indices" : [ 50, 54 ],
      "id_str" : "8841372",
      "id" : 8841372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/dYmWdINQH6",
      "expanded_url" : "http:\/\/www.businessinsider.com\/the-smartphone-is-dead-2013-8",
      "display_url" : "businessinsider.com\/the-smartphone\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366985369759125507",
  "text" : "The Smartphone Is Dead http:\/\/t.co\/dYmWdINQH6 via @sai",
  "id" : 366985369759125507,
  "created_at" : "2013-08-12 18:11:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 62, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365990931129827330",
  "text" : "Great news for Friday afternoon, thanks to the great folks at #SFU my CMPT 363 class of 75 students will have a more comfortable room - yay!",
  "id" : 365990931129827330,
  "created_at" : "2013-08-10 00:20:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ycFI1l0G4q",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/ca3b5284-9bc7-04ee-6596-a284eb3bff1e\/",
      "display_url" : "workflowy.com\/shared\/ca3b528\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365892663746109440",
  "text" : "Week 9 of my open course development\u2026 revised all readings and assignments. HT to Ted Kirkpatrick for his feedback. https:\/\/t.co\/ycFI1l0G4q",
  "id" : 365892663746109440,
  "created_at" : "2013-08-09 17:49:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/kWiAo02UmV",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/ux-techniques-guide\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365532615178072064",
  "text" : "UI\/UX peeps - looking for organization\/content feedback for UX Techniques Guide to accompany my Fall UI design course http:\/\/t.co\/kWiAo02UmV",
  "id" : 365532615178072064,
  "created_at" : "2013-08-08 17:59:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 53, 65 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/UbSPt1hyiP",
      "expanded_url" : "http:\/\/kck.st\/1724zvZ",
      "display_url" : "kck.st\/1724zvZ"
    } ]
  },
  "geo" : { },
  "id_str" : "365509001095561216",
  "text" : "I just backed Cadence &amp; Slang: Second Edition on @Kickstarter http:\/\/t.co\/UbSPt1hyiP",
  "id" : 365509001095561216,
  "created_at" : "2013-08-08 16:25:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/TTSkiRaOEt",
      "expanded_url" : "http:\/\/aspiringwebdev.com\/making-a-page-responsive-in-5-minutes-with-zurb-foundation\/",
      "display_url" : "aspiringwebdev.com\/making-a-page-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "365165401178509313",
  "geo" : { },
  "id_str" : "365167075662118912",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 Just came across this yesterday and thought it might be of interest to you http:\/\/t.co\/TTSkiRaOEt Do you have a preferred framework?",
  "id" : 365167075662118912,
  "in_reply_to_status_id" : 365165401178509313,
  "created_at" : "2013-08-07 17:46:29 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Balsamiq",
      "screen_name" : "balsamiq",
      "indices" : [ 0, 9 ],
      "id_str" : "14361698",
      "id" : 14361698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/DiYVqZijN0",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365161092596514817",
  "in_reply_to_user_id" : 14361698,
  "text" : "@balsamiq Thanks again for the free classroom use license! I've just added myBalsamiq to my course tools list http:\/\/t.co\/DiYVqZijN0",
  "id" : 365161092596514817,
  "created_at" : "2013-08-07 17:22:43 +0000",
  "in_reply_to_screen_name" : "balsamiq",
  "in_reply_to_user_id_str" : "14361698",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Winer",
      "screen_name" : "davewiner",
      "indices" : [ 3, 13 ],
      "id_str" : "3839",
      "id" : 3839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/LXM5QDkawC",
      "expanded_url" : "http:\/\/57m.r2.ly\/",
      "display_url" : "57m.r2.ly"
    } ]
  },
  "geo" : { },
  "id_str" : "364430692051984385",
  "text" : "RT @davewiner: Scripting News: Looking into Bootstrap 3. http:\/\/t.co\/LXM5QDkawC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/LXM5QDkawC",
        "expanded_url" : "http:\/\/57m.r2.ly\/",
        "display_url" : "57m.r2.ly"
      } ]
    },
    "geo" : { },
    "id_str" : "364382841884250112",
    "text" : "Scripting News: Looking into Bootstrap 3. http:\/\/t.co\/LXM5QDkawC",
    "id" : 364382841884250112,
    "created_at" : "2013-08-05 13:50:14 +0000",
    "user" : {
      "name" : "Dave Winer",
      "screen_name" : "davewiner",
      "protected" : false,
      "id_str" : "3839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716686126254321664\/v3citfg4_normal.jpg",
      "id" : 3839,
      "verified" : true
    }
  },
  "id" : 364430692051984385,
  "created_at" : "2013-08-05 17:00:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Teinaki",
      "screen_name" : "vickytnz",
      "indices" : [ 3, 12 ],
      "id_str" : "11231752",
      "id" : 11231752
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vickytnz\/status\/364331630439063552\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/0finhG98xf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQ5dsAUCYAAPabJ.png",
      "id_str" : "364331630443257856",
      "id" : 364331630443257856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQ5dsAUCYAAPabJ.png",
      "sizes" : [ {
        "h" : 120,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 128,
        "resize" : "fit",
        "w" : 641
      }, {
        "h" : 128,
        "resize" : "crop",
        "w" : 128
      }, {
        "h" : 128,
        "resize" : "fit",
        "w" : 641
      }, {
        "h" : 68,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0finhG98xf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364428773199855617",
  "text" : "RT @vickytnz: Ooh look, it's 2007 again http:\/\/t.co\/0finhG98xf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vickytnz\/status\/364331630439063552\/photo\/1",
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/0finhG98xf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQ5dsAUCYAAPabJ.png",
        "id_str" : "364331630443257856",
        "id" : 364331630443257856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQ5dsAUCYAAPabJ.png",
        "sizes" : [ {
          "h" : 120,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 128,
          "resize" : "fit",
          "w" : 641
        }, {
          "h" : 128,
          "resize" : "crop",
          "w" : 128
        }, {
          "h" : 128,
          "resize" : "fit",
          "w" : 641
        }, {
          "h" : 68,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/0finhG98xf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364331630439063552",
    "text" : "Ooh look, it's 2007 again http:\/\/t.co\/0finhG98xf",
    "id" : 364331630439063552,
    "created_at" : "2013-08-05 10:26:44 +0000",
    "user" : {
      "name" : "Vicky Teinaki",
      "screen_name" : "vickytnz",
      "protected" : false,
      "id_str" : "11231752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696054526227456000\/IafDk1ds_normal.jpg",
      "id" : 11231752,
      "verified" : false
    }
  },
  "id" : 364428773199855617,
  "created_at" : "2013-08-05 16:52:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Fraser Univ.",
      "screen_name" : "SFU",
      "indices" : [ 78, 82 ],
      "id_str" : "8071702",
      "id" : 8071702
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/363425222856163329\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/lnTPTFnupC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQslUI9CQAAHGdz.jpg",
      "id_str" : "363425222864551936",
      "id" : 363425222864551936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQslUI9CQAAHGdz.jpg",
      "sizes" : [ {
        "h" : 639,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 396
      } ],
      "display_url" : "pic.twitter.com\/lnTPTFnupC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363425222856163329",
  "text" : "CMPT-363 course companion as viewed on iOS. My goal: to set a new UX standard @SFU for multi-device course materials. http:\/\/t.co\/lnTPTFnupC",
  "id" : 363425222856163329,
  "created_at" : "2013-08-02 22:24:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/363391418267492352\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/oZCX89SF8k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQsGkdCCYAAfRWo.jpg",
      "id_str" : "363391418271686656",
      "id" : 363391418271686656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQsGkdCCYAAfRWo.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oZCX89SF8k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363391418267492352",
  "text" : "A little, well maybe not that little, mobile gem from the past... http:\/\/t.co\/oZCX89SF8k",
  "id" : 363391418267492352,
  "created_at" : "2013-08-02 20:10:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/DiYVqZijN0",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363383892192931840",
  "text" : "Week 8 of my open course development\u2026 draft assignments, class summary ratings, small screen font sizing tweaks http:\/\/t.co\/DiYVqZijN0",
  "id" : 363383892192931840,
  "created_at" : "2013-08-02 19:40:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "O'Reilly Media",
      "screen_name" : "OReillyMedia",
      "indices" : [ 105, 118 ],
      "id_str" : "11069462",
      "id" : 11069462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/P0sEvIR2r3",
      "expanded_url" : "http:\/\/oreillynet.com\/pub\/e\/2740",
      "display_url" : "oreillynet.com\/pub\/e\/2740"
    } ]
  },
  "geo" : { },
  "id_str" : "363076431816822785",
  "text" : "I just signed up for the O'Reilly Webcast: Designing Multi-Device Experiences http:\/\/t.co\/P0sEvIR2r3 via @oreillymedia",
  "id" : 363076431816822785,
  "created_at" : "2013-08-01 23:19:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]