Grailbird.data.tweets_2009_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uxexchange",
      "indices" : [ 124, 135 ]
    }, {
      "text" : "ux",
      "indices" : [ 136, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5272423681",
  "text" : "Kudos to Matt Goddard for UX Exchange, a very approachable Q&A site for user experience professionals http:\/\/bit.ly\/34Sk5D  #uxexchange #ux",
  "id" : 5272423681,
  "created_at" : "2009-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5216058047",
  "text" : "Without challenge, there is no growth.",
  "id" : 5216058047,
  "created_at" : "2009-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5236190356",
  "text" : "A real game-changer in the area of GPS navigation systems UX - Google Maps Navigation for Android 2.0 http:\/\/bit.ly\/3QBp00",
  "id" : 5236190356,
  "created_at" : "2009-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Dragan",
      "screen_name" : "aprilush",
      "indices" : [ 0, 9 ],
      "id_str" : "19180160",
      "id" : 19180160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5048536320",
  "in_reply_to_user_id" : 19180160,
  "text" : "@aprilush Looking forward to seeing the next version of SemNotes!",
  "id" : 5048536320,
  "created_at" : "2009-10-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "aprilush",
  "in_reply_to_user_id_str" : "19180160",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4916255691",
  "text" : "Results of Agile UCD Survey 2009 via Agile Experience Design http:\/\/bit.ly\/1dXM9p",
  "id" : 4916255691,
  "created_at" : "2009-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nelly Yusupova",
      "screen_name" : "DigitalWoman",
      "indices" : [ 0, 13 ],
      "id_str" : "15598707",
      "id" : 15598707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4897333200",
  "in_reply_to_user_id" : 15598707,
  "text" : "@DigitalWoman Have you checked out TimeDriver? It might be an option. http:\/\/timedriver.timetrade.com\/",
  "id" : 4897333200,
  "created_at" : "2009-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "DigitalWoman",
  "in_reply_to_user_id_str" : "15598707",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitney Hess",
      "screen_name" : "whitneyhess",
      "indices" : [ 0, 12 ],
      "id_str" : "11963132",
      "id" : 11963132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4684928710",
  "in_reply_to_user_id" : 11963132,
  "text" : "@whitneyhess You might find this search dialog from Thunderbird a useful reference. http:\/\/yfrog.com\/5aqbmp",
  "id" : 4684928710,
  "created_at" : "2009-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "whitneyhess",
  "in_reply_to_user_id_str" : "11963132",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Agile For All",
      "screen_name" : "agileforall",
      "indices" : [ 127, 139 ],
      "id_str" : "19637701",
      "id" : 19637701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 61, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4664558595",
  "text" : "Short and sweet principles of Agile - akin to my approach to #UX: \"New to agile? Keep it very simple\" http:\/\/bit.ly\/U4VeJ (via @AgileForAll)",
  "id" : 4664558595,
  "created_at" : "2009-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitney Hess",
      "screen_name" : "whitneyhess",
      "indices" : [ 0, 12 ],
      "id_str" : "11963132",
      "id" : 11963132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 108, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4540997981",
  "in_reply_to_user_id" : 11963132,
  "text" : "@whitneyhess Great question! For me, it is three things; relevancy, clarity, and empathy (for the audience) #ux",
  "id" : 4540997981,
  "created_at" : "2009-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "whitneyhess",
  "in_reply_to_user_id_str" : "11963132",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]