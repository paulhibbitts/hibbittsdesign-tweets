Grailbird.data.tweets_2014_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527954818090799104",
  "geo" : { },
  "id_str" : "527957804930183168",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Ironic ;-)",
  "id" : 527957804930183168,
  "in_reply_to_status_id" : 527954818090799104,
  "created_at" : "2014-10-30 22:58:44 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/yiw6T09imn",
      "expanded_url" : "http:\/\/learnerxproject.com",
      "display_url" : "learnerxproject.com"
    }, {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/G8wB7P5x84",
      "expanded_url" : "http:\/\/thelearnerexperience.com",
      "display_url" : "thelearnerexperience.com"
    } ]
  },
  "geo" : { },
  "id_str" : "527944741745201152",
  "text" : "I\u2019ve got two URLs for my learner experience project so far: http:\/\/t.co\/yiw6T09imn or http:\/\/t.co\/G8wB7P5x84. Any preference Twitterverse?",
  "id" : 527944741745201152,
  "created_at" : "2014-10-30 22:06:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SIAT",
      "screen_name" : "SIAT_SFU",
      "indices" : [ 3, 12 ],
      "id_str" : "45701038",
      "id" : 45701038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vancouver",
      "indices" : [ 18, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/q09A0XNGwD",
      "expanded_url" : "http:\/\/ow.ly\/CSKN1",
      "display_url" : "ow.ly\/CSKN1"
    } ]
  },
  "geo" : { },
  "id_str" : "527937502867230720",
  "text" : "RT @SIAT_SFU: The #Vancouver UX Awards submission deadline is tomorrow! Will you be participating? http:\/\/t.co\/q09A0XNGwD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Vancouver",
        "indices" : [ 4, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/q09A0XNGwD",
        "expanded_url" : "http:\/\/ow.ly\/CSKN1",
        "display_url" : "ow.ly\/CSKN1"
      } ]
    },
    "geo" : { },
    "id_str" : "527928450712371200",
    "text" : "The #Vancouver UX Awards submission deadline is tomorrow! Will you be participating? http:\/\/t.co\/q09A0XNGwD",
    "id" : 527928450712371200,
    "created_at" : "2014-10-30 21:02:05 +0000",
    "user" : {
      "name" : "SIAT",
      "screen_name" : "SIAT_SFU",
      "protected" : false,
      "id_str" : "45701038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699362551369338880\/LDhtS1hi_normal.png",
      "id" : 45701038,
      "verified" : false
    }
  },
  "id" : 527937502867230720,
  "created_at" : "2014-10-30 21:38:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Fraser Univ.",
      "screen_name" : "SFU",
      "indices" : [ 102, 106 ],
      "id_str" : "8071702",
      "id" : 8071702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DevLearn",
      "indices" : [ 3, 12 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 53, 63 ]
    }, {
      "text" : "Demofest",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527886253216505856",
  "text" : "At #DevLearn and want to get some ideas about making #CanvasLMS more multi-device friendly? Visit the @SFU table (#1) at #Demofest",
  "id" : 527886253216505856,
  "created_at" : "2014-10-30 18:14:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 3, 13 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "demofest",
      "indices" : [ 40, 49 ]
    }, {
      "text" : "devlearn",
      "indices" : [ 50, 59 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 68, 78 ]
    }, {
      "text" : "accessibility",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/KUe7tQFbc1",
      "expanded_url" : "http:\/\/ow.ly\/i\/7nWkF",
      "display_url" : "ow.ly\/i\/7nWkF"
    } ]
  },
  "geo" : { },
  "id_str" : "527608326826520576",
  "text" : "RT @keroleenl: Sneak Peak of my demo at #demofest #devlearn Booth 1 #CanvasLMS Welcoming talks of UDL and #accessibility  http:\/\/t.co\/KUe7t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "demofest",
        "indices" : [ 25, 34 ]
      }, {
        "text" : "devlearn",
        "indices" : [ 35, 44 ]
      }, {
        "text" : "CanvasLMS",
        "indices" : [ 53, 63 ]
      }, {
        "text" : "accessibility",
        "indices" : [ 91, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/KUe7tQFbc1",
        "expanded_url" : "http:\/\/ow.ly\/i\/7nWkF",
        "display_url" : "ow.ly\/i\/7nWkF"
      } ]
    },
    "geo" : { },
    "id_str" : "527342871951994880",
    "text" : "Sneak Peak of my demo at #demofest #devlearn Booth 1 #CanvasLMS Welcoming talks of UDL and #accessibility  http:\/\/t.co\/KUe7tQFbc1",
    "id" : 527342871951994880,
    "created_at" : "2014-10-29 06:15:12 +0000",
    "user" : {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "protected" : false,
      "id_str" : "887742962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515581656686546944\/Q76DpwVe_normal.png",
      "id" : 887742962,
      "verified" : false
    }
  },
  "id" : 527608326826520576,
  "created_at" : "2014-10-29 23:50:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Maeda",
      "screen_name" : "johnmaeda",
      "indices" : [ 3, 13 ],
      "id_str" : "15414807",
      "id" : 15414807
    }, {
      "name" : "Nicholas Negroponte",
      "screen_name" : "nnegroponte",
      "indices" : [ 120, 132 ],
      "id_str" : "29002666",
      "id" : 29002666
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnmaeda\/status\/527269502099423232\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/PasHqGXJEg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1E8qCbCIAAUDEW.jpg",
      "id_str" : "527269324281487360",
      "id" : 527269324281487360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1E8qCbCIAAUDEW.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PasHqGXJEg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527270961281007616",
  "text" : "RT @johnmaeda: \"In 1977, there were peer-reviewed articles that said that the idea of touching a screen was 'stupid.'\" \u2014@nnegroponte http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nicholas Negroponte",
        "screen_name" : "nnegroponte",
        "indices" : [ 105, 117 ],
        "id_str" : "29002666",
        "id" : 29002666
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/johnmaeda\/status\/527269502099423232\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/PasHqGXJEg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1E8qCbCIAAUDEW.jpg",
        "id_str" : "527269324281487360",
        "id" : 527269324281487360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1E8qCbCIAAUDEW.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/PasHqGXJEg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "527269502099423232",
    "text" : "\"In 1977, there were peer-reviewed articles that said that the idea of touching a screen was 'stupid.'\" \u2014@nnegroponte http:\/\/t.co\/PasHqGXJEg",
    "id" : 527269502099423232,
    "created_at" : "2014-10-29 01:23:40 +0000",
    "user" : {
      "name" : "John Maeda",
      "screen_name" : "johnmaeda",
      "protected" : false,
      "id_str" : "15414807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749782211054952448\/_qeErSoY_normal.jpg",
      "id" : 15414807,
      "verified" : true
    }
  },
  "id" : 527270961281007616,
  "created_at" : "2014-10-29 01:29:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Fraser Univ.",
      "screen_name" : "SFU",
      "indices" : [ 13, 17 ],
      "id_str" : "8071702",
      "id" : 8071702
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/526795043496275968\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/jDSUc03VC3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0-NTL7CcAEzvep.png",
      "id_str" : "526795042183081985",
      "id" : 526795042183081985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0-NTL7CcAEzvep.png",
      "sizes" : [ {
        "h" : 520,
        "resize" : "fit",
        "w" : 1160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jDSUc03VC3"
    } ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 62, 72 ]
    }, {
      "text" : "DevLearn",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526795043496275968",
  "text" : "Excited that @SFU will be showcasing my multi-device friendly #CanvasLMS site at their booth (#1) during #DevLearn! http:\/\/t.co\/jDSUc03VC3",
  "id" : 526795043496275968,
  "created_at" : "2014-10-27 17:58:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 3, 19 ],
      "id_str" : "17349291",
      "id" : 17349291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vancouver",
      "indices" : [ 64, 74 ]
    }, {
      "text" : "UX",
      "indices" : [ 122, 125 ]
    }, {
      "text" : "YVR",
      "indices" : [ 126, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/ioouv3LD03",
      "expanded_url" : "http:\/\/www.vancouveruxawards.com",
      "display_url" : "vancouveruxawards.com"
    } ]
  },
  "geo" : { },
  "id_str" : "525759775640801280",
  "text" : "RT @HabaneroConsult: Get your submissions in for the first-ever #Vancouver User Experience Awards: http:\/\/t.co\/ioouv3LD03 #UX #YVR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Vancouver",
        "indices" : [ 43, 53 ]
      }, {
        "text" : "UX",
        "indices" : [ 101, 104 ]
      }, {
        "text" : "YVR",
        "indices" : [ 105, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/ioouv3LD03",
        "expanded_url" : "http:\/\/www.vancouveruxawards.com",
        "display_url" : "vancouveruxawards.com"
      } ]
    },
    "geo" : { },
    "id_str" : "525758741845909504",
    "text" : "Get your submissions in for the first-ever #Vancouver User Experience Awards: http:\/\/t.co\/ioouv3LD03 #UX #YVR",
    "id" : 525758741845909504,
    "created_at" : "2014-10-24 21:20:26 +0000",
    "user" : {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "protected" : false,
      "id_str" : "17349291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768212660244537344\/z_mWqOrE_normal.jpg",
      "id" : 17349291,
      "verified" : false
    }
  },
  "id" : 525759775640801280,
  "created_at" : "2014-10-24 21:24:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525729018365378560",
  "geo" : { },
  "id_str" : "525729235801870338",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Awesome! I just checked them out and everything looks a-ok. Thanks for the prompt response!",
  "id" : 525729235801870338,
  "in_reply_to_status_id" : 525729018365378560,
  "created_at" : "2014-10-24 19:23:12 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Skella",
      "screen_name" : "JamieSkella",
      "indices" : [ 3, 15 ],
      "id_str" : "486342415",
      "id" : 486342415
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JamieSkella\/status\/525392770643419136\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/QY1afkk8lh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0qR76fIYAANmOL.jpg",
      "id_str" : "525392765040222208",
      "id" : 525392765040222208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0qR76fIYAANmOL.jpg",
      "sizes" : [ {
        "h" : 519,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 304,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QY1afkk8lh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525516650075131904",
  "text" : "RT @JamieSkella: Apple, then and now. http:\/\/t.co\/QY1afkk8lh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JamieSkella\/status\/525392770643419136\/photo\/1",
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/QY1afkk8lh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0qR76fIYAANmOL.jpg",
        "id_str" : "525392765040222208",
        "id" : 525392765040222208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0qR76fIYAANmOL.jpg",
        "sizes" : [ {
          "h" : 519,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 172,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 304,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QY1afkk8lh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "525392770643419136",
    "text" : "Apple, then and now. http:\/\/t.co\/QY1afkk8lh",
    "id" : 525392770643419136,
    "created_at" : "2014-10-23 21:06:12 +0000",
    "user" : {
      "name" : "Jamie Skella",
      "screen_name" : "JamieSkella",
      "protected" : false,
      "id_str" : "486342415",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658065045813792768\/skR1Qhmx_normal.jpg",
      "id" : 486342415,
      "verified" : false
    }
  },
  "id" : 525516650075131904,
  "created_at" : "2014-10-24 05:18:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFF",
      "screen_name" : "EFF",
      "indices" : [ 3, 7 ],
      "id_str" : "4816",
      "id" : 4816
    }, {
      "name" : "Carl Malamud",
      "screen_name" : "carlmalamud",
      "indices" : [ 59, 71 ],
      "id_str" : "17495946",
      "id" : 17495946
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/EFF\/status\/525413415763066880\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/expbnIZhBG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0qkt1eIUAABoO9.jpg",
      "id_str" : "525413413896605696",
      "id" : 525413413896605696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0qkt1eIUAABoO9.jpg",
      "sizes" : [ {
        "h" : 359,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 443,
        "resize" : "fit",
        "w" : 741
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 203,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 443,
        "resize" : "fit",
        "w" : 741
      } ],
      "display_url" : "pic.twitter.com\/expbnIZhBG"
    } ],
    "hashtags" : [ {
      "text" : "OAWeek",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/thuGZ4SMnW",
      "expanded_url" : "https:\/\/eff.org\/r.mycw",
      "display_url" : "eff.org\/r.mycw"
    } ]
  },
  "geo" : { },
  "id_str" : "525423402304430080",
  "text" : "RT @EFF: \"Open should be the default, not the exception.\" \u2014@carlmalamud https:\/\/t.co\/thuGZ4SMnW #OAWeek http:\/\/t.co\/expbnIZhBG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Carl Malamud",
        "screen_name" : "carlmalamud",
        "indices" : [ 50, 62 ],
        "id_str" : "17495946",
        "id" : 17495946
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/EFF\/status\/525413415763066880\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/expbnIZhBG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0qkt1eIUAABoO9.jpg",
        "id_str" : "525413413896605696",
        "id" : 525413413896605696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0qkt1eIUAABoO9.jpg",
        "sizes" : [ {
          "h" : 359,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 443,
          "resize" : "fit",
          "w" : 741
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 203,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 443,
          "resize" : "fit",
          "w" : 741
        } ],
        "display_url" : "pic.twitter.com\/expbnIZhBG"
      } ],
      "hashtags" : [ {
        "text" : "OAWeek",
        "indices" : [ 87, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/thuGZ4SMnW",
        "expanded_url" : "https:\/\/eff.org\/r.mycw",
        "display_url" : "eff.org\/r.mycw"
      } ]
    },
    "geo" : { },
    "id_str" : "525413415763066880",
    "text" : "\"Open should be the default, not the exception.\" \u2014@carlmalamud https:\/\/t.co\/thuGZ4SMnW #OAWeek http:\/\/t.co\/expbnIZhBG",
    "id" : 525413415763066880,
    "created_at" : "2014-10-23 22:28:14 +0000",
    "user" : {
      "name" : "EFF",
      "screen_name" : "EFF",
      "protected" : false,
      "id_str" : "4816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756133504413495296\/7NlilDyR_normal.jpg",
      "id" : 4816,
      "verified" : true
    }
  },
  "id" : 525423402304430080,
  "created_at" : "2014-10-23 23:07:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Lidwell",
      "screen_name" : "williamlidwell",
      "indices" : [ 3, 18 ],
      "id_str" : "97539641",
      "id" : 97539641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/t6l3ddyOLY",
      "expanded_url" : "http:\/\/ow.ly\/Dfpw0",
      "display_url" : "ow.ly\/Dfpw0"
    } ]
  },
  "geo" : { },
  "id_str" : "525395571310219264",
  "text" : "RT @williamlidwell: The pocket edition of Universal Principles of Design is off to the printers! Sneak preview on Amazon http:\/\/t.co\/t6l3dd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/t6l3ddyOLY",
        "expanded_url" : "http:\/\/ow.ly\/Dfpw0",
        "display_url" : "ow.ly\/Dfpw0"
      } ]
    },
    "geo" : { },
    "id_str" : "525392922444062721",
    "text" : "The pocket edition of Universal Principles of Design is off to the printers! Sneak preview on Amazon http:\/\/t.co\/t6l3ddyOLY",
    "id" : 525392922444062721,
    "created_at" : "2014-10-23 21:06:48 +0000",
    "user" : {
      "name" : "William Lidwell",
      "screen_name" : "williamlidwell",
      "protected" : false,
      "id_str" : "97539641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707963992497455104\/W6Mtv8Mm_normal.jpg",
      "id" : 97539641,
      "verified" : false
    }
  },
  "id" : 525395571310219264,
  "created_at" : "2014-10-23 21:17:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Grigsby, \u26014",
      "screen_name" : "grigs",
      "indices" : [ 3, 9 ],
      "id_str" : "5774462",
      "id" : 5774462
    }, {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "indices" : [ 73, 85 ],
      "id_str" : "730373",
      "id" : 730373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/SWBkh7Tbs8",
      "expanded_url" : "http:\/\/blog.intercom.io\/the-end-of-apps-as-we-know-them\/",
      "display_url" : "blog.intercom.io\/the-end-of-app\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525344132261490689",
  "text" : "RT @grigs: The End Of Apps As We Know Them \u2014 this reminds of the things  @scottjenson has been saying for awhile. http:\/\/t.co\/SWBkh7Tbs8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.instapaper.com\/\" rel=\"nofollow\"\u003EInstapaper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott JensOn",
        "screen_name" : "scottjenson",
        "indices" : [ 62, 74 ],
        "id_str" : "730373",
        "id" : 730373
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/SWBkh7Tbs8",
        "expanded_url" : "http:\/\/blog.intercom.io\/the-end-of-apps-as-we-know-them\/",
        "display_url" : "blog.intercom.io\/the-end-of-app\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "525343546040020992",
    "text" : "The End Of Apps As We Know Them \u2014 this reminds of the things  @scottjenson has been saying for awhile. http:\/\/t.co\/SWBkh7Tbs8",
    "id" : 525343546040020992,
    "created_at" : "2014-10-23 17:50:36 +0000",
    "user" : {
      "name" : "Jason Grigsby, \u26014",
      "screen_name" : "grigs",
      "protected" : false,
      "id_str" : "5774462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694573720606605312\/j_l6cQVS_normal.jpg",
      "id" : 5774462,
      "verified" : false
    }
  },
  "id" : 525344132261490689,
  "created_at" : "2014-10-23 17:52:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525204587033427968",
  "geo" : { },
  "id_str" : "525287334376259584",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Thanks very much for the follow-up. If any more details on my side of things are helpful just let me know.",
  "id" : 525287334376259584,
  "in_reply_to_status_id" : 525204587033427968,
  "created_at" : "2014-10-23 14:07:14 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DevLearn",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525060422764740608",
  "geo" : { },
  "id_str" : "525061724357939200",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Love to get together sometime after #DevLearn for a coffee chat and hear your thoughts about the conference.",
  "id" : 525061724357939200,
  "in_reply_to_status_id" : 525060422764740608,
  "created_at" : "2014-10-22 23:10:44 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    }, {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 69, 79 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "demofest",
      "indices" : [ 42, 51 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525052642368557056",
  "geo" : { },
  "id_str" : "525058513806950400",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco You could drop by booth #1 at #demofest and say hello to @keroleenl from SFU! Demo includes my multi-device #CanvasLMS project.",
  "id" : 525058513806950400,
  "in_reply_to_status_id" : 525052642368557056,
  "created_at" : "2014-10-22 22:57:59 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ZRTIw614uj",
      "expanded_url" : "https:\/\/slides.com\/paulhibbitts",
      "display_url" : "slides.com\/paulhibbitts"
    } ]
  },
  "geo" : { },
  "id_str" : "525031733142749186",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp It seems that deck previews are not updated anymore when an existing deck is copied? See 1st four decks https:\/\/t.co\/ZRTIw614uj",
  "id" : 525031733142749186,
  "created_at" : "2014-10-22 21:11:34 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 10, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524680022754623488",
  "text" : "While the #SFU CMPT 363 student feedback is overall positive, \"intimidating\" and \"confusing\" are clear indicators of aspects I can improve.",
  "id" : 524680022754623488,
  "created_at" : "2014-10-21 21:54:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/524675248458072064\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/LZ2yJR46XK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0gFW3iIYAAwiyr.png",
      "id_str" : "524675247011028992",
      "id" : 524675247011028992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0gFW3iIYAAwiyr.png",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 810
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 810
      } ],
      "display_url" : "pic.twitter.com\/LZ2yJR46XK"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 14, 18 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524675248458072064",
  "text" : "I've asked my #SFU CMPT 363 students to share their personal reactions to our #CanvasLMS course site. Results so far: http:\/\/t.co\/LZ2yJR46XK",
  "id" : 524675248458072064,
  "created_at" : "2014-10-21 21:35:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/wrmLDpop4K",
      "expanded_url" : "https:\/\/speakerdeck.com\/hibbittsdesign\/cauce-mobile-learning-a-user-experience-perspective",
      "display_url" : "speakerdeck.com\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524669820525371392",
  "text" : "Thanks to everyone who attended my Canadian Association for University Continuing Education mobile learning webinar! https:\/\/t.co\/wrmLDpop4K",
  "id" : 524669820525371392,
  "created_at" : "2014-10-21 21:13:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Weller",
      "screen_name" : "mweller",
      "indices" : [ 3, 11 ],
      "id_str" : "7127162",
      "id" : 7127162
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 109, 122 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/BzHOTkc9j0",
      "expanded_url" : "http:\/\/www.cipo.ic.gc.ca\/app\/opic-cipo\/trdmrks\/srch\/vwTrdmrk.do?lang=eng&status=OK&fileNumber=0922139&extension=0&startingDocumentIndexOnPage=1",
      "display_url" : "cipo.ic.gc.ca\/app\/opic-cipo\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524646007905071104",
  "text" : "RT @mweller: Uni of Guelph trademarks \"OpenED\" http:\/\/t.co\/BzHOTkc9j0 - where to start, where to start? (via @clintlalonde)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Clint Lalonde",
        "screen_name" : "clintlalonde",
        "indices" : [ 96, 109 ],
        "id_str" : "12991032",
        "id" : 12991032
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/BzHOTkc9j0",
        "expanded_url" : "http:\/\/www.cipo.ic.gc.ca\/app\/opic-cipo\/trdmrks\/srch\/vwTrdmrk.do?lang=eng&status=OK&fileNumber=0922139&extension=0&startingDocumentIndexOnPage=1",
        "display_url" : "cipo.ic.gc.ca\/app\/opic-cipo\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "524639623147163648",
    "text" : "Uni of Guelph trademarks \"OpenED\" http:\/\/t.co\/BzHOTkc9j0 - where to start, where to start? (via @clintlalonde)",
    "id" : 524639623147163648,
    "created_at" : "2014-10-21 19:13:28 +0000",
    "user" : {
      "name" : "Martin Weller",
      "screen_name" : "mweller",
      "protected" : false,
      "id_str" : "7127162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760047558404214784\/9BjBxogx_normal.jpg",
      "id" : 7127162,
      "verified" : false
    }
  },
  "id" : 524646007905071104,
  "created_at" : "2014-10-21 19:38:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524164422395502592",
  "geo" : { },
  "id_str" : "524418219650846720",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Thank you. Great to see this invaluable feature has returned!",
  "id" : 524418219650846720,
  "in_reply_to_status_id" : 524164422395502592,
  "created_at" : "2014-10-21 04:33:41 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Intercom",
      "screen_name" : "intercom",
      "indices" : [ 3, 12 ],
      "id_str" : "274788446",
      "id" : 274788446
    }, {
      "name" : "Smashing Magazine",
      "screen_name" : "smashingmag",
      "indices" : [ 39, 51 ],
      "id_str" : "15736190",
      "id" : 15736190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/1aOMMmCnmf",
      "expanded_url" : "http:\/\/buff.ly\/1vLGO9k",
      "display_url" : "buff.ly\/1vLGO9k"
    } ]
  },
  "geo" : { },
  "id_str" : "522872473398697984",
  "text" : "RT @intercom: Comprehensive piece from @smashingmag on impact low-fidelity prototypes can have on design processes and outcomes http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Smashing Magazine",
        "screen_name" : "smashingmag",
        "indices" : [ 25, 37 ],
        "id_str" : "15736190",
        "id" : 15736190
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/1aOMMmCnmf",
        "expanded_url" : "http:\/\/buff.ly\/1vLGO9k",
        "display_url" : "buff.ly\/1vLGO9k"
      } ]
    },
    "geo" : { },
    "id_str" : "522871907788808193",
    "text" : "Comprehensive piece from @smashingmag on impact low-fidelity prototypes can have on design processes and outcomes http:\/\/t.co\/1aOMMmCnmf",
    "id" : 522871907788808193,
    "created_at" : "2014-10-16 22:09:11 +0000",
    "user" : {
      "name" : "Intercom",
      "screen_name" : "intercom",
      "protected" : false,
      "id_str" : "274788446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652527891700428800\/iWpbzpjL_normal.png",
      "id" : 274788446,
      "verified" : true
    }
  },
  "id" : 522872473398697984,
  "created_at" : "2014-10-16 22:11:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/xHeMWjvek5",
      "expanded_url" : "https:\/\/speakerdeck.com\/hibbittsdesign\/cauce-mobile-learning-a-user-experience-perspective",
      "display_url" : "speakerdeck.com\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522138145509236736",
  "text" : "Draft slides of my mobile learning webinar for the Canadian Association for University Continuing Education (CAUCE) https:\/\/t.co\/xHeMWjvek5",
  "id" : 522138145509236736,
  "created_at" : "2014-10-14 21:33:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leisa Reichelt",
      "screen_name" : "leisa",
      "indices" : [ 3, 9 ],
      "id_str" : "34663",
      "id" : 34663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/qULEj6wWsc",
      "expanded_url" : "http:\/\/findingada.com\/",
      "display_url" : "findingada.com"
    } ]
  },
  "geo" : { },
  "id_str" : "522091897200721921",
  "text" : "RT @leisa: It's Ada Lovelace day. If you admire a woman working in technology, today is a good day to tell her. http:\/\/t.co\/qULEj6wWsc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/qULEj6wWsc",
        "expanded_url" : "http:\/\/findingada.com\/",
        "display_url" : "findingada.com"
      } ]
    },
    "geo" : { },
    "id_str" : "522058287593041920",
    "text" : "It's Ada Lovelace day. If you admire a woman working in technology, today is a good day to tell her. http:\/\/t.co\/qULEj6wWsc",
    "id" : 522058287593041920,
    "created_at" : "2014-10-14 16:16:09 +0000",
    "user" : {
      "name" : "Leisa Reichelt",
      "screen_name" : "leisa",
      "protected" : false,
      "id_str" : "34663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468392909817921537\/b7wBJttj_normal.jpeg",
      "id" : 34663,
      "verified" : false
    }
  },
  "id" : 522091897200721921,
  "created_at" : "2014-10-14 18:29:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Drupal",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/l7r8o8uv3g",
      "expanded_url" : "http:\/\/elmsln.org\/",
      "display_url" : "elmsln.org"
    } ]
  },
  "geo" : { },
  "id_str" : "520319230529396736",
  "text" : "Any experiences out there with using #Drupal as a LMS or social learning platform? I am really digging the http:\/\/t.co\/l7r8o8uv3g approach.",
  "id" : 520319230529396736,
  "created_at" : "2014-10-09 21:05:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syncplicity",
      "screen_name" : "syncplicity",
      "indices" : [ 0, 12 ],
      "id_str" : "15184636",
      "id" : 15184636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520242303529533440",
  "geo" : { },
  "id_str" : "520243066440265728",
  "in_reply_to_user_id" : 15184636,
  "text" : "@syncplicity Thanks very much for the info, I will send support an email.",
  "id" : 520243066440265728,
  "in_reply_to_status_id" : 520242303529533440,
  "created_at" : "2014-10-09 16:03:07 +0000",
  "in_reply_to_screen_name" : "syncplicity",
  "in_reply_to_user_id_str" : "15184636",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aarron Walter",
      "screen_name" : "aarron",
      "indices" : [ 3, 10 ],
      "id_str" : "9463382",
      "id" : 9463382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/pUdwtviKCU",
      "expanded_url" : "http:\/\/uxpin.com\/guide-to-ux-design-process-and-documentation.html",
      "display_url" : "uxpin.com\/guide-to-ux-de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520235953395224576",
  "text" : "RT @aarron: The Guide to UX Design Process &amp; Documentation http:\/\/t.co\/pUdwtviKCU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/pUdwtviKCU",
        "expanded_url" : "http:\/\/uxpin.com\/guide-to-ux-design-process-and-documentation.html",
        "display_url" : "uxpin.com\/guide-to-ux-de\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "520235025791348736",
    "text" : "The Guide to UX Design Process &amp; Documentation http:\/\/t.co\/pUdwtviKCU",
    "id" : 520235025791348736,
    "created_at" : "2014-10-09 15:31:10 +0000",
    "user" : {
      "name" : "Aarron Walter",
      "screen_name" : "aarron",
      "protected" : false,
      "id_str" : "9463382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727883346035023874\/pvWNeypQ_normal.jpg",
      "id" : 9463382,
      "verified" : false
    }
  },
  "id" : 520235953395224576,
  "created_at" : "2014-10-09 15:34:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moodle News",
      "screen_name" : "moodlenews",
      "indices" : [ 80, 91 ],
      "id_str" : "96450920",
      "id" : 96450920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/hS1F8V4ZFZ",
      "expanded_url" : "http:\/\/www.moodlenews.com\/2014\/moodle-gets-a-bootstrap-3-parent-theme\/",
      "display_url" : "moodlenews.com\/2014\/moodle-ge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519988315391393793",
  "text" : "Moodle gets a Bootstrap 3 parent theme\u00A0|\u00A0Moodle News http:\/\/t.co\/hS1F8V4ZFZ via @moodlenews",
  "id" : 519988315391393793,
  "created_at" : "2014-10-08 23:10:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 3, 11 ],
      "id_str" : "10675",
      "id" : 10675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 133, 136 ]
    }, {
      "text" : "yvr",
      "indices" : [ 137, 140 ]
    }, {
      "text" : "design",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/qtkvAR7gCe",
      "expanded_url" : "http:\/\/vancouveruxawards.com",
      "display_url" : "vancouveruxawards.com"
    } ]
  },
  "geo" : { },
  "id_str" : "519920151563870210",
  "text" : "RT @gordonr: Vancouver has some brilliant UX design talent. Help us celebrate. Submit your awesomeness here: http:\/\/t.co\/qtkvAR7gCe  #UX #y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 120, 123 ]
      }, {
        "text" : "yvr",
        "indices" : [ 124, 128 ]
      }, {
        "text" : "design",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/qtkvAR7gCe",
        "expanded_url" : "http:\/\/vancouveruxawards.com",
        "display_url" : "vancouveruxawards.com"
      } ]
    },
    "geo" : { },
    "id_str" : "519893722868117504",
    "text" : "Vancouver has some brilliant UX design talent. Help us celebrate. Submit your awesomeness here: http:\/\/t.co\/qtkvAR7gCe  #UX #yvr #design",
    "id" : 519893722868117504,
    "created_at" : "2014-10-08 16:54:57 +0000",
    "user" : {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "protected" : false,
      "id_str" : "10675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723725303218991104\/GhSmJXhv_normal.jpg",
      "id" : 10675,
      "verified" : false
    }
  },
  "id" : 519920151563870210,
  "created_at" : "2014-10-08 18:39:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syncplicity",
      "screen_name" : "syncplicity",
      "indices" : [ 0, 12 ],
      "id_str" : "15184636",
      "id" : 15184636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519887072153591808",
  "in_reply_to_user_id" : 15184636,
  "text" : "@syncplicity Just installed Syncplicity on Mac and PC - is there supposed to be a \"Syncplicity\" folder on the Mac as there is on the PC?",
  "id" : 519887072153591808,
  "created_at" : "2014-10-08 16:28:31 +0000",
  "in_reply_to_screen_name" : "syncplicity",
  "in_reply_to_user_id_str" : "15184636",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Wilcox",
      "screen_name" : "MattWilcox",
      "indices" : [ 3, 14 ],
      "id_str" : "33843",
      "id" : 33843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/xD46SyOkSI",
      "expanded_url" : "http:\/\/seriouspony.com\/trouble-at-the-koolaid-point",
      "display_url" : "seriouspony.com\/trouble-at-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519867936161267712",
  "text" : "RT @MattWilcox: We should stop calling people who do this ( http:\/\/t.co\/xD46SyOkSI ) trolls. It\u2019s a word that makes light of it, and is gam\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/xD46SyOkSI",
        "expanded_url" : "http:\/\/seriouspony.com\/trouble-at-the-koolaid-point",
        "display_url" : "seriouspony.com\/trouble-at-the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "519800467837423616",
    "text" : "We should stop calling people who do this ( http:\/\/t.co\/xD46SyOkSI ) trolls. It\u2019s a word that makes light of it, and is gamified. \u201CAbusers\u201D.",
    "id" : 519800467837423616,
    "created_at" : "2014-10-08 10:44:23 +0000",
    "user" : {
      "name" : "Matt Wilcox",
      "screen_name" : "MattWilcox",
      "protected" : false,
      "id_str" : "33843",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2961155956\/3b5a9b58ac21cbf1fe5cc1f267ecd160_normal.jpeg",
      "id" : 33843,
      "verified" : false
    }
  },
  "id" : 519867936161267712,
  "created_at" : "2014-10-08 15:12:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Serious Pony",
      "screen_name" : "seriouspony",
      "indices" : [ 37, 49 ],
      "id_str" : "122932694",
      "id" : 122932694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/wT2b7wBi5Y",
      "expanded_url" : "http:\/\/seriouspony.com\/trouble-at-the-koolaid-point",
      "display_url" : "seriouspony.com\/trouble-at-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519865546196529153",
  "text" : "RT @waxpancake: So much to say about @seriouspony's story of online harassment. Go read it before it's gone, then read it again. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Serious Pony",
        "screen_name" : "seriouspony",
        "indices" : [ 21, 33 ],
        "id_str" : "122932694",
        "id" : 122932694
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/wT2b7wBi5Y",
        "expanded_url" : "http:\/\/seriouspony.com\/trouble-at-the-koolaid-point",
        "display_url" : "seriouspony.com\/trouble-at-the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "519859835622285313",
    "text" : "So much to say about @seriouspony's story of online harassment. Go read it before it's gone, then read it again. http:\/\/t.co\/wT2b7wBi5Y",
    "id" : 519859835622285313,
    "created_at" : "2014-10-08 14:40:18 +0000",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590385501179289602\/qvTvxmCX_normal.png",
      "id" : 13461,
      "verified" : true
    }
  },
  "id" : 519865546196529153,
  "created_at" : "2014-10-08 15:02:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519619858401472512",
  "text" : "Is it more effective to view the (often dreaded) LMS as a conversation rather than an object? I think this perspective has legs, do you?",
  "id" : 519619858401472512,
  "created_at" : "2014-10-07 22:46:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 3, 18 ],
      "id_str" : "1122631",
      "id" : 1122631
    }, {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 72, 88 ],
      "id_str" : "17349291",
      "id" : 17349291
    }, {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "indices" : [ 89, 96 ],
      "id_str" : "944913038",
      "id" : 944913038
    }, {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 101, 113 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/9w2ugMPozX",
      "expanded_url" : "http:\/\/www.vancouveruxawards.com\/",
      "display_url" : "vancouveruxawards.com"
    } ]
  },
  "geo" : { },
  "id_str" : "519522515706978304",
  "text" : "RT @MalloryOConnor: Launching the inaugural http:\/\/t.co\/9w2ugMPozX with @HabaneroConsult @Van_UE and @openroadies We have such great #UX ta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Habanero",
        "screen_name" : "HabaneroConsult",
        "indices" : [ 52, 68 ],
        "id_str" : "17349291",
        "id" : 17349291
      }, {
        "name" : "VanUE",
        "screen_name" : "Van_UE",
        "indices" : [ 69, 76 ],
        "id_str" : "944913038",
        "id" : 944913038
      }, {
        "name" : "OpenRoad",
        "screen_name" : "openroadies",
        "indices" : [ 81, 93 ],
        "id_str" : "66913866",
        "id" : 66913866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 113, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/9w2ugMPozX",
        "expanded_url" : "http:\/\/www.vancouveruxawards.com\/",
        "display_url" : "vancouveruxawards.com"
      } ]
    },
    "geo" : { },
    "id_str" : "517060739186851840",
    "text" : "Launching the inaugural http:\/\/t.co\/9w2ugMPozX with @HabaneroConsult @Van_UE and @openroadies We have such great #UX talent in this city!",
    "id" : 517060739186851840,
    "created_at" : "2014-09-30 21:17:41 +0000",
    "user" : {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "protected" : false,
      "id_str" : "1122631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2261747531\/mallory_thumbnail_normal.png",
      "id" : 1122631,
      "verified" : false
    }
  },
  "id" : 519522515706978304,
  "created_at" : "2014-10-07 16:19:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Wodtke",
      "screen_name" : "cwodtke",
      "indices" : [ 3, 11 ],
      "id_str" : "1763261",
      "id" : 1763261
    }, {
      "name" : "Serious Pony",
      "screen_name" : "seriouspony",
      "indices" : [ 26, 38 ],
      "id_str" : "122932694",
      "id" : 122932694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518865451523129344",
  "text" : "RT @cwodtke: We have lost @seriouspony because we haven't figured out how to make online social spaces safe. \nWe haven't figured out bc we \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Serious Pony",
        "screen_name" : "seriouspony",
        "indices" : [ 13, 25 ],
        "id_str" : "122932694",
        "id" : 122932694
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518761041644498944",
    "text" : "We have lost @seriouspony because we haven't figured out how to make online social spaces safe. \nWe haven't figured out bc we aren't trying.",
    "id" : 518761041644498944,
    "created_at" : "2014-10-05 13:54:05 +0000",
    "user" : {
      "name" : "Christina Wodtke",
      "screen_name" : "cwodtke",
      "protected" : false,
      "id_str" : "1763261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2287668665\/68xniffgwgsmmjnxxz66_normal.jpeg",
      "id" : 1763261,
      "verified" : false
    }
  },
  "id" : 518865451523129344,
  "created_at" : "2014-10-05 20:48:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517811700884463616",
  "geo" : { },
  "id_str" : "517812868436094976",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob I did not know about CoursePress as I\u2019ve been heads-down in Moodle and Canvas land for the past while. Thanks for the info!",
  "id" : 517812868436094976,
  "in_reply_to_status_id" : 517811700884463616,
  "created_at" : "2014-10-02 23:06:22 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517803431973507073",
  "geo" : { },
  "id_str" : "517811495313227776",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob On a semi-related note, how did your explorations of LearnDash go?",
  "id" : 517811495313227776,
  "in_reply_to_status_id" : 517803431973507073,
  "created_at" : "2014-10-02 23:00:55 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517788875524034561",
  "geo" : { },
  "id_str" : "517790298567897089",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Fair enough, but a lack of learner experience design further decreases the LMS value to the learner. I wonder where the balance is?",
  "id" : 517790298567897089,
  "in_reply_to_status_id" : 517788875524034561,
  "created_at" : "2014-10-02 21:36:41 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517787587038425089",
  "text" : "Coming to the conclusion that all too often the LMS is used as a scapegoat for a lack of learner experience design vision and execution.",
  "id" : 517787587038425089,
  "created_at" : "2014-10-02 21:25:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517730907969843200",
  "text" : "Minimizing the need to use global navigation allows students to remain focused on course content, and helps on small screens even w\/o RWD.",
  "id" : 517730907969843200,
  "created_at" : "2014-10-02 17:40:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/Tcb2ZfW4U9",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/17482\/",
      "display_url" : "canvas.sfu.ca\/courses\/17482\/"
    } ]
  },
  "geo" : { },
  "id_str" : "517729187118206976",
  "text" : "Update to my multi-device friendly #CanvasLMS course companion. Added more navigation support within content. https:\/\/t.co\/Tcb2ZfW4U9",
  "id" : 517729187118206976,
  "created_at" : "2014-10-02 17:33:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MeasuringU",
      "screen_name" : "MeasuringU",
      "indices" : [ 3, 14 ],
      "id_str" : "103951768",
      "id" : 103951768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/LvQU58wGXx",
      "expanded_url" : "http:\/\/ow.ly\/Bl5Wj",
      "display_url" : "ow.ly\/Bl5Wj"
    } ]
  },
  "geo" : { },
  "id_str" : "517368753907310592",
  "text" : "RT @MeasuringU: For Developers, a Little UX can Go a Long Way http:\/\/t.co\/LvQU58wGXx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/LvQU58wGXx",
        "expanded_url" : "http:\/\/ow.ly\/Bl5Wj",
        "display_url" : "ow.ly\/Bl5Wj"
      } ]
    },
    "geo" : { },
    "id_str" : "517366170631290880",
    "text" : "For Developers, a Little UX can Go a Long Way http:\/\/t.co\/LvQU58wGXx",
    "id" : 517366170631290880,
    "created_at" : "2014-10-01 17:31:21 +0000",
    "user" : {
      "name" : "MeasuringU",
      "screen_name" : "MeasuringU",
      "protected" : false,
      "id_str" : "103951768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768568168553910272\/Qigu06V6_normal.jpg",
      "id" : 103951768,
      "verified" : false
    }
  },
  "id" : 517368753907310592,
  "created_at" : "2014-10-01 17:41:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]