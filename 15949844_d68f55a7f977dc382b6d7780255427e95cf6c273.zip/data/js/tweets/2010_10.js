Grailbird.data.tweets_2010_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karo Group",
      "screen_name" : "KaroGroup",
      "indices" : [ 129, 139 ],
      "id_str" : "48536610",
      "id" : 48536610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nonprofits",
      "indices" : [ 12, 23 ]
    }, {
      "text" : "Vancouver",
      "indices" : [ 104, 114 ]
    }, {
      "text" : "Calgary",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29406824421",
  "text" : "Calling all #nonprofits Apply for Karo Kaus, Karo\u2019s $50,000 creative services grant. http:\/\/ow.ly\/32KQ0 #Vancouver #Calgary (via @KaroGroup)",
  "id" : 29406824421,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28911819707",
  "text" : "Enjoyed today's UXmarathon presentation by Rolf Molich on improving usability evaluations http:\/\/uxmarathon.com\/molich.html#",
  "id" : 28911819707,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baldwin",
      "screen_name" : "benry",
      "indices" : [ 3, 9 ],
      "id_str" : "1969441",
      "id" : 1969441
    }, {
      "name" : "UX Magazine",
      "screen_name" : "uxmag",
      "indices" : [ 21, 27 ],
      "id_str" : "15056788",
      "id" : 15056788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28913106009",
  "text" : "RT @benry My article @uxmag is now live: http:\/\/uxmag.com\/design\/plain-language-tenets-in-ux Hear, hear!",
  "id" : 28913106009,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28736392449",
  "text" : "The final slides of my BusinessAnalystWorld presentation about collaborative scenario-based design techniques: http:\/\/slidesha.re\/9fBiYb",
  "id" : 28736392449,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Tomlin",
      "screen_name" : "ctomlin",
      "indices" : [ 88, 96 ],
      "id_str" : "15395410",
      "id" : 15395410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28614097113",
  "text" : "'Usability Inspection of Digital Libraries' by Paterson & Low http:\/\/bit.ly\/dCN9Pg (via @ctomlin) Includes use of ISO 9241-110's principles!",
  "id" : 28614097113,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Tomlin",
      "screen_name" : "ctomlin",
      "indices" : [ 0, 8 ],
      "id_str" : "15395410",
      "id" : 15395410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28635457640",
  "in_reply_to_user_id" : 15395410,
  "text" : "@ctomlin Nice to see you back on Twitter Craig. Thanks so much for all your great finds!",
  "id" : 28635457640,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "ctomlin",
  "in_reply_to_user_id_str" : "15395410",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27844114958",
  "text" : "TEDxCreativeCoast - Jon Kolko - The Phenomenon of Synthesis http:\/\/bit.ly\/cu9kf1 One of my favourite aspects of interaction design!",
  "id" : 27844114958,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 115, 119 ],
      "id_str" : "1063291",
      "id" : 1063291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27484664554",
  "text" : "Finding Q&A breaks every 15-20 mins. during on-line seminars an effective way to keep the audience engaged. Thanks @UIE for the inspiration!",
  "id" : 27484664554,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "concrete5",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27155557369",
  "text" : "Continue to be pleased with using #concrete5 CMS as a virtual learning environment system. Look forward to exploring mobile access options.",
  "id" : 27155557369,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Saffer",
      "screen_name" : "odannyboy",
      "indices" : [ 3, 13 ],
      "id_str" : "3252",
      "id" : 3252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26759586991",
  "text" : "RT @odannyboy I give you: The IxD Library http:\/\/theixdlibrary.com\/ Outstanding resource for usability\/ucd\/ux courses!",
  "id" : 26759586991,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]