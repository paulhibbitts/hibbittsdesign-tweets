Grailbird.data.tweets_2010_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Dragan",
      "screen_name" : "aprilush",
      "indices" : [ 0, 9 ],
      "id_str" : "19180160",
      "id" : 19180160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17373218606",
  "in_reply_to_user_id" : 19180160,
  "text" : "@aprilush Excited to see the announcement of your nepomuk user study - good luck!",
  "id" : 17373218606,
  "created_at" : "2010-06-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "aprilush",
  "in_reply_to_user_id_str" : "19180160",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Snyder",
      "screen_name" : "csnyder",
      "indices" : [ 0, 8 ],
      "id_str" : "14943457",
      "id" : 14943457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16189624687",
  "geo" : { },
  "id_str" : "16227825570",
  "in_reply_to_user_id" : 14943457,
  "text" : "@csnyder Thanks for sharing your thoughts! I find it an interesting issue to consider.",
  "id" : 16227825570,
  "in_reply_to_status_id" : 16189624687,
  "created_at" : "2010-06-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "csnyder",
  "in_reply_to_user_id_str" : "14943457",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Snyder",
      "screen_name" : "csnyder",
      "indices" : [ 0, 8 ],
      "id_str" : "14943457",
      "id" : 14943457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16173835996",
  "geo" : { },
  "id_str" : "16179369311",
  "in_reply_to_user_id" : 14943457,
  "text" : "@csnyder Would you say that length of time + freq of use might provide more meaningful self-assessments? I've also tried descriptive scales.",
  "id" : 16179369311,
  "in_reply_to_status_id" : 16173835996,
  "created_at" : "2010-06-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "csnyder",
  "in_reply_to_user_id_str" : "14943457",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitney Quesenbery",
      "screen_name" : "whitneyq",
      "indices" : [ 59, 68 ],
      "id_str" : "16949684",
      "id" : 16949684
    }, {
      "name" : "David Travis",
      "screen_name" : "userfocus",
      "indices" : [ 96, 106 ],
      "id_str" : "16509110",
      "id" : 16509110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 44, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15939852299",
  "text" : "Using stories for a better user experience. #ux article by @whitneyq. http:\/\/bit.ly\/bir35U (via @userfocus)",
  "id" : 15939852299,
  "created_at" : "2010-06-11 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "D8",
      "indices" : [ 29, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15228285321",
  "text" : "Favourite quote from Jobs at #D8 tonight\" \"I think PCs are going to be like trucks. Less people will need them.\"",
  "id" : 15228285321,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]