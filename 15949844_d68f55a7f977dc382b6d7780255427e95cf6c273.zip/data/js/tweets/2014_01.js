Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429387376700301312",
  "text" : "Thinking about ways I try to support today's learner: accessibility, cooperation, networks, and personalization. How about you?",
  "id" : 429387376700301312,
  "created_at" : "2014-01-31 22:55:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "indices" : [ 0, 14 ],
      "id_str" : "153597392",
      "id" : 153597392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429361053370032128",
  "geo" : { },
  "id_str" : "429362003237281792",
  "in_reply_to_user_id" : 153597392,
  "text" : "@SFUteachlearn Thanks very much for looking into it - always happy to test things out :-)",
  "id" : 429362003237281792,
  "in_reply_to_status_id" : 429361053370032128,
  "created_at" : "2014-01-31 21:14:13 +0000",
  "in_reply_to_screen_name" : "SFUteachlearn",
  "in_reply_to_user_id_str" : "153597392",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "indices" : [ 0, 14 ],
      "id_str" : "153597392",
      "id" : 153597392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/mTdvm2S024",
      "expanded_url" : "https:\/\/www.sfu.ca\/tlc\/programming\/wiley\/signup.html",
      "display_url" : "sfu.ca\/tlc\/programmin\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "428303261288775680",
  "geo" : { },
  "id_str" : "429357795662516224",
  "in_reply_to_user_id" : 153597392,
  "text" : "@SFUteachlearn Thanks for the update. Still no luck trying to access https:\/\/t.co\/mTdvm2S024 after SFU login (I am off campus).",
  "id" : 429357795662516224,
  "in_reply_to_status_id" : 428303261288775680,
  "created_at" : "2014-01-31 20:57:30 +0000",
  "in_reply_to_screen_name" : "SFUteachlearn",
  "in_reply_to_user_id_str" : "153597392",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/YdqFbClzuN",
      "expanded_url" : "https:\/\/skydrive.live.com\/redir?resid=74D2D06DCB0AFD88!139273&authkey=!AOk1YyDZelkgVfk&ithint=folder%2c.docx",
      "display_url" : "skydrive.live.com\/redir?resid=74\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429041078012891137",
  "text" : "Working on a multi-device learning project? This collection of worksheets for my upcoming course might be helpful. https:\/\/t.co\/YdqFbClzuN",
  "id" : 429041078012891137,
  "created_at" : "2014-01-30 23:58:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Blankenship",
      "screen_name" : "blankenship",
      "indices" : [ 3, 15 ],
      "id_str" : "3238871",
      "id" : 3238871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428929504921124864",
  "text" : "RT @blankenship: Sure, the design problems are harder, but \u201CNo one\u2019s going to _______ on mobile\u201D sets you up for missed opportunities and u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428928297863368704",
    "text" : "Sure, the design problems are harder, but \u201CNo one\u2019s going to _______ on mobile\u201D sets you up for missed opportunities and underserved people.",
    "id" : 428928297863368704,
    "created_at" : "2014-01-30 16:30:49 +0000",
    "user" : {
      "name" : "Joshua Blankenship",
      "screen_name" : "blankenship",
      "protected" : false,
      "id_str" : "3238871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763765118207401985\/MiAZ2TB3_normal.jpg",
      "id" : 3238871,
      "verified" : false
    }
  },
  "id" : 428929504921124864,
  "created_at" : "2014-01-30 16:35:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UBC Robson Square",
      "screen_name" : "UBCRobsonSquare",
      "indices" : [ 86, 102 ],
      "id_str" : "210914069",
      "id" : 210914069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/IAThcqT8GK",
      "expanded_url" : "http:\/\/www.mindmeister.com\/352789915\/designing-the-learner-experience-for-a-multi-device-world-topic-map",
      "display_url" : "mindmeister.com\/352789915\/desi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428640220070674432",
  "text" : "First draft topic map for upcoming Designing Multi-device Learning Experiences course @UBCRobsonSquare this Spring http:\/\/t.co\/IAThcqT8GK",
  "id" : 428640220070674432,
  "created_at" : "2014-01-29 21:26:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428617568358633472",
  "text" : "Trying to capture the essence of creating a (multi-device) learning strategy: the classic 5 W's and one H looks like a promising framework.",
  "id" : 428617568358633472,
  "created_at" : "2014-01-29 19:56:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "indices" : [ 0, 14 ],
      "id_str" : "153597392",
      "id" : 153597392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428303261288775680",
  "geo" : { },
  "id_str" : "428335236548526080",
  "in_reply_to_user_id" : 153597392,
  "text" : "@SFUteachlearn Thanks very much, but sorry to say still no luck :-(",
  "id" : 428335236548526080,
  "in_reply_to_status_id" : 428303261288775680,
  "created_at" : "2014-01-29 01:14:13 +0000",
  "in_reply_to_screen_name" : "SFUteachlearn",
  "in_reply_to_user_id_str" : "153597392",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428280389816164352",
  "text" : "Who in my Twitterverse is actually doing mobile\/multi-device Web learning (and not just writting about it)? Would love to share experiences!",
  "id" : 428280389816164352,
  "created_at" : "2014-01-28 21:36:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Warren H. Wong",
      "screen_name" : "WarrenWong",
      "indices" : [ 3, 14 ],
      "id_str" : "18263142",
      "id" : 18263142
    }, {
      "name" : "Appnovation",
      "screen_name" : "Appnovation",
      "indices" : [ 35, 47 ],
      "id_str" : "28170359",
      "id" : 28170359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/MEFRZCjSxD",
      "expanded_url" : "http:\/\/www.appnovation.com\/blog\/meet-team-five-ws-maryam-najafian",
      "display_url" : "appnovation.com\/blog\/meet-team\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428212800922456065",
  "text" : "RT @WarrenWong: We're still hiring @appnovation.   Join out team and work with cool people like Maryam http:\/\/t.co\/MEFRZCjSxD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Appnovation",
        "screen_name" : "Appnovation",
        "indices" : [ 19, 31 ],
        "id_str" : "28170359",
        "id" : 28170359
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/MEFRZCjSxD",
        "expanded_url" : "http:\/\/www.appnovation.com\/blog\/meet-team-five-ws-maryam-najafian",
        "display_url" : "appnovation.com\/blog\/meet-team\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "428056054824333312",
    "text" : "We're still hiring @appnovation.   Join out team and work with cool people like Maryam http:\/\/t.co\/MEFRZCjSxD",
    "id" : 428056054824333312,
    "created_at" : "2014-01-28 06:44:51 +0000",
    "user" : {
      "name" : "Warren H. Wong",
      "screen_name" : "WarrenWong",
      "protected" : false,
      "id_str" : "18263142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/96335661\/DSC_0868__3__normal.jpg",
      "id" : 18263142,
      "verified" : false
    }
  },
  "id" : 428212800922456065,
  "created_at" : "2014-01-28 17:07:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "indices" : [ 0, 14 ],
      "id_str" : "153597392",
      "id" : 153597392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427950635107880961",
  "geo" : { },
  "id_str" : "427952092594982912",
  "in_reply_to_user_id" : 153597392,
  "text" : "@SFUteachlearn Thanks very much! More than happy to test any updates, etc. :-)",
  "id" : 427952092594982912,
  "in_reply_to_status_id" : 427950635107880961,
  "created_at" : "2014-01-27 23:51:44 +0000",
  "in_reply_to_screen_name" : "SFUteachlearn",
  "in_reply_to_user_id_str" : "153597392",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "indices" : [ 0, 14 ],
      "id_str" : "153597392",
      "id" : 153597392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427947863998345217",
  "geo" : { },
  "id_str" : "427949531531972609",
  "in_reply_to_user_id" : 153597392,
  "text" : "@SFUteachlearn Thanks. I am using my Computing ID, which works also for Connect. When I go to Sign In and enter credentials it just hangs\u2026",
  "id" : 427949531531972609,
  "in_reply_to_status_id" : 427947863998345217,
  "created_at" : "2014-01-27 23:41:33 +0000",
  "in_reply_to_screen_name" : "SFUteachlearn",
  "in_reply_to_user_id_str" : "153597392",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "indices" : [ 0, 14 ],
      "id_str" : "153597392",
      "id" : 153597392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427922568129949696",
  "geo" : { },
  "id_str" : "427947024655200256",
  "in_reply_to_user_id" : 153597392,
  "text" : "@SFUteachlearn I seem to keep getting an error when I try to signup though, is the Wiley project signup page accessible off-campus?",
  "id" : 427947024655200256,
  "in_reply_to_status_id" : 427922568129949696,
  "created_at" : "2014-01-27 23:31:36 +0000",
  "in_reply_to_screen_name" : "SFUteachlearn",
  "in_reply_to_user_id_str" : "153597392",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Responsive Design",
      "screen_name" : "RWD",
      "indices" : [ 3, 7 ],
      "id_str" : "348664405",
      "id" : 348664405
    }, {
      "name" : "Ben Callahan",
      "screen_name" : "bencallahan",
      "indices" : [ 70, 82 ],
      "id_str" : "14105473",
      "id" : 14105473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/Of4x7ueaYU",
      "expanded_url" : "http:\/\/www.creativebloq.com\/business\/what-responsive-web-design-means-team-organisation-11410353",
      "display_url" : "creativebloq.com\/business\/what-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427944175711969280",
  "text" : "RT @RWD: \u201CResponsive design is a catalyst for organizational change.\u201D @bencallahan on designing teams for multi-device work: http:\/\/t.co\/Of\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Callahan",
        "screen_name" : "bencallahan",
        "indices" : [ 61, 73 ],
        "id_str" : "14105473",
        "id" : 14105473
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/Of4x7ueaYU",
        "expanded_url" : "http:\/\/www.creativebloq.com\/business\/what-responsive-web-design-means-team-organisation-11410353",
        "display_url" : "creativebloq.com\/business\/what-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "425970059656564736",
    "text" : "\u201CResponsive design is a catalyst for organizational change.\u201D @bencallahan on designing teams for multi-device work: http:\/\/t.co\/Of4x7ueaYU",
    "id" : 425970059656564736,
    "created_at" : "2014-01-22 12:35:51 +0000",
    "user" : {
      "name" : "Responsive Design",
      "screen_name" : "RWD",
      "protected" : false,
      "id_str" : "348664405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539462074808561664\/PgmryUKs_normal.png",
      "id" : 348664405,
      "verified" : false
    }
  },
  "id" : 427944175711969280,
  "created_at" : "2014-01-27 23:20:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "indices" : [ 0, 14 ],
      "id_str" : "153597392",
      "id" : 153597392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427922568129949696",
  "geo" : { },
  "id_str" : "427931979539939328",
  "in_reply_to_user_id" : 153597392,
  "text" : "@SFUteachlearn Great to see this being offered!",
  "id" : 427931979539939328,
  "in_reply_to_status_id" : 427922568129949696,
  "created_at" : "2014-01-27 22:31:49 +0000",
  "in_reply_to_screen_name" : "SFUteachlearn",
  "in_reply_to_user_id_str" : "153597392",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/426837243668336640\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/w3umQf8z4C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BexuNiaCUAAhcYn.jpg",
      "id_str" : "426837243546718208",
      "id" : 426837243546718208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BexuNiaCUAAhcYn.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/w3umQf8z4C"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426837243668336640",
  "text" : "Continuing to explore using themes in course creation. 9 so far w Designing Multi-device Learning Experiences course. http:\/\/t.co\/w3umQf8z4C",
  "id" : 426837243668336640,
  "created_at" : "2014-01-24 22:01:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/u8VsqxwRa6",
      "expanded_url" : "http:\/\/www.apple.com\/30-years\/",
      "display_url" : "apple.com\/30-years\/"
    } ]
  },
  "geo" : { },
  "id_str" : "426788636743331840",
  "text" : "As a teenager working at an Apple Dealership in Halifax in 1984 my career arrived in a brown box (inside-out Mac box) http:\/\/t.co\/u8VsqxwRa6",
  "id" : 426788636743331840,
  "created_at" : "2014-01-24 18:48:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426456116520689665",
  "text" : "My four E's of the learner experience: Effort, Engagement, Effective, and Emotion.",
  "id" : 426456116520689665,
  "created_at" : "2014-01-23 20:47:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Qzzr",
      "screen_name" : "Qzzr_",
      "indices" : [ 122, 128 ],
      "id_str" : "2180948154",
      "id" : 2180948154
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quizzes",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/vw8yJCOX3J",
      "expanded_url" : "http:\/\/www.qzzr.co\/quiz\/can-you-identify-the-elearning-bullshit\/shared",
      "display_url" : "qzzr.co\/quiz\/can-you-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426442428778676224",
  "text" : "I got 100% on \u201CCan You Identify the \"elearning\" Bullshit?\u201D on Qzzr! Can you match me? http:\/\/t.co\/vw8yJCOX3J #quizzes via @Qzzr_",
  "id" : 426442428778676224,
  "created_at" : "2014-01-23 19:52:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 77, 89 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Nj6Q8u3oVn",
      "expanded_url" : "http:\/\/kck.st\/1iqVp4Q",
      "display_url" : "kck.st\/1iqVp4Q"
    } ]
  },
  "geo" : { },
  "id_str" : "426441148312207360",
  "text" : "I just backed Unicorn Institute: Courses to shape the future of UX design on @Kickstarter http:\/\/t.co\/Nj6Q8u3oVn",
  "id" : 426441148312207360,
  "created_at" : "2014-01-23 19:47:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/426147983466328064\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/KdHzaXkeri",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ben7VTpCYAEMZ5g.png",
      "id_str" : "426147983231442945",
      "id" : 426147983231442945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ben7VTpCYAEMZ5g.png",
      "sizes" : [ {
        "h" : 3400,
        "resize" : "fit",
        "w" : 2200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1583,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 927,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/KdHzaXkeri"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/lKNWfvj1SO",
      "expanded_url" : "http:\/\/cmpt-363-133.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-133.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "426147983466328064",
  "text" : "In 2013 I experimented with open course creation and delivery http:\/\/t.co\/lKNWfvj1SO Feels right to now share evals! http:\/\/t.co\/KdHzaXkeri",
  "id" : 426147983466328064,
  "created_at" : "2014-01-23 00:22:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Carson",
      "screen_name" : "brandonwcarson",
      "indices" : [ 3, 18 ],
      "id_str" : "6289892",
      "id" : 6289892
    }, {
      "name" : "i4cp",
      "screen_name" : "i4cp",
      "indices" : [ 58, 63 ],
      "id_str" : "10874572",
      "id" : 10874572
    }, {
      "name" : "Qualcomm",
      "screen_name" : "Qualcomm",
      "indices" : [ 79, 88 ],
      "id_str" : "84623395",
      "id" : 84623395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/VFg2i0E0Zg",
      "expanded_url" : "http:\/\/www.brandonwcarson.com\/2014\/01\/the-state-of-mobile-learning-2014-so-far\/",
      "display_url" : "brandonwcarson.com\/2014\/01\/the-st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426112861908111360",
  "text" : "RT @brandonwcarson: The State of Mobile Learning 2014 via @i4cp and the CLO of @Qualcomm: http:\/\/t.co\/VFg2i0E0Zg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "i4cp",
        "screen_name" : "i4cp",
        "indices" : [ 38, 43 ],
        "id_str" : "10874572",
        "id" : 10874572
      }, {
        "name" : "Qualcomm",
        "screen_name" : "Qualcomm",
        "indices" : [ 59, 68 ],
        "id_str" : "84623395",
        "id" : 84623395
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/VFg2i0E0Zg",
        "expanded_url" : "http:\/\/www.brandonwcarson.com\/2014\/01\/the-state-of-mobile-learning-2014-so-far\/",
        "display_url" : "brandonwcarson.com\/2014\/01\/the-st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "426105177863487488",
    "text" : "The State of Mobile Learning 2014 via @i4cp and the CLO of @Qualcomm: http:\/\/t.co\/VFg2i0E0Zg",
    "id" : 426105177863487488,
    "created_at" : "2014-01-22 21:32:45 +0000",
    "user" : {
      "name" : "Brandon Carson",
      "screen_name" : "brandonwcarson",
      "protected" : false,
      "id_str" : "6289892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632923196140974080\/YmdjsKuV_normal.jpg",
      "id" : 6289892,
      "verified" : false
    }
  },
  "id" : 426112861908111360,
  "created_at" : "2014-01-22 22:03:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426101677565833216",
  "text" : "To me, teaching is:creating a narrative, content curation, interaction, giving feedback, being accessible, &amp; networked learning. And to you?",
  "id" : 426101677565833216,
  "created_at" : "2014-01-22 21:18:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Maeda",
      "screen_name" : "johnmaeda",
      "indices" : [ 3, 13 ],
      "id_str" : "15414807",
      "id" : 15414807
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnmaeda\/status\/423480685991440387\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/fEVORF4r1K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeCBcKXCYAACkM7.jpg",
      "id_str" : "423480685790126080",
      "id" : 423480685790126080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeCBcKXCYAACkM7.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/fEVORF4r1K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426040367893315584",
  "text" : "RT @johnmaeda: To make something more meaningful with tech, you need to know what's meaningful without tech. http:\/\/t.co\/fEVORF4r1K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/johnmaeda\/status\/423480685991440387\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/fEVORF4r1K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeCBcKXCYAACkM7.jpg",
        "id_str" : "423480685790126080",
        "id" : 423480685790126080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeCBcKXCYAACkM7.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/fEVORF4r1K"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423480685991440387",
    "text" : "To make something more meaningful with tech, you need to know what's meaningful without tech. http:\/\/t.co\/fEVORF4r1K",
    "id" : 423480685991440387,
    "created_at" : "2014-01-15 15:43:58 +0000",
    "user" : {
      "name" : "John Maeda",
      "screen_name" : "johnmaeda",
      "protected" : false,
      "id_str" : "15414807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749782211054952448\/_qeErSoY_normal.jpg",
      "id" : 15414807,
      "verified" : true
    }
  },
  "id" : 426040367893315584,
  "created_at" : "2014-01-22 17:15:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brilliant Ads",
      "screen_name" : "Brilliant_Ads",
      "indices" : [ 3, 17 ],
      "id_str" : "564686965",
      "id" : 564686965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/lMvQaPVI42",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=R706isyDrqI",
      "display_url" : "youtube.com\/watch?v=R706is\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426009269066952704",
  "text" : "RT @Brilliant_Ads: Apple's famous '1984' commercial, introducing Macintosh, broadcast during Super Bowl XVIII, 30 years ago today: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/lMvQaPVI42",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=R706isyDrqI",
        "display_url" : "youtube.com\/watch?v=R706is\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "425988056983027712",
    "text" : "Apple's famous '1984' commercial, introducing Macintosh, broadcast during Super Bowl XVIII, 30 years ago today: http:\/\/t.co\/lMvQaPVI42",
    "id" : 425988056983027712,
    "created_at" : "2014-01-22 13:47:21 +0000",
    "user" : {
      "name" : "Brilliant Ads",
      "screen_name" : "Brilliant_Ads",
      "protected" : false,
      "id_str" : "564686965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568757608471736320\/HVxk-qDA_normal.jpeg",
      "id" : 564686965,
      "verified" : false
    }
  },
  "id" : 426009269066952704,
  "created_at" : "2014-01-22 15:11:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 93, 107 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Will Richardson",
      "screen_name" : "willrich45",
      "indices" : [ 109, 120 ],
      "id_str" : "1349941",
      "id" : 1349941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/DRqWWcp0vb",
      "expanded_url" : "http:\/\/bit.ly\/1hfEL4I",
      "display_url" : "bit.ly\/1hfEL4I"
    } ]
  },
  "geo" : { },
  "id_str" : "425758615920574464",
  "text" : "RT @clintlalonde: Just signed up for Educating Modern Learners. Some great edu thinkers like @audreywatters, @willrich45 behind project htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 75, 89 ],
        "id_str" : "25388528",
        "id" : 25388528
      }, {
        "name" : "Will Richardson",
        "screen_name" : "willrich45",
        "indices" : [ 91, 102 ],
        "id_str" : "1349941",
        "id" : 1349941
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/DRqWWcp0vb",
        "expanded_url" : "http:\/\/bit.ly\/1hfEL4I",
        "display_url" : "bit.ly\/1hfEL4I"
      } ]
    },
    "geo" : { },
    "id_str" : "425753934246854656",
    "text" : "Just signed up for Educating Modern Learners. Some great edu thinkers like @audreywatters, @willrich45 behind project http:\/\/t.co\/DRqWWcp0vb",
    "id" : 425753934246854656,
    "created_at" : "2014-01-21 22:17:02 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 425758615920574464,
  "created_at" : "2014-01-21 22:35:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Kessler",
      "screen_name" : "dkdsgn",
      "indices" : [ 3, 10 ],
      "id_str" : "2505183032",
      "id" : 2505183032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424344142513045504",
  "text" : "RT @dkdsgn: Post-CES Samsung Android screen sizes:\n2.8\n3\n3.2\n3.4\n3.5\n3.65\n3.7\n3.8\n4\n4.27\n4.3\n4.5\n4.6\n4.65\n4.7\n4.8\n4.99\n5\n5.5\n5.7\n6.3\n7\n8\n8.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423939036097429504",
    "text" : "Post-CES Samsung Android screen sizes:\n2.8\n3\n3.2\n3.4\n3.5\n3.65\n3.7\n3.8\n4\n4.27\n4.3\n4.5\n4.6\n4.65\n4.7\n4.8\n4.99\n5\n5.5\n5.7\n6.3\n7\n8\n8.4\n10.1\n12.2",
    "id" : 423939036097429504,
    "created_at" : "2014-01-16 22:05:17 +0000",
    "user" : {
      "name" : "D\u039ER\u039EK \u26A1 K\u039ESSL\u039ER",
      "screen_name" : "derekakessler",
      "protected" : false,
      "id_str" : "67721376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458748180310413312\/gJv0iCFJ_normal.jpeg",
      "id" : 67721376,
      "verified" : false
    }
  },
  "id" : 424344142513045504,
  "created_at" : "2014-01-18 00:55:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/160u0z2baC",
      "expanded_url" : "http:\/\/serendip.brynmawr.edu\/exchange\/node\/8430",
      "display_url" : "serendip.brynmawr.edu\/exchange\/node\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424293473454284800",
  "text" : "Thinking about emotion and (blended) learning these days. Have any favorite articles? Here is a recent find of mine: http:\/\/t.co\/160u0z2baC",
  "id" : 424293473454284800,
  "created_at" : "2014-01-17 21:33:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Canadian Web Hosting",
      "screen_name" : "cawebhosting",
      "indices" : [ 0, 13 ],
      "id_str" : "65774919",
      "id" : 65774919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423879975305875457",
  "geo" : { },
  "id_str" : "423880669471596544",
  "in_reply_to_user_id" : 65774919,
  "text" : "@cawebhosting Thanks for the update, everything looks good.",
  "id" : 423880669471596544,
  "in_reply_to_status_id" : 423879975305875457,
  "created_at" : "2014-01-16 18:13:21 +0000",
  "in_reply_to_screen_name" : "cawebhosting",
  "in_reply_to_user_id_str" : "65774919",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Canadian Web Hosting",
      "screen_name" : "cawebhosting",
      "indices" : [ 0, 13 ],
      "id_str" : "65774919",
      "id" : 65774919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/O4VVy3Czr9",
      "expanded_url" : "http:\/\/cmpt-363-133.hibbittsdesign.com",
      "display_url" : "cmpt-363-133.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "423628948363169792",
  "in_reply_to_user_id" : 65774919,
  "text" : "@cawebhosting Is there something up with the server for http:\/\/t.co\/O4VVy3Czr9 ? I keep getting timeouts.",
  "id" : 423628948363169792,
  "created_at" : "2014-01-16 01:33:06 +0000",
  "in_reply_to_screen_name" : "cawebhosting",
  "in_reply_to_user_id_str" : "65774919",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423500351547777024",
  "text" : "Key factors for a successful mentorship? For me: aligned goals, appropriate skills gap, and compatible communication styes. How about you?",
  "id" : 423500351547777024,
  "created_at" : "2014-01-15 17:02:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 0, 11 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423236031693877248",
  "geo" : { },
  "id_str" : "423239338957107201",
  "in_reply_to_user_id" : 217880712,
  "text" : "@jimbobtyer Thanks James, it was awesome to meet and chat with you! I will be in touch again very soon.",
  "id" : 423239338957107201,
  "in_reply_to_status_id" : 423236031693877248,
  "created_at" : "2014-01-14 23:44:56 +0000",
  "in_reply_to_screen_name" : "jimbobtyer",
  "in_reply_to_user_id_str" : "217880712",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/amgkmuzvLm",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1fVuKhTdZEvKDeneGpLHDz1tWV4yDwjgxne24G9j0SC4\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1fV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423161952722878464",
  "text" : "Updated course description (with commenting enabled) for Designing Multi-device Learning Experiences: https:\/\/t.co\/amgkmuzvLm",
  "id" : 423161952722878464,
  "created_at" : "2014-01-14 18:37:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everett McKay",
      "screen_name" : "UXDesignEdge",
      "indices" : [ 3, 16 ],
      "id_str" : "205411420",
      "id" : 205411420
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ui",
      "indices" : [ 96, 99 ]
    }, {
      "text" : "ux",
      "indices" : [ 100, 103 ]
    }, {
      "text" : "uxdesign",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/KZKfrioYq6",
      "expanded_url" : "http:\/\/ux-poll.com",
      "display_url" : "ux-poll.com"
    } ]
  },
  "geo" : { },
  "id_str" : "423157598481694721",
  "text" : "RT @UXDesignEdge: Vote for the most under appreciated UI in this week's http:\/\/t.co\/KZKfrioYq6. #ui #ux #uxdesign",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ui",
        "indices" : [ 78, 81 ]
      }, {
        "text" : "ux",
        "indices" : [ 82, 85 ]
      }, {
        "text" : "uxdesign",
        "indices" : [ 86, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/KZKfrioYq6",
        "expanded_url" : "http:\/\/ux-poll.com",
        "display_url" : "ux-poll.com"
      } ]
    },
    "geo" : { },
    "id_str" : "422978966945685505",
    "text" : "Vote for the most under appreciated UI in this week's http:\/\/t.co\/KZKfrioYq6. #ui #ux #uxdesign",
    "id" : 422978966945685505,
    "created_at" : "2014-01-14 06:30:18 +0000",
    "user" : {
      "name" : "Everett McKay",
      "screen_name" : "UXDesignEdge",
      "protected" : false,
      "id_str" : "205411420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000149771048\/61b261f6ae826532a06e5acdda953c15_normal.png",
      "id" : 205411420,
      "verified" : false
    }
  },
  "id" : 423157598481694721,
  "created_at" : "2014-01-14 18:20:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/bJzRGfbIrx",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Kano_model",
      "display_url" : "en.wikipedia.org\/wiki\/Kano_model"
    } ]
  },
  "geo" : { },
  "id_str" : "423152438485336064",
  "text" : "I don\u2019t see responsive web design as a competitive advantage anymore. RWD (or equivalent) is a \u201Cmust-be quality\u201D now. http:\/\/t.co\/bJzRGfbIrx",
  "id" : 423152438485336064,
  "created_at" : "2014-01-14 17:59:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Grigsby, \u26014",
      "screen_name" : "grigs",
      "indices" : [ 3, 9 ],
      "id_str" : "5774462",
      "id" : 5774462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/jga25LbZKC",
      "expanded_url" : "http:\/\/feedly.com\/k\/1eOQjKL",
      "display_url" : "feedly.com\/k\/1eOQjKL"
    } ]
  },
  "geo" : { },
  "id_str" : "422767684955029504",
  "text" : "RT @grigs: People swap devices 21 times an hour http:\/\/t.co\/jga25LbZKC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/jga25LbZKC",
        "expanded_url" : "http:\/\/feedly.com\/k\/1eOQjKL",
        "display_url" : "feedly.com\/k\/1eOQjKL"
      } ]
    },
    "geo" : { },
    "id_str" : "422750868320952320",
    "text" : "People swap devices 21 times an hour http:\/\/t.co\/jga25LbZKC",
    "id" : 422750868320952320,
    "created_at" : "2014-01-13 15:23:56 +0000",
    "user" : {
      "name" : "Jason Grigsby, \u26014",
      "screen_name" : "grigs",
      "protected" : false,
      "id_str" : "5774462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694573720606605312\/j_l6cQVS_normal.jpg",
      "id" : 5774462,
      "verified" : false
    }
  },
  "id" : 422767684955029504,
  "created_at" : "2014-01-13 16:30:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Morrison",
      "screen_name" : "onlinelearningI",
      "indices" : [ 3, 19 ],
      "id_str" : "105007386",
      "id" : 105007386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/DVxLAT2z98",
      "expanded_url" : "http:\/\/shar.es\/9P0Xm",
      "display_url" : "shar.es\/9P0Xm"
    } ]
  },
  "geo" : { },
  "id_str" : "422763722793172992",
  "text" : "RT @onlinelearningI: Very good report by McKinsey: How to help students make the most of their education... http:\/\/t.co\/DVxLAT2z98",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/DVxLAT2z98",
        "expanded_url" : "http:\/\/shar.es\/9P0Xm",
        "display_url" : "shar.es\/9P0Xm"
      } ]
    },
    "geo" : { },
    "id_str" : "422762707020812289",
    "text" : "Very good report by McKinsey: How to help students make the most of their education... http:\/\/t.co\/DVxLAT2z98",
    "id" : 422762707020812289,
    "created_at" : "2014-01-13 16:10:58 +0000",
    "user" : {
      "name" : "Debbie Morrison",
      "screen_name" : "onlinelearningI",
      "protected" : false,
      "id_str" : "105007386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505024123706163200\/J--oZYHj_normal.jpeg",
      "id" : 105007386,
      "verified" : false
    }
  },
  "id" : 422763722793172992,
  "created_at" : "2014-01-13 16:15:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Instone",
      "screen_name" : "keithinstone",
      "indices" : [ 3, 16 ],
      "id_str" : "8735782",
      "id" : 8735782
    }, {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "indices" : [ 36, 44 ],
      "id_str" : "15022225",
      "id" : 15022225
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UXCareerDev",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/vp5EtrkrXx",
      "expanded_url" : "http:\/\/www.nngroup.com\/articles\/ux-career-advice\/",
      "display_url" : "nngroup.com\/articles\/ux-ca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422762807776403456",
  "text" : "RT @keithinstone: #UXCareerDev from @NNgroup http:\/\/t.co\/vp5EtrkrXx Survey of career satisfaction, diversity, backgrounds, getting started.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nielsen Norman Group",
        "screen_name" : "NNgroup",
        "indices" : [ 18, 26 ],
        "id_str" : "15022225",
        "id" : 15022225
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UXCareerDev",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/vp5EtrkrXx",
        "expanded_url" : "http:\/\/www.nngroup.com\/articles\/ux-career-advice\/",
        "display_url" : "nngroup.com\/articles\/ux-ca\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "422744908512784384",
    "text" : "#UXCareerDev from @NNgroup http:\/\/t.co\/vp5EtrkrXx Survey of career satisfaction, diversity, backgrounds, getting started. Free download.",
    "id" : 422744908512784384,
    "created_at" : "2014-01-13 15:00:15 +0000",
    "user" : {
      "name" : "Keith Instone",
      "screen_name" : "keithinstone",
      "protected" : false,
      "id_str" : "8735782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531175848423215105\/KCQQMGjo_normal.jpeg",
      "id" : 8735782,
      "verified" : false
    }
  },
  "id" : 422762807776403456,
  "created_at" : "2014-01-13 16:11:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Jursa",
      "screen_name" : "IATV",
      "indices" : [ 3, 8 ],
      "id_str" : "17151314",
      "id" : 17151314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/LOyaIKlKzS",
      "expanded_url" : "http:\/\/bit.ly\/1hoHU5i",
      "display_url" : "bit.ly\/1hoHU5i"
    }, {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/QxhCLZTBao",
      "expanded_url" : "http:\/\/mutuallyhuman.com",
      "display_url" : "mutuallyhuman.com"
    } ]
  },
  "geo" : { },
  "id_str" : "420952858427539456",
  "text" : "RT @IATV: \"The Ethos of Responsive Design\" http:\/\/t.co\/LOyaIKlKzS (http:\/\/t.co\/QxhCLZTBao)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/LOyaIKlKzS",
        "expanded_url" : "http:\/\/bit.ly\/1hoHU5i",
        "display_url" : "bit.ly\/1hoHU5i"
      }, {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/QxhCLZTBao",
        "expanded_url" : "http:\/\/mutuallyhuman.com",
        "display_url" : "mutuallyhuman.com"
      } ]
    },
    "geo" : { },
    "id_str" : "420952082796273664",
    "text" : "\"The Ethos of Responsive Design\" http:\/\/t.co\/LOyaIKlKzS (http:\/\/t.co\/QxhCLZTBao)",
    "id" : 420952082796273664,
    "created_at" : "2014-01-08 16:16:12 +0000",
    "user" : {
      "name" : "Jan Jursa",
      "screen_name" : "IATV",
      "protected" : false,
      "id_str" : "17151314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466681693235982336\/4v-lZ2o2_normal.jpeg",
      "id" : 17151314,
      "verified" : false
    }
  },
  "id" : 420952858427539456,
  "created_at" : "2014-01-08 16:19:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "indices" : [ 3, 13 ],
      "id_str" : "18983561",
      "id" : 18983561
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/basbrands\/status\/420154009497141248\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Fk49XhvGJh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdSv2G6IgAAxu4C.jpg",
      "id_str" : "420154009354534912",
      "id" : 420154009354534912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdSv2G6IgAAxu4C.jpg",
      "sizes" : [ {
        "h" : 392,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/Fk49XhvGJh"
    } ],
    "hashtags" : [ {
      "text" : "moodle",
      "indices" : [ 19, 26 ]
    }, {
      "text" : "bootstrap3",
      "indices" : [ 46, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/vUVM207nSf",
      "expanded_url" : "https:\/\/github.com\/bmbrands\/theme_bootstrap",
      "display_url" : "github.com\/bmbrands\/theme\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420721051677364225",
  "text" : "RT @basbrands: New #moodle  Beta theme to use #bootstrap3. Still a work in process but already available on https:\/\/t.co\/vUVM207nSf http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/basbrands\/status\/420154009497141248\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Fk49XhvGJh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdSv2G6IgAAxu4C.jpg",
        "id_str" : "420154009354534912",
        "id" : 420154009354534912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdSv2G6IgAAxu4C.jpg",
        "sizes" : [ {
          "h" : 392,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 267,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 392,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 392,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/Fk49XhvGJh"
      } ],
      "hashtags" : [ {
        "text" : "moodle",
        "indices" : [ 4, 11 ]
      }, {
        "text" : "bootstrap3",
        "indices" : [ 31, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/vUVM207nSf",
        "expanded_url" : "https:\/\/github.com\/bmbrands\/theme_bootstrap",
        "display_url" : "github.com\/bmbrands\/theme\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "420154009497141248",
    "text" : "New #moodle  Beta theme to use #bootstrap3. Still a work in process but already available on https:\/\/t.co\/vUVM207nSf http:\/\/t.co\/Fk49XhvGJh",
    "id" : 420154009497141248,
    "created_at" : "2014-01-06 11:24:56 +0000",
    "user" : {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "protected" : false,
      "id_str" : "18983561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570499815742521344\/KPZ0dxP5_normal.png",
      "id" : 18983561,
      "verified" : false
    }
  },
  "id" : 420721051677364225,
  "created_at" : "2014-01-08 00:58:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420672194834739200",
  "text" : "Love this quote from Michael Allen that I just heard today - \u201C \u2026 implement the experiences that are worth the learner\u2019s time\u201D Well said!",
  "id" : 420672194834739200,
  "created_at" : "2014-01-07 21:44:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((patlockley)))",
      "screen_name" : "patlockley",
      "indices" : [ 0, 11 ],
      "id_str" : "18833145",
      "id" : 18833145
    }, {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 12, 19 ],
      "id_str" : "10817782",
      "id" : 10817782
    }, {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 20, 27 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "Colin Madland",
      "screen_name" : "colinmadland",
      "indices" : [ 28, 41 ],
      "id_str" : "81038069",
      "id" : 81038069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420656753282256897",
  "geo" : { },
  "id_str" : "420662428137836544",
  "in_reply_to_user_id" : 18833145,
  "text" : "@patlockley @tanbob @brlamb @colinmadland Sounds good to my ears :-)",
  "id" : 420662428137836544,
  "in_reply_to_status_id" : 420656753282256897,
  "created_at" : "2014-01-07 21:05:13 +0000",
  "in_reply_to_screen_name" : "patlockley",
  "in_reply_to_user_id_str" : "18833145",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    }, {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 8, 15 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "Colin Madland",
      "screen_name" : "colinmadland",
      "indices" : [ 16, 29 ],
      "id_str" : "81038069",
      "id" : 81038069
    }, {
      "name" : "(((patlockley)))",
      "screen_name" : "patlockley",
      "indices" : [ 30, 41 ],
      "id_str" : "18833145",
      "id" : 18833145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420652083411288066",
  "geo" : { },
  "id_str" : "420653578911375360",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob @brlamb @colinmadland @patlockley Love to know how it goes! LearnDash is theme independent, so responsive multi-device possible too.",
  "id" : 420653578911375360,
  "in_reply_to_status_id" : 420652083411288066,
  "created_at" : "2014-01-07 20:30:03 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlearning",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/lOIdx5s9Kb",
      "expanded_url" : "http:\/\/sdrv.ms\/1aBPDoK",
      "display_url" : "sdrv.ms\/1aBPDoK"
    } ]
  },
  "geo" : { },
  "id_str" : "420309290096672768",
  "text" : "Draft course description for Designing Multi-device Learning Experiences: http:\/\/t.co\/lOIdx5s9Kb Any comments or suggestions? #mlearning",
  "id" : 420309290096672768,
  "created_at" : "2014-01-06 21:41:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 0, 7 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 8, 15 ],
      "id_str" : "10817782",
      "id" : 10817782
    }, {
      "name" : "(((patlockley)))",
      "screen_name" : "patlockley",
      "indices" : [ 16, 27 ],
      "id_str" : "18833145",
      "id" : 18833145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420279586945900544",
  "geo" : { },
  "id_str" : "420282266024022016",
  "in_reply_to_user_id" : 745903,
  "text" : "@brlamb @tanbob @patlockley CourSys lets me avoid storing student info\/docs on my own server, but does require an additional SFU log-in",
  "id" : 420282266024022016,
  "in_reply_to_status_id" : 420279586945900544,
  "created_at" : "2014-01-06 19:54:35 +0000",
  "in_reply_to_screen_name" : "brlamb",
  "in_reply_to_user_id_str" : "745903",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 0, 12 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420281168689246208",
  "geo" : { },
  "id_str" : "420281649058693121",
  "in_reply_to_user_id" : 6271482,
  "text" : "@grantpotter I believe it is homegrown and hosted at SFU. It is quite old now, and they are looking for a replacement\u2026",
  "id" : 420281649058693121,
  "in_reply_to_status_id" : 420281168689246208,
  "created_at" : "2014-01-06 19:52:08 +0000",
  "in_reply_to_screen_name" : "grantpotter",
  "in_reply_to_user_id_str" : "6271482",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 0, 12 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/h83wigoU1g",
      "expanded_url" : "http:\/\/websurvey.sfu.ca\/survey\/147465893",
      "display_url" : "websurvey.sfu.ca\/survey\/1474658\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "420278955740889088",
  "geo" : { },
  "id_str" : "420280609290731520",
  "in_reply_to_user_id" : 6271482,
  "text" : "@grantpotter Choose WS as it supports SFU authentication and of course Canadian host. Very basic - here is a sample http:\/\/t.co\/h83wigoU1g",
  "id" : 420280609290731520,
  "in_reply_to_status_id" : 420278955740889088,
  "created_at" : "2014-01-06 19:48:00 +0000",
  "in_reply_to_screen_name" : "grantpotter",
  "in_reply_to_user_id_str" : "6271482",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    }, {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 8, 15 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "(((patlockley)))",
      "screen_name" : "patlockley",
      "indices" : [ 16, 27 ],
      "id_str" : "18833145",
      "id" : 18833145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/zW8VZrS34p",
      "expanded_url" : "http:\/\/www.sfu.ca\/itservices\/publishing\/websurvey.html",
      "display_url" : "sfu.ca\/itservices\/pub\u2026"
    }, {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/lKNWfvj1SO",
      "expanded_url" : "http:\/\/cmpt-363-133.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-133.hibbittsdesign.com"
    } ]
  },
  "in_reply_to_status_id_str" : "420268306122039296",
  "geo" : { },
  "id_str" : "420277964849156096",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob @brlamb @patlockley Almost used LD last term but ended up w. WebSurvey http:\/\/t.co\/zW8VZrS34p &amp; WP\/PageLines http:\/\/t.co\/lKNWfvj1SO",
  "id" : 420277964849156096,
  "in_reply_to_status_id" : 420268306122039296,
  "created_at" : "2014-01-06 19:37:29 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    }, {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 8, 15 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "(((patlockley)))",
      "screen_name" : "patlockley",
      "indices" : [ 16, 27 ],
      "id_str" : "18833145",
      "id" : 18833145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/rhlGKAyxsH",
      "expanded_url" : "http:\/\/www.learndash.com\/",
      "display_url" : "learndash.com"
    } ]
  },
  "in_reply_to_status_id_str" : "420256070108323840",
  "geo" : { },
  "id_str" : "420260819729788928",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob @brlamb @patlockley Have you also seen LearnDash? http:\/\/t.co\/rhlGKAyxsH",
  "id" : 420260819729788928,
  "in_reply_to_status_id" : 420256070108323840,
  "created_at" : "2014-01-06 18:29:22 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Mark Bullen)))",
      "screen_name" : "markbullen",
      "indices" : [ 0, 11 ],
      "id_str" : "14080697",
      "id" : 14080697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419614750595506176",
  "geo" : { },
  "id_str" : "419617685672972288",
  "in_reply_to_user_id" : 14080697,
  "text" : "@markbullen Try here: ~\/Library\/Containers\/com.apple.BKAgentService\/Data\/Documents\/iBooks",
  "id" : 419617685672972288,
  "in_reply_to_status_id" : 419614750595506176,
  "created_at" : "2014-01-04 23:53:47 +0000",
  "in_reply_to_screen_name" : "markbullen",
  "in_reply_to_user_id_str" : "14080697",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Historical Pics",
      "screen_name" : "HistoricalPics",
      "indices" : [ 3, 18 ],
      "id_str" : "1598644159",
      "id" : 1598644159
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HistoricalPics\/status\/419449414533783552\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/yHUiB5C9lJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdIvBSMIUAAHqla.jpg",
      "id_str" : "419449414407966720",
      "id" : 419449414407966720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdIvBSMIUAAHqla.jpg",
      "sizes" : [ {
        "h" : 451,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 690,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 690,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 690,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/yHUiB5C9lJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419514188998795264",
  "text" : "RT @HistoricalPics: A 5 megabyte IBM hard disk is loaded into an airplane. It weighed over 1000kg, 1956. http:\/\/t.co\/yHUiB5C9lJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HistoricalPics\/status\/419449414533783552\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/yHUiB5C9lJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdIvBSMIUAAHqla.jpg",
        "id_str" : "419449414407966720",
        "id" : 419449414407966720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdIvBSMIUAAHqla.jpg",
        "sizes" : [ {
          "h" : 451,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 690,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 690,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 690,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/yHUiB5C9lJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "419449414533783552",
    "text" : "A 5 megabyte IBM hard disk is loaded into an airplane. It weighed over 1000kg, 1956. http:\/\/t.co\/yHUiB5C9lJ",
    "id" : 419449414533783552,
    "created_at" : "2014-01-04 12:45:08 +0000",
    "user" : {
      "name" : "Historical Pics",
      "screen_name" : "HistoricalPics",
      "protected" : false,
      "id_str" : "1598644159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000427629583\/884341028bb46b82f4dc8743b9ad24d7_normal.jpeg",
      "id" : 1598644159,
      "verified" : false
    }
  },
  "id" : 419514188998795264,
  "created_at" : "2014-01-04 17:02:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiz Beretta",
      "screen_name" : "tizberetta",
      "indices" : [ 0, 11 ],
      "id_str" : "32661922",
      "id" : 32661922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419241939108511744",
  "geo" : { },
  "id_str" : "419242846755909632",
  "in_reply_to_user_id" : 32661922,
  "text" : "@tizberetta Thanks Tiz! Happy new year!!",
  "id" : 419242846755909632,
  "in_reply_to_status_id" : 419241939108511744,
  "created_at" : "2014-01-03 23:04:18 +0000",
  "in_reply_to_screen_name" : "tizberetta",
  "in_reply_to_user_id_str" : "32661922",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419241163711713280",
  "text" : "What makes a learner happy?",
  "id" : 419241163711713280,
  "created_at" : "2014-01-03 22:57:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Klement",
      "screen_name" : "alanklement",
      "indices" : [ 40, 52 ],
      "id_str" : "19033970",
      "id" : 19033970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/TLfPpnH6vW",
      "expanded_url" : "http:\/\/insideintercom.io\/using-job-stories-design-features-ui-ux\/",
      "display_url" : "insideintercom.io\/using-job-stor\u2026"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/2hlSEPEI5L",
      "expanded_url" : "http:\/\/sdrv.ms\/1dtvmpV",
      "display_url" : "sdrv.ms\/1dtvmpV"
    } ]
  },
  "geo" : { },
  "id_str" : "419162920430231552",
  "text" : "Designing Features Using Job Stories by @alanklement  http:\/\/t.co\/TLfPpnH6vW Prefer it over my own earlier template http:\/\/t.co\/2hlSEPEI5L",
  "id" : 419162920430231552,
  "created_at" : "2014-01-03 17:46:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/4AG2ckmqJJ",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/067b6c39-5ce0-b223-aa77-37eb0fabcbc9\/",
      "display_url" : "workflowy.com\/shared\/067b6c3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418893142385889280",
  "text" : "Limiting each 3 hr. class to 3 themes helps me improve focus and flow. Designing Multi-device Learning Experiences https:\/\/t.co\/4AG2ckmqJJ",
  "id" : 418893142385889280,
  "created_at" : "2014-01-02 23:54:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]