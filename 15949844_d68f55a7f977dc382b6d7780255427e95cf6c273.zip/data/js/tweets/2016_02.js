Grailbird.data.tweets_2016_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 11, 19 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/O66lntUSDV",
      "expanded_url" : "http:\/\/1drv.ms\/1ndclQG",
      "display_url" : "1drv.ms\/1ndclQG"
    } ]
  },
  "geo" : { },
  "id_str" : "704442624107610112",
  "text" : "Planning a @getgrav CMS workshop?\n\u2713HTML slides\n\u2713Sample screenshots\n\u2713Two Skeletons, with Admin Plugin\n\u2713Mac\/PC apps\nhttps:\/\/t.co\/O66lntUSDV",
  "id" : 704442624107610112,
  "created_at" : "2016-02-29 23:06:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 84, 92 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 117, 127 ]
    }, {
      "text" : "D2L",
      "indices" : [ 128, 132 ]
    }, {
      "text" : "Moodle",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704378373758275585",
  "text" : "Grav Course Hub Getting Started Guide, for instructors wanting to flip the LMS with @getgrav https:\/\/t.co\/VgQsw7bHP4 #CanvasLMS #D2L #Moodle",
  "id" : 704378373758275585,
  "created_at" : "2016-02-29 18:51:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704378317403615232",
  "text" : "(3\/3) What to flip the LMS with?\nAn open + collaborative platform, where course participants can shape and contribute to their online space.",
  "id" : 704378317403615232,
  "created_at" : "2016-02-29 18:50:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704378278706941952",
  "text" : "(2\/3) Why flip the LMS?\n\u2713 to reach unmet pedagogical goals\n\u2713 to increase access, sharing, and collaboration\n\u2713 a better experience for all",
  "id" : 704378278706941952,
  "created_at" : "2016-02-29 18:50:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704378236889792512",
  "text" : "(1\/3) A flipped-LMS is where a platform chosen by the instructor, under their full control, serves as an alternative front-end to the LMS.",
  "id" : 704378236889792512,
  "created_at" : "2016-02-29 18:50:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 19, 27 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 94, 107 ],
      "id_str" : "12991032",
      "id" : 12991032
    }, {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 108, 120 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/US60aUAAVK",
      "expanded_url" : "https:\/\/twitter.com\/drchuck\/status\/704169535180566528",
      "display_url" : "twitter.com\/drchuck\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704355260890898432",
  "text" : "Thanks for sharing @drchuck, looks quite interesting esp. portability &amp; data housing. cc\/ @clintlalonde @grantpotter https:\/\/t.co\/US60aUAAVK",
  "id" : 704355260890898432,
  "created_at" : "2016-02-29 17:19:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "indices" : [ 0, 11 ],
      "id_str" : "27633854",
      "id" : 27633854
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 12, 20 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704155999884541952",
  "geo" : { },
  "id_str" : "704156479549353984",
  "in_reply_to_user_id" : 27633854,
  "text" : "@JustStormy @getgrav Thanks very much Melissa!",
  "id" : 704156479549353984,
  "in_reply_to_status_id" : 704155999884541952,
  "created_at" : "2016-02-29 04:09:21 +0000",
  "in_reply_to_screen_name" : "JustStormy",
  "in_reply_to_user_id_str" : "27633854",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 24, 32 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/9PFedwpqcF",
      "expanded_url" : "https:\/\/getgrav.org\/downloads\/skeletons",
      "display_url" : "getgrav.org\/downloads\/skel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704108185209032705",
  "text" : "Well, it's official: my @getgrav skeleton to support a flipped-LMS is now called 'Course Hub', and is available at https:\/\/t.co\/9PFedwpqcF \uD83D\uDE4C",
  "id" : 704108185209032705,
  "created_at" : "2016-02-29 00:57:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 3, 13 ],
      "id_str" : "8198012",
      "id" : 8198012
    }, {
      "name" : "joe posner",
      "screen_name" : "joeposner",
      "indices" : [ 66, 76 ],
      "id_str" : "15637568",
      "id" : 15637568
    }, {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 81, 91 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704061443340050432",
  "text" : "RT @romanmars: I just released the \"Norman Door\" video episode by @joeposner for @voxdotcom on the podcast feed. Refresh your feed!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "joe posner",
        "screen_name" : "joeposner",
        "indices" : [ 51, 61 ],
        "id_str" : "15637568",
        "id" : 15637568
      }, {
        "name" : "Vox",
        "screen_name" : "voxdotcom",
        "indices" : [ 66, 76 ],
        "id_str" : "2347049341",
        "id" : 2347049341
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703672833180762112",
    "text" : "I just released the \"Norman Door\" video episode by @joeposner for @voxdotcom on the podcast feed. Refresh your feed!",
    "id" : 703672833180762112,
    "created_at" : "2016-02-27 20:07:31 +0000",
    "user" : {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "protected" : false,
      "id_str" : "8198012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1300364633\/Twitter_Icon_normal.jpg",
      "id" : 8198012,
      "verified" : true
    }
  },
  "id" : 704061443340050432,
  "created_at" : "2016-02-28 21:51:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EDUKWEST",
      "screen_name" : "edukwest",
      "indices" : [ 3, 12 ],
      "id_str" : "63241187",
      "id" : 63241187
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/6Q1PZlQrGR",
      "expanded_url" : "http:\/\/bit.ly\/1S1H4O2",
      "display_url" : "bit.ly\/1S1H4O2"
    } ]
  },
  "geo" : { },
  "id_str" : "704024761911767040",
  "text" : "RT @edukwest: The Last Days of the Monolithic LMS https:\/\/t.co\/6Q1PZlQrGR #edtech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 60, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/6Q1PZlQrGR",
        "expanded_url" : "http:\/\/bit.ly\/1S1H4O2",
        "display_url" : "bit.ly\/1S1H4O2"
      } ]
    },
    "geo" : { },
    "id_str" : "704022883664797696",
    "text" : "The Last Days of the Monolithic LMS https:\/\/t.co\/6Q1PZlQrGR #edtech",
    "id" : 704022883664797696,
    "created_at" : "2016-02-28 19:18:30 +0000",
    "user" : {
      "name" : "EDUKWEST",
      "screen_name" : "edukwest",
      "protected" : false,
      "id_str" : "63241187",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615848656709619712\/Xb6593hO_normal.jpg",
      "id" : 63241187,
      "verified" : false
    }
  },
  "id" : 704024761911767040,
  "created_at" : "2016-02-28 19:25:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Buxton",
      "screen_name" : "wasbuxton",
      "indices" : [ 0, 10 ],
      "id_str" : "57046779",
      "id" : 57046779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703607714115616769",
  "geo" : { },
  "id_str" : "703641294648713216",
  "in_reply_to_user_id" : 57046779,
  "text" : "@wasbuxton I hope you have a speedy recovery!",
  "id" : 703641294648713216,
  "in_reply_to_status_id" : 703607714115616769,
  "created_at" : "2016-02-27 18:02:12 +0000",
  "in_reply_to_screen_name" : "wasbuxton",
  "in_reply_to_user_id_str" : "57046779",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 104, 112 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 113, 123 ]
    }, {
      "text" : "D2L",
      "indices" : [ 124, 128 ]
    }, {
      "text" : "Moodle",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/jqQHqddup9",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-18-flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703286722356850689",
  "text" : "Updated Post: Flipped-LMS Approach Using an Open and Collaborative Web Platform https:\/\/t.co\/jqQHqddup9 #GravEdu #CanvasLMS #D2L #Moodle",
  "id" : 703286722356850689,
  "created_at" : "2016-02-26 18:33:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 40, 47 ],
      "id_str" : "236846178",
      "id" : 236846178
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 55, 63 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/zeRpRmRdRS",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-course-companion",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/uFAW2h9ZCW",
      "expanded_url" : "https:\/\/twitter.com\/clintlalonde\/status\/702920377538719744",
      "display_url" : "twitter.com\/clintlalonde\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702986159358476289",
  "text" : "Two projects in the spirit of NGDLE are @elmsln and my @getgrav Course Hub https:\/\/t.co\/zeRpRmRdRS. What others? https:\/\/t.co\/uFAW2h9ZCW",
  "id" : 702986159358476289,
  "created_at" : "2016-02-25 22:38:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Richards",
      "screen_name" : "vancouverjulian",
      "indices" : [ 3, 19 ],
      "id_str" : "1143584377",
      "id" : 1143584377
    }, {
      "name" : "TELUS digital",
      "screen_name" : "telusdigital",
      "indices" : [ 105, 118 ],
      "id_str" : "3023244921",
      "id" : 3023244921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ECommerce",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/14NI099h4d",
      "expanded_url" : "http:\/\/labs.telus.com\/interaction-designer-contractvancouver\/",
      "display_url" : "labs.telus.com\/interaction-de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702911759682633729",
  "text" : "RT @vancouverjulian: IxD with #ECommerce or transactional design skills? apply for our contract position @telusdigital ! https:\/\/t.co\/14NI0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TELUS digital",
        "screen_name" : "telusdigital",
        "indices" : [ 84, 97 ],
        "id_str" : "3023244921",
        "id" : 3023244921
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ECommerce",
        "indices" : [ 9, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/14NI099h4d",
        "expanded_url" : "http:\/\/labs.telus.com\/interaction-designer-contractvancouver\/",
        "display_url" : "labs.telus.com\/interaction-de\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702911590224367616",
    "text" : "IxD with #ECommerce or transactional design skills? apply for our contract position @telusdigital ! https:\/\/t.co\/14NI099h4d",
    "id" : 702911590224367616,
    "created_at" : "2016-02-25 17:42:37 +0000",
    "user" : {
      "name" : "Julian Richards",
      "screen_name" : "vancouverjulian",
      "protected" : false,
      "id_str" : "1143584377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649336071872868352\/FcHByrAJ_normal.jpg",
      "id" : 1143584377,
      "verified" : false
    }
  },
  "id" : 702911759682633729,
  "created_at" : "2016-02-25 17:43:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 0, 8 ],
      "id_str" : "5690792",
      "id" : 5690792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702749211893342208",
  "geo" : { },
  "id_str" : "702902511724724225",
  "in_reply_to_user_id" : 5690792,
  "text" : "@draggin What a nicely written tagline \uD83D\uDE00 Thanks very much for the feedback, looks like Hub is the one esp. with the brevity you mention.",
  "id" : 702902511724724225,
  "in_reply_to_status_id" : 702749211893342208,
  "created_at" : "2016-02-25 17:06:32 +0000",
  "in_reply_to_screen_name" : "draggin",
  "in_reply_to_user_id_str" : "5690792",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702740866905968640",
  "geo" : { },
  "id_str" : "702902155015954433",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Thanks very much Glen, that's helpful info to know. Looks like it is going to be Course Hub for the 1.0 \uD83D\uDE00",
  "id" : 702902155015954433,
  "in_reply_to_status_id" : 702740866905968640,
  "created_at" : "2016-02-25 17:05:07 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Gadikian",
      "screen_name" : "jacobgadikian",
      "indices" : [ 0, 14 ],
      "id_str" : "5533262",
      "id" : 5533262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/2Vp4bYtd2j",
      "expanded_url" : "http:\/\/demo.hibbittsdesign.org\/grav-course-companion-bv\/",
      "display_url" : "demo.hibbittsdesign.org\/grav-course-co\u2026"
    }, {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/2hkdxVTvJK",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-course-companion\/blob\/master\/README.md",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "702643348889186305",
  "geo" : { },
  "id_str" : "702644498375901185",
  "in_reply_to_user_id" : 5533262,
  "text" : "@jacobgadikian Thanks for asking. I've got a demo at https:\/\/t.co\/2Vp4bYtd2j and intial docs at https:\/\/t.co\/2hkdxVTvJK Comments welcome!",
  "id" : 702644498375901185,
  "in_reply_to_status_id" : 702643348889186305,
  "created_at" : "2016-02-25 00:01:17 +0000",
  "in_reply_to_screen_name" : "jacobgadikian",
  "in_reply_to_user_id_str" : "5533262",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702639713715245056",
  "text" : "So far \"Course Hub\" seems to be hitting the mark more than \"Course Companion\" for the name of my open-source Grav CMS package.. and you?",
  "id" : 702639713715245056,
  "created_at" : "2016-02-24 23:42:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 14, 19 ]
    }, {
      "text" : "FoL16",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/2juI1xjpfm",
      "expanded_url" : "http:\/\/ow.ly\/YrU7j",
      "display_url" : "ow.ly\/YrU7j"
    } ]
  },
  "geo" : { },
  "id_str" : "702627420080181248",
  "text" : "RT @BCcampus: #ETUG Spring 2016 Call for Proposals: Education &amp; Technology Studio https:\/\/t.co\/2juI1xjpfm #FoL16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ETUG",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "FoL16",
        "indices" : [ 96, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/2juI1xjpfm",
        "expanded_url" : "http:\/\/ow.ly\/YrU7j",
        "display_url" : "ow.ly\/YrU7j"
      } ]
    },
    "geo" : { },
    "id_str" : "702621884102348800",
    "text" : "#ETUG Spring 2016 Call for Proposals: Education &amp; Technology Studio https:\/\/t.co\/2juI1xjpfm #FoL16",
    "id" : 702621884102348800,
    "created_at" : "2016-02-24 22:31:25 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 702627420080181248,
  "created_at" : "2016-02-24 22:53:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 0, 11 ],
      "id_str" : "91634720",
      "id" : 91634720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702598487158845440",
  "geo" : { },
  "id_str" : "702598840302456832",
  "in_reply_to_user_id" : 91634720,
  "text" : "@kenjeffery Thanks very much for sharing your thoughts, greatly appreciated!",
  "id" : 702598840302456832,
  "in_reply_to_status_id" : 702598487158845440,
  "created_at" : "2016-02-24 20:59:51 +0000",
  "in_reply_to_screen_name" : "kenjeffery",
  "in_reply_to_user_id_str" : "91634720",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698302358577545216",
  "geo" : { },
  "id_str" : "702595869296623617",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Any thoughts about the label \"Course Hub\" vs. \"Course Companion\" for my Grav package?",
  "id" : 702595869296623617,
  "in_reply_to_status_id" : 698302358577545216,
  "created_at" : "2016-02-24 20:48:03 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 0, 11 ],
      "id_str" : "91634720",
      "id" : 91634720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699352354106126336",
  "geo" : { },
  "id_str" : "702595747737268224",
  "in_reply_to_user_id" : 91634720,
  "text" : "@kenjeffery Any thoughts about the label \"Course Hub\" vs. \"Course Companion\" for my Grav package?",
  "id" : 702595747737268224,
  "in_reply_to_status_id" : 699352354106126336,
  "created_at" : "2016-02-24 20:47:34 +0000",
  "in_reply_to_screen_name" : "kenjeffery",
  "in_reply_to_user_id_str" : "91634720",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702593708860911618",
  "geo" : { },
  "id_str" : "702594710037106688",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv Thanks for the feedback too!",
  "id" : 702594710037106688,
  "in_reply_to_status_id" : 702593708860911618,
  "created_at" : "2016-02-24 20:43:27 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702593708860911618",
  "geo" : { },
  "id_str" : "702594184302080000",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv By quite a bit really \uD83D\uDE04",
  "id" : 702594184302080000,
  "in_reply_to_status_id" : 702593708860911618,
  "created_at" : "2016-02-24 20:41:21 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702593200276402176",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv Any thoughts about the label \"Course Hub\" vs. \"Course Companion\" for my Grav package?",
  "id" : 702593200276402176,
  "created_at" : "2016-02-24 20:37:27 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 0, 8 ],
      "id_str" : "5690792",
      "id" : 5690792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702593094919663618",
  "in_reply_to_user_id" : 5690792,
  "text" : "@draggin Any thoughts about the label \"Course Hub\" vs. \"Course Companion\" for my Grav package?",
  "id" : 702593094919663618,
  "created_at" : "2016-02-24 20:37:02 +0000",
  "in_reply_to_screen_name" : "draggin",
  "in_reply_to_user_id_str" : "5690792",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/preROHHJho",
      "expanded_url" : "https:\/\/twitter.com\/Jisc\/status\/702587385134096385",
      "display_url" : "twitter.com\/Jisc\/status\/70\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702588700622893056",
  "text" : "This. https:\/\/t.co\/preROHHJho",
  "id" : 702588700622893056,
  "created_at" : "2016-02-24 20:19:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    }, {
      "name" : "Emma Irwin",
      "screen_name" : "sunnydeveloper",
      "indices" : [ 42, 57 ],
      "id_str" : "109086082",
      "id" : 109086082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/2Vp4bYtd2j",
      "expanded_url" : "http:\/\/demo.hibbittsdesign.org\/grav-course-companion-bv\/",
      "display_url" : "demo.hibbittsdesign.org\/grav-course-co\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "702568665338638336",
  "geo" : { },
  "id_str" : "702573612738306048",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Please get in touch with me @sunnydeveloper if I can be of any help. Demo site w. GitHub page editing: https:\/\/t.co\/2Vp4bYtd2j",
  "id" : 702573612738306048,
  "in_reply_to_status_id" : 702568665338638336,
  "created_at" : "2016-02-24 19:19:37 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Kapeli",
      "screen_name" : "kapeli",
      "indices" : [ 85, 92 ],
      "id_str" : "175264452",
      "id" : 175264452
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/702563117163622400\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/hWTB5i4yiI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcABbqtUkAIa5-R.png",
      "id_str" : "702563116702273538",
      "id" : 702563116702273538,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcABbqtUkAIa5-R.png",
      "sizes" : [ {
        "h" : 688,
        "resize" : "fit",
        "w" : 788
      }, {
        "h" : 688,
        "resize" : "fit",
        "w" : 788
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 688,
        "resize" : "fit",
        "w" : 788
      }, {
        "h" : 594,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/hWTB5i4yiI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702565113799114752",
  "text" : "RT @getgrav: Hey Grav community, we need your help to get Grav added to Dash Docs by @kapeli. Dash users click here: https:\/\/t.co\/hWTB5i4yiI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kapeli",
        "screen_name" : "kapeli",
        "indices" : [ 72, 79 ],
        "id_str" : "175264452",
        "id" : 175264452
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/702563117163622400\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/hWTB5i4yiI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcABbqtUkAIa5-R.png",
        "id_str" : "702563116702273538",
        "id" : 702563116702273538,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcABbqtUkAIa5-R.png",
        "sizes" : [ {
          "h" : 688,
          "resize" : "fit",
          "w" : 788
        }, {
          "h" : 688,
          "resize" : "fit",
          "w" : 788
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 688,
          "resize" : "fit",
          "w" : 788
        }, {
          "h" : 594,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/hWTB5i4yiI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702563117163622400",
    "text" : "Hey Grav community, we need your help to get Grav added to Dash Docs by @kapeli. Dash users click here: https:\/\/t.co\/hWTB5i4yiI",
    "id" : 702563117163622400,
    "created_at" : "2016-02-24 18:37:54 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 702565113799114752,
  "created_at" : "2016-02-24 18:45:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 59, 67 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702549625413087232",
  "text" : "Hey Twitterverse, any thoughts\/feedback on the name for my @getgrav flipped-LMS course website project? \"Course Companion\" vs. \"Course Hub\"?",
  "id" : 702549625413087232,
  "created_at" : "2016-02-24 17:44:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Eric J. Gruber",
      "screen_name" : "ericjgruber",
      "indices" : [ 8, 20 ],
      "id_str" : "162050684",
      "id" : 162050684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702547272714870789",
  "geo" : { },
  "id_str" : "702548173072441344",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @ericjgruber GitHub stars as birthday gifts is actually a pretty awesome idea \uD83D\uDE00",
  "id" : 702548173072441344,
  "in_reply_to_status_id" : 702547272714870789,
  "created_at" : "2016-02-24 17:38:31 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Eric J. Gruber",
      "screen_name" : "ericjgruber",
      "indices" : [ 8, 20 ],
      "id_str" : "162050684",
      "id" : 162050684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702547272714870789",
  "geo" : { },
  "id_str" : "702547480265633797",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @ericjgruber LOL Consider it done!",
  "id" : 702547480265633797,
  "in_reply_to_status_id" : 702547272714870789,
  "created_at" : "2016-02-24 17:35:46 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702545690157838336",
  "geo" : { },
  "id_str" : "702546318179192832",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Happy Birthday Bryan!",
  "id" : 702546318179192832,
  "in_reply_to_status_id" : 702545690157838336,
  "created_at" : "2016-02-24 17:31:09 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BCcampus",
      "indices" : [ 19, 28 ]
    }, {
      "text" : "FoL16",
      "indices" : [ 121, 127 ]
    }, {
      "text" : "bcpse",
      "indices" : [ 128, 134 ]
    }, {
      "text" : "yyj",
      "indices" : [ 135, 139 ]
    }, {
      "text" : "yvr",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/xPJb7mYh4M",
      "expanded_url" : "http:\/\/ow.ly\/YHu6g",
      "display_url" : "ow.ly\/YHu6g"
    } ]
  },
  "geo" : { },
  "id_str" : "702511800487546880",
  "text" : "RT @BCcampus: NEW! #BCcampus newsletter: Festival of Learning, 2016\/17 Faculty Fellows and more! https:\/\/t.co\/xPJb7mYh4M #FoL16 #bcpse #yyj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BCcampus",
        "indices" : [ 5, 14 ]
      }, {
        "text" : "FoL16",
        "indices" : [ 107, 113 ]
      }, {
        "text" : "bcpse",
        "indices" : [ 114, 120 ]
      }, {
        "text" : "yyj",
        "indices" : [ 121, 125 ]
      }, {
        "text" : "yvr",
        "indices" : [ 126, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/xPJb7mYh4M",
        "expanded_url" : "http:\/\/ow.ly\/YHu6g",
        "display_url" : "ow.ly\/YHu6g"
      } ]
    },
    "geo" : { },
    "id_str" : "702509350812839937",
    "text" : "NEW! #BCcampus newsletter: Festival of Learning, 2016\/17 Faculty Fellows and more! https:\/\/t.co\/xPJb7mYh4M #FoL16 #bcpse #yyj #yvr",
    "id" : 702509350812839937,
    "created_at" : "2016-02-24 15:04:15 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 702511800487546880,
  "created_at" : "2016-02-24 15:13:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Gentle",
      "screen_name" : "annegentle",
      "indices" : [ 94, 105 ],
      "id_str" : "5666852",
      "id" : 5666852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/cV2Tg8kic1",
      "expanded_url" : "http:\/\/justwriteclick.com\/2015\/12\/17\/why-use-github-as-a-content-management-system\/",
      "display_url" : "justwriteclick.com\/2015\/12\/17\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702245282973511682",
  "text" : "Why use GitHub as a Content Management System? | Just Write Click https:\/\/t.co\/cV2Tg8kic1 via @annegentle",
  "id" : 702245282973511682,
  "created_at" : "2016-02-23 21:34:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "unixstickers",
      "screen_name" : "unixstickers",
      "indices" : [ 82, 95 ],
      "id_str" : "335989008",
      "id" : 335989008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/znHrXSxPDc",
      "expanded_url" : "https:\/\/trello.com\/c\/nPDBh78n",
      "display_url" : "trello.com\/c\/nPDBh78n"
    } ]
  },
  "geo" : { },
  "id_str" : "702229375391936512",
  "text" : "RT @getgrav: With your help we can get Grav stickers available by voting for Grav @unixstickers on Trello https:\/\/t.co\/znHrXSxPDc - Please \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "unixstickers",
        "screen_name" : "unixstickers",
        "indices" : [ 69, 82 ],
        "id_str" : "335989008",
        "id" : 335989008
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/znHrXSxPDc",
        "expanded_url" : "https:\/\/trello.com\/c\/nPDBh78n",
        "display_url" : "trello.com\/c\/nPDBh78n"
      } ]
    },
    "geo" : { },
    "id_str" : "702199671737876480",
    "text" : "With your help we can get Grav stickers available by voting for Grav @unixstickers on Trello https:\/\/t.co\/znHrXSxPDc - Please share!",
    "id" : 702199671737876480,
    "created_at" : "2016-02-23 18:33:42 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 702229375391936512,
  "created_at" : "2016-02-23 20:31:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rubeli",
      "screen_name" : "drubeli",
      "indices" : [ 0, 8 ],
      "id_str" : "17217620",
      "id" : 17217620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Lle9XWLJZY",
      "expanded_url" : "http:\/\/shop.oreilly.com\/product\/0636920035084.do?cmp=tw-design-books-videos-product-lgen_ux_for_beginners__jj",
      "display_url" : "shop.oreilly.com\/product\/063692\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "700014299482165248",
  "geo" : { },
  "id_str" : "702195251209895936",
  "in_reply_to_user_id" : 17217620,
  "text" : "@drubeli I just came across this very recent book which would also partner quite nicely with Dorian Peters book https:\/\/t.co\/Lle9XWLJZY",
  "id" : 702195251209895936,
  "in_reply_to_status_id" : 700014299482165248,
  "created_at" : "2016-02-23 18:16:08 +0000",
  "in_reply_to_screen_name" : "drubeli",
  "in_reply_to_user_id_str" : "17217620",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 108, 118 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/sQQomZWQwz",
      "expanded_url" : "https:\/\/shar.es\/1C0FCn",
      "display_url" : "shar.es\/1C0FCn"
    } ]
  },
  "geo" : { },
  "id_str" : "702194197265149953",
  "text" : "Book Review: UX for Beginners: A Crash Course in 100 Short Lessons :: UXmatters https:\/\/t.co\/sQQomZWQwz via @sharethis",
  "id" : 702194197265149953,
  "created_at" : "2016-02-23 18:11:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beanstalk",
      "screen_name" : "beanstalkapp",
      "indices" : [ 25, 38 ],
      "id_str" : "23161518",
      "id" : 23161518
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 44, 52 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/d7uCbuRZpZ",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-22-using-github-desktop-and-beanstalk-with-Grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702192760837640192",
  "text" : "Using GitHub Desktop and @beanstalkapp with @getgrav CMS https:\/\/t.co\/d7uCbuRZpZ #GravEdu",
  "id" : 702192760837640192,
  "created_at" : "2016-02-23 18:06:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/d7uCbuRZpZ",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-22-using-github-desktop-and-beanstalk-with-Grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701955109576572928",
  "text" : "Monday night sneak peek at my upcoming full nerd-out blog post 'Using GitHub Desktop and Beanstalk with Grav': https:\/\/t.co\/d7uCbuRZpZ",
  "id" : 701955109576572928,
  "created_at" : "2016-02-23 02:21:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/6vpLTHBD4A",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/cnie-2016-flipping-the-lms-with-an-open-and-collaborative-platform",
      "display_url" : "slides.com\/paulhibbitts\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701891645067767808",
  "text" : "Draft 15-minute version of my 'Flip it Good! Flipping the LMS with an Open + Collaborative Platform' presentation: https:\/\/t.co\/6vpLTHBD4A",
  "id" : 701891645067767808,
  "created_at" : "2016-02-22 22:09:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "indices" : [ 0, 12 ],
      "id_str" : "19812150",
      "id" : 19812150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/bsfWR7SDZc",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-01-28-a-brief-presentation-about-flipping-the-lms",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "701881394662772736",
  "geo" : { },
  "id_str" : "701889201453666304",
  "in_reply_to_user_id" : 19812150,
  "text" : "@drtonybates Thanks for the very timely article Tony! Might you have any comments on my recent flipped-LMS approach? https:\/\/t.co\/bsfWR7SDZc",
  "id" : 701889201453666304,
  "in_reply_to_status_id" : 701881394662772736,
  "created_at" : "2016-02-22 22:00:00 +0000",
  "in_reply_to_screen_name" : "drtonybates",
  "in_reply_to_user_id_str" : "19812150",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 40, 48 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "CNIE-RCI\u00C9",
      "screen_name" : "CNIE_RCIE",
      "indices" : [ 65, 75 ],
      "id_str" : "244782783",
      "id" : 244782783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/JL7EGcte7H",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-companion-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701844400918278144",
  "text" : "My flipped-LMS open source project with @getgrav will be part of @CNIE_RCIE \"Knocking Down Walls\" virtual conference https:\/\/t.co\/JL7EGcte7H",
  "id" : 701844400918278144,
  "created_at" : "2016-02-22 19:01:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 22, 30 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Q6kKV4cPSv",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-153\/",
      "display_url" : "paulhibbitts.net\/cmpt-363-153\/"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/NYJ57bF6Uk",
      "expanded_url" : "https:\/\/twitter.com\/skrabut\/status\/701794976041197570",
      "display_url" : "twitter.com\/skrabut\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701830235709308928",
  "text" : "To see my open source @getgrav Course Companion work with #CanvasLMS you can check out https:\/\/t.co\/Q6kKV4cPSv. https:\/\/t.co\/NYJ57bF6Uk",
  "id" : 701830235709308928,
  "created_at" : "2016-02-22 18:05:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Coolidge",
      "screen_name" : "acoolidge",
      "indices" : [ 3, 13 ],
      "id_str" : "17416175",
      "id" : 17416175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 72, 76 ]
    }, {
      "text" : "oer2016",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/KWr5FGc2p7",
      "expanded_url" : "https:\/\/open.bccampus.ca\/2016\/02\/01\/festival-of-learning\/",
      "display_url" : "open.bccampus.ca\/2016\/02\/01\/fes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701827488566026240",
  "text" : "RT @acoolidge: For those interested in participating in another amazing #OER event, check out our Festival of Learning https:\/\/t.co\/KWr5FGc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OER",
        "indices" : [ 57, 61 ]
      }, {
        "text" : "oer2016",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/KWr5FGc2p7",
        "expanded_url" : "https:\/\/open.bccampus.ca\/2016\/02\/01\/festival-of-learning\/",
        "display_url" : "open.bccampus.ca\/2016\/02\/01\/fes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701810416037416960",
    "text" : "For those interested in participating in another amazing #OER event, check out our Festival of Learning https:\/\/t.co\/KWr5FGc2p7 #oer2016",
    "id" : 701810416037416960,
    "created_at" : "2016-02-22 16:46:56 +0000",
    "user" : {
      "name" : "Amanda Coolidge",
      "screen_name" : "acoolidge",
      "protected" : false,
      "id_str" : "17416175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674352077020073984\/88hyOiSP_normal.jpg",
      "id" : 17416175,
      "verified" : false
    }
  },
  "id" : 701827488566026240,
  "created_at" : "2016-02-22 17:54:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 3, 15 ],
      "id_str" : "6271482",
      "id" : 6271482
    }, {
      "name" : "Dave Winer",
      "screen_name" : "davewiner",
      "indices" : [ 22, 32 ],
      "id_str" : "3839",
      "id" : 3839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openweb",
      "indices" : [ 54, 62 ]
    }, {
      "text" : "highered",
      "indices" : [ 87, 96 ]
    }, {
      "text" : "bcpse",
      "indices" : [ 97, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/7RrGr5SSgo",
      "expanded_url" : "http:\/\/scripting.com\/liveblog\/users\/davewiner\/2016\/02\/21\/1045.html",
      "display_url" : "scripting.com\/liveblog\/users\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701811623158091776",
  "text" : "RT @grantpotter: via: @davewiner Universities and the #openweb https:\/\/t.co\/7RrGr5SSgo #highered #bcpse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/known.networkeffects.ca\" rel=\"nofollow\"\u003Eknown-twitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dave Winer",
        "screen_name" : "davewiner",
        "indices" : [ 5, 15 ],
        "id_str" : "3839",
        "id" : 3839
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openweb",
        "indices" : [ 37, 45 ]
      }, {
        "text" : "highered",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bcpse",
        "indices" : [ 80, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/7RrGr5SSgo",
        "expanded_url" : "http:\/\/scripting.com\/liveblog\/users\/davewiner\/2016\/02\/21\/1045.html",
        "display_url" : "scripting.com\/liveblog\/users\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701807690453020673",
    "text" : "via: @davewiner Universities and the #openweb https:\/\/t.co\/7RrGr5SSgo #highered #bcpse",
    "id" : 701807690453020673,
    "created_at" : "2016-02-22 16:36:07 +0000",
    "user" : {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "protected" : false,
      "id_str" : "6271482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639833921228640256\/S63CDenk_normal.jpg",
      "id" : 6271482,
      "verified" : false
    }
  },
  "id" : 701811623158091776,
  "created_at" : "2016-02-22 16:51:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Porter",
      "screen_name" : "dendroglyph",
      "indices" : [ 0, 12 ],
      "id_str" : "15170764",
      "id" : 15170764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691680436683051008",
  "geo" : { },
  "id_str" : "701805961212657664",
  "in_reply_to_user_id" : 15170764,
  "text" : "@dendroglyph Thanks again for sharing this, just got word that my flipped-LMS presentation proposal was accepted \uD83D\uDE00",
  "id" : 701805961212657664,
  "in_reply_to_status_id" : 691680436683051008,
  "created_at" : "2016-02-22 16:29:14 +0000",
  "in_reply_to_screen_name" : "dendroglyph",
  "in_reply_to_user_id_str" : "15170764",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 46, 54 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/QbFCRvRCDB",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-19-ways-to-install-and-maintain-your-grav-site",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701207780737220608",
  "text" : "4 Different Ways to Install and Maintain Your @getgrav CMS Site https:\/\/t.co\/QbFCRvRCDB #GravEdu",
  "id" : 701207780737220608,
  "created_at" : "2016-02-21 00:52:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701085418993881089",
  "geo" : { },
  "id_str" : "701085775937478656",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Awesome! Look forward to hearing how that goes too.",
  "id" : 701085775937478656,
  "in_reply_to_status_id" : 701085418993881089,
  "created_at" : "2016-02-20 16:47:29 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701023820962885633",
  "geo" : { },
  "id_str" : "701085029980504064",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Very nice indeed! I've been using drag and drop for my GitHub release ZIP files for a while so great to see it further implemented\uD83D\uDC4D",
  "id" : 701085029980504064,
  "in_reply_to_status_id" : 701023820962885633,
  "created_at" : "2016-02-20 16:44:31 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/bsfWR7SDZc",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-01-28-a-brief-presentation-about-flipping-the-lms",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700843284285886464",
  "text" : "Updated Post: A Brief Presentation about Flipping the LMS https:\/\/t.co\/bsfWR7SDZc #GravEdu",
  "id" : 700843284285886464,
  "created_at" : "2016-02-20 00:43:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 30, 38 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Slides",
      "screen_name" : "slides",
      "indices" : [ 94, 101 ],
      "id_str" : "813740730",
      "id" : 813740730
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/753qpCWnKz",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators#\/",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700806470418300929",
  "text" : "I think it bodes well that my @getgrav CMS for Educators slides have now over 10,000 views on @slides. https:\/\/t.co\/753qpCWnKz #GravEdu \uD83D\uDC4D",
  "id" : 700806470418300929,
  "created_at" : "2016-02-19 22:17:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aarron Walter",
      "screen_name" : "aarron",
      "indices" : [ 3, 10 ],
      "id_str" : "9463382",
      "id" : 9463382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/k2RRJaRtzy",
      "expanded_url" : "http:\/\/collectui.com\/",
      "display_url" : "collectui.com"
    } ]
  },
  "geo" : { },
  "id_str" : "700785974708559872",
  "text" : "RT @aarron: Boat loads of well categorized UI patterns. https:\/\/t.co\/k2RRJaRtzy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/k2RRJaRtzy",
        "expanded_url" : "http:\/\/collectui.com\/",
        "display_url" : "collectui.com"
      } ]
    },
    "geo" : { },
    "id_str" : "700780983306559488",
    "text" : "Boat loads of well categorized UI patterns. https:\/\/t.co\/k2RRJaRtzy",
    "id" : 700780983306559488,
    "created_at" : "2016-02-19 20:36:20 +0000",
    "user" : {
      "name" : "Aarron Walter",
      "screen_name" : "aarron",
      "protected" : false,
      "id_str" : "9463382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727883346035023874\/pvWNeypQ_normal.jpg",
      "id" : 9463382,
      "verified" : false
    }
  },
  "id" : 700785974708559872,
  "created_at" : "2016-02-19 20:56:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Flello",
      "screen_name" : "kflello",
      "indices" : [ 3, 11 ],
      "id_str" : "256659871",
      "id" : 256659871
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kflello\/status\/700728551062933504\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/nsVNLogrCs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbl85GhUAAA2oao.jpg",
      "id_str" : "700728537477545984",
      "id" : 700728537477545984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbl85GhUAAA2oao.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/nsVNLogrCs"
    } ],
    "hashtags" : [ {
      "text" : "dlconference",
      "indices" : [ 13, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700755026717724672",
  "text" : "RT @kflello: #dlconference Alec Couros keynote https:\/\/t.co\/nsVNLogrCs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kflello\/status\/700728551062933504\/photo\/1",
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/nsVNLogrCs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbl85GhUAAA2oao.jpg",
        "id_str" : "700728537477545984",
        "id" : 700728537477545984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbl85GhUAAA2oao.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/nsVNLogrCs"
      } ],
      "hashtags" : [ {
        "text" : "dlconference",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700728551062933504",
    "text" : "#dlconference Alec Couros keynote https:\/\/t.co\/nsVNLogrCs",
    "id" : 700728551062933504,
    "created_at" : "2016-02-19 17:08:00 +0000",
    "user" : {
      "name" : "Karen Flello",
      "screen_name" : "kflello",
      "protected" : false,
      "id_str" : "256659871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1503650811\/KarenFlello_normal.jpg",
      "id" : 256659871,
      "verified" : false
    }
  },
  "id" : 700755026717724672,
  "created_at" : "2016-02-19 18:53:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amir Khella",
      "screen_name" : "amirkhella",
      "indices" : [ 3, 14 ],
      "id_str" : "7985762",
      "id" : 7985762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "business",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700736410018426881",
  "text" : "RT @amirkhella: The whole point about starting a #business isn't to work less, but to work more on what care about.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "business",
        "indices" : [ 33, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700736269165309952",
    "text" : "The whole point about starting a #business isn't to work less, but to work more on what care about.",
    "id" : 700736269165309952,
    "created_at" : "2016-02-19 17:38:40 +0000",
    "user" : {
      "name" : "Amir Khella",
      "screen_name" : "amirkhella",
      "protected" : false,
      "id_str" : "7985762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000064136776\/0459de9b955462b2a983d29d6dcd3a90_normal.png",
      "id" : 7985762,
      "verified" : false
    }
  },
  "id" : 700736410018426881,
  "created_at" : "2016-02-19 17:39:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/QbFCRvRCDB",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-19-ways-to-install-and-maintain-your-grav-site",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "700512657296617473",
  "geo" : { },
  "id_str" : "700736180447412224",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv OK, I think that article is now fit for human consumption \uD83D\uDE00 https:\/\/t.co\/QbFCRvRCDB Feedback more than welcome!",
  "id" : 700736180447412224,
  "in_reply_to_status_id" : 700512657296617473,
  "created_at" : "2016-02-19 17:38:19 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 66, 74 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/QbFCRvRCDB",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-19-ways-to-install-and-maintain-your-grav-site",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700733146015248384",
  "text" : "New post: 4 Different Ways to Install and Maintain Your (Awesome) @getgrav CMS Site https:\/\/t.co\/QbFCRvRCDB #GravEdu",
  "id" : 700733146015248384,
  "created_at" : "2016-02-19 17:26:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 90, 98 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/QbFCRvRCDB",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-19-ways-to-install-and-maintain-your-grav-site",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700512843372711937",
  "text" : "Thursday night sneak peek at an upcoming post about ways to install the awesome flat-file @getgrav CMS https:\/\/t.co\/QbFCRvRCDB",
  "id" : 700512843372711937,
  "created_at" : "2016-02-19 02:50:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/ZFRF8J5OiM",
      "expanded_url" : "http:\/\/learn.getgrav.org\/basics\/installation#option-1-install-from-zip-package",
      "display_url" : "learn.getgrav.org\/basics\/install\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "700508127842537474",
  "geo" : { },
  "id_str" : "700509917216542720",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv Also see https:\/\/t.co\/ZFRF8J5OiM Grav folder contains invis. config files, so that is why entire folder must be copied.",
  "id" : 700509917216542720,
  "in_reply_to_status_id" : 700508127842537474,
  "created_at" : "2016-02-19 02:39:13 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700508127842537474",
  "geo" : { },
  "id_str" : "700509168604618752",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv Wow, great to see your own Grav site starting to come alive! For server install best to FTP copy ENTIRE Grav site folder.",
  "id" : 700509168604618752,
  "in_reply_to_status_id" : 700508127842537474,
  "created_at" : "2016-02-19 02:36:15 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/QbFCRvRCDB",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-19-ways-to-install-and-maintain-your-grav-site",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "700451821484056577",
  "geo" : { },
  "id_str" : "700507266416398336",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv New blog post with Grav install\/setup options: https:\/\/t.co\/QbFCRvRCDB Do you think this will be helpful for other instructors?",
  "id" : 700507266416398336,
  "in_reply_to_status_id" : 700451821484056577,
  "created_at" : "2016-02-19 02:28:41 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700451821484056577",
  "geo" : { },
  "id_str" : "700453221492400132",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv Hope that those approaches\/levels make sense \uD83D\uDE00",
  "id" : 700453221492400132,
  "in_reply_to_status_id" : 700451821484056577,
  "created_at" : "2016-02-18 22:53:56 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700451821484056577",
  "geo" : { },
  "id_str" : "700453125879009280",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv and update pages using Admin Panel during term, and 3rd level is full-term desktop &lt;-&gt; server sync w. option for student collab.",
  "id" : 700453125879009280,
  "in_reply_to_status_id" : 700451821484056577,
  "created_at" : "2016-02-18 22:53:33 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700451821484056577",
  "geo" : { },
  "id_str" : "700452851873509377",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv 1st level you do everything on web-server, 2nd level you can develop\/test site locally, then push \"term-ready\" site and...",
  "id" : 700452851873509377,
  "in_reply_to_status_id" : 700451821484056577,
  "created_at" : "2016-02-18 22:52:28 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700451821484056577",
  "geo" : { },
  "id_str" : "700452303355006976",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv Yes, that is certainly an option too.",
  "id" : 700452303355006976,
  "in_reply_to_status_id" : 700451821484056577,
  "created_at" : "2016-02-18 22:50:17 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700370586174754817",
  "geo" : { },
  "id_str" : "700451901649743872",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv So perhaps \"lightest\" is Web install only, then next would be Web install + local MAMP mirror, then full collab w. GitHub.",
  "id" : 700451901649743872,
  "in_reply_to_status_id" : 700370586174754817,
  "created_at" : "2016-02-18 22:48:41 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    }, {
      "name" : "Cyberduck",
      "screen_name" : "cyberduckapp",
      "indices" : [ 23, 36 ],
      "id_str" : "235981770",
      "id" : 235981770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700370586174754817",
  "geo" : { },
  "id_str" : "700451423457120256",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv Looks like @cyberduckapp offers the best open source app for 2-day folder sync between local MAMP install and FTP Web-server.",
  "id" : 700451423457120256,
  "in_reply_to_status_id" : 700370586174754817,
  "created_at" : "2016-02-18 22:46:47 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beanstalk",
      "screen_name" : "beanstalkapp",
      "indices" : [ 0, 13 ],
      "id_str" : "23161518",
      "id" : 23161518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700449731114352642",
  "geo" : { },
  "id_str" : "700450823055118336",
  "in_reply_to_user_id" : 23161518,
  "text" : "@beanstalkapp Thanks for letting me know. Your 1 project free plan is also a great way to introduce other instructors to your service!",
  "id" : 700450823055118336,
  "in_reply_to_status_id" : 700449731114352642,
  "created_at" : "2016-02-18 22:44:24 +0000",
  "in_reply_to_screen_name" : "beanstalkapp",
  "in_reply_to_user_id_str" : "23161518",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 70, 78 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/iQDl9mBX65",
      "expanded_url" : "https:\/\/youtu.be\/7uzDewvXkbY",
      "display_url" : "youtu.be\/7uzDewvXkbY"
    } ]
  },
  "geo" : { },
  "id_str" : "700449363181449216",
  "text" : "Use the GitHub Application with Beanstalk https:\/\/t.co\/iQDl9mBX65 via @YouTube",
  "id" : 700449363181449216,
  "created_at" : "2016-02-18 22:38:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 20, 28 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "MAMP",
      "screen_name" : "mamp_en",
      "indices" : [ 43, 51 ],
      "id_str" : "69245216",
      "id" : 69245216
    }, {
      "name" : "Cyberduck",
      "screen_name" : "cyberduckapp",
      "indices" : [ 90, 103 ],
      "id_str" : "235981770",
      "id" : 235981770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700448726737752064",
  "text" : "For a minimal local @getgrav install using @mamp_en for development, plus Web-server sync @cyberduckapp looks to be the leading candidate.",
  "id" : 700448726737752064,
  "created_at" : "2016-02-18 22:36:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beanstalk",
      "screen_name" : "beanstalkapp",
      "indices" : [ 10, 23 ],
      "id_str" : "23161518",
      "id" : 23161518
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 57, 65 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700447867853533184",
  "text" : "Exploring @beanstalkapp for fellow educators to use with @getgrav Course Companion - very nice Git service with FTP deployment built in.",
  "id" : 700447867853533184,
  "created_at" : "2016-02-18 22:32:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mountain Duck",
      "screen_name" : "mountainduckapp",
      "indices" : [ 0, 16 ],
      "id_str" : "3731050157",
      "id" : 3731050157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700430368197861378",
  "in_reply_to_user_id" : 3731050157,
  "text" : "@mountainduckapp Any thoughts about some sort of a pause or sync trigger? Thinking of working on Website locally and then pushing update.",
  "id" : 700430368197861378,
  "created_at" : "2016-02-18 21:23:07 +0000",
  "in_reply_to_screen_name" : "mountainduckapp",
  "in_reply_to_user_id_str" : "3731050157",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/clintlalonde\/status\/700089218400301056\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/NA7RTg4mFL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbc3bwzUAAAHfq-.png",
      "id_str" : "700089217175519232",
      "id" : 700089217175519232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbc3bwzUAAAHfq-.png",
      "sizes" : [ {
        "h" : 314,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NA7RTg4mFL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/2J26MngSKV",
      "expanded_url" : "http:\/\/clintlalonde.net\/2016\/02\/17\/dear-edtech-conferences-try-harder\/",
      "display_url" : "clintlalonde.net\/2016\/02\/17\/dea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700092235442888705",
  "text" : "RT @clintlalonde: Dear EdTech Conferences. Try\u00A0harder. https:\/\/t.co\/2J26MngSKV https:\/\/t.co\/NA7RTg4mFL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/clintlalonde\/status\/700089218400301056\/photo\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/NA7RTg4mFL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbc3bwzUAAAHfq-.png",
        "id_str" : "700089217175519232",
        "id" : 700089217175519232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbc3bwzUAAAHfq-.png",
        "sizes" : [ {
          "h" : 314,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 174,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 308,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/NA7RTg4mFL"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/2J26MngSKV",
        "expanded_url" : "http:\/\/clintlalonde.net\/2016\/02\/17\/dear-edtech-conferences-try-harder\/",
        "display_url" : "clintlalonde.net\/2016\/02\/17\/dea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700089218400301056",
    "text" : "Dear EdTech Conferences. Try\u00A0harder. https:\/\/t.co\/2J26MngSKV https:\/\/t.co\/NA7RTg4mFL",
    "id" : 700089218400301056,
    "created_at" : "2016-02-17 22:47:31 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 700092235442888705,
  "created_at" : "2016-02-17 22:59:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 3, 17 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 41, 45 ]
    }, {
      "text" : "etug",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/0sjYBW3VeU",
      "expanded_url" : "https:\/\/open.bccampus.ca\/2016\/02\/01\/festival-of-learning\/",
      "display_url" : "open.bccampus.ca\/2016\/02\/01\/fes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700052999599583232",
  "text" : "RT @clhendricksbc: Call for proposals on #OER for conference near Vancouver, BC. Been part of #etug before; has been excellent. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OER",
        "indices" : [ 22, 26 ]
      }, {
        "text" : "etug",
        "indices" : [ 75, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/0sjYBW3VeU",
        "expanded_url" : "https:\/\/open.bccampus.ca\/2016\/02\/01\/festival-of-learning\/",
        "display_url" : "open.bccampus.ca\/2016\/02\/01\/fes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700047079691845632",
    "text" : "Call for proposals on #OER for conference near Vancouver, BC. Been part of #etug before; has been excellent. https:\/\/t.co\/0sjYBW3VeU",
    "id" : 700047079691845632,
    "created_at" : "2016-02-17 20:00:04 +0000",
    "user" : {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "protected" : false,
      "id_str" : "260919324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726838525086208000\/46wx7Jih_normal.jpg",
      "id" : 260919324,
      "verified" : false
    }
  },
  "id" : 700052999599583232,
  "created_at" : "2016-02-17 20:23:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 11, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700052597449707521",
  "text" : "Q. In your #edtech experience what % of instructors are:\n\u2713 Unsatisfied w. LMS re: control &amp; flexibility\n\u2713 Web-savvy eg HTML, FTP access, etc",
  "id" : 700052597449707521,
  "created_at" : "2016-02-17 20:22:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    }, {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 12, 20 ],
      "id_str" : "5690792",
      "id" : 5690792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700045342562131968",
  "geo" : { },
  "id_str" : "700050531276853248",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv @draggin Looking forward to hearing your thoughts. Sorry to have missed you yesterday Jason!",
  "id" : 700050531276853248,
  "in_reply_to_status_id" : 700045342562131968,
  "created_at" : "2016-02-17 20:13:47 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699770383960936448",
  "geo" : { },
  "id_str" : "700038189205958656",
  "in_reply_to_user_id" : 15949844,
  "text" : "@okalrelsrv Also revising my standard flipped-LMS approach to using an open Web platform as alternative LMS front-end, with collab optional.",
  "id" : 700038189205958656,
  "in_reply_to_status_id" : 699770383960936448,
  "created_at" : "2016-02-17 19:24:45 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699770383960936448",
  "geo" : { },
  "id_str" : "700037659289214976",
  "in_reply_to_user_id" : 15949844,
  "text" : "@okalrelsrv Looks like FileZilla is a no-go, but interestingly there is an FTP sync extension for Adobe Brackets. What was old is new again!",
  "id" : 700037659289214976,
  "in_reply_to_status_id" : 699770383960936448,
  "created_at" : "2016-02-17 19:22:38 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hope Miller",
      "screen_name" : "aHEMpublishing",
      "indices" : [ 3, 18 ],
      "id_str" : "1299940627",
      "id" : 1299940627
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 37, 42 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Douglas College",
      "screen_name" : "douglascollege",
      "indices" : [ 89, 104 ],
      "id_str" : "18194015",
      "id" : 18194015
    }, {
      "name" : "Academic Technology",
      "screen_name" : "ATS_Douglas",
      "indices" : [ 111, 123 ],
      "id_str" : "2666730674",
      "id" : 2666730674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 144 ],
      "url" : "https:\/\/t.co\/rC0CHt0ZSM",
      "expanded_url" : "https:\/\/etug.ca\/2016\/01\/27\/t-e-l-l-february-blended-by-design-how-inquiry-based-design-is-engaging-faculty-and-students\/",
      "display_url" : "etug.ca\/2016\/01\/27\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700033677401542656",
  "text" : "RT @aHEMpublishing: Don't forget the @ETUG Feb.23 Tell Collaborate session, presented by @douglascollege &amp; @ATS_Douglas: https:\/\/t.co\/rC0CH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 17, 22 ],
        "id_str" : "17102936",
        "id" : 17102936
      }, {
        "name" : "Douglas College",
        "screen_name" : "douglascollege",
        "indices" : [ 69, 84 ],
        "id_str" : "18194015",
        "id" : 18194015
      }, {
        "name" : "Academic Technology",
        "screen_name" : "ATS_Douglas",
        "indices" : [ 91, 103 ],
        "id_str" : "2666730674",
        "id" : 2666730674
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/rC0CHt0ZSM",
        "expanded_url" : "https:\/\/etug.ca\/2016\/01\/27\/t-e-l-l-february-blended-by-design-how-inquiry-based-design-is-engaging-faculty-and-students\/",
        "display_url" : "etug.ca\/2016\/01\/27\/t-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700033175364317185",
    "text" : "Don't forget the @ETUG Feb.23 Tell Collaborate session, presented by @douglascollege &amp; @ATS_Douglas: https:\/\/t.co\/rC0CHt0ZSM",
    "id" : 700033175364317185,
    "created_at" : "2016-02-17 19:04:49 +0000",
    "user" : {
      "name" : "Hope Miller",
      "screen_name" : "aHEMpublishing",
      "protected" : false,
      "id_str" : "1299940627",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530413039602765824\/aaz5p_gf_normal.jpeg",
      "id" : 1299940627,
      "verified" : false
    }
  },
  "id" : 700033677401542656,
  "created_at" : "2016-02-17 19:06:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rubeli",
      "screen_name" : "drubeli",
      "indices" : [ 0, 8 ],
      "id_str" : "17217620",
      "id" : 17217620
    }, {
      "name" : "Dorian Peters",
      "screen_name" : "dorian_peters",
      "indices" : [ 9, 23 ],
      "id_str" : "415293130",
      "id" : 415293130
    }, {
      "name" : "Julie Dirksen",
      "screen_name" : "usablelearning",
      "indices" : [ 56, 71 ],
      "id_str" : "61260256",
      "id" : 61260256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700014299482165248",
  "geo" : { },
  "id_str" : "700016001262317568",
  "in_reply_to_user_id" : 17217620,
  "text" : "@drubeli @dorian_peters I think it pairs very well with @usablelearning's book as a solid foundation of experience design for learning.",
  "id" : 700016001262317568,
  "in_reply_to_status_id" : 700014299482165248,
  "created_at" : "2016-02-17 17:56:35 +0000",
  "in_reply_to_screen_name" : "drubeli",
  "in_reply_to_user_id_str" : "17217620",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699770383960936448",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv Exploring a more 'introductory' method to use FileZilla to mirror (only sync changed files) local Grav install to Web-server \uD83D\uDE00",
  "id" : 699770383960936448,
  "created_at" : "2016-02-17 01:40:35 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699738182208716800",
  "text" : "(4\/4) automatic deployment service with GitHub to enable student collaboration and a highly efficient workflow for instructors. \uD83D\uDE80\n#GravEdu",
  "id" : 699738182208716800,
  "created_at" : "2016-02-16 23:32:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699738153674940416",
  "text" : "(3\/4) the Admin Panel to maintain the site, and a second module about setting up Grav on your local computer and configuring an\n#GravEdu",
  "id" : 699738153674940416,
  "created_at" : "2016-02-16 23:32:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699738122137968640",
  "text" : "(2\/4) I'll be splitting the workshop into two modules; the first to introduce Grav and installing Grav on a Web-server using \n#GravEdu",
  "id" : 699738122137968640,
  "created_at" : "2016-02-16 23:32:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 120, 128 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699738094505848832",
  "text" : "(1\/4) The 1st Grav CMS for Educators workshop is a wrap, and from the looks of it Web-savvy educators are excited about @getgrav! \uD83D\uDC4D\n#GravEdu",
  "id" : 699738094505848832,
  "created_at" : "2016-02-16 23:32:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 35, 43 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "indices" : [ 94, 108 ],
      "id_str" : "153597392",
      "id" : 153597392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699644873205354496",
  "text" : "Today is the day. Giving the first @getgrav CMS for Educators workshop for the great folks at @SFUteachlearn - really looking forward to it!",
  "id" : 699644873205354496,
  "created_at" : "2016-02-16 17:21:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/699392361865076736\/video\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/YpfogxCTd6",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/699391767011930112\/pu\/img\/1ejNzVN1JFryqKuc.jpg",
      "id_str" : "699391767011930112",
      "id" : 699391767011930112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/699391767011930112\/pu\/img\/1ejNzVN1JFryqKuc.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YpfogxCTd6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/JL7EGcKPwh",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-companion-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699392361865076736",
  "text" : "Instructors, and assigned students, can review\/discuss suggested changes and approve them. https:\/\/t.co\/JL7EGcKPwh https:\/\/t.co\/YpfogxCTd6",
  "id" : 699392361865076736,
  "created_at" : "2016-02-16 00:38:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/699391462069260288\/video\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/APIpG4E0SK",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/699391255726272513\/pu\/img\/kNothi9eFjHriXdg.jpg",
      "id_str" : "699391255726272513",
      "id" : 699391255726272513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/699391255726272513\/pu\/img\/kNothi9eFjHriXdg.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/APIpG4E0SK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/JL7EGcte7H",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-companion-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699391462069260288",
  "text" : "With the Grav Course Companion students can shape &amp; control their online course environment https:\/\/t.co\/JL7EGcte7H https:\/\/t.co\/APIpG4E0SK",
  "id" : 699391462069260288,
  "created_at" : "2016-02-16 00:34:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/JL7EGcte7H",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-companion-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699378084470853632",
  "text" : "Support innovation by giving instructors an open platform they fully control, while an LMS still holds student data. https:\/\/t.co\/JL7EGcte7H",
  "id" : 699378084470853632,
  "created_at" : "2016-02-15 23:41:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 0, 11 ],
      "id_str" : "91634720",
      "id" : 91634720
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 39, 54 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/dVqLrq33Kf",
      "expanded_url" : "https:\/\/blog.timowens.io\/get-your-grav-on\/",
      "display_url" : "blog.timowens.io\/get-your-grav-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "699354942952222721",
  "geo" : { },
  "id_str" : "699375180829691904",
  "in_reply_to_user_id" : 91634720,
  "text" : "@kenjeffery I've been super happy with @ReclaimHosting, and they even have a one-click Web install for Grav now https:\/\/t.co\/dVqLrq33Kf.",
  "id" : 699375180829691904,
  "in_reply_to_status_id" : 699354942952222721,
  "created_at" : "2016-02-15 23:30:11 +0000",
  "in_reply_to_screen_name" : "kenjeffery",
  "in_reply_to_user_id_str" : "91634720",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 0, 11 ],
      "id_str" : "91634720",
      "id" : 91634720
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 12, 20 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699352354106126336",
  "geo" : { },
  "id_str" : "699354142377013248",
  "in_reply_to_user_id" : 91634720,
  "text" : "@kenjeffery @getgrav Thanks very much Ken, ready to help you get things started anytime \uD83D\uDE00",
  "id" : 699354142377013248,
  "in_reply_to_status_id" : 699352354106126336,
  "created_at" : "2016-02-15 22:06:35 +0000",
  "in_reply_to_screen_name" : "kenjeffery",
  "in_reply_to_user_id_str" : "91634720",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 45, 53 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 117, 127 ]
    }, {
      "text" : "Moodle",
      "indices" : [ 128, 135 ]
    }, {
      "text" : "DL2",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/JL7EGcte7H",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-companion-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699349250237280256",
  "text" : "As an educator and IxD designer, I built the @getgrav Course Companion to work with your LMS https:\/\/t.co\/JL7EGcte7H #CanvasLMS #Moodle #DL2",
  "id" : 699349250237280256,
  "created_at" : "2016-02-15 21:47:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/699344880980496384\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/fvBYhBEO3M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbSSdogVAAAuS8g.jpg",
      "id_str" : "699344879936143360",
      "id" : 699344879936143360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbSSdogVAAAuS8g.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fvBYhBEO3M"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/699344880980496384\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/fvBYhBEO3M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbSSdlIUUAAmSjJ.jpg",
      "id_str" : "699344879030128640",
      "id" : 699344879030128640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbSSdlIUUAAmSjJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fvBYhBEO3M"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699344880980496384",
  "text" : "Pick your favorite! The Grav Course Companion comes in 2 responsive design flavors:\n\u2705Bootstrap\n\u2705Foundation\n#GravEdu https:\/\/t.co\/fvBYhBEO3M",
  "id" : 699344880980496384,
  "created_at" : "2016-02-15 21:29:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/JL7EGcte7H",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-companion-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699299160336388097",
  "text" : "2\/2 If you're a Web-savvy educator the Grav Course Companion can provide a better experience for you &amp; your students https:\/\/t.co\/JL7EGcte7H",
  "id" : 699299160336388097,
  "created_at" : "2016-02-15 18:28:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699299076840394752",
  "text" : "1\/2 You can think about experience design many ways as an educator, including this one: it's a way to show your students that you care.",
  "id" : 699299076840394752,
  "created_at" : "2016-02-15 18:27:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699285350275903488",
  "text" : "For example, each new open source Grav theme released represents a possible candidate for use with the Course Companion framework. #GravEdu",
  "id" : 699285350275903488,
  "created_at" : "2016-02-15 17:33:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/zeRpRmRdRS",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/grav-skeleton-course-companion",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699282311053860864",
  "text" : "A key aspect of my Grav Course Companion is that it builds upon active open source projects, and is not one big app. https:\/\/t.co\/zeRpRmRdRS",
  "id" : 699282311053860864,
  "created_at" : "2016-02-15 17:21:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/rzM902pRQb",
      "expanded_url" : "http:\/\/www.designcontentconf.com\/code-of-conduct\/",
      "display_url" : "designcontentconf.com\/code-of-conduc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "698948307616305152",
  "geo" : { },
  "id_str" : "698949233269846016",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc If you are still looking for examples here is one for a local conference I attended last summer https:\/\/t.co\/rzM902pRQb",
  "id" : 698949233269846016,
  "in_reply_to_status_id" : 698948307616305152,
  "created_at" : "2016-02-14 19:17:37 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBC Radio",
      "screen_name" : "cbcradio",
      "indices" : [ 115, 124 ],
      "id_str" : "17679977",
      "id" : 17679977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698934806617272320",
  "text" : "If you think of Facebook as an advertising platform, things become much clearer. Really good doc about Facebook on @cbcradio this morning.",
  "id" : 698934806617272320,
  "created_at" : "2016-02-14 18:20:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 32, 40 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/753qpCWnKz",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators#\/",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/SKHaHkX5al",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-10-grav-cms-for-educators-workshop-resources",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698659830710448132",
  "text" : "Three days until the first ever @getgrav CMS for Educators Workshop\n\u2713 Slides @ https:\/\/t.co\/753qpCWnKz\n\u2713 Resources @ https:\/\/t.co\/SKHaHkX5al",
  "id" : 698659830710448132,
  "created_at" : "2016-02-14 00:07:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 92, 100 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 125, 132 ]
    }, {
      "text" : "edchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/JL7EGcte7H",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-companion-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698561692565839872",
  "text" : "Grav Course Companion Getting Started Guide, for instructors wanting to flip their LMS with @getgrav https:\/\/t.co\/JL7EGcte7H #edtech #edchat",
  "id" : 698561692565839872,
  "created_at" : "2016-02-13 17:37:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFF",
      "screen_name" : "EFF",
      "indices" : [ 3, 7 ],
      "id_str" : "4816",
      "id" : 4816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/PjhKtOJ5mS",
      "expanded_url" : "http:\/\/www.phillyvoice.com\/70-years-ago-six-philly-women-eniac-digital-computer-programmers\/",
      "display_url" : "phillyvoice.com\/70-years-ago-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698295468673994752",
  "text" : "RT @EFF: 70 years ago, these six women became programmers on the first ever electronic general-purpose computer: https:\/\/t.co\/PjhKtOJ5mS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.eff.org\/\" rel=\"nofollow\"\u003EThingie\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/PjhKtOJ5mS",
        "expanded_url" : "http:\/\/www.phillyvoice.com\/70-years-ago-six-philly-women-eniac-digital-computer-programmers\/",
        "display_url" : "phillyvoice.com\/70-years-ago-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "698294181194649600",
    "text" : "70 years ago, these six women became programmers on the first ever electronic general-purpose computer: https:\/\/t.co\/PjhKtOJ5mS",
    "id" : 698294181194649600,
    "created_at" : "2016-02-12 23:54:41 +0000",
    "user" : {
      "name" : "EFF",
      "screen_name" : "EFF",
      "protected" : false,
      "id_str" : "4816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756133504413495296\/7NlilDyR_normal.jpg",
      "id" : 4816,
      "verified" : true
    }
  },
  "id" : 698295468673994752,
  "created_at" : "2016-02-12 23:59:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/mjKbUzSUnH",
      "expanded_url" : "http:\/\/ow.ly\/YeINI",
      "display_url" : "ow.ly\/YeINI"
    } ]
  },
  "geo" : { },
  "id_str" : "698289114379001856",
  "text" : "RT @BCcampus: BCcampus is looking for a Digital Designer to join our Marketing and Communications team. Apply today: https:\/\/t.co\/mjKbUzSUnH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/mjKbUzSUnH",
        "expanded_url" : "http:\/\/ow.ly\/YeINI",
        "display_url" : "ow.ly\/YeINI"
      } ]
    },
    "geo" : { },
    "id_str" : "698288226952482817",
    "text" : "BCcampus is looking for a Digital Designer to join our Marketing and Communications team. Apply today: https:\/\/t.co\/mjKbUzSUnH",
    "id" : 698288226952482817,
    "created_at" : "2016-02-12 23:31:01 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 698289114379001856,
  "created_at" : "2016-02-12 23:34:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 84, 92 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 121, 129 ]
    }, {
      "text" : "EdTech",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/JL7EGcte7H",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-companion-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698280481951842304",
  "text" : "Grav Course Companion Getting Started Guide, for educators interested in trying out @getgrav CMS https:\/\/t.co\/JL7EGcte7H #GravEdu #EdTech",
  "id" : 698280481951842304,
  "created_at" : "2016-02-12 23:00:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/JL7EGcte7H",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-companion-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698220285724471296",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy And there is also a new getting started guide  https:\/\/t.co\/JL7EGcte7H Do you think this looks appropriate for the audience? TY",
  "id" : 698220285724471296,
  "created_at" : "2016-02-12 19:01:03 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/9PFedwpqcF",
      "expanded_url" : "https:\/\/getgrav.org\/downloads\/skeletons",
      "display_url" : "getgrav.org\/downloads\/skel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698219991951212544",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy Grav Course Companion skeleton package now listed on the Grav site https:\/\/t.co\/9PFedwpqcF \uD83D\uDE00",
  "id" : 698219991951212544,
  "created_at" : "2016-02-12 18:59:53 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 10, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697940912911962112",
  "text" : "RT @etug: #etug at the Festival of Learning has a theme of \"Studio\" Get hands-on and experiential with your learning! Call is now on! http;\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697206903865155584",
    "text" : "#etug at the Festival of Learning has a theme of \"Studio\" Get hands-on and experiential with your learning! Call is now on! http;\/\/etug.ca",
    "id" : 697206903865155584,
    "created_at" : "2016-02-09 23:54:14 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 697940912911962112,
  "created_at" : "2016-02-12 00:30:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 13, 21 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/697900531147083776\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/XgJ48FlxZa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca9w1WxUYAARvwq.jpg",
      "id_str" : "697900529213530112",
      "id" : 697900529213530112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca9w1WxUYAARvwq.jpg",
      "sizes" : [ {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      } ],
      "display_url" : "pic.twitter.com\/XgJ48FlxZa"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/d6zNB16aO5",
      "expanded_url" : "http:\/\/demo.hibbittsdesign.org\/grav-course-companion\/",
      "display_url" : "demo.hibbittsdesign.org\/grav-course-co\u2026"
    }, {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/9PFedwpqcF",
      "expanded_url" : "https:\/\/getgrav.org\/downloads\/skeletons",
      "display_url" : "getgrav.org\/downloads\/skel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697900531147083776",
  "text" : "v0.9.5 of my @getgrav Course Companion now available\nDemo: https:\/\/t.co\/d6zNB16aO5\nDownload: https:\/\/t.co\/9PFedwpqcF https:\/\/t.co\/XgJ48FlxZa",
  "id" : 697900531147083776,
  "created_at" : "2016-02-11 21:50:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 44, 52 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "indices" : [ 66, 80 ],
      "id_str" : "153597392",
      "id" : 153597392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/SKHaHkX5al",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-10-grav-cms-for-educators-workshop-resources",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697531944343437312",
  "text" : "Getting excited to share the awesomeness of @getgrav CMS with the @SFUteachlearn team next week! Workshop resources: https:\/\/t.co\/SKHaHkX5al",
  "id" : 697531944343437312,
  "created_at" : "2016-02-10 21:25:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Van Essen",
      "screen_name" : "kyleve",
      "indices" : [ 3, 10 ],
      "id_str" : "14680556",
      "id" : 14680556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697274379416113153",
  "text" : "RT @kyleve: Related: Too much of an emphasis on \u201Cperfect design\u201D is just as bad as an emphasis on \u201Cperfect engineering\u201D: nothing gets done.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697272147991928832",
    "text" : "Related: Too much of an emphasis on \u201Cperfect design\u201D is just as bad as an emphasis on \u201Cperfect engineering\u201D: nothing gets done.",
    "id" : 697272147991928832,
    "created_at" : "2016-02-10 04:13:29 +0000",
    "user" : {
      "name" : "Kyle\u2764\uFE0F\uD83D\uDE0E\uD83D\uDC4C\uD83C\uDFFC\uD83D\uDC40",
      "screen_name" : "kyleve",
      "protected" : false,
      "id_str" : "14680556",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768281561556930561\/5jETek6X_normal.jpg",
      "id" : 14680556,
      "verified" : false
    }
  },
  "id" : 697274379416113153,
  "created_at" : "2016-02-10 04:22:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treehouse",
      "screen_name" : "treehouse",
      "indices" : [ 3, 13 ],
      "id_str" : "14843763",
      "id" : 14843763
    }, {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 77, 88 ],
      "id_str" : "10876852",
      "id" : 10876852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/q9dNCUZ4l1",
      "expanded_url" : "http:\/\/trhou.se\/1T6Rpst",
      "display_url" : "trhou.se\/1T6Rpst"
    } ]
  },
  "geo" : { },
  "id_str" : "696475803282898944",
  "text" : "RT @treehouse: 8 habits of veteran UX designers: https:\/\/t.co\/q9dNCUZ4l1 via @TheNextWeb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Next Web",
        "screen_name" : "TheNextWeb",
        "indices" : [ 62, 73 ],
        "id_str" : "10876852",
        "id" : 10876852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/q9dNCUZ4l1",
        "expanded_url" : "http:\/\/trhou.se\/1T6Rpst",
        "display_url" : "trhou.se\/1T6Rpst"
      } ]
    },
    "geo" : { },
    "id_str" : "696453914347053056",
    "text" : "8 habits of veteran UX designers: https:\/\/t.co\/q9dNCUZ4l1 via @TheNextWeb",
    "id" : 696453914347053056,
    "created_at" : "2016-02-07 22:02:07 +0000",
    "user" : {
      "name" : "Treehouse",
      "screen_name" : "treehouse",
      "protected" : false,
      "id_str" : "14843763",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428279627933417472\/thV1pch1_normal.png",
      "id" : 14843763,
      "verified" : true
    }
  },
  "id" : 696475803282898944,
  "created_at" : "2016-02-07 23:29:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 0, 11 ],
      "id_str" : "91634720",
      "id" : 91634720
    }, {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 12, 26 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696141312291053569",
  "geo" : { },
  "id_str" : "696146189180231680",
  "in_reply_to_user_id" : 91634720,
  "text" : "@kenjeffery @clhendricksbc Hope to do a TELL in March too as an intro to approach and open source Grav Course Companion package.",
  "id" : 696146189180231680,
  "in_reply_to_status_id" : 696141312291053569,
  "created_at" : "2016-02-07 01:39:19 +0000",
  "in_reply_to_screen_name" : "kenjeffery",
  "in_reply_to_user_id_str" : "91634720",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 0, 11 ],
      "id_str" : "91634720",
      "id" : 91634720
    }, {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 12, 26 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696141312291053569",
  "geo" : { },
  "id_str" : "696144359385726976",
  "in_reply_to_user_id" : 91634720,
  "text" : "@kenjeffery @clhendricksbc Thanks Ken! Yes, from what I know D2L can support deep links \u263A",
  "id" : 696144359385726976,
  "in_reply_to_status_id" : 696141312291053569,
  "created_at" : "2016-02-07 01:32:03 +0000",
  "in_reply_to_screen_name" : "kenjeffery",
  "in_reply_to_user_id_str" : "91634720",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/dVqLrq33Kf",
      "expanded_url" : "https:\/\/blog.timowens.io\/get-your-grav-on\/",
      "display_url" : "blog.timowens.io\/get-your-grav-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "696069968840896512",
  "geo" : { },
  "id_str" : "696131297702334464",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Should also have mentioned that reclaim hosting also now has 1-click Grav install https:\/\/t.co\/dVqLrq33Kf \uD83D\uDC4D",
  "id" : 696131297702334464,
  "in_reply_to_status_id" : 696069968840896512,
  "created_at" : "2016-02-07 00:40:09 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696065013895684096",
  "geo" : { },
  "id_str" : "696129146695516160",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc I've still got work to do for an official release of my Grav Course Companion package, but it is getting close now :-)",
  "id" : 696129146695516160,
  "in_reply_to_status_id" : 696065013895684096,
  "created_at" : "2016-02-07 00:31:36 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696069968840896512",
  "geo" : { },
  "id_str" : "696128872870379521",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Sent you an updated link - I am actually running my CMPT 363 course site now on reclaim hosting and I've been REALLY pleased!",
  "id" : 696128872870379521,
  "in_reply_to_status_id" : 696069968840896512,
  "created_at" : "2016-02-07 00:30:31 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696068431846617088",
  "geo" : { },
  "id_str" : "696128479637573632",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Indeed, the tool\/approach works best if deep links are possible to specific LMS elements\/pages :-(",
  "id" : 696128479637573632,
  "in_reply_to_status_id" : 696068431846617088,
  "created_at" : "2016-02-07 00:28:57 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/nc7erbVBWq",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-01-25-grav-course-companion-early-release-now-available",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "696065013895684096",
  "geo" : { },
  "id_str" : "696128138347020288",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc I appreciate you taking a look! The best link to use at this point is https:\/\/t.co\/nc7erbVBWq",
  "id" : 696128138347020288,
  "in_reply_to_status_id" : 696065013895684096,
  "created_at" : "2016-02-07 00:27:36 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abi Jones",
      "screen_name" : "jonesabi",
      "indices" : [ 3, 12 ],
      "id_str" : "2990621",
      "id" : 2990621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696049060344496128",
  "text" : "RT @jonesabi: In UX we have a problem where so-called experts push people away. And that has to stop. Push away new people and your field s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "695979620110192640",
    "geo" : { },
    "id_str" : "695979878408007680",
    "in_reply_to_user_id" : 2990621,
    "text" : "In UX we have a problem where so-called experts push people away. And that has to stop. Push away new people and your field stagnates, dies.",
    "id" : 695979878408007680,
    "in_reply_to_status_id" : 695979620110192640,
    "created_at" : "2016-02-06 14:38:28 +0000",
    "in_reply_to_screen_name" : "jonesabi",
    "in_reply_to_user_id_str" : "2990621",
    "user" : {
      "name" : "Abi Jones",
      "screen_name" : "jonesabi",
      "protected" : false,
      "id_str" : "2990621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736824582867451904\/HaysfjK1_normal.jpg",
      "id" : 2990621,
      "verified" : false
    }
  },
  "id" : 696049060344496128,
  "created_at" : "2016-02-06 19:13:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/695763819360989184\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/oDOdbJmOin",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CafZgZBVAAAO5Sj.png",
      "id_str" : "695763817947529216",
      "id" : 695763817947529216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CafZgZBVAAAO5Sj.png",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 814
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 814
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oDOdbJmOin"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/W1tomiXfmH",
      "expanded_url" : "https:\/\/getgrav.org\/downloads#changelog",
      "display_url" : "getgrav.org\/downloads#chan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695784245604651008",
  "text" : "RT @getgrav: Grav v1.0.9 released. Also Admin Plugin v1.0.8 available. https:\/\/t.co\/W1tomiXfmH https:\/\/t.co\/oDOdbJmOin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/695763819360989184\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/oDOdbJmOin",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CafZgZBVAAAO5Sj.png",
        "id_str" : "695763817947529216",
        "id" : 695763817947529216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CafZgZBVAAAO5Sj.png",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 814
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 814
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/oDOdbJmOin"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/W1tomiXfmH",
        "expanded_url" : "https:\/\/getgrav.org\/downloads#changelog",
        "display_url" : "getgrav.org\/downloads#chan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "695763819360989184",
    "text" : "Grav v1.0.9 released. Also Admin Plugin v1.0.8 available. https:\/\/t.co\/W1tomiXfmH https:\/\/t.co\/oDOdbJmOin",
    "id" : 695763819360989184,
    "created_at" : "2016-02-06 00:19:55 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 695784245604651008,
  "created_at" : "2016-02-06 01:41:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 4, 11 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/WGem7Pm41g",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/flipping-the-lms-with-an-open-and-collaborative-platform#\/4",
      "display_url" : "slides.com\/paulhibbitts\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695435008643768321",
  "text" : "Hey @btopro, you just made it into a new presentation I am working on - you phrased things so perfectly \uD83D\uDE09 https:\/\/t.co\/WGem7Pm41g",
  "id" : 695435008643768321,
  "created_at" : "2016-02-05 02:33:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George",
      "screen_name" : "georgekroner",
      "indices" : [ 3, 16 ],
      "id_str" : "9128102",
      "id" : 9128102
    }, {
      "name" : "Stephen Downes",
      "screen_name" : "oldaily",
      "indices" : [ 22, 30 ],
      "id_str" : "96139902",
      "id" : 96139902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/wNKUUoEQ9b",
      "expanded_url" : "http:\/\/www.downes.ca\/post\/65019",
      "display_url" : "downes.ca\/post\/65019"
    } ]
  },
  "geo" : { },
  "id_str" : "695416801094598660",
  "text" : "RT @georgekroner: via @oldaily \"maybe this is a good point for them to pause &amp; think about whether they need to run a LMS at all\" https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen Downes",
        "screen_name" : "oldaily",
        "indices" : [ 4, 12 ],
        "id_str" : "96139902",
        "id" : 96139902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/wNKUUoEQ9b",
        "expanded_url" : "http:\/\/www.downes.ca\/post\/65019",
        "display_url" : "downes.ca\/post\/65019"
      } ]
    },
    "geo" : { },
    "id_str" : "695409038297706501",
    "text" : "via @oldaily \"maybe this is a good point for them to pause &amp; think about whether they need to run a LMS at all\" https:\/\/t.co\/wNKUUoEQ9b",
    "id" : 695409038297706501,
    "created_at" : "2016-02-05 00:50:09 +0000",
    "user" : {
      "name" : "George",
      "screen_name" : "georgekroner",
      "protected" : false,
      "id_str" : "9128102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/470252277425385472\/NVdbYHMk_normal.png",
      "id" : 9128102,
      "verified" : false
    }
  },
  "id" : 695416801094598660,
  "created_at" : "2016-02-05 01:21:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 108, 113 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695369873375887361",
  "text" : "Just submitted a proposal for 3 hr studio session titled \"Moving Beyond the LMS with Grav\" at this Spring's @etug workshop. Fingers crossed!",
  "id" : 695369873375887361,
  "created_at" : "2016-02-04 22:14:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eLearning@Camosun",
      "screen_name" : "DE_Camosun",
      "indices" : [ 3, 14 ],
      "id_str" : "2317841377",
      "id" : 2317841377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/xjyfcgjJ8t",
      "expanded_url" : "https:\/\/etug.ca\/2016\/02\/02\/spring-2016-call-for-proposals\/",
      "display_url" : "etug.ca\/2016\/02\/02\/spr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695353755718385666",
  "text" : "RT @DE_Camosun: The ETUG 2016 Workshop Call for Proposals is up - deadline is March 15th!  https:\/\/t.co\/xjyfcgjJ8t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/xjyfcgjJ8t",
        "expanded_url" : "https:\/\/etug.ca\/2016\/02\/02\/spring-2016-call-for-proposals\/",
        "display_url" : "etug.ca\/2016\/02\/02\/spr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "694950704322998272",
    "text" : "The ETUG 2016 Workshop Call for Proposals is up - deadline is March 15th!  https:\/\/t.co\/xjyfcgjJ8t",
    "id" : 694950704322998272,
    "created_at" : "2016-02-03 18:28:54 +0000",
    "user" : {
      "name" : "eLearning@Camosun",
      "screen_name" : "DE_Camosun",
      "protected" : false,
      "id_str" : "2317841377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666389541381541888\/yYfRav_t_normal.png",
      "id" : 2317841377,
      "verified" : false
    }
  },
  "id" : 695353755718385666,
  "created_at" : "2016-02-04 21:10:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Koebbe",
      "screen_name" : "andrewkoebbe",
      "indices" : [ 3, 16 ],
      "id_str" : "550355098",
      "id" : 550355098
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 45, 53 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/xqfG0R6tXI",
      "expanded_url" : "http:\/\/slides.com\/akoebbe\/kcpug-grav#\/",
      "display_url" : "slides.com\/akoebbe\/kcpug-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695350574686941185",
  "text" : "RT @andrewkoebbe: My slides from last nights @getgrav talk... https:\/\/t.co\/xqfG0R6tXI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 27, 35 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/xqfG0R6tXI",
        "expanded_url" : "http:\/\/slides.com\/akoebbe\/kcpug-grav#\/",
        "display_url" : "slides.com\/akoebbe\/kcpug-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "695350048326987781",
    "text" : "My slides from last nights @getgrav talk... https:\/\/t.co\/xqfG0R6tXI",
    "id" : 695350048326987781,
    "created_at" : "2016-02-04 20:55:45 +0000",
    "user" : {
      "name" : "Andrew Koebbe",
      "screen_name" : "andrewkoebbe",
      "protected" : false,
      "id_str" : "550355098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433981003741155328\/NjQWkeSG_normal.jpeg",
      "id" : 550355098,
      "verified" : false
    }
  },
  "id" : 695350574686941185,
  "created_at" : "2016-02-04 20:57:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 92, 100 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/JA1D7XwNcL",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-03-why-I-chose-Grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695041276970831872",
  "text" : "Just made some additions to my fresh blog post: Why I (as a Web-savvy Instructor) Chose the @getgrav CMS https:\/\/t.co\/JA1D7XwNcL \u2026 #GravEdu",
  "id" : 695041276970831872,
  "created_at" : "2016-02-04 00:28:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Haney",
      "screen_name" : "notasausage",
      "indices" : [ 0, 12 ],
      "id_str" : "11718",
      "id" : 11718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694996017742151680",
  "geo" : { },
  "id_str" : "694999409868693504",
  "in_reply_to_user_id" : 11718,
  "text" : "@notasausage You're most welcome! Really looking forward to reading your article too.",
  "id" : 694999409868693504,
  "in_reply_to_status_id" : 694996017742151680,
  "created_at" : "2016-02-03 21:42:26 +0000",
  "in_reply_to_screen_name" : "notasausage",
  "in_reply_to_user_id_str" : "11718",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 59, 67 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/JA1D7XwNcL",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-03-why-I-chose-Grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694997108298878976",
  "text" : "New blog post: Why I (as a Web-savvy Instructor) Chose the @getgrav CMS https:\/\/t.co\/JA1D7XwNcL #GravEdu",
  "id" : 694997108298878976,
  "created_at" : "2016-02-03 21:33:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Haney",
      "screen_name" : "notasausage",
      "indices" : [ 0, 12 ],
      "id_str" : "11718",
      "id" : 11718
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 13, 21 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Hanerino Design",
      "screen_name" : "hanerino",
      "indices" : [ 22, 31 ],
      "id_str" : "15521097",
      "id" : 15521097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/JA1D7XwNcL",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-03-why-I-chose-Grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "694974144241385472",
  "geo" : { },
  "id_str" : "694992148781858816",
  "in_reply_to_user_id" : 11718,
  "text" : "@notasausage @getgrav @hanerino I couldn't help myself and had to write a short blog post \uD83D\uDE00 Here is the first draft: https:\/\/t.co\/JA1D7XwNcL",
  "id" : 694992148781858816,
  "in_reply_to_status_id" : 694974144241385472,
  "created_at" : "2016-02-03 21:13:35 +0000",
  "in_reply_to_screen_name" : "notasausage",
  "in_reply_to_user_id_str" : "11718",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Haney",
      "screen_name" : "notasausage",
      "indices" : [ 0, 12 ],
      "id_str" : "11718",
      "id" : 11718
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 96, 104 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694972469300568066",
  "geo" : { },
  "id_str" : "694973904381571073",
  "in_reply_to_user_id" : 11718,
  "text" : "@notasausage I'd share my experiences - I am an educator who tried out each one before choosing @getgrav, very happy with how things went!",
  "id" : 694973904381571073,
  "in_reply_to_status_id" : 694972469300568066,
  "created_at" : "2016-02-03 20:01:05 +0000",
  "in_reply_to_screen_name" : "notasausage",
  "in_reply_to_user_id_str" : "11718",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Koebbe",
      "screen_name" : "andrewkoebbe",
      "indices" : [ 3, 16 ],
      "id_str" : "550355098",
      "id" : 550355098
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 45, 53 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Kansas City's PHP UG",
      "screen_name" : "kcphpug",
      "indices" : [ 57, 65 ],
      "id_str" : "365812670",
      "id" : 365812670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/sBbOPw6fEz",
      "expanded_url" : "http:\/\/www.meetup.com\/kcphpug\/events\/228014266\/",
      "display_url" : "meetup.com\/kcphpug\/events\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694967182015336448",
  "text" : "RT @andrewkoebbe: Tonight 6p I'm speaking on @getgrav at @kcphpug. Tired of DB backed and statically generated CMSs? You need to come. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 27, 35 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      }, {
        "name" : "Kansas City's PHP UG",
        "screen_name" : "kcphpug",
        "indices" : [ 39, 47 ],
        "id_str" : "365812670",
        "id" : 365812670
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/sBbOPw6fEz",
        "expanded_url" : "http:\/\/www.meetup.com\/kcphpug\/events\/228014266\/",
        "display_url" : "meetup.com\/kcphpug\/events\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "694915354607226882",
    "text" : "Tonight 6p I'm speaking on @getgrav at @kcphpug. Tired of DB backed and statically generated CMSs? You need to come. https:\/\/t.co\/sBbOPw6fEz",
    "id" : 694915354607226882,
    "created_at" : "2016-02-03 16:08:26 +0000",
    "user" : {
      "name" : "Andrew Koebbe",
      "screen_name" : "andrewkoebbe",
      "protected" : false,
      "id_str" : "550355098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433981003741155328\/NjQWkeSG_normal.jpeg",
      "id" : 550355098,
      "verified" : false
    }
  },
  "id" : 694967182015336448,
  "created_at" : "2016-02-03 19:34:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 46, 54 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/5YbJIEv9gr",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694960596555399168",
  "text" : "Are you an educator interested in an intro to @getgrav CMS? Just updated my Grav for Educators workshop slides: https:\/\/t.co\/5YbJIEv9gr",
  "id" : 694960596555399168,
  "created_at" : "2016-02-03 19:08:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694622745842180097",
  "text" : "How much control do students have over their LMS? By flipping the LMS with an open &amp; collab platform control is with students &amp; instructors.",
  "id" : 694622745842180097,
  "created_at" : "2016-02-02 20:45:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 3, 16 ],
      "id_str" : "91939908",
      "id" : 91939908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 79, 86 ]
    }, {
      "text" : "jekyll",
      "indices" : [ 101, 108 ]
    }, {
      "text" : "GravEdu",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694617720197816320",
  "text" : "RT @davidnwright: The argument for using static or folder-driven web setups in #edtech is archiving. #jekyll #GravEdu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 61, 68 ]
      }, {
        "text" : "jekyll",
        "indices" : [ 83, 90 ]
      }, {
        "text" : "GravEdu",
        "indices" : [ 91, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694405063616262145",
    "text" : "The argument for using static or folder-driven web setups in #edtech is archiving. #jekyll #GravEdu",
    "id" : 694405063616262145,
    "created_at" : "2016-02-02 06:20:43 +0000",
    "user" : {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "protected" : false,
      "id_str" : "91939908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000388128638\/0a05619f6295cf44230a317aea475ef1_normal.jpeg",
      "id" : 91939908,
      "verified" : false
    }
  },
  "id" : 694617720197816320,
  "created_at" : "2016-02-02 20:25:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/8ThZgaVfkJ",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/a-brief-presentation-about-flipping-the-lms",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/a-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694610788363841536",
  "text" : "As long as (most) LMSs lack flexibility, great UX, openness and control there's a case for the flipped-LMS approach. https:\/\/t.co\/8ThZgaVfkJ",
  "id" : 694610788363841536,
  "created_at" : "2016-02-02 19:58:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/kLnuLVnzi9",
      "expanded_url" : "https:\/\/twitter.com\/softaculous\/status\/694412918797004801",
      "display_url" : "twitter.com\/softaculous\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694546406887927808",
  "text" : "RT @getgrav: Grav is now in Softaculous! https:\/\/t.co\/kLnuLVnzi9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/kLnuLVnzi9",
        "expanded_url" : "https:\/\/twitter.com\/softaculous\/status\/694412918797004801",
        "display_url" : "twitter.com\/softaculous\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "694543839286038528",
    "text" : "Grav is now in Softaculous! https:\/\/t.co\/kLnuLVnzi9",
    "id" : 694543839286038528,
    "created_at" : "2016-02-02 15:32:09 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 694546406887927808,
  "created_at" : "2016-02-02 15:42:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 25, 33 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Simon Fraser Univ.",
      "screen_name" : "SFU",
      "indices" : [ 92, 96 ],
      "id_str" : "8071702",
      "id" : 8071702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/EGFWbiYLRE",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/flipping-the-lms-with-an-open-and-collaborative-platform",
      "display_url" : "slides.com\/paulhibbitts\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694330713483534336",
  "text" : "Cool beans, my slides of @getgrav CMS for educators just hit +4500 views. Pilot workshop at @SFU in 2 wks. https:\/\/t.co\/EGFWbiYLRE #GravEdu",
  "id" : 694330713483534336,
  "created_at" : "2016-02-02 01:25:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Groom",
      "screen_name" : "jimgroom",
      "indices" : [ 3, 12 ],
      "id_str" : "3362981",
      "id" : 3362981
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 82, 97 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    }, {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 98, 110 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/yElIxQ9NiO",
      "expanded_url" : "http:\/\/bavatuesdays.com\/caught-in-the-sandstorm\/",
      "display_url" : "bavatuesdays.com\/caught-in-the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694195131474321408",
  "text" : "RT @jimgroom: New blog post: \"Caught in the Sandstorm\" https:\/\/t.co\/yElIxQ9NiO cc @reclaimhosting @SandstormIO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reclaim Hosting",
        "screen_name" : "ReclaimHosting",
        "indices" : [ 68, 83 ],
        "id_str" : "1602053274",
        "id" : 1602053274
      }, {
        "name" : "Sandstorm.IO",
        "screen_name" : "SandstormIO",
        "indices" : [ 84, 96 ],
        "id_str" : "2476570038",
        "id" : 2476570038
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/yElIxQ9NiO",
        "expanded_url" : "http:\/\/bavatuesdays.com\/caught-in-the-sandstorm\/",
        "display_url" : "bavatuesdays.com\/caught-in-the-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "694138776906551297",
    "text" : "New blog post: \"Caught in the Sandstorm\" https:\/\/t.co\/yElIxQ9NiO cc @reclaimhosting @SandstormIO",
    "id" : 694138776906551297,
    "created_at" : "2016-02-01 12:42:35 +0000",
    "user" : {
      "name" : "Jim Groom",
      "screen_name" : "jimgroom",
      "protected" : false,
      "id_str" : "3362981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626944793302581248\/TxzPTAYL_normal.jpg",
      "id" : 3362981,
      "verified" : false
    }
  },
  "id" : 694195131474321408,
  "created_at" : "2016-02-01 16:26:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]