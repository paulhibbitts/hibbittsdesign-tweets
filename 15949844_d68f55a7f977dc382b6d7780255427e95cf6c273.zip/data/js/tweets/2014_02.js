Grailbird.data.tweets_2014_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/k2DQouOI7p",
      "expanded_url" : "http:\/\/iy103-w14.hibbittsdesign.com\/mod\/glossary\/view.php?id=6",
      "display_url" : "iy103-w14.hibbittsdesign.com\/mod\/glossary\/v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439505928950648832",
  "text" : "Interested in designing multi-device learning experiences? First 20 resources added to my course resource glossary http:\/\/t.co\/k2DQouOI7p",
  "id" : 439505928950648832,
  "created_at" : "2014-02-28 21:02:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 131, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/hMMGi8Tqdu",
      "expanded_url" : "http:\/\/goo.gl\/s1uGZF",
      "display_url" : "goo.gl\/s1uGZF"
    } ]
  },
  "geo" : { },
  "id_str" : "438507819130556416",
  "text" : "My open course development experiment continues: multi-device learning experiences course companion updated http:\/\/t.co\/hMMGi8Tqdu #OER",
  "id" : 438507819130556416,
  "created_at" : "2014-02-26 02:56:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Warren Anthony",
      "screen_name" : "wjanthony",
      "indices" : [ 3, 13 ],
      "id_str" : "5752072",
      "id" : 5752072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438463285042507776",
  "text" : "RT @wjanthony: Steal from the vision, not the look.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438374227725795328",
    "text" : "Steal from the vision, not the look.",
    "id" : 438374227725795328,
    "created_at" : "2014-02-25 18:05:35 +0000",
    "user" : {
      "name" : "Warren Anthony",
      "screen_name" : "wjanthony",
      "protected" : false,
      "id_str" : "5752072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569622253004795904\/htlfIG3w_normal.jpeg",
      "id" : 5752072,
      "verified" : false
    }
  },
  "id" : 438463285042507776,
  "created_at" : "2014-02-25 23:59:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Wesley",
      "screen_name" : "ResultsJunkie",
      "indices" : [ 0, 14 ],
      "id_str" : "29762189",
      "id" : 29762189
    }, {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 15, 21 ],
      "id_str" : "5357662",
      "id" : 5357662
    }, {
      "name" : "Chet Woodside",
      "screen_name" : "cosmicblend",
      "indices" : [ 22, 34 ],
      "id_str" : "18189981",
      "id" : 18189981
    }, {
      "name" : "Lynne Polischuik",
      "screen_name" : "lynneux",
      "indices" : [ 35, 43 ],
      "id_str" : "18745824",
      "id" : 18745824
    }, {
      "name" : "Denim & Steel",
      "screen_name" : "DenimAndSteel",
      "indices" : [ 44, 58 ],
      "id_str" : "386399234",
      "id" : 386399234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436994808306208768",
  "geo" : { },
  "id_str" : "437020071018237953",
  "in_reply_to_user_id" : 29762189,
  "text" : "@ResultsJunkie @diesh @cosmicblend @lynneux @DenimAndSteel Awesome learning about these terrific undertakings. Will explore them more fully!",
  "id" : 437020071018237953,
  "in_reply_to_status_id" : 436994808306208768,
  "created_at" : "2014-02-22 00:24:39 +0000",
  "in_reply_to_screen_name" : "ResultsJunkie",
  "in_reply_to_user_id_str" : "29762189",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437018768103833601",
  "text" : "More and more I see multi-device access as a powerful agent of change. Responsive or not is just an implementation detail.",
  "id" : 437018768103833601,
  "created_at" : "2014-02-22 00:19:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    }, {
      "name" : "Chet Woodside",
      "screen_name" : "cosmicblend",
      "indices" : [ 7, 19 ],
      "id_str" : "18189981",
      "id" : 18189981
    }, {
      "name" : "Lynne Polischuik",
      "screen_name" : "lynneux",
      "indices" : [ 20, 28 ],
      "id_str" : "18745824",
      "id" : 18745824
    }, {
      "name" : "Denim & Steel",
      "screen_name" : "DenimAndSteel",
      "indices" : [ 29, 43 ],
      "id_str" : "386399234",
      "id" : 386399234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436985313043296256",
  "geo" : { },
  "id_str" : "436987390343663616",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh @cosmicblend @lynneux @DenimAndSteel Honestly? When human-centered design is fully internalized within orgs. Q: how best to do that?",
  "id" : 436987390343663616,
  "in_reply_to_status_id" : 436985313043296256,
  "created_at" : "2014-02-21 22:14:47 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436972052252090368",
  "geo" : { },
  "id_str" : "436972427315122176",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh %100 agree!",
  "id" : 436972427315122176,
  "in_reply_to_status_id" : 436972052252090368,
  "created_at" : "2014-02-21 21:15:19 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436970125602746368",
  "geo" : { },
  "id_str" : "436971514101907456",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh Same goes for many uni\/school sites for students, which is an area I am trying to make improvements in, esp. re: multi-device access",
  "id" : 436971514101907456,
  "in_reply_to_status_id" : 436970125602746368,
  "created_at" : "2014-02-21 21:11:42 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436965411783856128",
  "geo" : { },
  "id_str" : "436969534965035008",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh Strong indicator of how your products are a result of your culture.",
  "id" : 436969534965035008,
  "in_reply_to_status_id" : 436965411783856128,
  "created_at" : "2014-02-21 21:03:50 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dudley Storey",
      "screen_name" : "dudleystorey",
      "indices" : [ 3, 16 ],
      "id_str" : "133129567",
      "id" : 133129567
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/dudleystorey\/status\/436930337734537216\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/cKxL5txHSS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhBJ08SCMAEWUx3.jpg",
      "id_str" : "436930337738731521",
      "id" : 436930337738731521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhBJ08SCMAEWUx3.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/cKxL5txHSS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436932223925628928",
  "text" : "RT @dudleystorey: Now this is a Winter Olympics event I could get behind: Men's Outdoor Kerning. http:\/\/t.co\/cKxL5txHSS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/dudleystorey\/status\/436930337734537216\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/cKxL5txHSS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhBJ08SCMAEWUx3.jpg",
        "id_str" : "436930337738731521",
        "id" : 436930337738731521,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhBJ08SCMAEWUx3.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/cKxL5txHSS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436930337734537216",
    "text" : "Now this is a Winter Olympics event I could get behind: Men's Outdoor Kerning. http:\/\/t.co\/cKxL5txHSS",
    "id" : 436930337734537216,
    "created_at" : "2014-02-21 18:28:05 +0000",
    "user" : {
      "name" : "Dudley Storey",
      "screen_name" : "dudleystorey",
      "protected" : false,
      "id_str" : "133129567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1416193769\/mini-me-head_normal.jpg",
      "id" : 133129567,
      "verified" : false
    }
  },
  "id" : 436932223925628928,
  "created_at" : "2014-02-21 18:35:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lambda Solutions",
      "screen_name" : "lambdasolutions",
      "indices" : [ 0, 16 ],
      "id_str" : "86378776",
      "id" : 86378776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436652136953561088",
  "geo" : { },
  "id_str" : "436662201554726913",
  "in_reply_to_user_id" : 86378776,
  "text" : "@lambdasolutions 1) Embedding HTML, e.g. Twitter widget 2) Editing the CSS of a theme, esp. a responsive one 3) Hiding topics 4) Forums",
  "id" : 436662201554726913,
  "in_reply_to_status_id" : 436652136953561088,
  "created_at" : "2014-02-21 00:42:36 +0000",
  "in_reply_to_screen_name" : "lambdasolutions",
  "in_reply_to_user_id_str" : "86378776",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "indices" : [ 3, 13 ],
      "id_str" : "18983561",
      "id" : 18983561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/f2j0o1p3V2",
      "expanded_url" : "http:\/\/Moodle.org",
      "display_url" : "Moodle.org"
    }, {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/KO9TAFff6E",
      "expanded_url" : "https:\/\/moodle.org\/plugins\/view.php?plugin=theme_bootstrap",
      "display_url" : "moodle.org\/plugins\/view.p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436590810310537216",
  "text" : "RT @basbrands: The bootstrap 3 theme: now available on http:\/\/t.co\/f2j0o1p3V2 : https:\/\/t.co\/KO9TAFff6E\nThis is a major rewrite tested well\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/f2j0o1p3V2",
        "expanded_url" : "http:\/\/Moodle.org",
        "display_url" : "Moodle.org"
      }, {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/KO9TAFff6E",
        "expanded_url" : "https:\/\/moodle.org\/plugins\/view.php?plugin=theme_bootstrap",
        "display_url" : "moodle.org\/plugins\/view.p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436589933105782784",
    "text" : "The bootstrap 3 theme: now available on http:\/\/t.co\/f2j0o1p3V2 : https:\/\/t.co\/KO9TAFff6E\nThis is a major rewrite tested well but still BETA",
    "id" : 436589933105782784,
    "created_at" : "2014-02-20 19:55:26 +0000",
    "user" : {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "protected" : false,
      "id_str" : "18983561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570499815742521344\/KPZ0dxP5_normal.png",
      "id" : 18983561,
      "verified" : false
    }
  },
  "id" : 436590810310537216,
  "created_at" : "2014-02-20 19:58:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 3, 14 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436584893594599424",
  "text" : "RT @sparkandco: Dear internet - please excuse us while we all go watch overtime. Thanks, All of Canada",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436583798793203712",
    "text" : "Dear internet - please excuse us while we all go watch overtime. Thanks, All of Canada",
    "id" : 436583798793203712,
    "created_at" : "2014-02-20 19:31:03 +0000",
    "user" : {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "protected" : false,
      "id_str" : "47105948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656831720809889792\/aQbeijGD_normal.png",
      "id" : 47105948,
      "verified" : false
    }
  },
  "id" : 436584893594599424,
  "created_at" : "2014-02-20 19:35:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 0, 8 ],
      "id_str" : "5690792",
      "id" : 5690792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436573599873253376",
  "geo" : { },
  "id_str" : "436576335641595904",
  "in_reply_to_user_id" : 5690792,
  "text" : "@draggin Thanks very much Jason. I would love to see any of your current Canvas work that you could share!",
  "id" : 436576335641595904,
  "in_reply_to_status_id" : 436573599873253376,
  "created_at" : "2014-02-20 19:01:24 +0000",
  "in_reply_to_screen_name" : "draggin",
  "in_reply_to_user_id_str" : "5690792",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/8iJUPMrWa3",
      "expanded_url" : "http:\/\/goo.gl\/izl9ND",
      "display_url" : "goo.gl\/izl9ND"
    } ]
  },
  "geo" : { },
  "id_str" : "436566123811594240",
  "text" : "Draft resource pages for multi-device learning experiences course: Essentials\/Assess\/Design\/Build  http:\/\/t.co\/8iJUPMrWa3 Feedback welcome.",
  "id" : 436566123811594240,
  "created_at" : "2014-02-20 18:20:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/CLZ9mZihzj",
      "expanded_url" : "http:\/\/ift.tt\/1cungNJ",
      "display_url" : "ift.tt\/1cungNJ"
    } ]
  },
  "geo" : { },
  "id_str" : "436562023556460545",
  "text" : "RT @etug: New post! [Spring Workshop 2014] Call for Proposal Open http:\/\/t.co\/CLZ9mZihzj #ETUG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ETUG",
        "indices" : [ 79, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/CLZ9mZihzj",
        "expanded_url" : "http:\/\/ift.tt\/1cungNJ",
        "display_url" : "ift.tt\/1cungNJ"
      } ]
    },
    "geo" : { },
    "id_str" : "436551758169776128",
    "text" : "New post! [Spring Workshop 2014] Call for Proposal Open http:\/\/t.co\/CLZ9mZihzj #ETUG",
    "id" : 436551758169776128,
    "created_at" : "2014-02-20 17:23:44 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 436562023556460545,
  "created_at" : "2014-02-20 18:04:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "O'Reilly Webcasts",
      "screen_name" : "OReillyWebcasts",
      "indices" : [ 3, 19 ],
      "id_str" : "551217152",
      "id" : 551217152
    }, {
      "name" : "Michal Levin",
      "screen_name" : "michall79",
      "indices" : [ 98, 108 ],
      "id_str" : "8874632",
      "id" : 8874632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MobileUXDesign",
      "indices" : [ 79, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/LUOUbSPjzF",
      "expanded_url" : "http:\/\/oreillynet.com\/pub\/e\/2740",
      "display_url" : "oreillynet.com\/pub\/e\/2740"
    } ]
  },
  "geo" : { },
  "id_str" : "435834019914063873",
  "text" : "RT @OReillyWebcasts: Webcast starting now 'Designing Multi-Device Experiences' #MobileUXDesign w\/ @michall79 join now http:\/\/t.co\/LUOUbSPjzF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michal Levin",
        "screen_name" : "michall79",
        "indices" : [ 77, 87 ],
        "id_str" : "8874632",
        "id" : 8874632
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MobileUXDesign",
        "indices" : [ 58, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/LUOUbSPjzF",
        "expanded_url" : "http:\/\/oreillynet.com\/pub\/e\/2740",
        "display_url" : "oreillynet.com\/pub\/e\/2740"
      } ]
    },
    "geo" : { },
    "id_str" : "435833713763442688",
    "text" : "Webcast starting now 'Designing Multi-Device Experiences' #MobileUXDesign w\/ @michall79 join now http:\/\/t.co\/LUOUbSPjzF",
    "id" : 435833713763442688,
    "created_at" : "2014-02-18 17:50:29 +0000",
    "user" : {
      "name" : "O'Reilly Webcasts",
      "screen_name" : "OReillyWebcasts",
      "protected" : false,
      "id_str" : "551217152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651900183366598656\/607KF6VI_normal.jpg",
      "id" : 551217152,
      "verified" : false
    }
  },
  "id" : 435834019914063873,
  "created_at" : "2014-02-18 17:51:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435820017708314624",
  "text" : "Open education resources get all the love, but I\u2019ve found developing ANY course in the open also adds a lot of value and possibilities. #OER",
  "id" : 435820017708314624,
  "created_at" : "2014-02-18 16:56:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/oMfMbrj76c",
      "expanded_url" : "http:\/\/iy103-w14.hibbittsdesign.com\/",
      "display_url" : "iy103-w14.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "435490715590606848",
  "text" : "Trying out Moodle 2.6 w\/ Bootstrap to build the mobile companion for my course on multi-device learning experiences http:\/\/t.co\/oMfMbrj76c",
  "id" : 435490715590606848,
  "created_at" : "2014-02-17 19:07:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 0, 11 ],
      "id_str" : "28429477",
      "id" : 28429477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434564568530944000",
  "geo" : { },
  "id_str" : "434733958274617345",
  "in_reply_to_user_id" : 28429477,
  "text" : "@chadleaman Could you please send me a few more details? Thanks!",
  "id" : 434733958274617345,
  "in_reply_to_status_id" : 434564568530944000,
  "created_at" : "2014-02-15 17:00:27 +0000",
  "in_reply_to_screen_name" : "chadleaman",
  "in_reply_to_user_id_str" : "28429477",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/AnbpJ42tbw",
      "expanded_url" : "http:\/\/1drv.ms\/1bSfGJv",
      "display_url" : "1drv.ms\/1bSfGJv"
    } ]
  },
  "geo" : { },
  "id_str" : "434437652813582336",
  "text" : "New worksheets for my multi-device learning course: Universal Instruction Design Principles &amp; Responsive Sketches http:\/\/t.co\/AnbpJ42tbw",
  "id" : 434437652813582336,
  "created_at" : "2014-02-14 21:23:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UBC Robson Square",
      "screen_name" : "UBCRobsonSquare",
      "indices" : [ 75, 91 ],
      "id_str" : "210914069",
      "id" : 210914069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/EAj4EmpP9d",
      "expanded_url" : "https:\/\/cstudies.ubc.ca\/a\/Course\/Designing-Multi-device-Learning-Experiences\/IY103\/",
      "display_url" : "cstudies.ubc.ca\/a\/Course\/Desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434022747891441664",
  "text" : "Registration for my new course Designing Multi-device Learning Experiences @UBCRobsonSquare is now available at https:\/\/t.co\/EAj4EmpP9d",
  "id" : 434022747891441664,
  "created_at" : "2014-02-13 17:54:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Gaskin",
      "screen_name" : "FourthWorldSys",
      "indices" : [ 3, 18 ],
      "id_str" : "29292677",
      "id" : 29292677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/tvxCzqDRKt",
      "expanded_url" : "http:\/\/recode.net\/2014\/02\/06\/our-love-affair-with-the-tablet-is-over\/",
      "display_url" : "recode.net\/2014\/02\/06\/our\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432912141138403328",
  "text" : "RT @FourthWorldSys: Has tablet sales growth peaked already? http:\/\/t.co\/tvxCzqDRKt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/tvxCzqDRKt",
        "expanded_url" : "http:\/\/recode.net\/2014\/02\/06\/our-love-affair-with-the-tablet-is-over\/",
        "display_url" : "recode.net\/2014\/02\/06\/our\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "432911302554427393",
    "text" : "Has tablet sales growth peaked already? http:\/\/t.co\/tvxCzqDRKt",
    "id" : 432911302554427393,
    "created_at" : "2014-02-10 16:17:52 +0000",
    "user" : {
      "name" : "Richard Gaskin",
      "screen_name" : "FourthWorldSys",
      "protected" : false,
      "id_str" : "29292677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708443422386880515\/kqBQKtFi_normal.jpg",
      "id" : 29292677,
      "verified" : false
    }
  },
  "id" : 432912141138403328,
  "created_at" : "2014-02-10 16:21:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Happy Cog\u00AE",
      "screen_name" : "happycog",
      "indices" : [ 3, 12 ],
      "id_str" : "14117434",
      "id" : 14117434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/HSgPTgSCUr",
      "expanded_url" : "http:\/\/cog.gd\/5ui",
      "display_url" : "cog.gd\/5ui"
    } ]
  },
  "geo" : { },
  "id_str" : "431937020760297472",
  "text" : "RT @happycog: \"It\u2019s a multi-device world, and developers can no longer afford to play favorites.\u201D http:\/\/t.co\/HSgPTgSCUr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/HSgPTgSCUr",
        "expanded_url" : "http:\/\/cog.gd\/5ui",
        "display_url" : "cog.gd\/5ui"
      } ]
    },
    "geo" : { },
    "id_str" : "431882885474172928",
    "text" : "\"It\u2019s a multi-device world, and developers can no longer afford to play favorites.\u201D http:\/\/t.co\/HSgPTgSCUr",
    "id" : 431882885474172928,
    "created_at" : "2014-02-07 20:11:18 +0000",
    "user" : {
      "name" : "Happy Cog\u00AE",
      "screen_name" : "happycog",
      "protected" : false,
      "id_str" : "14117434",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616212122482135041\/9ITImo0P_normal.jpg",
      "id" : 14117434,
      "verified" : false
    }
  },
  "id" : 431937020760297472,
  "created_at" : "2014-02-07 23:46:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431816930823917568",
  "geo" : { },
  "id_str" : "431818292752158720",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Thanks very much for the prompt reply! I am looking to display a complete rectangle though, should I explore Custom CSS then?",
  "id" : 431818292752158720,
  "in_reply_to_status_id" : 431816930823917568,
  "created_at" : "2014-02-07 15:54:38 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/nia74O4BzN",
      "expanded_url" : "http:\/\/slid.es\/paulhibbitts\/multi-device-experience-design-questions-for-discussion",
      "display_url" : "slid.es\/paulhibbitts\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431576287740575744",
  "text" : "Slides for my discussion-style presentation on multi-device UX design http:\/\/t.co\/nia74O4BzN Learned lots from various Vancouver dev teams!",
  "id" : 431576287740575744,
  "created_at" : "2014-02-06 23:52:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/6Kk7drzqsk",
      "expanded_url" : "https:\/\/www.haikudeck.com\/p\/NWUjw2vXqJ\/copywriting-tips-try-subtle-persuasion",
      "display_url" : "haikudeck.com\/p\/NWUjw2vXqJ\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431566648995110912",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Could you please point me to any info to place a semi-transparent bkgnd behind slide text? TIA! Example: https:\/\/t.co\/6Kk7drzqsk",
  "id" : 431566648995110912,
  "created_at" : "2014-02-06 23:14:41 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Nixon",
      "screen_name" : "MichaelRNixon",
      "indices" : [ 0, 14 ],
      "id_str" : "4212981",
      "id" : 4212981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431489386153123840",
  "geo" : { },
  "id_str" : "431503594471170048",
  "in_reply_to_user_id" : 4212981,
  "text" : "@MichaelRNixon Out of curiosity, what's your avg. class size? I've had more success discussion-wise w. &lt;16 students vs. 70+ students classes",
  "id" : 431503594471170048,
  "in_reply_to_status_id" : 431489386153123840,
  "created_at" : "2014-02-06 19:04:08 +0000",
  "in_reply_to_screen_name" : "MichaelRNixon",
  "in_reply_to_user_id_str" : "4212981",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Nixon",
      "screen_name" : "MichaelRNixon",
      "indices" : [ 0, 14 ],
      "id_str" : "4212981",
      "id" : 4212981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431489386153123840",
  "geo" : { },
  "id_str" : "431494125792133120",
  "in_reply_to_user_id" : 4212981,
  "text" : "@MichaelRNixon I also find it helpful to think about the conversation I want to initiate when choosing which materials to share in class.",
  "id" : 431494125792133120,
  "in_reply_to_status_id" : 431489386153123840,
  "created_at" : "2014-02-06 18:26:31 +0000",
  "in_reply_to_screen_name" : "MichaelRNixon",
  "in_reply_to_user_id_str" : "4212981",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Nixon",
      "screen_name" : "MichaelRNixon",
      "indices" : [ 0, 14 ],
      "id_str" : "4212981",
      "id" : 4212981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431489386153123840",
  "geo" : { },
  "id_str" : "431492490919567360",
  "in_reply_to_user_id" : 4212981,
  "text" : "@MichaelRNixon I wish I knew :-) I include case studies &amp; examples within lectures to aid discussion. Also embed Q&amp;A every 10-15 slides.",
  "id" : 431492490919567360,
  "in_reply_to_status_id" : 431489386153123840,
  "created_at" : "2014-02-06 18:20:01 +0000",
  "in_reply_to_screen_name" : "MichaelRNixon",
  "in_reply_to_user_id_str" : "4212981",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/2BlSxybvHp",
      "expanded_url" : "http:\/\/home.bt.com\/news\/btlife\/new-smartphone-that-blocks-nuisance-calls-11363873468882#.UvPNGNJgXbo.twitter",
      "display_url" : "home.bt.com\/news\/btlife\/ne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431488080772468736",
  "text" : "New HOME smartphone that blocks nuisance calls - BT http:\/\/t.co\/2BlSxybvHp &lt;-Good example how the term 'mobile' is context guessing at best",
  "id" : 431488080772468736,
  "created_at" : "2014-02-06 18:02:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431484331790315520",
  "text" : "Teaching some fellow adults? Think discussion, not presentation. And while we are at it, let\u2019s call ourselves facilitators, not instructors.",
  "id" : 431484331790315520,
  "created_at" : "2014-02-06 17:47:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "indices" : [ 3, 15 ],
      "id_str" : "19812150",
      "id" : 19812150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/oaEND4GIum",
      "expanded_url" : "http:\/\/wp.me\/pi2SZ-2pQ",
      "display_url" : "wp.me\/pi2SZ-2pQ"
    } ]
  },
  "geo" : { },
  "id_str" : "430885297916624898",
  "text" : "RT @drtonybates: 'Why I decided to try open publishing'  - http:\/\/t.co\/oaEND4GIum",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tonybates.ca\" rel=\"nofollow\"\u003EDrTonyBates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/oaEND4GIum",
        "expanded_url" : "http:\/\/wp.me\/pi2SZ-2pQ",
        "display_url" : "wp.me\/pi2SZ-2pQ"
      } ]
    },
    "geo" : { },
    "id_str" : "430884132084662272",
    "text" : "'Why I decided to try open publishing'  - http:\/\/t.co\/oaEND4GIum",
    "id" : 430884132084662272,
    "created_at" : "2014-02-05 02:02:37 +0000",
    "user" : {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "protected" : false,
      "id_str" : "19812150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2563456751\/wicaixr93w2lri2wsarw_normal.jpeg",
      "id" : 19812150,
      "verified" : false
    }
  },
  "id" : 430885297916624898,
  "created_at" : "2014-02-05 02:07:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/n4kIEOuReO",
      "expanded_url" : "http:\/\/ht.ly\/thCTv",
      "display_url" : "ht.ly\/thCTv"
    } ]
  },
  "geo" : { },
  "id_str" : "430859101698924546",
  "text" : "RT @BCcampus: 6 Technologies Will Change Colleges in Coming Years, Experts Say \u2013 Wired Campus - Blogs  http:\/\/t.co\/n4kIEOuReO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/n4kIEOuReO",
        "expanded_url" : "http:\/\/ht.ly\/thCTv",
        "display_url" : "ht.ly\/thCTv"
      } ]
    },
    "geo" : { },
    "id_str" : "430857087745531904",
    "text" : "6 Technologies Will Change Colleges in Coming Years, Experts Say \u2013 Wired Campus - Blogs  http:\/\/t.co\/n4kIEOuReO",
    "id" : 430857087745531904,
    "created_at" : "2014-02-05 00:15:09 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 430859101698924546,
  "created_at" : "2014-02-05 00:23:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catriona Shedd",
      "screen_name" : "inspireUX",
      "indices" : [ 3, 13 ],
      "id_str" : "15325945",
      "id" : 15325945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/fl4c9bOL18",
      "expanded_url" : "http:\/\/scotthurff.com\/posts\/facebook-paper-gestures",
      "display_url" : "scotthurff.com\/posts\/facebook\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430837426743808000",
  "text" : "RT @inspireUX: Great writeup on ergonomics and gestures used in the Facebook Paper app http:\/\/t.co\/fl4c9bOL18",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/fl4c9bOL18",
        "expanded_url" : "http:\/\/scotthurff.com\/posts\/facebook-paper-gestures",
        "display_url" : "scotthurff.com\/posts\/facebook\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "430834544032239616",
    "text" : "Great writeup on ergonomics and gestures used in the Facebook Paper app http:\/\/t.co\/fl4c9bOL18",
    "id" : 430834544032239616,
    "created_at" : "2014-02-04 22:45:34 +0000",
    "user" : {
      "name" : "Catriona Shedd",
      "screen_name" : "inspireUX",
      "protected" : false,
      "id_str" : "15325945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3583107610\/22970983042e614f78fd022359b9c453_normal.jpeg",
      "id" : 15325945,
      "verified" : false
    }
  },
  "id" : 430837426743808000,
  "created_at" : "2014-02-04 22:57:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/X1TmYZ6sJK",
      "expanded_url" : "http:\/\/learni.st\/users\/435300",
      "display_url" : "learni.st\/users\/435300"
    } ]
  },
  "geo" : { },
  "id_str" : "430485464642895872",
  "text" : "Trying out Learnist for my upcoming course about multi-device learning experiences.\n\nHere are my in-progress Boards: http:\/\/t.co\/X1TmYZ6sJK",
  "id" : 430485464642895872,
  "created_at" : "2014-02-03 23:38:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Cooper",
      "screen_name" : "MrAlanCooper",
      "indices" : [ 3, 16 ],
      "id_str" : "103920270",
      "id" : 103920270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/iW7pqyrEDW",
      "expanded_url" : "https:\/\/medium.com\/ux-ui-design\/4f96aa7fb547",
      "display_url" : "medium.com\/ux-ui-design\/4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429662273611649024",
  "text" : "RT @MrAlanCooper: \"Designers are, first and foremost, problem solvers.\" https:\/\/t.co\/iW7pqyrEDW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/iW7pqyrEDW",
        "expanded_url" : "https:\/\/medium.com\/ux-ui-design\/4f96aa7fb547",
        "display_url" : "medium.com\/ux-ui-design\/4\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "429641353186643968",
    "text" : "\"Designers are, first and foremost, problem solvers.\" https:\/\/t.co\/iW7pqyrEDW",
    "id" : 429641353186643968,
    "created_at" : "2014-02-01 15:44:15 +0000",
    "user" : {
      "name" : "Alan Cooper",
      "screen_name" : "MrAlanCooper",
      "protected" : false,
      "id_str" : "103920270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1470274107\/Alan_Avatar_normal.jpg",
      "id" : 103920270,
      "verified" : false
    }
  },
  "id" : 429662273611649024,
  "created_at" : "2014-02-01 17:07:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InteractionDesignOrg",
      "screen_name" : "interacting",
      "indices" : [ 3, 15 ],
      "id_str" : "24160604",
      "id" : 24160604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 33, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/KLVMDXz4da",
      "expanded_url" : "http:\/\/ow.ly\/t2syt",
      "display_url" : "ow.ly\/t2syt"
    } ]
  },
  "geo" : { },
  "id_str" : "429648213021167617",
  "text" : "RT @interacting: List of the top #UX blogs http:\/\/t.co\/KLVMDXz4da",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 16, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/KLVMDXz4da",
        "expanded_url" : "http:\/\/ow.ly\/t2syt",
        "display_url" : "ow.ly\/t2syt"
      } ]
    },
    "geo" : { },
    "id_str" : "428596111088304128",
    "text" : "List of the top #UX blogs http:\/\/t.co\/KLVMDXz4da",
    "id" : 428596111088304128,
    "created_at" : "2014-01-29 18:30:50 +0000",
    "user" : {
      "name" : "InteractionDesignOrg",
      "screen_name" : "interacting",
      "protected" : false,
      "id_str" : "24160604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/602854461166460928\/1f8QiNbN_normal.jpg",
      "id" : 24160604,
      "verified" : false
    }
  },
  "id" : 429648213021167617,
  "created_at" : "2014-02-01 16:11:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]