Grailbird.data.tweets_2013_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kontra",
      "screen_name" : "counternotions",
      "indices" : [ 3, 18 ],
      "id_str" : "19225408",
      "id" : 19225408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362714725441744896",
  "text" : "RT @counternotions: 'Disruption is facile. Disruption is easy. Disruption is ineffective. It's the technological equivalent of a temper tan\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360988216305790977",
    "text" : "'Disruption is facile. Disruption is easy. Disruption is ineffective. It's the technological equivalent of a temper tantrum\u2014nothing more.\"",
    "id" : 360988216305790977,
    "created_at" : "2013-07-27 05:01:12 +0000",
    "user" : {
      "name" : "Kontra",
      "screen_name" : "counternotions",
      "protected" : false,
      "id_str" : "19225408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472995716663488512\/0MErVHN__normal.png",
      "id" : 19225408,
      "verified" : false
    }
  },
  "id" : 362714725441744896,
  "created_at" : "2013-07-31 23:21:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/DiYVqZijN0",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "362699135410909186",
  "text" : "Updated version of my CMPT-363 multi-device course companion: http:\/\/t.co\/DiYVqZijN0 Trying to infuse more elements of performance support.",
  "id" : 362699135410909186,
  "created_at" : "2013-07-31 22:19:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 3, 19 ],
      "id_str" : "17349291",
      "id" : 17349291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/8Rt4i6ZQK4",
      "expanded_url" : "http:\/\/goo.gl\/qyTrLA",
      "display_url" : "goo.gl\/qyTrLA"
    } ]
  },
  "geo" : { },
  "id_str" : "362347876220809217",
  "text" : "RT @HabaneroConsult: User experience consultant Jas Shukla tackles responsive navigation for complex sites in her latest Insights post: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/8Rt4i6ZQK4",
        "expanded_url" : "http:\/\/goo.gl\/qyTrLA",
        "display_url" : "goo.gl\/qyTrLA"
      } ]
    },
    "geo" : { },
    "id_str" : "362332437348487168",
    "text" : "User experience consultant Jas Shukla tackles responsive navigation for complex sites in her latest Insights post: http:\/\/t.co\/8Rt4i6ZQK4",
    "id" : 362332437348487168,
    "created_at" : "2013-07-30 22:02:39 +0000",
    "user" : {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "protected" : false,
      "id_str" : "17349291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768212660244537344\/z_mWqOrE_normal.jpg",
      "id" : 17349291,
      "verified" : false
    }
  },
  "id" : 362347876220809217,
  "created_at" : "2013-07-30 23:04:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "indices" : [ 70, 80 ],
      "id_str" : "18983561",
      "id" : 18983561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/DiYVqZijN0",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360446830011617280",
  "text" : "Week 7 of my open course development\u2026 enhanced TWBS accordion (thanks @BasBrands), sidebar login, and anon. feedback http:\/\/t.co\/DiYVqZijN0",
  "id" : 360446830011617280,
  "created_at" : "2013-07-25 17:09:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chromecast",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360147287491624960",
  "geo" : { },
  "id_str" : "360159146013769731",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh I was really bummed out about this too -  fantastic educational uses to me. #chromecast",
  "id" : 360159146013769731,
  "in_reply_to_status_id" : 360147287491624960,
  "created_at" : "2013-07-24 22:06:46 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/uq74KlIHNP",
      "expanded_url" : "http:\/\/onforb.es\/1b58m1t",
      "display_url" : "onforb.es\/1b58m1t"
    } ]
  },
  "geo" : { },
  "id_str" : "359345748602654720",
  "text" : "http:\/\/t.co\/uq74KlIHNP &lt;- \"...multi-device web page that enables all kinds of input (touch, mouse and keyboard) depending on device.\"",
  "id" : 359345748602654720,
  "created_at" : "2013-07-22 16:14:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/DiYVqZijN0",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "358276855125639168",
  "text" : "Week 6 of my open course development\u2026 student-only comment visibility &amp; testing SFU survey tool for reading summaries http:\/\/t.co\/DiYVqZijN0",
  "id" : 358276855125639168,
  "created_at" : "2013-07-19 17:27:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "farhan putrananda",
      "screen_name" : "FarhanP",
      "indices" : [ 0, 8 ],
      "id_str" : "2705034932",
      "id" : 2705034932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357998726389841920",
  "geo" : { },
  "id_str" : "358031178479054848",
  "in_reply_to_user_id" : 18129659,
  "text" : "@Farhanp Thanks Farhan. I would welcome any suggestions for improvements. Sorry about the waiting list, some may drop after first class.",
  "id" : 358031178479054848,
  "in_reply_to_status_id" : 357998726389841920,
  "created_at" : "2013-07-19 01:10:59 +0000",
  "in_reply_to_screen_name" : "Farhanpatel",
  "in_reply_to_user_id_str" : "18129659",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everett McKay",
      "screen_name" : "UXDesignEdge",
      "indices" : [ 3, 16 ],
      "id_str" : "205411420",
      "id" : 205411420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/tIQd2M9HTn",
      "expanded_url" : "http:\/\/lnkd.in\/6bm79H",
      "display_url" : "lnkd.in\/6bm79H"
    } ]
  },
  "geo" : { },
  "id_str" : "357533117529071616",
  "text" : "RT @UXDesignEdge: \u201CUI is Communication\u201D Book Tour: http:\/\/t.co\/tIQd2M9HTn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/tIQd2M9HTn",
        "expanded_url" : "http:\/\/lnkd.in\/6bm79H",
        "display_url" : "lnkd.in\/6bm79H"
      } ]
    },
    "geo" : { },
    "id_str" : "357526651883618304",
    "text" : "\u201CUI is Communication\u201D Book Tour: http:\/\/t.co\/tIQd2M9HTn",
    "id" : 357526651883618304,
    "created_at" : "2013-07-17 15:46:10 +0000",
    "user" : {
      "name" : "Everett McKay",
      "screen_name" : "UXDesignEdge",
      "protected" : false,
      "id_str" : "205411420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000149771048\/61b261f6ae826532a06e5acdda953c15_normal.png",
      "id" : 205411420,
      "verified" : false
    }
  },
  "id" : 357533117529071616,
  "created_at" : "2013-07-17 16:11:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/WUvgsgrncs",
      "expanded_url" : "http:\/\/www.lukew.com\/ff\/entry.asp?1745",
      "display_url" : "lukew.com\/ff\/entry.asp?1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357524564298833920",
  "text" : "RT @lukew: rethink how the Web can work -not just on one device but across many\nhttp:\/\/t.co\/WUvgsgrncs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/WUvgsgrncs",
        "expanded_url" : "http:\/\/www.lukew.com\/ff\/entry.asp?1745",
        "display_url" : "lukew.com\/ff\/entry.asp?1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "357523127481270274",
    "text" : "rethink how the Web can work -not just on one device but across many\nhttp:\/\/t.co\/WUvgsgrncs",
    "id" : 357523127481270274,
    "created_at" : "2013-07-17 15:32:10 +0000",
    "user" : {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "protected" : false,
      "id_str" : "13889622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477610446917103616\/_cjU3_ga_normal.png",
      "id" : 13889622,
      "verified" : false
    }
  },
  "id" : 357524564298833920,
  "created_at" : "2013-07-17 15:37:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Barrese",
      "screen_name" : "jamesbarrese",
      "indices" : [ 3, 16 ],
      "id_str" : "21266738",
      "id" : 21266738
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jamesbarrese\/status\/355039687703928833\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/Amknvn7nG4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BO1atwNCIAIBYyt.jpg",
      "id_str" : "355039687712317442",
      "id" : 355039687712317442,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BO1atwNCIAIBYyt.jpg",
      "sizes" : [ {
        "h" : 555,
        "resize" : "fit",
        "w" : 408
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 408
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 408
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Amknvn7nG4"
    } ],
    "hashtags" : [ {
      "text" : "designforthefuture",
      "indices" : [ 107, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357339165756637187",
  "text" : "RT @jamesbarrese: What we are carrying around today will soon look as primitive as the device in this ad - #designforthefuture http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jamesbarrese\/status\/355039687703928833\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/Amknvn7nG4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BO1atwNCIAIBYyt.jpg",
        "id_str" : "355039687712317442",
        "id" : 355039687712317442,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BO1atwNCIAIBYyt.jpg",
        "sizes" : [ {
          "h" : 555,
          "resize" : "fit",
          "w" : 408
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 408
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 408
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Amknvn7nG4"
      } ],
      "hashtags" : [ {
        "text" : "designforthefuture",
        "indices" : [ 89, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "355039687703928833",
    "text" : "What we are carrying around today will soon look as primitive as the device in this ad - #designforthefuture http:\/\/t.co\/Amknvn7nG4",
    "id" : 355039687703928833,
    "created_at" : "2013-07-10 19:03:52 +0000",
    "user" : {
      "name" : "James Barrese",
      "screen_name" : "jamesbarrese",
      "protected" : false,
      "id_str" : "21266738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3524072757\/25a4548267de972dbb7c18234aae0873_normal.jpeg",
      "id" : 21266738,
      "verified" : false
    }
  },
  "id" : 357339165756637187,
  "created_at" : "2013-07-17 03:21:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/LyGg7rxev1",
      "expanded_url" : "http:\/\/store.griffintechnology.com\/powerdock-5-device-charger",
      "display_url" : "store.griffintechnology.com\/powerdock-5-de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357210775091294209",
  "text" : "Sign of the (multi-device) times? http:\/\/t.co\/LyGg7rxev1",
  "id" : 357210775091294209,
  "created_at" : "2013-07-16 18:51:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/iZPt8i4kfB",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/b0ddae89-8156-6687-ba26-46e5bf624a52",
      "display_url" : "workflowy.com\/shared\/b0ddae8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357202464937746433",
  "text" : "Latest iteration of my multi-device experience principles https:\/\/t.co\/iZPt8i4kfB Changes\/additions\/suggestions?",
  "id" : 357202464937746433,
  "created_at" : "2013-07-16 18:17:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThoughtFarmer",
      "screen_name" : "thoughtfarmer",
      "indices" : [ 3, 17 ],
      "id_str" : "13743032",
      "id" : 13743032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/l6TV28Xiso",
      "expanded_url" : "http:\/\/ow.ly\/mV6zF",
      "display_url" : "ow.ly\/mV6zF"
    } ]
  },
  "geo" : { },
  "id_str" : "355831025097654273",
  "text" : "RT @thoughtfarmer: New Job Posting: Enterprise Social Software Implementation Consultant http:\/\/t.co\/l6TV28Xiso",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/l6TV28Xiso",
        "expanded_url" : "http:\/\/ow.ly\/mV6zF",
        "display_url" : "ow.ly\/mV6zF"
      } ]
    },
    "geo" : { },
    "id_str" : "355821130176663554",
    "text" : "New Job Posting: Enterprise Social Software Implementation Consultant http:\/\/t.co\/l6TV28Xiso",
    "id" : 355821130176663554,
    "created_at" : "2013-07-12 22:49:03 +0000",
    "user" : {
      "name" : "ThoughtFarmer",
      "screen_name" : "thoughtfarmer",
      "protected" : false,
      "id_str" : "13743032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/470000809732624384\/-ck6fNiH_normal.png",
      "id" : 13743032,
      "verified" : false
    }
  },
  "id" : 355831025097654273,
  "created_at" : "2013-07-12 23:28:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SFU Applied Sciences",
      "screen_name" : "FAS_SFU",
      "indices" : [ 0, 8 ],
      "id_str" : "397523053",
      "id" : 397523053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/DiYVqZijN0",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "355752815789998080",
  "in_reply_to_user_id" : 397523053,
  "text" : "@FAS_SFU For students interested in CMPT-363 this Fall, draft course materials are available for preview and feedback http:\/\/t.co\/DiYVqZijN0",
  "id" : 355752815789998080,
  "created_at" : "2013-07-12 18:17:35 +0000",
  "in_reply_to_screen_name" : "FAS_SFU",
  "in_reply_to_user_id_str" : "397523053",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "indices" : [ 91, 101 ],
      "id_str" : "18983561",
      "id" : 18983561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/DiYVqZijN0",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "355748275221045249",
  "text" : "Week 5 of my open course development\u2026 multi-device companion: menubar font scaling (thanks @basbrands) better search http:\/\/t.co\/DiYVqZijN0",
  "id" : 355748275221045249,
  "created_at" : "2013-07-12 17:59:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    }, {
      "name" : "Warren Anthony",
      "screen_name" : "wjanthony",
      "indices" : [ 7, 17 ],
      "id_str" : "5752072",
      "id" : 5752072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355450721887469571",
  "geo" : { },
  "id_str" : "355452252464492545",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh @wjanthony An interesting question for sure. The Tumblr vs. Posterous example highlights the issue of expectations + control to me.",
  "id" : 355452252464492545,
  "in_reply_to_status_id" : 355450721887469571,
  "created_at" : "2013-07-11 22:23:15 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/Eu4MFr2Jzt",
      "expanded_url" : "https:\/\/docs.google.com\/file\/d\/0B9wnAcAqh8tVV0Q2SExDM0JLR2c\/edit?usp=sharing",
      "display_url" : "docs.google.com\/file\/d\/0B9wnAc\u2026"
    }, {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/Aj0Bp6ZLYc",
      "expanded_url" : "https:\/\/docs.google.com\/file\/d\/0B9wnAcAqh8tVUUllV3R4TWRHUGc\/edit?usp=sharing",
      "display_url" : "docs.google.com\/file\/d\/0B9wnAc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "355428100156313601",
  "geo" : { },
  "id_str" : "355446623293276160",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh I always liked comparing (the now defunct of course) Posterous signup https:\/\/t.co\/Eu4MFr2Jzt to Tumblr https:\/\/t.co\/Aj0Bp6ZLYc",
  "id" : 355446623293276160,
  "in_reply_to_status_id" : 355428100156313601,
  "created_at" : "2013-07-11 22:00:53 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355371591011532800",
  "geo" : { },
  "id_str" : "355374586512158720",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco I took a look last week and liked what I saw (site seems down right now). So much potential in that space!",
  "id" : 355374586512158720,
  "in_reply_to_status_id" : 355371591011532800,
  "created_at" : "2013-07-11 17:14:38 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/bzcHUHotal",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/b0ddae89-8156-6687-ba26-46e5bf624a52\/",
      "display_url" : "workflowy.com\/shared\/b0ddae8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "355371137305296898",
  "text" : "My evolving multi-device design principles: 1.Consistency 2.Parity 3.Task transferability 4.Adaptive interaction https:\/\/t.co\/bzcHUHotal",
  "id" : 355371137305296898,
  "created_at" : "2013-07-11 17:00:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 0, 12 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/355148058893381632\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/eW3ds0EQdF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BO29RyWCcAAXFpW.jpg",
      "id_str" : "355148058901770240",
      "id" : 355148058901770240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BO29RyWCcAAXFpW.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/eW3ds0EQdF"
    } ],
    "hashtags" : [ {
      "text" : "GastownGP",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355148058893381632",
  "in_reply_to_user_id" : 66913866,
  "text" : "@openroadies Great to watch the #GastownGP with you folks, thanks so much for the invite! Awesome viewing location. http:\/\/t.co\/eW3ds0EQdF",
  "id" : 355148058893381632,
  "created_at" : "2013-07-11 02:14:30 +0000",
  "in_reply_to_screen_name" : "openroadies",
  "in_reply_to_user_id_str" : "66913866",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 3, 15 ],
      "id_str" : "66913866",
      "id" : 66913866
    }, {
      "name" : "Gastown Grand Prix",
      "screen_name" : "GastownGP",
      "indices" : [ 33, 43 ],
      "id_str" : "403027255",
      "id" : 403027255
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GastownGP",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/qDx2dmKTHl",
      "expanded_url" : "http:\/\/ow.ly\/mQtO4",
      "display_url" : "ow.ly\/mQtO4"
    }, {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Pm9uyp5v5E",
      "expanded_url" : "http:\/\/ow.ly\/i\/2zQz4",
      "display_url" : "ow.ly\/i\/2zQz4"
    } ]
  },
  "geo" : { },
  "id_str" : "355094171985518592",
  "text" : "RT @openroadies: Excited for the @GastownGP tonight! Go Jen Go! #GastownGP http:\/\/t.co\/qDx2dmKTHl http:\/\/t.co\/Pm9uyp5v5E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gastown Grand Prix",
        "screen_name" : "GastownGP",
        "indices" : [ 16, 26 ],
        "id_str" : "403027255",
        "id" : 403027255
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GastownGP",
        "indices" : [ 47, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/qDx2dmKTHl",
        "expanded_url" : "http:\/\/ow.ly\/mQtO4",
        "display_url" : "ow.ly\/mQtO4"
      }, {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/Pm9uyp5v5E",
        "expanded_url" : "http:\/\/ow.ly\/i\/2zQz4",
        "display_url" : "ow.ly\/i\/2zQz4"
      } ]
    },
    "geo" : { },
    "id_str" : "355077137159569408",
    "text" : "Excited for the @GastownGP tonight! Go Jen Go! #GastownGP http:\/\/t.co\/qDx2dmKTHl http:\/\/t.co\/Pm9uyp5v5E",
    "id" : 355077137159569408,
    "created_at" : "2013-07-10 21:32:41 +0000",
    "user" : {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "protected" : false,
      "id_str" : "66913866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554783440747237376\/HA2Svg4h_normal.png",
      "id" : 66913866,
      "verified" : false
    }
  },
  "id" : 355094171985518592,
  "created_at" : "2013-07-10 22:40:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355022068686921728",
  "geo" : { },
  "id_str" : "355024707873021952",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 Brutal for sure, but on the upside congratulations on having content worthy of being duplicated :-)",
  "id" : 355024707873021952,
  "in_reply_to_status_id" : 355022068686921728,
  "created_at" : "2013-07-10 18:04:21 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/TQqUEIKcDp",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/all-classes\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "354730024512929793",
  "text" : "Example of responsive IxD: on large screens (esp. touch) provide left side floating menu, but hide on smaller screens http:\/\/t.co\/TQqUEIKcDp",
  "id" : 354730024512929793,
  "created_at" : "2013-07-09 22:33:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354665200332443649",
  "geo" : { },
  "id_str" : "354665750268616704",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 I remember finding an exact clone of my website - with revised copy at least",
  "id" : 354665750268616704,
  "in_reply_to_status_id" : 354665200332443649,
  "created_at" : "2013-07-09 18:17:58 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "effectiveui",
      "screen_name" : "effectiveui",
      "indices" : [ 3, 15 ],
      "id_str" : "14627322",
      "id" : 14627322
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 112, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/Q0dTPPbjlC",
      "expanded_url" : "http:\/\/ow.ly\/mM2o8",
      "display_url" : "ow.ly\/mM2o8"
    } ]
  },
  "geo" : { },
  "id_str" : "354398299509362688",
  "text" : "RT @effectiveui: Microsoft to launch User Experience Design Competency for app designers http:\/\/t.co\/Q0dTPPbjlC #ux",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ux",
        "indices" : [ 95, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/Q0dTPPbjlC",
        "expanded_url" : "http:\/\/ow.ly\/mM2o8",
        "display_url" : "ow.ly\/mM2o8"
      } ]
    },
    "geo" : { },
    "id_str" : "354397458954072064",
    "text" : "Microsoft to launch User Experience Design Competency for app designers http:\/\/t.co\/Q0dTPPbjlC #ux",
    "id" : 354397458954072064,
    "created_at" : "2013-07-09 00:31:53 +0000",
    "user" : {
      "name" : "effectiveui",
      "screen_name" : "effectiveui",
      "protected" : false,
      "id_str" : "14627322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760186329514803200\/np6gVDUY_normal.jpg",
      "id" : 14627322,
      "verified" : false
    }
  },
  "id" : 354398299509362688,
  "created_at" : "2013-07-09 00:35:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Chris Heilmann)))",
      "screen_name" : "codepo8",
      "indices" : [ 3, 11 ],
      "id_str" : "13567",
      "id" : 13567
    }, {
      "name" : "Daniel Appelquist",
      "screen_name" : "torgo",
      "indices" : [ 136, 140 ],
      "id_str" : "117723",
      "id" : 117723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FirefoxOS",
      "indices" : [ 37, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/1tfIqvah6T",
      "expanded_url" : "https:\/\/hacks.mozilla.org\/2013\/06\/firefox-os-for-developers-the-platform-html5-deserves\/",
      "display_url" : "hacks.mozilla.org\/2013\/06\/firefo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "353530474410418177",
  "text" : "RT @codepo8: https:\/\/t.co\/1tfIqvah6T #FirefoxOS for developers \u2013 the platform HTML5 deserves - start of a video series - this time with @to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Appelquist",
        "screen_name" : "torgo",
        "indices" : [ 123, 129 ],
        "id_str" : "117723",
        "id" : 117723
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FirefoxOS",
        "indices" : [ 24, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/1tfIqvah6T",
        "expanded_url" : "https:\/\/hacks.mozilla.org\/2013\/06\/firefox-os-for-developers-the-platform-html5-deserves\/",
        "display_url" : "hacks.mozilla.org\/2013\/06\/firefo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "347826675045769216",
    "text" : "https:\/\/t.co\/1tfIqvah6T #FirefoxOS for developers \u2013 the platform HTML5 deserves - start of a video series - this time with @torgo and me.",
    "id" : 347826675045769216,
    "created_at" : "2013-06-20 21:21:56 +0000",
    "user" : {
      "name" : "(((Chris Heilmann)))",
      "screen_name" : "codepo8",
      "protected" : false,
      "id_str" : "13567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1666904408\/codepo8_normal.png",
      "id" : 13567,
      "verified" : false
    }
  },
  "id" : 353530474410418177,
  "created_at" : "2013-07-06 15:06:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/2wm1aPbnnO",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/87a2284f-a24d-656b-790c-5b620f479465\/",
      "display_url" : "workflowy.com\/shared\/87a2284\u2026"
    }, {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/O6J4TlbhuO",
      "expanded_url" : "http:\/\/www.mindmeister.com\/307145734\/cmpt-363-133-concepts-techniques-and-principles-inventory",
      "display_url" : "mindmeister.com\/307145734\/cmpt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "353242413256556544",
  "text" : "Week 4 of my open course development\u2026 concepts, techniques &amp; principles inventory https:\/\/t.co\/2wm1aPbnnO as mind map http:\/\/t.co\/O6J4TlbhuO",
  "id" : 353242413256556544,
  "created_at" : "2013-07-05 20:02:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 0, 11 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352930436357431297",
  "geo" : { },
  "id_str" : "352933010536005632",
  "in_reply_to_user_id" : 217880712,
  "text" : "@jimbobtyer If it helps I'd be glad to meet sometime to share experiences and examples of using WordPress and Moodle. DM me if interested.",
  "id" : 352933010536005632,
  "in_reply_to_status_id" : 352930436357431297,
  "created_at" : "2013-07-04 23:32:41 +0000",
  "in_reply_to_screen_name" : "jimbobtyer",
  "in_reply_to_user_id_str" : "217880712",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 58, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/2wm1aPbnnO",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/87a2284f-a24d-656b-790c-5b620f479465\/",
      "display_url" : "workflowy.com\/shared\/87a2284\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352904381554884608",
  "text" : "Hey UX peeps, how does this look like for a comprehensive #UX concepts, techniques, and principles inventory? https:\/\/t.co\/2wm1aPbnnO",
  "id" : 352904381554884608,
  "created_at" : "2013-07-04 21:38:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Howard Rheingold",
      "screen_name" : "hrheingold",
      "indices" : [ 3, 14 ],
      "id_str" : "5388852",
      "id" : 5388852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/5k7htpURk1",
      "expanded_url" : "http:\/\/ow.ly\/mDruk",
      "display_url" : "ow.ly\/mDruk"
    } ]
  },
  "geo" : { },
  "id_str" : "352514166491320320",
  "text" : "RT @hrheingold: Engelbart's Mother of All Demos http:\/\/t.co\/5k7htpURk1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/5k7htpURk1",
        "expanded_url" : "http:\/\/ow.ly\/mDruk",
        "display_url" : "ow.ly\/mDruk"
      } ]
    },
    "geo" : { },
    "id_str" : "352491258893189120",
    "text" : "Engelbart's Mother of All Demos http:\/\/t.co\/5k7htpURk1",
    "id" : 352491258893189120,
    "created_at" : "2013-07-03 18:17:19 +0000",
    "user" : {
      "name" : "Howard Rheingold",
      "screen_name" : "hrheingold",
      "protected" : false,
      "id_str" : "5388852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730929355463892992\/zsgC6WvT_normal.jpg",
      "id" : 5388852,
      "verified" : false
    }
  },
  "id" : 352514166491320320,
  "created_at" : "2013-07-03 19:48:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitch Kapor",
      "screen_name" : "mkapor",
      "indices" : [ 3, 10 ],
      "id_str" : "2730791",
      "id" : 2730791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/wPqwpHNYam",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/07\/04\/technology\/douglas-c-engelbart-inventor-of-the-computer-mouse-dies-at-88.html?pagewanted=all&_r=1&",
      "display_url" : "nytimes.com\/2013\/07\/04\/tec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352506540508446722",
  "text" : "RT @mkapor: MUST READ NYT obituary for Doug Engelbart  to understand why so important to computing http:\/\/t.co\/wPqwpHNYam",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/wPqwpHNYam",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/07\/04\/technology\/douglas-c-engelbart-inventor-of-the-computer-mouse-dies-at-88.html?pagewanted=all&_r=1&",
        "display_url" : "nytimes.com\/2013\/07\/04\/tec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "352505746690281472",
    "text" : "MUST READ NYT obituary for Doug Engelbart  to understand why so important to computing http:\/\/t.co\/wPqwpHNYam",
    "id" : 352505746690281472,
    "created_at" : "2013-07-03 19:14:53 +0000",
    "user" : {
      "name" : "Mitch Kapor",
      "screen_name" : "mkapor",
      "protected" : false,
      "id_str" : "2730791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2980368237\/711ec3a016b6aaf3d6ec98e14ec145aa_normal.jpeg",
      "id" : 2730791,
      "verified" : true
    }
  },
  "id" : 352506540508446722,
  "created_at" : "2013-07-03 19:18:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MindMeister",
      "screen_name" : "mindmeister",
      "indices" : [ 0, 12 ],
      "id_str" : "5570982",
      "id" : 5570982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352436465248116736",
  "in_reply_to_user_id" : 5570982,
  "text" : "@mindmeister Thanks for the RT!",
  "id" : 352436465248116736,
  "created_at" : "2013-07-03 14:39:35 +0000",
  "in_reply_to_screen_name" : "mindmeister",
  "in_reply_to_user_id_str" : "5570982",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 108, 112 ]
    }, {
      "text" : "UX",
      "indices" : [ 136, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/O6J4TlbhuO",
      "expanded_url" : "http:\/\/www.mindmeister.com\/307145734\/cmpt-363-133-concepts-techniques-and-principles-inventory",
      "display_url" : "mindmeister.com\/307145734\/cmpt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352171020750295042",
  "text" : "First draft of a mind map to represent concepts, techniques, and principles for my Fall UI design course at #SFU http:\/\/t.co\/O6J4TlbhuO #UX",
  "id" : 352171020750295042,
  "created_at" : "2013-07-02 21:04:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]