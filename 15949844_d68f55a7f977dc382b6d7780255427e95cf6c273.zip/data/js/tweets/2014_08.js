Grailbird.data.tweets_2014_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Nixon",
      "screen_name" : "MichaelRNixon",
      "indices" : [ 0, 14 ],
      "id_str" : "4212981",
      "id" : 4212981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505500168415084544",
  "geo" : { },
  "id_str" : "505743610424598528",
  "in_reply_to_user_id" : 4212981,
  "text" : "@MichaelRNixon Yes, I think the Web = multi-device by default now. Just as it did originally.",
  "id" : 505743610424598528,
  "in_reply_to_status_id" : 505500168415084544,
  "created_at" : "2014-08-30 15:47:27 +0000",
  "in_reply_to_screen_name" : "MichaelRNixon",
  "in_reply_to_user_id_str" : "4212981",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505497778618118144",
  "text" : "Wow, the time that responsive Web design was a competitive advantage are long gone\u2026 adjust accordingly.",
  "id" : 505497778618118144,
  "created_at" : "2014-08-29 23:30:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "concrete5",
      "screen_name" : "concrete5",
      "indices" : [ 3, 13 ],
      "id_str" : "14982767",
      "id" : 14982767
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "concrete5",
      "indices" : [ 15, 25 ]
    }, {
      "text" : "cms",
      "indices" : [ 86, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/37itomJmSv",
      "expanded_url" : "http:\/\/www.concrete5.org\/about\/blog\/concrete5-sightings\/5-7-0-release-date\/",
      "display_url" : "concrete5.org\/about\/blog\/con\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505133692830760960",
  "text" : "RT @concrete5: #concrete5 5.7.0 Official Release Date Released http:\/\/t.co\/37itomJmSv #cms",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "concrete5",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "cms",
        "indices" : [ 71, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/37itomJmSv",
        "expanded_url" : "http:\/\/www.concrete5.org\/about\/blog\/concrete5-sightings\/5-7-0-release-date\/",
        "display_url" : "concrete5.org\/about\/blog\/con\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "505126299283636224",
    "text" : "#concrete5 5.7.0 Official Release Date Released http:\/\/t.co\/37itomJmSv #cms",
    "id" : 505126299283636224,
    "created_at" : "2014-08-28 22:54:29 +0000",
    "user" : {
      "name" : "concrete5",
      "screen_name" : "concrete5",
      "protected" : false,
      "id_str" : "14982767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000580849770\/9008b57334082bb616b345d910c95589_normal.png",
      "id" : 14982767,
      "verified" : false
    }
  },
  "id" : 505133692830760960,
  "created_at" : "2014-08-28 23:23:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johanna Erickson",
      "screen_name" : "JohannaBeth",
      "indices" : [ 3, 15 ],
      "id_str" : "23014822",
      "id" : 23014822
    }, {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 109, 120 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/2Rd5M6Y4q8",
      "expanded_url" : "http:\/\/techcrunch.com\/2014\/08\/27\/kato-im-launches-kato-teams-a-free-chat-platform-for-businesses\/?ncid=twittersocialshare",
      "display_url" : "techcrunch.com\/2014\/08\/27\/kat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504702748508835840",
  "text" : "RT @JohannaBeth: Kato.im Launches Kato Teams, A Free Chat Platform for Businesses http:\/\/t.co\/2Rd5M6Y4q8 via @techcrunch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TechCrunch",
        "screen_name" : "TechCrunch",
        "indices" : [ 92, 103 ],
        "id_str" : "816653",
        "id" : 816653
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/2Rd5M6Y4q8",
        "expanded_url" : "http:\/\/techcrunch.com\/2014\/08\/27\/kato-im-launches-kato-teams-a-free-chat-platform-for-businesses\/?ncid=twittersocialshare",
        "display_url" : "techcrunch.com\/2014\/08\/27\/kat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "504621480798208002",
    "text" : "Kato.im Launches Kato Teams, A Free Chat Platform for Businesses http:\/\/t.co\/2Rd5M6Y4q8 via @techcrunch",
    "id" : 504621480798208002,
    "created_at" : "2014-08-27 13:28:31 +0000",
    "user" : {
      "name" : "Johanna Erickson",
      "screen_name" : "JohannaBeth",
      "protected" : false,
      "id_str" : "23014822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/420832860\/Johanna_normal.jpg",
      "id" : 23014822,
      "verified" : false
    }
  },
  "id" : 504702748508835840,
  "created_at" : "2014-08-27 18:51:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504381339601489921",
  "text" : "Working on an on-line companion for your class this Fall? Think about the top three reasons students visit the site and support those first.",
  "id" : 504381339601489921,
  "created_at" : "2014-08-26 21:34:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Lepofsky",
      "screen_name" : "alanlepo",
      "indices" : [ 3, 12 ],
      "id_str" : "10458822",
      "id" : 10458822
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/alanlepo\/status\/504284720901799936\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/PG3EOAJvHU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv-UR5wIAAAOA1Z.jpg",
      "id_str" : "504284718570143744",
      "id" : 504284718570143744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv-UR5wIAAAOA1Z.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 885
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 885
      } ],
      "display_url" : "pic.twitter.com\/PG3EOAJvHU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504285726062952448",
  "text" : "RT @alanlepo: Time and time again I come back to this. Innovation is an overused term in the software industry. http:\/\/t.co\/PG3EOAJvHU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/alanlepo\/status\/504284720901799936\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/PG3EOAJvHU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv-UR5wIAAAOA1Z.jpg",
        "id_str" : "504284718570143744",
        "id" : 504284718570143744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv-UR5wIAAAOA1Z.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 885
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 885
        } ],
        "display_url" : "pic.twitter.com\/PG3EOAJvHU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504284720901799936",
    "text" : "Time and time again I come back to this. Innovation is an overused term in the software industry. http:\/\/t.co\/PG3EOAJvHU",
    "id" : 504284720901799936,
    "created_at" : "2014-08-26 15:10:21 +0000",
    "user" : {
      "name" : "Alan Lepofsky",
      "screen_name" : "alanlepo",
      "protected" : false,
      "id_str" : "10458822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752601991587606528\/WonwF1pg_normal.jpg",
      "id" : 10458822,
      "verified" : true
    }
  },
  "id" : 504285726062952448,
  "created_at" : "2014-08-26 15:14:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504166718185697280",
  "geo" : { },
  "id_str" : "504272563548479488",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp I will keep my fingers crossed for the return of Image by URL :-) Thanks again for creating such an awesome presentation tool!",
  "id" : 504272563548479488,
  "in_reply_to_status_id" : 504166718185697280,
  "created_at" : "2014-08-26 14:22:02 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504166718185697280",
  "geo" : { },
  "id_str" : "504272031207395328",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp but with all the great work on the Editor I think I would need per-slide HTML editing a whole lot less or perhaps not at all.",
  "id" : 504272031207395328,
  "in_reply_to_status_id" : 504166718185697280,
  "created_at" : "2014-08-26 14:19:55 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504166718185697280",
  "geo" : { },
  "id_str" : "504271352787140608",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Thanks for the update. Using slides for educational purposes Image (and YouTube) by URL is supper valuable and even essential &gt;",
  "id" : 504271352787140608,
  "in_reply_to_status_id" : 504166718185697280,
  "created_at" : "2014-08-26 14:17:14 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504009202327908352",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Really enjoying the new editor! Templates are really awesome :-) Are images by URL and slide HTML access on the roadmap?",
  "id" : 504009202327908352,
  "created_at" : "2014-08-25 20:55:32 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503963423437516800",
  "text" : "Trying to identify most imp. aspects of design thinking for Comp Sci students: multidisciplinary collaboration &amp; problem-reframing\u2026 agree?",
  "id" : 503963423437516800,
  "created_at" : "2014-08-25 17:53:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503944024131391489",
  "text" : "Don\u2019t be worried about the future, just go out there and create it",
  "id" : 503944024131391489,
  "created_at" : "2014-08-25 16:36:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paolo Pedercini",
      "screen_name" : "molleindustria",
      "indices" : [ 3, 18 ],
      "id_str" : "173155110",
      "id" : 173155110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/79aQCrutpr",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=EMFscTOazS0",
      "display_url" : "youtube.com\/watch?v=EMFscT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "503661106355642368",
  "text" : "RT @molleindustria: Apple\u2019s Hypercard demo from 1987. User friendly hypertext reader\/editor too ahead of its time (browser+flash+ppt)\nhttps\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/79aQCrutpr",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=EMFscTOazS0",
        "display_url" : "youtube.com\/watch?v=EMFscT\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "503556402283966464",
    "text" : "Apple\u2019s Hypercard demo from 1987. User friendly hypertext reader\/editor too ahead of its time (browser+flash+ppt)\nhttps:\/\/t.co\/79aQCrutpr",
    "id" : 503556402283966464,
    "created_at" : "2014-08-24 14:56:16 +0000",
    "user" : {
      "name" : "Paolo Pedercini",
      "screen_name" : "molleindustria",
      "protected" : false,
      "id_str" : "173155110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1093212724\/logo_small_normal.png",
      "id" : 173155110,
      "verified" : false
    }
  },
  "id" : 503661106355642368,
  "created_at" : "2014-08-24 21:52:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhan Patel",
      "screen_name" : "Farhanpatel",
      "indices" : [ 0, 12 ],
      "id_str" : "18129659",
      "id" : 18129659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502595072924598272",
  "geo" : { },
  "id_str" : "502598502116233216",
  "in_reply_to_user_id" : 18129659,
  "text" : "@Farhanpatel Thanks very much, great to know you can already access the course companion as well.",
  "id" : 502598502116233216,
  "in_reply_to_status_id" : 502595072924598272,
  "created_at" : "2014-08-21 23:29:55 +0000",
  "in_reply_to_screen_name" : "Farhanpatel",
  "in_reply_to_user_id_str" : "18129659",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502589409662095360",
  "text" : "With less than two weeks until the university school year begins, are you totally energized like me? The Fall always seems to be my New Year",
  "id" : 502589409662095360,
  "created_at" : "2014-08-21 22:53:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/502547926288445440\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/HLX9i87rtT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvlorI-CEAAnSdR.png",
      "id_str" : "502547923779850240",
      "id" : 502547923779850240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvlorI-CEAAnSdR.png",
      "sizes" : [ {
        "h" : 786,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 988,
        "resize" : "fit",
        "w" : 754
      }, {
        "h" : 988,
        "resize" : "fit",
        "w" : 754
      } ],
      "display_url" : "pic.twitter.com\/HLX9i87rtT"
    } ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 22, 32 ]
    }, {
      "text" : "SFU",
      "indices" : [ 54, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/Tcb2ZfW4U9",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/17482\/",
      "display_url" : "canvas.sfu.ca\/courses\/17482\/"
    } ]
  },
  "geo" : { },
  "id_str" : "502547926288445440",
  "text" : "Multi-device friendly #CanvasLMS course companion for #SFU CMPT 363 UI Design is now live at https:\/\/t.co\/Tcb2ZfW4U9 http:\/\/t.co\/HLX9i87rtT",
  "id" : 502547926288445440,
  "created_at" : "2014-08-21 20:08:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Hoober",
      "screen_name" : "shoobe01",
      "indices" : [ 94, 103 ],
      "id_str" : "5468322",
      "id" : 5468322
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/502120457395793921\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/fimBrYE0y4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvfj5LCCUAA1rOz.jpg",
      "id_str" : "502120454828478464",
      "id" : 502120454828478464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvfj5LCCUAA1rOz.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fimBrYE0y4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502120457395793921",
  "text" : "Just got my 4ourth Mobile Touch Template, a brilliant multi-device design and testing tool by @shoobe01! http:\/\/t.co\/fimBrYE0y4",
  "id" : 502120457395793921,
  "created_at" : "2014-08-20 15:50:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paige MacFarlane",
      "screen_name" : "edupaige",
      "indices" : [ 3, 12 ],
      "id_str" : "213488431",
      "id" : 213488431
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcssasla14",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500662365814546432",
  "text" : "RT @edupaige: \"if we teach today's students as we taught yesterday's, we rob them of tomorrow\" - John Dewey #bcssasla14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bcssasla14",
        "indices" : [ 94, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 49.8910321623, -119.4970447337 ]
    },
    "id_str" : "500311420383133698",
    "text" : "\"if we teach today's students as we taught yesterday's, we rob them of tomorrow\" - John Dewey #bcssasla14",
    "id" : 500311420383133698,
    "created_at" : "2014-08-15 16:01:52 +0000",
    "user" : {
      "name" : "Paige MacFarlane",
      "screen_name" : "edupaige",
      "protected" : false,
      "id_str" : "213488431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665610713759506433\/j9GCKJHO_normal.jpg",
      "id" : 213488431,
      "verified" : false
    }
  },
  "id" : 500662365814546432,
  "created_at" : "2014-08-16 15:16:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/erFAslGMoc",
      "expanded_url" : "https:\/\/workflowy.com\/s\/70689867-6f5e-6f1c-fca9-ba0396959552",
      "display_url" : "workflowy.com\/s\/70689867-6f5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "499662276937646080",
  "text" : "Another update to my relationship + tool\/platform success factors for online mentoring and coaching: https:\/\/t.co\/erFAslGMoc",
  "id" : 499662276937646080,
  "created_at" : "2014-08-13 21:02:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 3, 11 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Gizmodo\/status\/499316529092374528\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/AhOs7qZ9in",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu3tvNHIcAAjgHQ.jpg",
      "id_str" : "499316528937201664",
      "id" : 499316528937201664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu3tvNHIcAAjgHQ.jpg",
      "sizes" : [ {
        "h" : 288,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 154,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AhOs7qZ9in"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/0PlrcfsvA4",
      "expanded_url" : "http:\/\/gizmo.do\/eCQUUoU",
      "display_url" : "gizmo.do\/eCQUUoU"
    } ]
  },
  "geo" : { },
  "id_str" : "499328148065255425",
  "text" : "RT @Gizmodo: Photoshop contest: Give the LA Clippers a new, Ballmer-friendly logo http:\/\/t.co\/0PlrcfsvA4 http:\/\/t.co\/AhOs7qZ9in",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Gizmodo\/status\/499316529092374528\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/AhOs7qZ9in",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu3tvNHIcAAjgHQ.jpg",
        "id_str" : "499316528937201664",
        "id" : 499316528937201664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu3tvNHIcAAjgHQ.jpg",
        "sizes" : [ {
          "h" : 288,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 154,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/AhOs7qZ9in"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/0PlrcfsvA4",
        "expanded_url" : "http:\/\/gizmo.do\/eCQUUoU",
        "display_url" : "gizmo.do\/eCQUUoU"
      } ]
    },
    "geo" : { },
    "id_str" : "499316529092374528",
    "text" : "Photoshop contest: Give the LA Clippers a new, Ballmer-friendly logo http:\/\/t.co\/0PlrcfsvA4 http:\/\/t.co\/AhOs7qZ9in",
    "id" : 499316529092374528,
    "created_at" : "2014-08-12 22:08:32 +0000",
    "user" : {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "protected" : false,
      "id_str" : "2890961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590508740010348544\/eS1F7mN5_normal.png",
      "id" : 2890961,
      "verified" : true
    }
  },
  "id" : 499328148065255425,
  "created_at" : "2014-08-12 22:54:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis Rosenfeld",
      "screen_name" : "louisrosenfeld",
      "indices" : [ 0, 15 ],
      "id_str" : "1760431",
      "id" : 1760431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499307794789433344",
  "geo" : { },
  "id_str" : "499311576340774912",
  "in_reply_to_user_id" : 1760431,
  "text" : "@louisrosenfeld No connection with the company (other than being a happy customer), but I've found zoom.us a great replacement for Hangouts.",
  "id" : 499311576340774912,
  "in_reply_to_status_id" : 499307794789433344,
  "created_at" : "2014-08-12 21:48:51 +0000",
  "in_reply_to_screen_name" : "louisrosenfeld",
  "in_reply_to_user_id_str" : "1760431",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/497514446118719490\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/iFiuhH6mAc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BueGwDqIgAAfdGr.png",
      "id_str" : "497514444021596160",
      "id" : 497514444021596160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BueGwDqIgAAfdGr.png",
      "sizes" : [ {
        "h" : 1528,
        "resize" : "fit",
        "w" : 1263
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1239,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/iFiuhH6mAc"
    } ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497514446118719490",
  "text" : "Continuing work on multi-device friendly #CanvasLMS course site. Have increased performance support + social aspects. http:\/\/t.co\/iFiuhH6mAc",
  "id" : 497514446118719490,
  "created_at" : "2014-08-07 22:47:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evert Pruis",
      "screen_name" : "EvertPruis",
      "indices" : [ 3, 14 ],
      "id_str" : "127479491",
      "id" : 127479491
    }, {
      "name" : "Charles Jennings",
      "screen_name" : "charlesjennings",
      "indices" : [ 27, 43 ],
      "id_str" : "17928413",
      "id" : 17928413
    }, {
      "name" : "Clark Quinn",
      "screen_name" : "Quinnovator",
      "indices" : [ 97, 109 ],
      "id_str" : "15312626",
      "id" : 15312626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/UfdMZRo03C",
      "expanded_url" : "http:\/\/buff.ly\/1ofydd2",
      "display_url" : "buff.ly\/1ofydd2"
    } ]
  },
  "geo" : { },
  "id_str" : "497388415915421697",
  "text" : "RT @EvertPruis: Nice point @charlesjennings \"will it be revolution or a slow demise of L&amp;D?\" @Quinnovator http:\/\/t.co\/UfdMZRo03C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charles Jennings",
        "screen_name" : "charlesjennings",
        "indices" : [ 11, 27 ],
        "id_str" : "17928413",
        "id" : 17928413
      }, {
        "name" : "Clark Quinn",
        "screen_name" : "Quinnovator",
        "indices" : [ 81, 93 ],
        "id_str" : "15312626",
        "id" : 15312626
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/UfdMZRo03C",
        "expanded_url" : "http:\/\/buff.ly\/1ofydd2",
        "display_url" : "buff.ly\/1ofydd2"
      } ]
    },
    "geo" : { },
    "id_str" : "497379467502030848",
    "text" : "Nice point @charlesjennings \"will it be revolution or a slow demise of L&amp;D?\" @Quinnovator http:\/\/t.co\/UfdMZRo03C",
    "id" : 497379467502030848,
    "created_at" : "2014-08-07 13:51:20 +0000",
    "user" : {
      "name" : "Evert Pruis",
      "screen_name" : "EvertPruis",
      "protected" : false,
      "id_str" : "127479491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000706982854\/6d5e14d25c3bc9fcb48ea0c4732579eb_normal.jpeg",
      "id" : 127479491,
      "verified" : false
    }
  },
  "id" : 497388415915421697,
  "created_at" : "2014-08-07 14:26:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497148775056822272",
  "text" : "The three most important characteristics of a university instructor today?\n\nMy picks would be relevant, current, and empathetic.",
  "id" : 497148775056822272,
  "created_at" : "2014-08-06 22:34:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/wAojrpbTib",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/16304\/files\/1598263",
      "display_url" : "canvas.sfu.ca\/courses\/16304\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "496704381136683009",
  "text" : "Trying out learner-generated ratings for CMPT-363 UX techniques guide. +\/- seem more suitable than 5 star ratings.\nhttps:\/\/t.co\/wAojrpbTib",
  "id" : 496704381136683009,
  "created_at" : "2014-08-05 17:08:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]