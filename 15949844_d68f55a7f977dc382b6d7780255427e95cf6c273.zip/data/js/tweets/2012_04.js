Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195272871700987904",
  "text" : "\"Mobile First\" is useful, but \"Experience First\" can be even more insightful.",
  "id" : 195272871700987904,
  "created_at" : "2012-04-25 22:07:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.meetup.com\/\" rel=\"nofollow\"\u003EMeetup\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/VOwFcQN2",
      "expanded_url" : "http:\/\/meetu.ps\/9stPC",
      "display_url" : "meetu.ps\/9stPC"
    } ]
  },
  "geo" : { },
  "id_str" : "194549500856115200",
  "text" : "Check out this Meetup with The Vancouver WordPress Meetup Group http:\/\/t.co\/VOwFcQN2",
  "id" : 194549500856115200,
  "created_at" : "2012-04-23 22:13:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193076698638598144",
  "text" : "Any recommendations for mobile learning LMS\/CMS platforms out there? My current tool of choice for student UX is WordPress + WPtouch Pro.",
  "id" : 193076698638598144,
  "created_at" : "2012-04-19 20:40:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/nuB6MKF2",
      "expanded_url" : "http:\/\/globalmoxie.com\/blog\/josh-clark-talks.shtml",
      "display_url" : "globalmoxie.com\/blog\/josh-clar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192374579119931392",
  "text" : "Slides from Josh Clark's talk \"Seven Deadly Mobile Myths\" are here: http:\/\/t.co\/nuB6MKF2 &lt;- All seven myths relevant to mobile learning too",
  "id" : 192374579119931392,
  "created_at" : "2012-04-17 22:10:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SIAT",
      "screen_name" : "SIAT_SFU",
      "indices" : [ 3, 12 ],
      "id_str" : "45701038",
      "id" : 45701038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/L4hmeiAM",
      "expanded_url" : "http:\/\/fb.me\/YkMPT8GD",
      "display_url" : "fb.me\/YkMPT8GD"
    } ]
  },
  "geo" : { },
  "id_str" : "190633321229848576",
  "text" : "RT @SIAT_SFU: SFU is seeking a User Experience Analyst... http:\/\/t.co\/L4hmeiAM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http:\/\/t.co\/L4hmeiAM",
        "expanded_url" : "http:\/\/fb.me\/YkMPT8GD",
        "display_url" : "fb.me\/YkMPT8GD"
      } ]
    },
    "geo" : { },
    "id_str" : "190623727988391936",
    "text" : "SFU is seeking a User Experience Analyst... http:\/\/t.co\/L4hmeiAM",
    "id" : 190623727988391936,
    "created_at" : "2012-04-13 02:13:33 +0000",
    "user" : {
      "name" : "SIAT",
      "screen_name" : "SIAT_SFU",
      "protected" : false,
      "id_str" : "45701038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699362551369338880\/LDhtS1hi_normal.png",
      "id" : 45701038,
      "verified" : false
    }
  },
  "id" : 190633321229848576,
  "created_at" : "2012-04-13 02:51:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Instone",
      "screen_name" : "keithinstone",
      "indices" : [ 3, 16 ],
      "id_str" : "8735782",
      "id" : 8735782
    }, {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "indices" : [ 39, 47 ],
      "id_str" : "15022225",
      "id" : 15022225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/r0Z3OcLe",
      "expanded_url" : "http:\/\/www.netmagazine.com\/interviews\/nielsen-responds-mobile-criticism",
      "display_url" : "netmagazine.com\/interviews\/nie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190544624136355841",
  "text" : "RT @keithinstone: Nice to see Jakob of @NNgroup engaging with feedback of his mobile alertbox. http:\/\/t.co\/r0Z3OcLe Agree or not, let's  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nielsen Norman Group",
        "screen_name" : "NNgroup",
        "indices" : [ 21, 29 ],
        "id_str" : "15022225",
        "id" : 15022225
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/r0Z3OcLe",
        "expanded_url" : "http:\/\/www.netmagazine.com\/interviews\/nielsen-responds-mobile-criticism",
        "display_url" : "netmagazine.com\/interviews\/nie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "190530811110498308",
    "text" : "Nice to see Jakob of @NNgroup engaging with feedback of his mobile alertbox. http:\/\/t.co\/r0Z3OcLe Agree or not, let's discuss.",
    "id" : 190530811110498308,
    "created_at" : "2012-04-12 20:04:19 +0000",
    "user" : {
      "name" : "Keith Instone",
      "screen_name" : "keithinstone",
      "protected" : false,
      "id_str" : "8735782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531175848423215105\/KCQQMGjo_normal.jpeg",
      "id" : 8735782,
      "verified" : false
    }
  },
  "id" : 190544624136355841,
  "created_at" : "2012-04-12 20:59:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/zLHcW9IJ",
      "expanded_url" : "http:\/\/speakerdeck.com\/u\/hibbittsdesign\/p\/mobile-learning-user-experience-ux-design-creating-a-mobile-course-companion-with-wordpress",
      "display_url" : "speakerdeck.com\/u\/hibbittsdesi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "189804171464155136",
  "text" : "Mobile Learning User Experience (UX) Design: Creating a Mobile Course Companion with WordPress draft slides http:\/\/t.co\/zLHcW9IJ",
  "id" : 189804171464155136,
  "created_at" : "2012-04-10 19:56:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nextminds",
      "screen_name" : "Nextminds",
      "indices" : [ 0, 10 ],
      "id_str" : "1435615447",
      "id" : 1435615447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/UWiCFcvb",
      "expanded_url" : "http:\/\/store.elsevier.com\/Moderating-Usability-Tests\/Joseph-Dumas\/isbn-9780123739339\/",
      "display_url" : "store.elsevier.com\/Moderating-Usa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "183143593224052736",
  "geo" : { },
  "id_str" : "187683339086475264",
  "in_reply_to_user_id" : 9830292,
  "text" : "@Nextminds Very glad to hear that my UX resources page was helpful! Re: orientation, lots of info & tips in this book: http:\/\/t.co\/UWiCFcvb",
  "id" : 187683339086475264,
  "in_reply_to_status_id" : 183143593224052736,
  "created_at" : "2012-04-04 23:29:29 +0000",
  "in_reply_to_screen_name" : "rorykoehein",
  "in_reply_to_user_id_str" : "9830292",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]