Grailbird.data.tweets_2014_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 117, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/1jCI2vILRd",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/70689867-6f5e-6f1c-fca9-ba0396959552\/",
      "display_url" : "workflowy.com\/shared\/7068986\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483683464579801088",
  "text" : "Updated key success factors for mentoring\/coaching: https:\/\/t.co\/1jCI2vILRd Planning to provide this online to my 80 #SFU students this Fall",
  "id" : 483683464579801088,
  "created_at" : "2014-06-30 18:48:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483405059070255104",
  "text" : "When I no longer feel my next course will be better than the last, it's time to pack up my teaching bag.",
  "id" : 483405059070255104,
  "created_at" : "2014-06-30 00:22:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/dgN5uEUdix",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/etug-spring-2014-developing-a-course-in-the-open-a-case-study",
      "display_url" : "slides.com\/paulhibbitts\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482569354790195200",
  "text" : "ETUG Spring 2014 - Developing a Course in the Open: A Case Study http:\/\/t.co\/dgN5uEUdix So happy to see this experience inspire others!",
  "id" : 482569354790195200,
  "created_at" : "2014-06-27 17:01:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 48, 63 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 67, 76 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/LZifit5SAd",
      "expanded_url" : "http:\/\/www.linkedin.com\/today\/post\/article\/20140626203446-572658-key-success-factors-for-mentoring-coaching",
      "display_url" : "linkedin.com\/today\/post\/art\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482299200558743552",
  "text" : "\"Key Success Factors for Mentoring\/Coaching\" by @hibbittsdesign on @LinkedIn http:\/\/t.co\/LZifit5SAd",
  "id" : 482299200558743552,
  "created_at" : "2014-06-26 23:07:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Saffer",
      "screen_name" : "odannyboy",
      "indices" : [ 3, 13 ],
      "id_str" : "3252",
      "id" : 3252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482255727205941248",
  "text" : "RT @odannyboy: Did we all agree that Google\u2019s Material Design was a better design language than iOS7 yet? If so, let that sink in.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482200839164268544",
    "text" : "Did we all agree that Google\u2019s Material Design was a better design language than iOS7 yet? If so, let that sink in.",
    "id" : 482200839164268544,
    "created_at" : "2014-06-26 16:36:53 +0000",
    "user" : {
      "name" : "Dan Saffer",
      "screen_name" : "odannyboy",
      "protected" : false,
      "id_str" : "3252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477328081057619968\/rKaB5tsc_normal.jpeg",
      "id" : 3252,
      "verified" : true
    }
  },
  "id" : 482255727205941248,
  "created_at" : "2014-06-26 20:14:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/TK2ZFrRr1Q",
      "expanded_url" : "http:\/\/1drv.ms\/1ms0Di1",
      "display_url" : "1drv.ms\/1ms0Di1"
    } ]
  },
  "geo" : { },
  "id_str" : "481927343145881600",
  "text" : "Interested in creating better multi-device Moodle experiences? Here's the OneNote notebook for an upcoming workshop http:\/\/t.co\/TK2ZFrRr1Q",
  "id" : 481927343145881600,
  "created_at" : "2014-06-25 22:30:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Kadlec",
      "screen_name" : "tkadlec",
      "indices" : [ 3, 11 ],
      "id_str" : "13182702",
      "id" : 13182702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481865282621669376",
  "text" : "RT @tkadlec: Google's focus on seamless experiences is drawing a *very* thin line between native and web within the platform. Almost artifi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481859760459751424",
    "text" : "Google's focus on seamless experiences is drawing a *very* thin line between native and web within the platform. Almost artificial.",
    "id" : 481859760459751424,
    "created_at" : "2014-06-25 18:01:34 +0000",
    "user" : {
      "name" : "Tim Kadlec",
      "screen_name" : "tkadlec",
      "protected" : false,
      "id_str" : "13182702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478537432103538688\/ZCyWGyJs_normal.jpeg",
      "id" : 13182702,
      "verified" : false
    }
  },
  "id" : 481865282621669376,
  "created_at" : "2014-06-25 18:23:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/3r68bqpF04",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/06d9fc64-5fcc-26ab-2e81-70a99c003b69\/",
      "display_url" : "workflowy.com\/shared\/06d9fc6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481852147147882496",
  "text" : "Draft outline of my upcoming half-day workshop about multi-device moodle learning experiences @ Open School BC https:\/\/t.co\/3r68bqpF04",
  "id" : 481852147147882496,
  "created_at" : "2014-06-25 17:31:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Developers",
      "screen_name" : "googledevs",
      "indices" : [ 3, 14 ],
      "id_str" : "50090898",
      "id" : 50090898
    }, {
      "name" : "sundarpichai",
      "screen_name" : "sundarpichai",
      "indices" : [ 32, 45 ],
      "id_str" : "14130366",
      "id" : 14130366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "io14",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/PzbSkqkXkC",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wtLJPvx7-ys",
      "display_url" : "youtube.com\/watch?v=wtLJPv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481835356921155584",
  "text" : "RT @googledevs: I\/O 14 is Live. @sundarpichai just stepped on stage, to welcome a room full of 6,000 developers in Moscone. https:\/\/t.co\/Pz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "sundarpichai",
        "screen_name" : "sundarpichai",
        "indices" : [ 16, 29 ],
        "id_str" : "14130366",
        "id" : 14130366
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "io14",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/PzbSkqkXkC",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wtLJPvx7-ys",
        "display_url" : "youtube.com\/watch?v=wtLJPv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481832405838221312",
    "text" : "I\/O 14 is Live. @sundarpichai just stepped on stage, to welcome a room full of 6,000 developers in Moscone. https:\/\/t.co\/PzbSkqkXkC #io14",
    "id" : 481832405838221312,
    "created_at" : "2014-06-25 16:12:52 +0000",
    "user" : {
      "name" : "Google Developers",
      "screen_name" : "googledevs",
      "protected" : false,
      "id_str" : "50090898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756235654980308994\/JLbEEloM_normal.jpg",
      "id" : 50090898,
      "verified" : true
    }
  },
  "id" : 481835356921155584,
  "created_at" : "2014-06-25 16:24:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480190314129264641",
  "text" : "Your career is a story that you have the power to write.",
  "id" : 480190314129264641,
  "created_at" : "2014-06-21 03:27:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 69, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/LbEcd23IvR",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/3a4557a5-08c4-c6b4-38a5-70ec4d37a253\/",
      "display_url" : "workflowy.com\/shared\/3a4557a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480062508342861824",
  "text" : "Revised processes, concepts, principles and techniques inventory for #SFU CMPT-363 down to 31 items from 71 https:\/\/t.co\/LbEcd23IvR",
  "id" : 480062508342861824,
  "created_at" : "2014-06-20 18:59:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 0, 8 ],
      "id_str" : "5690792",
      "id" : 5690792
    }, {
      "name" : "Simon Fraser Univ.",
      "screen_name" : "SFU",
      "indices" : [ 128, 132 ],
      "id_str" : "8071702",
      "id" : 8071702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479813232559788032",
  "in_reply_to_user_id" : 5690792,
  "text" : "@draggin Really great talking with you today Jason! I'll keep an eye open for updates about the WordPress Community of Practice @SFU.",
  "id" : 479813232559788032,
  "created_at" : "2014-06-20 02:29:23 +0000",
  "in_reply_to_screen_name" : "draggin",
  "in_reply_to_user_id_str" : "5690792",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenn Stringer",
      "screen_name" : "jenn_stringer",
      "indices" : [ 3, 17 ],
      "id_str" : "14387163",
      "id" : 14387163
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "instcon",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479733574015279104",
  "text" : "RT @jenn_stringer: Robert Reich says technology will change the role of teachers. They will be coaches, mentors. Technology appropriately u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "instcon",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.6851215628, -111.5564231566 ]
    },
    "id_str" : "479650923237478402",
    "text" : "Robert Reich says technology will change the role of teachers. They will be coaches, mentors. Technology appropriately utilized.  #instcon",
    "id" : 479650923237478402,
    "created_at" : "2014-06-19 15:44:26 +0000",
    "user" : {
      "name" : "Jenn Stringer",
      "screen_name" : "jenn_stringer",
      "protected" : false,
      "id_str" : "14387163",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674836300273348608\/Sua-l9l__normal.jpg",
      "id" : 14387163,
      "verified" : false
    }
  },
  "id" : 479733574015279104,
  "created_at" : "2014-06-19 21:12:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/479720245016268800\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mYVJ6AQQKH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqhPBMpCUAAQlNf.png",
      "id_str" : "479720242306764800",
      "id" : 479720242306764800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqhPBMpCUAAQlNf.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mYVJ6AQQKH"
    } ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 7, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479720245016268800",
  "text" : "Making #CanvasLMS multi-device friendly is more of a challenge without a responsive framework, but certainly feasible http:\/\/t.co\/mYVJ6AQQKH",
  "id" : 479720245016268800,
  "created_at" : "2014-06-19 20:19:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 3, 10 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 36, 43 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/F6Kt2zmqQo",
      "expanded_url" : "http:\/\/bcopened.org\/bc-open-open-ed-chats\/",
      "display_url" : "bcopened.org\/bc-open-open-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479378692318040065",
  "text" : "RT @brlamb: Friday! Open Open Chat! @tanbob shares fantastic work using WordPress as an alternative to the LMS! Excited! http:\/\/t.co\/F6Kt2z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tannis Morgan",
        "screen_name" : "tanbob",
        "indices" : [ 24, 31 ],
        "id_str" : "10817782",
        "id" : 10817782
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/F6Kt2zmqQo",
        "expanded_url" : "http:\/\/bcopened.org\/bc-open-open-ed-chats\/",
        "display_url" : "bcopened.org\/bc-open-open-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "479376888280784896",
    "text" : "Friday! Open Open Chat! @tanbob shares fantastic work using WordPress as an alternative to the LMS! Excited! http:\/\/t.co\/F6Kt2zmqQo",
    "id" : 479376888280784896,
    "created_at" : "2014-06-18 21:35:31 +0000",
    "user" : {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "protected" : false,
      "id_str" : "745903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671910130498203649\/btEUG3ES_normal.jpg",
      "id" : 745903,
      "verified" : false
    }
  },
  "id" : 479378692318040065,
  "created_at" : "2014-06-18 21:42:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 8, 18 ]
    }, {
      "text" : "SFU",
      "indices" : [ 40, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/xXLuhlCQ5V",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/16304\/",
      "display_url" : "canvas.sfu.ca\/courses\/16304\/"
    } ]
  },
  "geo" : { },
  "id_str" : "479368250891841536",
  "text" : "Updated #CanvasLMS course companion for #SFU CMPT-363 https:\/\/t.co\/xXLuhlCQ5V Each page is intentionally designed to support student goals.",
  "id" : 479368250891841536,
  "created_at" : "2014-06-18 21:01:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 56, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/gbdtosbhvp",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/a7bcbdb1-25d5-9d99-3085-7156d91d6e96\/",
      "display_url" : "workflowy.com\/shared\/a7bcbdb\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/wXGUrKq8m3",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/77c66460-c9c5-32a1-0e43-0a81c5dbb7e8\/",
      "display_url" : "workflowy.com\/shared\/77c6646\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479362251011272704",
  "text" : "I've begun the open development of CMPT-363 this Fall @ #SFU. Learning outcomes: https:\/\/t.co\/gbdtosbhvp Assessment: https:\/\/t.co\/wXGUrKq8m3",
  "id" : 479362251011272704,
  "created_at" : "2014-06-18 20:37:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 3, 17 ],
      "id_str" : "260919324",
      "id" : 260919324
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 86, 101 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openeducation",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/AugXaUIw4Y",
      "expanded_url" : "http:\/\/blogs.ubc.ca\/chendricks\/2014\/06\/18\/develop-course-open\/",
      "display_url" : "blogs.ubc.ca\/chendricks\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479334847312175104",
  "text" : "RT @clhendricksbc: Why not do your course development in the open? A post inspired by @hibbittsdesign  http:\/\/t.co\/AugXaUIw4Y #openeducation",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 67, 82 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openeducation",
        "indices" : [ 107, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/AugXaUIw4Y",
        "expanded_url" : "http:\/\/blogs.ubc.ca\/chendricks\/2014\/06\/18\/develop-course-open\/",
        "display_url" : "blogs.ubc.ca\/chendricks\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "479312719246413824",
    "text" : "Why not do your course development in the open? A post inspired by @hibbittsdesign  http:\/\/t.co\/AugXaUIw4Y #openeducation",
    "id" : 479312719246413824,
    "created_at" : "2014-06-18 17:20:32 +0000",
    "user" : {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "protected" : false,
      "id_str" : "260919324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726838525086208000\/46wx7Jih_normal.jpg",
      "id" : 260919324,
      "verified" : false
    }
  },
  "id" : 479334847312175104,
  "created_at" : "2014-06-18 18:48:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479312600576958464",
  "geo" : { },
  "id_str" : "479334804417024000",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Thanks very much Christina, it's awesome to read about your own open course development plans!",
  "id" : 479334804417024000,
  "in_reply_to_status_id" : 479312600576958464,
  "created_at" : "2014-06-18 18:48:17 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "will engle",
      "screen_name" : "infology",
      "indices" : [ 3, 12 ],
      "id_str" : "93031146",
      "id" : 93031146
    }, {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 63, 70 ],
      "id_str" : "745903",
      "id" : 745903
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/65dxgir0xp",
      "expanded_url" : "http:\/\/abject.ca\/post-privacy\/",
      "display_url" : "abject.ca\/post-privacy\/"
    } ]
  },
  "geo" : { },
  "id_str" : "479067698907738112",
  "text" : "RT @infology: What is student privacy in a post privacy world? @brlamb's presentation at #etug on BC FIPPA Laws with a live DJ: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian Lamb",
        "screen_name" : "brlamb",
        "indices" : [ 49, 56 ],
        "id_str" : "745903",
        "id" : 745903
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 75, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/65dxgir0xp",
        "expanded_url" : "http:\/\/abject.ca\/post-privacy\/",
        "display_url" : "abject.ca\/post-privacy\/"
      } ]
    },
    "geo" : { },
    "id_str" : "479048063592325120",
    "text" : "What is student privacy in a post privacy world? @brlamb's presentation at #etug on BC FIPPA Laws with a live DJ: http:\/\/t.co\/65dxgir0xp",
    "id" : 479048063592325120,
    "created_at" : "2014-06-17 23:48:53 +0000",
    "user" : {
      "name" : "will engle",
      "screen_name" : "infology",
      "protected" : false,
      "id_str" : "93031146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1598136377\/icon_normal.jpg",
      "id" : 93031146,
      "verified" : false
    }
  },
  "id" : 479067698907738112,
  "created_at" : "2014-06-18 01:06:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 0, 11 ],
      "id_str" : "91634720",
      "id" : 91634720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478643176236777472",
  "geo" : { },
  "id_str" : "478737824624029696",
  "in_reply_to_user_id" : 91634720,
  "text" : "@kenjeffery Hi Ken, thanks for saying hello and the kind words! If you are interested in a coffee\/chat sometime at BCIT let me know via DM.",
  "id" : 478737824624029696,
  "in_reply_to_status_id" : 478643176236777472,
  "created_at" : "2014-06-17 03:16:06 +0000",
  "in_reply_to_screen_name" : "kenjeffery",
  "in_reply_to_user_id_str" : "91634720",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/478623264273477633\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/lZQ4gPHtS6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqRpUp8CAAAmO9l.png",
      "id_str" : "478623263984058368",
      "id" : 478623263984058368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqRpUp8CAAAmO9l.png",
      "sizes" : [ {
        "h" : 437,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1317,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 772,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1317,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lZQ4gPHtS6"
    } ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/GfNN9H5bbF",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/16304\/pages\/week-2-materials-sep-11-sep-17",
      "display_url" : "canvas.sfu.ca\/courses\/16304\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478623264273477633",
  "text" : "Experimenting with Embedly for required reading previews on my #CanvasLMS prototype site https:\/\/t.co\/GfNN9H5bbF http:\/\/t.co\/lZQ4gPHtS6",
  "id" : 478623264273477633,
  "created_at" : "2014-06-16 19:40:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kimberly Voll",
      "screen_name" : "zanytomato",
      "indices" : [ 0, 11 ],
      "id_str" : "199980153",
      "id" : 199980153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477939886083690496",
  "geo" : { },
  "id_str" : "477958372868644864",
  "in_reply_to_user_id" : 199980153,
  "text" : "@zanytomato What is today's relevant equivalent would you say? Back in the day, the same outcome was achieved for me with a VIC-20 :-)",
  "id" : 477958372868644864,
  "in_reply_to_status_id" : 477939886083690496,
  "created_at" : "2014-06-14 23:38:50 +0000",
  "in_reply_to_screen_name" : "zanytomato",
  "in_reply_to_user_id_str" : "199980153",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "levalee",
      "screen_name" : "levalee",
      "indices" : [ 0, 8 ],
      "id_str" : "17505659",
      "id" : 17505659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477626099438854145",
  "geo" : { },
  "id_str" : "477649642289512450",
  "in_reply_to_user_id" : 17505659,
  "text" : "@levalee Maybe a New West coffee chat again soon? I'll be in touch!",
  "id" : 477649642289512450,
  "in_reply_to_status_id" : 477626099438854145,
  "created_at" : "2014-06-14 03:12:03 +0000",
  "in_reply_to_screen_name" : "levalee",
  "in_reply_to_user_id_str" : "17505659",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Currie",
      "screen_name" : "Currie",
      "indices" : [ 0, 7 ],
      "id_str" : "1282151",
      "id" : 1282151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477574140430278656",
  "in_reply_to_user_id" : 1282151,
  "text" : "@Currie Sorry I missed you this time around Sylvia! Hope we can connect next time around.",
  "id" : 477574140430278656,
  "created_at" : "2014-06-13 22:12:02 +0000",
  "in_reply_to_screen_name" : "Currie",
  "in_reply_to_user_id_str" : "1282151",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Embedly",
      "screen_name" : "embedly",
      "indices" : [ 0, 8 ],
      "id_str" : "82485597",
      "id" : 82485597
    }, {
      "name" : "A.I",
      "screen_name" : "embed",
      "indices" : [ 9, 15 ],
      "id_str" : "288197385",
      "id" : 288197385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477541208135196673",
  "geo" : { },
  "id_str" : "477557192472535040",
  "in_reply_to_user_id" : 82485597,
  "text" : "@embedly @embed Thanks very much, but still no luck. I will email support as suggested.",
  "id" : 477557192472535040,
  "in_reply_to_status_id" : 477541208135196673,
  "created_at" : "2014-06-13 21:04:41 +0000",
  "in_reply_to_screen_name" : "embedly",
  "in_reply_to_user_id_str" : "82485597",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 41, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477556304450314240",
  "text" : "While I could only attend the first day, #etug once again inspires me to be a better educator. Such an open and welcoming community as well!",
  "id" : 477556304450314240,
  "created_at" : "2014-06-13 21:01:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 3, 10 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "will engle",
      "screen_name" : "infology",
      "indices" : [ 72, 81 ],
      "id_str" : "93031146",
      "id" : 93031146
    }, {
      "name" : "Erin Fields",
      "screen_name" : "Emefie",
      "indices" : [ 88, 95 ],
      "id_str" : "32193364",
      "id" : 32193364
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 12, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477550554155995137",
  "text" : "RT @brlamb: #etug is still a space where unapologetic idealism thrives. @infology &amp; @Emefie cite Freire's notion of education as \"practice \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "will engle",
        "screen_name" : "infology",
        "indices" : [ 60, 69 ],
        "id_str" : "93031146",
        "id" : 93031146
      }, {
        "name" : "Erin Fields",
        "screen_name" : "Emefie",
        "indices" : [ 76, 83 ],
        "id_str" : "32193364",
        "id" : 32193364
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "477545048045670400",
    "text" : "#etug is still a space where unapologetic idealism thrives. @infology &amp; @Emefie cite Freire's notion of education as \"practice of freedom\".",
    "id" : 477545048045670400,
    "created_at" : "2014-06-13 20:16:26 +0000",
    "user" : {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "protected" : false,
      "id_str" : "745903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671910130498203649\/btEUG3ES_normal.jpg",
      "id" : 745903,
      "verified" : false
    }
  },
  "id" : 477550554155995137,
  "created_at" : "2014-06-13 20:38:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477521136071081985",
  "geo" : { },
  "id_str" : "477523980455120896",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv Sounds great, I look forward to it!",
  "id" : 477523980455120896,
  "in_reply_to_status_id" : 477521136071081985,
  "created_at" : "2014-06-13 18:52:43 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 3, 14 ],
      "id_str" : "28429477",
      "id" : 28429477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/zD45ZrGO7s",
      "expanded_url" : "http:\/\/www.ds106rad.io\/listen",
      "display_url" : "ds106rad.io\/listen"
    } ]
  },
  "geo" : { },
  "id_str" : "477510617805246464",
  "text" : "RT @chadleaman: Broadcasting my gameshow live at http:\/\/t.co\/zD45ZrGO7s at #etug.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 59, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/zD45ZrGO7s",
        "expanded_url" : "http:\/\/www.ds106rad.io\/listen",
        "display_url" : "ds106rad.io\/listen"
      } ]
    },
    "geo" : { },
    "id_str" : "477510376645349376",
    "text" : "Broadcasting my gameshow live at http:\/\/t.co\/zD45ZrGO7s at #etug.",
    "id" : 477510376645349376,
    "created_at" : "2014-06-13 17:58:40 +0000",
    "user" : {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "protected" : false,
      "id_str" : "28429477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529010906080894976\/Ij-z3nNd_normal.png",
      "id" : 28429477,
      "verified" : false
    }
  },
  "id" : 477510617805246464,
  "created_at" : "2014-06-13 17:59:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Embedly",
      "screen_name" : "embedly",
      "indices" : [ 0, 8 ],
      "id_str" : "82485597",
      "id" : 82485597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/ER2iG4zZfT",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/16304",
      "display_url" : "canvas.sfu.ca\/courses\/16304"
    } ]
  },
  "geo" : { },
  "id_str" : "477509861626748928",
  "in_reply_to_user_id" : 82485597,
  "text" : "@embedly Loving Embedly Cards! Using it w Canvas LMS, but can't seem to left align the results - any hints? https:\/\/t.co\/ER2iG4zZfT Thanks!",
  "id" : 477509861626748928,
  "created_at" : "2014-06-13 17:56:37 +0000",
  "in_reply_to_screen_name" : "embedly",
  "in_reply_to_user_id_str" : "82485597",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 0, 11 ],
      "id_str" : "28429477",
      "id" : 28429477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477495612066123776",
  "in_reply_to_user_id" : 28429477,
  "text" : "@chadleaman Best of luck with your session today, it sounds awesome! Won't make it back for today's sessions, let's plan for a coffee soon.",
  "id" : 477495612066123776,
  "created_at" : "2014-06-13 17:00:00 +0000",
  "in_reply_to_screen_name" : "chadleaman",
  "in_reply_to_user_id_str" : "28429477",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 0, 5 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477494426302820352",
  "in_reply_to_user_id" : 17102936,
  "text" : "@etug Looks like my plans for attending today's sessions won't work out - had a great time yesterday with talks and networking, thank you!",
  "id" : 477494426302820352,
  "created_at" : "2014-06-13 16:55:17 +0000",
  "in_reply_to_screen_name" : "etug",
  "in_reply_to_user_id_str" : "17102936",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 0, 7 ],
      "id_str" : "745903",
      "id" : 745903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477166801399214080",
  "geo" : { },
  "id_str" : "477490794694070272",
  "in_reply_to_user_id" : 745903,
  "text" : "@brlamb Thanks very much Brian - it was great to chat with you yesterday!",
  "id" : 477490794694070272,
  "in_reply_to_status_id" : 477166801399214080,
  "created_at" : "2014-06-13 16:40:51 +0000",
  "in_reply_to_screen_name" : "brlamb",
  "in_reply_to_user_id_str" : "745903",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Kitchen",
      "screen_name" : "LynnKitchen",
      "indices" : [ 0, 12 ],
      "id_str" : "17526302",
      "id" : 17526302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477164248800309248",
  "geo" : { },
  "id_str" : "477490576980312065",
  "in_reply_to_user_id" : 17526302,
  "text" : "@LynnKitchen Thanks very much Lynn, it was my pleasure!",
  "id" : 477490576980312065,
  "in_reply_to_status_id" : 477164248800309248,
  "created_at" : "2014-06-13 16:39:59 +0000",
  "in_reply_to_screen_name" : "LynnKitchen",
  "in_reply_to_user_id_str" : "17526302",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Porter",
      "screen_name" : "dendroglyph",
      "indices" : [ 3, 15 ],
      "id_str" : "15170764",
      "id" : 15170764
    }, {
      "name" : "Amanda Coolidge",
      "screen_name" : "acoolidge",
      "indices" : [ 50, 60 ],
      "id_str" : "17416175",
      "id" : 17416175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcbooksprint",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477457069331595264",
  "text" : "RT @dendroglyph: This is amazing. Bravo team!  RT @acoolidge: Done!! 48,420 words. Interactive maps, videos, service learning activities  #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Coolidge",
        "screen_name" : "acoolidge",
        "indices" : [ 33, 43 ],
        "id_str" : "17416175",
        "id" : 17416175
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bcbooksprint",
        "indices" : [ 121, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "477348310395518978",
    "text" : "This is amazing. Bravo team!  RT @acoolidge: Done!! 48,420 words. Interactive maps, videos, service learning activities  #bcbooksprint",
    "id" : 477348310395518978,
    "created_at" : "2014-06-13 07:14:40 +0000",
    "user" : {
      "name" : "David Porter",
      "screen_name" : "dendroglyph",
      "protected" : false,
      "id_str" : "15170764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626046344\/bear_scratch_bw2_lzn_normal.jpg",
      "id" : 15170764,
      "verified" : false
    }
  },
  "id" : 477457069331595264,
  "created_at" : "2014-06-13 14:26:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Ab3zQAdPwC",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/etug-spring-2014-developing-a-course-in-the-open-a-case-study\/",
      "display_url" : "slides.com\/paulhibbitts\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477186720534761472",
  "text" : "Thanks to everyone who attended my #etug session on developing a course in the open! Slides are available at http:\/\/t.co\/Ab3zQAdPwC",
  "id" : 477186720534761472,
  "created_at" : "2014-06-12 20:32:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 3, 13 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG14",
      "indices" : [ 42, 49 ]
    }, {
      "text" : "etug",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477096266627694592",
  "text" : "RT @keroleenl: \"Game of Things\" at 8am at #ETUG14. Remember the past, consider the present, and think about the future of technology in edu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ETUG14",
        "indices" : [ 27, 34 ]
      }, {
        "text" : "etug",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "477092246873853952",
    "text" : "\"Game of Things\" at 8am at #ETUG14. Remember the past, consider the present, and think about the future of technology in education. #etug",
    "id" : 477092246873853952,
    "created_at" : "2014-06-12 14:17:10 +0000",
    "user" : {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "protected" : false,
      "id_str" : "887742962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515581656686546944\/Q76DpwVe_normal.png",
      "id" : 887742962,
      "verified" : false
    }
  },
  "id" : 477096266627694592,
  "created_at" : "2014-06-12 14:33:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477093353146699776",
  "geo" : { },
  "id_str" : "477093753618837504",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Best of luck! Awesome to see so much of the process itself in the open :-)",
  "id" : 477093753618837504,
  "in_reply_to_status_id" : 477093353146699776,
  "created_at" : "2014-06-12 14:23:09 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477080748453679104",
  "text" : "I'll never learn... working on some fine tuning for my presentation at #ETUG today about developing a course in the open @ 11:40 am in L207.",
  "id" : 477080748453679104,
  "created_at" : "2014-06-12 13:31:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476525471727747072",
  "geo" : { },
  "id_str" : "476955374663131136",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv @paulhibbittsSFU Thanks for spreading the news about my multi-device work with  #CanvasLMS Lynda!",
  "id" : 476955374663131136,
  "in_reply_to_status_id" : 476525471727747072,
  "created_at" : "2014-06-12 05:13:17 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 0, 5 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476874055983710209",
  "in_reply_to_user_id" : 17102936,
  "text" : "@etug Thanks so much for the surprise Starbucks card, love it :-)",
  "id" : 476874055983710209,
  "created_at" : "2014-06-11 23:50:09 +0000",
  "in_reply_to_screen_name" : "etug",
  "in_reply_to_user_id_str" : "17102936",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinegrow Web Editor",
      "screen_name" : "pinegrow",
      "indices" : [ 6, 15 ],
      "id_str" : "352962657",
      "id" : 352962657
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/476784318790905857\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/kzo4NKVpF5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp3gz2IIgAAnmu7.png",
      "id_str" : "476784316878716928",
      "id" : 476784316878716928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp3gz2IIgAAnmu7.png",
      "sizes" : [ {
        "h" : 621,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 943,
        "resize" : "fit",
        "w" : 1554
      } ],
      "display_url" : "pic.twitter.com\/kzo4NKVpF5"
    } ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 21, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/xXLuhlCQ5V",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/16304\/",
      "display_url" : "canvas.sfu.ca\/courses\/16304\/"
    } ]
  },
  "geo" : { },
  "id_str" : "476784318790905857",
  "text" : "Using @PineGrow with #CanvasLMS provides live preview\/code editing w CSS styling. Course site https:\/\/t.co\/xXLuhlCQ5V http:\/\/t.co\/kzo4NKVpF5",
  "id" : 476784318790905857,
  "created_at" : "2014-06-11 17:53:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Baxley",
      "screen_name" : "bbaxley",
      "indices" : [ 0, 8 ],
      "id_str" : "14161605",
      "id" : 14161605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476460423022387200",
  "geo" : { },
  "id_str" : "476477497849040896",
  "in_reply_to_user_id" : 14161605,
  "text" : "@bbaxley That's awesome news Bob, congratulations!",
  "id" : 476477497849040896,
  "in_reply_to_status_id" : 476460423022387200,
  "created_at" : "2014-06-10 21:34:22 +0000",
  "in_reply_to_screen_name" : "bbaxley",
  "in_reply_to_user_id_str" : "14161605",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/rqE63yEeK0",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/etug-spring-2014-developing-a-course-in-the-open-a-case-study#\/",
      "display_url" : "slides.com\/paulhibbitts\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476061390419927040",
  "text" : "Really looking forward to the #etug Spring Workshop this week! Sneak peek of my Developing a Course in the Open preso http:\/\/t.co\/rqE63yEeK0",
  "id" : 476061390419927040,
  "created_at" : "2014-06-09 18:00:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Lurie",
      "screen_name" : "portentint",
      "indices" : [ 3, 14 ],
      "id_str" : "3849391",
      "id" : 3849391
    }, {
      "name" : "Doug Gapinski",
      "screen_name" : "DougGapinski",
      "indices" : [ 97, 110 ],
      "id_str" : "10216312",
      "id" : 10216312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/PQTO5KO782",
      "expanded_url" : "http:\/\/slidesha.re\/1oDg2ws",
      "display_url" : "slidesha.re\/1oDg2ws"
    } ]
  },
  "geo" : { },
  "id_str" : "476038775038963713",
  "text" : "RT @portentint: Multi-Device Prototypes http:\/\/t.co\/PQTO5KO782 The tools alone made this read by @douggapinski worth it",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Doug Gapinski",
        "screen_name" : "DougGapinski",
        "indices" : [ 81, 94 ],
        "id_str" : "10216312",
        "id" : 10216312
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/PQTO5KO782",
        "expanded_url" : "http:\/\/slidesha.re\/1oDg2ws",
        "display_url" : "slidesha.re\/1oDg2ws"
      } ]
    },
    "geo" : { },
    "id_str" : "476034770259161088",
    "text" : "Multi-Device Prototypes http:\/\/t.co\/PQTO5KO782 The tools alone made this read by @douggapinski worth it",
    "id" : 476034770259161088,
    "created_at" : "2014-06-09 16:15:08 +0000",
    "user" : {
      "name" : "Ian Lurie",
      "screen_name" : "portentint",
      "protected" : false,
      "id_str" : "3849391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1992847527\/headshot1cropped2_normal.jpg",
      "id" : 3849391,
      "verified" : false
    }
  },
  "id" : 476038775038963713,
  "created_at" : "2014-06-09 16:31:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Ridden",
      "screen_name" : "EduRidden",
      "indices" : [ 0, 10 ],
      "id_str" : "9198142",
      "id" : 9198142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475079099757891584",
  "geo" : { },
  "id_str" : "475082397965242368",
  "in_reply_to_user_id" : 9198142,
  "text" : "@EduRidden Welcome to Canada, however briefly!",
  "id" : 475082397965242368,
  "in_reply_to_status_id" : 475079099757891584,
  "created_at" : "2014-06-07 01:10:44 +0000",
  "in_reply_to_screen_name" : "EduRidden",
  "in_reply_to_user_id_str" : "9198142",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Winer",
      "screen_name" : "davewiner",
      "indices" : [ 3, 13 ],
      "id_str" : "3839",
      "id" : 3839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/6krHAbQuuL",
      "expanded_url" : "http:\/\/kng.ht\/PJBliT",
      "display_url" : "kng.ht\/PJBliT"
    } ]
  },
  "geo" : { },
  "id_str" : "475032901285724160",
  "text" : "RT @davewiner: Knight News Challenge: Using outliners to enable open science documentation. http:\/\/t.co\/6krHAbQuuL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/fargo.io\/\" rel=\"nofollow\"\u003EFargo Bridge\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/6krHAbQuuL",
        "expanded_url" : "http:\/\/kng.ht\/PJBliT",
        "display_url" : "kng.ht\/PJBliT"
      } ]
    },
    "geo" : { },
    "id_str" : "475030152494452736",
    "text" : "Knight News Challenge: Using outliners to enable open science documentation. http:\/\/t.co\/6krHAbQuuL",
    "id" : 475030152494452736,
    "created_at" : "2014-06-06 21:43:08 +0000",
    "user" : {
      "name" : "Dave Winer",
      "screen_name" : "davewiner",
      "protected" : false,
      "id_str" : "3839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716686126254321664\/v3citfg4_normal.jpg",
      "id" : 3839,
      "verified" : true
    }
  },
  "id" : 475032901285724160,
  "created_at" : "2014-06-06 21:54:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/UbWsdPACcq",
      "expanded_url" : "http:\/\/1drv.ms\/1f0v0L7",
      "display_url" : "1drv.ms\/1f0v0L7"
    } ]
  },
  "geo" : { },
  "id_str" : "474929508898729986",
  "text" : "A great group of participants in yesterday's multi-device learning experiences workshop! Explore the online companion http:\/\/t.co\/UbWsdPACcq",
  "id" : 474929508898729986,
  "created_at" : "2014-06-06 15:03:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web \uD83C\uDF0D\uD83D\uDCBB\uD83D\uDCF1",
      "screen_name" : "TheNextWeb",
      "indices" : [ 3, 14 ],
      "id_str" : "10876852",
      "id" : 10876852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/dKdfOt4Dbn",
      "expanded_url" : "http:\/\/tnw.co\/1rbyvQI",
      "display_url" : "tnw.co\/1rbyvQI"
    } ]
  },
  "geo" : { },
  "id_str" : "474766656795717632",
  "text" : "RT @TheNextWeb: Why you should build your product in public http:\/\/t.co\/dKdfOt4Dbn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/dKdfOt4Dbn",
        "expanded_url" : "http:\/\/tnw.co\/1rbyvQI",
        "display_url" : "tnw.co\/1rbyvQI"
      } ]
    },
    "geo" : { },
    "id_str" : "460098337023488000",
    "text" : "Why you should build your product in public http:\/\/t.co\/dKdfOt4Dbn",
    "id" : 460098337023488000,
    "created_at" : "2014-04-26 16:49:26 +0000",
    "user" : {
      "name" : "The Next Web \uD83C\uDF0D\uD83D\uDCBB\uD83D\uDCF1",
      "screen_name" : "TheNextWeb",
      "protected" : false,
      "id_str" : "10876852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712955373557325824\/CZ2ne8yK_normal.jpg",
      "id" : 10876852,
      "verified" : true
    }
  },
  "id" : 474766656795717632,
  "created_at" : "2014-06-06 04:16:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kato.im",
      "screen_name" : "kato_im",
      "indices" : [ 52, 60 ],
      "id_str" : "1026990656",
      "id" : 1026990656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/okNuQJX2Wx",
      "expanded_url" : "http:\/\/blog.kato.im\/embedded-customer-development-rooms\/",
      "display_url" : "blog.kato.im\/embedded-custo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474225333558718464",
  "text" : "For persistent and private coaching\/mentoring uses, @kato_im just keeps getting better and better! http:\/\/t.co\/okNuQJX2Wx",
  "id" : 474225333558718464,
  "created_at" : "2014-06-04 16:25:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 73, 82 ],
      "id_str" : "16891384",
      "id" : 16891384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/qCaN0oiPlE",
      "expanded_url" : "http:\/\/pragprog.com\/magazines\/2009-09\/responsive-design",
      "display_url" : "pragprog.com\/magazines\/2009\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474223506872233985",
  "text" : "Great insight: \u201COur designs shape us as much as we shape our designs\u201D by @KentBeck http:\/\/t.co\/qCaN0oiPlE",
  "id" : 474223506872233985,
  "created_at" : "2014-06-04 16:17:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UBC Robson Square",
      "screen_name" : "UBCRobsonSquare",
      "indices" : [ 80, 96 ],
      "id_str" : "210914069",
      "id" : 210914069
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iy103",
      "indices" : [ 30, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/UbWsdPACcq",
      "expanded_url" : "http:\/\/1drv.ms\/1f0v0L7",
      "display_url" : "1drv.ms\/1f0v0L7"
    } ]
  },
  "geo" : { },
  "id_str" : "474218971688738817",
  "text" : "Looking forward to tomorrow's #iy103 multi-device learning experiences workshop @UBCRobsonSquare. OneNote companion http:\/\/t.co\/UbWsdPACcq",
  "id" : 474218971688738817,
  "created_at" : "2014-06-04 15:59:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 97, 107 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/OFkPfYpzlh",
      "expanded_url" : "http:\/\/shar.es\/VM70j",
      "display_url" : "shar.es\/VM70j"
    } ]
  },
  "geo" : { },
  "id_str" : "473880198689980417",
  "text" : "Empirical Development of Heuristics for Touch Interfaces :: UXmatters http:\/\/t.co\/OFkPfYpzlh via @sharethis",
  "id" : 473880198689980417,
  "created_at" : "2014-06-03 17:33:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/473611507365085184\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/tvFDdPuGpc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpKbKBEIUAAyXoc.png",
      "id_str" : "473611507214077952",
      "id" : 473611507214077952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpKbKBEIUAAyXoc.png",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tvFDdPuGpc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473611507365085184",
  "text" : "I still love you Apple, but a mobile-friendly sign in page would be nice to see - after all it is 2014! http:\/\/t.co\/tvFDdPuGpc",
  "id" : 473611507365085184,
  "created_at" : "2014-06-02 23:45:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 23, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/xXLuhlCQ5V",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/16304\/",
      "display_url" : "canvas.sfu.ca\/courses\/16304\/"
    } ]
  },
  "geo" : { },
  "id_str" : "473572613311049728",
  "text" : "Looks like CMPT 363 at #SFU is a go for this Fall. Lots of exciting plans for the course! Prototype course companion https:\/\/t.co\/xXLuhlCQ5V",
  "id" : 473572613311049728,
  "created_at" : "2014-06-02 21:11:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UBC Robson Square",
      "screen_name" : "UBCRobsonSquare",
      "indices" : [ 98, 114 ],
      "id_str" : "210914069",
      "id" : 210914069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/QAZDgXiHWw",
      "expanded_url" : "http:\/\/www.cstudies.ubc.ca\/a\/Course\/Designing-Multi-device-Learning-Experiences\/IY103\/",
      "display_url" : "cstudies.ubc.ca\/a\/Course\/Desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473542903608770560",
  "text" : "Interested in multi-device learning experiences? Last chance to register for my June 5th Workshop @UBCRobsonSquare http:\/\/t.co\/QAZDgXiHWw",
  "id" : 473542903608770560,
  "created_at" : "2014-06-02 19:13:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]