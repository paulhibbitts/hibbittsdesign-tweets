Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BraveNewCode",
      "screen_name" : "BraveNewCode",
      "indices" : [ 3, 16 ],
      "id_str" : "89039840",
      "id" : 89039840
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mobile",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/MvgmBopTAF",
      "expanded_url" : "http:\/\/www.bravenewcode.com\/",
      "display_url" : "bravenewcode.com"
    } ]
  },
  "geo" : { },
  "id_str" : "329391365593104384",
  "text" : "RT @bravenewcode: All-new themes. Endless possibilities. Preview WPtouch Pro 3.0 [Video] http:\/\/t.co\/MvgmBopTAF #mobile",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mobile",
        "indices" : [ 94, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/MvgmBopTAF",
        "expanded_url" : "http:\/\/www.bravenewcode.com\/",
        "display_url" : "bravenewcode.com"
      } ]
    },
    "geo" : { },
    "id_str" : "329386559767998464",
    "text" : "All-new themes. Endless possibilities. Preview WPtouch Pro 3.0 [Video] http:\/\/t.co\/MvgmBopTAF #mobile",
    "id" : 329386559767998464,
    "created_at" : "2013-05-01 00:07:30 +0000",
    "user" : {
      "name" : "WPtouch",
      "screen_name" : "wptouch",
      "protected" : false,
      "id_str" : "15478959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462325592214343681\/qQ0_HpkJ_normal.png",
      "id" : 15478959,
      "verified" : false
    }
  },
  "id" : 329391365593104384,
  "created_at" : "2013-05-01 00:26:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BraveNewCode",
      "screen_name" : "BraveNewCode",
      "indices" : [ 0, 13 ],
      "id_str" : "89039840",
      "id" : 89039840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329386559767998464",
  "geo" : { },
  "id_str" : "329389330604888065",
  "in_reply_to_user_id" : 15478959,
  "text" : "@bravenewcode WPtouch Pro 3.0 looks awesome, all the best with the upcoming release!",
  "id" : 329389330604888065,
  "in_reply_to_status_id" : 329386559767998464,
  "created_at" : "2013-05-01 00:18:30 +0000",
  "in_reply_to_screen_name" : "wptouch",
  "in_reply_to_user_id_str" : "15478959",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/ml6Zi6NZGp",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/49d37085-8c02-2c84-188d-034e29ef4812\/",
      "display_url" : "workflowy.com\/shared\/49d3708\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329381807302787073",
  "text" : "First draft of topics and readings for my 3rd year UI course at SFU Computing Science: https:\/\/t.co\/ml6Zi6NZGp UX peeps, any comments?",
  "id" : 329381807302787073,
  "created_at" : "2013-04-30 23:48:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Epic",
      "screen_name" : "epictalk",
      "indices" : [ 3, 12 ],
      "id_str" : "114431814",
      "id" : 114431814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/KiIhDdF9gG",
      "expanded_url" : "http:\/\/ow.ly\/kz2tY",
      "display_url" : "ow.ly\/kz2tY"
    } ]
  },
  "geo" : { },
  "id_str" : "329257242408910849",
  "text" : "RT @epictalk: Moodle embraces the true multi-device experience http:\/\/t.co\/KiIhDdF9gG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/KiIhDdF9gG",
        "expanded_url" : "http:\/\/ow.ly\/kz2tY",
        "display_url" : "ow.ly\/kz2tY"
      } ]
    },
    "geo" : { },
    "id_str" : "329225187138605058",
    "text" : "Moodle embraces the true multi-device experience http:\/\/t.co\/KiIhDdF9gG",
    "id" : 329225187138605058,
    "created_at" : "2013-04-30 13:26:15 +0000",
    "user" : {
      "name" : "Epic",
      "screen_name" : "epictalk",
      "protected" : false,
      "id_str" : "114431814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3283379121\/2eaa0aecd2caf0771c52f0b063aa207c_normal.jpeg",
      "id" : 114431814,
      "verified" : false
    }
  },
  "id" : 329257242408910849,
  "created_at" : "2013-04-30 15:33:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328968603594534912",
  "text" : "For brainstorming multi-device user stories: \u201CAs a &lt;role&gt; when\/while &lt;situation&gt;, I want to &lt;goal\/desire&gt; so that &lt;benefit&gt;.\u201D Thoughts?",
  "id" : 328968603594534912,
  "created_at" : "2013-04-29 20:26:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Schroeter",
      "screen_name" : "matthanns",
      "indices" : [ 3, 13 ],
      "id_str" : "22445401",
      "id" : 22445401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/28mlMOnGKf",
      "expanded_url" : "http:\/\/www.uxmatters.com\/mt\/archives\/2013\/03\/common-misconceptions-about-touch.php",
      "display_url" : "uxmatters.com\/mt\/archives\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327919872401092608",
  "text" : "RT @matthanns: Common Misconceptions About Touch http:\/\/t.co\/28mlMOnGKf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/28mlMOnGKf",
        "expanded_url" : "http:\/\/www.uxmatters.com\/mt\/archives\/2013\/03\/common-misconceptions-about-touch.php",
        "display_url" : "uxmatters.com\/mt\/archives\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "327878202271875072",
    "text" : "Common Misconceptions About Touch http:\/\/t.co\/28mlMOnGKf",
    "id" : 327878202271875072,
    "created_at" : "2013-04-26 20:13:49 +0000",
    "user" : {
      "name" : "Matt Schroeter",
      "screen_name" : "matthanns",
      "protected" : false,
      "id_str" : "22445401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764974621238059008\/0ZkuY25w_normal.jpg",
      "id" : 22445401,
      "verified" : false
    }
  },
  "id" : 327919872401092608,
  "created_at" : "2013-04-26 22:59:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 0, 8 ],
      "id_str" : "10675",
      "id" : 10675
    }, {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 16, 28 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327905457794584577",
  "geo" : { },
  "id_str" : "327919452907769856",
  "in_reply_to_user_id" : 10675,
  "text" : "@gordonr @bctia @openroadies Awesome news - congrats to you and the entire team!",
  "id" : 327919452907769856,
  "in_reply_to_status_id" : 327905457794584577,
  "created_at" : "2013-04-26 22:57:44 +0000",
  "in_reply_to_screen_name" : "gordonr",
  "in_reply_to_user_id_str" : "10675",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fliptheswitch",
      "indices" : [ 3, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327540624758816768",
  "text" : "My #fliptheswitch day was April 22nd as well, when it was suddenly clear my mobile learning work was really multi-device experience design.",
  "id" : 327540624758816768,
  "created_at" : "2013-04-25 21:52:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 0, 8 ],
      "id_str" : "10675",
      "id" : 10675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327453435857350656",
  "geo" : { },
  "id_str" : "327458078909931521",
  "in_reply_to_user_id" : 10675,
  "text" : "@gordonr Keyspan Presentation Remote Pro! Mine has never let me down and great wireless range for walkabouts.",
  "id" : 327458078909931521,
  "in_reply_to_status_id" : 327453435857350656,
  "created_at" : "2013-04-25 16:24:24 +0000",
  "in_reply_to_screen_name" : "gordonr",
  "in_reply_to_user_id_str" : "10675",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 0, 8 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327409466473594880",
  "geo" : { },
  "id_str" : "327449581522653184",
  "in_reply_to_user_id" : 1550251,
  "text" : "@dmitryn Thanks very much Dmitry!",
  "id" : 327449581522653184,
  "in_reply_to_status_id" : 327409466473594880,
  "created_at" : "2013-04-25 15:50:38 +0000",
  "in_reply_to_screen_name" : "dmitryn",
  "in_reply_to_user_id_str" : "1550251",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baldwin",
      "screen_name" : "benry",
      "indices" : [ 0, 6 ],
      "id_str" : "1969441",
      "id" : 1969441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327157617858314241",
  "geo" : { },
  "id_str" : "327159573213487104",
  "in_reply_to_user_id" : 1969441,
  "text" : "@benry I actually enjoyed reading the associated \"Legal Terms\", as curiosity got the best of me.",
  "id" : 327159573213487104,
  "in_reply_to_status_id" : 327157617858314241,
  "created_at" : "2013-04-24 20:38:15 +0000",
  "in_reply_to_screen_name" : "benry",
  "in_reply_to_user_id_str" : "1969441",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327153210794078212",
  "in_reply_to_user_id" : 478963764,
  "text" : "@langilj2012 Thanks for the RT Langille! Interesting times.",
  "id" : 327153210794078212,
  "created_at" : "2013-04-24 20:12:58 +0000",
  "in_reply_to_screen_name" : "ECFjournal",
  "in_reply_to_user_id_str" : "478963764",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 0, 8 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327148067512012800",
  "in_reply_to_user_id" : 1550251,
  "text" : "@dmitryn Thanks for the RT! Any assessment factors to add\/change\/remove from your perspective? Hope all is well in Ottawa.",
  "id" : 327148067512012800,
  "created_at" : "2013-04-24 19:52:32 +0000",
  "in_reply_to_screen_name" : "dmitryn",
  "in_reply_to_user_id_str" : "1550251",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327117735463112704",
  "text" : "How do you assess the suitability of a 'mobile first' approach? My main factors: audience &amp; business goals, contexts, content, and devices.",
  "id" : 327117735463112704,
  "created_at" : "2013-04-24 17:52:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326821020155670529",
  "text" : "The impact of multi-device experiences varies with regards to domain. Example: mobile learning vs. traditional elearning. Other examples?",
  "id" : 326821020155670529,
  "created_at" : "2013-04-23 22:12:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Haney",
      "screen_name" : "notasausage",
      "indices" : [ 3, 15 ],
      "id_str" : "11718",
      "id" : 11718
    }, {
      "name" : "Second Screen",
      "screen_name" : "secondscreen",
      "indices" : [ 71, 84 ],
      "id_str" : "1096207496",
      "id" : 1096207496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FITCTO",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/sfaRwDK2jC",
      "expanded_url" : "http:\/\/bit.ly\/XUFQau",
      "display_url" : "bit.ly\/XUFQau"
    } ]
  },
  "geo" : { },
  "id_str" : "326804718749884417",
  "text" : "RT @notasausage: If you liked our #FITCTO presentation, keep an eye on @SecondScreen for insights into our multi-device world: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Second Screen",
        "screen_name" : "secondscreen",
        "indices" : [ 54, 67 ],
        "id_str" : "1096207496",
        "id" : 1096207496
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FITCTO",
        "indices" : [ 17, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/sfaRwDK2jC",
        "expanded_url" : "http:\/\/bit.ly\/XUFQau",
        "display_url" : "bit.ly\/XUFQau"
      } ]
    },
    "geo" : { },
    "id_str" : "326802427623903233",
    "text" : "If you liked our #FITCTO presentation, keep an eye on @SecondScreen for insights into our multi-device world: http:\/\/t.co\/sfaRwDK2jC",
    "id" : 326802427623903233,
    "created_at" : "2013-04-23 20:59:05 +0000",
    "user" : {
      "name" : "Patrick Haney",
      "screen_name" : "notasausage",
      "protected" : false,
      "id_str" : "11718",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746334254867554304\/f-cwmzFI_normal.jpg",
      "id" : 11718,
      "verified" : false
    }
  },
  "id" : 326804718749884417,
  "created_at" : "2013-04-23 21:08:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Scott",
      "screen_name" : "billwscott",
      "indices" : [ 3, 14 ],
      "id_str" : "17383191",
      "id" : 17383191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/iltbgu4TwF",
      "expanded_url" : "http:\/\/designmind.frogdesign.com\/blog\/unraveling-html5-vs-native.html",
      "display_url" : "designmind.frogdesign.com\/blog\/unravelin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326730922013626369",
  "text" : "RT @billwscott: Anyone confused about the mobile native vs mobile html5 debate? Read this. Share it. Clearly lays out choices.  http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/iltbgu4TwF",
        "expanded_url" : "http:\/\/designmind.frogdesign.com\/blog\/unraveling-html5-vs-native.html",
        "display_url" : "designmind.frogdesign.com\/blog\/unravelin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "326729883801767936",
    "text" : "Anyone confused about the mobile native vs mobile html5 debate? Read this. Share it. Clearly lays out choices.  http:\/\/t.co\/iltbgu4TwF",
    "id" : 326729883801767936,
    "created_at" : "2013-04-23 16:10:49 +0000",
    "user" : {
      "name" : "Bill Scott",
      "screen_name" : "billwscott",
      "protected" : false,
      "id_str" : "17383191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754468737818951681\/z7yzbAyj_normal.jpg",
      "id" : 17383191,
      "verified" : false
    }
  },
  "id" : 326730922013626369,
  "created_at" : "2013-04-23 16:14:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/AW7Qz8Pi1i",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/b0ddae89-8156-6687-ba26-46e5bf624a52\/",
      "display_url" : "workflowy.com\/shared\/b0ddae8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326455200372101121",
  "text" : "Multi-device experiences are getting more common, are you ready? First draft of high-level design principles https:\/\/t.co\/AW7Qz8Pi1i",
  "id" : 326455200372101121,
  "created_at" : "2013-04-22 21:59:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetroapp.com\" rel=\"nofollow\"\u003ETweetro+ for Windows 8\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Learndot",
      "screen_name" : "Learndot",
      "indices" : [ 3, 12 ],
      "id_str" : "44676673",
      "id" : 44676673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2kuOzH6pwr",
      "expanded_url" : "http:\/\/bit.ly\/11dH8hn",
      "display_url" : "bit.ly\/11dH8hn"
    } ]
  },
  "geo" : { },
  "id_str" : "324620018442711040",
  "text" : "RT @Learndot: Want to build online courses for your business? Launching new free plan and web signup: Get a Learndot, right now: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/2kuOzH6pwr",
        "expanded_url" : "http:\/\/bit.ly\/11dH8hn",
        "display_url" : "bit.ly\/11dH8hn"
      } ]
    },
    "geo" : { },
    "id_str" : "324576817631600641",
    "text" : "Want to build online courses for your business? Launching new free plan and web signup: Get a Learndot, right now: http:\/\/t.co\/2kuOzH6pwr",
    "id" : 324576817631600641,
    "created_at" : "2013-04-17 17:35:18 +0000",
    "user" : {
      "name" : "Learndot",
      "screen_name" : "Learndot",
      "protected" : false,
      "id_str" : "44676673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466305704953782272\/qFe_6yX8_normal.png",
      "id" : 44676673,
      "verified" : false
    }
  },
  "id" : 324620018442711040,
  "created_at" : "2013-04-17 20:26:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetroapp.com\" rel=\"nofollow\"\u003ETweetro+ for Windows 8\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Lambert",
      "screen_name" : "prlambert",
      "indices" : [ 0, 10 ],
      "id_str" : "17029883",
      "id" : 17029883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324582697899020288",
  "geo" : { },
  "id_str" : "324619588618842113",
  "in_reply_to_user_id" : 17029883,
  "text" : "@prlambert Congratulations Paul!",
  "id" : 324619588618842113,
  "in_reply_to_status_id" : 324582697899020288,
  "created_at" : "2013-04-17 20:25:15 +0000",
  "in_reply_to_screen_name" : "prlambert",
  "in_reply_to_user_id_str" : "17029883",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinny Stocker",
      "screen_name" : "vinnystocker",
      "indices" : [ 3, 16 ],
      "id_str" : "168094459",
      "id" : 168094459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2013",
      "indices" : [ 18, 28 ]
    }, {
      "text" : "moodle",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/x6nASLKiWG",
      "expanded_url" : "http:\/\/2013.imoot.org\/mod\/forum\/discuss.php?d=518",
      "display_url" : "2013.imoot.org\/mod\/forum\/disc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324270605773963266",
  "text" : "RT @vinnystocker: #iMoot2013 presentations announced. http:\/\/t.co\/x6nASLKiWG #moodle Congratulations to all the presenters! It's going t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iMoot2013",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "moodle",
        "indices" : [ 59, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/x6nASLKiWG",
        "expanded_url" : "http:\/\/2013.imoot.org\/mod\/forum\/discuss.php?d=518",
        "display_url" : "2013.imoot.org\/mod\/forum\/disc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "324063267733520384",
    "text" : "#iMoot2013 presentations announced. http:\/\/t.co\/x6nASLKiWG #moodle Congratulations to all the presenters! It's going to be awesome!",
    "id" : 324063267733520384,
    "created_at" : "2013-04-16 07:34:38 +0000",
    "user" : {
      "name" : "Vinny Stocker",
      "screen_name" : "vinnystocker",
      "protected" : false,
      "id_str" : "168094459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566128010433011712\/MKrSVPFf_normal.jpeg",
      "id" : 168094459,
      "verified" : false
    }
  },
  "id" : 324270605773963266,
  "created_at" : "2013-04-16 21:18:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 10, 15 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/JDvmf38rqc",
      "expanded_url" : "http:\/\/bit.ly\/13bWHKc",
      "display_url" : "bit.ly\/13bWHKc"
    } ]
  },
  "geo" : { },
  "id_str" : "324209211317821441",
  "text" : "RT @etug: @etug Call for Posters for the Spring workshop is still Open! http:\/\/t.co\/JDvmf38rqc Deadline is May 16th",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 0, 5 ],
        "id_str" : "17102936",
        "id" : 17102936
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/JDvmf38rqc",
        "expanded_url" : "http:\/\/bit.ly\/13bWHKc",
        "display_url" : "bit.ly\/13bWHKc"
      } ]
    },
    "geo" : { },
    "id_str" : "324207170122035201",
    "in_reply_to_user_id" : 17102936,
    "text" : "@etug Call for Posters for the Spring workshop is still Open! http:\/\/t.co\/JDvmf38rqc Deadline is May 16th",
    "id" : 324207170122035201,
    "created_at" : "2013-04-16 17:06:27 +0000",
    "in_reply_to_screen_name" : "etug",
    "in_reply_to_user_id_str" : "17102936",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 324209211317821441,
  "created_at" : "2013-04-16 17:14:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Scapin, Ph.D.",
      "screen_name" : "rscapin",
      "indices" : [ 3, 11 ],
      "id_str" : "2755301",
      "id" : 2755301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wordpress",
      "indices" : [ 30, 40 ]
    }, {
      "text" : "LMS",
      "indices" : [ 60, 64 ]
    }, {
      "text" : "edtech",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ummMyVJOkW",
      "expanded_url" : "http:\/\/scap.in\/14pY9JM",
      "display_url" : "scap.in\/14pY9JM"
    } ]
  },
  "geo" : { },
  "id_str" : "323829709907570688",
  "text" : "RT @rscapin: Using plugins in #Wordpress as a decentralized #LMS, data management, and curating time capsules #edtech http:\/\/t.co\/ummMyVJOkW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Wordpress",
        "indices" : [ 17, 27 ]
      }, {
        "text" : "LMS",
        "indices" : [ 47, 51 ]
      }, {
        "text" : "edtech",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/ummMyVJOkW",
        "expanded_url" : "http:\/\/scap.in\/14pY9JM",
        "display_url" : "scap.in\/14pY9JM"
      } ]
    },
    "geo" : { },
    "id_str" : "323814855494754304",
    "text" : "Using plugins in #Wordpress as a decentralized #LMS, data management, and curating time capsules #edtech http:\/\/t.co\/ummMyVJOkW",
    "id" : 323814855494754304,
    "created_at" : "2013-04-15 15:07:32 +0000",
    "user" : {
      "name" : "Rafael Scapin, Ph.D.",
      "screen_name" : "rscapin",
      "protected" : false,
      "id_str" : "2755301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582370192698806272\/8ZY9I3Wl_normal.jpg",
      "id" : 2755301,
      "verified" : false
    }
  },
  "id" : 323829709907570688,
  "created_at" : "2013-04-15 16:06:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Kessler",
      "screen_name" : "dkdsgn",
      "indices" : [ 3, 10 ],
      "id_str" : "2505183032",
      "id" : 2505183032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322892044760649731",
  "text" : "RT @dkdsgn: Samsung Android Screen Sizes:\n2.8\n3.14\n3.2\n3.4\n3.5\n3.6\n3.65\n3.7\n3.97\n4\n4.2\n4.27\n4.3\n4.5\n4.52\n4.65\n4.8\n5\n5.3\n5.5\n5.8\n6.3\n7\n7. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "322342508912852992",
    "text" : "Samsung Android Screen Sizes:\n2.8\n3.14\n3.2\n3.4\n3.5\n3.6\n3.65\n3.7\n3.97\n4\n4.2\n4.27\n4.3\n4.5\n4.52\n4.65\n4.8\n5\n5.3\n5.5\n5.8\n6.3\n7\n7.7\n8\n10\n10.1",
    "id" : 322342508912852992,
    "created_at" : "2013-04-11 13:36:57 +0000",
    "user" : {
      "name" : "D\u039ER\u039EK \u26A1 K\u039ESSL\u039ER",
      "screen_name" : "derekakessler",
      "protected" : false,
      "id_str" : "67721376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458748180310413312\/gJv0iCFJ_normal.jpeg",
      "id" : 67721376,
      "verified" : false
    }
  },
  "id" : 322892044760649731,
  "created_at" : "2013-04-13 02:00:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322467590612066305",
  "geo" : { },
  "id_str" : "322468094964555776",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh Glad to help out! Good luck with your roundtable tonight.",
  "id" : 322468094964555776,
  "in_reply_to_status_id" : 322467590612066305,
  "created_at" : "2013-04-11 21:55:59 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    }, {
      "name" : "VFS Digital Design",
      "screen_name" : "vfsDesign",
      "indices" : [ 7, 17 ],
      "id_str" : "94396228",
      "id" : 94396228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322463670498123776",
  "geo" : { },
  "id_str" : "322467601160732672",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh @vfsDesign #5 Don\u2019t seek credit \u2013 share or let others take it.",
  "id" : 322467601160732672,
  "in_reply_to_status_id" : 322463670498123776,
  "created_at" : "2013-04-11 21:54:01 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    }, {
      "name" : "VFS Digital Design",
      "screen_name" : "vfsDesign",
      "indices" : [ 7, 17 ],
      "id_str" : "94396228",
      "id" : 94396228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322463670498123776",
  "geo" : { },
  "id_str" : "322466818298085376",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh @vfsdesign #4. Try one new technique every project, and view it as an experiment.",
  "id" : 322466818298085376,
  "in_reply_to_status_id" : 322463670498123776,
  "created_at" : "2013-04-11 21:50:55 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    }, {
      "name" : "VFS Digital Design",
      "screen_name" : "vfsDesign",
      "indices" : [ 7, 17 ],
      "id_str" : "94396228",
      "id" : 94396228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322463670498123776",
  "geo" : { },
  "id_str" : "322466592967520256",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh @vfsdesign #3 Track when work makes you feel energized, and use this list to help guide your pursuit of future work.",
  "id" : 322466592967520256,
  "in_reply_to_status_id" : 322463670498123776,
  "created_at" : "2013-04-11 21:50:01 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    }, {
      "name" : "VFS Digital Design",
      "screen_name" : "vfsDesign",
      "indices" : [ 7, 17 ],
      "id_str" : "94396228",
      "id" : 94396228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322463670498123776",
  "geo" : { },
  "id_str" : "322466193954971648",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh @vfsdesign #2 Humility is just as important as design skills.",
  "id" : 322466193954971648,
  "in_reply_to_status_id" : 322463670498123776,
  "created_at" : "2013-04-11 21:48:26 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    }, {
      "name" : "VFS Digital Design",
      "screen_name" : "vfsDesign",
      "indices" : [ 7, 17 ],
      "id_str" : "94396228",
      "id" : 94396228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322463670498123776",
  "geo" : { },
  "id_str" : "322465949376716800",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh @vfsdesign #1 Your education is just starting with graduation. Lifelong learning is your future.",
  "id" : 322465949376716800,
  "in_reply_to_status_id" : 322463670498123776,
  "created_at" : "2013-04-11 21:47:28 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RunRev",
      "screen_name" : "RunRev",
      "indices" : [ 3, 10 ],
      "id_str" : "2882852739",
      "id" : 2882852739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/nAspz7LlJ4",
      "expanded_url" : "http:\/\/www.runrev.com\/products\/Open-Source\/Community-Edition-Overview\/",
      "display_url" : "runrev.com\/products\/Open-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "322020718076391424",
  "text" : "RT @runrev: LiveCode Open Source is here! Go get it http:\/\/t.co\/nAspz7LlJ4 Thanks for your support and patience - that was a late night.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/nAspz7LlJ4",
        "expanded_url" : "http:\/\/www.runrev.com\/products\/Open-Source\/Community-Edition-Overview\/",
        "display_url" : "runrev.com\/products\/Open-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "321884066804822016",
    "text" : "LiveCode Open Source is here! Go get it http:\/\/t.co\/nAspz7LlJ4 Thanks for your support and patience - that was a late night.",
    "id" : 321884066804822016,
    "created_at" : "2013-04-10 07:15:16 +0000",
    "user" : {
      "name" : "LiveCode",
      "screen_name" : "LiveCode",
      "protected" : false,
      "id_str" : "69660541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552829787870220288\/UP7Pvo9Y_normal.jpeg",
      "id" : 69660541,
      "verified" : false
    }
  },
  "id" : 322020718076391424,
  "created_at" : "2013-04-10 16:18:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/PfQwbXvW9q",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/6e6dc766-18f0-a2c4-7ece-bf06f03cdf6d\/",
      "display_url" : "workflowy.com\/shared\/6e6dc76\u2026"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/gHFTS26rKH",
      "expanded_url" : "https:\/\/www.lystee.com\/user\/app515478182d31e30e2e00009c\/list\/Mobile-Design-Principles",
      "display_url" : "lystee.com\/user\/app515478\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "321726049031438336",
  "text" : "Draft checklist of touchscreen guidelines https:\/\/t.co\/PfQwbXvW9q to complement my earlier mobile design principles https:\/\/t.co\/gHFTS26rKH",
  "id" : 321726049031438336,
  "created_at" : "2013-04-09 20:47:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MindMup",
      "screen_name" : "MindMup",
      "indices" : [ 3, 11 ],
      "id_str" : "1057537267",
      "id" : 1057537267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/sn3vDudHnA",
      "expanded_url" : "http:\/\/blog.mindmup.com\/2013\/03\/3-months-35k-users-out-of-beta-and-into.html",
      "display_url" : "blog.mindmup.com\/2013\/03\/3-mont\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "321398388010676224",
  "text" : "RT @MindMup: MindMup is no longer in Beta. We've cleaned up performance and functionality. http:\/\/t.co\/sn3vDudHnA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/sn3vDudHnA",
        "expanded_url" : "http:\/\/blog.mindmup.com\/2013\/03\/3-months-35k-users-out-of-beta-and-into.html",
        "display_url" : "blog.mindmup.com\/2013\/03\/3-mont\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "316203450193043456",
    "text" : "MindMup is no longer in Beta. We've cleaned up performance and functionality. http:\/\/t.co\/sn3vDudHnA",
    "id" : 316203450193043456,
    "created_at" : "2013-03-25 15:02:31 +0000",
    "user" : {
      "name" : "MindMup",
      "screen_name" : "MindMup",
      "protected" : false,
      "id_str" : "1057537267",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3203604537\/bf805208be140da6d6affc6745924632_normal.png",
      "id" : 1057537267,
      "verified" : false
    }
  },
  "id" : 321398388010676224,
  "created_at" : "2013-04-08 23:05:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiz Beretta",
      "screen_name" : "tizberetta",
      "indices" : [ 0, 11 ],
      "id_str" : "32661922",
      "id" : 32661922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320277457422934016",
  "geo" : { },
  "id_str" : "320291273707749376",
  "in_reply_to_user_id" : 32661922,
  "text" : "@tizberetta Likewise Tiz!",
  "id" : 320291273707749376,
  "in_reply_to_status_id" : 320277457422934016,
  "created_at" : "2013-04-05 21:46:05 +0000",
  "in_reply_to_screen_name" : "tizberetta",
  "in_reply_to_user_id_str" : "32661922",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "indices" : [ 3, 11 ],
      "id_str" : "15022225",
      "id" : 15022225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/60OkpdDWUO",
      "expanded_url" : "http:\/\/ti.me\/101x5eB",
      "display_url" : "ti.me\/101x5eB"
    } ]
  },
  "geo" : { },
  "id_str" : "319491346652069888",
  "text" : "RT @NNgroup: Dynabook Pioneer Alan Kay: current tablets betraying educational vision http:\/\/t.co\/60OkpdDWUO TIME",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/60OkpdDWUO",
        "expanded_url" : "http:\/\/ti.me\/101x5eB",
        "display_url" : "ti.me\/101x5eB"
      } ]
    },
    "geo" : { },
    "id_str" : "319475740313780224",
    "text" : "Dynabook Pioneer Alan Kay: current tablets betraying educational vision http:\/\/t.co\/60OkpdDWUO TIME",
    "id" : 319475740313780224,
    "created_at" : "2013-04-03 15:45:26 +0000",
    "user" : {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "protected" : false,
      "id_str" : "15022225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467725885949227008\/JTT0mnp4_normal.png",
      "id" : 15022225,
      "verified" : false
    }
  },
  "id" : 319491346652069888,
  "created_at" : "2013-04-03 16:47:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319488037841154050",
  "geo" : { },
  "id_str" : "319489108097519616",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Congratulations Glen!",
  "id" : 319489108097519616,
  "in_reply_to_status_id" : 319488037841154050,
  "created_at" : "2013-04-03 16:38:33 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    }, {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "indices" : [ 100, 113 ],
      "id_str" : "35943",
      "id" : 35943
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aeasea",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/ug3VemASJA",
      "expanded_url" : "http:\/\/www.lukew.com\/ff\/entry.asp?1701",
      "display_url" : "lukew.com\/ff\/entry.asp?1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "319165832481603584",
  "text" : "RT @lukew: why you should care about mobile. it's disruptive:\nhttp:\/\/t.co\/ug3VemASJA\n\nmy notes from @karenmcgrane talk at #aeasea",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Karen McGrane",
        "screen_name" : "karenmcgrane",
        "indices" : [ 89, 102 ],
        "id_str" : "35943",
        "id" : 35943
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aeasea",
        "indices" : [ 111, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/ug3VemASJA",
        "expanded_url" : "http:\/\/www.lukew.com\/ff\/entry.asp?1701",
        "display_url" : "lukew.com\/ff\/entry.asp?1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "319132485495685122",
    "text" : "why you should care about mobile. it's disruptive:\nhttp:\/\/t.co\/ug3VemASJA\n\nmy notes from @karenmcgrane talk at #aeasea",
    "id" : 319132485495685122,
    "created_at" : "2013-04-02 17:01:28 +0000",
    "user" : {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "protected" : false,
      "id_str" : "13889622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477610446917103616\/_cjU3_ga_normal.png",
      "id" : 13889622,
      "verified" : false
    }
  },
  "id" : 319165832481603584,
  "created_at" : "2013-04-02 19:13:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leisa Reichelt",
      "screen_name" : "leisa",
      "indices" : [ 3, 9 ],
      "id_str" : "34663",
      "id" : 34663
    }, {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "indices" : [ 139, 140 ],
      "id_str" : "35943",
      "id" : 35943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319114974339411968",
  "text" : "RT @leisa: 'User-centered design is more than a methodology. It is a values system that has changed the very water we swim in.' brillian ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Karen McGrane",
        "screen_name" : "karenmcgrane",
        "indices" : [ 127, 140 ],
        "id_str" : "35943",
        "id" : 35943
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319069069028499456",
    "text" : "'User-centered design is more than a methodology. It is a values system that has changed the very water we swim in.' brilliant @karenmcgrane",
    "id" : 319069069028499456,
    "created_at" : "2013-04-02 12:49:28 +0000",
    "user" : {
      "name" : "Leisa Reichelt",
      "screen_name" : "leisa",
      "protected" : false,
      "id_str" : "34663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468392909817921537\/b7wBJttj_normal.jpeg",
      "id" : 34663,
      "verified" : false
    }
  },
  "id" : 319114974339411968,
  "created_at" : "2013-04-02 15:51:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]