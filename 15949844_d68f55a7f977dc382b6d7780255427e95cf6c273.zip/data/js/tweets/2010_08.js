Grailbird.data.tweets_2010_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.nambu.com\/\" rel=\"nofollow\"\u003ENambu\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gil Vinokoor",
      "screen_name" : "vinokoor",
      "indices" : [ 0, 9 ],
      "id_str" : "30701926",
      "id" : 30701926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22438609665",
  "geo" : { },
  "id_str" : "22479652186",
  "in_reply_to_user_id" : 30701926,
  "text" : "@vinokoor Thanks very much for the positive feedback and the retweet about my usability and UX resources!",
  "id" : 22479652186,
  "in_reply_to_status_id" : 22438609665,
  "created_at" : "2010-08-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "vinokoor",
  "in_reply_to_user_id_str" : "30701926",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nambu.com\/\" rel=\"nofollow\"\u003ENambu\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HotGloo",
      "screen_name" : "HotGloo",
      "indices" : [ 58, 66 ],
      "id_str" : "24670901",
      "id" : 24670901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22480506817",
  "text" : "Web-based collab prototyping tools I currently prefer are @HotGloo and MockFlow (has desktop app too!) \u2013 both very capable and well designed",
  "id" : 22480506817,
  "created_at" : "2010-08-30 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nambu.com\/\" rel=\"nofollow\"\u003ENambu\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iMeet Central",
      "screen_name" : "centraldesktop",
      "indices" : [ 125, 140 ],
      "id_str" : "3530524574",
      "id" : 3530524574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22308860015",
  "text" : "Day 1 of using PowerPoint with Central Desktop for Office for collab prototyping has gone well, commenting esp. handy! Kudos @centraldesktop",
  "id" : 22308860015,
  "created_at" : "2010-08-27 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nambu.com\/\" rel=\"nofollow\"\u003ENambu\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 0, 15 ],
      "id_str" : "1122631",
      "id" : 1122631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 74, 77 ]
    }, {
      "text" : "supernav",
      "indices" : [ 78, 87 ]
    }, {
      "text" : "meganav",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22123881675",
  "in_reply_to_user_id" : 1122631,
  "text" : "@MalloryOConnor This collection might be of interest http:\/\/bit.ly\/bGQGCE #UX #supernav #meganav",
  "id" : 22123881675,
  "created_at" : "2010-08-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "MalloryOConnor",
  "in_reply_to_user_id_str" : "1122631",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smashing Magazine",
      "screen_name" : "smashingmag",
      "indices" : [ 73, 85 ],
      "id_str" : "15736190",
      "id" : 15736190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21085507245",
  "text" : "Endeca User Interface Design Pattern Library - http:\/\/bit.ly\/c1W2Fa (via @smashingmag) Focus on e-commerce websites, nicely organized",
  "id" : 21085507245,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "concrete5",
      "screen_name" : "concrete5",
      "indices" : [ 32, 42 ],
      "id_str" : "14982767",
      "id" : 14982767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20926459511",
  "text" : "Kudos to everyone involved with @concrete5 \u2013 it\u2019s been a pleasure to create a custom website to accompany my usability + UX design seminars",
  "id" : 20926459511,
  "created_at" : "2010-08-11 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UXTweets",
      "screen_name" : "UXTweets",
      "indices" : [ 108, 117 ],
      "id_str" : "17768845",
      "id" : 17768845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20927189184",
  "text" : "5 Task-Centered Design Patterns Competitors are Employing to Out-gun Your Design: http:\/\/bit.ly\/9BlzJ1 (via @UXTweets)",
  "id" : 20927189184,
  "created_at" : "2010-08-11 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]