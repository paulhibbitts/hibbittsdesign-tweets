Grailbird.data.tweets_2011_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 116, 123 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ocshowcase2011",
      "indices" : [ 15, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142052003592417280",
  "text" : "Learnt lots at #ocshowcase2011 and enjoyed presenting about mobile-friendly course companions. Thanks everyone, esp @tanbob, Karen & Tracie!",
  "id" : 142052003592417280,
  "created_at" : "2011-12-01 01:26:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "selma zafar",
      "screen_name" : "selmaz",
      "indices" : [ 0, 7 ],
      "id_str" : "36598690",
      "id" : 36598690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140825950144311296",
  "geo" : { },
  "id_str" : "140839368792342529",
  "in_reply_to_user_id" : 36598690,
  "text" : "@selmaz Loving your Cool Dutch Bike of the Day pics!",
  "id" : 140839368792342529,
  "in_reply_to_status_id" : 140825950144311296,
  "created_at" : "2011-11-27 17:08:16 +0000",
  "in_reply_to_screen_name" : "selmaz",
  "in_reply_to_user_id_str" : "36598690",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "farhan putrananda",
      "screen_name" : "FarhanP",
      "indices" : [ 0, 8 ],
      "id_str" : "2705034932",
      "id" : 2705034932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138761731202748416",
  "geo" : { },
  "id_str" : "139040342740705281",
  "in_reply_to_user_id" : 18129659,
  "text" : "@Farhanp Thanks very much. Your iOS app is a really helpful resource for SFU students!",
  "id" : 139040342740705281,
  "in_reply_to_status_id" : 138761731202748416,
  "created_at" : "2011-11-22 17:59:35 +0000",
  "in_reply_to_screen_name" : "Farhanpatel",
  "in_reply_to_user_id_str" : "18129659",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/5iVPIshG",
      "expanded_url" : "http:\/\/www.netmagazine.com\/opinions\/new-ux-skills",
      "display_url" : "netmagazine.com\/opinions\/new-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "137611835363958784",
  "text" : "The new UX skills http:\/\/t.co\/5iVPIshG &lt;- Great to see the importance of education, collaboration, and facilitation skills being highlighted",
  "id" : 137611835363958784,
  "created_at" : "2011-11-18 19:23:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/i6UCrXBo",
      "expanded_url" : "http:\/\/www.paulhibbitts.com\/mobile-learning-sfu-course-website-case-study.html",
      "display_url" : "paulhibbitts.com\/mobile-learnin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "134372694446714880",
  "text" : "My newest case study: Mobile Learning \u2013 SFU Course Website http:\/\/t.co\/i6UCrXBo",
  "id" : 134372694446714880,
  "created_at" : "2011-11-09 20:52:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]