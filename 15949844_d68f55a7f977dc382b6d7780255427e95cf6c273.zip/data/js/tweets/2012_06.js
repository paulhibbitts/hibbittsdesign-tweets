Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218752058071842818",
  "text" : "Responsive web design should be viewed as the floor and not the ceiling. Device specific designs can also be appropriate wrt device stats.",
  "id" : 218752058071842818,
  "created_at" : "2012-06-29 17:05:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Udell",
      "screen_name" : "visualrinse",
      "indices" : [ 0, 12 ],
      "id_str" : "809010",
      "id" : 809010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218003908004548609",
  "geo" : { },
  "id_str" : "218006333016903682",
  "in_reply_to_user_id" : 809010,
  "text" : "@visualrinse Thanks very much for the info. From a user experience design perspective, mobile learning is a fascinating field!",
  "id" : 218006333016903682,
  "in_reply_to_status_id" : 218003908004548609,
  "created_at" : "2012-06-27 15:42:14 +0000",
  "in_reply_to_screen_name" : "visualrinse",
  "in_reply_to_user_id_str" : "809010",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Udell",
      "screen_name" : "visualrinse",
      "indices" : [ 0, 12 ],
      "id_str" : "809010",
      "id" : 809010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217997933654704128",
  "geo" : { },
  "id_str" : "218002640582356993",
  "in_reply_to_user_id" : 809010,
  "text" : "@visualrinse Really looking forward to reading your book! Would you know when the Kindle edition is expected?",
  "id" : 218002640582356993,
  "in_reply_to_status_id" : 217997933654704128,
  "created_at" : "2012-06-27 15:27:34 +0000",
  "in_reply_to_screen_name" : "visualrinse",
  "in_reply_to_user_id_str" : "809010",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Odell",
      "screen_name" : "ugaodawg",
      "indices" : [ 3, 12 ],
      "id_str" : "33091641",
      "id" : 33091641
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iste12",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217982890808573952",
  "text" : "RT @ugaodawg: \"Technology is not technology if it happened before you were born.\" Students do not see current tech as new. #iste12",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iste12",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217077057627226112",
    "text" : "\"Technology is not technology if it happened before you were born.\" Students do not see current tech as new. #iste12",
    "id" : 217077057627226112,
    "created_at" : "2012-06-25 02:09:38 +0000",
    "user" : {
      "name" : "Greg Odell",
      "screen_name" : "ugaodawg",
      "protected" : false,
      "id_str" : "33091641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3007652785\/e7c334c1b3a02711b41eb19e32b2d1b4_normal.png",
      "id" : 33091641,
      "verified" : false
    }
  },
  "id" : 217982890808573952,
  "created_at" : "2012-06-27 14:09:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Usabilla",
      "screen_name" : "usabilla",
      "indices" : [ 3, 12 ],
      "id_str" : "16601140",
      "id" : 16601140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/9IATC8O9",
      "expanded_url" : "http:\/\/usabil.la\/n4JVwy",
      "display_url" : "usabil.la\/n4JVwy"
    } ]
  },
  "geo" : { },
  "id_str" : "217980134693670912",
  "text" : "RT @usabilla: Finding Usability definitions just got easier! Need a definition? We've got you covered! http:\/\/t.co\/9IATC8O9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/9IATC8O9",
        "expanded_url" : "http:\/\/usabil.la\/n4JVwy",
        "display_url" : "usabil.la\/n4JVwy"
      } ]
    },
    "geo" : { },
    "id_str" : "217978119099916289",
    "text" : "Finding Usability definitions just got easier! Need a definition? We've got you covered! http:\/\/t.co\/9IATC8O9",
    "id" : 217978119099916289,
    "created_at" : "2012-06-27 13:50:08 +0000",
    "user" : {
      "name" : "Usabilla",
      "screen_name" : "usabilla",
      "protected" : false,
      "id_str" : "16601140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555698253535010816\/Ln3de7fV_normal.png",
      "id" : 16601140,
      "verified" : false
    }
  },
  "id" : 217980134693670912,
  "created_at" : "2012-06-27 13:58:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Pontefract",
      "screen_name" : "dpontefract",
      "indices" : [ 0, 12 ],
      "id_str" : "18343116",
      "id" : 18343116
    }, {
      "name" : "A Small Orange",
      "screen_name" : "asmallorange",
      "indices" : [ 59, 72 ],
      "id_str" : "14429384",
      "id" : 14429384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216254796494143488",
  "geo" : { },
  "id_str" : "216291730008440833",
  "in_reply_to_user_id" : 18343116,
  "text" : "@dpontefract Twitter handle for A Small Orange is actually @asmallorange",
  "id" : 216291730008440833,
  "in_reply_to_status_id" : 216254796494143488,
  "created_at" : "2012-06-22 22:09:01 +0000",
  "in_reply_to_screen_name" : "dpontefract",
  "in_reply_to_user_id_str" : "18343116",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Pontefract",
      "screen_name" : "dpontefract",
      "indices" : [ 0, 12 ],
      "id_str" : "18343116",
      "id" : 18343116
    }, {
      "name" : "H.AsO",
      "screen_name" : "AsO",
      "indices" : [ 95, 99 ],
      "id_str" : "3618111",
      "id" : 3618111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216254796494143488",
  "geo" : { },
  "id_str" : "216291138447998977",
  "in_reply_to_user_id" : 18343116,
  "text" : "@dpontefract If it is on WordPress I can be of help. My preferred hosting company right now is @aso - great support and responsive servers.",
  "id" : 216291138447998977,
  "in_reply_to_status_id" : 216254796494143488,
  "created_at" : "2012-06-22 22:06:40 +0000",
  "in_reply_to_screen_name" : "dpontefract",
  "in_reply_to_user_id_str" : "18343116",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darren Gibbons",
      "screen_name" : "dgibbons",
      "indices" : [ 3, 12 ],
      "id_str" : "1305061",
      "id" : 1305061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/zWqTA0mj",
      "expanded_url" : "http:\/\/www.zurb.com\/article\/1012\/new-foundation-30-playground-release-off-",
      "display_url" : "zurb.com\/article\/1012\/n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216287908661964800",
  "text" : "RT @dgibbons: Love these new off-canvas responsive layouts in Foundation 3: http:\/\/t.co\/zWqTA0mj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/zWqTA0mj",
        "expanded_url" : "http:\/\/www.zurb.com\/article\/1012\/new-foundation-30-playground-release-off-",
        "display_url" : "zurb.com\/article\/1012\/n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "216281491477495808",
    "text" : "Love these new off-canvas responsive layouts in Foundation 3: http:\/\/t.co\/zWqTA0mj",
    "id" : 216281491477495808,
    "created_at" : "2012-06-22 21:28:20 +0000",
    "user" : {
      "name" : "Darren Gibbons",
      "screen_name" : "dgibbons",
      "protected" : false,
      "id_str" : "1305061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733337158241550337\/KX-Lq7GC_normal.jpg",
      "id" : 1305061,
      "verified" : false
    }
  },
  "id" : 216287908661964800,
  "created_at" : "2012-06-22 21:53:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ranvir Bahl",
      "screen_name" : "bahl",
      "indices" : [ 0, 5 ],
      "id_str" : "16232686",
      "id" : 16232686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/riaws9Dh",
      "expanded_url" : "http:\/\/www.paulhibbitts.com\/mobilelearningux\/index.html",
      "display_url" : "paulhibbitts.com\/mobilelearning\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "216272253640376320",
  "geo" : { },
  "id_str" : "216278540121939970",
  "in_reply_to_user_id" : 16232686,
  "text" : "@bahl My mobile learning presentations resource page, including slides, is at http:\/\/t.co\/riaws9Dh Suggestions for improvement most welcome!",
  "id" : 216278540121939970,
  "in_reply_to_status_id" : 216272253640376320,
  "created_at" : "2012-06-22 21:16:36 +0000",
  "in_reply_to_screen_name" : "bahl",
  "in_reply_to_user_id_str" : "16232686",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VCC's CID News feed",
      "screen_name" : "CIDvcc",
      "indices" : [ 0, 7 ],
      "id_str" : "50566264",
      "id" : 50566264
    }, {
      "name" : "it4bc",
      "screen_name" : "it4bc",
      "indices" : [ 8, 14 ],
      "id_str" : "587973973",
      "id" : 587973973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 72, 77 ]
    }, {
      "text" : "it4bc",
      "indices" : [ 82, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215506432248905731",
  "geo" : { },
  "id_str" : "215571023519682560",
  "in_reply_to_user_id" : 50566264,
  "text" : "@CIDvcc @it4bc Thanks very much! It was a pleasure to be a part of both #etug and #it4bc this year.",
  "id" : 215571023519682560,
  "in_reply_to_status_id" : 215506432248905731,
  "created_at" : "2012-06-20 22:25:11 +0000",
  "in_reply_to_screen_name" : "CIDvcc",
  "in_reply_to_user_id_str" : "50566264",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 1, 13 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/qZqSwYwV",
      "expanded_url" : "http:\/\/goo.gl\/p3pJJ",
      "display_url" : "goo.gl\/p3pJJ"
    } ]
  },
  "geo" : { },
  "id_str" : "213766732567941121",
  "text" : "\u201C@openroadies: Attn Visual Designers w\/ a passion for the web: we're hiring &amp; want to talk to you - http:\/\/t.co\/qZqSwYwV &lt;- Great people!",
  "id" : 213766732567941121,
  "created_at" : "2012-06-15 22:55:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "it4bc",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/e0U6P2HV",
      "expanded_url" : "http:\/\/mobilelearningux.com",
      "display_url" : "mobilelearningux.com"
    } ]
  },
  "geo" : { },
  "id_str" : "213428889505112066",
  "text" : "Thanks to everyone who attended my mobile learning UX talk - greatly enjoyed the questions and discussion! #it4bc http:\/\/t.co\/e0U6P2HV",
  "id" : 213428889505112066,
  "created_at" : "2012-06-15 00:33:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "it4bc",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213306362011197440",
  "text" : "Great student panel! #it4bc",
  "id" : 213306362011197440,
  "created_at" : "2012-06-14 16:26:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "it4bc",
      "screen_name" : "it4bc",
      "indices" : [ 3, 9 ],
      "id_str" : "587973973",
      "id" : 587973973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "it4bc",
      "indices" : [ 124, 130 ]
    }, {
      "text" : "gauntletthrown",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213305108946108416",
  "text" : "RT @it4bc: I am loving the honest insights from our student panel.  They want usability and a way to simplify their world.  #it4bc  #gau ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "it4bc",
        "indices" : [ 113, 119 ]
      }, {
        "text" : "gauntletthrown",
        "indices" : [ 121, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213304593973645312",
    "text" : "I am loving the honest insights from our student panel.  They want usability and a way to simplify their world.  #it4bc  #gauntletthrown",
    "id" : 213304593973645312,
    "created_at" : "2012-06-14 16:19:12 +0000",
    "user" : {
      "name" : "it4bc",
      "screen_name" : "it4bc",
      "protected" : false,
      "id_str" : "587973973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2242597126\/it4bc_normal.png",
      "id" : 587973973,
      "verified" : false
    }
  },
  "id" : 213305108946108416,
  "created_at" : "2012-06-14 16:21:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "it4bc",
      "indices" : [ 59, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213299332634513408",
  "text" : "Engagement is a critical element of the student experience #it4bc",
  "id" : 213299332634513408,
  "created_at" : "2012-06-14 15:58:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "it4bc",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213294952459935744",
  "text" : "Great to be at #it4bc today. Looking forward to discussing mobile learning UX at 2:45pm!",
  "id" : 213294952459935744,
  "created_at" : "2012-06-14 15:40:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "it4bc",
      "screen_name" : "it4bc",
      "indices" : [ 67, 73 ],
      "id_str" : "587973973",
      "id" : 587973973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/4HH0PxGw",
      "expanded_url" : "http:\/\/www.mobilelearningux.com",
      "display_url" : "mobilelearningux.com"
    } ]
  },
  "geo" : { },
  "id_str" : "212658710659596288",
  "text" : "Presenting about mobile learning UX and my secret weapon WordPress @it4bc this Thursday - will be posting slides on http:\/\/t.co\/4HH0PxGw",
  "id" : 212658710659596288,
  "created_at" : "2012-06-12 21:32:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "foundationzurb",
      "screen_name" : "foundationzurb",
      "indices" : [ 1, 16 ],
      "id_str" : "2394933703",
      "id" : 2394933703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/vAZEBJyv",
      "expanded_url" : "http:\/\/www.zurb.com\/article\/1000\/foundation-30-typography-and-modular-scal",
      "display_url" : "zurb.com\/article\/1000\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "212227217709740033",
  "text" : "\u201C@foundationzurb: More info on what's coming to Foundation 3.0: http:\/\/t.co\/vAZEBJyv\u201D&lt;- My favourite responsive web design framework",
  "id" : 212227217709740033,
  "created_at" : "2012-06-11 16:58:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211213287793233921",
  "text" : "Thanks very much #etug attendees, fellow presenters, organizers and VCC - I really enjoyed the conference and conversations!",
  "id" : 211213287793233921,
  "created_at" : "2012-06-08 21:49:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Currie",
      "screen_name" : "Currie",
      "indices" : [ 0, 7 ],
      "id_str" : "1282151",
      "id" : 1282151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211146589807448065",
  "geo" : { },
  "id_str" : "211209945692110850",
  "in_reply_to_user_id" : 1282151,
  "text" : "@Currie Thanks for attending my mobile learning UX session today and tweeting the accompanying resource microsite!",
  "id" : 211209945692110850,
  "in_reply_to_status_id" : 211146589807448065,
  "created_at" : "2012-06-08 21:35:49 +0000",
  "in_reply_to_screen_name" : "Currie",
  "in_reply_to_user_id_str" : "1282151",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/ftZ32SVX",
      "expanded_url" : "http:\/\/underthebedstudios.com\/blog\/experience-first\/",
      "display_url" : "underthebedstudios.com\/blog\/experienc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "211132778929070080",
  "geo" : { },
  "id_str" : "211204415527456768",
  "in_reply_to_user_id" : 602149473,
  "text" : "@ArwenWallington Thanks very much for joining us and your kind words! HT to Kevin Powell for \"Experience First\" http:\/\/t.co\/ftZ32SVX",
  "id" : 211204415527456768,
  "in_reply_to_status_id" : 211132778929070080,
  "created_at" : "2012-06-08 21:13:51 +0000",
  "in_reply_to_screen_name" : "ArwenSchewe",
  "in_reply_to_user_id_str" : "602149473",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 24, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210895033698750464",
  "text" : "Energized by my time at #etug today. Making some changes to my mobile learning UX presentation for tomorrow - looking forward to sharing it!",
  "id" : 210895033698750464,
  "created_at" : "2012-06-08 00:44:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liam R",
      "screen_name" : "liamr",
      "indices" : [ 0, 6 ],
      "id_str" : "5414132",
      "id" : 5414132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210492074091479040",
  "in_reply_to_user_id" : 5414132,
  "text" : "@liamr Thanks so much for your Zurb Foundation Textmate Bundle! Could you please tell me how to access the zfpage snippet?",
  "id" : 210492074091479040,
  "created_at" : "2012-06-06 22:03:15 +0000",
  "in_reply_to_screen_name" : "liamr",
  "in_reply_to_user_id_str" : "5414132",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlearning",
      "indices" : [ 126, 136 ]
    }, {
      "text" : "ux",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/cOMiZfFA",
      "expanded_url" : "http:\/\/www.gliffy.com\/publish\/3363991\/",
      "display_url" : "gliffy.com\/publish\/336399\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210449463444123649",
  "text" : "My 2nd attempt illustrating the role of UX w. mobile learning http:\/\/t.co\/cOMiZfFA Performance instead of learning objectives #mlearning #ux",
  "id" : 210449463444123649,
  "created_at" : "2012-06-06 19:13:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209688423596965891",
  "text" : "Looking forward to #ETUG this week to discuss mobile learning UX design and leveraging WordPress as a mobile learning platform.",
  "id" : 209688423596965891,
  "created_at" : "2012-06-04 16:49:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]