Grailbird.data.tweets_2014_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537756131146215424",
  "geo" : { },
  "id_str" : "537763500836151296",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Hope the slides are of use - if any more details of my experiences with open development is of help please let me know.",
  "id" : 537763500836151296,
  "in_reply_to_status_id" : 537756131146215424,
  "created_at" : "2014-11-27 00:23:04 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christy Clark",
      "screen_name" : "christyclarkbc",
      "indices" : [ 5, 20 ],
      "id_str" : "19240337",
      "id" : 19240337
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BurnabyMountain",
      "indices" : [ 94, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/MxcLpHDDHu",
      "expanded_url" : "http:\/\/BCReview.ca",
      "display_url" : "BCReview.ca"
    } ]
  },
  "geo" : { },
  "id_str" : "537672438666903552",
  "text" : "Tell @ChristyClarkBC: it\u2019s time for a fair, independent review of the Kinder Morgan proposal. #BurnabyMountain http:\/\/t.co\/MxcLpHDDHu",
  "id" : 537672438666903552,
  "created_at" : "2014-11-26 18:21:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/EYRbIGGdDt",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/138OmCxlbjLx_aeLbWbIicW7tPv5Zr2bdlhYJmoU5pEk\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/138\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537315597218889730",
  "text" : "Draft title of my next workshop is \"Designing Multi-device Learning Ecologies\". Read more details and comment at https:\/\/t.co\/EYRbIGGdDt",
  "id" : 537315597218889730,
  "created_at" : "2014-11-25 18:43:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535898125597433856",
  "geo" : { },
  "id_str" : "535902770906136576",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro That\u2019s awesome, I am really looking forward to it!",
  "id" : 535902770906136576,
  "in_reply_to_status_id" : 535898125597433856,
  "created_at" : "2014-11-21 21:09:11 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "indices" : [ 3, 14 ],
      "id_str" : "27633854",
      "id" : 27633854
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 45, 52 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened14",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/oqmaZfUsOW",
      "expanded_url" : "http:\/\/www.slideshare.net\/btopro\/elmsln-opened-14",
      "display_url" : "slideshare.net\/btopro\/elmsln-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535876321872584704",
  "text" : "RT @JustStormy: Check him out at 2:30 pm! RT @btopro: got my slides up in case anyone wants to cheat on the test\u2026 #opened14 http:\/\/t.co\/oqm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bryan Ollendyke",
        "screen_name" : "btopro",
        "indices" : [ 29, 36 ],
        "id_str" : "16847370",
        "id" : 16847370
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened14",
        "indices" : [ 98, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/oqmaZfUsOW",
        "expanded_url" : "http:\/\/www.slideshare.net\/btopro\/elmsln-opened-14",
        "display_url" : "slideshare.net\/btopro\/elmsln-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "535867792244105216",
    "text" : "Check him out at 2:30 pm! RT @btopro: got my slides up in case anyone wants to cheat on the test\u2026 #opened14 http:\/\/t.co\/oqmaZfUsOW",
    "id" : 535867792244105216,
    "created_at" : "2014-11-21 18:50:12 +0000",
    "user" : {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "protected" : false,
      "id_str" : "27633854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766452852248109056\/nnq9NFSH_normal.jpg",
      "id" : 27633854,
      "verified" : false
    }
  },
  "id" : 535876321872584704,
  "created_at" : "2014-11-21 19:24:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Van Alstyne",
      "screen_name" : "audreyvan5",
      "indices" : [ 3, 14 ],
      "id_str" : "2592455540",
      "id" : 2592455540
    }, {
      "name" : "Maria H. Andersen",
      "screen_name" : "busynessgirl",
      "indices" : [ 124, 137 ],
      "id_str" : "18555344",
      "id" : 18555344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IL4K12",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "vsblearns",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535573271152824320",
  "text" : "RT @audreyvan5: \"Learning in he future will be a team activity where technology is ON the team!\" Tech must be chosen wisely @busynessgirl #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maria H. Andersen",
        "screen_name" : "busynessgirl",
        "indices" : [ 108, 121 ],
        "id_str" : "18555344",
        "id" : 18555344
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IL4K12",
        "indices" : [ 122, 129 ]
      }, {
        "text" : "vsblearns",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535481603108007936",
    "text" : "\"Learning in he future will be a team activity where technology is ON the team!\" Tech must be chosen wisely @busynessgirl #IL4K12 #vsblearns",
    "id" : 535481603108007936,
    "created_at" : "2014-11-20 17:15:37 +0000",
    "user" : {
      "name" : "Audrey Van Alstyne",
      "screen_name" : "audreyvan5",
      "protected" : false,
      "id_str" : "2592455540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482752776338808833\/nu1rersZ_normal.jpeg",
      "id" : 2592455540,
      "verified" : false
    }
  },
  "id" : 535573271152824320,
  "created_at" : "2014-11-20 23:19:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "indices" : [ 3, 10 ],
      "id_str" : "944913038",
      "id" : 944913038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vancouver",
      "indices" : [ 134, 140 ]
    }, {
      "text" : "UX",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/WU3MkunHl1",
      "expanded_url" : "http:\/\/www.vancouveruxawards.com",
      "display_url" : "vancouveruxawards.com"
    } ]
  },
  "geo" : { },
  "id_str" : "535528580894052352",
  "text" : "RT @Van_UE: Congratulations to all our finalists! Tickets are still available for the Nov. 26 gala. Info here: http:\/\/t.co\/WU3MkunHl1 #Vanc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Vancouver",
        "indices" : [ 122, 132 ]
      }, {
        "text" : "UX",
        "indices" : [ 133, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/WU3MkunHl1",
        "expanded_url" : "http:\/\/www.vancouveruxawards.com",
        "display_url" : "vancouveruxawards.com"
      } ]
    },
    "geo" : { },
    "id_str" : "535521405904109568",
    "text" : "Congratulations to all our finalists! Tickets are still available for the Nov. 26 gala. Info here: http:\/\/t.co\/WU3MkunHl1 #Vancouver #UX",
    "id" : 535521405904109568,
    "created_at" : "2014-11-20 19:53:47 +0000",
    "user" : {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "protected" : false,
      "id_str" : "944913038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2842592785\/c138e36411049b83817c208ab9149c60_normal.png",
      "id" : 944913038,
      "verified" : false
    }
  },
  "id" : 535528580894052352,
  "created_at" : "2014-11-20 20:22:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535263945217818624",
  "geo" : { },
  "id_str" : "535505856847028224",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Thanks very much Bryan, I look forward to hearing it!",
  "id" : 535505856847028224,
  "in_reply_to_status_id" : 535263945217818624,
  "created_at" : "2014-11-20 18:52:00 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WordPress",
      "indices" : [ 65, 75 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 80, 90 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535200410471247872",
  "text" : "Does anyone know of example (publicly available) integrations of #WordPress and #CanvasLMS or any other open source CMS with #CanvasLMS?",
  "id" : 535200410471247872,
  "created_at" : "2014-11-19 22:38:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elmsln",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534919639198089217",
  "geo" : { },
  "id_str" : "535199730721386496",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro I would love to see a recording of this session if one is made. The approach of #elmsln really resonates with me.",
  "id" : 535199730721386496,
  "in_reply_to_status_id" : 534919639198089217,
  "created_at" : "2014-11-19 22:35:33 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened14",
      "indices" : [ 12, 21 ]
    }, {
      "text" : "elmsln",
      "indices" : [ 55, 62 ]
    }, {
      "text" : "edtech",
      "indices" : [ 119, 126 ]
    }, {
      "text" : "education",
      "indices" : [ 127, 137 ]
    }, {
      "text" : "edu",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/dAVvH1Npyb",
      "expanded_url" : "http:\/\/sched.co\/1mhxeXz",
      "display_url" : "sched.co\/1mhxeXz"
    } ]
  },
  "geo" : { },
  "id_str" : "535198968310153219",
  "text" : "RT @btopro: #opened14 starts tomorrow, excited to show #elmsln Friday and put forward its ideas http:\/\/t.co\/dAVvH1Npyb #edtech #education #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened14",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "elmsln",
        "indices" : [ 43, 50 ]
      }, {
        "text" : "edtech",
        "indices" : [ 107, 114 ]
      }, {
        "text" : "education",
        "indices" : [ 115, 125 ]
      }, {
        "text" : "edu",
        "indices" : [ 126, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/dAVvH1Npyb",
        "expanded_url" : "http:\/\/sched.co\/1mhxeXz",
        "display_url" : "sched.co\/1mhxeXz"
      } ]
    },
    "geo" : { },
    "id_str" : "534919639198089217",
    "text" : "#opened14 starts tomorrow, excited to show #elmsln Friday and put forward its ideas http:\/\/t.co\/dAVvH1Npyb #edtech #education #edu",
    "id" : 534919639198089217,
    "created_at" : "2014-11-19 04:02:34 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 535198968310153219,
  "created_at" : "2014-11-19 22:32:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SitePoint",
      "screen_name" : "sitepointdotcom",
      "indices" : [ 3, 19 ],
      "id_str" : "15743570",
      "id" : 15743570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/qsscEqDhvP",
      "expanded_url" : "http:\/\/buff.ly\/11lXPuV",
      "display_url" : "buff.ly\/11lXPuV"
    } ]
  },
  "geo" : { },
  "id_str" : "534900183855665152",
  "text" : "RT @sitepointdotcom: OctoberCMS: scalable, extensible, and allows for the effortless creation of administrative back-end interfaces: http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/qsscEqDhvP",
        "expanded_url" : "http:\/\/buff.ly\/11lXPuV",
        "display_url" : "buff.ly\/11lXPuV"
      } ]
    },
    "geo" : { },
    "id_str" : "534712144320024579",
    "text" : "OctoberCMS: scalable, extensible, and allows for the effortless creation of administrative back-end interfaces: http:\/\/t.co\/qsscEqDhvP",
    "id" : 534712144320024579,
    "created_at" : "2014-11-18 14:18:04 +0000",
    "user" : {
      "name" : "SitePoint",
      "screen_name" : "sitepointdotcom",
      "protected" : false,
      "id_str" : "15743570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709990641455988736\/Zn1XQhbJ_normal.jpg",
      "id" : 15743570,
      "verified" : true
    }
  },
  "id" : 534900183855665152,
  "created_at" : "2014-11-19 02:45:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 23, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/3snbXbWqYy",
      "expanded_url" : "http:\/\/1drv.ms\/1ESErDg",
      "display_url" : "1drv.ms\/1ESErDg"
    } ]
  },
  "geo" : { },
  "id_str" : "534462659156930561",
  "text" : "Multi-device (non-RWD) #CanvasLMS learning ecology: formal\/informal\/social learning, performance support &amp; coaching http:\/\/t.co\/3snbXbWqYy",
  "id" : 534462659156930561,
  "created_at" : "2014-11-17 21:46:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Fraser Univ.",
      "screen_name" : "SFU",
      "indices" : [ 106, 110 ],
      "id_str" : "8071702",
      "id" : 8071702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534398428067815425",
  "text" : "Looking forward to sharing my experiences creating a multi-device friendly #CanvasLMS learning ecology at @SFU Canvas Now! tomorrow.",
  "id" : 534398428067815425,
  "created_at" : "2014-11-17 17:31:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "City of Vancouver",
      "screen_name" : "CityofVancouver",
      "indices" : [ 3, 19 ],
      "id_str" : "55323056",
      "id" : 55323056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xfstW9rnPa",
      "expanded_url" : "http:\/\/ow.ly\/EkGG2",
      "display_url" : "ow.ly\/EkGG2"
    } ]
  },
  "geo" : { },
  "id_str" : "533757615109447680",
  "text" : "RT @CityofVancouver: You can vote at close to 120 voting locations! If there's a line use this link to find other nearby voting locations h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/xfstW9rnPa",
        "expanded_url" : "http:\/\/ow.ly\/EkGG2",
        "display_url" : "ow.ly\/EkGG2"
      } ]
    },
    "geo" : { },
    "id_str" : "533739232373006337",
    "text" : "You can vote at close to 120 voting locations! If there's a line use this link to find other nearby voting locations http:\/\/t.co\/xfstW9rnPa",
    "id" : 533739232373006337,
    "created_at" : "2014-11-15 21:52:04 +0000",
    "user" : {
      "name" : "City of Vancouver",
      "screen_name" : "CityofVancouver",
      "protected" : false,
      "id_str" : "55323056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610511664748695552\/g2OBM_H3_normal.jpg",
      "id" : 55323056,
      "verified" : true
    }
  },
  "id" : 533757615109447680,
  "created_at" : "2014-11-15 23:05:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533028909227335680",
  "text" : "I am definitely a live the story and then tell the story kind of person when it comes to sharing design processes and approaches.",
  "id" : 533028909227335680,
  "created_at" : "2014-11-13 22:49:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532662249593503744",
  "text" : "Working on a model describing my learning + technology development process\u2026 hope it will be useful for others.",
  "id" : 532662249593503744,
  "created_at" : "2014-11-12 22:32:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ESA Rosetta Mission",
      "screen_name" : "ESA_Rosetta",
      "indices" : [ 3, 15 ],
      "id_str" : "253536357",
      "id" : 253536357
    }, {
      "name" : "Philae Lander",
      "screen_name" : "Philae2014",
      "indices" : [ 31, 42 ],
      "id_str" : "208442526",
      "id" : 208442526
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ESA_Rosetta\/status\/532565327721545728\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ZMBeB8ng3h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2QNV7WCcAAVpCU.jpg",
      "id_str" : "532565326295101440",
      "id" : 532565326295101440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2QNV7WCcAAVpCU.jpg",
      "sizes" : [ {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZMBeB8ng3h"
    } ],
    "hashtags" : [ {
      "text" : "CometLanding",
      "indices" : [ 44, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532566044083486721",
  "text" : "RT @ESA_Rosetta: TOUCHDOWN for @Philae2014! #CometLanding http:\/\/t.co\/ZMBeB8ng3h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Philae Lander",
        "screen_name" : "Philae2014",
        "indices" : [ 14, 25 ],
        "id_str" : "208442526",
        "id" : 208442526
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ESA_Rosetta\/status\/532565327721545728\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/ZMBeB8ng3h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2QNV7WCcAAVpCU.jpg",
        "id_str" : "532565326295101440",
        "id" : 532565326295101440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2QNV7WCcAAVpCU.jpg",
        "sizes" : [ {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZMBeB8ng3h"
      } ],
      "hashtags" : [ {
        "text" : "CometLanding",
        "indices" : [ 27, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532565327721545728",
    "text" : "TOUCHDOWN for @Philae2014! #CometLanding http:\/\/t.co\/ZMBeB8ng3h",
    "id" : 532565327721545728,
    "created_at" : "2014-11-12 16:07:23 +0000",
    "user" : {
      "name" : "ESA Rosetta Mission",
      "screen_name" : "ESA_Rosetta",
      "protected" : false,
      "id_str" : "253536357",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000850926297\/a6286c08618d966740207142a62eda84_normal.png",
      "id" : 253536357,
      "verified" : true
    }
  },
  "id" : 532566044083486721,
  "created_at" : "2014-11-12 16:10:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 3, 19 ],
      "id_str" : "17349291",
      "id" : 17349291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vancouver",
      "indices" : [ 58, 68 ]
    }, {
      "text" : "UX",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "YVR",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ioouv3LD03",
      "expanded_url" : "http:\/\/www.vancouveruxawards.com",
      "display_url" : "vancouveruxawards.com"
    } ]
  },
  "geo" : { },
  "id_str" : "530458681901871107",
  "text" : "RT @HabaneroConsult: Tomorrow's the last day to enter the #Vancouver User Experience Awards. Get those entries in soon! http:\/\/t.co\/ioouv3L\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Vancouver",
        "indices" : [ 37, 47 ]
      }, {
        "text" : "UX",
        "indices" : [ 122, 125 ]
      }, {
        "text" : "YVR",
        "indices" : [ 126, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/ioouv3LD03",
        "expanded_url" : "http:\/\/www.vancouveruxawards.com",
        "display_url" : "vancouveruxawards.com"
      } ]
    },
    "geo" : { },
    "id_str" : "530453132372082688",
    "text" : "Tomorrow's the last day to enter the #Vancouver User Experience Awards. Get those entries in soon! http:\/\/t.co\/ioouv3LD03 #UX #YVR",
    "id" : 530453132372082688,
    "created_at" : "2014-11-06 20:14:16 +0000",
    "user" : {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "protected" : false,
      "id_str" : "17349291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768212660244537344\/z_mWqOrE_normal.jpg",
      "id" : 17349291,
      "verified" : false
    }
  },
  "id" : 530458681901871107,
  "created_at" : "2014-11-06 20:36:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaleem",
      "screen_name" : "kaleemlive",
      "indices" : [ 3, 14 ],
      "id_str" : "92248134",
      "id" : 92248134
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UXfutures",
      "indices" : [ 139, 144 ]
    }, {
      "text" : "ux50",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530113157793316865",
  "text" : "RT @kaleemlive: Idea of hiring a UX team has gone away in 2048. \n\nBusinesses need deep understanding &amp; need to keep knowledge inside.\n\n#UXf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UXfutures",
        "indices" : [ 123, 133 ]
      }, {
        "text" : "ux50",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "530109146855923712",
    "text" : "Idea of hiring a UX team has gone away in 2048. \n\nBusinesses need deep understanding &amp; need to keep knowledge inside.\n\n#UXfutures #ux50",
    "id" : 530109146855923712,
    "created_at" : "2014-11-05 21:27:24 +0000",
    "user" : {
      "name" : "Kaleem",
      "screen_name" : "kaleemlive",
      "protected" : false,
      "id_str" : "92248134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586587960339902464\/mKXErKez_normal.jpg",
      "id" : 92248134,
      "verified" : false
    }
  },
  "id" : 530113157793316865,
  "created_at" : "2014-11-05 21:43:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie Jensen-Inman",
      "screen_name" : "jenseninman",
      "indices" : [ 3, 15 ],
      "id_str" : "14088072",
      "id" : 14088072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/K3QYBmq9CB",
      "expanded_url" : "http:\/\/uxmag.com\/articles\/why-investment-in-design-is-the-only-way-to-win-in-education",
      "display_url" : "uxmag.com\/articles\/why-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530093390281867265",
  "text" : "RT @jenseninman: Why Investment in Design is the Only Way to \u201CWin\u201D in Education - http:\/\/t.co\/K3QYBmq9CB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/K3QYBmq9CB",
        "expanded_url" : "http:\/\/uxmag.com\/articles\/why-investment-in-design-is-the-only-way-to-win-in-education",
        "display_url" : "uxmag.com\/articles\/why-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "530091684923596800",
    "text" : "Why Investment in Design is the Only Way to \u201CWin\u201D in Education - http:\/\/t.co\/K3QYBmq9CB",
    "id" : 530091684923596800,
    "created_at" : "2014-11-05 20:18:00 +0000",
    "user" : {
      "name" : "Leslie Jensen-Inman",
      "screen_name" : "jenseninman",
      "protected" : false,
      "id_str" : "14088072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477447116139151360\/Dplu6-hq_normal.jpeg",
      "id" : 14088072,
      "verified" : false
    }
  },
  "id" : 530093390281867265,
  "created_at" : "2014-11-05 20:24:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Goodwin",
      "screen_name" : "kimgoodwin",
      "indices" : [ 3, 14 ],
      "id_str" : "16295946",
      "id" : 16295946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530066693704675328",
  "text" : "RT @kimgoodwin: If you find your work unsatisfying, others will eventually find your work product  unsatisfying.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "530063578028855296",
    "text" : "If you find your work unsatisfying, others will eventually find your work product  unsatisfying.",
    "id" : 530063578028855296,
    "created_at" : "2014-11-05 18:26:19 +0000",
    "user" : {
      "name" : "Kim Goodwin",
      "screen_name" : "kimgoodwin",
      "protected" : false,
      "id_str" : "16295946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756436364929994752\/ADL0_wac_normal.jpg",
      "id" : 16295946,
      "verified" : false
    }
  },
  "id" : 530066693704675328,
  "created_at" : "2014-11-05 18:38:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/qgHmc6u8qB",
      "expanded_url" : "http:\/\/bit.ly\/1vCXwV4",
      "display_url" : "bit.ly\/1vCXwV4"
    } ]
  },
  "geo" : { },
  "id_str" : "529421766943195136",
  "text" : "RT @etug: Ok just so you have a little something to go on for what's happening at the #etug unconference:  http:\/\/t.co\/qgHmc6u8qB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 76, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/qgHmc6u8qB",
        "expanded_url" : "http:\/\/bit.ly\/1vCXwV4",
        "display_url" : "bit.ly\/1vCXwV4"
      } ]
    },
    "geo" : { },
    "id_str" : "529420696997212160",
    "text" : "Ok just so you have a little something to go on for what's happening at the #etug unconference:  http:\/\/t.co\/qgHmc6u8qB",
    "id" : 529420696997212160,
    "created_at" : "2014-11-03 23:51:44 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 529421766943195136,
  "created_at" : "2014-11-03 23:56:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 3, 11 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 106, 109 ]
    }, {
      "text" : "research",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/4EOc4NFGv5",
      "expanded_url" : "http:\/\/www.userfocus.co.uk\/articles\/60-ways-to-understand-user-needs.html?utm_content=bufferf1854&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "userfocus.co.uk\/articles\/60-wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529306435767644160",
  "text" : "RT @dmitryn: 60 ways to understand user needs that aren't focus groups or surveys. http:\/\/t.co\/4EOc4NFGv5 #UX #research",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 93, 96 ]
      }, {
        "text" : "research",
        "indices" : [ 97, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/4EOc4NFGv5",
        "expanded_url" : "http:\/\/www.userfocus.co.uk\/articles\/60-ways-to-understand-user-needs.html?utm_content=bufferf1854&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
        "display_url" : "userfocus.co.uk\/articles\/60-wa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529286606453506048",
    "text" : "60 ways to understand user needs that aren't focus groups or surveys. http:\/\/t.co\/4EOc4NFGv5 #UX #research",
    "id" : 529286606453506048,
    "created_at" : "2014-11-03 14:58:55 +0000",
    "user" : {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "protected" : false,
      "id_str" : "1550251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623216199791329280\/hoNAcmrW_normal.jpg",
      "id" : 1550251,
      "verified" : false
    }
  },
  "id" : 529306435767644160,
  "created_at" : "2014-11-03 16:17:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]