Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gavin Henrick",
      "screen_name" : "ghenrick",
      "indices" : [ 0, 9 ],
      "id_str" : "24712239",
      "id" : 24712239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307174073673338880",
  "geo" : { },
  "id_str" : "307176810234408960",
  "in_reply_to_user_id" : 24712239,
  "text" : "@ghenrick Well put - really something to be defined on a course-by-course basis! Same goes for top-level nav menus (not to be site-wide).",
  "id" : 307176810234408960,
  "in_reply_to_status_id" : 307174073673338880,
  "created_at" : "2013-02-28 17:13:53 +0000",
  "in_reply_to_screen_name" : "ghenrick",
  "in_reply_to_user_id_str" : "24712239",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gavin Henrick",
      "screen_name" : "ghenrick",
      "indices" : [ 0, 9 ],
      "id_str" : "24712239",
      "id" : 24712239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307026985836769280",
  "geo" : { },
  "id_str" : "307163387379470337",
  "in_reply_to_user_id" : 24712239,
  "text" : "@ghenrick Even just the ability to choose one (i.e. Events) to be above all page content when viewed on a smaller screen would be useful.",
  "id" : 307163387379470337,
  "in_reply_to_status_id" : 307026985836769280,
  "created_at" : "2013-02-28 16:20:33 +0000",
  "in_reply_to_screen_name" : "ghenrick",
  "in_reply_to_user_id_str" : "24712239",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gavin Henrick",
      "screen_name" : "ghenrick",
      "indices" : [ 0, 9 ],
      "id_str" : "24712239",
      "id" : 24712239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/eRqHMMc0PB",
      "expanded_url" : "http:\/\/css-tricks.com\/content-folding\/",
      "display_url" : "css-tricks.com\/content-foldin\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "306843106089771008",
  "geo" : { },
  "id_str" : "306926527344427008",
  "in_reply_to_user_id" : 24712239,
  "text" : "@ghenrick Based on my experience with Moodle + responsive theme, I would like to see an option for content folding http:\/\/t.co\/eRqHMMc0PB",
  "id" : 306926527344427008,
  "in_reply_to_status_id" : 306843106089771008,
  "created_at" : "2013-02-28 00:39:21 +0000",
  "in_reply_to_screen_name" : "ghenrick",
  "in_reply_to_user_id_str" : "24712239",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stuart lamour",
      "screen_name" : "stuartlamour",
      "indices" : [ 0, 13 ],
      "id_str" : "8075672",
      "id" : 8075672
    }, {
      "name" : "City Moodle",
      "screen_name" : "CityMoodle",
      "indices" : [ 14, 25 ],
      "id_str" : "534242193",
      "id" : 534242193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/XsBr1B7Kgh",
      "expanded_url" : "http:\/\/uxfundamentals.com\/moodle\/course\/view.php?id=2",
      "display_url" : "uxfundamentals.com\/moodle\/course\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "306722370360590337",
  "geo" : { },
  "id_str" : "306830335906287616",
  "in_reply_to_user_id" : 8075672,
  "text" : "@stuartlamour @CityMoodle My example responsive Moodle site http:\/\/t.co\/XsBr1B7Kgh",
  "id" : 306830335906287616,
  "in_reply_to_status_id" : 306722370360590337,
  "created_at" : "2013-02-27 18:17:07 +0000",
  "in_reply_to_screen_name" : "stuartlamour",
  "in_reply_to_user_id_str" : "8075672",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetroapp.com\" rel=\"nofollow\"\u003ETweetro+ for Windows 8\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/8PGwZBUYMk",
      "expanded_url" : "http:\/\/blog.pressbooks.com\/?p=211",
      "display_url" : "blog.pressbooks.com\/?p=211"
    } ]
  },
  "geo" : { },
  "id_str" : "306568201196691458",
  "text" : "RT @clintlalonde: Pressbooks Wordpress plugin now open source http:\/\/t.co\/8PGwZBUYMk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/8PGwZBUYMk",
        "expanded_url" : "http:\/\/blog.pressbooks.com\/?p=211",
        "display_url" : "blog.pressbooks.com\/?p=211"
      } ]
    },
    "geo" : { },
    "id_str" : "306566309544591360",
    "text" : "Pressbooks Wordpress plugin now open source http:\/\/t.co\/8PGwZBUYMk",
    "id" : 306566309544591360,
    "created_at" : "2013-02-27 00:47:58 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 306568201196691458,
  "created_at" : "2013-02-27 00:55:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetroapp.com\" rel=\"nofollow\"\u003ETweetro+ for Windows 8\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306559031529578496",
  "geo" : { },
  "id_str" : "306567907725414401",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh Well said, and all visions also benefit from being re-evaluated periodically.",
  "id" : 306567907725414401,
  "in_reply_to_status_id" : 306559031529578496,
  "created_at" : "2013-02-27 00:54:19 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RunRev",
      "screen_name" : "RunRev",
      "indices" : [ 3, 10 ],
      "id_str" : "2882852739",
      "id" : 2882852739
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 31, 43 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LiveCode",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/wX8iDBvEvH",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/1755283828\/open-source-edition-of-livecode",
      "display_url" : "kickstarter.com\/projects\/17552\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306539281848082432",
  "text" : "RT @runrev: Next Gen #LiveCode @kickstarter we made it! Thanks to all! 35 hrs left for some amazing stretch goals &amp; great rewards ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kickstarter",
        "screen_name" : "kickstarter",
        "indices" : [ 19, 31 ],
        "id_str" : "16186995",
        "id" : 16186995
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LiveCode",
        "indices" : [ 9, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/wX8iDBvEvH",
        "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/1755283828\/open-source-edition-of-livecode",
        "display_url" : "kickstarter.com\/projects\/17552\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306520656034549760",
    "text" : "Next Gen #LiveCode @kickstarter we made it! Thanks to all! 35 hrs left for some amazing stretch goals &amp; great rewards http:\/\/t.co\/wX8iDBvEvH",
    "id" : 306520656034549760,
    "created_at" : "2013-02-26 21:46:33 +0000",
    "user" : {
      "name" : "LiveCode",
      "screen_name" : "LiveCode",
      "protected" : false,
      "id_str" : "69660541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552829787870220288\/UP7Pvo9Y_normal.jpeg",
      "id" : 69660541,
      "verified" : false
    }
  },
  "id" : 306539281848082432,
  "created_at" : "2013-02-26 23:00:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/CZLHk0Ezj3",
      "expanded_url" : "http:\/\/Wired.com",
      "display_url" : "Wired.com"
    }, {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/hpSY8IAFco",
      "expanded_url" : "http:\/\/www.wired.com\/geekdad\/2013\/02\/kickstarter-alert-cross-platform-app-programming-less-than-42h-remaining\/",
      "display_url" : "wired.com\/geekdad\/2013\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306469482916872192",
  "text" : "Kickstarter Alert: Cross-Platform App Programming (Less Than 42h Remaining!) | GeekDad | http:\/\/t.co\/CZLHk0Ezj3 http:\/\/t.co\/hpSY8IAFco",
  "id" : 306469482916872192,
  "created_at" : "2013-02-26 18:23:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305089872614535168",
  "geo" : { },
  "id_str" : "305091468765310976",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Trackpad? Two-finger swipe is handy way to navigate the Start screen horizontally...",
  "id" : 305091468765310976,
  "in_reply_to_status_id" : 305089872614535168,
  "created_at" : "2013-02-22 23:07:29 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305086344047255552",
  "geo" : { },
  "id_str" : "305089311844478976",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Do you have a touchscreen? I can attest to the big difference it makes. I use Win8 with Lenovo Yoga (touchscreen ultrabook).",
  "id" : 305089311844478976,
  "in_reply_to_status_id" : 305086344047255552,
  "created_at" : "2013-02-22 22:58:54 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fast Company",
      "screen_name" : "FastCompany",
      "indices" : [ 3, 15 ],
      "id_str" : "2735591",
      "id" : 2735591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/UC0dxwTVdX",
      "expanded_url" : "http:\/\/trib.al\/dQhCQ7S",
      "display_url" : "trib.al\/dQhCQ7S"
    } ]
  },
  "geo" : { },
  "id_str" : "304757784086462464",
  "text" : "RT @FastCompany Google's Chromebook Pixel is here http:\/\/t.co\/UC0dxwTVdX &lt;- As I stated earlier laptops w\/o touch are antiques. Apple?",
  "id" : 304757784086462464,
  "created_at" : "2013-02-22 01:01:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BraveNewCode",
      "screen_name" : "BraveNewCode",
      "indices" : [ 3, 16 ],
      "id_str" : "89039840",
      "id" : 89039840
    }, {
      "name" : "The Next Web \uD83C\uDF0D\uD83D\uDCBB\uD83D\uDCF1",
      "screen_name" : "TheNextWeb",
      "indices" : [ 139, 140 ],
      "id_str" : "10876852",
      "id" : 10876852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/BlPD528jYh",
      "expanded_url" : "http:\/\/owl.li\/hWbWR",
      "display_url" : "owl.li\/hWbWR"
    } ]
  },
  "geo" : { },
  "id_str" : "304756093274451969",
  "text" : "RT @bravenewcode: Tablet shipments experienced the largest growth in 2012, up 78.4% over 2011, smartphones grew 46.1% http:\/\/t.co\/BlPD52 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Next Web \uD83C\uDF0D\uD83D\uDCBB\uD83D\uDCF1",
        "screen_name" : "TheNextWeb",
        "indices" : [ 127, 138 ],
        "id_str" : "10876852",
        "id" : 10876852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/BlPD528jYh",
        "expanded_url" : "http:\/\/owl.li\/hWbWR",
        "display_url" : "owl.li\/hWbWR"
      } ]
    },
    "geo" : { },
    "id_str" : "304751135552585728",
    "text" : "Tablet shipments experienced the largest growth in 2012, up 78.4% over 2011, smartphones grew 46.1% http:\/\/t.co\/BlPD528jYh via @TheNextWeb",
    "id" : 304751135552585728,
    "created_at" : "2013-02-22 00:35:07 +0000",
    "user" : {
      "name" : "WPtouch",
      "screen_name" : "wptouch",
      "protected" : false,
      "id_str" : "15478959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462325592214343681\/qQ0_HpkJ_normal.png",
      "id" : 15478959,
      "verified" : false
    }
  },
  "id" : 304756093274451969,
  "created_at" : "2013-02-22 00:54:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootie13",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/XsBr1B7Kgh",
      "expanded_url" : "http:\/\/uxfundamentals.com\/moodle\/course\/view.php?id=2",
      "display_url" : "uxfundamentals.com\/moodle\/course\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304615012310327297",
  "text" : "Excited to see Bootstrap as a topic at #mootie13 Hackfest! Mobile-friendly demo site using Bas Brands Bootstrap theme http:\/\/t.co\/XsBr1B7Kgh",
  "id" : 304615012310327297,
  "created_at" : "2013-02-21 15:34:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtain Revenue",
      "screen_name" : "corvustweets",
      "indices" : [ 0, 13 ],
      "id_str" : "2503692858",
      "id" : 2503692858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304362430333595649",
  "text" : "@corvustweets Oh yes, that would be most lovely too!",
  "id" : 304362430333595649,
  "created_at" : "2013-02-20 22:50:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtain Revenue",
      "screen_name" : "corvustweets",
      "indices" : [ 0, 13 ],
      "id_str" : "2503692858",
      "id" : 2503692858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304362062241480704",
  "text" : "@corvustweets I am holding out for Facebook Glass...",
  "id" : 304362062241480704,
  "created_at" : "2013-02-20 22:49:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304351463776337920",
  "text" : "Thinking about mobile learning strategy; problem\/opportunity, value provided, where to deliver, and how to create. Thoughts Twitterverse?",
  "id" : 304351463776337920,
  "created_at" : "2013-02-20 22:06:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 94, 106 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/2FoZ9ReASD",
      "expanded_url" : "http:\/\/kck.st\/WutiWr",
      "display_url" : "kck.st\/WutiWr"
    } ]
  },
  "geo" : { },
  "id_str" : "304348168127139841",
  "text" : "Next Generation LiveCode (Open Source) by RunRev Ltd \u2014 Kickstarter http:\/\/t.co\/2FoZ9ReASD via @kickstarter",
  "id" : 304348168127139841,
  "created_at" : "2013-02-20 21:53:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "indices" : [ 0, 10 ],
      "id_str" : "18983561",
      "id" : 18983561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootie13",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304269412016476160",
  "in_reply_to_user_id" : 18983561,
  "text" : "@basbrands Great to see all the discussion about Bootstrap at #mootie13!",
  "id" : 304269412016476160,
  "created_at" : "2013-02-20 16:40:55 +0000",
  "in_reply_to_screen_name" : "basbrands",
  "in_reply_to_user_id_str" : "18983561",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootie13",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 105 ],
      "url" : "https:\/\/t.co\/H4dykwp9",
      "expanded_url" : "https:\/\/tracker.moodle.org\/browse\/MDL-38016",
      "display_url" : "tracker.moodle.org\/browse\/MDL-380\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304240637803364352",
  "text" : "RT @SDCMoodle: Lots of good conversation happening about Bootstrap, themeing et al: https:\/\/t.co\/H4dykwp9 #mootie13",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mootie13",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 90 ],
        "url" : "https:\/\/t.co\/H4dykwp9",
        "expanded_url" : "https:\/\/tracker.moodle.org\/browse\/MDL-38016",
        "display_url" : "tracker.moodle.org\/browse\/MDL-380\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304180741451952129",
    "text" : "Lots of good conversation happening about Bootstrap, themeing et al: https:\/\/t.co\/H4dykwp9 #mootie13",
    "id" : 304180741451952129,
    "created_at" : "2013-02-20 10:48:34 +0000",
    "user" : {
      "name" : "Paul Vaughan",
      "screen_name" : "MoodleVaughany",
      "protected" : false,
      "id_str" : "69288106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632134443055063040\/42Tf90k7_normal.jpg",
      "id" : 69288106,
      "verified" : false
    }
  },
  "id" : 304240637803364352,
  "created_at" : "2013-02-20 14:46:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 79, 89 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/0Uez92zQ",
      "expanded_url" : "http:\/\/shar.es\/YQ27w",
      "display_url" : "shar.es\/YQ27w"
    } ]
  },
  "geo" : { },
  "id_str" : "303614769166970880",
  "text" : "How Do Users Really Hold Mobile Devices? :: UXmatters http:\/\/t.co\/0Uez92zQ via @sharethis",
  "id" : 303614769166970880,
  "created_at" : "2013-02-18 21:19:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 3, 14 ],
      "id_str" : "28429477",
      "id" : 28429477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storify",
      "indices" : [ 69, 77 ]
    }, {
      "text" : "mootca13",
      "indices" : [ 78, 87 ]
    }, {
      "text" : "moodle",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/wBRAT5bY",
      "expanded_url" : "http:\/\/sfy.co\/eET8",
      "display_url" : "sfy.co\/eET8"
    } ]
  },
  "geo" : { },
  "id_str" : "303523979581349888",
  "text" : "RT @chadleaman: Canada Moodle Moot 2013 summary http:\/\/t.co\/wBRAT5bY #storify #mootca13 #moodle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "storify",
        "indices" : [ 53, 61 ]
      }, {
        "text" : "mootca13",
        "indices" : [ 62, 71 ]
      }, {
        "text" : "moodle",
        "indices" : [ 72, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/wBRAT5bY",
        "expanded_url" : "http:\/\/sfy.co\/eET8",
        "display_url" : "sfy.co\/eET8"
      } ]
    },
    "geo" : { },
    "id_str" : "303332341504430080",
    "text" : "Canada Moodle Moot 2013 summary http:\/\/t.co\/wBRAT5bY #storify #mootca13 #moodle",
    "id" : 303332341504430080,
    "created_at" : "2013-02-18 02:37:20 +0000",
    "user" : {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "protected" : false,
      "id_str" : "28429477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529010906080894976\/Ij-z3nNd_normal.png",
      "id" : 28429477,
      "verified" : false
    }
  },
  "id" : 303523979581349888,
  "created_at" : "2013-02-18 15:18:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinny Stocker",
      "screen_name" : "vinnystocker",
      "indices" : [ 0, 13 ],
      "id_str" : "168094459",
      "id" : 168094459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302670874832683008",
  "geo" : { },
  "id_str" : "302930809873133568",
  "in_reply_to_user_id" : 168094459,
  "text" : "@vinnystocker Thanks for sharing!",
  "id" : 302930809873133568,
  "in_reply_to_status_id" : 302670874832683008,
  "created_at" : "2013-02-17 00:01:47 +0000",
  "in_reply_to_screen_name" : "vinnystocker",
  "in_reply_to_user_id_str" : "168094459",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Gleebits",
      "screen_name" : "DGleebits",
      "indices" : [ 0, 10 ],
      "id_str" : "364557525",
      "id" : 364557525
    }, {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 11, 22 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302544839172558848",
  "in_reply_to_user_id" : 364557525,
  "text" : "@DGleebits @sparkandco Thanks for the RTs. Have a great weekend!",
  "id" : 302544839172558848,
  "created_at" : "2013-02-15 22:28:05 +0000",
  "in_reply_to_screen_name" : "DGleebits",
  "in_reply_to_user_id_str" : "364557525",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetroapp.com\" rel=\"nofollow\"\u003ETweetro+ for Windows 8\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootca13",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/LM4j59sm",
      "expanded_url" : "http:\/\/www.paulhibbitts.com\/mobilelearningux\/moodle\/index.html",
      "display_url" : "paulhibbitts.com\/mobilelearning\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302515105596325889",
  "text" : "#mootca13 attendees who were not able to make it to my mobile learning UX session can access presentation resources at http:\/\/t.co\/LM4j59sm",
  "id" : 302515105596325889,
  "created_at" : "2013-02-15 20:29:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetroapp.com\" rel=\"nofollow\"\u003ETweetro+ for Windows 8\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Canada Moodle Moot",
      "screen_name" : "canadamoot",
      "indices" : [ 100, 111 ],
      "id_str" : "22040608",
      "id" : 22040608
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootca13",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302513704728137728",
  "text" : "Thanks for such a great conference #mootca13 attendees, organizers, fellow presenters and of course @canadamoot",
  "id" : 302513704728137728,
  "created_at" : "2013-02-15 20:24:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everett McKay",
      "screen_name" : "UXDesignEdge",
      "indices" : [ 0, 13 ],
      "id_str" : "205411420",
      "id" : 205411420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302072027798450177",
  "geo" : { },
  "id_str" : "302252855895666690",
  "in_reply_to_user_id" : 205411420,
  "text" : "@UXDesignEdge Just placed my pre-order for a copy from Amazon.ca!",
  "id" : 302252855895666690,
  "in_reply_to_status_id" : 302072027798450177,
  "created_at" : "2013-02-15 03:07:51 +0000",
  "in_reply_to_screen_name" : "UXDesignEdge",
  "in_reply_to_user_id_str" : "205411420",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynne Polischuik",
      "screen_name" : "lynneux",
      "indices" : [ 3, 11 ],
      "id_str" : "18745824",
      "id" : 18745824
    }, {
      "name" : "vanue",
      "screen_name" : "vanue",
      "indices" : [ 18, 24 ],
      "id_str" : "24132108",
      "id" : 24132108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/X5hRcSli",
      "expanded_url" : "http:\/\/meetu.ps\/wPc7j",
      "display_url" : "meetu.ps\/wPc7j"
    } ]
  },
  "geo" : { },
  "id_str" : "302198440572628992",
  "text" : "RT @lynneux: Join @VanUE for 'Hiring UX: From Salaries to Skills'. Feb 26th at VFS. Register now!  http:\/\/t.co\/X5hRcSli",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "vanue",
        "screen_name" : "vanue",
        "indices" : [ 5, 11 ],
        "id_str" : "24132108",
        "id" : 24132108
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/X5hRcSli",
        "expanded_url" : "http:\/\/meetu.ps\/wPc7j",
        "display_url" : "meetu.ps\/wPc7j"
      } ]
    },
    "geo" : { },
    "id_str" : "302182906544136192",
    "text" : "Join @VanUE for 'Hiring UX: From Salaries to Skills'. Feb 26th at VFS. Register now!  http:\/\/t.co\/X5hRcSli",
    "id" : 302182906544136192,
    "created_at" : "2013-02-14 22:29:53 +0000",
    "user" : {
      "name" : "Lynne Polischuik",
      "screen_name" : "lynneux",
      "protected" : false,
      "id_str" : "18745824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693853974412177409\/NTVYOqlk_normal.jpg",
      "id" : 18745824,
      "verified" : false
    }
  },
  "id" : 302198440572628992,
  "created_at" : "2013-02-14 23:31:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Fullerton",
      "screen_name" : "tomfullerton",
      "indices" : [ 0, 13 ],
      "id_str" : "66946501",
      "id" : 66946501
    }, {
      "name" : "VCC's CID News feed",
      "screen_name" : "CIDvcc",
      "indices" : [ 14, 21 ],
      "id_str" : "50566264",
      "id" : 50566264
    }, {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 22, 33 ],
      "id_str" : "28429477",
      "id" : 28429477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302140783870484480",
  "geo" : { },
  "id_str" : "302186729601908736",
  "in_reply_to_user_id" : 66946501,
  "text" : "@tomfullerton @CIDvcc @chadleaman Thanks very much for the kind words, it was my pleasure. Cheers!",
  "id" : 302186729601908736,
  "in_reply_to_status_id" : 302140783870484480,
  "created_at" : "2013-02-14 22:45:05 +0000",
  "in_reply_to_screen_name" : "tomfullerton",
  "in_reply_to_user_id_str" : "66946501",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootca13",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/qayV2nNQ",
      "expanded_url" : "http:\/\/www.slideshare.net\/hibbittsdesign\/canada-moodlemoot-2013-mobile-learning-a-user-experience-perspective",
      "display_url" : "slideshare.net\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302185447323496449",
  "text" : "Thanks to everyone who squeezed into my Mobile Learning UX session today! Great questions and discussion. http:\/\/t.co\/qayV2nNQ #mootca13",
  "id" : 302185447323496449,
  "created_at" : "2013-02-14 22:39:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 0, 11 ],
      "id_str" : "28429477",
      "id" : 28429477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/8L4BQ992",
      "expanded_url" : "http:\/\/www.slideshare.net\/utbkevin\/why-mobile-first-isnt-enough-developing-a-better-user-experience",
      "display_url" : "slideshare.net\/utbkevin\/why-m\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "302127777056972802",
  "geo" : { },
  "id_str" : "302184375422959616",
  "in_reply_to_user_id" : 28429477,
  "text" : "@chadleaman Thanks for the tweets! Credit for \"experience first\" should go to Kevin Powell http:\/\/t.co\/8L4BQ992",
  "id" : 302184375422959616,
  "in_reply_to_status_id" : 302127777056972802,
  "created_at" : "2013-02-14 22:35:44 +0000",
  "in_reply_to_screen_name" : "chadleaman",
  "in_reply_to_user_id_str" : "28429477",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootca13",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302104771538591745",
  "text" : "RT @BCcampus: It\u2019s apparent from Dr. Bates\u2019 talk that \u201Cquality in e-learning\u201D is really \u201Cquality in learning\u201D using the infrastructure o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mootca13",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302103488454864897",
    "text" : "It\u2019s apparent from Dr. Bates\u2019 talk that \u201Cquality in e-learning\u201D is really \u201Cquality in learning\u201D using the infrastructure on hand. #mootca13",
    "id" : 302103488454864897,
    "created_at" : "2013-02-14 17:14:19 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 302104771538591745,
  "created_at" : "2013-02-14 17:19:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everett McKay",
      "screen_name" : "UXDesignEdge",
      "indices" : [ 3, 16 ],
      "id_str" : "205411420",
      "id" : 205411420
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "ux",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302082664544997376",
  "text" : "RT @UXDesignEdge: My next book, \"UI is Communication\" is now listed on Amazon. Intuitive UI from communication POV. Publication date is  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ux",
        "indices" : [ 133, 136 ]
      }, {
        "text" : "ux",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302072027798450177",
    "text" : "My next book, \"UI is Communication\" is now listed on Amazon. Intuitive UI from communication POV. Publication date is June 29, 2013. #ux #ux",
    "id" : 302072027798450177,
    "created_at" : "2013-02-14 15:09:18 +0000",
    "user" : {
      "name" : "Everett McKay",
      "screen_name" : "UXDesignEdge",
      "protected" : false,
      "id_str" : "205411420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000149771048\/61b261f6ae826532a06e5acdda953c15_normal.png",
      "id" : 205411420,
      "verified" : false
    }
  },
  "id" : 302082664544997376,
  "created_at" : "2013-02-14 15:51:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootca13",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/hr2hkM1I",
      "expanded_url" : "http:\/\/canadamoot13.sched.org\/event\/5e1e4c32be84e8108e6d0431763f449f",
      "display_url" : "canadamoot13.sched.org\/event\/5e1e4c32\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302072782232109059",
  "text" : "Presenting Mobile Learning: A User Experience Perspective this morning #mootca13 http:\/\/t.co\/hr2hkM1I Will share final slides afterwards.",
  "id" : 302072782232109059,
  "created_at" : "2013-02-14 15:12:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetroapp.com\" rel=\"nofollow\"\u003ETweetro+ for Windows 8\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 3, 14 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/36shEzrO",
      "expanded_url" : "http:\/\/lnkd.in\/-MJBvS",
      "display_url" : "lnkd.in\/-MJBvS"
    } ]
  },
  "geo" : { },
  "id_str" : "301906622886862848",
  "text" : "RT @sparkandco: Job opportunity: Learning Facilitator Member Services Cen at Vancity - Vancouver, Canada Area #jobs http:\/\/t.co\/36shEzrO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 94, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/36shEzrO",
        "expanded_url" : "http:\/\/lnkd.in\/-MJBvS",
        "display_url" : "lnkd.in\/-MJBvS"
      } ]
    },
    "geo" : { },
    "id_str" : "301857935368261632",
    "text" : "Job opportunity: Learning Facilitator Member Services Cen at Vancity - Vancouver, Canada Area #jobs http:\/\/t.co\/36shEzrO",
    "id" : 301857935368261632,
    "created_at" : "2013-02-14 00:58:34 +0000",
    "user" : {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "protected" : false,
      "id_str" : "47105948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656831720809889792\/aQbeijGD_normal.png",
      "id" : 47105948,
      "verified" : false
    }
  },
  "id" : 301906622886862848,
  "created_at" : "2013-02-14 04:12:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/hr2hkM1I",
      "expanded_url" : "http:\/\/canadamoot13.sched.org\/event\/5e1e4c32be84e8108e6d0431763f449f",
      "display_url" : "canadamoot13.sched.org\/event\/5e1e4c32\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301839692104609793",
  "text" : "@_DirkMeyer_ Another option would be a responsive web design (RWD) theme, which will be part of my talk tomorrow http:\/\/t.co\/hr2hkM1I",
  "id" : 301839692104609793,
  "created_at" : "2013-02-13 23:46:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 119, 130 ],
      "id_str" : "28429477",
      "id" : 28429477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootca13",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301835368012070913",
  "text" : "Greatly enjoyed seeing the many ways Moodle is being used in the wild in the Show and Tell session. Thanks for hosting @chadleaman #mootca13",
  "id" : 301835368012070913,
  "created_at" : "2013-02-13 23:28:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 3, 14 ],
      "id_str" : "28429477",
      "id" : 28429477
    }, {
      "name" : "Canada Moodle Moot",
      "screen_name" : "canadamoot",
      "indices" : [ 31, 42 ],
      "id_str" : "22040608",
      "id" : 22040608
    }, {
      "name" : "Decoda Literacy",
      "screen_name" : "decodaliteracy",
      "indices" : [ 88, 103 ],
      "id_str" : "182442017",
      "id" : 182442017
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootca13",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301798825138475008",
  "text" : "RT @chadleaman: Very cool that @canadamoot speakers have donation made in their name to @decodaliteracy. #mootca13",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Canada Moodle Moot",
        "screen_name" : "canadamoot",
        "indices" : [ 15, 26 ],
        "id_str" : "22040608",
        "id" : 22040608
      }, {
        "name" : "Decoda Literacy",
        "screen_name" : "decodaliteracy",
        "indices" : [ 72, 87 ],
        "id_str" : "182442017",
        "id" : 182442017
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mootca13",
        "indices" : [ 89, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301714028202426368",
    "text" : "Very cool that @canadamoot speakers have donation made in their name to @decodaliteracy. #mootca13",
    "id" : 301714028202426368,
    "created_at" : "2013-02-13 15:26:44 +0000",
    "user" : {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "protected" : false,
      "id_str" : "28429477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529010906080894976\/Ij-z3nNd_normal.png",
      "id" : 28429477,
      "verified" : false
    }
  },
  "id" : 301798825138475008,
  "created_at" : "2013-02-13 21:03:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Suttle",
      "screen_name" : "kevinSuttle",
      "indices" : [ 3, 15 ],
      "id_str" : "14859608",
      "id" : 14859608
    }, {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 75, 81 ],
      "id_str" : "13889622",
      "id" : 13889622
    }, {
      "name" : "Josh Clark",
      "screen_name" : "globalmoxie",
      "indices" : [ 83, 95 ],
      "id_str" : "2733270440",
      "id" : 2733270440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/JIb0ykqc",
      "expanded_url" : "http:\/\/buff.ly\/YokQFr",
      "display_url" : "buff.ly\/YokQFr"
    } ]
  },
  "geo" : { },
  "id_str" : "301461143183032320",
  "text" : "RT @kevinSuttle: Chrome's Giant Touch-Optimized Menu http:\/\/t.co\/JIb0ykqc +@lukew, @globalmoxie",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Luke Wroblewski",
        "screen_name" : "lukew",
        "indices" : [ 58, 64 ],
        "id_str" : "13889622",
        "id" : 13889622
      }, {
        "name" : "Josh Clark",
        "screen_name" : "globalmoxie",
        "indices" : [ 66, 78 ],
        "id_str" : "2733270440",
        "id" : 2733270440
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/JIb0ykqc",
        "expanded_url" : "http:\/\/buff.ly\/YokQFr",
        "display_url" : "buff.ly\/YokQFr"
      } ]
    },
    "geo" : { },
    "id_str" : "301422212576051200",
    "text" : "Chrome's Giant Touch-Optimized Menu http:\/\/t.co\/JIb0ykqc +@lukew, @globalmoxie",
    "id" : 301422212576051200,
    "created_at" : "2013-02-12 20:07:10 +0000",
    "user" : {
      "name" : "Kevin Suttle",
      "screen_name" : "kevinSuttle",
      "protected" : false,
      "id_str" : "14859608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766268546997489664\/rMnRgy43_normal.jpg",
      "id" : 14859608,
      "verified" : false
    }
  },
  "id" : 301461143183032320,
  "created_at" : "2013-02-12 22:41:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootca13",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 114 ],
      "url" : "https:\/\/t.co\/ZZyo2qFj",
      "expanded_url" : "https:\/\/speakerdeck.com\/hibbittsdesign\/canada-moodlemoot-2013-mobile-learning-a-user-experience-perspective",
      "display_url" : "speakerdeck.com\/hibbittsdesign\u2026"
    }, {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/qayV2nNQ",
      "expanded_url" : "http:\/\/www.slideshare.net\/hibbittsdesign\/canada-moodlemoot-2013-mobile-learning-a-user-experience-perspective",
      "display_url" : "slideshare.net\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301453257988005888",
  "text" : "Slides for my Mobile Learning: A User Experience Perspective talk at #mootca13 now available https:\/\/t.co\/ZZyo2qFj http:\/\/t.co\/qayV2nNQ",
  "id" : 301453257988005888,
  "created_at" : "2013-02-12 22:10:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootca13",
      "indices" : [ 111, 120 ]
    }, {
      "text" : "mlearning",
      "indices" : [ 121, 131 ]
    }, {
      "text" : "ux",
      "indices" : [ 132, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/LM4j59sm",
      "expanded_url" : "http:\/\/www.paulhibbitts.com\/mobilelearningux\/moodle\/index.html",
      "display_url" : "paulhibbitts.com\/mobilelearning\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301032339901935617",
  "text" : "Resources for my Mobile Learning: A User Experience Perspective talk at Canada MoodleMoot http:\/\/t.co\/LM4j59sm #mootca13 #mlearning #ux",
  "id" : 301032339901935617,
  "created_at" : "2013-02-11 18:17:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Harrison",
      "screen_name" : "oliverh72",
      "indices" : [ 0, 10 ],
      "id_str" : "219368128",
      "id" : 219368128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300464454972358656",
  "geo" : { },
  "id_str" : "300643850370813954",
  "in_reply_to_user_id" : 219368128,
  "text" : "@oliverh72 A solid album by any measure!",
  "id" : 300643850370813954,
  "in_reply_to_status_id" : 300464454972358656,
  "created_at" : "2013-02-10 16:34:14 +0000",
  "in_reply_to_screen_name" : "oliverh72",
  "in_reply_to_user_id_str" : "219368128",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Pontefract",
      "screen_name" : "dpontefract",
      "indices" : [ 0, 12 ],
      "id_str" : "18343116",
      "id" : 18343116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300384385163739136",
  "geo" : { },
  "id_str" : "300404356187033601",
  "in_reply_to_user_id" : 18343116,
  "text" : "@dpontefract Thought provoking question. Finding shelf life instructional materials are continually shortening as well (in my experience).",
  "id" : 300404356187033601,
  "in_reply_to_status_id" : 300384385163739136,
  "created_at" : "2013-02-10 00:42:34 +0000",
  "in_reply_to_screen_name" : "dpontefract",
  "in_reply_to_user_id_str" : "18343116",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jeremy graham",
      "screen_name" : "jeremy_graham",
      "indices" : [ 3, 17 ],
      "id_str" : "1496814312",
      "id" : 1496814312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "marketing",
      "indices" : [ 111, 121 ]
    }, {
      "text" : "lemming",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299687495279443969",
  "text" : "RT @jeremy_graham: Just signed up for an App about which I know abs. nothing. Because 350k others already did. #marketing #lemming",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "marketing",
        "indices" : [ 92, 102 ]
      }, {
        "text" : "lemming",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299670295546056704",
    "text" : "Just signed up for an App about which I know abs. nothing. Because 350k others already did. #marketing #lemming",
    "id" : 299670295546056704,
    "created_at" : "2013-02-08 00:05:40 +0000",
    "user" : {
      "name" : "Jeremy Graham",
      "screen_name" : "js_graham",
      "protected" : false,
      "id_str" : "39588452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000051591219\/45f129d2773141592654d2f2cdece6d4_normal.jpeg",
      "id" : 39588452,
      "verified" : false
    }
  },
  "id" : 299687495279443969,
  "created_at" : "2013-02-08 01:14:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlearning",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/Fliu2EFf",
      "expanded_url" : "http:\/\/www.paulhibbitts.com\/mobilelearningux\/",
      "display_url" : "paulhibbitts.com\/mobilelearning\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299623021726007296",
  "text" : "The most exciting part of mobile learning is the intersection of learning and interaction design. #mlearning resources http:\/\/t.co\/Fliu2EFf",
  "id" : 299623021726007296,
  "created_at" : "2013-02-07 20:57:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Canada Moodle Moot",
      "screen_name" : "canadamoot",
      "indices" : [ 3, 14 ],
      "id_str" : "22040608",
      "id" : 22040608
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootca13",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/trG3qVFb",
      "expanded_url" : "http:\/\/ht.ly\/hw3zl",
      "display_url" : "ht.ly\/hw3zl"
    } ]
  },
  "geo" : { },
  "id_str" : "299614326233387009",
  "text" : "RT @canadamoot: Before you get to Vancouver next week: personalize your schedule and download it onto your phone #mootca13 http:\/\/t.co\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mootca13",
        "indices" : [ 97, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/trG3qVFb",
        "expanded_url" : "http:\/\/ht.ly\/hw3zl",
        "display_url" : "ht.ly\/hw3zl"
      } ]
    },
    "geo" : { },
    "id_str" : "299601226889310208",
    "text" : "Before you get to Vancouver next week: personalize your schedule and download it onto your phone #mootca13 http:\/\/t.co\/trG3qVFb",
    "id" : 299601226889310208,
    "created_at" : "2013-02-07 19:31:13 +0000",
    "user" : {
      "name" : "Canada Moodle Moot",
      "screen_name" : "canadamoot",
      "protected" : false,
      "id_str" : "22040608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533678470035804160\/H2IjdP3-_normal.jpeg",
      "id" : 22040608,
      "verified" : false
    }
  },
  "id" : 299614326233387009,
  "created_at" : "2013-02-07 20:23:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    }, {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "indices" : [ 53, 62 ],
      "id_str" : "18613",
      "id" : 18613
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tietalk",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299594916844142592",
  "geo" : { },
  "id_str" : "299614133983252480",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Thanks so much for sharing the link to @gsiemens #tietalk presentation - very informative and thought-provoking talk!",
  "id" : 299614133983252480,
  "in_reply_to_status_id" : 299594916844142592,
  "created_at" : "2013-02-07 20:22:30 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/WkDZsYOk",
      "expanded_url" : "http:\/\/www.androidauthority.com\/chromebook-pixel-video-154370\/",
      "display_url" : "androidauthority.com\/chromebook-pix\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299318547606278144",
  "text" : "RT @lukew Looks like touch is coming to Google Chromebooks: http:\/\/t.co\/WkDZsYOk &lt;- Makes me wonder when touchscreens are coming to the Mac",
  "id" : 299318547606278144,
  "created_at" : "2013-02-07 00:47:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dennis kardys",
      "screen_name" : "dkardys",
      "indices" : [ 3, 11 ],
      "id_str" : "18728007",
      "id" : 18728007
    }, {
      "name" : "Beyond The Desktop",
      "screen_name" : "bdconf",
      "indices" : [ 107, 114 ],
      "id_str" : "207529197",
      "id" : 207529197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/V59Z8fby",
      "expanded_url" : "http:\/\/Time.com",
      "display_url" : "Time.com"
    }, {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/7LEPFG8z",
      "expanded_url" : "http:\/\/www.magazine.org\/timecom-gm-craig-ettinger-bringing-responsive-web-design-iconic-brand",
      "display_url" : "magazine.org\/timecom-gm-cra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299297553546096641",
  "text" : "RT @dkardys: http:\/\/t.co\/V59Z8fby describes the process of going responsive, and how they were inspired by @bdconf: http:\/\/t.co\/7LEPFG8z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Beyond The Desktop",
        "screen_name" : "bdconf",
        "indices" : [ 94, 101 ],
        "id_str" : "207529197",
        "id" : 207529197
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/V59Z8fby",
        "expanded_url" : "http:\/\/Time.com",
        "display_url" : "Time.com"
      }, {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/7LEPFG8z",
        "expanded_url" : "http:\/\/www.magazine.org\/timecom-gm-craig-ettinger-bringing-responsive-web-design-iconic-brand",
        "display_url" : "magazine.org\/timecom-gm-cra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "298303985989857281",
    "text" : "http:\/\/t.co\/V59Z8fby describes the process of going responsive, and how they were inspired by @bdconf: http:\/\/t.co\/7LEPFG8z",
    "id" : 298303985989857281,
    "created_at" : "2013-02-04 05:36:27 +0000",
    "user" : {
      "name" : "dennis kardys",
      "screen_name" : "dkardys",
      "protected" : false,
      "id_str" : "18728007",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1181046858\/avatar_dkardys_normal.jpg",
      "id" : 18728007,
      "verified" : false
    }
  },
  "id" : 299297553546096641,
  "created_at" : "2013-02-06 23:24:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetroapp.com\" rel=\"nofollow\"\u003ETweetro+ for Windows 8\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Fahey",
      "screen_name" : "chrisfahey",
      "indices" : [ 3, 14 ],
      "id_str" : "974131",
      "id" : 974131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298892837309788160",
  "text" : "RT @chrisfahey: Today's discussion: Microinteraction design is basically old school UI design, and proud of it. UX without the all-encom ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298887753351974912",
    "text" : "Today's discussion: Microinteraction design is basically old school UI design, and proud of it. UX without the all-encompassing grandiosity.",
    "id" : 298887753351974912,
    "created_at" : "2013-02-05 20:16:08 +0000",
    "user" : {
      "name" : "Christopher Fahey",
      "screen_name" : "chrisfahey",
      "protected" : false,
      "id_str" : "974131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000686149203\/18da62da12c004d491cdc36127150529_normal.jpeg",
      "id" : 974131,
      "verified" : false
    }
  },
  "id" : 298892837309788160,
  "created_at" : "2013-02-05 20:36:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 3, 7 ],
      "id_str" : "1063291",
      "id" : 1063291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/ByuljD7R",
      "expanded_url" : "http:\/\/ar.gy\/3K50",
      "display_url" : "ar.gy\/3K50"
    } ]
  },
  "geo" : { },
  "id_str" : "298603125693095936",
  "text" : "RT @UIE: When responsive design doesn't work. One company's rationale to why they ditched it. http:\/\/t.co\/ByuljD7R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/reach.me\" rel=\"nofollow\"\u003EReach.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/ByuljD7R",
        "expanded_url" : "http:\/\/ar.gy\/3K50",
        "display_url" : "ar.gy\/3K50"
      } ]
    },
    "geo" : { },
    "id_str" : "298597106476781568",
    "text" : "When responsive design doesn't work. One company's rationale to why they ditched it. http:\/\/t.co\/ByuljD7R",
    "id" : 298597106476781568,
    "created_at" : "2013-02-05 01:01:12 +0000",
    "user" : {
      "name" : "UIE",
      "screen_name" : "UIE",
      "protected" : false,
      "id_str" : "1063291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3759116326\/19308cfcdb0b831111d4ee3fc3e6232c_normal.jpeg",
      "id" : 1063291,
      "verified" : false
    }
  },
  "id" : 298603125693095936,
  "created_at" : "2013-02-05 01:25:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eLearning Learning",
      "screen_name" : "elearningPosts",
      "indices" : [ 3, 18 ],
      "id_str" : "31521133",
      "id" : 31521133
    }, {
      "name" : "Stephen J. Gill",
      "screen_name" : "sjgill",
      "indices" : [ 75, 82 ],
      "id_str" : "20411290",
      "id" : 20411290
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elearning",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/vA33nJhH",
      "expanded_url" : "http:\/\/bit.ly\/Wq2Ei2",
      "display_url" : "bit.ly\/Wq2Ei2"
    } ]
  },
  "geo" : { },
  "id_str" : "298561672812040192",
  "text" : "RT @elearningPosts: Hyper-Connectivity: Get Used To It! Educate for It! by @sjgill Weekly Best in #elearning http:\/\/t.co\/vA33nJhH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen J. Gill",
        "screen_name" : "sjgill",
        "indices" : [ 55, 62 ],
        "id_str" : "20411290",
        "id" : 20411290
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elearning",
        "indices" : [ 78, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/vA33nJhH",
        "expanded_url" : "http:\/\/bit.ly\/Wq2Ei2",
        "display_url" : "bit.ly\/Wq2Ei2"
      } ]
    },
    "geo" : { },
    "id_str" : "298555876564926464",
    "text" : "Hyper-Connectivity: Get Used To It! Educate for It! by @sjgill Weekly Best in #elearning http:\/\/t.co\/vA33nJhH",
    "id" : 298555876564926464,
    "created_at" : "2013-02-04 22:17:22 +0000",
    "user" : {
      "name" : "eLearning Learning",
      "screen_name" : "elearningPosts",
      "protected" : false,
      "id_str" : "31521133",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755849131982073860\/r3MdXSlP_normal.jpg",
      "id" : 31521133,
      "verified" : false
    }
  },
  "id" : 298561672812040192,
  "created_at" : "2013-02-04 22:40:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 0, 11 ],
      "id_str" : "28429477",
      "id" : 28429477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "canadamoot",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298477193636478976",
  "in_reply_to_user_id" : 28429477,
  "text" : "@chadleaman Thanks for the RT! Hope to get a chance to chat with you at #canadamoot.",
  "id" : 298477193636478976,
  "created_at" : "2013-02-04 17:04:43 +0000",
  "in_reply_to_screen_name" : "chadleaman",
  "in_reply_to_user_id_str" : "28429477",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Canada Moodle Moot",
      "screen_name" : "canadamoot",
      "indices" : [ 0, 11 ],
      "id_str" : "22040608",
      "id" : 22040608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298089332454088706",
  "geo" : { },
  "id_str" : "298475331218718721",
  "in_reply_to_user_id" : 22040608,
  "text" : "@canadamoot Many thanks for the MT, much appreciated.",
  "id" : 298475331218718721,
  "in_reply_to_status_id" : 298089332454088706,
  "created_at" : "2013-02-04 16:57:19 +0000",
  "in_reply_to_screen_name" : "canadamoot",
  "in_reply_to_user_id_str" : "22040608",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Buxton",
      "screen_name" : "wasbuxton",
      "indices" : [ 3, 13 ],
      "id_str" : "57046779",
      "id" : 57046779
    }, {
      "name" : "Cooper Hewitt",
      "screen_name" : "cooperhewitt",
      "indices" : [ 67, 80 ],
      "id_str" : "17518626",
      "id" : 17518626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "billmoggridge",
      "indices" : [ 38, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/a6pdmY4L",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Atsmy_oMLaI&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=Atsmy_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297450700479287297",
  "text" : "RT @wasbuxton: To view the tribute to #billmoggridge  organized by @cooperhewitt: http:\/\/t.co\/a6pdmY4L Hopefully fitting for such a beli ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cooper Hewitt",
        "screen_name" : "cooperhewitt",
        "indices" : [ 52, 65 ],
        "id_str" : "17518626",
        "id" : 17518626
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "billmoggridge",
        "indices" : [ 23, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/a6pdmY4L",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Atsmy_oMLaI&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=Atsmy_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "297447143080333312",
    "text" : "To view the tribute to #billmoggridge  organized by @cooperhewitt: http:\/\/t.co\/a6pdmY4L Hopefully fitting for such a believer in stories",
    "id" : 297447143080333312,
    "created_at" : "2013-02-01 20:51:39 +0000",
    "user" : {
      "name" : "Bill Buxton",
      "screen_name" : "wasbuxton",
      "protected" : false,
      "id_str" : "57046779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1295268556\/Bill_TN_normal.jpg",
      "id" : 57046779,
      "verified" : false
    }
  },
  "id" : 297450700479287297,
  "created_at" : "2013-02-01 21:05:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]