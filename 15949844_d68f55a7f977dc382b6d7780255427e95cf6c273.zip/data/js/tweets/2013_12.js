Grailbird.data.tweets_2013_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/4AG2ckmqJJ",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/067b6c39-5ce0-b223-aa77-37eb0fabcbc9\/",
      "display_url" : "workflowy.com\/shared\/067b6c3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417809103772078080",
  "text" : "Looking forward to 2014 for many reasons, including launching my new course on multi-device learning experiences: https:\/\/t.co\/4AG2ckmqJJ",
  "id" : 417809103772078080,
  "created_at" : "2013-12-31 00:07:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417802257900380160",
  "text" : "Let\u2019s also ditch \u201Cmobile learning\u201D, and think more about \u201Cmulti-device learning\u201D, described as:\n\nUbiquitous\nSituational\nConnected\nPersonal",
  "id" : 417802257900380160,
  "created_at" : "2013-12-30 23:39:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zoe Shakespeare ",
      "screen_name" : "ZShakespeare",
      "indices" : [ 0, 13 ],
      "id_str" : "2618423705",
      "id" : 2618423705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417798899231756288",
  "geo" : { },
  "id_str" : "417799581296889856",
  "in_reply_to_user_id" : 167111234,
  "text" : "@ZShakespeare For sure, it is time for full content and feature parity. \u201CDesktop Version\u201D link should be outlawed (not needed with parity).",
  "id" : 417799581296889856,
  "in_reply_to_status_id" : 417798899231756288,
  "created_at" : "2013-12-30 23:29:17 +0000",
  "in_reply_to_screen_name" : "BJOlaney",
  "in_reply_to_user_id_str" : "167111234",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417798070638628864",
  "text" : "Is this a starter set of multi-device experience design principles?\n\nContent Parity\nConsistency\nTask Transferability\nOptimized Interactions",
  "id" : 417798070638628864,
  "created_at" : "2013-12-30 23:23:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417795886849064960",
  "text" : "In 2013 I found using \u201Cmobile\u201D as a prefix for most things became meaningless. I prefer the term \u201Cmulti-device\u201D and not context guessing.",
  "id" : 417795886849064960,
  "created_at" : "2013-12-30 23:14:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzanne",
      "screen_name" : "suzanneginsburg",
      "indices" : [ 0, 16 ],
      "id_str" : "21534965",
      "id" : 21534965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/Zh6FZ1YZ5k",
      "expanded_url" : "http:\/\/www.razorfishhealthware.com\/en\/geekhealth\/geekhealth\/detail\/0\/430\/1635\/responsive-website-native-apps-or-what.html",
      "display_url" : "razorfishhealthware.com\/en\/geekhealth\/\u2026"
    }, {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/OvABVkRFlT",
      "expanded_url" : "http:\/\/designmind.frogdesign.com\/blog\/unraveling-html5-vs-native.html",
      "display_url" : "designmind.frogdesign.com\/blog\/unravelin\u2026"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/DQbRmH0Cfg",
      "expanded_url" : "http:\/\/cmpt-363-133.hibbittsdesign.com\/ux-techniques-guide\/",
      "display_url" : "cmpt-363-133.hibbittsdesign.com\/ux-techniques-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "416326808674373632",
  "geo" : { },
  "id_str" : "416334637187608576",
  "in_reply_to_user_id" : 21534965,
  "text" : "@suzanneginsburg http:\/\/t.co\/Zh6FZ1YZ5k http:\/\/t.co\/OvABVkRFlT Might be items of interest on my recent course site: http:\/\/t.co\/DQbRmH0Cfg",
  "id" : 416334637187608576,
  "in_reply_to_status_id" : 416326808674373632,
  "created_at" : "2013-12-26 22:28:07 +0000",
  "in_reply_to_screen_name" : "suzanneginsburg",
  "in_reply_to_user_id_str" : "21534965",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerry Canavan",
      "screen_name" : "gerrycanavan",
      "indices" : [ 3, 16 ],
      "id_str" : "18048935",
      "id" : 18048935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "415704539119906816",
  "text" : "RT @gerrycanavan: Tonight, you will be visited by three adjunct professors\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "415685403094441985",
    "text" : "Tonight, you will be visited by three adjunct professors\u2026",
    "id" : 415685403094441985,
    "created_at" : "2013-12-25 03:28:17 +0000",
    "user" : {
      "name" : "Gerry Canavan",
      "screen_name" : "gerrycanavan",
      "protected" : false,
      "id_str" : "18048935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000652967824\/150d4bc6484b192259cffdcb2cb8806a_normal.jpeg",
      "id" : 18048935,
      "verified" : false
    }
  },
  "id" : 415704539119906816,
  "created_at" : "2013-12-25 04:44:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MWC_Barcelona",
      "screen_name" : "MWC_Barcelona",
      "indices" : [ 3, 17 ],
      "id_str" : "729941541284921344",
      "id" : 729941541284921344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/Tfq1ImaDg8",
      "expanded_url" : "http:\/\/mwcb.at\/1htHzwv",
      "display_url" : "mwcb.at\/1htHzwv"
    } ]
  },
  "geo" : { },
  "id_str" : "414151389606969344",
  "text" : "RT @MWC_Barcelona: Welcome to the Multi-Screen World: a different device for every moment of the day http:\/\/t.co\/Tfq1ImaDg8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/Tfq1ImaDg8",
        "expanded_url" : "http:\/\/mwcb.at\/1htHzwv",
        "display_url" : "mwcb.at\/1htHzwv"
      } ]
    },
    "geo" : { },
    "id_str" : "414087253216858114",
    "text" : "Welcome to the Multi-Screen World: a different device for every moment of the day http:\/\/t.co\/Tfq1ImaDg8",
    "id" : 414087253216858114,
    "created_at" : "2013-12-20 17:37:49 +0000",
    "user" : {
      "name" : "Mobile World Capital",
      "screen_name" : "MWCapital",
      "protected" : false,
      "id_str" : "504299333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729952993450172420\/BozwEbMj_normal.jpg",
      "id" : 504299333,
      "verified" : false
    }
  },
  "id" : 414151389606969344,
  "created_at" : "2013-12-20 21:52:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/MsMIzfxE3I",
      "expanded_url" : "http:\/\/thecontentwrangler.com\/2006\/11\/14\/designing_for_the_small_screen_interview_with_paul_hibbitts\/",
      "display_url" : "thecontentwrangler.com\/2006\/11\/14\/des\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413815897321521152",
  "text" : "Some of my thoughts on designing for small screens, circa 2006 http:\/\/t.co\/MsMIzfxE3I Small Screens, Big Lessons concept was formed in 2004.",
  "id" : 413815897321521152,
  "created_at" : "2013-12-19 23:39:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Spiglanin",
      "screen_name" : "tomspiglanin",
      "indices" : [ 3, 16 ],
      "id_str" : "190073838",
      "id" : 190073838
    }, {
      "name" : "Adam Weisblatt",
      "screen_name" : "weisblatt",
      "indices" : [ 78, 88 ],
      "id_str" : "17156081",
      "id" : 17156081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/LjzcRtMDjx",
      "expanded_url" : "http:\/\/wp.me\/s1gqj8-228",
      "display_url" : "wp.me\/s1gqj8-228"
    } ]
  },
  "geo" : { },
  "id_str" : "413519166587424769",
  "text" : "RT @tomspiglanin: Should Technology Drive Learning? http:\/\/t.co\/LjzcRtMDjx by @weisblatt &lt; Good read!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam Weisblatt",
        "screen_name" : "weisblatt",
        "indices" : [ 60, 70 ],
        "id_str" : "17156081",
        "id" : 17156081
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/LjzcRtMDjx",
        "expanded_url" : "http:\/\/wp.me\/s1gqj8-228",
        "display_url" : "wp.me\/s1gqj8-228"
      } ]
    },
    "geo" : { },
    "id_str" : "413409517624258560",
    "text" : "Should Technology Drive Learning? http:\/\/t.co\/LjzcRtMDjx by @weisblatt &lt; Good read!",
    "id" : 413409517624258560,
    "created_at" : "2013-12-18 20:44:44 +0000",
    "user" : {
      "name" : "Tom Spiglanin",
      "screen_name" : "tomspiglanin",
      "protected" : false,
      "id_str" : "190073838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1867952782\/image_normal.jpg",
      "id" : 190073838,
      "verified" : false
    }
  },
  "id" : 413519166587424769,
  "created_at" : "2013-12-19 04:00:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adebayo",
      "screen_name" : "iYarn",
      "indices" : [ 3, 9 ],
      "id_str" : "136109156",
      "id" : 136109156
    }, {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "indices" : [ 94, 106 ],
      "id_str" : "730373",
      "id" : 730373
    }, {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 134, 141 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/XlHIzr1v3N",
      "expanded_url" : "http:\/\/onforb.es\/1bSfVqx",
      "display_url" : "onforb.es\/1bSfVqx"
    } ]
  },
  "geo" : { },
  "id_str" : "412994149118251008",
  "text" : "RT @iYarn: Apple's iBeacon In approx 200 Million iPhones\/iPads &amp; interesting insight from @scottjenson http:\/\/t.co\/XlHIzr1v3N via @forbes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott JensOn",
        "screen_name" : "scottjenson",
        "indices" : [ 83, 95 ],
        "id_str" : "730373",
        "id" : 730373
      }, {
        "name" : "Forbes",
        "screen_name" : "Forbes",
        "indices" : [ 123, 130 ],
        "id_str" : "91478624",
        "id" : 91478624
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/XlHIzr1v3N",
        "expanded_url" : "http:\/\/onforb.es\/1bSfVqx",
        "display_url" : "onforb.es\/1bSfVqx"
      } ]
    },
    "geo" : { },
    "id_str" : "412691183358328832",
    "text" : "Apple's iBeacon In approx 200 Million iPhones\/iPads &amp; interesting insight from @scottjenson http:\/\/t.co\/XlHIzr1v3N via @forbes",
    "id" : 412691183358328832,
    "created_at" : "2013-12-16 21:10:20 +0000",
    "user" : {
      "name" : "Adebayo",
      "screen_name" : "iYarn",
      "protected" : false,
      "id_str" : "136109156",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000705671583\/160db0411b456de8c7663bb631c27fd0_normal.jpeg",
      "id" : 136109156,
      "verified" : false
    }
  },
  "id" : 412994149118251008,
  "created_at" : "2013-12-17 17:14:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 66, 78 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5UrOXnDu34",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/ca578766-e77b-3616-0d97-90026b671147\/",
      "display_url" : "workflowy.com\/shared\/ca57876\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412720602420506624",
  "text" : "Excited to be discussing multi-device design experiences with the @openroadies UX team tomorrow! Our menu of topics: https:\/\/t.co\/5UrOXnDu34",
  "id" : 412720602420506624,
  "created_at" : "2013-12-16 23:07:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dinah R Berch",
      "screen_name" : "NewMediaMaiden",
      "indices" : [ 3, 18 ],
      "id_str" : "134352367",
      "id" : 134352367
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aeasf",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410840990644047872",
  "text" : "RT @NewMediaMaiden: Multi-device design must: support continuum of screens, account for high resolution, optimize for touch &amp; support curso\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aeasf",
        "indices" : [ 138, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410826728496693248",
    "text" : "Multi-device design must: support continuum of screens, account for high resolution, optimize for touch &amp; support cursor and keyboard #aeasf",
    "id" : 410826728496693248,
    "created_at" : "2013-12-11 17:41:39 +0000",
    "user" : {
      "name" : "Dinah R Berch",
      "screen_name" : "NewMediaMaiden",
      "protected" : false,
      "id_str" : "134352367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2162419578\/10af051f-d865-462e-95c5-30e9df9b8dd0_normal.JPG",
      "id" : 134352367,
      "verified" : false
    }
  },
  "id" : 410840990644047872,
  "created_at" : "2013-12-11 18:38:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olark Live Chat",
      "screen_name" : "olark",
      "indices" : [ 0, 6 ],
      "id_str" : "21672965",
      "id" : 21672965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410544217245892609",
  "geo" : { },
  "id_str" : "410560676189335552",
  "in_reply_to_user_id" : 21672965,
  "text" : "@olark Sounds great, will do. And thanks again for the great Olark t-shirts!",
  "id" : 410560676189335552,
  "in_reply_to_status_id" : 410544217245892609,
  "created_at" : "2013-12-11 00:04:27 +0000",
  "in_reply_to_screen_name" : "olark",
  "in_reply_to_user_id_str" : "21672965",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olark Live Chat",
      "screen_name" : "olark",
      "indices" : [ 38, 44 ],
      "id_str" : "21672965",
      "id" : 21672965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/lKNWfvj1SO",
      "expanded_url" : "http:\/\/cmpt-363-133.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-133.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "410451917051924480",
  "text" : "Marking final exams in my awesome new @olark shirt. Appropriate, as live instructor chat was a student favorite for http:\/\/t.co\/lKNWfvj1SO",
  "id" : 410451917051924480,
  "created_at" : "2013-12-10 16:52:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410230649224577024",
  "text" : "When I see that a professor has a communications policy of \u201Cemergencies only\u201D my blood boils - your job is to be accessible to students!",
  "id" : 410230649224577024,
  "created_at" : "2013-12-10 02:13:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veronica Wong",
      "screen_name" : "supervee",
      "indices" : [ 3, 12 ],
      "id_str" : "13057162",
      "id" : 13057162
    }, {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 128, 134 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aeasf",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410188506418262016",
  "text" : "RT @supervee: Design for a multi-device web, but create a holistic experience by remembering what each device is best used for. @lukew #aea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Luke Wroblewski",
        "screen_name" : "lukew",
        "indices" : [ 114, 120 ],
        "id_str" : "13889622",
        "id" : 13889622
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aeasf",
        "indices" : [ 121, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410182732904284160",
    "text" : "Design for a multi-device web, but create a holistic experience by remembering what each device is best used for. @lukew #aeasf",
    "id" : 410182732904284160,
    "created_at" : "2013-12-09 23:02:39 +0000",
    "user" : {
      "name" : "Veronica Wong",
      "screen_name" : "supervee",
      "protected" : false,
      "id_str" : "13057162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763425312017440768\/xzABIMyF_normal.jpg",
      "id" : 13057162,
      "verified" : false
    }
  },
  "id" : 410188506418262016,
  "created_at" : "2013-12-09 23:25:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/asXtntOrnU",
      "expanded_url" : "http:\/\/news.cnet.com\/8301-1023_3-57614960-93\/google-doodle-honors-pioneer-programmer-grace-hopper\/",
      "display_url" : "news.cnet.com\/8301-1023_3-57\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410122034522632192",
  "text" : "I was fortunate to learn about Grace Hopper in high school, and still remember how she explained nanoseconds. http:\/\/t.co\/asXtntOrnU",
  "id" : 410122034522632192,
  "created_at" : "2013-12-09 19:01:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409090037507035136",
  "text" : "What makes a great class experience? My students say engaging, delightful, motivational and structured. Great goals for all of us who teach!",
  "id" : 409090037507035136,
  "created_at" : "2013-12-06 22:40:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Krug",
      "screen_name" : "skrug",
      "indices" : [ 3, 9 ],
      "id_str" : "18544024",
      "id" : 18544024
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/skrug\/status\/409079394204782592\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/xOR58GRrt9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba1XiqkCEAAN3q_.jpg",
      "id_str" : "409079394213171200",
      "id" : 409079394213171200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba1XiqkCEAAN3q_.jpg",
      "sizes" : [ {
        "h" : 349,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 924,
        "resize" : "fit",
        "w" : 1590
      }, {
        "h" : 595,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xOR58GRrt9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409087974140170240",
  "text" : "RT @skrug: Don't Make Me Think Revisited went to the printer 3:59 am thanks to some very nice  talented people. Whew! http:\/\/t.co\/xOR58GRrt9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/skrug\/status\/409079394204782592\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/xOR58GRrt9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba1XiqkCEAAN3q_.jpg",
        "id_str" : "409079394213171200",
        "id" : 409079394213171200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba1XiqkCEAAN3q_.jpg",
        "sizes" : [ {
          "h" : 349,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 924,
          "resize" : "fit",
          "w" : 1590
        }, {
          "h" : 595,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/xOR58GRrt9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409079394204782592",
    "text" : "Don't Make Me Think Revisited went to the printer 3:59 am thanks to some very nice  talented people. Whew! http:\/\/t.co\/xOR58GRrt9",
    "id" : 409079394204782592,
    "created_at" : "2013-12-06 21:58:22 +0000",
    "user" : {
      "name" : "Steve Krug",
      "screen_name" : "skrug",
      "protected" : false,
      "id_str" : "18544024",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477696849533362177\/Q4loFGmr_normal.jpeg",
      "id" : 18544024,
      "verified" : false
    }
  },
  "id" : 409087974140170240,
  "created_at" : "2013-12-06 22:32:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Infotrova Research",
      "screen_name" : "Infotrova",
      "indices" : [ 0, 10 ],
      "id_str" : "906612751",
      "id" : 906612751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408804752999600129",
  "geo" : { },
  "id_str" : "409069424973328384",
  "in_reply_to_user_id" : 906612751,
  "text" : "@Infotrova Thanks very much! Planning to offer the course in the Spring though UBC Continuing Studies at Robson Square (downtown Vancouver).",
  "id" : 409069424973328384,
  "in_reply_to_status_id" : 408804752999600129,
  "created_at" : "2013-12-06 21:18:45 +0000",
  "in_reply_to_screen_name" : "Infotrova",
  "in_reply_to_user_id_str" : "906612751",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmnestyInternational",
      "screen_name" : "amnesty",
      "indices" : [ 3, 11 ],
      "id_str" : "16153562",
      "id" : 16153562
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mandela",
      "indices" : [ 34, 42 ]
    }, {
      "text" : "HumanRights",
      "indices" : [ 65, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408723306850701312",
  "text" : "RT @amnesty: Rest in Peace Nelson #Mandela -- a true champion of #HumanRights.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Mandela",
        "indices" : [ 21, 29 ]
      }, {
        "text" : "HumanRights",
        "indices" : [ 52, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408716612758679552",
    "text" : "Rest in Peace Nelson #Mandela -- a true champion of #HumanRights.",
    "id" : 408716612758679552,
    "created_at" : "2013-12-05 21:56:48 +0000",
    "user" : {
      "name" : "AmnestyInternational",
      "screen_name" : "amnesty",
      "protected" : false,
      "id_str" : "16153562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503277927912329216\/niWJ1nYD_normal.jpeg",
      "id" : 16153562,
      "verified" : true
    }
  },
  "id" : 408723306850701312,
  "created_at" : "2013-12-05 22:23:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/4AG2ckmqJJ",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/067b6c39-5ce0-b223-aa77-37eb0fabcbc9\/",
      "display_url" : "workflowy.com\/shared\/067b6c3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408715549976195072",
  "text" : "Learning objectives &amp; concept inventory for Designing the Learner Experience for a Multi-device World - second draft https:\/\/t.co\/4AG2ckmqJJ",
  "id" : 408715549976195072,
  "created_at" : "2013-12-05 21:52:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 0, 12 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408684424314621952",
  "geo" : { },
  "id_str" : "408694455516930048",
  "in_reply_to_user_id" : 66913866,
  "text" : "@openroadies Big news, congratulations to all!",
  "id" : 408694455516930048,
  "in_reply_to_status_id" : 408684424314621952,
  "created_at" : "2013-12-05 20:28:46 +0000",
  "in_reply_to_screen_name" : "openroadies",
  "in_reply_to_user_id_str" : "66913866",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNET",
      "screen_name" : "CNET",
      "indices" : [ 68, 73 ],
      "id_str" : "30261067",
      "id" : 30261067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/rJo4B92jMn",
      "expanded_url" : "http:\/\/cnet.co\/1dOOCAO",
      "display_url" : "cnet.co\/1dOOCAO"
    } ]
  },
  "geo" : { },
  "id_str" : "408412026445115392",
  "text" : "Mobile Chrome Apps closer than you think http:\/\/t.co\/rJo4B92jMn via @CNET &lt;- Keep an eye on this one, it is the future... (almost) now!",
  "id" : 408412026445115392,
  "created_at" : "2013-12-05 01:46:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "effectiveui",
      "screen_name" : "effectiveui",
      "indices" : [ 3, 15 ],
      "id_str" : "14627322",
      "id" : 14627322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/9ixDKUfnw4",
      "expanded_url" : "http:\/\/ow.ly\/rqj3l",
      "display_url" : "ow.ly\/rqj3l"
    } ]
  },
  "geo" : { },
  "id_str" : "408367080954556417",
  "text" : "RT @effectiveui: Tablets will outship mobile PCs for the first time in 2013 http:\/\/t.co\/9ixDKUfnw4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/9ixDKUfnw4",
        "expanded_url" : "http:\/\/ow.ly\/rqj3l",
        "display_url" : "ow.ly\/rqj3l"
      } ]
    },
    "geo" : { },
    "id_str" : "408366447992537088",
    "text" : "Tablets will outship mobile PCs for the first time in 2013 http:\/\/t.co\/9ixDKUfnw4",
    "id" : 408366447992537088,
    "created_at" : "2013-12-04 22:45:22 +0000",
    "user" : {
      "name" : "effectiveui",
      "screen_name" : "effectiveui",
      "protected" : false,
      "id_str" : "14627322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760186329514803200\/np6gVDUY_normal.jpg",
      "id" : 14627322,
      "verified" : false
    }
  },
  "id" : 408367080954556417,
  "created_at" : "2013-12-04 22:47:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/4AG2ckmqJJ",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/067b6c39-5ce0-b223-aa77-37eb0fabcbc9\/",
      "display_url" : "workflowy.com\/shared\/067b6c3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407967232753299456",
  "text" : "Learning objectives &amp; concept inventory for my new course: Designing the Learner Experience for a Multi-device World https:\/\/t.co\/4AG2ckmqJJ",
  "id" : 407967232753299456,
  "created_at" : "2013-12-03 20:19:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]