Grailbird.data.tweets_2009_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1992627844",
  "text" : "Adobe Flash Catalyst Public Beta is now available at http:\/\/is.gd\/LBeg \u2013 will reality match expectations?",
  "id" : 1992627844,
  "created_at" : "2009-06-01 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1925407374",
  "text" : "While not overly elegant, Office Live Workspace provides a surprisingly client friendly PowerPoint\u2013based collaborative prototyping solution",
  "id" : 1925407374,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter",
      "screen_name" : "JP_marketing",
      "indices" : [ 0, 13 ],
      "id_str" : "42438567",
      "id" : 42438567
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustProto",
      "indices" : [ 47, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1914290947",
  "geo" : { },
  "id_str" : "1914450501",
  "in_reply_to_user_id" : 42438567,
  "text" : "@JP_marketing Thanks for letting me know about #JustProto, I will check it out",
  "id" : 1914450501,
  "in_reply_to_status_id" : 1914290947,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "JP_marketing",
  "in_reply_to_user_id_str" : "42438567",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iPlotz",
      "indices" : [ 35, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1865366995",
  "text" : "Good product feedback session with #iPlotz \u2013 looking forward to seeing how the product develops.",
  "id" : 1865366995,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DocVerse",
      "indices" : [ 10, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1851627177",
  "text" : "Exploring #DocVerse to support collaborative prototyping with teams using PowerPoint http:\/\/www.docverse.com\/",
  "id" : 1851627177,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iPlotz",
      "indices" : [ 5, 12 ]
    }, {
      "text" : "ProtoShare",
      "indices" : [ 17, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1851704376",
  "text" : "Both #iPlotz and #ProtoShare look very promising for collaborative prototyping, but not quite ready for mission-critical work with clients",
  "id" : 1851704376,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iplotz",
      "screen_name" : "iplotz",
      "indices" : [ 0, 7 ],
      "id_str" : "18956461",
      "id" : 18956461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1852785412",
  "geo" : { },
  "id_str" : "1852935699",
  "in_reply_to_user_id" : 18956461,
  "text" : "@iplotz Thanks for reaching out. Happy to further discuss, let me know if you prefer email or IM",
  "id" : 1852935699,
  "in_reply_to_status_id" : 1852785412,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "iplotz",
  "in_reply_to_user_id_str" : "18956461",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1708215551",
  "text" : "Doodle: Easy Scheduling http:\/\/tinyurl.com\/55ep2x via www.diigo.com\/~paulhibbitts",
  "id" : 1708215551,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]