Grailbird.data.tweets_2016_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/aKEG1fPrrZ",
      "expanded_url" : "http:\/\/osleproject.org",
      "display_url" : "osleproject.org"
    } ]
  },
  "in_reply_to_status_id_str" : "726187719664095232",
  "geo" : { },
  "id_str" : "726191003623772160",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde I've settled on using Open [Source] Learning Environments Project for my own work in this area https:\/\/t.co\/aKEG1fPrrZ \uD83D\uDE42",
  "id" : 726191003623772160,
  "in_reply_to_status_id" : 726187719664095232,
  "created_at" : "2016-04-29 23:26:41 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726188395471347713",
  "geo" : { },
  "id_str" : "726190632520192000",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Definitely!",
  "id" : 726190632520192000,
  "in_reply_to_status_id" : 726188395471347713,
  "created_at" : "2016-04-29 23:25:13 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CMS Critic",
      "screen_name" : "cmscritic",
      "indices" : [ 3, 13 ],
      "id_str" : "16147963",
      "id" : 16147963
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 48, 56 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/wjRaFLGK8E",
      "expanded_url" : "https:\/\/www.cmscritic.com\/getting-to-grips-with-grav\/",
      "display_url" : "cmscritic.com\/getting-to-gri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726166693114859520",
  "text" : "RT @cmscritic: We've been getting familiar with @GetGrav, an exciting, free, open source, and flat-file CMS\n\nhttps:\/\/t.co\/wjRaFLGK8E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 33, 41 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/wjRaFLGK8E",
        "expanded_url" : "https:\/\/www.cmscritic.com\/getting-to-grips-with-grav\/",
        "display_url" : "cmscritic.com\/getting-to-gri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "726139850160754689",
    "text" : "We've been getting familiar with @GetGrav, an exciting, free, open source, and flat-file CMS\n\nhttps:\/\/t.co\/wjRaFLGK8E",
    "id" : 726139850160754689,
    "created_at" : "2016-04-29 20:03:25 +0000",
    "user" : {
      "name" : "CMS Critic",
      "screen_name" : "cmscritic",
      "protected" : false,
      "id_str" : "16147963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650486867448737792\/VgUfaW4N_normal.png",
      "id" : 16147963,
      "verified" : false
    }
  },
  "id" : 726166693114859520,
  "created_at" : "2016-04-29 21:50:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NGDLE",
      "indices" : [ 40, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726146675899670528",
  "text" : "There's nothing really 'Next Gen' about #NGDLE - it is here, now, and multiple elements are being realized. Thoughts, my fellow educators?",
  "id" : 726146675899670528,
  "created_at" : "2016-04-29 20:30:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726143931361202180",
  "text" : "A flipped LMS approach empowers instructors with an open + collaborative platform while still using the existing institutional LMS. #GravEdu",
  "id" : 726143931361202180,
  "created_at" : "2016-04-29 20:19:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 99, 107 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 108, 115 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/2dUoaYrX0U",
      "expanded_url" : "https:\/\/workflowy.com\/s\/3FLodoor9P",
      "display_url" : "workflowy.com\/s\/3FLodoor9P"
    } ]
  },
  "geo" : { },
  "id_str" : "726141718806958080",
  "text" : "Outline of my part in 'Emerging Next Generation Digital Learning Environments' #apereo16 talk with @drchuck @btopro https:\/\/t.co\/2dUoaYrX0U",
  "id" : 726141718806958080,
  "created_at" : "2016-04-29 20:10:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/tv9q3n8Pxr",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/",
      "display_url" : "hibbittsdesign.org\/blog\/"
    } ]
  },
  "geo" : { },
  "id_str" : "726083813336440832",
  "text" : "My Open [Source] Learning Environments Project milestones so far:\n\u2705 Flipped-LMS approach\n\u2705 Grav Course Hub 1.0\nhttps:\/\/t.co\/tv9q3n8Pxr",
  "id" : 726083813336440832,
  "created_at" : "2016-04-29 16:20:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Korman",
      "screen_name" : "miniver",
      "indices" : [ 3, 11 ],
      "id_str" : "822441",
      "id" : 822441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726055084799352832",
  "text" : "RT @miniver: Adding UX designers to your organization without changing your development process will not give your products a good user exp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "726050964382183425",
    "text" : "Adding UX designers to your organization without changing your development process will not give your products a good user experience",
    "id" : 726050964382183425,
    "created_at" : "2016-04-29 14:10:13 +0000",
    "user" : {
      "name" : "Jonathan Korman",
      "screen_name" : "miniver",
      "protected" : false,
      "id_str" : "822441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750157227940392960\/vB7d5cM2_normal.jpg",
      "id" : 822441,
      "verified" : false
    }
  },
  "id" : 726055084799352832,
  "created_at" : "2016-04-29 14:26:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heath Ray Davis",
      "screen_name" : "Heath_Bears",
      "indices" : [ 3, 15 ],
      "id_str" : "15781859",
      "id" : 15781859
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elifocus",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ObygjRf4hg",
      "expanded_url" : "https:\/\/storify.com\/hrdavis\/day-two-next-generation-digital-learning-environme",
      "display_url" : "storify.com\/hrdavis\/day-tw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725827769607802880",
  "text" : "RT @Heath_Bears: Another rough Storify for day 2 of #elifocus session today: https:\/\/t.co\/ObygjRf4hg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elifocus",
        "indices" : [ 35, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/ObygjRf4hg",
        "expanded_url" : "https:\/\/storify.com\/hrdavis\/day-two-next-generation-digital-learning-environme",
        "display_url" : "storify.com\/hrdavis\/day-tw\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "725815767824920576",
    "text" : "Another rough Storify for day 2 of #elifocus session today: https:\/\/t.co\/ObygjRf4hg",
    "id" : 725815767824920576,
    "created_at" : "2016-04-28 22:35:38 +0000",
    "user" : {
      "name" : "Heath Ray Davis",
      "screen_name" : "Heath_Bears",
      "protected" : false,
      "id_str" : "15781859",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519644895871373313\/GI3iZUCA_normal.jpeg",
      "id" : 15781859,
      "verified" : false
    }
  },
  "id" : 725827769607802880,
  "created_at" : "2016-04-28 23:23:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/EoFrTkolPk",
      "expanded_url" : "https:\/\/twitter.com\/PhilOnEdTech\/status\/725756791443886080",
      "display_url" : "twitter.com\/PhilOnEdTech\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725759883010805761",
  "text" : "Interestingly, my Grav Course Hub does this: 'Content is to be authored in a shared space with the concept of reuse' https:\/\/t.co\/EoFrTkolPk",
  "id" : 725759883010805761,
  "created_at" : "2016-04-28 18:53:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 138, 139 ],
      "id_str" : "236846178",
      "id" : 236846178
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELIfocus",
      "indices" : [ 12, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725734548147965952",
  "text" : "RT @btopro: #ELIfocus This part is spot on. Built API \/ Mobile \/ distributed tools 1st. Its the principles we\u2019re building our ecosystem on\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ELMS:LN",
        "screen_name" : "elmsln",
        "indices" : [ 127, 134 ],
        "id_str" : "236846178",
        "id" : 236846178
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELIfocus",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725734408016125952",
    "text" : "#ELIfocus This part is spot on. Built API \/ Mobile \/ distributed tools 1st. Its the principles we\u2019re building our ecosystem on @elmsln",
    "id" : 725734408016125952,
    "created_at" : "2016-04-28 17:12:21 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 725734548147965952,
  "created_at" : "2016-04-28 17:12:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELIfocus",
      "indices" : [ 12, 21 ]
    }, {
      "text" : "ngdle",
      "indices" : [ 39, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725733160567357440",
  "text" : "RT @btopro: #ELIfocus LMS is dying and #ngdle is just recognition of that. these \u201Cgrowing years\u201D will see many abandon poor UX solutions",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELIfocus",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "ngdle",
        "indices" : [ 27, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725733047211974656",
    "text" : "#ELIfocus LMS is dying and #ngdle is just recognition of that. these \u201Cgrowing years\u201D will see many abandon poor UX solutions",
    "id" : 725733047211974656,
    "created_at" : "2016-04-28 17:06:56 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 725733160567357440,
  "created_at" : "2016-04-28 17:07:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 4, 12 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elifocus",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/VgQsw7tjdE",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725730293982879745",
  "text" : "The @getgrav Course Hub is one example where ALL course participants can shape their online learning space https:\/\/t.co\/VgQsw7tjdE #elifocus",
  "id" : 725730293982879745,
  "created_at" : "2016-04-28 16:56:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elifocus",
      "indices" : [ 134, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725727900016762883",
  "text" : "By using an open &amp; collaborative platform as an alternative front-end to the LMS you can pick and choose the best aspects of both #elifocus",
  "id" : 725727900016762883,
  "created_at" : "2016-04-28 16:46:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELIfocus",
      "indices" : [ 12, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725726871946706945",
  "text" : "RT @btopro: #ELIfocus future LMS: An LTI and REST capable Router. No garbed, no roster, no email, nothing. A place to go and find the link\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELIfocus",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725725673877164032",
    "text" : "#ELIfocus future LMS: An LTI and REST capable Router. No garbed, no roster, no email, nothing. A place to go and find the link to the space",
    "id" : 725725673877164032,
    "created_at" : "2016-04-28 16:37:38 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 725726871946706945,
  "created_at" : "2016-04-28 16:42:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725723634493349888",
  "geo" : { },
  "id_str" : "725726374229626880",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro First time I've seen those two words used in the same sentence \uD83D\uDE09",
  "id" : 725726374229626880,
  "in_reply_to_status_id" : 725723634493349888,
  "created_at" : "2016-04-28 16:40:25 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ajit kumar",
      "screen_name" : "urwithajit9",
      "indices" : [ 3, 15 ],
      "id_str" : "184152427",
      "id" : 184152427
    }, {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 17, 25 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Stack Overflow",
      "screen_name" : "StackOverflow",
      "indices" : [ 26, 40 ],
      "id_str" : "128700677",
      "id" : 128700677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725645699510067201",
  "text" : "RT @urwithajit9: @drchuck @StackOverflow Online learning is pure form of learning where learner have to self determinate for learning..a ch\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "drchuck",
        "screen_name" : "drchuck",
        "indices" : [ 0, 8 ],
        "id_str" : "10185562",
        "id" : 10185562
      }, {
        "name" : "Stack Overflow",
        "screen_name" : "StackOverflow",
        "indices" : [ 9, 23 ],
        "id_str" : "128700677",
        "id" : 128700677
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "725174129654161408",
    "geo" : { },
    "id_str" : "725356848363102209",
    "in_reply_to_user_id" : 10185562,
    "text" : "@drchuck @StackOverflow Online learning is pure form of learning where learner have to self determinate for learning..a cheater can't learn",
    "id" : 725356848363102209,
    "in_reply_to_status_id" : 725174129654161408,
    "created_at" : "2016-04-27 16:12:03 +0000",
    "in_reply_to_screen_name" : "drchuck",
    "in_reply_to_user_id_str" : "10185562",
    "user" : {
      "name" : "Ajit kumar",
      "screen_name" : "urwithajit9",
      "protected" : false,
      "id_str" : "184152427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1438251095\/ajit_normal.JPG",
      "id" : 184152427,
      "verified" : false
    }
  },
  "id" : 725645699510067201,
  "created_at" : "2016-04-28 11:19:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "indices" : [ 3, 12 ],
      "id_str" : "18613",
      "id" : 18613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/rbWDkhSkmi",
      "expanded_url" : "https:\/\/twitter.com\/philkomarny\/status\/725491173658365953",
      "display_url" : "twitter.com\/philkomarny\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725493499425083393",
  "text" : "RT @gsiemens: But why move from an open system to one that is closed? https:\/\/t.co\/rbWDkhSkmi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/rbWDkhSkmi",
        "expanded_url" : "https:\/\/twitter.com\/philkomarny\/status\/725491173658365953",
        "display_url" : "twitter.com\/philkomarny\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "725491685266837506",
    "text" : "But why move from an open system to one that is closed? https:\/\/t.co\/rbWDkhSkmi",
    "id" : 725491685266837506,
    "created_at" : "2016-04-28 01:07:51 +0000",
    "user" : {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "protected" : false,
      "id_str" : "18613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451036825637761025\/7_0RawE8_normal.jpeg",
      "id" : 18613,
      "verified" : false
    }
  },
  "id" : 725493499425083393,
  "created_at" : "2016-04-28 01:15:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/Vk0zUiX9Z9",
      "expanded_url" : "https:\/\/getgrav.org\/downloads",
      "display_url" : "getgrav.org\/downloads"
    } ]
  },
  "geo" : { },
  "id_str" : "725483293957865472",
  "text" : "RT @getgrav: Grav 1.1.0-beta.2 and Admin Plugin 1.1.0-beta.2 released.  You can help improve Grav by testing. Cheers!\n\nhttps:\/\/t.co\/Vk0zUiX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/Vk0zUiX9Z9",
        "expanded_url" : "https:\/\/getgrav.org\/downloads",
        "display_url" : "getgrav.org\/downloads"
      } ]
    },
    "geo" : { },
    "id_str" : "725475377540288512",
    "text" : "Grav 1.1.0-beta.2 and Admin Plugin 1.1.0-beta.2 released.  You can help improve Grav by testing. Cheers!\n\nhttps:\/\/t.co\/Vk0zUiX9Z9",
    "id" : 725475377540288512,
    "created_at" : "2016-04-28 00:03:03 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 725483293957865472,
  "created_at" : "2016-04-28 00:34:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725473338684919808",
  "text" : "If you are building a digital learning environment in 2016 that does not leverage version control you are already behind the curve. #GravEdu",
  "id" : 725473338684919808,
  "created_at" : "2016-04-27 23:54:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725467374191779840",
  "text" : "A flipped-LMS setup using the Grav Course Hub results in a development + production server so site changes can be tested before deployment.\uD83D\uDC4D",
  "id" : 725467374191779840,
  "created_at" : "2016-04-27 23:31:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 13, 28 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725404921697284097",
  "text" : "RT @btopro: .@hibbittsdesign is the future of the LMS \u2014 largely not having one. When you realize this, your budgets increase by not spendin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 1, 16 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725388364648689665",
    "text" : ".@hibbittsdesign is the future of the LMS \u2014 largely not having one. When you realize this, your budgets increase by not spending ;)",
    "id" : 725388364648689665,
    "created_at" : "2016-04-27 18:17:17 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 725404921697284097,
  "created_at" : "2016-04-27 19:23:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Cloudways",
      "screen_name" : "Cloudways",
      "indices" : [ 99, 109 ],
      "id_str" : "285598870",
      "id" : 285598870
    }, {
      "name" : "Team RocketTheme",
      "screen_name" : "rockettheme",
      "indices" : [ 110, 122 ],
      "id_str" : "18314250",
      "id" : 18314250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/vwQVNKvcfP",
      "expanded_url" : "http:\/\/www.cloudways.com\/blog\/interview-andy-miller\/",
      "display_url" : "cloudways.com\/blog\/interview\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725343879260692480",
  "text" : "RT @getgrav: New interview with Andy Miller - the originator of Grav CMS - https:\/\/t.co\/vwQVNKvcfP @cloudways @rockettheme",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cloudways",
        "screen_name" : "Cloudways",
        "indices" : [ 86, 96 ],
        "id_str" : "285598870",
        "id" : 285598870
      }, {
        "name" : "Team RocketTheme",
        "screen_name" : "rockettheme",
        "indices" : [ 97, 109 ],
        "id_str" : "18314250",
        "id" : 18314250
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/vwQVNKvcfP",
        "expanded_url" : "http:\/\/www.cloudways.com\/blog\/interview-andy-miller\/",
        "display_url" : "cloudways.com\/blog\/interview\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "725039542835650561",
    "text" : "New interview with Andy Miller - the originator of Grav CMS - https:\/\/t.co\/vwQVNKvcfP @cloudways @rockettheme",
    "id" : 725039542835650561,
    "created_at" : "2016-04-26 19:11:12 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 725343879260692480,
  "created_at" : "2016-04-27 15:20:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Travis",
      "screen_name" : "userfocus",
      "indices" : [ 3, 13 ],
      "id_str" : "16509110",
      "id" : 16509110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/TRKSEtVpP1",
      "expanded_url" : "http:\/\/bit.ly\/1Sza6k8",
      "display_url" : "bit.ly\/1Sza6k8"
    } ]
  },
  "geo" : { },
  "id_str" : "725341968088326145",
  "text" : "RT @userfocus: My God-Awful Year With the Apple  Watch https:\/\/t.co\/TRKSEtVpP1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/TRKSEtVpP1",
        "expanded_url" : "http:\/\/bit.ly\/1Sza6k8",
        "display_url" : "bit.ly\/1Sza6k8"
      } ]
    },
    "geo" : { },
    "id_str" : "725340328585236480",
    "text" : "My God-Awful Year With the Apple  Watch https:\/\/t.co\/TRKSEtVpP1",
    "id" : 725340328585236480,
    "created_at" : "2016-04-27 15:06:25 +0000",
    "user" : {
      "name" : "David Travis",
      "screen_name" : "userfocus",
      "protected" : false,
      "id_str" : "16509110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748776721\/Userfocus_blurry_o_normal.png",
      "id" : 16509110,
      "verified" : false
    }
  },
  "id" : 725341968088326145,
  "created_at" : "2016-04-27 15:12:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 50, 57 ],
      "id_str" : "236846178",
      "id" : 236846178
    }, {
      "name" : "H5P",
      "screen_name" : "H5PTechnology",
      "indices" : [ 59, 73 ],
      "id_str" : "2216405440",
      "id" : 2216405440
    }, {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 75, 83 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 93, 108 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ngdle",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/IvzQbmcTvy",
      "expanded_url" : "https:\/\/btopro.wordpress.com\/2016\/04\/26\/faculty-rising-the-next-10-years\/",
      "display_url" : "btopro.wordpress.com\/2016\/04\/26\/fac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725063175083687936",
  "text" : "RT @btopro: Faculty led revolution via ideas like @elmsln, @H5PTechnology, @drchuck\u2019s Tsugi, @hibbittsdesign\u2019s CourseHub https:\/\/t.co\/IvzQb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ELMS:LN",
        "screen_name" : "elmsln",
        "indices" : [ 38, 45 ],
        "id_str" : "236846178",
        "id" : 236846178
      }, {
        "name" : "H5P",
        "screen_name" : "H5PTechnology",
        "indices" : [ 47, 61 ],
        "id_str" : "2216405440",
        "id" : 2216405440
      }, {
        "name" : "drchuck",
        "screen_name" : "drchuck",
        "indices" : [ 63, 71 ],
        "id_str" : "10185562",
        "id" : 10185562
      }, {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 81, 96 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ngdle",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/IvzQbmcTvy",
        "expanded_url" : "https:\/\/btopro.wordpress.com\/2016\/04\/26\/faculty-rising-the-next-10-years\/",
        "display_url" : "btopro.wordpress.com\/2016\/04\/26\/fac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "725055965536505856",
    "text" : "Faculty led revolution via ideas like @elmsln, @H5PTechnology, @drchuck\u2019s Tsugi, @hibbittsdesign\u2019s CourseHub https:\/\/t.co\/IvzQbmcTvy #ngdle",
    "id" : 725055965536505856,
    "created_at" : "2016-04-26 20:16:27 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 725063175083687936,
  "created_at" : "2016-04-26 20:45:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723988733872107520",
  "text" : "Really sinking in that the Grav Course Hub project was a solution to my own problems, and now the challenge is sustainable open development.",
  "id" : 723988733872107520,
  "created_at" : "2016-04-23 21:35:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/ugkKePQ73A",
      "expanded_url" : "https:\/\/getgrav.org\/blog\/grav-beta-1.1-available",
      "display_url" : "getgrav.org\/blog\/grav-beta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723596367210250240",
  "text" : "RT @getgrav: New blog post about Grav v1.1 Beta + Admin v1.1 Beta. https:\/\/t.co\/ugkKePQ73A\n\nCheck out what's coming in the new version and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/ugkKePQ73A",
        "expanded_url" : "https:\/\/getgrav.org\/blog\/grav-beta-1.1-available",
        "display_url" : "getgrav.org\/blog\/grav-beta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "723596199882678272",
    "text" : "New blog post about Grav v1.1 Beta + Admin v1.1 Beta. https:\/\/t.co\/ugkKePQ73A\n\nCheck out what's coming in the new version and help us test.",
    "id" : 723596199882678272,
    "created_at" : "2016-04-22 19:35:52 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 723596367210250240,
  "created_at" : "2016-04-22 19:36:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 3, 10 ],
      "id_str" : "236846178",
      "id" : 236846178
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drupal",
      "indices" : [ 94, 101 ]
    }, {
      "text" : "edtech",
      "indices" : [ 102, 109 ]
    }, {
      "text" : "lms",
      "indices" : [ 110, 114 ]
    }, {
      "text" : "ngdle",
      "indices" : [ 115, 121 ]
    }, {
      "text" : "xapi",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/ZmwEshI4iW",
      "expanded_url" : "https:\/\/github.com\/elmsln\/elmsln",
      "display_url" : "github.com\/elmsln\/elmsln"
    } ]
  },
  "geo" : { },
  "id_str" : "723530891822133248",
  "text" : "RT @elmsln: 70 stars, 32 forks and climbing, give us a look will you? https:\/\/t.co\/ZmwEshI4iW #drupal #edtech #lms #ngdle #xapi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drupal",
        "indices" : [ 82, 89 ]
      }, {
        "text" : "edtech",
        "indices" : [ 90, 97 ]
      }, {
        "text" : "lms",
        "indices" : [ 98, 102 ]
      }, {
        "text" : "ngdle",
        "indices" : [ 103, 109 ]
      }, {
        "text" : "xapi",
        "indices" : [ 110, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/ZmwEshI4iW",
        "expanded_url" : "https:\/\/github.com\/elmsln\/elmsln",
        "display_url" : "github.com\/elmsln\/elmsln"
      } ]
    },
    "geo" : { },
    "id_str" : "723523442021163008",
    "text" : "70 stars, 32 forks and climbing, give us a look will you? https:\/\/t.co\/ZmwEshI4iW #drupal #edtech #lms #ngdle #xapi",
    "id" : 723523442021163008,
    "created_at" : "2016-04-22 14:46:45 +0000",
    "user" : {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "protected" : false,
      "id_str" : "236846178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601925668025278465\/4j0l2bWZ_normal.png",
      "id" : 236846178,
      "verified" : false
    }
  },
  "id" : 723530891822133248,
  "created_at" : "2016-04-22 15:16:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mark britz",
      "screen_name" : "britz",
      "indices" : [ 3, 9 ],
      "id_str" : "14719875",
      "id" : 14719875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723310455054172160",
  "text" : "RT @britz: I read articles until I reach the word millennial. Then I\u2019m out. They go from credible to crap just like that.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "723307423964999680",
    "text" : "I read articles until I reach the word millennial. Then I\u2019m out. They go from credible to crap just like that.",
    "id" : 723307423964999680,
    "created_at" : "2016-04-22 00:28:22 +0000",
    "user" : {
      "name" : "mark britz",
      "screen_name" : "britz",
      "protected" : false,
      "id_str" : "14719875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753236992809402368\/-upHQ4Dq_normal.jpg",
      "id" : 14719875,
      "verified" : false
    }
  },
  "id" : 723310455054172160,
  "created_at" : "2016-04-22 00:40:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tylor Sherman",
      "screen_name" : "tylorsherman",
      "indices" : [ 0, 13 ],
      "id_str" : "6274112",
      "id" : 6274112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723302668932775936",
  "geo" : { },
  "id_str" : "723304840323964928",
  "in_reply_to_user_id" : 6274112,
  "text" : "@tylorsherman goodtimes",
  "id" : 723304840323964928,
  "in_reply_to_status_id" : 723302668932775936,
  "created_at" : "2016-04-22 00:18:06 +0000",
  "in_reply_to_screen_name" : "tylorsherman",
  "in_reply_to_user_id_str" : "6274112",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/RIhLtRVvmq",
      "expanded_url" : "https:\/\/twitter.com\/studentfirstnl\/status\/723248529326637056",
      "display_url" : "twitter.com\/studentfirstnl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723267409616863232",
  "text" : "Absolutely awesome. https:\/\/t.co\/RIhLtRVvmq",
  "id" : 723267409616863232,
  "created_at" : "2016-04-21 21:49:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/g891q90LUj",
      "expanded_url" : "https:\/\/git-scm.com\/book\/en\/v2",
      "display_url" : "git-scm.com\/book\/en\/v2"
    } ]
  },
  "geo" : { },
  "id_str" : "723259465424769026",
  "text" : "RT @cogdog: I'm \"gitting\" the Pro Git Book https:\/\/t.co\/g891q90LUj Not only understandable, it's available under Creative Commons license",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/g891q90LUj",
        "expanded_url" : "https:\/\/git-scm.com\/book\/en\/v2",
        "display_url" : "git-scm.com\/book\/en\/v2"
      } ]
    },
    "geo" : { },
    "id_str" : "723259129305800704",
    "text" : "I'm \"gitting\" the Pro Git Book https:\/\/t.co\/g891q90LUj Not only understandable, it's available under Creative Commons license",
    "id" : 723259129305800704,
    "created_at" : "2016-04-21 21:16:28 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 723259465424769026,
  "created_at" : "2016-04-21 21:17:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723257880103669760",
  "text" : "If you are building a digital learning environment in 2016 that does not support collaborative authoring you are already behind the curve.",
  "id" : 723257880103669760,
  "created_at" : "2016-04-21 21:11:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeopardy Jackie",
      "screen_name" : "JeopardyJackie",
      "indices" : [ 0, 15 ],
      "id_str" : "1687114014",
      "id" : 1687114014
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723201670235082752",
  "geo" : { },
  "id_str" : "723229791831236608",
  "in_reply_to_user_id" : 1687114014,
  "text" : "@JeopardyJackie Listening to Prince, one of the strongest memories I have is countless Exit 10's with one or more of his songs being played.",
  "id" : 723229791831236608,
  "in_reply_to_status_id" : 723201670235082752,
  "created_at" : "2016-04-21 19:19:53 +0000",
  "in_reply_to_screen_name" : "JeopardyJackie",
  "in_reply_to_user_id_str" : "1687114014",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723198878212747264",
  "text" : "Speechless about the death of Prince.",
  "id" : 723198878212747264,
  "created_at" : "2016-04-21 17:17:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723187373677256704",
  "text" : "By using an open and collaborative platform as an alternative front-end to the LMS you can pick and choose the best aspects of both #GravEdu",
  "id" : 723187373677256704,
  "created_at" : "2016-04-21 16:31:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Stewart",
      "screen_name" : "jstew511",
      "indices" : [ 0, 9 ],
      "id_str" : "73977188",
      "id" : 73977188
    }, {
      "name" : "Adam Croom",
      "screen_name" : "acroom",
      "indices" : [ 10, 17 ],
      "id_str" : "19056987",
      "id" : 19056987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/tv9q3n8Pxr",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/",
      "display_url" : "hibbittsdesign.org\/blog\/"
    } ]
  },
  "in_reply_to_status_id_str" : "722775165596233728",
  "geo" : { },
  "id_str" : "722942071535833089",
  "in_reply_to_user_id" : 73977188,
  "text" : "@jstew511 @acroom Thanks for this great resource to introduce educators to GitHub! Added as a linked post on my blog https:\/\/t.co\/tv9q3n8Pxr",
  "id" : 722942071535833089,
  "in_reply_to_status_id" : 722775165596233728,
  "created_at" : "2016-04-21 00:16:36 +0000",
  "in_reply_to_screen_name" : "jstew511",
  "in_reply_to_user_id_str" : "73977188",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722917007377608705",
  "text" : "Grav Course Hub - an open &amp; collaborative Web platform that delivers a better experience for course participants, in partnership with an LMS",
  "id" : 722917007377608705,
  "created_at" : "2016-04-20 22:37:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722906472640700417",
  "text" : "Grav Course Hub - an open and collaborative Web platform that delivers a better experience for course participants, regardless of your LMS.",
  "id" : 722906472640700417,
  "created_at" : "2016-04-20 21:55:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722896749526814721",
  "text" : "Grav Course Hub - an open and collaborative Web platform that provides an improved front-end user experience to your existing LMS\n\nComments?",
  "id" : 722896749526814721,
  "created_at" : "2016-04-20 21:16:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 131, 139 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/5YbJIEv9gr",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722884898164330497",
  "text" : "My Grav CMS for Educators slides have clocked 5,000 new views this month https:\/\/t.co\/5YbJIEv9gr Credit goes to the awesomeness of @getgrav\uD83D\uDE4C",
  "id" : 722884898164330497,
  "created_at" : "2016-04-20 20:29:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 71, 79 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722879877439815681",
  "text" : "Reminded again today how valuable the open and collaborative nature of @getgrav Course Hub is *between* instructors. https:\/\/t.co\/VgQsw7bHP4",
  "id" : 722879877439815681,
  "created_at" : "2016-04-20 20:09:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722830694364221440",
  "text" : "If you are building a digital learning environment in 2016 that participants cannot directly shape then you are already behind the curve.",
  "id" : 722830694364221440,
  "created_at" : "2016-04-20 16:54:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 73, 81 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/rUCY0eUC7n",
      "expanded_url" : "https:\/\/twitter.com\/jstew511\/status\/722775165596233728",
      "display_url" : "twitter.com\/jstew511\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722827798130241537",
  "text" : "Excellent overview of GitHub, especially for educators using GitHub with @getgrav Course Hub https:\/\/t.co\/VgQsw7bHP4 https:\/\/t.co\/rUCY0eUC7n",
  "id" : 722827798130241537,
  "created_at" : "2016-04-20 16:42:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Alex F\u00FCrstenau)))",
      "screen_name" : "afuerstenau",
      "indices" : [ 3, 15 ],
      "id_str" : "49754882",
      "id" : 49754882
    }, {
      "name" : "Sebastian Eichner",
      "screen_name" : "stdout",
      "indices" : [ 139, 140 ],
      "id_str" : "18988223",
      "id" : 18988223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722819054445006848",
  "text" : "RT @afuerstenau: Quote of the day: \u201CI\u2019m always surprised how long people are willing to work on a solution without even understanding the p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sebastian Eichner",
        "screen_name" : "stdout",
        "indices" : [ 133, 140 ],
        "id_str" : "18988223",
        "id" : 18988223
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "686463759485943808",
    "text" : "Quote of the day: \u201CI\u2019m always surprised how long people are willing to work on a solution without even understanding the problem.\" - @stdout",
    "id" : 686463759485943808,
    "created_at" : "2016-01-11 08:24:48 +0000",
    "user" : {
      "name" : "(((Alex F\u00FCrstenau)))",
      "screen_name" : "afuerstenau",
      "protected" : false,
      "id_str" : "49754882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767692488786186241\/teoxh_zp_normal.jpg",
      "id" : 49754882,
      "verified" : false
    }
  },
  "id" : 722819054445006848,
  "created_at" : "2016-04-20 16:07:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 3, 15 ],
      "id_str" : "6271482",
      "id" : 6271482
    }, {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 31, 43 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opensource",
      "indices" : [ 50, 61 ]
    }, {
      "text" : "oer16",
      "indices" : [ 150, 151 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 150 ],
      "url" : "https:\/\/t.co\/XX1cheQ8y4",
      "expanded_url" : "http:\/\/oet.sandcats.io",
      "display_url" : "oet.sandcats.io"
    } ]
  },
  "geo" : { },
  "id_str" : "722796854593724417",
  "text" : "RT @grantpotter: Curious about @sandstormio &amp; #opensource apps? Drop me a line &amp; come experiment &amp; explore with us https:\/\/t.co\/XX1cheQ8y4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sandstorm.IO",
        "screen_name" : "SandstormIO",
        "indices" : [ 14, 26 ],
        "id_str" : "2476570038",
        "id" : 2476570038
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opensource",
        "indices" : [ 33, 44 ]
      }, {
        "text" : "oer16",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/XX1cheQ8y4",
        "expanded_url" : "http:\/\/oet.sandcats.io",
        "display_url" : "oet.sandcats.io"
      } ]
    },
    "geo" : { },
    "id_str" : "722796187619893253",
    "text" : "Curious about @sandstormio &amp; #opensource apps? Drop me a line &amp; come experiment &amp; explore with us https:\/\/t.co\/XX1cheQ8y4 #oer16",
    "id" : 722796187619893253,
    "created_at" : "2016-04-20 14:36:54 +0000",
    "user" : {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "protected" : false,
      "id_str" : "6271482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639833921228640256\/S63CDenk_normal.jpg",
      "id" : 6271482,
      "verified" : false
    }
  },
  "id" : 722796854593724417,
  "created_at" : "2016-04-20 14:39:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/6eSLXDPno4",
      "expanded_url" : "http:\/\/gravcoursehub.org",
      "display_url" : "gravcoursehub.org"
    } ]
  },
  "geo" : { },
  "id_str" : "722572588782735361",
  "text" : "Almost every LMS has a few good qualities - use only the LMS features you want by 'flipping' it with Grav Course Hub https:\/\/t.co\/6eSLXDPno4",
  "id" : 722572588782735361,
  "created_at" : "2016-04-19 23:48:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitLab",
      "screen_name" : "gitlab",
      "indices" : [ 100, 107 ],
      "id_str" : "390167291",
      "id" : 390167291
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 124, 132 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722568645000343552",
  "text" : "A fully FIPPA compliant dream set-up for an open and collaborative Grav Course Hub?\n\u2713 School-hosted @gitlab\n\u2713 School-hosted @getgrav\nBOOM!",
  "id" : 722568645000343552,
  "created_at" : "2016-04-19 23:32:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 14, 22 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/SKHaHkX5al",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-10-grav-cms-for-educators-workshop-resources",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722529260468961280",
  "text" : "Updated Post: @getgrav CMS for Educators Workshop Resources https:\/\/t.co\/SKHaHkX5al",
  "id" : 722529260468961280,
  "created_at" : "2016-04-19 20:56:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 43, 51 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722492122536943616",
  "text" : "The way that the open source flat-file CMS @getgrav Course Hub enables educators to share + collaborate w other educations is the new floor.",
  "id" : 722492122536943616,
  "created_at" : "2016-04-19 18:28:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atom Editor",
      "screen_name" : "AtomEditor",
      "indices" : [ 3, 14 ],
      "id_str" : "2339397540",
      "id" : 2339397540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/kl4MGTfUt5",
      "expanded_url" : "http:\/\/blog.atom.io\/2016\/04\/19\/managing-the-deluge-of-atom-issues.html",
      "display_url" : "blog.atom.io\/2016\/04\/19\/man\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722490691465531392",
  "text" : "RT @AtomEditor: We're trying some new strategies to help us be more transparent and responsive on Issues. See the blog post: https:\/\/t.co\/k\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/kl4MGTfUt5",
        "expanded_url" : "http:\/\/blog.atom.io\/2016\/04\/19\/managing-the-deluge-of-atom-issues.html",
        "display_url" : "blog.atom.io\/2016\/04\/19\/man\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722485990003073024",
    "text" : "We're trying some new strategies to help us be more transparent and responsive on Issues. See the blog post: https:\/\/t.co\/kl4MGTfUt5",
    "id" : 722485990003073024,
    "created_at" : "2016-04-19 18:04:17 +0000",
    "user" : {
      "name" : "Atom Editor",
      "screen_name" : "AtomEditor",
      "protected" : false,
      "id_str" : "2339397540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614071524853616640\/L7hkgWm7_normal.png",
      "id" : 2339397540,
      "verified" : false
    }
  },
  "id" : 722490691465531392,
  "created_at" : "2016-04-19 18:22:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Pasquini",
      "screen_name" : "laurapasquini",
      "indices" : [ 3, 17 ],
      "id_str" : "16708242",
      "id" : 16708242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cyberbullying",
      "indices" : [ 138, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/ZxAsOx7yht",
      "expanded_url" : "http:\/\/bbc.in\/1qDuyJv",
      "display_url" : "bbc.in\/1qDuyJv"
    } ]
  },
  "geo" : { },
  "id_str" : "722487287360020481",
  "text" : "RT @laurapasquini: CPS to prosecute 'trolls' who use fake online profiles https:\/\/t.co\/ZxAsOx7yht Now when will this legislation cross the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cyberbullying",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/ZxAsOx7yht",
        "expanded_url" : "http:\/\/bbc.in\/1qDuyJv",
        "display_url" : "bbc.in\/1qDuyJv"
      } ]
    },
    "geo" : { },
    "id_str" : "722486100598616064",
    "text" : "CPS to prosecute 'trolls' who use fake online profiles https:\/\/t.co\/ZxAsOx7yht Now when will this legislation cross the pond? #cyberbullying",
    "id" : 722486100598616064,
    "created_at" : "2016-04-19 18:04:44 +0000",
    "user" : {
      "name" : "Laura Pasquini",
      "screen_name" : "laurapasquini",
      "protected" : false,
      "id_str" : "16708242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697649536915808256\/KpkIiKhe_normal.png",
      "id" : 16708242,
      "verified" : false
    }
  },
  "id" : 722487287360020481,
  "created_at" : "2016-04-19 18:09:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shuli Gilutz, Ph.D.",
      "screen_name" : "ShuliGilutz",
      "indices" : [ 3, 15 ],
      "id_str" : "930009205",
      "id" : 930009205
    }, {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "indices" : [ 129, 137 ],
      "id_str" : "15022225",
      "id" : 15022225
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "usertesting",
      "indices" : [ 61, 73 ]
    }, {
      "text" : "UXresearch",
      "indices" : [ 74, 85 ]
    }, {
      "text" : "designprocess",
      "indices" : [ 86, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/Or04suLP06",
      "expanded_url" : "http:\/\/www.nngroup.com\/articles\/usability-test-checklist\/",
      "display_url" : "nngroup.com\/articles\/usabi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722479037768081412",
  "text" : "RT @ShuliGilutz: \u2705 Checklist for Planning Usability Studies. #usertesting #UXresearch #designprocess https:\/\/t.co\/Or04suLP06 via @nngroup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nielsen Norman Group",
        "screen_name" : "NNgroup",
        "indices" : [ 112, 120 ],
        "id_str" : "15022225",
        "id" : 15022225
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "usertesting",
        "indices" : [ 44, 56 ]
      }, {
        "text" : "UXresearch",
        "indices" : [ 57, 68 ]
      }, {
        "text" : "designprocess",
        "indices" : [ 69, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/Or04suLP06",
        "expanded_url" : "http:\/\/www.nngroup.com\/articles\/usability-test-checklist\/",
        "display_url" : "nngroup.com\/articles\/usabi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722003432228405248",
    "text" : "\u2705 Checklist for Planning Usability Studies. #usertesting #UXresearch #designprocess https:\/\/t.co\/Or04suLP06 via @nngroup",
    "id" : 722003432228405248,
    "created_at" : "2016-04-18 10:06:47 +0000",
    "user" : {
      "name" : "Shuli Gilutz, Ph.D.",
      "screen_name" : "ShuliGilutz",
      "protected" : false,
      "id_str" : "930009205",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636620507249401858\/CQmBHKyI_normal.jpg",
      "id" : 930009205,
      "verified" : false
    }
  },
  "id" : 722479037768081412,
  "created_at" : "2016-04-19 17:36:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 63, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722477193800998912",
  "text" : "Sustainability must be part of the discussion when it comes to #OER. It was a critical strategy element for my own Grav Course Hub project.",
  "id" : 722477193800998912,
  "created_at" : "2016-04-19 17:29:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deborah So",
      "screen_name" : "DeborahSo",
      "indices" : [ 3, 13 ],
      "id_str" : "20408626",
      "id" : 20408626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 74, 79 ]
    }, {
      "text" : "designer",
      "indices" : [ 80, 89 ]
    }, {
      "text" : "design",
      "indices" : [ 90, 97 ]
    }, {
      "text" : "BCjobs",
      "indices" : [ 98, 105 ]
    }, {
      "text" : "artist",
      "indices" : [ 106, 113 ]
    }, {
      "text" : "langaracollege",
      "indices" : [ 114, 129 ]
    }, {
      "text" : "vancouverjobs",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/ABKsSsyPIG",
      "expanded_url" : "http:\/\/ow.ly\/4mPSDc",
      "display_url" : "ow.ly\/4mPSDc"
    } ]
  },
  "geo" : { },
  "id_str" : "722476389266370560",
  "text" : "RT @DeborahSo: Langara is seeking a new designer! https:\/\/t.co\/ABKsSsyPIG #jobs #designer #design #BCjobs #artist #langaracollege #vancouve\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 59, 64 ]
      }, {
        "text" : "designer",
        "indices" : [ 65, 74 ]
      }, {
        "text" : "design",
        "indices" : [ 75, 82 ]
      }, {
        "text" : "BCjobs",
        "indices" : [ 83, 90 ]
      }, {
        "text" : "artist",
        "indices" : [ 91, 98 ]
      }, {
        "text" : "langaracollege",
        "indices" : [ 99, 114 ]
      }, {
        "text" : "vancouverjobs",
        "indices" : [ 115, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/ABKsSsyPIG",
        "expanded_url" : "http:\/\/ow.ly\/4mPSDc",
        "display_url" : "ow.ly\/4mPSDc"
      } ]
    },
    "geo" : { },
    "id_str" : "722209341592444928",
    "text" : "Langara is seeking a new designer! https:\/\/t.co\/ABKsSsyPIG #jobs #designer #design #BCjobs #artist #langaracollege #vancouverjobs",
    "id" : 722209341592444928,
    "created_at" : "2016-04-18 23:44:59 +0000",
    "user" : {
      "name" : "Deborah So",
      "screen_name" : "DeborahSo",
      "protected" : false,
      "id_str" : "20408626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3340915253\/46e0a1987696a7e0c05ddb5036c62e9e_normal.jpeg",
      "id" : 20408626,
      "verified" : false
    }
  },
  "id" : 722476389266370560,
  "created_at" : "2016-04-19 17:26:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722467301887332353",
  "text" : "I was fortunate to provide UI\/UX design for 20 years with so many great clients, but moving into the open source space is a dream come true.",
  "id" : 722467301887332353,
  "created_at" : "2016-04-19 16:50:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 28, 36 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "BCIT",
      "screen_name" : "bcit",
      "indices" : [ 95, 100 ],
      "id_str" : "19372538",
      "id" : 19372538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/sWm51Hk83x",
      "expanded_url" : "https:\/\/onedrive.live.com\/redir?resid=74D2D06DCB0AFD88!281144&authkey=!AK7K9JwGkVTfPso&ithint=folder%2cpdf",
      "display_url" : "onedrive.live.com\/redir?resid=74\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722465392430460928",
  "text" : "Getting ready for my second @getgrav CMS for Educators workshop, this time around for folks at @bcit. Resources at https:\/\/t.co\/sWm51Hk83x",
  "id" : 722465392430460928,
  "created_at" : "2016-04-19 16:42:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 10, 18 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 55, 62 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 97, 105 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/pTMPHl38lW",
      "expanded_url" : "https:\/\/www.eventsforce.net\/concentra\/frontend\/reg\/titem.csp?pageID=4607&&eventID=9",
      "display_url" : "eventsforce.net\/concentra\/fron\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722460457286520832",
  "text" : "Thanks to @drchuck I'll be (virtually) joining him and @btopro at Open Apereo 2016 to talk about @getgrav Course Hub https:\/\/t.co\/pTMPHl38lW",
  "id" : 722460457286520832,
  "created_at" : "2016-04-19 16:22:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 33, 40 ],
      "id_str" : "236846178",
      "id" : 236846178
    }, {
      "name" : "Apereo Foundation",
      "screen_name" : "ApereoOrg",
      "indices" : [ 73, 83 ],
      "id_str" : "1117619618",
      "id" : 1117619618
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 124, 131 ]
    }, {
      "text" : "ngdle",
      "indices" : [ 132, 138 ]
    }, {
      "text" : "lms",
      "indices" : [ 138, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/Q2n5hdAqWG",
      "expanded_url" : "https:\/\/www.eventsforce.net\/concentra\/frontend\/reg\/titem.csp?pageID=4607&&eventID=9",
      "display_url" : "eventsforce.net\/concentra\/fron\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722456189473136640",
  "text" : "RT @btopro: It would appear that @elmsln will be making an appearance at @apereoorg conf next month https:\/\/t.co\/Q2n5hdAqWG #edtech #ngdle\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ELMS:LN",
        "screen_name" : "elmsln",
        "indices" : [ 21, 28 ],
        "id_str" : "236846178",
        "id" : 236846178
      }, {
        "name" : "Apereo Foundation",
        "screen_name" : "ApereoOrg",
        "indices" : [ 61, 71 ],
        "id_str" : "1117619618",
        "id" : 1117619618
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 112, 119 ]
      }, {
        "text" : "ngdle",
        "indices" : [ 120, 126 ]
      }, {
        "text" : "lms",
        "indices" : [ 127, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/Q2n5hdAqWG",
        "expanded_url" : "https:\/\/www.eventsforce.net\/concentra\/frontend\/reg\/titem.csp?pageID=4607&&eventID=9",
        "display_url" : "eventsforce.net\/concentra\/fron\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722445715717251072",
    "text" : "It would appear that @elmsln will be making an appearance at @apereoorg conf next month https:\/\/t.co\/Q2n5hdAqWG #edtech #ngdle #lms",
    "id" : 722445715717251072,
    "created_at" : "2016-04-19 15:24:15 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 722456189473136640,
  "created_at" : "2016-04-19 16:05:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 3, 11 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Apereo2016",
      "indices" : [ 112, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/WHpooi5MrP",
      "expanded_url" : "https:\/\/www.eventsforce.net\/concentra\/frontend\/reg\/titem.csp?pageID=4607&&eventID=9",
      "display_url" : "eventsforce.net\/concentra\/fron\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722447698385772544",
  "text" : "RT @drchuck: If you are interested in progress on Next Generation Digital Learning Environments (NGDLE) come to #Apereo2016 https:\/\/t.co\/WH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Apereo2016",
        "indices" : [ 99, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/WHpooi5MrP",
        "expanded_url" : "https:\/\/www.eventsforce.net\/concentra\/frontend\/reg\/titem.csp?pageID=4607&&eventID=9",
        "display_url" : "eventsforce.net\/concentra\/fron\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722435804551868416",
    "text" : "If you are interested in progress on Next Generation Digital Learning Environments (NGDLE) come to #Apereo2016 https:\/\/t.co\/WHpooi5MrP",
    "id" : 722435804551868416,
    "created_at" : "2016-04-19 14:44:52 +0000",
    "user" : {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "protected" : false,
      "id_str" : "10185562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1396181322\/new-square-pic_normal.jpg",
      "id" : 10185562,
      "verified" : false
    }
  },
  "id" : 722447698385772544,
  "created_at" : "2016-04-19 15:32:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 3, 18 ],
      "id_str" : "1122631",
      "id" : 1122631
    }, {
      "name" : "Kevan Gilbert",
      "screen_name" : "kevangilbert",
      "indices" : [ 39, 52 ],
      "id_str" : "17015437",
      "id" : 17015437
    }, {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "indices" : [ 102, 109 ],
      "id_str" : "944913038",
      "id" : 944913038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/cYGRkZQt0R",
      "expanded_url" : "http:\/\/meetu.ps\/e\/BvhCK\/1D0qM\/a",
      "display_url" : "meetu.ps\/e\/BvhCK\/1D0qM\/a"
    } ]
  },
  "geo" : { },
  "id_str" : "722430768748728320",
  "text" : "RT @MalloryOConnor: Looking forward to @kevangilbert sharing insights about working with stakeholders @Van_UE on April 27 - https:\/\/t.co\/cY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevan Gilbert",
        "screen_name" : "kevangilbert",
        "indices" : [ 19, 32 ],
        "id_str" : "17015437",
        "id" : 17015437
      }, {
        "name" : "VanUE",
        "screen_name" : "Van_UE",
        "indices" : [ 82, 89 ],
        "id_str" : "944913038",
        "id" : 944913038
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 128, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/cYGRkZQt0R",
        "expanded_url" : "http:\/\/meetu.ps\/e\/BvhCK\/1D0qM\/a",
        "display_url" : "meetu.ps\/e\/BvhCK\/1D0qM\/a"
      } ]
    },
    "geo" : { },
    "id_str" : "722430661345148928",
    "text" : "Looking forward to @kevangilbert sharing insights about working with stakeholders @Van_UE on April 27 - https:\/\/t.co\/cYGRkZQt0R #UX",
    "id" : 722430661345148928,
    "created_at" : "2016-04-19 14:24:26 +0000",
    "user" : {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "protected" : false,
      "id_str" : "1122631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2261747531\/mallory_thumbnail_normal.png",
      "id" : 1122631,
      "verified" : false
    }
  },
  "id" : 722430768748728320,
  "created_at" : "2016-04-19 14:24:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722188921665232897",
  "geo" : { },
  "id_str" : "722189908245282816",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 Solid interviewing skills are important, especially in that case.",
  "id" : 722189908245282816,
  "in_reply_to_status_id" : 722188921665232897,
  "created_at" : "2016-04-18 22:27:46 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/arhrQcSjh3",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=OIMGPlH4XPo",
      "display_url" : "youtube.com\/watch?v=OIMGPl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "722183818732408832",
  "geo" : { },
  "id_str" : "722186188098904064",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 You might enjoy this Sigur Ros interview that I use in my classes as how NOT to conduct an interview \uD83D\uDE42 https:\/\/t.co\/arhrQcSjh3",
  "id" : 722186188098904064,
  "in_reply_to_status_id" : 722183818732408832,
  "created_at" : "2016-04-18 22:12:59 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oer16",
      "indices" : [ 51, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/xky1rbWLdt",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-07-using-grav-as-a-simple-open-publishing-tool",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722179109334290432",
  "text" : "An oldie but a goodie, and perhaps of interest for #oer16 folks: Using Grav as a GitHub-powered Open Publishing Tool https:\/\/t.co\/xky1rbWLdt",
  "id" : 722179109334290432,
  "created_at" : "2016-04-18 21:44:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722173819528450048",
  "text" : "What problems can the Grav Course Hub solve? Reaching unmet pedagogical goals + better experience for all without changing the LMS #GravEdu",
  "id" : 722173819528450048,
  "created_at" : "2016-04-18 21:23:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 23, 31 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/722160506723704832\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/kutLNgKfp2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgWhJ1VVAAEaQEI.jpg",
      "id_str" : "722160505570263041",
      "id" : 722160505570263041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgWhJ1VVAAEaQEI.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kutLNgKfp2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/9PFedwpqcF",
      "expanded_url" : "https:\/\/getgrav.org\/downloads\/skeletons",
      "display_url" : "getgrav.org\/downloads\/skel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722160506723704832",
  "text" : "New release of default @getgrav Course Hub theme now available, built using Zurb Foundation https:\/\/t.co\/9PFedwpqcF https:\/\/t.co\/kutLNgKfp2",
  "id" : 722160506723704832,
  "created_at" : "2016-04-18 20:30:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722157881911410688",
  "text" : "Want to livechat about flipping your LMS with the Web platform Grav? I'll be online for the next few hours at hibbittsdesign dot org #edtech",
  "id" : 722157881911410688,
  "created_at" : "2016-04-18 20:20:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 0, 8 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 9, 16 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/2dUoaYrX0U",
      "expanded_url" : "https:\/\/workflowy.com\/s\/3FLodoor9P",
      "display_url" : "workflowy.com\/s\/3FLodoor9P"
    } ]
  },
  "geo" : { },
  "id_str" : "722107340401446913",
  "in_reply_to_user_id" : 10185562,
  "text" : "@drchuck @btopro Here is a draft outline for my 10 min flipped-LMS preso in our Open Apereo talk https:\/\/t.co\/2dUoaYrX0U Feedback welcome \uD83D\uDE42",
  "id" : 722107340401446913,
  "created_at" : "2016-04-18 16:59:40 +0000",
  "in_reply_to_screen_name" : "drchuck",
  "in_reply_to_user_id_str" : "10185562",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexey Zagalsky",
      "screen_name" : "alexeyzagalsky",
      "indices" : [ 3, 18 ],
      "id_str" : "597572114",
      "id" : 597572114
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "git",
      "indices" : [ 53, 57 ]
    }, {
      "text" : "github",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/i42Ujc9bBH",
      "expanded_url" : "https:\/\/twitter.com\/elliotblackburn\/status\/696335476953845761",
      "display_url" : "twitter.com\/elliotblackbur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722101976926781441",
  "text" : "RT @alexeyzagalsky: Great tips on how to start using #git and #github in class https:\/\/t.co\/i42Ujc9bBH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "git",
        "indices" : [ 33, 37 ]
      }, {
        "text" : "github",
        "indices" : [ 42, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/i42Ujc9bBH",
        "expanded_url" : "https:\/\/twitter.com\/elliotblackburn\/status\/696335476953845761",
        "display_url" : "twitter.com\/elliotblackbur\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722098713229795328",
    "text" : "Great tips on how to start using #git and #github in class https:\/\/t.co\/i42Ujc9bBH",
    "id" : 722098713229795328,
    "created_at" : "2016-04-18 16:25:23 +0000",
    "user" : {
      "name" : "Alexey Zagalsky",
      "screen_name" : "alexeyzagalsky",
      "protected" : false,
      "id_str" : "597572114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672265921184968704\/zfaNnuNX_normal.jpg",
      "id" : 597572114,
      "verified" : false
    }
  },
  "id" : 722101976926781441,
  "created_at" : "2016-04-18 16:38:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722098686566633474",
  "text" : "(3\/3) Deliver a better multi-device experience to students and instructors while keeping sensitive course data in your current LMS. #GravEdu",
  "id" : 722098686566633474,
  "created_at" : "2016-04-18 16:25:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722098628056129537",
  "text" : "(2\/3) Empower instructors with an open and collaborative platform while keeping sensitive student information in your current LMS. #GravEdu",
  "id" : 722098628056129537,
  "created_at" : "2016-04-18 16:25:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722098566278176768",
  "text" : "(1\/3) Lesson learned over the past week: I must speak to the instructor AND institutional perspective with Grav Course Hub project. #GravEdu",
  "id" : 722098566278176768,
  "created_at" : "2016-04-18 16:24:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721908689553076224",
  "text" : "Empower instructors with an open and collaborative platform while keeping sensitive student information in your institutional LMS. #GravEdu",
  "id" : 721908689553076224,
  "created_at" : "2016-04-18 03:50:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/XGujdPWwl4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-04-18-customizing-a-grav-course-hub-theme",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721815229802221568",
  "text" : "Sneaking in a little new post on a Sunday: Customizing a Grav Course Hub Theme https:\/\/t.co\/XGujdPWwl4 #GravEdu",
  "id" : 721815229802221568,
  "created_at" : "2016-04-17 21:38:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "davidwebster",
      "screen_name" : "davidwebster",
      "indices" : [ 3, 16 ],
      "id_str" : "15734898",
      "id" : 15734898
    }, {
      "name" : "Jisc",
      "screen_name" : "Jisc",
      "indices" : [ 136, 140 ],
      "id_str" : "18829580",
      "id" : 18829580
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "employability",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/hxQ5v26FSO",
      "expanded_url" : "http:\/\/davewebster.org\/2016\/04\/11\/sho",
      "display_url" : "davewebster.org\/2016\/04\/11\/sho"
    } ]
  },
  "geo" : { },
  "id_str" : "721414594267193344",
  "text" : "RT @davidwebster: Shock News: The future doesn\u2019t exist yet... https:\/\/t.co\/hxQ5v26FSO\u2026 - on \u201Ctraining for jobs that don\u2019t exist\u201D talk.. @ji\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jisc",
        "screen_name" : "Jisc",
        "indices" : [ 118, 123 ],
        "id_str" : "18829580",
        "id" : 18829580
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "employability",
        "indices" : [ 125, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/hxQ5v26FSO",
        "expanded_url" : "http:\/\/davewebster.org\/2016\/04\/11\/sho",
        "display_url" : "davewebster.org\/2016\/04\/11\/sho"
      } ]
    },
    "geo" : { },
    "id_str" : "721380173711548420",
    "text" : "Shock News: The future doesn\u2019t exist yet... https:\/\/t.co\/hxQ5v26FSO\u2026 - on \u201Ctraining for jobs that don\u2019t exist\u201D talk.. @jisc  #employability",
    "id" : 721380173711548420,
    "created_at" : "2016-04-16 16:50:10 +0000",
    "user" : {
      "name" : "davidwebster",
      "screen_name" : "davidwebster",
      "protected" : false,
      "id_str" : "15734898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727087557994008579\/3dofdYeW_normal.jpg",
      "id" : 15734898,
      "verified" : false
    }
  },
  "id" : 721414594267193344,
  "created_at" : "2016-04-16 19:06:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Riedl",
      "screen_name" : "mark_riedl",
      "indices" : [ 3, 14 ],
      "id_str" : "96135022",
      "id" : 96135022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721148268575494144",
  "text" : "RT @mark_riedl: All those Facebook Messenger chatbots are little walled gardens inside a bigger walled garden.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "721138918092091393",
    "text" : "All those Facebook Messenger chatbots are little walled gardens inside a bigger walled garden.",
    "id" : 721138918092091393,
    "created_at" : "2016-04-16 00:51:30 +0000",
    "user" : {
      "name" : "Mark Riedl",
      "screen_name" : "mark_riedl",
      "protected" : false,
      "id_str" : "96135022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000546907310\/545a95905a690ea55b4d8deeed3200fd_normal.png",
      "id" : 96135022,
      "verified" : false
    }
  },
  "id" : 721148268575494144,
  "created_at" : "2016-04-16 01:28:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/H2iSGQn9qx",
      "expanded_url" : "https:\/\/twitter.com\/DMLResearchHub\/status\/721137365587214336",
      "display_url" : "twitter.com\/DMLResearchHub\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721147747219300354",
  "text" : "The issue to me is that currently one student's use of technology most often impacts their neighbor's experience. https:\/\/t.co\/H2iSGQn9qx",
  "id" : 721147747219300354,
  "created_at" : "2016-04-16 01:26:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ODQsoue9NO",
      "expanded_url" : "https:\/\/twitter.com\/benwerd\/status\/721131410472325121",
      "display_url" : "twitter.com\/benwerd\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721133226115215360",
  "text" : "Personally, I've found what was happening @ Microsoft more interesting that Apple since about 2012 w. first Surface. https:\/\/t.co\/ODQsoue9NO",
  "id" : 721133226115215360,
  "created_at" : "2016-04-16 00:28:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "indices" : [ 3, 12 ],
      "id_str" : "18613",
      "id" : 18613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/CKAyjQ8ycY",
      "expanded_url" : "http:\/\/www.dailymotion.com\/video\/x387n7u",
      "display_url" : "dailymotion.com\/video\/x387n7u"
    } ]
  },
  "geo" : { },
  "id_str" : "721102352573313024",
  "text" : "RT @gsiemens: Terrific. Well worth the 50+min: The Secret Rules of Modern Living: Algorithms https:\/\/t.co\/CKAyjQ8ycY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/CKAyjQ8ycY",
        "expanded_url" : "http:\/\/www.dailymotion.com\/video\/x387n7u",
        "display_url" : "dailymotion.com\/video\/x387n7u"
      } ]
    },
    "geo" : { },
    "id_str" : "721101560844050432",
    "text" : "Terrific. Well worth the 50+min: The Secret Rules of Modern Living: Algorithms https:\/\/t.co\/CKAyjQ8ycY",
    "id" : 721101560844050432,
    "created_at" : "2016-04-15 22:23:04 +0000",
    "user" : {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "protected" : false,
      "id_str" : "18613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451036825637761025\/7_0RawE8_normal.jpeg",
      "id" : 18613,
      "verified" : false
    }
  },
  "id" : 721102352573313024,
  "created_at" : "2016-04-15 22:26:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/QYEZCoTAvO",
      "expanded_url" : "http:\/\/hibbittsdesign.org",
      "display_url" : "hibbittsdesign.org"
    }, {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/JA1D7XwNcL",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-03-why-I-chose-Grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721068237006327808",
  "text" : "Most popular https:\/\/t.co\/QYEZCoTAvO post this week?\nWhy I (as a Web-savvy Instructor) Chose the Grav CMS https:\/\/t.co\/JA1D7XwNcL #GravEdu",
  "id" : 721068237006327808,
  "created_at" : "2016-04-15 20:10:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/5WxaymzDbM",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/19NgvK5InAj-T83O3cSqynKDN5GJZGv0cUSarhmfzQWM\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/19N\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "721065914779742209",
  "geo" : { },
  "id_str" : "721066565974630400",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Full workshop description could also help re: context and interpretation https:\/\/t.co\/5WxaymzDbM",
  "id" : 721066565974630400,
  "in_reply_to_status_id" : 721065914779742209,
  "created_at" : "2016-04-15 20:04:00 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721065769463857152",
  "geo" : { },
  "id_str" : "721066104206938112",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro As better\/easier tools come into play certainly! Did you see GitHub being used for the HTML 5.1 spec now? Nice one.",
  "id" : 721066104206938112,
  "in_reply_to_status_id" : 721065769463857152,
  "created_at" : "2016-04-15 20:02:10 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721064723433840642",
  "geo" : { },
  "id_str" : "721065196656037888",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Perhaps some other term than \"tech-savvy\" then... technically comfortable? Not much better, eh\u2639\uFE0F I will think more about this...",
  "id" : 721065196656037888,
  "in_reply_to_status_id" : 721064723433840642,
  "created_at" : "2016-04-15 19:58:34 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721064393186873344",
  "geo" : { },
  "id_str" : "721064794665582592",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Agree, it is a challenge as the current needed skills are far from ubiquitous.",
  "id" : 721064794665582592,
  "in_reply_to_status_id" : 721064393186873344,
  "created_at" : "2016-04-15 19:56:58 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/721063561489817600\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/VVLGv7d0HN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgG7fNNUsAIXWVr.jpg",
      "id_str" : "721063560151871490",
      "id" : 721063560151871490,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgG7fNNUsAIXWVr.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/VVLGv7d0HN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721063561489817600",
  "text" : "New version for my upcoming Grav workshop. My fellow educators: does this workshop description catch your interest? https:\/\/t.co\/VVLGv7d0HN",
  "id" : 721063561489817600,
  "created_at" : "2016-04-15 19:52:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 58, 67 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721023255633461249",
  "text" : "Working on the final title of my Grav CMS workshop at the @BCcampus Festival of Learning. 'Moving Beyond the LMS with Grav' still leading...",
  "id" : 721023255633461249,
  "created_at" : "2016-04-15 17:11:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 48, 56 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/720744205765586946\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/Fe9uHA7uDX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgCZCSmUkAER0wE.jpg",
      "id_str" : "720744205010636801",
      "id" : 720744205010636801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgCZCSmUkAER0wE.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Fe9uHA7uDX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720744205765586946",
  "text" : "Trying to capture the essence of my open source @getgrav CMS Course Hub project in less than 500 characters... https:\/\/t.co\/Fe9uHA7uDX",
  "id" : 720744205765586946,
  "created_at" : "2016-04-14 22:43:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/FOhjjMTJEY",
      "expanded_url" : "https:\/\/twitter.com\/effectiveui\/status\/720573633798737920",
      "display_url" : "twitter.com\/effectiveui\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720690044822904832",
  "text" : "Score another one for GitHub... https:\/\/t.co\/FOhjjMTJEY",
  "id" : 720690044822904832,
  "created_at" : "2016-04-14 19:07:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Robinson",
      "screen_name" : "krob",
      "indices" : [ 0, 5 ],
      "id_str" : "1069802168",
      "id" : 1069802168
    }, {
      "name" : "Kyle Mathews",
      "screen_name" : "kylemathews",
      "indices" : [ 6, 18 ],
      "id_str" : "10907062",
      "id" : 10907062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720383073628491776",
  "geo" : { },
  "id_str" : "720383512126160896",
  "in_reply_to_user_id" : 1069802168,
  "text" : "@krob @kylemathews I like it! Thanks for sharing \uD83D\uDE42",
  "id" : 720383512126160896,
  "in_reply_to_status_id" : 720383073628491776,
  "created_at" : "2016-04-13 22:49:48 +0000",
  "in_reply_to_screen_name" : "krob",
  "in_reply_to_user_id_str" : "1069802168",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 66, 75 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/5WxaymzDbM",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/19NgvK5InAj-T83O3cSqynKDN5GJZGv0cUSarhmfzQWM\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/19N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720379403243364352",
  "text" : "Working on a detailed description for my Grav CMS workshop at the @BCcampus Festival of Learning https:\/\/t.co\/5WxaymzDbM Look of interest?",
  "id" : 720379403243364352,
  "created_at" : "2016-04-13 22:33:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UXPA International",
      "screen_name" : "UXPA_Int",
      "indices" : [ 3, 12 ],
      "id_str" : "47451021",
      "id" : 47451021
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/UXPA_Int\/status\/720318572610854912\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/CThfWLVS6B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8V7LKXIAEQ3HK.jpg",
      "id_str" : "720318571755282433",
      "id" : 720318571755282433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8V7LKXIAEQ3HK.jpg",
      "sizes" : [ {
        "h" : 748,
        "resize" : "fit",
        "w" : 475
      }, {
        "h" : 748,
        "resize" : "fit",
        "w" : 475
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 748,
        "resize" : "fit",
        "w" : 475
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CThfWLVS6B"
    } ],
    "hashtags" : [ {
      "text" : "UXPA2016",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "Seattle",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/j7nykp0Rmd",
      "expanded_url" : "http:\/\/goo.gl\/Pv7e8p",
      "display_url" : "goo.gl\/Pv7e8p"
    } ]
  },
  "geo" : { },
  "id_str" : "720320541383483392",
  "text" : "RT @UXPA_Int: Susan Dray will be awarded the 2016 UXPA Lifetime Achievement Award at #UXPA2016 in #Seattle https:\/\/t.co\/j7nykp0Rmd https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/UXPA_Int\/status\/720318572610854912\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/CThfWLVS6B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8V7LKXIAEQ3HK.jpg",
        "id_str" : "720318571755282433",
        "id" : 720318571755282433,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8V7LKXIAEQ3HK.jpg",
        "sizes" : [ {
          "h" : 748,
          "resize" : "fit",
          "w" : 475
        }, {
          "h" : 748,
          "resize" : "fit",
          "w" : 475
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 748,
          "resize" : "fit",
          "w" : 475
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CThfWLVS6B"
      } ],
      "hashtags" : [ {
        "text" : "UXPA2016",
        "indices" : [ 71, 80 ]
      }, {
        "text" : "Seattle",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/j7nykp0Rmd",
        "expanded_url" : "http:\/\/goo.gl\/Pv7e8p",
        "display_url" : "goo.gl\/Pv7e8p"
      } ]
    },
    "geo" : { },
    "id_str" : "720318572610854912",
    "text" : "Susan Dray will be awarded the 2016 UXPA Lifetime Achievement Award at #UXPA2016 in #Seattle https:\/\/t.co\/j7nykp0Rmd https:\/\/t.co\/CThfWLVS6B",
    "id" : 720318572610854912,
    "created_at" : "2016-04-13 18:31:45 +0000",
    "user" : {
      "name" : "UXPA International",
      "screen_name" : "UXPA_Int",
      "protected" : false,
      "id_str" : "47451021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2281300583\/5ka9izwtlid5e423qik1_normal.png",
      "id" : 47451021,
      "verified" : false
    }
  },
  "id" : 720320541383483392,
  "created_at" : "2016-04-13 18:39:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Mark Bullen)))",
      "screen_name" : "markbullen",
      "indices" : [ 0, 11 ],
      "id_str" : "14080697",
      "id" : 14080697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720056121197666304",
  "geo" : { },
  "id_str" : "720317036258197504",
  "in_reply_to_user_id" : 14080697,
  "text" : "@markbullen Ok, theme update will be (or is) available via your Admin Panel. Once updated go to Plugins section and enable 'SimpleSearch'.",
  "id" : 720317036258197504,
  "in_reply_to_status_id" : 720056121197666304,
  "created_at" : "2016-04-13 18:25:38 +0000",
  "in_reply_to_screen_name" : "markbullen",
  "in_reply_to_user_id_str" : "14080697",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Mark Bullen)))",
      "screen_name" : "markbullen",
      "indices" : [ 0, 11 ],
      "id_str" : "14080697",
      "id" : 14080697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720056121197666304",
  "geo" : { },
  "id_str" : "720301549763735553",
  "in_reply_to_user_id" : 14080697,
  "text" : "@markbullen I am now working on a theme update which will support having the Simple Search widget at the top of your sidebar.",
  "id" : 720301549763735553,
  "in_reply_to_status_id" : 720056121197666304,
  "created_at" : "2016-04-13 17:24:06 +0000",
  "in_reply_to_screen_name" : "markbullen",
  "in_reply_to_user_id_str" : "14080697",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Mark Bullen)))",
      "screen_name" : "markbullen",
      "indices" : [ 0, 11 ],
      "id_str" : "14080697",
      "id" : 14080697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/zp37ctS1s4",
      "expanded_url" : "http:\/\/demo.getgrav.org\/blog-skeleton\/",
      "display_url" : "demo.getgrav.org\/blog-skeleton\/"
    } ]
  },
  "in_reply_to_status_id_str" : "720056121197666304",
  "geo" : { },
  "id_str" : "720074660134555648",
  "in_reply_to_user_id" : 14080697,
  "text" : "@markbullen Yes, but very basic. Look at demo at https:\/\/t.co\/zp37ctS1s4 I think we could get in going in the Course Hub with a few tweaks.",
  "id" : 720074660134555648,
  "in_reply_to_status_id" : 720056121197666304,
  "created_at" : "2016-04-13 02:22:31 +0000",
  "in_reply_to_screen_name" : "markbullen",
  "in_reply_to_user_id_str" : "14080697",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 0, 12 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720030968413859840",
  "geo" : { },
  "id_str" : "720031592782016512",
  "in_reply_to_user_id" : 6271482,
  "text" : "@grantpotter Where you around Halifax back then? I remember Wizards being where I first saw Space Invaders and later Quinpool Amusements \uD83D\uDE80",
  "id" : 720031592782016512,
  "in_reply_to_status_id" : 720030968413859840,
  "created_at" : "2016-04-12 23:31:23 +0000",
  "in_reply_to_screen_name" : "grantpotter",
  "in_reply_to_user_id_str" : "6271482",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Mark Bullen)))",
      "screen_name" : "markbullen",
      "indices" : [ 0, 11 ],
      "id_str" : "14080697",
      "id" : 14080697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/cegel1X0w4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-11-using-grav-with-github",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720019102861950976",
  "in_reply_to_user_id" : 14080697,
  "text" : "@markbullen You might find this updated post of use, provides 2 methods for automatic deployments (I suggest Buddy) https:\/\/t.co\/cegel1X0w4",
  "id" : 720019102861950976,
  "created_at" : "2016-04-12 22:41:46 +0000",
  "in_reply_to_screen_name" : "markbullen",
  "in_reply_to_user_id_str" : "14080697",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 20, 28 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/cegel1X0w4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-11-using-grav-with-github",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720015890515800065",
  "text" : "Updated Post: Using @getgrav with GitHub Desktop (now includes Deploy *or* Buddy for automatic deployments) https:\/\/t.co\/cegel1X0w4 #GravEdu",
  "id" : 720015890515800065,
  "created_at" : "2016-04-12 22:29:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bajarin",
      "screen_name" : "BenBajarin",
      "indices" : [ 0, 11 ],
      "id_str" : "14546264",
      "id" : 14546264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720013638795284480",
  "geo" : { },
  "id_str" : "720015041651576832",
  "in_reply_to_user_id" : 14546264,
  "text" : "@BenBajarin As is the tradition of all of Apple's previous presentation products\u2639\uFE0F. I was a fan of ClarisWorks and said never again.",
  "id" : 720015041651576832,
  "in_reply_to_status_id" : 720013638795284480,
  "created_at" : "2016-04-12 22:25:37 +0000",
  "in_reply_to_screen_name" : "BenBajarin",
  "in_reply_to_user_id_str" : "14546264",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/rq0ZKPqLGz",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-04-12-local-vs-cloud-grav-development-with-github",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719938904267161600",
  "text" : "Updated Post (now includes diagrams): Local vs Cloud Grav Development with GitHub https:\/\/t.co\/rq0ZKPqLGz #GravEdu",
  "id" : 719938904267161600,
  "created_at" : "2016-04-12 17:23:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/A46WiH3dqW",
      "expanded_url" : "https:\/\/twitter.com\/btopro\/status\/719669969848549377",
      "display_url" : "twitter.com\/btopro\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719672512775229440",
  "text" : "Choice + Control = Open https:\/\/t.co\/A46WiH3dqW",
  "id" : 719672512775229440,
  "created_at" : "2016-04-11 23:44:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cloud9 IDE",
      "screen_name" : "Cloud9IDE",
      "indices" : [ 0, 10 ],
      "id_str" : "143638554",
      "id" : 143638554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719666806466609153",
  "in_reply_to_user_id" : 143638554,
  "text" : "@Cloud9IDE Is there a non-CLI (Command Line Interface) method to deploy a Cloud9 Workspace to a FTP server? Using a cloned GitHub repo too.",
  "id" : 719666806466609153,
  "created_at" : "2016-04-11 23:21:52 +0000",
  "in_reply_to_screen_name" : "Cloud9IDE",
  "in_reply_to_user_id_str" : "143638554",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/rq0ZKPqLGz",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-04-12-local-vs-cloud-grav-development-with-github",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719657184192167936",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro You've made it into my new post \uD83D\uDE42 https:\/\/t.co\/rq0ZKPqLGz",
  "id" : 719657184192167936,
  "created_at" : "2016-04-11 22:43:37 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 25, 33 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/rq0ZKPqLGz",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-04-12-local-vs-cloud-grav-development-with-github",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719657043078950914",
  "text" : "New Post: Local vs Cloud @getgrav CMS Development with GitHub https:\/\/t.co\/rq0ZKPqLGz",
  "id" : 719657043078950914,
  "created_at" : "2016-04-11 22:43:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 12, 27 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719629384693354497",
  "text" : "RT @btopro: @hibbittsdesign Hubs can be shut down, controlled and have policies changed. Local deployments will always serve the individual",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 0, 15 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "719625825247567872",
    "geo" : { },
    "id_str" : "719628366953848833",
    "in_reply_to_user_id" : 15949844,
    "text" : "@hibbittsdesign Hubs can be shut down, controlled and have policies changed. Local deployments will always serve the individual",
    "id" : 719628366953848833,
    "in_reply_to_status_id" : 719625825247567872,
    "created_at" : "2016-04-11 20:49:07 +0000",
    "in_reply_to_screen_name" : "hibbittsdesign",
    "in_reply_to_user_id_str" : "15949844",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 719629384693354497,
  "created_at" : "2016-04-11 20:53:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719628366953848833",
  "geo" : { },
  "id_str" : "719629362174119936",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Really good feedback, thanks!!",
  "id" : 719629362174119936,
  "in_reply_to_status_id" : 719628366953848833,
  "created_at" : "2016-04-11 20:53:04 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719625825247567872",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Having your Course Hub run on your own computer seems to be the most comforting approach to me, can I even use that word???",
  "id" : 719625825247567872,
  "created_at" : "2016-04-11 20:39:01 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719624915385655297",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Do you have any thoughts re: local dev server (with desktop editing) vs. cloud IDE for Faculty? I can see pros and cons with each...",
  "id" : 719624915385655297,
  "created_at" : "2016-04-11 20:35:24 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719622154443067392",
  "geo" : { },
  "id_str" : "719623391150415872",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro While my recommended Grav setups are more involved than I'd like, both result in one-tap updates\/sync + server deployments - BOYAA!",
  "id" : 719623391150415872,
  "in_reply_to_status_id" : 719622154443067392,
  "created_at" : "2016-04-11 20:29:21 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719620869195112453",
  "geo" : { },
  "id_str" : "719621355163881472",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Less so if Faculty can directly shape that same structure? Placing more control with students and faculty is where I want to go.",
  "id" : 719621355163881472,
  "in_reply_to_status_id" : 719620869195112453,
  "created_at" : "2016-04-11 20:21:15 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719619047864672256",
  "geo" : { },
  "id_str" : "719620386309033984",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Like where you're going \uD83D\uDE42  Would love to empower faculty with fewer steps in the future \uD83D\uDC4D  As close to zero-effort as possible!",
  "id" : 719620386309033984,
  "in_reply_to_status_id" : 719619047864672256,
  "created_at" : "2016-04-11 20:17:24 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 59, 67 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 91, 98 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Buddy",
      "screen_name" : "BuddyGit",
      "indices" : [ 111, 120 ],
      "id_str" : "3055936108",
      "id" : 3055936108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/8XvJWQb7Ts",
      "expanded_url" : "https:\/\/workflowy.com\/s\/p77z7GMA6H",
      "display_url" : "workflowy.com\/s\/p77z7GMA6H"
    } ]
  },
  "geo" : { },
  "id_str" : "719617763849805824",
  "text" : "For comparison, here is what a local (desktop) + Webserver @getgrav setup looks like using @github, MAMP &amp; @BuddyGit https:\/\/t.co\/8XvJWQb7Ts",
  "id" : 719617763849805824,
  "created_at" : "2016-04-11 20:06:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 58, 66 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 84, 91 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "SourceLair",
      "screen_name" : "sourcelair",
      "indices" : [ 93, 104 ],
      "id_str" : "244491121",
      "id" : 244491121
    }, {
      "name" : "Buddy",
      "screen_name" : "BuddyGit",
      "indices" : [ 111, 120 ],
      "id_str" : "3055936108",
      "id" : 3055936108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/eZh3ldx7a7",
      "expanded_url" : "https:\/\/workflowy.com\/s\/ftuwGM6Dvf",
      "display_url" : "workflowy.com\/s\/ftuwGM6Dvf"
    } ]
  },
  "geo" : { },
  "id_str" : "719616595975217152",
  "text" : "Documenting a cloud (online) only setup + workflow for my @getgrav Course Hub using @github, @sourcelair &amp; @BuddyGit https:\/\/t.co\/eZh3ldx7a7",
  "id" : 719616595975217152,
  "created_at" : "2016-04-11 20:02:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 88, 94 ]
    }, {
      "text" : "bcpse",
      "indices" : [ 95, 101 ]
    }, {
      "text" : "teaching",
      "indices" : [ 102, 111 ]
    }, {
      "text" : "learning",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/r1ZsGTGJjB",
      "expanded_url" : "http:\/\/ow.ly\/10qajm",
      "display_url" : "ow.ly\/10qajm"
    } ]
  },
  "geo" : { },
  "id_str" : "719551365987471360",
  "text" : "RT @BCcampus: The Festival of Learning, come celebrate with us! https:\/\/t.co\/r1ZsGTGJjB #FoL16 #bcpse #teaching #learning",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 74, 80 ]
      }, {
        "text" : "bcpse",
        "indices" : [ 81, 87 ]
      }, {
        "text" : "teaching",
        "indices" : [ 88, 97 ]
      }, {
        "text" : "learning",
        "indices" : [ 98, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/r1ZsGTGJjB",
        "expanded_url" : "http:\/\/ow.ly\/10qajm",
        "display_url" : "ow.ly\/10qajm"
      } ]
    },
    "geo" : { },
    "id_str" : "719550726633099264",
    "text" : "The Festival of Learning, come celebrate with us! https:\/\/t.co\/r1ZsGTGJjB #FoL16 #bcpse #teaching #learning",
    "id" : 719550726633099264,
    "created_at" : "2016-04-11 15:40:36 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 719551365987471360,
  "created_at" : "2016-04-11 15:43:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Coolidge",
      "screen_name" : "acoolidge",
      "indices" : [ 3, 13 ],
      "id_str" : "17416175",
      "id" : 17416175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oer",
      "indices" : [ 81, 85 ]
    }, {
      "text" : "opentextbooks",
      "indices" : [ 86, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/W3ldc0Wzg0",
      "expanded_url" : "http:\/\/bit.ly\/22mDgrl",
      "display_url" : "bit.ly\/22mDgrl"
    } ]
  },
  "geo" : { },
  "id_str" : "719249062164172801",
  "text" : "RT @acoolidge: Thoughts on the blog: Open as a Practice https:\/\/t.co\/W3ldc0Wzg0  #oer #opentextbooks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oer",
        "indices" : [ 66, 70 ]
      }, {
        "text" : "opentextbooks",
        "indices" : [ 71, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/W3ldc0Wzg0",
        "expanded_url" : "http:\/\/bit.ly\/22mDgrl",
        "display_url" : "bit.ly\/22mDgrl"
      } ]
    },
    "geo" : { },
    "id_str" : "719237324731625472",
    "text" : "Thoughts on the blog: Open as a Practice https:\/\/t.co\/W3ldc0Wzg0  #oer #opentextbooks",
    "id" : 719237324731625472,
    "created_at" : "2016-04-10 18:55:15 +0000",
    "user" : {
      "name" : "Amanda Coolidge",
      "screen_name" : "acoolidge",
      "protected" : false,
      "id_str" : "17416175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674352077020073984\/88hyOiSP_normal.jpg",
      "id" : 17416175,
      "verified" : false
    }
  },
  "id" : 719249062164172801,
  "created_at" : "2016-04-10 19:41:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/718831187075080192\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/MUh1Gd3oSX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfnNJ6tUIAAI8dd.jpg",
      "id_str" : "718831185804140544",
      "id" : 718831185804140544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfnNJ6tUIAAI8dd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MUh1Gd3oSX"
    } ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/9PFedwpqcF",
      "expanded_url" : "https:\/\/getgrav.org\/downloads\/skeletons",
      "display_url" : "getgrav.org\/downloads\/skel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718831187075080192",
  "text" : "It's a weekend 1-dot-oh! My Course Hub Skeleton for Grav CMS is now available at https:\/\/t.co\/9PFedwpqcF #GravEdu https:\/\/t.co\/MUh1Gd3oSX",
  "id" : 718831187075080192,
  "created_at" : "2016-04-09 16:01:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/718593372500283392\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/zCVEtLeScC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfj03UPUsAAcFdT.jpg",
      "id_str" : "718593371728556032",
      "id" : 718593371728556032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfj03UPUsAAcFdT.jpg",
      "sizes" : [ {
        "h" : 298,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 299,
        "resize" : "fit",
        "w" : 602
      }, {
        "h" : 299,
        "resize" : "fit",
        "w" : 602
      }, {
        "h" : 169,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zCVEtLeScC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718593372500283392",
  "text" : "Here are more details about this possible new Grav CMS workflow for fellow instructors to use with Grav Course Hub. https:\/\/t.co\/zCVEtLeScC",
  "id" : 718593372500283392,
  "created_at" : "2016-04-09 00:16:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 4, 12 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "SourceLair",
      "screen_name" : "sourcelair",
      "indices" : [ 96, 107 ],
      "id_str" : "244491121",
      "id" : 244491121
    }, {
      "name" : "Buddy",
      "screen_name" : "BuddyGit",
      "indices" : [ 131, 140 ],
      "id_str" : "3055936108",
      "id" : 3055936108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718589634079363073",
  "text" : "New @getgrav dev\/prod server setup + workflow? \nCourse Hub Skeleton \u27A4 GitHub repo\nGitHub repo \u27A4 @sourcelair CloudIDE\nAuto deploy w @BuddyGit",
  "id" : 718589634079363073,
  "created_at" : "2016-04-09 00:01:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 9, 17 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/718569606227472384\/photo\/1",
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/7hxpsl1Imj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfjfP8mUEAAqrW8.png",
      "id_str" : "718569605623451648",
      "id" : 718569605623451648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfjfP8mUEAAqrW8.png",
      "sizes" : [ {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 947,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 814,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7hxpsl1Imj"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/718569606227472384\/photo\/1",
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/7hxpsl1Imj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfjfPatUsAAwNi-.png",
      "id_str" : "718569596526047232",
      "id" : 718569596526047232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfjfPatUsAAwNi-.png",
      "sizes" : [ {
        "h" : 814,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 947,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7hxpsl1Imj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718569606227472384",
  "text" : "With the @getgrav Course Hub package there can be 2 interfaces to your materials: a multi-device Website &amp; GitHub. \uD83D\uDE4C https:\/\/t.co\/7hxpsl1Imj",
  "id" : 718569606227472384,
  "created_at" : "2016-04-08 22:41:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SourceLair",
      "screen_name" : "sourcelair",
      "indices" : [ 106, 117 ],
      "id_str" : "244491121",
      "id" : 244491121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718548265533202432",
  "text" : "Still looking for a Cloud IDE with:\n\u2713 One-tap GitHub commit\/sync\n\u2713 One-tap FTP deployment\nAny candidates? @sourcelair is the closest so far",
  "id" : 718548265533202432,
  "created_at" : "2016-04-08 21:17:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718529484186497024",
  "text" : "So exciting to see that my open source project can not only generate income for myself, but for others as well. Sustainable open design FTW.",
  "id" : 718529484186497024,
  "created_at" : "2016-04-08 20:02:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 12, 20 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "SmartGravity",
      "screen_name" : "smartgravity",
      "indices" : [ 56, 69 ],
      "id_str" : "46856872",
      "id" : 46856872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718528713378242560",
  "text" : "Looking for @getgrav custom theme development services? @smartgravity did an amazing job visually branding my Course Hub for a local client.",
  "id" : 718528713378242560,
  "created_at" : "2016-04-08 19:59:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Gerdeen",
      "screen_name" : "njerd",
      "indices" : [ 3, 9 ],
      "id_str" : "19150160",
      "id" : 19150160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HyperCard",
      "indices" : [ 75, 85 ]
    }, {
      "text" : "LiveCode",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/VVSBG0x5Dp",
      "expanded_url" : "https:\/\/twit.tv\/shows\/triangulation",
      "display_url" : "twit.tv\/shows\/triangul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718476772388397056",
  "text" : "RT @njerd: Great episode with Bill Atkinson and history of Apple including #HyperCard. #LiveCode today. Triangulation | TWiT https:\/\/t.co\/V\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HyperCard",
        "indices" : [ 64, 74 ]
      }, {
        "text" : "LiveCode",
        "indices" : [ 76, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/VVSBG0x5Dp",
        "expanded_url" : "https:\/\/twit.tv\/shows\/triangulation",
        "display_url" : "twit.tv\/shows\/triangul\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717077662167142401",
    "text" : "Great episode with Bill Atkinson and history of Apple including #HyperCard. #LiveCode today. Triangulation | TWiT https:\/\/t.co\/VVSBG0x5Dp",
    "id" : 717077662167142401,
    "created_at" : "2016-04-04 19:53:31 +0000",
    "user" : {
      "name" : "Joel Gerdeen",
      "screen_name" : "njerd",
      "protected" : false,
      "id_str" : "19150160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718499338465378305\/VqjO-JFx_normal.jpg",
      "id" : 19150160,
      "verified" : false
    }
  },
  "id" : 718476772388397056,
  "created_at" : "2016-04-08 16:33:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 83, 91 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718248814541434881",
  "text" : "Collaborating with an educator via GitHub to help with content AND behavior of his @getgrav Course Hub site \uD83D\uDC4D . Just try that with an LMS!",
  "id" : 718248814541434881,
  "created_at" : "2016-04-08 01:27:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Robinson",
      "screen_name" : "krob",
      "indices" : [ 0, 5 ],
      "id_str" : "1069802168",
      "id" : 1069802168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718112827702165504",
  "geo" : { },
  "id_str" : "718113589807022081",
  "in_reply_to_user_id" : 1069802168,
  "text" : "@krob Not specifically, as I've always included GitHub Desktop &amp; Grav in my workflow articles. This might be a possible future blog post \uD83D\uDE42",
  "id" : 718113589807022081,
  "in_reply_to_status_id" : 718112827702165504,
  "created_at" : "2016-04-07 16:29:56 +0000",
  "in_reply_to_screen_name" : "krob",
  "in_reply_to_user_id_str" : "1069802168",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 26, 34 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718111606601691136",
  "text" : "With a flat-file CMS (eg. @getgrav) stored on GitHub, educators can directly help other educators with their on-line course spaces. #GravEdu",
  "id" : 718111606601691136,
  "created_at" : "2016-04-07 16:22:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buddy",
      "screen_name" : "BuddyGit",
      "indices" : [ 0, 9 ],
      "id_str" : "3055936108",
      "id" : 3055936108
    }, {
      "name" : "GitLab",
      "screen_name" : "gitlab",
      "indices" : [ 10, 17 ],
      "id_str" : "390167291",
      "id" : 390167291
    }, {
      "name" : "Buddy",
      "screen_name" : "BuddyGit",
      "indices" : [ 18, 27 ],
      "id_str" : "3055936108",
      "id" : 3055936108
    }, {
      "name" : "GitLab",
      "screen_name" : "gitlab",
      "indices" : [ 28, 35 ],
      "id_str" : "390167291",
      "id" : 390167291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718021433738326016",
  "geo" : { },
  "id_str" : "718104461051191296",
  "in_reply_to_user_id" : 3055936108,
  "text" : "@BuddyGit @gitlab @BuddyGit @gitlab Awesome news, congrats! Will GitLab on your own server work to?",
  "id" : 718104461051191296,
  "in_reply_to_status_id" : 718021433738326016,
  "created_at" : "2016-04-07 15:53:39 +0000",
  "in_reply_to_screen_name" : "BuddyGit",
  "in_reply_to_user_id_str" : "3055936108",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 3, 15 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    }, {
      "name" : "Kenton Varda",
      "screen_name" : "KentonVarda",
      "indices" : [ 102, 114 ],
      "id_str" : "17459118",
      "id" : 17459118
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SandstormIO\/status\/717766267311095808\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/DPpNw1warz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfYEnevUUAA2cA-.jpg",
      "id_str" : "717766266925109248",
      "id" : 717766266925109248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfYEnevUUAA2cA-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DPpNw1warz"
    } ],
    "hashtags" : [ {
      "text" : "selfhost",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/ioNTnzOvRd",
      "expanded_url" : "https:\/\/sandstorm.io\/news\/2016-04-06-sandstorm-for-work",
      "display_url" : "sandstorm.io\/news\/2016-04-0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717869618560245761",
  "text" : "RT @SandstormIO: Sandstorm for Work Beta: LDAP, SAML, organization management https:\/\/t.co\/ioNTnzOvRd @KentonVarda #selfhost https:\/\/t.co\/D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kenton Varda",
        "screen_name" : "KentonVarda",
        "indices" : [ 85, 97 ],
        "id_str" : "17459118",
        "id" : 17459118
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SandstormIO\/status\/717766267311095808\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/DPpNw1warz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfYEnevUUAA2cA-.jpg",
        "id_str" : "717766266925109248",
        "id" : 717766266925109248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfYEnevUUAA2cA-.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DPpNw1warz"
      } ],
      "hashtags" : [ {
        "text" : "selfhost",
        "indices" : [ 98, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/ioNTnzOvRd",
        "expanded_url" : "https:\/\/sandstorm.io\/news\/2016-04-06-sandstorm-for-work",
        "display_url" : "sandstorm.io\/news\/2016-04-0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717766267311095808",
    "text" : "Sandstorm for Work Beta: LDAP, SAML, organization management https:\/\/t.co\/ioNTnzOvRd @KentonVarda #selfhost https:\/\/t.co\/DPpNw1warz",
    "id" : 717766267311095808,
    "created_at" : "2016-04-06 17:29:48 +0000",
    "user" : {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "protected" : false,
      "id_str" : "2476570038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463413707150589952\/s17ccuOO_normal.png",
      "id" : 2476570038,
      "verified" : false
    }
  },
  "id" : 717869618560245761,
  "created_at" : "2016-04-07 00:20:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Mark Bullen)))",
      "screen_name" : "markbullen",
      "indices" : [ 0, 11 ],
      "id_str" : "14080697",
      "id" : 14080697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717799316593618944",
  "geo" : { },
  "id_str" : "717804792039387136",
  "in_reply_to_user_id" : 14080697,
  "text" : "@markbullen Thanks very much Mark, my pleasure!",
  "id" : 717804792039387136,
  "in_reply_to_status_id" : 717799316593618944,
  "created_at" : "2016-04-06 20:02:53 +0000",
  "in_reply_to_screen_name" : "markbullen",
  "in_reply_to_user_id_str" : "14080697",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FastComet",
      "screen_name" : "FastCometCloud",
      "indices" : [ 3, 18 ],
      "id_str" : "2775689878",
      "id" : 2775689878
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 88, 96 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FastCometCloud\/status\/717376387385008132\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/m9Y6fmOlGx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfSiBcTUYAE3zT0.jpg",
      "id_str" : "717376386319540225",
      "id" : 717376386319540225,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfSiBcTUYAE3zT0.jpg",
      "sizes" : [ {
        "h" : 279,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 146,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 279,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/m9Y6fmOlGx"
    } ],
    "hashtags" : [ {
      "text" : "tutorials",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/47D6SEGhDn",
      "expanded_url" : "http:\/\/bit.ly\/1W9G0Zi",
      "display_url" : "bit.ly\/1W9G0Zi"
    } ]
  },
  "geo" : { },
  "id_str" : "717781174844678144",
  "text" : "RT @FastCometCloud: Build faster and more flexible websites by using our #tutorials and @getgrav CMS - https:\/\/t.co\/47D6SEGhDn https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 68, 76 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FastCometCloud\/status\/717376387385008132\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/m9Y6fmOlGx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfSiBcTUYAE3zT0.jpg",
        "id_str" : "717376386319540225",
        "id" : 717376386319540225,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfSiBcTUYAE3zT0.jpg",
        "sizes" : [ {
          "h" : 279,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 146,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 279,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 258,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/m9Y6fmOlGx"
      } ],
      "hashtags" : [ {
        "text" : "tutorials",
        "indices" : [ 53, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/47D6SEGhDn",
        "expanded_url" : "http:\/\/bit.ly\/1W9G0Zi",
        "display_url" : "bit.ly\/1W9G0Zi"
      } ]
    },
    "geo" : { },
    "id_str" : "717376387385008132",
    "text" : "Build faster and more flexible websites by using our #tutorials and @getgrav CMS - https:\/\/t.co\/47D6SEGhDn https:\/\/t.co\/m9Y6fmOlGx",
    "id" : 717376387385008132,
    "created_at" : "2016-04-05 15:40:33 +0000",
    "user" : {
      "name" : "FastComet",
      "screen_name" : "FastCometCloud",
      "protected" : false,
      "id_str" : "2775689878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598825274449334272\/gicGnKZ__normal.jpg",
      "id" : 2775689878,
      "verified" : false
    }
  },
  "id" : 717781174844678144,
  "created_at" : "2016-04-06 18:29:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 0, 8 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717551897842831360",
  "geo" : { },
  "id_str" : "717552422776758272",
  "in_reply_to_user_id" : 10185562,
  "text" : "@drchuck No I have not, thanks very much for sharing it!",
  "id" : 717552422776758272,
  "in_reply_to_status_id" : 717551897842831360,
  "created_at" : "2016-04-06 03:20:03 +0000",
  "in_reply_to_screen_name" : "drchuck",
  "in_reply_to_user_id_str" : "10185562",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717550602746638336",
  "text" : "The difference between an open source 'project' vs. open source 'product' is still murky to me.",
  "id" : 717550602746638336,
  "created_at" : "2016-04-06 03:12:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717550149304627200",
  "text" : "Bit-by-bit, figuratively and literally, I am changing Hibbitts Design from a professional UX consulting co. to an open source project co.",
  "id" : 717550149304627200,
  "created_at" : "2016-04-06 03:11:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Human Future Design",
      "screen_name" : "Humanfuturedsgn",
      "indices" : [ 3, 19 ],
      "id_str" : "4062565210",
      "id" : 4062565210
    }, {
      "name" : "Laura Klein",
      "screen_name" : "lauraklein",
      "indices" : [ 122, 133 ],
      "id_str" : "14804195",
      "id" : 14804195
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Humanfuturedsgn\/status\/717401791294349313\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/eXMslraPLA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfS5IEqVAAAWxcO.jpg",
      "id_str" : "717401789000122368",
      "id" : 717401789000122368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfS5IEqVAAAWxcO.jpg",
      "sizes" : [ {
        "h" : 298,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 169,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 956,
        "resize" : "fit",
        "w" : 1922
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 509,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/eXMslraPLA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717536264593879040",
  "text" : "RT @Humanfuturedsgn: \u201CWe should all be advocates for the user in a company, not just the UX team. We should all care.\u201D By @lauraklein https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laura Klein",
        "screen_name" : "lauraklein",
        "indices" : [ 101, 112 ],
        "id_str" : "14804195",
        "id" : 14804195
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Humanfuturedsgn\/status\/717401791294349313\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/eXMslraPLA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfS5IEqVAAAWxcO.jpg",
        "id_str" : "717401789000122368",
        "id" : 717401789000122368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfS5IEqVAAAWxcO.jpg",
        "sizes" : [ {
          "h" : 298,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 169,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 956,
          "resize" : "fit",
          "w" : 1922
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 509,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/eXMslraPLA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717401791294349313",
    "text" : "\u201CWe should all be advocates for the user in a company, not just the UX team. We should all care.\u201D By @lauraklein https:\/\/t.co\/eXMslraPLA",
    "id" : 717401791294349313,
    "created_at" : "2016-04-05 17:21:30 +0000",
    "user" : {
      "name" : "Human Future Design",
      "screen_name" : "Humanfuturedsgn",
      "protected" : false,
      "id_str" : "4062565210",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661924903118086144\/p_FTNCdu_normal.jpg",
      "id" : 4062565210,
      "verified" : false
    }
  },
  "id" : 717536264593879040,
  "created_at" : "2016-04-06 02:15:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/HslYUAUShc",
      "expanded_url" : "http:\/\/cogdogblog.com\/?p=55491",
      "display_url" : "cogdogblog.com\/?p=55491"
    } ]
  },
  "geo" : { },
  "id_str" : "717533188529065985",
  "text" : "RT @cogdog: CogDogBlogged: Fork on the Range: Getting Over the Fear of GitHub Forking https:\/\/t.co\/HslYUAUShc Fork this! Fork this! Fork th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sopresto.mailchimp.com\" rel=\"nofollow\"\u003ESocial Proxy by Mailchimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/HslYUAUShc",
        "expanded_url" : "http:\/\/cogdogblog.com\/?p=55491",
        "display_url" : "cogdogblog.com\/?p=55491"
      } ]
    },
    "geo" : { },
    "id_str" : "717529915671752705",
    "text" : "CogDogBlogged: Fork on the Range: Getting Over the Fear of GitHub Forking https:\/\/t.co\/HslYUAUShc Fork this! Fork this! Fork this?",
    "id" : 717529915671752705,
    "created_at" : "2016-04-06 01:50:37 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 717533188529065985,
  "created_at" : "2016-04-06 02:03:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "V\u00EDtor Galv\u00E3o",
      "screen_name" : "vhgalvao",
      "indices" : [ 0, 9 ],
      "id_str" : "370136412",
      "id" : 370136412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717524711303946242",
  "geo" : { },
  "id_str" : "717526529933074432",
  "in_reply_to_user_id" : 370136412,
  "text" : "@vhgalvao Thank you so much for spotting those typos! I've made the corrections in the deck, thanks again!",
  "id" : 717526529933074432,
  "in_reply_to_status_id" : 717524711303946242,
  "created_at" : "2016-04-06 01:37:10 +0000",
  "in_reply_to_screen_name" : "vhgalvao",
  "in_reply_to_user_id_str" : "370136412",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UX Magazine",
      "screen_name" : "uxmag",
      "indices" : [ 3, 9 ],
      "id_str" : "15056788",
      "id" : 15056788
    }, {
      "name" : "UX Magazine",
      "screen_name" : "uxmag",
      "indices" : [ 26, 32 ],
      "id_str" : "15056788",
      "id" : 15056788
    }, {
      "name" : "Techved Consulting",
      "screen_name" : "Techved",
      "indices" : [ 98, 106 ],
      "id_str" : "48945401",
      "id" : 48945401
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/uxmag\/status\/717103391118389248\/photo\/1",
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/UAKiws6NmQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfOpu_8WwAUdTu0.png",
      "id_str" : "717103390585700357",
      "id" : 717103390585700357,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfOpu_8WwAUdTu0.png",
      "sizes" : [ {
        "h" : 495,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 1482
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 164,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UAKiws6NmQ"
    } ],
    "hashtags" : [ {
      "text" : "Content",
      "indices" : [ 62, 70 ]
    }, {
      "text" : "UX",
      "indices" : [ 107, 110 ]
    }, {
      "text" : "design",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/O2SihZoJjw",
      "expanded_url" : "http:\/\/uxm.ag\/2ju",
      "display_url" : "uxm.ag\/2ju"
    } ]
  },
  "geo" : { },
  "id_str" : "717510729348157441",
  "text" : "RT @uxmag: New article in @uxmag: The User Experience of Good #Content https:\/\/t.co\/O2SihZoJjw by @Techved #UX #design https:\/\/t.co\/UAKiws6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UX Magazine",
        "screen_name" : "uxmag",
        "indices" : [ 15, 21 ],
        "id_str" : "15056788",
        "id" : 15056788
      }, {
        "name" : "Techved Consulting",
        "screen_name" : "Techved",
        "indices" : [ 87, 95 ],
        "id_str" : "48945401",
        "id" : 48945401
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/uxmag\/status\/717103391118389248\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/UAKiws6NmQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfOpu_8WwAUdTu0.png",
        "id_str" : "717103390585700357",
        "id" : 717103390585700357,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfOpu_8WwAUdTu0.png",
        "sizes" : [ {
          "h" : 495,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 1482
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 164,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 290,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/UAKiws6NmQ"
      } ],
      "hashtags" : [ {
        "text" : "Content",
        "indices" : [ 51, 59 ]
      }, {
        "text" : "UX",
        "indices" : [ 96, 99 ]
      }, {
        "text" : "design",
        "indices" : [ 100, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/O2SihZoJjw",
        "expanded_url" : "http:\/\/uxm.ag\/2ju",
        "display_url" : "uxm.ag\/2ju"
      } ]
    },
    "geo" : { },
    "id_str" : "717103391118389248",
    "text" : "New article in @uxmag: The User Experience of Good #Content https:\/\/t.co\/O2SihZoJjw by @Techved #UX #design https:\/\/t.co\/UAKiws6NmQ",
    "id" : 717103391118389248,
    "created_at" : "2016-04-04 21:35:46 +0000",
    "user" : {
      "name" : "UX Magazine",
      "screen_name" : "uxmag",
      "protected" : false,
      "id_str" : "15056788",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227292956\/twitter_logo_normal.png",
      "id" : 15056788,
      "verified" : false
    }
  },
  "id" : 717510729348157441,
  "created_at" : "2016-04-06 00:34:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 0, 13 ],
      "id_str" : "91939908",
      "id" : 91939908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717483952869474304",
  "geo" : { },
  "id_str" : "717486055331463169",
  "in_reply_to_user_id" : 91939908,
  "text" : "@davidnwright Awesome to hear, thank you! I will anxiously await your final verdict \uD83D\uDE42",
  "id" : 717486055331463169,
  "in_reply_to_status_id" : 717483952869474304,
  "created_at" : "2016-04-05 22:56:20 +0000",
  "in_reply_to_screen_name" : "davidnwright",
  "in_reply_to_user_id_str" : "91939908",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/5MCJLrARLE",
      "expanded_url" : "http:\/\/thebaffler.com\/blog\/the-digital-native-a-profitable-myth",
      "display_url" : "thebaffler.com\/blog\/the-digit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717469500854001664",
  "text" : "PREACH: The \u201CDigital Native,\u201D a Profitable Myth https:\/\/t.co\/5MCJLrARLE",
  "id" : 717469500854001664,
  "created_at" : "2016-04-05 21:50:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Mosher",
      "screen_name" : "bmosh",
      "indices" : [ 0, 6 ],
      "id_str" : "21192677",
      "id" : 21192677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717458935943397376",
  "geo" : { },
  "id_str" : "717459717354692609",
  "in_reply_to_user_id" : 21192677,
  "text" : "@bmosh I agree, though I still prefer 'learning' over 'learner'.",
  "id" : 717459717354692609,
  "in_reply_to_status_id" : 717458935943397376,
  "created_at" : "2016-04-05 21:11:41 +0000",
  "in_reply_to_screen_name" : "bmosh",
  "in_reply_to_user_id_str" : "21192677",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/edXT0becz0",
      "expanded_url" : "https:\/\/twitter.com\/barbaraneuhofer\/status\/717063727699386371",
      "display_url" : "twitter.com\/barbaraneuhofe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717444032448765954",
  "text" : "Is the term 'digital native' still a thing? https:\/\/t.co\/edXT0becz0",
  "id" : 717444032448765954,
  "created_at" : "2016-04-05 20:09:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/LkE3VpethO",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-10-29-alternative-to-the-term-learner-experience-design",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717441874768764928",
  "text" : "Updated Post: Alternative to the Term 'Learner Experience Design'? https:\/\/t.co\/LkE3VpethO",
  "id" : 717441874768764928,
  "created_at" : "2016-04-05 20:00:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 0, 8 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717421303326646272",
  "geo" : { },
  "id_str" : "717422135853977600",
  "in_reply_to_user_id" : 2737573033,
  "text" : "@getgrav And I've only just started promoting the awesomeness of Grav in the educational space! \uD83D\uDE09",
  "id" : 717422135853977600,
  "in_reply_to_status_id" : 717421303326646272,
  "created_at" : "2016-04-05 18:42:20 +0000",
  "in_reply_to_screen_name" : "getgrav",
  "in_reply_to_user_id_str" : "2737573033",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 43, 51 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Slides",
      "screen_name" : "slides",
      "indices" : [ 70, 77 ],
      "id_str" : "813740730",
      "id" : 813740730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/o6X46gEvXq",
      "expanded_url" : "https:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717418019060785152",
  "text" : "Well, I really didn't see that coming - my @getgrav CMS for Educators @slides have now over 30,000 views https:\/\/t.co\/o6X46gEvXq",
  "id" : 717418019060785152,
  "created_at" : "2016-04-05 18:25:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 0, 13 ],
      "id_str" : "91939908",
      "id" : 91939908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717407211585024001",
  "in_reply_to_user_id" : 91939908,
  "text" : "@davidnwright Just checking-in with you about your Grav Course Hub experience so far... questions or comments more than welcome!",
  "id" : 717407211585024001,
  "created_at" : "2016-04-05 17:43:02 +0000",
  "in_reply_to_screen_name" : "davidnwright",
  "in_reply_to_user_id_str" : "91939908",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/6eSLXDPno4",
      "expanded_url" : "http:\/\/gravcoursehub.org",
      "display_url" : "gravcoursehub.org"
    } ]
  },
  "geo" : { },
  "id_str" : "717401625602580480",
  "text" : "Prototyping a few ideas in the open of a landing page for the Grav Course Hub project - https:\/\/t.co\/6eSLXDPno4. Oh, and built with Grav \uD83D\uDE09",
  "id" : 717401625602580480,
  "created_at" : "2016-04-05 17:20:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 16, 21 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 41, 49 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 108, 115 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/fyUjYiPDBI",
      "expanded_url" : "https:\/\/etug.ca\/2016\/03\/30\/t-e-l-l-march-summary-flip-it-good-flipping-the-lms-with-an-open-and-collaborative-platform\/",
      "display_url" : "etug.ca\/2016\/03\/30\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717392968689197058",
  "text" : "Recording of my @etug TELL session about @getgrav as a flipped LMS is now online (incl. guest appearance by @btopro) https:\/\/t.co\/fyUjYiPDBI",
  "id" : 717392968689197058,
  "created_at" : "2016-04-05 16:46:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 24, 32 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 65, 80 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/btopro\/status\/717367266883596288\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/o383LR6wLx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfSZunOWsAATCjq.jpg",
      "id_str" : "717367266740973568",
      "id" : 717367266740973568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfSZunOWsAATCjq.jpg",
      "sizes" : [ {
        "h" : 175,
        "resize" : "fit",
        "w" : 884
      }, {
        "h" : 67,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 175,
        "resize" : "fit",
        "w" : 884
      }, {
        "h" : 119,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/o383LR6wLx"
    } ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 81, 88 ]
    }, {
      "text" : "NGDLE",
      "indices" : [ 89, 95 ]
    }, {
      "text" : "lms",
      "indices" : [ 96, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717377724885565444",
  "text" : "RT @btopro: my email to @drchuck that can\u2019t get lost in an inbox @hibbittsdesign #edtech #NGDLE #lms https:\/\/t.co\/o383LR6wLx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "drchuck",
        "screen_name" : "drchuck",
        "indices" : [ 12, 20 ],
        "id_str" : "10185562",
        "id" : 10185562
      }, {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 53, 68 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/btopro\/status\/717367266883596288\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/o383LR6wLx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfSZunOWsAATCjq.jpg",
        "id_str" : "717367266740973568",
        "id" : 717367266740973568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfSZunOWsAATCjq.jpg",
        "sizes" : [ {
          "h" : 175,
          "resize" : "fit",
          "w" : 884
        }, {
          "h" : 67,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 175,
          "resize" : "fit",
          "w" : 884
        }, {
          "h" : 119,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/o383LR6wLx"
      } ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 69, 76 ]
      }, {
        "text" : "NGDLE",
        "indices" : [ 77, 83 ]
      }, {
        "text" : "lms",
        "indices" : [ 84, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717367266883596288",
    "text" : "my email to @drchuck that can\u2019t get lost in an inbox @hibbittsdesign #edtech #NGDLE #lms https:\/\/t.co\/o383LR6wLx",
    "id" : 717367266883596288,
    "created_at" : "2016-04-05 15:04:19 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 717377724885565444,
  "created_at" : "2016-04-05 15:45:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/tKK7zm3AMv",
      "expanded_url" : "https:\/\/twitter.com\/jopas\/status\/515301088660959233",
      "display_url" : "twitter.com\/jopas\/status\/5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717087591867154432",
  "text" : "My favorite MVP visualization for the past while too. https:\/\/t.co\/tKK7zm3AMv",
  "id" : 717087591867154432,
  "created_at" : "2016-04-04 20:32:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 48, 56 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/717058200764178432\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/LCveD6zqA0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfOAokxVIAEQbsJ.jpg",
      "id_str" : "717058200235745281",
      "id" : 717058200235745281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfOAokxVIAEQbsJ.jpg",
      "sizes" : [ {
        "h" : 541,
        "resize" : "fit",
        "w" : 1243
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 148,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LCveD6zqA0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717058200764178432",
  "text" : "Working on summarizing the top 3 features of my @getgrav Course Hub - any comments or feedback my fellow educators? https:\/\/t.co\/LCveD6zqA0",
  "id" : 717058200764178432,
  "created_at" : "2016-04-04 18:36:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/fyUjYiPDBI",
      "expanded_url" : "https:\/\/etug.ca\/2016\/03\/30\/t-e-l-l-march-summary-flip-it-good-flipping-the-lms-with-an-open-and-collaborative-platform\/",
      "display_url" : "etug.ca\/2016\/03\/30\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716740947699113984",
  "text" : "Are you a tech-savvy educator who wants control of an open platform to reach unmet pedagogical goals w. LMS backend? https:\/\/t.co\/fyUjYiPDBI",
  "id" : 716740947699113984,
  "created_at" : "2016-04-03 21:35:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716740399969120258",
  "text" : "(2\/2) Main reasons for modern flat-file CMS vs. DB CMS:\n\u2713Open &amp; collaborative ecosystem (i.e. GitHub)\n\u2713Pliability\n\u2713Portability\n\u2713Simplicity",
  "id" : 716740399969120258,
  "created_at" : "2016-04-03 21:33:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 55, 63 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716740335771078656",
  "text" : "(1\/2) My viewpoint: in 2016 a modern flat-file CMS (eg @getgrav) is better suited to individual educators than a database CMS (eg WordPress)",
  "id" : 716740335771078656,
  "created_at" : "2016-04-03 21:33:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 0, 5 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 6, 15 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "Brett Griffiths",
      "screen_name" : "brettgri",
      "indices" : [ 55, 64 ],
      "id_str" : "32252744",
      "id" : 32252744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716336166098743296",
  "geo" : { },
  "id_str" : "716343065770745857",
  "in_reply_to_user_id" : 17102936,
  "text" : "@etug @BCcampus Thanks very much for the great summary @brettgri!",
  "id" : 716343065770745857,
  "in_reply_to_status_id" : 716336166098743296,
  "created_at" : "2016-04-02 19:14:30 +0000",
  "in_reply_to_screen_name" : "etug",
  "in_reply_to_user_id_str" : "17102936",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Brett Griffiths",
      "screen_name" : "brettgri",
      "indices" : [ 44, 53 ],
      "id_str" : "32252744",
      "id" : 32252744
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 57, 72 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 132, 140 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 14, 19 ]
    }, {
      "text" : "proflearn",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/IqD5PjJvk4",
      "expanded_url" : "http:\/\/bit.ly\/22ZjQ1g",
      "display_url" : "bit.ly\/22ZjQ1g"
    } ]
  },
  "geo" : { },
  "id_str" : "716342762522550273",
  "text" : "RT @etug: New #etug post! A Tell summary by @brettgri on @hibbittsdesign \"Flip it Good!\" session https:\/\/t.co\/IqD5PjJvk4 #proflearn @BCcamp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brett Griffiths",
        "screen_name" : "brettgri",
        "indices" : [ 34, 43 ],
        "id_str" : "32252744",
        "id" : 32252744
      }, {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 47, 62 ],
        "id_str" : "15949844",
        "id" : 15949844
      }, {
        "name" : "BCcampus",
        "screen_name" : "BCcampus",
        "indices" : [ 122, 131 ],
        "id_str" : "93710949",
        "id" : 93710949
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 4, 9 ]
      }, {
        "text" : "proflearn",
        "indices" : [ 111, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/IqD5PjJvk4",
        "expanded_url" : "http:\/\/bit.ly\/22ZjQ1g",
        "display_url" : "bit.ly\/22ZjQ1g"
      } ]
    },
    "geo" : { },
    "id_str" : "716336166098743296",
    "text" : "New #etug post! A Tell summary by @brettgri on @hibbittsdesign \"Flip it Good!\" session https:\/\/t.co\/IqD5PjJvk4 #proflearn @BCcampus",
    "id" : 716336166098743296,
    "created_at" : "2016-04-02 18:47:05 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 716342762522550273,
  "created_at" : "2016-04-02 19:13:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/lkOVFQomAI",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-04-04-using-github-desktop-and-gitlab-with-Grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716028208223641601",
  "text" : "It's no joke, but a Friday afternoon sneak peek of my upcoming blog post 'Using GitHub Desktop and GitLab with Grav' https:\/\/t.co\/lkOVFQomAI",
  "id" : 716028208223641601,
  "created_at" : "2016-04-01 22:23:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitLab",
      "screen_name" : "gitlab",
      "indices" : [ 114, 121 ],
      "id_str" : "390167291",
      "id" : 390167291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716002126896431104",
  "text" : "Due to popular demand from higher ed colleagues, I am working on a step-by-step guide of GitHub Desktop + a local @gitlab install with Grav.",
  "id" : 716002126896431104,
  "created_at" : "2016-04-01 20:39:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715960367357304832",
  "text" : "One of the great things about an open source product is you can engage with your audience and not have 'sales' be a required talking point.",
  "id" : 715960367357304832,
  "created_at" : "2016-04-01 17:53:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Schiller",
      "screen_name" : "pschiller",
      "indices" : [ 3, 13 ],
      "id_str" : "17104751",
      "id" : 17104751
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/pschiller\/status\/715799080664961028\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/0eqJKfymqM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce8HeKGXEAAbMat.jpg",
      "id_str" : "715799080463699968",
      "id" : 715799080463699968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce8HeKGXEAAbMat.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0eqJKfymqM"
    } ],
    "hashtags" : [ {
      "text" : "Apple",
      "indices" : [ 54, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715953825828352000",
  "text" : "RT @pschiller: 40 insanely great years\nHappy birthday #Apple https:\/\/t.co\/0eqJKfymqM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/pschiller\/status\/715799080664961028\/photo\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/0eqJKfymqM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce8HeKGXEAAbMat.jpg",
        "id_str" : "715799080463699968",
        "id" : 715799080463699968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce8HeKGXEAAbMat.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/0eqJKfymqM"
      } ],
      "hashtags" : [ {
        "text" : "Apple",
        "indices" : [ 39, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "715799080664961028",
    "text" : "40 insanely great years\nHappy birthday #Apple https:\/\/t.co\/0eqJKfymqM",
    "id" : 715799080664961028,
    "created_at" : "2016-04-01 07:12:54 +0000",
    "user" : {
      "name" : "Philip Schiller",
      "screen_name" : "pschiller",
      "protected" : false,
      "id_str" : "17104751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755268949017698304\/TDhoXK3l_normal.jpg",
      "id" : 17104751,
      "verified" : true
    }
  },
  "id" : 715953825828352000,
  "created_at" : "2016-04-01 17:27:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 0, 13 ],
      "id_str" : "91939908",
      "id" : 91939908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/0hMjBmpDwD",
      "expanded_url" : "https:\/\/gitter.im\/hibbitts-design\/grav-skeleton-course-hub",
      "display_url" : "gitter.im\/hibbitts-desig\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "715800259285368832",
  "geo" : { },
  "id_str" : "715935873821335553",
  "in_reply_to_user_id" : 91939908,
  "text" : "@davidnwright Great to hear David! Let me know if I can help, and the new Gitter chat room is https:\/\/t.co\/0hMjBmpDwD (GitHub account req.)",
  "id" : 715935873821335553,
  "in_reply_to_status_id" : 715800259285368832,
  "created_at" : "2016-04-01 16:16:28 +0000",
  "in_reply_to_screen_name" : "davidnwright",
  "in_reply_to_user_id_str" : "91939908",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]