Grailbird.data.tweets_2015_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Burton",
      "screen_name" : "swirlOsquirrel",
      "indices" : [ 3, 18 ],
      "id_str" : "454900582",
      "id" : 454900582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605203763343654913",
  "text" : "RT @swirlOsquirrel: Mac prod launch: 7 men,\n4 women. None of the women are in Jobs movie. They're not even cast. Every man is in the film w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "604700446360412160",
    "text" : "Mac prod launch: 7 men,\n4 women. None of the women are in Jobs movie. They're not even cast. Every man is in the film with a speaking role.",
    "id" : 604700446360412160,
    "created_at" : "2015-05-30 17:26:35 +0000",
    "user" : {
      "name" : "Lucy Burton",
      "screen_name" : "swirlOsquirrel",
      "protected" : false,
      "id_str" : "454900582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487674402721374208\/PuUVk_Cn_normal.png",
      "id" : 454900582,
      "verified" : false
    }
  },
  "id" : 605203763343654913,
  "created_at" : "2015-06-01 02:46:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "slides",
      "indices" : [ 0, 7 ],
      "id_str" : "813740730",
      "id" : 813740730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605055371389091840",
  "geo" : { },
  "id_str" : "605058375840231424",
  "in_reply_to_user_id" : 813740730,
  "text" : "@slides Thanks very much, sent you the details for the deck.",
  "id" : 605058375840231424,
  "in_reply_to_status_id" : 605055371389091840,
  "created_at" : "2015-05-31 17:08:52 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "slides",
      "indices" : [ 0, 7 ],
      "id_str" : "813740730",
      "id" : 813740730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604962760867364864",
  "geo" : { },
  "id_str" : "605017410517659648",
  "in_reply_to_user_id" : 813740730,
  "text" : "@slides Chrome and also tried Firefox. Used revision history in the end. Issues seen in history, how to share with you privately?",
  "id" : 605017410517659648,
  "in_reply_to_status_id" : 604962760867364864,
  "created_at" : "2015-05-31 14:26:06 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "slides",
      "indices" : [ 0, 7 ],
      "id_str" : "813740730",
      "id" : 813740730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604804691449348097",
  "in_reply_to_user_id" : 813740730,
  "text" : "@slides Also caused lots of blank lines to be inserted, and images seemed to shrink. I am manually trying to correct revisions now...",
  "id" : 604804691449348097,
  "created_at" : "2015-05-31 00:20:49 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "slides",
      "indices" : [ 0, 7 ],
      "id_str" : "813740730",
      "id" : 813740730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604804152745558017",
  "in_reply_to_user_id" : 813740730,
  "text" : "@slides Changed text box on 2nd slide to list and for some reason ALL text boxes on ALL slides were changes to lists as well. Known issue?",
  "id" : 604804152745558017,
  "created_at" : "2015-05-31 00:18:41 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 3, 15 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/openroadies\/status\/604379583685775361\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ifSsgi4JEK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGMwB2iXEAAkgch.png",
      "id_str" : "604379583375413248",
      "id" : 604379583375413248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGMwB2iXEAAkgch.png",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 691
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 691
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 313,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ifSsgi4JEK"
    } ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 122, 127 ]
    }, {
      "text" : "yvr",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/VtvyH3E7J8",
      "expanded_url" : "http:\/\/ow.ly\/NCxFy",
      "display_url" : "ow.ly\/NCxFy"
    } ]
  },
  "geo" : { },
  "id_str" : "604387491458596864",
  "text" : "RT @openroadies: We\u2019re looking for a full stack web developer to become a vital part of our team. http:\/\/t.co\/VtvyH3E7J8  #jobs #yvr http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/openroadies\/status\/604379583685775361\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/ifSsgi4JEK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGMwB2iXEAAkgch.png",
        "id_str" : "604379583375413248",
        "id" : 604379583375413248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGMwB2iXEAAkgch.png",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 691
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 691
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 313,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ifSsgi4JEK"
      } ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 105, 110 ]
      }, {
        "text" : "yvr",
        "indices" : [ 111, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/VtvyH3E7J8",
        "expanded_url" : "http:\/\/ow.ly\/NCxFy",
        "display_url" : "ow.ly\/NCxFy"
      } ]
    },
    "geo" : { },
    "id_str" : "604379583685775361",
    "text" : "We\u2019re looking for a full stack web developer to become a vital part of our team. http:\/\/t.co\/VtvyH3E7J8  #jobs #yvr http:\/\/t.co\/ifSsgi4JEK",
    "id" : 604379583685775361,
    "created_at" : "2015-05-29 20:11:36 +0000",
    "user" : {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "protected" : false,
      "id_str" : "66913866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554783440747237376\/HA2Svg4h_normal.png",
      "id" : 66913866,
      "verified" : false
    }
  },
  "id" : 604387491458596864,
  "created_at" : "2015-05-29 20:43:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Bart",
      "screen_name" : "facultyfocus",
      "indices" : [ 91, 104 ],
      "id_str" : "28334733",
      "id" : 28334733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/L0bhuSUdxA",
      "expanded_url" : "http:\/\/go.shr.lc\/1IcXj4D",
      "display_url" : "go.shr.lc\/1IcXj4D"
    } ]
  },
  "geo" : { },
  "id_str" : "604327784622612480",
  "text" : "Instructor Characteristics That Affect Online Student Success - http:\/\/t.co\/L0bhuSUdxA via @FacultyFocus",
  "id" : 604327784622612480,
  "created_at" : "2015-05-29 16:45:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/FEuk11jmBS",
      "expanded_url" : "http:\/\/etug.ca\/2015\/05\/28\/t-e-l-l-summary-may-enhancing-the-online-experience-for-students-and-instructors-with-a-modern-flat-file-cms\/",
      "display_url" : "etug.ca\/2015\/05\/28\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "604326479401373698",
  "text" : "Missed my \"Enhancing the Online Experience for Students &amp; Instructors with a Modern Flat-file CMS\" presentation? http:\/\/t.co\/FEuk11jmBS",
  "id" : 604326479401373698,
  "created_at" : "2015-05-29 16:40:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clark Quinn",
      "screen_name" : "Quinnovator",
      "indices" : [ 3, 15 ],
      "id_str" : "15312626",
      "id" : 15312626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/JhG8E6BfmC",
      "expanded_url" : "https:\/\/alymai.files.wordpress.com\/2011\/07\/diagram_cognitive_apprenticeship_forweb1.jpg",
      "display_url" : "alymai.files.wordpress.com\/2011\/07\/diagra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603962570337169410",
  "text" : "RT @Quinnovator: love this Cognitive Apprenticeship model! https:\/\/t.co\/JhG8E6BfmC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/JhG8E6BfmC",
        "expanded_url" : "https:\/\/alymai.files.wordpress.com\/2011\/07\/diagram_cognitive_apprenticeship_forweb1.jpg",
        "display_url" : "alymai.files.wordpress.com\/2011\/07\/diagra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "603962023546748928",
    "text" : "love this Cognitive Apprenticeship model! https:\/\/t.co\/JhG8E6BfmC",
    "id" : 603962023546748928,
    "created_at" : "2015-05-28 16:32:22 +0000",
    "user" : {
      "name" : "Clark Quinn",
      "screen_name" : "Quinnovator",
      "protected" : false,
      "id_str" : "15312626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639121092083224576\/9rAOP3Tq_normal.jpg",
      "id" : 15312626,
      "verified" : false
    }
  },
  "id" : 603962570337169410,
  "created_at" : "2015-05-28 16:34:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "otsummit",
      "indices" : [ 32, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/csAM6Kl37J",
      "expanded_url" : "http:\/\/otsummit.bccampus.ca\/livestream\/",
      "display_url" : "otsummit.bccampus.ca\/livestream\/"
    } ]
  },
  "geo" : { },
  "id_str" : "603957196087435264",
  "text" : "RT @clintlalonde: Livestreaming #otsummit http:\/\/t.co\/csAM6Kl37J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "otsummit",
        "indices" : [ 14, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/csAM6Kl37J",
        "expanded_url" : "http:\/\/otsummit.bccampus.ca\/livestream\/",
        "display_url" : "otsummit.bccampus.ca\/livestream\/"
      } ]
    },
    "geo" : { },
    "id_str" : "603954768957026305",
    "text" : "Livestreaming #otsummit http:\/\/t.co\/csAM6Kl37J",
    "id" : 603954768957026305,
    "created_at" : "2015-05-28 16:03:32 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 603957196087435264,
  "created_at" : "2015-05-28 16:13:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Chrome",
      "screen_name" : "googlechrome",
      "indices" : [ 3, 16 ],
      "id_str" : "56505125",
      "id" : 56505125
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/googlechrome\/status\/603778794944634880\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/D6UfTXuUTF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGENnSvVIAAuI8b.jpg",
      "id_str" : "603778793740771328",
      "id" : 603778793740771328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGENnSvVIAAuI8b.jpg",
      "sizes" : [ {
        "h" : 2919,
        "resize" : "fit",
        "w" : 2919
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/D6UfTXuUTF"
    } ],
    "hashtags" : [ {
      "text" : "io15",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603784347846451201",
  "text" : "RT @googlechrome: We're loaded in and ready at Moscone. Can't wait for tomorrow! #io15 http:\/\/t.co\/D6UfTXuUTF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/googlechrome\/status\/603778794944634880\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/D6UfTXuUTF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGENnSvVIAAuI8b.jpg",
        "id_str" : "603778793740771328",
        "id" : 603778793740771328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGENnSvVIAAuI8b.jpg",
        "sizes" : [ {
          "h" : 2919,
          "resize" : "fit",
          "w" : 2919
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/D6UfTXuUTF"
      } ],
      "hashtags" : [ {
        "text" : "io15",
        "indices" : [ 63, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603778794944634880",
    "text" : "We're loaded in and ready at Moscone. Can't wait for tomorrow! #io15 http:\/\/t.co\/D6UfTXuUTF",
    "id" : 603778794944634880,
    "created_at" : "2015-05-28 04:24:17 +0000",
    "user" : {
      "name" : "Google Chrome",
      "screen_name" : "googlechrome",
      "protected" : false,
      "id_str" : "56505125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639149491690471424\/slowQFCK_normal.png",
      "id" : 56505125,
      "verified" : true
    }
  },
  "id" : 603784347846451201,
  "created_at" : "2015-05-28 04:46:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603761117723262976",
  "text" : "Actually, upon further reflection I would say that learner experience is user experience (i.e. LX = UX) but in a particular context\/domain.",
  "id" : 603761117723262976,
  "created_at" : "2015-05-28 03:14:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "indices" : [ 3, 17 ],
      "id_str" : "1236101",
      "id" : 1236101
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BenedictEvans\/status\/603420915766931457\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/ZtpdltlQE9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF_IIB4UoAIe_Qr.png",
      "id_str" : "603420915360112642",
      "id" : 603420915360112642,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF_IIB4UoAIe_Qr.png",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1114,
        "resize" : "fit",
        "w" : 1978
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZtpdltlQE9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603712832014839808",
  "text" : "RT @BenedictEvans: Mobile is the first universal tech product. http:\/\/t.co\/ZtpdltlQE9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BenedictEvans\/status\/603420915766931457\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/ZtpdltlQE9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF_IIB4UoAIe_Qr.png",
        "id_str" : "603420915360112642",
        "id" : 603420915360112642,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF_IIB4UoAIe_Qr.png",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1114,
          "resize" : "fit",
          "w" : 1978
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZtpdltlQE9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603420915766931457",
    "text" : "Mobile is the first universal tech product. http:\/\/t.co\/ZtpdltlQE9",
    "id" : 603420915766931457,
    "created_at" : "2015-05-27 04:42:11 +0000",
    "user" : {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "protected" : false,
      "id_str" : "1236101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544407411193163776\/vGSguvLd_normal.jpeg",
      "id" : 1236101,
      "verified" : false
    }
  },
  "id" : 603712832014839808,
  "created_at" : "2015-05-28 00:02:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/RqyCLxIdBD",
      "expanded_url" : "http:\/\/www.slackEDU.net",
      "display_url" : "slackEDU.net"
    } ]
  },
  "in_reply_to_status_id_str" : "603658941759889409",
  "geo" : { },
  "id_str" : "603659251765157889",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob You might be interested in this group about Slack in Education, hosted on Slack of course :-) http:\/\/t.co\/RqyCLxIdBD",
  "id" : 603659251765157889,
  "in_reply_to_status_id" : 603658941759889409,
  "created_at" : "2015-05-27 20:29:15 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lyn Stoner",
      "screen_name" : "JesseLynStoner",
      "indices" : [ 3, 18 ],
      "id_str" : "201531255",
      "id" : 201531255
    }, {
      "name" : "Kate Nasser",
      "screen_name" : "KateNasser",
      "indices" : [ 25, 36 ],
      "id_str" : "17083396",
      "id" : 17083396
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leadership",
      "indices" : [ 80, 91 ]
    }, {
      "text" : "peopleskills",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/4eOH03r99y",
      "expanded_url" : "http:\/\/dlvr.it\/9yGmVQ",
      "display_url" : "dlvr.it\/9yGmVQ"
    } ]
  },
  "geo" : { },
  "id_str" : "603589323217317888",
  "text" : "RT @JesseLynStoner: From @KateNasser: Holacracy: Why Employees Like Hierarchy | #leadership #peopleskills http:\/\/t.co\/4eOH03r99y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kate Nasser",
        "screen_name" : "KateNasser",
        "indices" : [ 5, 16 ],
        "id_str" : "17083396",
        "id" : 17083396
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "leadership",
        "indices" : [ 60, 71 ]
      }, {
        "text" : "peopleskills",
        "indices" : [ 72, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/4eOH03r99y",
        "expanded_url" : "http:\/\/dlvr.it\/9yGmVQ",
        "display_url" : "dlvr.it\/9yGmVQ"
      } ]
    },
    "geo" : { },
    "id_str" : "602693964093763584",
    "text" : "From @KateNasser: Holacracy: Why Employees Like Hierarchy | #leadership #peopleskills http:\/\/t.co\/4eOH03r99y",
    "id" : 602693964093763584,
    "created_at" : "2015-05-25 04:33:33 +0000",
    "user" : {
      "name" : "Jesse Lyn Stoner",
      "screen_name" : "JesseLynStoner",
      "protected" : false,
      "id_str" : "201531255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667885745118416896\/65LIquW8_normal.jpg",
      "id" : 201531255,
      "verified" : false
    }
  },
  "id" : 603589323217317888,
  "created_at" : "2015-05-27 15:51:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Hive Vancouver",
      "screen_name" : "VancityBuzz",
      "indices" : [ 3, 15 ],
      "id_str" : "19314850",
      "id" : 19314850
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VancityBuzz\/status\/603344987854602240\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/HKzxSc4rNj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF-DEbdXIAAJIx-.jpg",
      "id_str" : "603344987204558848",
      "id" : 603344987204558848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF-DEbdXIAAJIx-.jpg",
      "sizes" : [ {
        "h" : 465,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 168,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HKzxSc4rNj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/rUB6XMetxZ",
      "expanded_url" : "http:\/\/ow.ly\/NsNHV",
      "display_url" : "ow.ly\/NsNHV"
    } ]
  },
  "geo" : { },
  "id_str" : "603417995029815296",
  "text" : "RT @VancityBuzz: Chapters Robson closing is the end of a magnificent era \n http:\/\/t.co\/rUB6XMetxZ http:\/\/t.co\/HKzxSc4rNj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VancityBuzz\/status\/603344987854602240\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/HKzxSc4rNj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF-DEbdXIAAJIx-.jpg",
        "id_str" : "603344987204558848",
        "id" : 603344987204558848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF-DEbdXIAAJIx-.jpg",
        "sizes" : [ {
          "h" : 465,
          "resize" : "fit",
          "w" : 940
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 940
        }, {
          "h" : 297,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 168,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HKzxSc4rNj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/rUB6XMetxZ",
        "expanded_url" : "http:\/\/ow.ly\/NsNHV",
        "display_url" : "ow.ly\/NsNHV"
      } ]
    },
    "geo" : { },
    "id_str" : "603344987854602240",
    "text" : "Chapters Robson closing is the end of a magnificent era \n http:\/\/t.co\/rUB6XMetxZ http:\/\/t.co\/HKzxSc4rNj",
    "id" : 603344987854602240,
    "created_at" : "2015-05-26 23:40:29 +0000",
    "user" : {
      "name" : "Daily Hive Vancouver",
      "screen_name" : "VancityBuzz",
      "protected" : false,
      "id_str" : "19314850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761310954869039104\/wcMr_RYT_normal.jpg",
      "id" : 19314850,
      "verified" : true
    }
  },
  "id" : 603417995029815296,
  "created_at" : "2015-05-27 04:30:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 17, 22 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Simon Bates",
      "screen_name" : "simonpbates",
      "indices" : [ 87, 99 ],
      "id_str" : "138373277",
      "id" : 138373277
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 106, 121 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 53, 58 ]
    }, {
      "text" : "proflearn",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/whHyqQScWZ",
      "expanded_url" : "http:\/\/bit.ly\/1HnfHUs",
      "display_url" : "bit.ly\/1HnfHUs"
    } ]
  },
  "geo" : { },
  "id_str" : "603365851782230016",
  "text" : "RT @BCcampus: RT @etug: A fab lineup of sessions for #etug Spring15 High5! w\/ keynotes @simonpbates &amp; @hibbittsdesign http:\/\/t.co\/whHyqQScW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 3, 8 ],
        "id_str" : "17102936",
        "id" : 17102936
      }, {
        "name" : "Simon Bates",
        "screen_name" : "simonpbates",
        "indices" : [ 73, 85 ],
        "id_str" : "138373277",
        "id" : 138373277
      }, {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 92, 107 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 39, 44 ]
      }, {
        "text" : "proflearn",
        "indices" : [ 131, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/whHyqQScWZ",
        "expanded_url" : "http:\/\/bit.ly\/1HnfHUs",
        "display_url" : "bit.ly\/1HnfHUs"
      } ]
    },
    "geo" : { },
    "id_str" : "603363781780070400",
    "text" : "RT @etug: A fab lineup of sessions for #etug Spring15 High5! w\/ keynotes @simonpbates &amp; @hibbittsdesign http:\/\/t.co\/whHyqQScWZ #proflearn",
    "id" : 603363781780070400,
    "created_at" : "2015-05-27 00:55:10 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 603365851782230016,
  "created_at" : "2015-05-27 01:03:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Merholz",
      "screen_name" : "peterme",
      "indices" : [ 3, 11 ],
      "id_str" : "1154",
      "id" : 1154
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/WmYcJLHe7u",
      "expanded_url" : "http:\/\/dupress.com\/articles\/beyond-design-thinking-business-trends\/",
      "display_url" : "dupress.com\/articles\/beyon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603305853244940289",
  "text" : "RT @peterme: Smart takedown of the church of \u201Cdesign thinking\u201D:\nhttp:\/\/t.co\/WmYcJLHe7u\nDesign is but one of many ways to solve problems and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/WmYcJLHe7u",
        "expanded_url" : "http:\/\/dupress.com\/articles\/beyond-design-thinking-business-trends\/",
        "display_url" : "dupress.com\/articles\/beyon\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "603303536928169984",
    "text" : "Smart takedown of the church of \u201Cdesign thinking\u201D:\nhttp:\/\/t.co\/WmYcJLHe7u\nDesign is but one of many ways to solve problems and see futures.",
    "id" : 603303536928169984,
    "created_at" : "2015-05-26 20:55:46 +0000",
    "user" : {
      "name" : "Peter Merholz",
      "screen_name" : "peterme",
      "protected" : false,
      "id_str" : "1154",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766259960011370496\/e9t34B07_normal.jpg",
      "id" : 1154,
      "verified" : false
    }
  },
  "id" : 603305853244940289,
  "created_at" : "2015-05-26 21:04:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moodle",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602939857476788225",
  "text" : "Key factors for #moodle UX? To me it's course format, navigation\/organization, block placements, theme &amp; multi-device experience. Comments?",
  "id" : 602939857476788225,
  "created_at" : "2015-05-25 20:50:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/d8iOy2JWuZ",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/canvas-prototype",
      "display_url" : "hibbittsdesign.com\/courses\/canvas\u2026"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/rfffNfM5IL",
      "expanded_url" : "http:\/\/ctlt2013.sites.olt.ubc.ca\/files\/2015\/05\/Learning-Technology-Ecosystem-Project-Report-May2015.pdf",
      "display_url" : "ctlt2013.sites.olt.ubc.ca\/files\/2015\/05\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "602872129621655552",
  "text" : "An example of a reduced LMS footprint with an instructor chosen tool (Grav) http:\/\/t.co\/d8iOy2JWuZ As described in: http:\/\/t.co\/rfffNfM5IL",
  "id" : 602872129621655552,
  "created_at" : "2015-05-25 16:21:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 0, 5 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601846942428049409",
  "geo" : { },
  "id_str" : "601847554368786432",
  "in_reply_to_user_id" : 17102936,
  "text" : "@etug Thanks so much :-) Too many twitter account experiments... Really looking forward to the Spring Workshop!",
  "id" : 601847554368786432,
  "in_reply_to_status_id" : 601846942428049409,
  "created_at" : "2015-05-22 20:30:13 +0000",
  "in_reply_to_screen_name" : "etug",
  "in_reply_to_user_id_str" : "17102936",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "will engle",
      "screen_name" : "infology",
      "indices" : [ 3, 12 ],
      "id_str" : "93031146",
      "id" : 93031146
    }, {
      "name" : "cindyu",
      "screen_name" : "cindyu",
      "indices" : [ 87, 94 ],
      "id_str" : "5540542",
      "id" : 5540542
    }, {
      "name" : "Rie",
      "screen_name" : "dreamsanatomy",
      "indices" : [ 101, 115 ],
      "id_str" : "395090227",
      "id" : 395090227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/WXRrPUUr3K",
      "expanded_url" : "http:\/\/blogs.ubc.ca\/open\/2015\/05\/22\/open-learning-design-a-manifesto\/",
      "display_url" : "blogs.ubc.ca\/open\/2015\/05\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601844559535087618",
  "text" : "RT @infology: Open Learning Design: The (draft) Manifesto - http:\/\/t.co\/WXRrPUUr3K (w\/ @cindyu &amp; @dreamsanatomy)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "cindyu",
        "screen_name" : "cindyu",
        "indices" : [ 73, 80 ],
        "id_str" : "5540542",
        "id" : 5540542
      }, {
        "name" : "Rie",
        "screen_name" : "dreamsanatomy",
        "indices" : [ 87, 101 ],
        "id_str" : "395090227",
        "id" : 395090227
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/WXRrPUUr3K",
        "expanded_url" : "http:\/\/blogs.ubc.ca\/open\/2015\/05\/22\/open-learning-design-a-manifesto\/",
        "display_url" : "blogs.ubc.ca\/open\/2015\/05\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "601843965273329665",
    "text" : "Open Learning Design: The (draft) Manifesto - http:\/\/t.co\/WXRrPUUr3K (w\/ @cindyu &amp; @dreamsanatomy)",
    "id" : 601843965273329665,
    "created_at" : "2015-05-22 20:15:57 +0000",
    "user" : {
      "name" : "will engle",
      "screen_name" : "infology",
      "protected" : false,
      "id_str" : "93031146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1598136377\/icon_normal.jpg",
      "id" : 93031146,
      "verified" : false
    }
  },
  "id" : 601844559535087618,
  "created_at" : "2015-05-22 20:18:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 0, 5 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 44, 59 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601843093558595584",
  "geo" : { },
  "id_str" : "601844291997151232",
  "in_reply_to_user_id" : 17102936,
  "text" : "@etug Thanks for the mention! Please use my @hibbittsdesign twitter handle, as others are just for family or students. All my fault :-)",
  "id" : 601844291997151232,
  "in_reply_to_status_id" : 601843093558595584,
  "created_at" : "2015-05-22 20:17:15 +0000",
  "in_reply_to_screen_name" : "etug",
  "in_reply_to_user_id_str" : "17102936",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 71, 76 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/C0zG06Bflb",
      "expanded_url" : "https:\/\/github.com\/paulhibbitts\/grav-canvas-prototype",
      "display_url" : "github.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601448803422502912",
  "text" : "The source files for the Grav\/Canvas LMS prototype shown yesterday for @etug TELL are now available at https:\/\/t.co\/C0zG06Bflb",
  "id" : 601448803422502912,
  "created_at" : "2015-05-21 18:05:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris nyffeler",
      "screen_name" : "nyff",
      "indices" : [ 3, 8 ],
      "id_str" : "3141",
      "id" : 3141
    }, {
      "name" : "IDEO",
      "screen_name" : "ideo",
      "indices" : [ 79, 84 ],
      "id_str" : "23462787",
      "id" : 23462787
    }, {
      "name" : "Danny Stillion",
      "screen_name" : "DannyStillion",
      "indices" : [ 106, 120 ],
      "id_str" : "1663824193",
      "id" : 1663824193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/caYOYz3vC0",
      "expanded_url" : "http:\/\/bit.ly\/1AkFpM8",
      "display_url" : "bit.ly\/1AkFpM8"
    } ]
  },
  "geo" : { },
  "id_str" : "601152815461896192",
  "text" : "RT @nyff: A 20 year perspective on the evolution of interaction design from my @IDEO colleague and mentor @DannyStillion http:\/\/t.co\/caYOYz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IDEO",
        "screen_name" : "ideo",
        "indices" : [ 69, 74 ],
        "id_str" : "23462787",
        "id" : 23462787
      }, {
        "name" : "Danny Stillion",
        "screen_name" : "DannyStillion",
        "indices" : [ 96, 110 ],
        "id_str" : "1663824193",
        "id" : 1663824193
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/caYOYz3vC0",
        "expanded_url" : "http:\/\/bit.ly\/1AkFpM8",
        "display_url" : "bit.ly\/1AkFpM8"
      } ]
    },
    "geo" : { },
    "id_str" : "601087760825503744",
    "text" : "A 20 year perspective on the evolution of interaction design from my @IDEO colleague and mentor @DannyStillion http:\/\/t.co\/caYOYz3vC0",
    "id" : 601087760825503744,
    "created_at" : "2015-05-20 18:11:04 +0000",
    "user" : {
      "name" : "chris nyffeler",
      "screen_name" : "nyff",
      "protected" : false,
      "id_str" : "3141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612063406804242432\/ZPgGNicR_normal.jpg",
      "id" : 3141,
      "verified" : false
    }
  },
  "id" : 601152815461896192,
  "created_at" : "2015-05-20 22:29:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/2bpEmOyjLh",
      "expanded_url" : "https:\/\/twitter.com\/Galimotion\/status\/591150527641169920",
      "display_url" : "twitter.com\/Galimotion\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601079506430926849",
  "text" : "I've found Slack (and similar modern chat tools) to be part of an effective learning ecology, that's for sure. https:\/\/t.co\/2bpEmOyjLh",
  "id" : 601079506430926849,
  "created_at" : "2015-05-20 17:38:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Howard",
      "screen_name" : "adrianh",
      "indices" : [ 3, 11 ],
      "id_str" : "23513",
      "id" : 23513
    }, {
      "name" : "Jeff Patton",
      "screen_name" : "jeffpatton",
      "indices" : [ 76, 87 ],
      "id_str" : "16043994",
      "id" : 16043994
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/adrianh\/status\/600977454581346304\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/kI2f1rAFys",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFcZz3tWoAA8sQV.jpg",
      "id_str" : "600977454195449856",
      "id" : 600977454195449856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFcZz3tWoAA8sQV.jpg",
      "sizes" : [ {
        "h" : 334,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 855,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/kI2f1rAFys"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601020580767207424",
  "text" : "RT @adrianh: Keep coming back to this Design Thinking Gone Wrong piece from @jeffpatton's excellent User Story Mapping book\u2026 http:\/\/t.co\/kI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff Patton",
        "screen_name" : "jeffpatton",
        "indices" : [ 63, 74 ],
        "id_str" : "16043994",
        "id" : 16043994
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/adrianh\/status\/600977454581346304\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/kI2f1rAFys",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFcZz3tWoAA8sQV.jpg",
        "id_str" : "600977454195449856",
        "id" : 600977454195449856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFcZz3tWoAA8sQV.jpg",
        "sizes" : [ {
          "h" : 334,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 855,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/kI2f1rAFys"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600977454581346304",
    "text" : "Keep coming back to this Design Thinking Gone Wrong piece from @jeffpatton's excellent User Story Mapping book\u2026 http:\/\/t.co\/kI2f1rAFys",
    "id" : 600977454581346304,
    "created_at" : "2015-05-20 10:52:45 +0000",
    "user" : {
      "name" : "Adrian Howard",
      "screen_name" : "adrianh",
      "protected" : false,
      "id_str" : "23513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299092306\/adrian-smiling_normal.jpg",
      "id" : 23513,
      "verified" : false
    }
  },
  "id" : 601020580767207424,
  "created_at" : "2015-05-20 13:44:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 31, 36 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "proflearn",
      "indices" : [ 114, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/3G49FDTizi",
      "expanded_url" : "http:\/\/ow.ly\/N0WWw",
      "display_url" : "ow.ly\/N0WWw"
    } ]
  },
  "geo" : { },
  "id_str" : "600782058210758656",
  "text" : "RT @BCcampus: Registration for @ETUG Spring Workshop closes May 21st! Have you registered? http:\/\/t.co\/3G49FDTizi #proflearn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 17, 22 ],
        "id_str" : "17102936",
        "id" : 17102936
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "proflearn",
        "indices" : [ 100, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/3G49FDTizi",
        "expanded_url" : "http:\/\/ow.ly\/N0WWw",
        "display_url" : "ow.ly\/N0WWw"
      } ]
    },
    "geo" : { },
    "id_str" : "600781778912153600",
    "text" : "Registration for @ETUG Spring Workshop closes May 21st! Have you registered? http:\/\/t.co\/3G49FDTizi #proflearn",
    "id" : 600781778912153600,
    "created_at" : "2015-05-19 21:55:12 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 600782058210758656,
  "created_at" : "2015-05-19 21:56:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 11, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/6wXufNylZB",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/enhancing-the-online-experience-for-students-and-instructors-with-a-modern-flat-file-cms",
      "display_url" : "slides.com\/paulhibbitts\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600742366148829184",
  "text" : "Slides for #etug T.E.L.L. session: Enhancing Student Experience w. a Modern Flat-file CMS http:\/\/t.co\/6wXufNylZB Thanks to all participants!",
  "id" : 600742366148829184,
  "created_at" : "2015-05-19 19:18:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 34, 39 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 70, 85 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/C6GfTWyJ7Z",
      "expanded_url" : "http:\/\/ow.ly\/N0WqH",
      "display_url" : "ow.ly\/N0WqH"
    } ]
  },
  "geo" : { },
  "id_str" : "600715355015741440",
  "text" : "RT @BCcampus: Starting in 30mins! @ETUG TELL session w\/ Paul Hibbitts @hibbittsdesign talking about a modern flat-file CMS. http:\/\/t.co\/C6G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 20, 25 ],
        "id_str" : "17102936",
        "id" : 17102936
      }, {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 56, 71 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/C6GfTWyJ7Z",
        "expanded_url" : "http:\/\/ow.ly\/N0WqH",
        "display_url" : "ow.ly\/N0WqH"
      } ]
    },
    "geo" : { },
    "id_str" : "600715263407972353",
    "text" : "Starting in 30mins! @ETUG TELL session w\/ Paul Hibbitts @hibbittsdesign talking about a modern flat-file CMS. http:\/\/t.co\/C6GfTWyJ7Z",
    "id" : 600715263407972353,
    "created_at" : "2015-05-19 17:30:54 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 600715355015741440,
  "created_at" : "2015-05-19 17:31:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Floro",
      "screen_name" : "nickfloro",
      "indices" : [ 3, 13 ],
      "id_str" : "15578710",
      "id" : 15578710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/9t0p7pwcs0",
      "expanded_url" : "http:\/\/sixrevisions.com\/resources\/learning-markdown-syntax\/",
      "display_url" : "sixrevisions.com\/resources\/lear\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600448614477901824",
  "text" : "RT @nickfloro: 10 Useful Resources for Learning Markdown Syntax http:\/\/t.co\/9t0p7pwcs0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/9t0p7pwcs0",
        "expanded_url" : "http:\/\/sixrevisions.com\/resources\/learning-markdown-syntax\/",
        "display_url" : "sixrevisions.com\/resources\/lear\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600447097641500672",
    "text" : "10 Useful Resources for Learning Markdown Syntax http:\/\/t.co\/9t0p7pwcs0",
    "id" : 600447097641500672,
    "created_at" : "2015-05-18 23:45:18 +0000",
    "user" : {
      "name" : "Nick Floro",
      "screen_name" : "nickfloro",
      "protected" : false,
      "id_str" : "15578710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/130051719\/Nick-Photo-Side_0508c_normal.jpg",
      "id" : 15578710,
      "verified" : false
    }
  },
  "id" : 600448614477901824,
  "created_at" : "2015-05-18 23:51:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/rObLbg2xkI",
      "expanded_url" : "http:\/\/bccampus.ca\/event\/t-e-l-l-may-enhancing-the-online-experience-for-students-and-instructors-with-a-modern-flat-file-cms\/",
      "display_url" : "bccampus.ca\/event\/t-e-l-l-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600414436692594688",
  "text" : "Join me tmrw (Tues) @ 11am PST: Enhancing the Online Experience for Students &amp; Instructors w\/ a Modern Flat-file CMS http:\/\/t.co\/rObLbg2xkI",
  "id" : 600414436692594688,
  "created_at" : "2015-05-18 21:35:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/OsMqKf58Gz",
      "expanded_url" : "http:\/\/techcrunch.com\/2015\/05\/17\/why-is-the-university-still-here\/",
      "display_url" : "techcrunch.com\/2015\/05\/17\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "599987626993528833",
  "text" : "RT @audreywatters: \"Why is the University Still Here?\" asks Techcrunch \u00AF\\_(\u30C4)_\/\u00AF http:\/\/t.co\/OsMqKf58Gz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/withknown.com\/\" rel=\"nofollow\"\u003EKnown Twitter Syndication\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/OsMqKf58Gz",
        "expanded_url" : "http:\/\/techcrunch.com\/2015\/05\/17\/why-is-the-university-still-here\/",
        "display_url" : "techcrunch.com\/2015\/05\/17\/why\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "599987093780111360",
    "text" : "\"Why is the University Still Here?\" asks Techcrunch \u00AF\\_(\u30C4)_\/\u00AF http:\/\/t.co\/OsMqKf58Gz",
    "id" : 599987093780111360,
    "created_at" : "2015-05-17 17:17:25 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 599987626993528833,
  "created_at" : "2015-05-17 17:19:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Jursa",
      "screen_name" : "IATV",
      "indices" : [ 3, 8 ],
      "id_str" : "17151314",
      "id" : 17151314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/x1u5ZYdrwm",
      "expanded_url" : "http:\/\/bit.ly\/1EGiEh8",
      "display_url" : "bit.ly\/1EGiEh8"
    } ]
  },
  "geo" : { },
  "id_str" : "599971843198439424",
  "text" : "RT @IATV: \"Why 'mobile first' may already be outdated\" http:\/\/t.co\/x1u5ZYdrwm (intercom.io)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/x1u5ZYdrwm",
        "expanded_url" : "http:\/\/bit.ly\/1EGiEh8",
        "display_url" : "bit.ly\/1EGiEh8"
      } ]
    },
    "geo" : { },
    "id_str" : "599965149353660417",
    "text" : "\"Why 'mobile first' may already be outdated\" http:\/\/t.co\/x1u5ZYdrwm (intercom.io)",
    "id" : 599965149353660417,
    "created_at" : "2015-05-17 15:50:13 +0000",
    "user" : {
      "name" : "Jan Jursa",
      "screen_name" : "IATV",
      "protected" : false,
      "id_str" : "17151314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466681693235982336\/4v-lZ2o2_normal.jpeg",
      "id" : 17151314,
      "verified" : false
    }
  },
  "id" : 599971843198439424,
  "created_at" : "2015-05-17 16:16:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Secord",
      "screen_name" : "JimSecord",
      "indices" : [ 0, 10 ],
      "id_str" : "12040282",
      "id" : 12040282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599032876340903936",
  "geo" : { },
  "id_str" : "599102693496393728",
  "in_reply_to_user_id" : 12040282,
  "text" : "@JimSecord Awesome show, too bad we didn't run into each other!",
  "id" : 599102693496393728,
  "in_reply_to_status_id" : 599032876340903936,
  "created_at" : "2015-05-15 06:43:07 +0000",
  "in_reply_to_screen_name" : "JimSecord",
  "in_reply_to_user_id_str" : "12040282",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/edNo69A5kE",
      "expanded_url" : "https:\/\/twitter.com\/drtonybates\/status\/597946974143434753",
      "display_url" : "twitter.com\/drtonybates\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598887962164625410",
  "text" : "Many aspects of \u201CNGDLE\u201D can be realized today with an open source front-end to complement required LMS functions. https:\/\/t.co\/edNo69A5kE",
  "id" : 598887962164625410,
  "created_at" : "2015-05-14 16:29:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karan Mavai",
      "screen_name" : "karanm",
      "indices" : [ 0, 7 ],
      "id_str" : "15401172",
      "id" : 15401172
    }, {
      "name" : "Nuzzel",
      "screen_name" : "nuzzel",
      "indices" : [ 8, 15 ],
      "id_str" : "106041193",
      "id" : 106041193
    }, {
      "name" : "Tom Warren",
      "screen_name" : "tomwarren",
      "indices" : [ 16, 26 ],
      "id_str" : "12273252",
      "id" : 12273252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598674703411085312",
  "geo" : { },
  "id_str" : "598681649451151360",
  "in_reply_to_user_id" : 15401172,
  "text" : "@karanm @nuzzel @tomwarren Next up, Pocket PC ;-)",
  "id" : 598681649451151360,
  "in_reply_to_status_id" : 598674703411085312,
  "created_at" : "2015-05-14 02:50:02 +0000",
  "in_reply_to_screen_name" : "karanm",
  "in_reply_to_user_id_str" : "15401172",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Wheeler",
      "screen_name" : "timbuckteeth",
      "indices" : [ 0, 13 ],
      "id_str" : "11435832",
      "id" : 11435832
    }, {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 27, 38 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/Uf8swt1GCI",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/model-learner-needs-experience-design-technology-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/model-le\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598568478216302592",
  "in_reply_to_user_id" : 11435832,
  "text" : "@timbuckteeth My colleague @jimbobtyer thought you might find this model of interest https:\/\/t.co\/Uf8swt1GCI Feedback v. appreciated, thanks",
  "id" : 598568478216302592,
  "created_at" : "2015-05-13 19:20:20 +0000",
  "in_reply_to_screen_name" : "timbuckteeth",
  "in_reply_to_user_id_str" : "11435832",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/B8vw8XojcA",
      "expanded_url" : "http:\/\/sched.co\/3NGi",
      "display_url" : "sched.co\/3NGi"
    } ]
  },
  "geo" : { },
  "id_str" : "598556531945123840",
  "text" : "Looking forward to presenting \"CON02.10 - From mobile access to multi-device learning ecologies: A case study\"  http:\/\/t.co\/B8vw8XojcA",
  "id" : 598556531945123840,
  "created_at" : "2015-05-13 18:32:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 7, 18 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598526806447230977",
  "geo" : { },
  "id_str" : "598530594469847041",
  "in_reply_to_user_id" : 217880712,
  "text" : "Thanks @jimbobtyer, will do!",
  "id" : 598530594469847041,
  "in_reply_to_status_id" : 598526806447230977,
  "created_at" : "2015-05-13 16:49:48 +0000",
  "in_reply_to_screen_name" : "jimbobtyer",
  "in_reply_to_user_id_str" : "217880712",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 13, 18 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/v71bgruMLn",
      "expanded_url" : "https:\/\/workflowy.com\/s\/guh6kp2VKd",
      "display_url" : "workflowy.com\/s\/guh6kp2VKd"
    } ]
  },
  "geo" : { },
  "id_str" : "597898707741216769",
  "text" : "May T.E.L.L. @etug outline: Enhancing the Online Experience for Students &amp; Instructors w\/ a Modern Flat-file CMS https:\/\/t.co\/v71bgruMLn",
  "id" : 597898707741216769,
  "created_at" : "2015-05-11 22:58:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/RZjE8UhHVg",
      "expanded_url" : "https:\/\/twitter.com\/swombat\/status\/597780255416459264",
      "display_url" : "twitter.com\/swombat\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597789525562241024",
  "text" : "\"I believe that each company should be run in whatever way is suitable to it. There is no superior or inferior way.\" https:\/\/t.co\/RZjE8UhHVg",
  "id" : 597789525562241024,
  "created_at" : "2015-05-11 15:45:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597297458067197952",
  "geo" : { },
  "id_str" : "597418340479414272",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Thanks for letting me know, just thought I'd ask :-) Finally using the new editor and really enjoying it, keep up the great work!",
  "id" : 597418340479414272,
  "in_reply_to_status_id" : 597297458067197952,
  "created_at" : "2015-05-10 15:10:06 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/ceVwmSgw03",
      "expanded_url" : "http:\/\/www.labnol.org\/internet\/light-youtube-embeds\/27941\/",
      "display_url" : "labnol.org\/internet\/light\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "565529822705623040",
  "geo" : { },
  "id_str" : "597179194695495680",
  "in_reply_to_user_id" : 15949844,
  "text" : "@SlidesApp Any more thoughts\/plans on ways to speed up embedded slides? It would be an super-awesome feature :-) http:\/\/t.co\/ceVwmSgw03",
  "id" : 597179194695495680,
  "in_reply_to_status_id" : 565529822705623040,
  "created_at" : "2015-05-09 23:19:49 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/s3shbqEX2u",
      "expanded_url" : "http:\/\/getgrav.org\/blog\/grav-0.9.27-released",
      "display_url" : "getgrav.org\/blog\/grav-0.9.\u2026"
    }, {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/9wsGnbQARE",
      "expanded_url" : "http:\/\/getgrav.org\/downloads#changelog",
      "display_url" : "getgrav.org\/downloads#chan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597136593225285632",
  "text" : "RT @getgrav: Grav 0.9.27 released with several improvements and bug fixes http:\/\/t.co\/s3shbqEX2u Check out the full changelog: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/s3shbqEX2u",
        "expanded_url" : "http:\/\/getgrav.org\/blog\/grav-0.9.27-released",
        "display_url" : "getgrav.org\/blog\/grav-0.9.\u2026"
      }, {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/9wsGnbQARE",
        "expanded_url" : "http:\/\/getgrav.org\/downloads#changelog",
        "display_url" : "getgrav.org\/downloads#chan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "597122480126300160",
    "text" : "Grav 0.9.27 released with several improvements and bug fixes http:\/\/t.co\/s3shbqEX2u Check out the full changelog: http:\/\/t.co\/9wsGnbQARE",
    "id" : 597122480126300160,
    "created_at" : "2015-05-09 19:34:27 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 597136593225285632,
  "created_at" : "2015-05-09 20:30:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/2VslFI53q1",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/canvas-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/canvas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596802473651609602",
  "text" : "Late Friday afternoon sneak peek of my mobile friendly alternative front-end for a #CanvasLMS course site http:\/\/t.co\/2VslFI53q1",
  "id" : 596802473651609602,
  "created_at" : "2015-05-08 22:22:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 45, 53 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/xSahkyv0bo",
      "expanded_url" : "https:\/\/bitnami.com\/stack\/grav",
      "display_url" : "bitnami.com\/stack\/grav"
    } ]
  },
  "geo" : { },
  "id_str" : "596668652490919936",
  "text" : "RT @getgrav: I just voted for Grav! Help get @getgrav packaged by Bitnami. You can vote at https:\/\/t.co\/xSahkyv0bo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 32, 40 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/xSahkyv0bo",
        "expanded_url" : "https:\/\/bitnami.com\/stack\/grav",
        "display_url" : "bitnami.com\/stack\/grav"
      } ]
    },
    "geo" : { },
    "id_str" : "596668291478736896",
    "text" : "I just voted for Grav! Help get @getgrav packaged by Bitnami. You can vote at https:\/\/t.co\/xSahkyv0bo",
    "id" : 596668291478736896,
    "created_at" : "2015-05-08 13:29:40 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 596668652490919936,
  "created_at" : "2015-05-08 13:31:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 84, 99 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "proflearn",
      "indices" : [ 123, 133 ]
    }, {
      "text" : "etug",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/X551QA0e0X",
      "expanded_url" : "http:\/\/bit.ly\/1bz0U00",
      "display_url" : "bit.ly\/1bz0U00"
    } ]
  },
  "geo" : { },
  "id_str" : "596093478284603393",
  "text" : "RT @etug: Yes! get the goods on the flat-file CMS Grav at our May TELL session with @hibbittsdesign http:\/\/t.co\/X551QA0e0X #proflearn #etug",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 74, 89 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "proflearn",
        "indices" : [ 113, 123 ]
      }, {
        "text" : "etug",
        "indices" : [ 124, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/X551QA0e0X",
        "expanded_url" : "http:\/\/bit.ly\/1bz0U00",
        "display_url" : "bit.ly\/1bz0U00"
      } ]
    },
    "geo" : { },
    "id_str" : "596092958190927872",
    "text" : "Yes! get the goods on the flat-file CMS Grav at our May TELL session with @hibbittsdesign http:\/\/t.co\/X551QA0e0X #proflearn #etug",
    "id" : 596092958190927872,
    "created_at" : "2015-05-06 23:23:30 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 596093478284603393,
  "created_at" : "2015-05-06 23:25:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "indices" : [ 3, 17 ],
      "id_str" : "153597392",
      "id" : 153597392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 19, 29 ]
    }, {
      "text" : "SFU",
      "indices" : [ 133, 137 ]
    }, {
      "text" : "UBC",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/3CJrUnDDED",
      "expanded_url" : "http:\/\/bit.ly\/1NYWmPR",
      "display_url" : "bit.ly\/1NYWmPR"
    } ]
  },
  "geo" : { },
  "id_str" : "596079411947909120",
  "text" : "RT @SFUteachlearn: #STLHE2015 is closing in on its maximum capacity. If you hope to attend, register quickly! http:\/\/t.co\/3CJrUnDDED #SFU #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STLHE2015",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "SFU",
        "indices" : [ 114, 118 ]
      }, {
        "text" : "UBC",
        "indices" : [ 119, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/3CJrUnDDED",
        "expanded_url" : "http:\/\/bit.ly\/1NYWmPR",
        "display_url" : "bit.ly\/1NYWmPR"
      } ]
    },
    "geo" : { },
    "id_str" : "594217428084600832",
    "text" : "#STLHE2015 is closing in on its maximum capacity. If you hope to attend, register quickly! http:\/\/t.co\/3CJrUnDDED #SFU #UBC",
    "id" : 594217428084600832,
    "created_at" : "2015-05-01 19:10:49 +0000",
    "user" : {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "protected" : false,
      "id_str" : "153597392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1011990133\/twitter_badge_teach_learn2_normal.jpg",
      "id" : 153597392,
      "verified" : false
    }
  },
  "id" : 596079411947909120,
  "created_at" : "2015-05-06 22:29:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Porter",
      "screen_name" : "dendroglyph",
      "indices" : [ 0, 12 ],
      "id_str" : "15170764",
      "id" : 15170764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595709195468550144",
  "geo" : { },
  "id_str" : "595733686856843266",
  "in_reply_to_user_id" : 15170764,
  "text" : "@dendroglyph Cheers! Funny that you mention Grav, as I've just started mapping out an on-line presentation about using it as a LMS front-end",
  "id" : 595733686856843266,
  "in_reply_to_status_id" : 595709195468550144,
  "created_at" : "2015-05-05 23:35:53 +0000",
  "in_reply_to_screen_name" : "dendroglyph",
  "in_reply_to_user_id_str" : "15170764",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Porter",
      "screen_name" : "dendroglyph",
      "indices" : [ 0, 12 ],
      "id_str" : "15170764",
      "id" : 15170764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595708059172868098",
  "in_reply_to_user_id" : 15170764,
  "text" : "@dendroglyph Great to see this news today!",
  "id" : 595708059172868098,
  "created_at" : "2015-05-05 21:54:03 +0000",
  "in_reply_to_screen_name" : "dendroglyph",
  "in_reply_to_user_id_str" : "15170764",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus Open",
      "screen_name" : "BCOpenText",
      "indices" : [ 3, 14 ],
      "id_str" : "3148543346",
      "id" : 3148543346
    }, {
      "name" : "David Porter",
      "screen_name" : "dendroglyph",
      "indices" : [ 48, 60 ],
      "id_str" : "15170764",
      "id" : 15170764
    }, {
      "name" : "BCIT",
      "screen_name" : "bcit",
      "indices" : [ 62, 67 ],
      "id_str" : "19372538",
      "id" : 19372538
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcpse",
      "indices" : [ 143, 144 ]
    }, {
      "text" : "oer",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595707779777716224",
  "text" : "RT @BCOpenText: Congratulations to David Porter @dendroglyph! @bcit welcomes new Associate Vice President, Education Support &amp; Innovation. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Porter",
        "screen_name" : "dendroglyph",
        "indices" : [ 32, 44 ],
        "id_str" : "15170764",
        "id" : 15170764
      }, {
        "name" : "BCIT",
        "screen_name" : "bcit",
        "indices" : [ 46, 51 ],
        "id_str" : "19372538",
        "id" : 19372538
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bcpse",
        "indices" : [ 127, 133 ]
      }, {
        "text" : "oer",
        "indices" : [ 134, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595636908899868672",
    "text" : "Congratulations to David Porter @dendroglyph! @bcit welcomes new Associate Vice President, Education Support &amp; Innovation. #bcpse #oer",
    "id" : 595636908899868672,
    "created_at" : "2015-05-05 17:11:20 +0000",
    "user" : {
      "name" : "BCcampus Open",
      "screen_name" : "BCOpenText",
      "protected" : false,
      "id_str" : "3148543346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587706251347243009\/BA0taxiM_normal.jpg",
      "id" : 3148543346,
      "verified" : false
    }
  },
  "id" : 595707779777716224,
  "created_at" : "2015-05-05 21:52:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 24, 32 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/2VslFHNsyt",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/canvas-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/canvas\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "595686372415033345",
  "geo" : { },
  "id_str" : "595687152710754304",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard I went with @getgrav and I've been very happy. An Admin Panel is also in the works. Course prototype at http:\/\/t.co\/2VslFHNsyt",
  "id" : 595687152710754304,
  "in_reply_to_status_id" : 595686372415033345,
  "created_at" : "2015-05-05 20:30:59 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595681690636386306",
  "text" : "Starting work on a yet-to-be-announced online presentation: The How and Why of Using a Modern, Flat-file Open Source CMS as a LMS Front-end.",
  "id" : 595681690636386306,
  "created_at" : "2015-05-05 20:09:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blackboard",
      "screen_name" : "Blackboard",
      "indices" : [ 3, 14 ],
      "id_str" : "70406994",
      "id" : 70406994
    }, {
      "name" : "Mark Strassman",
      "screen_name" : "markstrassman",
      "indices" : [ 38, 52 ],
      "id_str" : "171112532",
      "id" : 171112532
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Blackboard\/status\/595568135618621441\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/FsvKd6SKOi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEPiEFgWAAAVwwF.png",
      "id_str" : "595568135568228352",
      "id" : 595568135568228352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEPiEFgWAAAVwwF.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FsvKd6SKOi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Zu76mvmyjm",
      "expanded_url" : "http:\/\/bit.ly\/1R7PrWc",
      "display_url" : "bit.ly\/1R7PrWc"
    } ]
  },
  "geo" : { },
  "id_str" : "595585579871375360",
  "text" : "RT @Blackboard: New: Snap for Moodle. @MarkStrassman discusses our revolutionary Moodle theme on the blog: http:\/\/t.co\/Zu76mvmyjm http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Strassman",
        "screen_name" : "markstrassman",
        "indices" : [ 22, 36 ],
        "id_str" : "171112532",
        "id" : 171112532
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Blackboard\/status\/595568135618621441\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/FsvKd6SKOi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEPiEFgWAAAVwwF.png",
        "id_str" : "595568135568228352",
        "id" : 595568135568228352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEPiEFgWAAAVwwF.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FsvKd6SKOi"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/Zu76mvmyjm",
        "expanded_url" : "http:\/\/bit.ly\/1R7PrWc",
        "display_url" : "bit.ly\/1R7PrWc"
      } ]
    },
    "geo" : { },
    "id_str" : "595568135618621441",
    "text" : "New: Snap for Moodle. @MarkStrassman discusses our revolutionary Moodle theme on the blog: http:\/\/t.co\/Zu76mvmyjm http:\/\/t.co\/FsvKd6SKOi",
    "id" : 595568135618621441,
    "created_at" : "2015-05-05 12:38:03 +0000",
    "user" : {
      "name" : "Blackboard",
      "screen_name" : "Blackboard",
      "protected" : false,
      "id_str" : "70406994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684452100252823553\/rKSyV8K3_normal.png",
      "id" : 70406994,
      "verified" : true
    }
  },
  "id" : 595585579871375360,
  "created_at" : "2015-05-05 13:47:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "indices" : [ 3, 11 ],
      "id_str" : "15022225",
      "id" : 15022225
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Touchscreens",
      "indices" : [ 19, 32 ]
    }, {
      "text" : "UX",
      "indices" : [ 75, 78 ]
    }, {
      "text" : "tablets",
      "indices" : [ 79, 87 ]
    }, {
      "text" : "usability",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/T8qGfIIizC",
      "expanded_url" : "http:\/\/j.mp\/1bLzjZX",
      "display_url" : "j.mp\/1bLzjZX"
    } ]
  },
  "geo" : { },
  "id_str" : "595307281270476800",
  "text" : "RT @NNgroup: Large #Touchscreens: What's Different? http:\/\/t.co\/T8qGfIIizC #UX #tablets #usability",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Touchscreens",
        "indices" : [ 6, 19 ]
      }, {
        "text" : "UX",
        "indices" : [ 62, 65 ]
      }, {
        "text" : "tablets",
        "indices" : [ 66, 74 ]
      }, {
        "text" : "usability",
        "indices" : [ 75, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/T8qGfIIizC",
        "expanded_url" : "http:\/\/j.mp\/1bLzjZX",
        "display_url" : "j.mp\/1bLzjZX"
      } ]
    },
    "geo" : { },
    "id_str" : "595305256315138050",
    "text" : "Large #Touchscreens: What's Different? http:\/\/t.co\/T8qGfIIizC #UX #tablets #usability",
    "id" : 595305256315138050,
    "created_at" : "2015-05-04 19:13:27 +0000",
    "user" : {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "protected" : false,
      "id_str" : "15022225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467725885949227008\/JTT0mnp4_normal.png",
      "id" : 15022225,
      "verified" : false
    }
  },
  "id" : 595307281270476800,
  "created_at" : "2015-05-04 19:21:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595302342653648896",
  "text" : "Give educators the choice of their own (open source) front-end with links to required LMS functionality to easily benefit from both. Simple.",
  "id" : 595302342653648896,
  "created_at" : "2015-05-04 19:01:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olark Live Chat",
      "screen_name" : "olark",
      "indices" : [ 10, 16 ],
      "id_str" : "21672965",
      "id" : 21672965
    }, {
      "name" : "Slack",
      "screen_name" : "SlackHQ",
      "indices" : [ 41, 49 ],
      "id_str" : "1305940272",
      "id" : 1305940272
    }, {
      "name" : "myBalsamiq",
      "screen_name" : "mybalsamiq",
      "indices" : [ 81, 92 ],
      "id_str" : "29658000",
      "id" : 29658000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/2VslFI53q1",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/canvas-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/canvas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595295623353499649",
  "text" : "Exploring @Olark for instructor Q&amp;A, @SlackHQ for student discussions + CoP, @mybalsamiq for collaborative mockups http:\/\/t.co\/2VslFI53q1",
  "id" : 595295623353499649,
  "created_at" : "2015-05-04 18:35:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595280378526445570",
  "text" : "Facebook is looking like the new AOL more and more these days.",
  "id" : 595280378526445570,
  "created_at" : "2015-05-04 17:34:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 113, 129 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/YLAYkIkm6y",
      "expanded_url" : "http:\/\/wp.me\/p5HkQ8-q",
      "display_url" : "wp.me\/p5HkQ8-q"
    } ]
  },
  "geo" : { },
  "id_str" : "594281146847875072",
  "text" : "Education &amp; \"Interpersonal Computing:\" Steve Jobs on the origins of the internet. http:\/\/t.co\/YLAYkIkm6y via @wordpressdotcom",
  "id" : 594281146847875072,
  "created_at" : "2015-05-01 23:24:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]