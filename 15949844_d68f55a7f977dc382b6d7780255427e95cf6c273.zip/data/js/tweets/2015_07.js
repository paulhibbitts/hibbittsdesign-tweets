Grailbird.data.tweets_2015_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MichaelSmithSupt",
      "screen_name" : "principalspage",
      "indices" : [ 3, 18 ],
      "id_str" : "15704582",
      "id" : 15704582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627208339923963905",
  "text" : "RT @principalspage: Be happy for other people when they are successful.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626948966358216706",
    "text" : "Be happy for other people when they are successful.",
    "id" : 626948966358216706,
    "created_at" : "2015-07-31 02:54:16 +0000",
    "user" : {
      "name" : "MichaelSmithSupt",
      "screen_name" : "principalspage",
      "protected" : false,
      "id_str" : "15704582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3411185797\/0f570301520d323c8713e51b73fb28de_normal.png",
      "id" : 15704582,
      "verified" : false
    }
  },
  "id" : 627208339923963905,
  "created_at" : "2015-07-31 20:04:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627177079285506049",
  "text" : "Streamlining the non-pedagogical tasks of a digital learning environment is often the most effective way to enhance the learner experience.",
  "id" : 627177079285506049,
  "created_at" : "2015-07-31 18:00:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/abG6zmYU9l",
      "expanded_url" : "http:\/\/slides.com",
      "display_url" : "slides.com"
    }, {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/bgxRiz1V99",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/cmpt-363-153-slides-placeholder#\/",
      "display_url" : "slides.com\/paulhibbitts\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627173837528940544",
  "text" : "#SFU CMPT 363 preparations are in full swing with the use of one of my favorite Web apps http:\/\/t.co\/abG6zmYU9l! http:\/\/t.co\/bgxRiz1V99",
  "id" : 627173837528940544,
  "created_at" : "2015-07-31 17:47:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CTET at RRU",
      "screen_name" : "RRUCTET",
      "indices" : [ 38, 46 ],
      "id_str" : "981330198",
      "id" : 981330198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627169114763628544",
  "text" : "It's been a pleasure working with the @RRUCTET team preparing for our first set of unmoderated usability tests on Moodle for ~50 students.",
  "id" : 627169114763628544,
  "created_at" : "2015-07-31 17:29:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626792110243471360",
  "geo" : { },
  "id_str" : "626826196337057792",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Mic drop.",
  "id" : 626826196337057792,
  "in_reply_to_status_id" : 626792110243471360,
  "created_at" : "2015-07-30 18:46:25 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 75, 84 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/WNJH6248Z3",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/what-problems-can-flat-file-cmss-solve-instructors-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/what-pro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626809783580909568",
  "text" : "\"What Problems can Flat-file CMS's Solve for Instructors and Students?\" on @LinkedIn https:\/\/t.co\/WNJH6248Z3 Comments fellow instructors?",
  "id" : 626809783580909568,
  "created_at" : "2015-07-30 17:41:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Maeda",
      "screen_name" : "johnmaeda",
      "indices" : [ 0, 10 ],
      "id_str" : "15414807",
      "id" : 15414807
    }, {
      "name" : "Takashi Okamoto",
      "screen_name" : "takashio",
      "indices" : [ 11, 20 ],
      "id_str" : "14989453",
      "id" : 14989453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/WNJH6248Z3",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/what-problems-can-flat-file-cmss-solve-instructors-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/what-pro\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "615681549535694848",
  "geo" : { },
  "id_str" : "626805948250632192",
  "in_reply_to_user_id" : 15414807,
  "text" : "@johnmaeda @takashio Love to hear more about how this went! You might also be interested in this related post https:\/\/t.co\/WNJH6248Z3",
  "id" : 626805948250632192,
  "in_reply_to_status_id" : 615681549535694848,
  "created_at" : "2015-07-30 17:25:58 +0000",
  "in_reply_to_screen_name" : "johnmaeda",
  "in_reply_to_user_id_str" : "15414807",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "will engle",
      "screen_name" : "infology",
      "indices" : [ 3, 12 ],
      "id_str" : "93031146",
      "id" : 93031146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 129, 144 ],
      "url" : "http:\/\/t.co\/6xSNKhCzGK",
      "expanded_url" : "http:\/\/udg.theagoraonline.net",
      "display_url" : "udg.theagoraonline.net"
    } ]
  },
  "geo" : { },
  "id_str" : "626803345273913347",
  "text" : "RT @infology: Wow! UDG Agora is an amazing resource\/template for a faculty dev program on student centred &amp; mobile learning: http:\/\/t.co\/6x\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/6xSNKhCzGK",
        "expanded_url" : "http:\/\/udg.theagoraonline.net",
        "display_url" : "udg.theagoraonline.net"
      } ]
    },
    "geo" : { },
    "id_str" : "626798862640898048",
    "text" : "Wow! UDG Agora is an amazing resource\/template for a faculty dev program on student centred &amp; mobile learning: http:\/\/t.co\/6xSNKhCzGK",
    "id" : 626798862640898048,
    "created_at" : "2015-07-30 16:57:48 +0000",
    "user" : {
      "name" : "will engle",
      "screen_name" : "infology",
      "protected" : false,
      "id_str" : "93031146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1598136377\/icon_normal.jpg",
      "id" : 93031146,
      "verified" : false
    }
  },
  "id" : 626803345273913347,
  "created_at" : "2015-07-30 17:15:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626793987500736512",
  "text" : "6) Existing LMS's\/CMS's often prevent content from being globally searched and replaced by authors. Content as FILES removes these barriers.",
  "id" : 626793987500736512,
  "created_at" : "2015-07-30 16:38:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Pilgrim",
      "screen_name" : "6sigma",
      "indices" : [ 0, 7 ],
      "id_str" : "7824742",
      "id" : 7824742
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 8, 16 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626791021225992192",
  "geo" : { },
  "id_str" : "626792860600274944",
  "in_reply_to_user_id" : 7824742,
  "text" : "@6sigma @getgrav Hey, I am really glad to hear that! Grav has been really awesome to work with, be sure to check out the Gitter.im room too.",
  "id" : 626792860600274944,
  "in_reply_to_status_id" : 626791021225992192,
  "created_at" : "2015-07-30 16:33:57 +0000",
  "in_reply_to_screen_name" : "6sigma",
  "in_reply_to_user_id_str" : "7824742",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626789521556803585",
  "text" : "5) Existing LMS's\/CMS's often require IT involvement for content or server migration, while a flat-file CMS only needs simple FILE COPYING.",
  "id" : 626789521556803585,
  "created_at" : "2015-07-30 16:20:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626789468083630080",
  "text" : "Here is a 5th problem that a flat-file CMS solved for me as an individual instructor:",
  "id" : 626789468083630080,
  "created_at" : "2015-07-30 16:20:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 44, 52 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/V4gRb8kA5t",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "626506733653917696",
  "text" : "Want to see an example of the flat-file CMS @getgrav being used? Explore my latest multi-device course companion at http:\/\/t.co\/V4gRb8kA5t",
  "id" : 626506733653917696,
  "created_at" : "2015-07-29 21:36:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626506684265971712",
  "text" : "4) Existing LMS's\/CMS's can often only be edited by pre-defined interfaces. A flat-file CMS gives authors and contributors tool CHOICE.",
  "id" : 626506684265971712,
  "created_at" : "2015-07-29 21:36:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626506642201313280",
  "text" : "3) Existing LMS's\/CMS's are often database-driven which can impact performance on even the simplest content presentation tasks. SPEED = UX.",
  "id" : 626506642201313280,
  "created_at" : "2015-07-29 21:36:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626506612824379394",
  "text" : "2) Existing LMS's\/CMS's are often blob-based, where each page is a single blog of content rather than MODULAR\/REUSABLE content chunks.",
  "id" : 626506612824379394,
  "created_at" : "2015-07-29 21:36:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626506582747017216",
  "text" : "1) Existing LMS's\/CMS's often only support limited collaborative editing. Content AND logic are both editable collaboratively (i.e. GitHub).",
  "id" : 626506582747017216,
  "created_at" : "2015-07-29 21:36:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 45, 53 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626506529521340416",
  "text" : "My current fav. open source flat-file CMS is @getgrav, which has solid docs, a really helpful community &amp; solves the following 4 problems:",
  "id" : 626506529521340416,
  "created_at" : "2015-07-29 21:36:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626486456744177665",
  "text" : "Flat-file CMS: A modern, modular and multi-device CMS which stores content as files (i.e. not in a database) using industry-standard formats",
  "id" : 626486456744177665,
  "created_at" : "2015-07-29 20:16:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626473034723897344",
  "text" : "Let's start talking about what flat-file CMS's bring to the table for instructors AND students from the viewpoint of problems they solve.",
  "id" : 626473034723897344,
  "created_at" : "2015-07-29 19:23:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    }, {
      "name" : "will engle",
      "screen_name" : "infology",
      "indices" : [ 15, 24 ],
      "id_str" : "93031146",
      "id" : 93031146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/jkM77aR4kL",
      "expanded_url" : "https:\/\/workflowy.com\/s\/kg4Cek6Syu",
      "display_url" : "workflowy.com\/s\/kg4Cek6Syu"
    } ]
  },
  "in_reply_to_status_id_str" : "626203905467125760",
  "geo" : { },
  "id_str" : "626409850990276608",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc @infology Awesome \uD83D\uDE04 Here is the in-progress workflowy for my upcoming CMPT-363 course at SFU https:\/\/t.co\/jkM77aR4kL",
  "id" : 626409850990276608,
  "in_reply_to_status_id" : 626203905467125760,
  "created_at" : "2015-07-29 15:12:01 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626190356766261249",
  "text" : "Lots of thoughts to share soon about the awesomeness of using a flat-file CMS for your multi-device course companion with deep links to LMS.",
  "id" : 626190356766261249,
  "created_at" : "2015-07-29 00:39:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626186718928965632",
  "text" : "As much as I love the experience of teaching, I love the experience of learning even more.",
  "id" : 626186718928965632,
  "created_at" : "2015-07-29 00:25:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "indices" : [ 3, 11 ],
      "id_str" : "783092",
      "id" : 783092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626173200490086400",
  "text" : "RT @benwerd: Institutions are - rightly - turning to open source solutions to escape from lock-in at high licensing cost. It's eating Black\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/werd.io\/\" rel=\"nofollow\"\u003Ewerd.io\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "626172403484221440",
    "geo" : { },
    "id_str" : "626172582044135424",
    "in_reply_to_user_id" : 783092,
    "text" : "Institutions are - rightly - turning to open source solutions to escape from lock-in at high licensing cost. It's eating Blackboard's lunch.",
    "id" : 626172582044135424,
    "in_reply_to_status_id" : 626172403484221440,
    "created_at" : "2015-07-28 23:29:11 +0000",
    "in_reply_to_screen_name" : "benwerd",
    "in_reply_to_user_id_str" : "783092",
    "user" : {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "protected" : false,
      "id_str" : "783092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681986174966104064\/t3BubQKk_normal.jpg",
      "id" : 783092,
      "verified" : true
    }
  },
  "id" : 626173200490086400,
  "created_at" : "2015-07-28 23:31:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Denman",
      "screen_name" : "PhilSDSU",
      "indices" : [ 3, 12 ],
      "id_str" : "1906858195",
      "id" : 1906858195
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 14, 29 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 30, 41 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626141441509580800",
  "text" : "RT @PhilSDSU: @hibbittsdesign @jimbobtyer I thought I was the only one who thought that experience was awful. Can I also add scoop.it to th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 0, 15 ],
        "id_str" : "15949844",
        "id" : 15949844
      }, {
        "name" : "James Tyer",
        "screen_name" : "jimbobtyer",
        "indices" : [ 16, 27 ],
        "id_str" : "217880712",
        "id" : 217880712
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "626135744965283840",
    "geo" : { },
    "id_str" : "626136425855975424",
    "in_reply_to_user_id" : 15949844,
    "text" : "@hibbittsdesign @jimbobtyer I thought I was the only one who thought that experience was awful. Can I also add scoop.it to the banned list?",
    "id" : 626136425855975424,
    "in_reply_to_status_id" : 626135744965283840,
    "created_at" : "2015-07-28 21:05:31 +0000",
    "in_reply_to_screen_name" : "hibbittsdesign",
    "in_reply_to_user_id_str" : "15949844",
    "user" : {
      "name" : "Phil Denman",
      "screen_name" : "PhilSDSU",
      "protected" : false,
      "id_str" : "1906858195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758514500911833088\/-VFj-OjX_normal.jpg",
      "id" : 1906858195,
      "verified" : false
    }
  },
  "id" : 626141441509580800,
  "created_at" : "2015-07-28 21:25:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/jKqpSEbaid",
      "expanded_url" : "https:\/\/twitter.com\/jimbobtyer\/status\/626135482070470656",
      "display_url" : "twitter.com\/jimbobtyer\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626135744965283840",
  "text" : "Amen! https:\/\/t.co\/jKqpSEbaid",
  "id" : 626135744965283840,
  "created_at" : "2015-07-28 21:02:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626128957994221572",
  "text" : "RT @audreywatters: Does Blackboard own student\/teacher data\/content in its services? What happens to that data in a sale?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "626112072053489665",
    "geo" : { },
    "id_str" : "626117989989900288",
    "in_reply_to_user_id" : 25388528,
    "text" : "Does Blackboard own student\/teacher data\/content in its services? What happens to that data in a sale?",
    "id" : 626117989989900288,
    "in_reply_to_status_id" : 626112072053489665,
    "created_at" : "2015-07-28 19:52:16 +0000",
    "in_reply_to_screen_name" : "audreywatters",
    "in_reply_to_user_id_str" : "25388528",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 626128957994221572,
  "created_at" : "2015-07-28 20:35:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/UMyVmeo1zR",
      "expanded_url" : "https:\/\/twitter.com\/PhilOnEdTech\/status\/626117178211762176",
      "display_url" : "twitter.com\/PhilOnEdTech\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626124384437010432",
  "text" : "Wow, last week it was all about reducing learner anxiety but now university anxiety has likely gone off the scale... https:\/\/t.co\/UMyVmeo1zR",
  "id" : 626124384437010432,
  "created_at" : "2015-07-28 20:17:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    }, {
      "name" : "will engle",
      "screen_name" : "infology",
      "indices" : [ 15, 24 ],
      "id_str" : "93031146",
      "id" : 93031146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626110623269523457",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc @infology Great to chat with you both today!",
  "id" : 626110623269523457,
  "created_at" : "2015-07-28 19:22:59 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "indices" : [ 3, 11 ],
      "id_str" : "783092",
      "id" : 783092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/6HEd992Tbt",
      "expanded_url" : "https:\/\/twitter.com\/rohanpinto\/status\/626062975837847552",
      "display_url" : "twitter.com\/rohanpinto\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626065595130183680",
  "text" : "RT @benwerd: My opinion: apps are the new CD-ROMs.  https:\/\/t.co\/6HEd992Tbt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/6HEd992Tbt",
        "expanded_url" : "https:\/\/twitter.com\/rohanpinto\/status\/626062975837847552",
        "display_url" : "twitter.com\/rohanpinto\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "626063374632267776",
    "text" : "My opinion: apps are the new CD-ROMs.  https:\/\/t.co\/6HEd992Tbt",
    "id" : 626063374632267776,
    "created_at" : "2015-07-28 16:15:14 +0000",
    "user" : {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "protected" : false,
      "id_str" : "783092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681986174966104064\/t3BubQKk_normal.jpg",
      "id" : 783092,
      "verified" : true
    }
  },
  "id" : 626065595130183680,
  "created_at" : "2015-07-28 16:24:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Whitby",
      "screen_name" : "tomwhitby",
      "indices" : [ 3, 13 ],
      "id_str" : "17762060",
      "id" : 17762060
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Edchat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626064708819292160",
  "text" : "RT @tomwhitby: Would it also be fair to say that in today's world a digitally illiterate educator is an irrelevant educator? #Edchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Edchat",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626064028415213568",
    "text" : "Would it also be fair to say that in today's world a digitally illiterate educator is an irrelevant educator? #Edchat",
    "id" : 626064028415213568,
    "created_at" : "2015-07-28 16:17:50 +0000",
    "user" : {
      "name" : "Tom Whitby",
      "screen_name" : "tomwhitby",
      "protected" : false,
      "id_str" : "17762060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601591035\/twitter_pic_1__normal.jpg",
      "id" : 17762060,
      "verified" : false
    }
  },
  "id" : 626064708819292160,
  "created_at" : "2015-07-28 16:20:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Boyer",
      "screen_name" : "brianboyer",
      "indices" : [ 3, 14 ],
      "id_str" : "14570738",
      "id" : 14570738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626062329793396737",
  "text" : "RT @brianboyer: Big Internet company showed us their new shit, guy kept saying \"focus group\" and \"We asked people what they wanted.\" THATS \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625988965179465728",
    "text" : "Big Internet company showed us their new shit, guy kept saying \"focus group\" and \"We asked people what they wanted.\" THATS NOT HOW YOU DO IT",
    "id" : 625988965179465728,
    "created_at" : "2015-07-28 11:19:34 +0000",
    "user" : {
      "name" : "Brian Boyer",
      "screen_name" : "brianboyer",
      "protected" : false,
      "id_str" : "14570738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508121738140319744\/Ff_UFtbA_normal.png",
      "id" : 14570738,
      "verified" : true
    }
  },
  "id" : 626062329793396737,
  "created_at" : "2015-07-28 16:11:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 0, 7 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "Vivian Forssman",
      "screen_name" : "vivforssman",
      "indices" : [ 75, 87 ],
      "id_str" : "257351755",
      "id" : 257351755
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625718124373880832",
  "geo" : { },
  "id_str" : "626048137543561216",
  "in_reply_to_user_id" : 745903,
  "text" : "@brlamb Love it :-) I've been doing some work with the new Snap theme with @vivforssman that might interest you too, always happy to chat.",
  "id" : 626048137543561216,
  "in_reply_to_status_id" : 625718124373880832,
  "created_at" : "2015-07-28 15:14:42 +0000",
  "in_reply_to_screen_name" : "brlamb",
  "in_reply_to_user_id_str" : "745903",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625835504274026496",
  "text" : "Looking back my multi-device course companions since 2011, 2 key themes emerge: conversation &amp; striving for a frictionless user experience.",
  "id" : 625835504274026496,
  "created_at" : "2015-07-28 01:09:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UBC CTLT",
      "screen_name" : "UBC_CTLT",
      "indices" : [ 3, 12 ],
      "id_str" : "16368476",
      "id" : 16368476
    }, {
      "name" : "Inside Higher Ed",
      "screen_name" : "insidehighered",
      "indices" : [ 63, 78 ],
      "id_str" : "16045268",
      "id" : 16045268
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EduNews",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/Zg5kRXgL63",
      "expanded_url" : "http:\/\/ow.ly\/PWIaC",
      "display_url" : "ow.ly\/PWIaC"
    } ]
  },
  "geo" : { },
  "id_str" : "625833871947337728",
  "text" : "RT @UBC_CTLT: Teaching is mentoring http:\/\/t.co\/Zg5kRXgL63 via @insidehighered #EduNews",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Inside Higher Ed",
        "screen_name" : "insidehighered",
        "indices" : [ 49, 64 ],
        "id_str" : "16045268",
        "id" : 16045268
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EduNews",
        "indices" : [ 65, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/Zg5kRXgL63",
        "expanded_url" : "http:\/\/ow.ly\/PWIaC",
        "display_url" : "ow.ly\/PWIaC"
      } ]
    },
    "geo" : { },
    "id_str" : "625833571425615872",
    "text" : "Teaching is mentoring http:\/\/t.co\/Zg5kRXgL63 via @insidehighered #EduNews",
    "id" : 625833571425615872,
    "created_at" : "2015-07-28 01:02:05 +0000",
    "user" : {
      "name" : "UBC CTLT",
      "screen_name" : "UBC_CTLT",
      "protected" : false,
      "id_str" : "16368476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669315281815105536\/xJtGMvol_normal.jpg",
      "id" : 16368476,
      "verified" : false
    }
  },
  "id" : 625833871947337728,
  "created_at" : "2015-07-28 01:03:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625809344244789248",
  "text" : "I often find it helpful to view teaching as a conversation with (and between) learners.",
  "id" : 625809344244789248,
  "created_at" : "2015-07-27 23:25:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Weckler",
      "screen_name" : "adrianweckler",
      "indices" : [ 3, 17 ],
      "id_str" : "18080002",
      "id" : 18080002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/JoypZwXpVj",
      "expanded_url" : "http:\/\/googlewebmastercentral.blogspot.ie\/2015\/07\/google-case-study-on-app-download-interstitials.html",
      "display_url" : "googlewebmastercentral.blogspot.ie\/2015\/07\/google\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "625708297010548736",
  "text" : "RT @adrianweckler: Google says 69% of us abandon a mobile web page when we're fed a 'get our app' pop-up http:\/\/t.co\/JoypZwXpVj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/JoypZwXpVj",
        "expanded_url" : "http:\/\/googlewebmastercentral.blogspot.ie\/2015\/07\/google-case-study-on-app-download-interstitials.html",
        "display_url" : "googlewebmastercentral.blogspot.ie\/2015\/07\/google\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "625585231366627328",
    "text" : "Google says 69% of us abandon a mobile web page when we're fed a 'get our app' pop-up http:\/\/t.co\/JoypZwXpVj",
    "id" : 625585231366627328,
    "created_at" : "2015-07-27 08:35:16 +0000",
    "user" : {
      "name" : "Adrian Weckler",
      "screen_name" : "adrianweckler",
      "protected" : false,
      "id_str" : "18080002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655483831772925952\/IkooiJAE_normal.png",
      "id" : 18080002,
      "verified" : true
    }
  },
  "id" : 625708297010548736,
  "created_at" : "2015-07-27 16:44:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625707789634043904",
  "text" : "This round of \"Next Gen\" LMS's seem to be getting bigger &amp; bigger. I'd like a more modular approach to support different front-ends... you?",
  "id" : 625707789634043904,
  "created_at" : "2015-07-27 16:42:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "indices" : [ 3, 15 ],
      "id_str" : "19812150",
      "id" : 19812150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/Bp4GlkOIVL",
      "expanded_url" : "http:\/\/wp.me\/pi2SZ-2BH",
      "display_url" : "wp.me\/pi2SZ-2BH"
    } ]
  },
  "geo" : { },
  "id_str" : "625082943426334720",
  "text" : "RT @drtonybates: Privacy and the use of learning analytics at http:\/\/t.co\/Bp4GlkOIVL discusses FT article on 'Students under surveillance'",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/Bp4GlkOIVL",
        "expanded_url" : "http:\/\/wp.me\/pi2SZ-2BH",
        "display_url" : "wp.me\/pi2SZ-2BH"
      } ]
    },
    "geo" : { },
    "id_str" : "625074693167431680",
    "text" : "Privacy and the use of learning analytics at http:\/\/t.co\/Bp4GlkOIVL discusses FT article on 'Students under surveillance'",
    "id" : 625074693167431680,
    "created_at" : "2015-07-25 22:46:34 +0000",
    "user" : {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "protected" : false,
      "id_str" : "19812150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2563456751\/wicaixr93w2lri2wsarw_normal.jpeg",
      "id" : 19812150,
      "verified" : false
    }
  },
  "id" : 625082943426334720,
  "created_at" : "2015-07-25 23:19:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucas Wright",
      "screen_name" : "Lucwrite",
      "indices" : [ 0, 9 ],
      "id_str" : "36246383",
      "id" : 36246383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624428523273334784",
  "geo" : { },
  "id_str" : "624744970486845440",
  "in_reply_to_user_id" : 36246383,
  "text" : "@Lucwrite Great, sent you a message via LinkedIn",
  "id" : 624744970486845440,
  "in_reply_to_status_id" : 624428523273334784,
  "created_at" : "2015-07-25 00:56:22 +0000",
  "in_reply_to_screen_name" : "Lucwrite",
  "in_reply_to_user_id_str" : "36246383",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/smdyJsryqL",
      "expanded_url" : "http:\/\/ow.ly\/Q3caI",
      "display_url" : "ow.ly\/Q3caI"
    } ]
  },
  "geo" : { },
  "id_str" : "624689021478801408",
  "text" : "RT @BCcampus: BCcampus Online Event: Free online seminar \"Creating Engaging Online Learning Activities\", starts Aug. 1st. http:\/\/t.co\/smdyJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/smdyJsryqL",
        "expanded_url" : "http:\/\/ow.ly\/Q3caI",
        "display_url" : "ow.ly\/Q3caI"
      } ]
    },
    "geo" : { },
    "id_str" : "624685818930704384",
    "text" : "BCcampus Online Event: Free online seminar \"Creating Engaging Online Learning Activities\", starts Aug. 1st. http:\/\/t.co\/smdyJsryqL",
    "id" : 624685818930704384,
    "created_at" : "2015-07-24 21:01:19 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 624689021478801408,
  "created_at" : "2015-07-24 21:14:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stuart lamour",
      "screen_name" : "stuartlamour",
      "indices" : [ 3, 16 ],
      "id_str" : "8075672",
      "id" : 8075672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moodle",
      "indices" : [ 80, 87 ]
    }, {
      "text" : "devcamp15",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/RyjF8i0RIu",
      "expanded_url" : "https:\/\/moodle.org\/plugins\/view\/atto_bsgrid",
      "display_url" : "moodle.org\/plugins\/view\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "624606024389914624",
  "text" : "RT @stuartlamour: Responsive grids for user generated content lands as official #moodle plugins https:\/\/t.co\/RyjF8i0RIu thanks to #devcamp1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "moodle",
        "indices" : [ 62, 69 ]
      }, {
        "text" : "devcamp15",
        "indices" : [ 112, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/RyjF8i0RIu",
        "expanded_url" : "https:\/\/moodle.org\/plugins\/view\/atto_bsgrid",
        "display_url" : "moodle.org\/plugins\/view\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "624514408245559297",
    "text" : "Responsive grids for user generated content lands as official #moodle plugins https:\/\/t.co\/RyjF8i0RIu thanks to #devcamp15 - bye bye tables!",
    "id" : 624514408245559297,
    "created_at" : "2015-07-24 09:40:12 +0000",
    "user" : {
      "name" : "stuart lamour",
      "screen_name" : "stuartlamour",
      "protected" : false,
      "id_str" : "8075672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684922682886995968\/GvEbcsPG_normal.jpg",
      "id" : 8075672,
      "verified" : false
    }
  },
  "id" : 624606024389914624,
  "created_at" : "2015-07-24 15:44:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Cable",
      "screen_name" : "steve_cable",
      "indices" : [ 3, 15 ],
      "id_str" : "36927904",
      "id" : 36927904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/lcBENxvG2S",
      "expanded_url" : "http:\/\/j.mp\/ux-comic",
      "display_url" : "j.mp\/ux-comic"
    } ]
  },
  "geo" : { },
  "id_str" : "624303005798563840",
  "text" : "RT @steve_cable: Need to tell the story of a user journey? I made a UX comic pattern library. Thought other folk may find it useful http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/lcBENxvG2S",
        "expanded_url" : "http:\/\/j.mp\/ux-comic",
        "display_url" : "j.mp\/ux-comic"
      } ]
    },
    "geo" : { },
    "id_str" : "624205496728309760",
    "text" : "Need to tell the story of a user journey? I made a UX comic pattern library. Thought other folk may find it useful http:\/\/t.co\/lcBENxvG2S",
    "id" : 624205496728309760,
    "created_at" : "2015-07-23 13:12:42 +0000",
    "user" : {
      "name" : "Steve Cable",
      "screen_name" : "steve_cable",
      "protected" : false,
      "id_str" : "36927904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/424458573020532736\/M4bSZBy4_normal.png",
      "id" : 36927904,
      "verified" : false
    }
  },
  "id" : 624303005798563840,
  "created_at" : "2015-07-23 19:40:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624268499100266497",
  "text" : "One of the easiest ways to reduce learner anxiety is to provide a frictionless user experience, ideally in the environment of their choosing",
  "id" : 624268499100266497,
  "created_at" : "2015-07-23 17:23:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624261083612590085",
  "text" : "One of the easiest ways to reduce learner anxiety is to provide a frictionless user experience, ideally on any device of their choosing.",
  "id" : 624261083612590085,
  "created_at" : "2015-07-23 16:53:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Irizarry",
      "screen_name" : "aaroni",
      "indices" : [ 3, 10 ],
      "id_str" : "11758542",
      "id" : 11758542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624236510498258946",
  "text" : "RT @aaroni: Critique should be a dialogue, not a statement. In order to improve the things we are working on we need to have productive con\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624215753374474240",
    "text" : "Critique should be a dialogue, not a statement. In order to improve the things we are working on we need to have productive conversations.",
    "id" : 624215753374474240,
    "created_at" : "2015-07-23 13:53:27 +0000",
    "user" : {
      "name" : "Aaron Irizarry",
      "screen_name" : "aaroni",
      "protected" : false,
      "id_str" : "11758542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745284398044618752\/5GMvcZYE_normal.jpg",
      "id" : 11758542,
      "verified" : false
    }
  },
  "id" : 624236510498258946,
  "created_at" : "2015-07-23 15:15:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy Underhill",
      "screen_name" : "cindyu",
      "indices" : [ 0, 7 ],
      "id_str" : "5540542",
      "id" : 5540542
    }, {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 8, 22 ],
      "id_str" : "260919324",
      "id" : 260919324
    }, {
      "name" : "will engle",
      "screen_name" : "infology",
      "indices" : [ 23, 32 ],
      "id_str" : "93031146",
      "id" : 93031146
    }, {
      "name" : "Lucas Wright",
      "screen_name" : "Lucwrite",
      "indices" : [ 33, 42 ],
      "id_str" : "36246383",
      "id" : 36246383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624059075794374660",
  "in_reply_to_user_id" : 5540542,
  "text" : "@cindyu @clhendricksbc @infology @Lucwrite I'll be at UBC several times next week, if one or more are up for a chat please DM me, cheers!",
  "id" : 624059075794374660,
  "created_at" : "2015-07-23 03:30:52 +0000",
  "in_reply_to_screen_name" : "cindyu",
  "in_reply_to_user_id_str" : "5540542",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bbworld15",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623999659455819776",
  "text" : "Lots of solid UX\/LX design with new learning experience being shown at #bbworld15, but I would have expected a more modular &amp; open approach.",
  "id" : 623999659455819776,
  "created_at" : "2015-07-22 23:34:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stuart lamour",
      "screen_name" : "stuartlamour",
      "indices" : [ 3, 16 ],
      "id_str" : "8075672",
      "id" : 8075672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "snapmoodletheme",
      "indices" : [ 18, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/wSAA4mBBUJ",
      "expanded_url" : "https:\/\/github.com\/moodlerooms\/moodle-theme_snap",
      "display_url" : "github.com\/moodlerooms\/mo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "623884575933009920",
  "text" : "RT @stuartlamour: #snapmoodletheme updated https:\/\/t.co\/wSAA4mBBUJ - 2.7 &amp; 2.8 versions now available",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "snapmoodletheme",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/wSAA4mBBUJ",
        "expanded_url" : "https:\/\/github.com\/moodlerooms\/moodle-theme_snap",
        "display_url" : "github.com\/moodlerooms\/mo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "623884017004363777",
    "text" : "#snapmoodletheme updated https:\/\/t.co\/wSAA4mBBUJ - 2.7 &amp; 2.8 versions now available",
    "id" : 623884017004363777,
    "created_at" : "2015-07-22 15:55:15 +0000",
    "user" : {
      "name" : "stuart lamour",
      "screen_name" : "stuartlamour",
      "protected" : false,
      "id_str" : "8075672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684922682886995968\/GvEbcsPG_normal.jpg",
      "id" : 8075672,
      "verified" : false
    }
  },
  "id" : 623884575933009920,
  "created_at" : "2015-07-22 15:57:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teresa MacKinnon",
      "screen_name" : "WarwickLanguage",
      "indices" : [ 3, 19 ],
      "id_str" : "81817497",
      "id" : 81817497
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WarwickLanguage\/status\/623585979497082880\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/8Rg2CzKM1o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKdsJMJWEAA9ntI.png",
      "id_str" : "623585978549145600",
      "id" : 623585978549145600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKdsJMJWEAA9ntI.png",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8Rg2CzKM1o"
    } ],
    "hashtags" : [ {
      "text" : "moodlerooms",
      "indices" : [ 35, 47 ]
    }, {
      "text" : "bbworld15",
      "indices" : [ 51, 61 ]
    }, {
      "text" : "bbcollaborate",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623676590937890816",
  "text" : "RT @WarwickLanguage: quick demo of #moodlerooms at #bbworld15 using snap theme as part of learner day, along with #bbcollaborate too http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WarwickLanguage\/status\/623585979497082880\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/8Rg2CzKM1o",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKdsJMJWEAA9ntI.png",
        "id_str" : "623585978549145600",
        "id" : 623585978549145600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKdsJMJWEAA9ntI.png",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/8Rg2CzKM1o"
      } ],
      "hashtags" : [ {
        "text" : "moodlerooms",
        "indices" : [ 14, 26 ]
      }, {
        "text" : "bbworld15",
        "indices" : [ 30, 40 ]
      }, {
        "text" : "bbcollaborate",
        "indices" : [ 93, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "623585979497082880",
    "text" : "quick demo of #moodlerooms at #bbworld15 using snap theme as part of learner day, along with #bbcollaborate too http:\/\/t.co\/8Rg2CzKM1o",
    "id" : 623585979497082880,
    "created_at" : "2015-07-21 20:10:57 +0000",
    "user" : {
      "name" : "Teresa MacKinnon",
      "screen_name" : "WarwickLanguage",
      "protected" : false,
      "id_str" : "81817497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754956635450200064\/iN-luRsi_normal.jpg",
      "id" : 81817497,
      "verified" : false
    }
  },
  "id" : 623676590937890816,
  "created_at" : "2015-07-22 02:11:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623617158560395264",
  "text" : "The more I use Activity-Centered Design\/Jobs to be Done the more they seem the best way to move instructors from a content to student view.",
  "id" : 623617158560395264,
  "created_at" : "2015-07-21 22:14:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pramod Sadalage",
      "screen_name" : "pramodsadalage",
      "indices" : [ 0, 15 ],
      "id_str" : "38798458",
      "id" : 38798458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/eZtCReJjQu",
      "expanded_url" : "https:\/\/vimeo.com\/128977703",
      "display_url" : "vimeo.com\/128977703"
    } ]
  },
  "in_reply_to_status_id_str" : "623550722408210432",
  "geo" : { },
  "id_str" : "623570716563116032",
  "in_reply_to_user_id" : 38798458,
  "text" : "@pramodsadalage Very helpful and supportive community as well (critical for me). I also did a preso re: use in edu https:\/\/t.co\/eZtCReJjQu",
  "id" : 623570716563116032,
  "in_reply_to_status_id" : 623550722408210432,
  "created_at" : "2015-07-21 19:10:18 +0000",
  "in_reply_to_screen_name" : "pramodsadalage",
  "in_reply_to_user_id_str" : "38798458",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pramod Sadalage",
      "screen_name" : "pramodsadalage",
      "indices" : [ 0, 15 ],
      "id_str" : "38798458",
      "id" : 38798458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623550722408210432",
  "geo" : { },
  "id_str" : "623570191096479744",
  "in_reply_to_user_id" : 38798458,
  "text" : "@pramodsadalage I've found it faster &amp; more straightforward to use than Statamic. The combination of Flat-file + Twig + Markdown is awesome!",
  "id" : 623570191096479744,
  "in_reply_to_status_id" : 623550722408210432,
  "created_at" : "2015-07-21 19:08:13 +0000",
  "in_reply_to_screen_name" : "pramodsadalage",
  "in_reply_to_user_id_str" : "38798458",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 97, 105 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623567487355871232",
  "text" : "Discovering an obvious yet awesome benefit of creating a course companion with the flat-file CMS @getgrav - *content* is editable on GitHub!",
  "id" : 623567487355871232,
  "created_at" : "2015-07-21 18:57:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 98, 107 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "xapicamp",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/nY2763E3u7",
      "expanded_url" : "https:\/\/twitter.com\/meganbowe\/status\/623535029566595072",
      "display_url" : "twitter.com\/meganbowe\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "623549960361897984",
  "text" : "Exciting to see the foundations of learner experience design model be presented at #xapicamp with @m_travin https:\/\/t.co\/nY2763E3u7",
  "id" : 623549960361897984,
  "created_at" : "2015-07-21 17:47:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 3, 12 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/xHofiZttXA",
      "expanded_url" : "https:\/\/prezi.com\/jbvvwt1mh9sp\/",
      "display_url" : "prezi.com\/jbvvwt1mh9sp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "623540831262105600",
  "text" : "RT @m_travin: I've shared the prezi 'Learning Ecology Framework': https:\/\/t.co\/xHofiZttXA @xapicamp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/xHofiZttXA",
        "expanded_url" : "https:\/\/prezi.com\/jbvvwt1mh9sp\/",
        "display_url" : "prezi.com\/jbvvwt1mh9sp\/"
      } ]
    },
    "geo" : { },
    "id_str" : "623509854594838528",
    "text" : "I've shared the prezi 'Learning Ecology Framework': https:\/\/t.co\/xHofiZttXA @xapicamp",
    "id" : 623509854594838528,
    "created_at" : "2015-07-21 15:08:28 +0000",
    "user" : {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "protected" : false,
      "id_str" : "837060721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765287050069159936\/eekFNEG5_normal.jpg",
      "id" : 837060721,
      "verified" : false
    }
  },
  "id" : 623540831262105600,
  "created_at" : "2015-07-21 17:11:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 3, 12 ],
      "id_str" : "837060721",
      "id" : 837060721
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 73, 88 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "APIcamp",
      "screen_name" : "apicamp",
      "indices" : [ 89, 97 ],
      "id_str" : "2518643575",
      "id" : 2518643575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/RPGEson4Yq",
      "expanded_url" : "http:\/\/bit.ly\/1HEBJVR",
      "display_url" : "bit.ly\/1HEBJVR"
    } ]
  },
  "geo" : { },
  "id_str" : "623334339267309568",
  "text" : "RT @m_travin: Learning Ecology Framework and xAPI. Meaning over matter.  @hibbittsdesign @apicamp  http:\/\/t.co\/RPGEson4Yq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 59, 74 ],
        "id_str" : "15949844",
        "id" : 15949844
      }, {
        "name" : "APIcamp",
        "screen_name" : "apicamp",
        "indices" : [ 75, 83 ],
        "id_str" : "2518643575",
        "id" : 2518643575
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/RPGEson4Yq",
        "expanded_url" : "http:\/\/bit.ly\/1HEBJVR",
        "display_url" : "bit.ly\/1HEBJVR"
      } ]
    },
    "geo" : { },
    "id_str" : "623236927475466240",
    "text" : "Learning Ecology Framework and xAPI. Meaning over matter.  @hibbittsdesign @apicamp  http:\/\/t.co\/RPGEson4Yq",
    "id" : 623236927475466240,
    "created_at" : "2015-07-20 21:03:57 +0000",
    "user" : {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "protected" : false,
      "id_str" : "837060721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765287050069159936\/eekFNEG5_normal.jpg",
      "id" : 837060721,
      "verified" : false
    }
  },
  "id" : 623334339267309568,
  "created_at" : "2015-07-21 03:31:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joyce \u2733\uFE0F",
      "screen_name" : "drjoyce_knudsen",
      "indices" : [ 3, 19 ],
      "id_str" : "46476526",
      "id" : 46476526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/YMDCLxIGKU",
      "expanded_url" : "https:\/\/twitter.com\/DeanHristov\/status\/622621399346192384",
      "display_url" : "twitter.com\/DeanHristov\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "623333618518089728",
  "text" : "RT @drjoyce_knudsen: As a continuous learner, I LOVE this! https:\/\/t.co\/YMDCLxIGKU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/YMDCLxIGKU",
        "expanded_url" : "https:\/\/twitter.com\/DeanHristov\/status\/622621399346192384",
        "display_url" : "twitter.com\/DeanHristov\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "622798153553567744",
    "text" : "As a continuous learner, I LOVE this! https:\/\/t.co\/YMDCLxIGKU",
    "id" : 622798153553567744,
    "created_at" : "2015-07-19 16:00:25 +0000",
    "user" : {
      "name" : "Dr. Joyce \u2733\uFE0F",
      "screen_name" : "drjoyce_knudsen",
      "protected" : false,
      "id_str" : "46476526",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750847765169598464\/UySGCDHV_normal.jpg",
      "id" : 46476526,
      "verified" : false
    }
  },
  "id" : 623333618518089728,
  "created_at" : "2015-07-21 03:28:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Fkwms3KSD6",
      "expanded_url" : "https:\/\/twitter.com\/creativecommons\/status\/621326394295869440",
      "display_url" : "twitter.com\/creativecommon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "623290570887200768",
  "text" : "A great project to support! As I place more my work in the open I am looking for new views on open business models. https:\/\/t.co\/Fkwms3KSD6",
  "id" : 623290570887200768,
  "created_at" : "2015-07-21 00:37:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/623283324585291776\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/33E6bza8Vd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKZY4R_UMAANCW5.png",
      "id_str" : "623283322362277888",
      "id" : 623283322362277888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKZY4R_UMAANCW5.png",
      "sizes" : [ {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      } ],
      "display_url" : "pic.twitter.com\/33E6bza8Vd"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/623283324585291776\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/33E6bza8Vd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKZY4X-UYAE4vhU.png",
      "id_str" : "623283323968708609",
      "id" : 623283323968708609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKZY4X-UYAE4vhU.png",
      "sizes" : [ {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      } ],
      "display_url" : "pic.twitter.com\/33E6bza8Vd"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/623283324585291776\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/33E6bza8Vd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKZY4XuUcAA8Gbw.png",
      "id_str" : "623283323901603840",
      "id" : 623283323901603840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKZY4XuUcAA8Gbw.png",
      "sizes" : [ {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      } ],
      "display_url" : "pic.twitter.com\/33E6bza8Vd"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 60, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/V4gRb8kA5t",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    }, {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/5Ezf5aFzpr",
      "expanded_url" : "https:\/\/github.com\/paulhibbitts\/cmpt-363-153-website",
      "display_url" : "github.com\/paulhibbitts\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "623283324585291776",
  "text" : "Learner experience (LX) design in the open &amp; in action: #SFU CMPT 363 http:\/\/t.co\/V4gRb8kA5t https:\/\/t.co\/5Ezf5aFzpr http:\/\/t.co\/33E6bza8Vd",
  "id" : 623283324585291776,
  "created_at" : "2015-07-21 00:08:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benn Cass",
      "screen_name" : "benncass",
      "indices" : [ 3, 12 ],
      "id_str" : "78269038",
      "id" : 78269038
    }, {
      "name" : "Moodlerooms EMEA",
      "screen_name" : "MoodleroomsEMEA",
      "indices" : [ 21, 37 ],
      "id_str" : "2438287668",
      "id" : 2438287668
    }, {
      "name" : "Moodle",
      "screen_name" : "moodle",
      "indices" : [ 57, 64 ],
      "id_str" : "3948971",
      "id" : 3948971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622878226575069184",
  "text" : "RT @benncass: Loving @MoodleroomsEMEA snap theme! Making @moodle look so modern. Hope they keep pushing updates for it to open source!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Moodlerooms EMEA",
        "screen_name" : "MoodleroomsEMEA",
        "indices" : [ 7, 23 ],
        "id_str" : "2438287668",
        "id" : 2438287668
      }, {
        "name" : "Moodle",
        "screen_name" : "moodle",
        "indices" : [ 43, 50 ],
        "id_str" : "3948971",
        "id" : 3948971
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620894446960439296",
    "text" : "Loving @MoodleroomsEMEA snap theme! Making @moodle look so modern. Hope they keep pushing updates for it to open source!",
    "id" : 620894446960439296,
    "created_at" : "2015-07-14 09:55:46 +0000",
    "user" : {
      "name" : "Benn Cass",
      "screen_name" : "benncass",
      "protected" : false,
      "id_str" : "78269038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000866170062\/tb5JZbZv_normal.jpeg",
      "id" : 78269038,
      "verified" : false
    }
  },
  "id" : 622878226575069184,
  "created_at" : "2015-07-19 21:18:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Floro",
      "screen_name" : "nickfloro",
      "indices" : [ 3, 13 ],
      "id_str" : "15578710",
      "id" : 15578710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/jnQwQjGVWs",
      "expanded_url" : "http:\/\/thenextweb.com\/insider\/2015\/07\/19\/pocketrocket-helps-you-slim-down-your-pocket-account-by-emailing-and-archiving-articles\/",
      "display_url" : "thenextweb.com\/insider\/2015\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "622829564423606272",
  "text" : "RT @nickfloro: PocketRocket helps you slim down your Pocket account by emailing and archiving articles http:\/\/t.co\/jnQwQjGVWs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/jnQwQjGVWs",
        "expanded_url" : "http:\/\/thenextweb.com\/insider\/2015\/07\/19\/pocketrocket-helps-you-slim-down-your-pocket-account-by-emailing-and-archiving-articles\/",
        "display_url" : "thenextweb.com\/insider\/2015\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "622825498561904640",
    "text" : "PocketRocket helps you slim down your Pocket account by emailing and archiving articles http:\/\/t.co\/jnQwQjGVWs",
    "id" : 622825498561904640,
    "created_at" : "2015-07-19 17:49:05 +0000",
    "user" : {
      "name" : "Nick Floro",
      "screen_name" : "nickfloro",
      "protected" : false,
      "id_str" : "15578710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/130051719\/Nick-Photo-Side_0508c_normal.jpg",
      "id" : 15578710,
      "verified" : false
    }
  },
  "id" : 622829564423606272,
  "created_at" : "2015-07-19 18:05:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Warren Anthony",
      "screen_name" : "wjanthony",
      "indices" : [ 0, 10 ],
      "id_str" : "5752072",
      "id" : 5752072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/TDd9Y9CTvc",
      "expanded_url" : "http:\/\/www.theatlantic.com\/magazine\/archive\/2015\/07\/world-without-work\/395294\/",
      "display_url" : "theatlantic.com\/magazine\/archi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "622219620183715840",
  "geo" : { },
  "id_str" : "622220652599095297",
  "in_reply_to_user_id" : 5752072,
  "text" : "@wjanthony Good companion article... http:\/\/t.co\/TDd9Y9CTvc",
  "id" : 622220652599095297,
  "in_reply_to_status_id" : 622219620183715840,
  "created_at" : "2015-07-18 01:45:38 +0000",
  "in_reply_to_screen_name" : "wjanthony",
  "in_reply_to_user_id_str" : "5752072",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 0, 14 ],
      "id_str" : "10451462",
      "id" : 10451462
    }, {
      "name" : "Phil Denman",
      "screen_name" : "PhilSDSU",
      "indices" : [ 15, 24 ],
      "id_str" : "1906858195",
      "id" : 1906858195
    }, {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 25, 40 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 41, 49 ],
      "id_str" : "7693002",
      "id" : 7693002
    }, {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 63, 72 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621591910340136960",
  "geo" : { },
  "id_str" : "621743338962747397",
  "in_reply_to_user_id" : 10451462,
  "text" : "@catspyjamasnz @PhilSDSU @whitneykilgore @jlknott My colleague @m_travin might be interested in contributing a post too.",
  "id" : 621743338962747397,
  "in_reply_to_status_id" : 621591910340136960,
  "created_at" : "2015-07-16 18:08:58 +0000",
  "in_reply_to_screen_name" : "catspyjamasnz",
  "in_reply_to_user_id_str" : "10451462",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 0, 8 ],
      "id_str" : "7693002",
      "id" : 7693002
    }, {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 9, 23 ],
      "id_str" : "10451462",
      "id" : 10451462
    }, {
      "name" : "Phil Denman",
      "screen_name" : "PhilSDSU",
      "indices" : [ 24, 33 ],
      "id_str" : "1906858195",
      "id" : 1906858195
    }, {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 34, 49 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 50, 59 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621734398560456704",
  "geo" : { },
  "id_str" : "621736069277487104",
  "in_reply_to_user_id" : 7693002,
  "text" : "@jlknott @catspyjamasnz @PhilSDSU @whitneykilgore @m_travin ...and that all three elements are interconnected and affect each other.",
  "id" : 621736069277487104,
  "in_reply_to_status_id" : 621734398560456704,
  "created_at" : "2015-07-16 17:40:04 +0000",
  "in_reply_to_screen_name" : "jlknott",
  "in_reply_to_user_id_str" : "7693002",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 0, 8 ],
      "id_str" : "7693002",
      "id" : 7693002
    }, {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 9, 23 ],
      "id_str" : "10451462",
      "id" : 10451462
    }, {
      "name" : "Phil Denman",
      "screen_name" : "PhilSDSU",
      "indices" : [ 24, 33 ],
      "id_str" : "1906858195",
      "id" : 1906858195
    }, {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 34, 49 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 50, 59 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621734398560456704",
  "geo" : { },
  "id_str" : "621735684647161857",
  "in_reply_to_user_id" : 7693002,
  "text" : "@jlknott @catspyjamasnz @PhilSDSU @whitneykilgore @m_travin  Among other things, it shows the full-stack of UX is part of LX,  and...",
  "id" : 621735684647161857,
  "in_reply_to_status_id" : 621734398560456704,
  "created_at" : "2015-07-16 17:38:33 +0000",
  "in_reply_to_screen_name" : "jlknott",
  "in_reply_to_user_id_str" : "7693002",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 0, 8 ],
      "id_str" : "7693002",
      "id" : 7693002
    }, {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 9, 23 ],
      "id_str" : "10451462",
      "id" : 10451462
    }, {
      "name" : "Phil Denman",
      "screen_name" : "PhilSDSU",
      "indices" : [ 24, 33 ],
      "id_str" : "1906858195",
      "id" : 1906858195
    }, {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 34, 49 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 121, 130 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621734398560456704",
  "geo" : { },
  "id_str" : "621734872889950209",
  "in_reply_to_user_id" : 7693002,
  "text" : "@jlknott @catspyjamasnz @PhilSDSU @whitneykilgore Yes, the model was recently created in collaboration with my colleague @m_travin.",
  "id" : 621734872889950209,
  "in_reply_to_status_id" : 621734398560456704,
  "created_at" : "2015-07-16 17:35:19 +0000",
  "in_reply_to_screen_name" : "jlknott",
  "in_reply_to_user_id_str" : "7693002",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 0, 14 ],
      "id_str" : "10451462",
      "id" : 10451462
    }, {
      "name" : "Phil Denman",
      "screen_name" : "PhilSDSU",
      "indices" : [ 15, 24 ],
      "id_str" : "1906858195",
      "id" : 1906858195
    }, {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 25, 40 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 41, 49 ],
      "id_str" : "7693002",
      "id" : 7693002
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/621733040960606208\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/avZm9V58Pu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKDW591UsAAxTY2.jpg",
      "id_str" : "621733039916232704",
      "id" : 621733039916232704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKDW591UsAAxTY2.jpg",
      "sizes" : [ {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      } ],
      "display_url" : "pic.twitter.com\/avZm9V58Pu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621591910340136960",
  "geo" : { },
  "id_str" : "621733040960606208",
  "in_reply_to_user_id" : 10451462,
  "text" : "@catspyjamasnz @PhilSDSU @whitneykilgore @jlknott In the meantime, you might be interested in this other LX model too http:\/\/t.co\/avZm9V58Pu",
  "id" : 621733040960606208,
  "in_reply_to_status_id" : 621591910340136960,
  "created_at" : "2015-07-16 17:28:02 +0000",
  "in_reply_to_screen_name" : "catspyjamasnz",
  "in_reply_to_user_id_str" : "10451462",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 0, 14 ],
      "id_str" : "10451462",
      "id" : 10451462
    }, {
      "name" : "Phil Denman",
      "screen_name" : "PhilSDSU",
      "indices" : [ 15, 24 ],
      "id_str" : "1906858195",
      "id" : 1906858195
    }, {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 25, 40 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 41, 49 ],
      "id_str" : "7693002",
      "id" : 7693002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621591910340136960",
  "geo" : { },
  "id_str" : "621731108103680000",
  "in_reply_to_user_id" : 10451462,
  "text" : "@catspyjamasnz @PhilSDSU @whitneykilgore @jlknott Thanks for the kind invite,  but I've got some other items needing tending to first.",
  "id" : 621731108103680000,
  "in_reply_to_status_id" : 621591910340136960,
  "created_at" : "2015-07-16 17:20:22 +0000",
  "in_reply_to_screen_name" : "catspyjamasnz",
  "in_reply_to_user_id_str" : "10451462",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Denman",
      "screen_name" : "PhilSDSU",
      "indices" : [ 0, 9 ],
      "id_str" : "1906858195",
      "id" : 1906858195
    }, {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 10, 25 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 26, 34 ],
      "id_str" : "7693002",
      "id" : 7693002
    }, {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 35, 49 ],
      "id_str" : "10451462",
      "id" : 10451462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621521720852156416",
  "geo" : { },
  "id_str" : "621522776294191105",
  "in_reply_to_user_id" : 1906858195,
  "text" : "@PhilSDSU @whitneykilgore @jlknott @catspyjamasnz Happy to further discuss however you like.",
  "id" : 621522776294191105,
  "in_reply_to_status_id" : 621521720852156416,
  "created_at" : "2015-07-16 03:32:31 +0000",
  "in_reply_to_screen_name" : "PhilSDSU",
  "in_reply_to_user_id_str" : "1906858195",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 10, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/oRyjK8Suj2",
      "expanded_url" : "https:\/\/workflowy.com\/s\/NaWNC7wj4A",
      "display_url" : "workflowy.com\/s\/NaWNC7wj4A"
    } ]
  },
  "geo" : { },
  "id_str" : "621372807427981312",
  "text" : "Are you a #SFU student registered in CMPT 363? Here is an in-progress course map to help decide if it's for you: https:\/\/t.co\/oRyjK8Suj2",
  "id" : 621372807427981312,
  "created_at" : "2015-07-15 17:36:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 0, 8 ],
      "id_str" : "7693002",
      "id" : 7693002
    }, {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 9, 24 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 25, 39 ],
      "id_str" : "10451462",
      "id" : 10451462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/EJELK4wFHB",
      "expanded_url" : "http:\/\/paulhibbitts.com",
      "display_url" : "paulhibbitts.com"
    } ]
  },
  "in_reply_to_status_id_str" : "621328671182319616",
  "geo" : { },
  "id_str" : "621333364402839552",
  "in_reply_to_user_id" : 7693002,
  "text" : "@jlknott @whitneykilgore @catspyjamasnz Thanks for considering my feedback. Happy to discuss more via email paul at http:\/\/t.co\/EJELK4wFHB",
  "id" : 621333364402839552,
  "in_reply_to_status_id" : 621328671182319616,
  "created_at" : "2015-07-15 14:59:52 +0000",
  "in_reply_to_screen_name" : "jlknott",
  "in_reply_to_user_id_str" : "7693002",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 0, 8 ],
      "id_str" : "7693002",
      "id" : 7693002
    }, {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 9, 24 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 25, 39 ],
      "id_str" : "10451462",
      "id" : 10451462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621320703552270339",
  "geo" : { },
  "id_str" : "621321046575058944",
  "in_reply_to_user_id" : 15949844,
  "text" : "@jlknott @whitneykilgore @catspyjamasnz (4\/4) Hope that explains why I am concerned about framing LX as a subset of UX. Thoughts?",
  "id" : 621321046575058944,
  "in_reply_to_status_id" : 621320703552270339,
  "created_at" : "2015-07-15 14:10:55 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 0, 8 ],
      "id_str" : "7693002",
      "id" : 7693002
    }, {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 9, 24 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 25, 39 ],
      "id_str" : "10451462",
      "id" : 10451462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621287586762477568",
  "geo" : { },
  "id_str" : "621320924097175553",
  "in_reply_to_user_id" : 7693002,
  "text" : "@jlknott @whitneykilgore @catspyjamasnz (3\/4) For example, in my experience I cannot think of any UX concept\/technique not valuable to LX.",
  "id" : 621320924097175553,
  "in_reply_to_status_id" : 621287586762477568,
  "created_at" : "2015-07-15 14:10:26 +0000",
  "in_reply_to_screen_name" : "jlknott",
  "in_reply_to_user_id_str" : "7693002",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 0, 8 ],
      "id_str" : "7693002",
      "id" : 7693002
    }, {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 9, 24 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 25, 39 ],
      "id_str" : "10451462",
      "id" : 10451462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621287586762477568",
  "geo" : { },
  "id_str" : "621320805121568768",
  "in_reply_to_user_id" : 7693002,
  "text" : "@jlknott @whitneykilgore @catspyjamasnz (2\/4) concern is that stating LX is a subset of UX could unintentionally confuse\/mislead educators.",
  "id" : 621320805121568768,
  "in_reply_to_status_id" : 621287586762477568,
  "created_at" : "2015-07-15 14:09:58 +0000",
  "in_reply_to_screen_name" : "jlknott",
  "in_reply_to_user_id_str" : "7693002",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 0, 8 ],
      "id_str" : "7693002",
      "id" : 7693002
    }, {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 9, 24 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 25, 39 ],
      "id_str" : "10451462",
      "id" : 10451462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621287586762477568",
  "geo" : { },
  "id_str" : "621320703552270339",
  "in_reply_to_user_id" : 7693002,
  "text" : "@jlknott @whitneykilgore @catspyjamasnz (1\/4) Awesome that you are highlighting the ongoing importance of UX in educational design, but my",
  "id" : 621320703552270339,
  "in_reply_to_status_id" : 621287586762477568,
  "created_at" : "2015-07-15 14:09:33 +0000",
  "in_reply_to_screen_name" : "jlknott",
  "in_reply_to_user_id_str" : "7693002",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 0, 15 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Canvas LMS",
      "screen_name" : "CanvasLMS",
      "indices" : [ 16, 26 ],
      "id_str" : "41847236",
      "id" : 41847236
    }, {
      "name" : "LX Design",
      "screen_name" : "lxdesignco",
      "indices" : [ 27, 38 ],
      "id_str" : "3223579116",
      "id" : 3223579116
    }, {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 39, 53 ],
      "id_str" : "10451462",
      "id" : 10451462
    }, {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 54, 62 ],
      "id_str" : "7693002",
      "id" : 7693002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621116406390636546",
  "geo" : { },
  "id_str" : "621119283167260672",
  "in_reply_to_user_id" : 12915742,
  "text" : "@whitneykilgore @CanvasLMS @lxdesignco @catspyjamasnz @jlknott Thanks Whitney, I look forward to learning more and sharing my concerns.",
  "id" : 621119283167260672,
  "in_reply_to_status_id" : 621116406390636546,
  "created_at" : "2015-07-15 00:49:11 +0000",
  "in_reply_to_screen_name" : "whitneykilgore",
  "in_reply_to_user_id_str" : "12915742",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 0, 15 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Canvas LMS",
      "screen_name" : "CanvasLMS",
      "indices" : [ 16, 26 ],
      "id_str" : "41847236",
      "id" : 41847236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621110468652855300",
  "geo" : { },
  "id_str" : "621115336524324864",
  "in_reply_to_user_id" : 12915742,
  "text" : "@whitneykilgore @CanvasLMS I really like this talk Whitney, thanks for sharing. I wonder though why LX is presented as a subset of UX?",
  "id" : 621115336524324864,
  "in_reply_to_status_id" : 621110468652855300,
  "created_at" : "2015-07-15 00:33:30 +0000",
  "in_reply_to_screen_name" : "whitneykilgore",
  "in_reply_to_user_id_str" : "12915742",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Haw",
      "screen_name" : "andrewhawr",
      "indices" : [ 0, 11 ],
      "id_str" : "742214790",
      "id" : 742214790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621097906943057920",
  "geo" : { },
  "id_str" : "621099695012614144",
  "in_reply_to_user_id" : 742214790,
  "text" : "@andrewhawr Hey Andrew, I agree that could be a plausible reason... sad if true. The cost vs. benefit boggles my mind.",
  "id" : 621099695012614144,
  "in_reply_to_status_id" : 621097906943057920,
  "created_at" : "2015-07-14 23:31:21 +0000",
  "in_reply_to_screen_name" : "andrewhawr",
  "in_reply_to_user_id_str" : "742214790",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 72, 87 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 91, 100 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/Ht0UcOiZIR",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/20140923193943-572658-course-companion-learner-experience-principles",
      "display_url" : "linkedin.com\/pulse\/20140923\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621095018900516864",
  "text" : "Re: last Tweet -&gt; \"(Multi-device) Learning Experience Principles\" by @hibbittsdesign on @LinkedIn https:\/\/t.co\/Ht0UcOiZIR",
  "id" : 621095018900516864,
  "created_at" : "2015-07-14 23:12:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621093896047562752",
  "text" : "It's 2015... why would anyone create a OS-specific mobile app for their classes rather than a multi-device Web app?",
  "id" : 621093896047562752,
  "created_at" : "2015-07-14 23:08:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/iCdHZRzcp7",
      "expanded_url" : "https:\/\/trello.com\/b\/taTJiyYO\/cmpt-363-153-high-level-roadmap",
      "display_url" : "trello.com\/b\/taTJiyYO\/cmp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621082749143613440",
  "text" : "Inspired by the GOV.UK public roadmap Trello board, I've created a board for CMPT 363 changes during this term. https:\/\/t.co\/iCdHZRzcp7",
  "id" : 621082749143613440,
  "created_at" : "2015-07-14 22:24:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 31, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/V4gRb8kA5t",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "621024483709616129",
  "text" : "And that's a wrap, CMPT 363 at #SFU is fully loaded with a waitlist. Super excited about the upcoming term! http:\/\/t.co\/V4gRb8kA5t",
  "id" : 621024483709616129,
  "created_at" : "2015-07-14 18:32:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 22, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/I4PQbQnw4x",
      "expanded_url" : "https:\/\/workflowy.com\/s\/RGBbU0I96E",
      "display_url" : "workflowy.com\/s\/RGBbU0I96E"
    } ]
  },
  "geo" : { },
  "id_str" : "621011698472726528",
  "text" : "Seats for CMPT 363 at #SFU this Fall are almost all gone - only 4 left. In-progress learning outcomes and assessment https:\/\/t.co\/I4PQbQnw4x",
  "id" : 621011698472726528,
  "created_at" : "2015-07-14 17:41:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 76, 88 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/B2cMg2so8t",
      "expanded_url" : "http:\/\/kck.st\/1fCU0d1",
      "display_url" : "kck.st\/1fCU0d1"
    } ]
  },
  "geo" : { },
  "id_str" : "620973240593190913",
  "text" : "I just backed Made with Creative Commons: A book on open business models on @Kickstarter http:\/\/t.co\/B2cMg2so8t",
  "id" : 620973240593190913,
  "created_at" : "2015-07-14 15:08:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Jeffries",
      "screen_name" : "developwithdan",
      "indices" : [ 3, 18 ],
      "id_str" : "188946965",
      "id" : 188946965
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moodle",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "connectmore",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/juHona0FqI",
      "expanded_url" : "https:\/\/moodle.org\/plugins\/view\/mod_bootstrapelements",
      "display_url" : "moodle.org\/plugins\/view\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620794276293705728",
  "text" : "RT @developwithdan: For all the #moodle users out there, this is one of the most useful plugins I've seen in a long time: https:\/\/t.co\/juHo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "moodle",
        "indices" : [ 12, 19 ]
      }, {
        "text" : "connectmore",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/juHona0FqI",
        "expanded_url" : "https:\/\/moodle.org\/plugins\/view\/mod_bootstrapelements",
        "display_url" : "moodle.org\/plugins\/view\/m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "620583256430264320",
    "text" : "For all the #moodle users out there, this is one of the most useful plugins I've seen in a long time: https:\/\/t.co\/juHona0FqI #connectmore",
    "id" : 620583256430264320,
    "created_at" : "2015-07-13 13:19:12 +0000",
    "user" : {
      "name" : "Dan Jeffries",
      "screen_name" : "developwithdan",
      "protected" : false,
      "id_str" : "188946965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1126785871\/head_shot_normal.jpg",
      "id" : 188946965,
      "verified" : false
    }
  },
  "id" : 620794276293705728,
  "created_at" : "2015-07-14 03:17:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 0, 7 ],
      "id_str" : "745903",
      "id" : 745903
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "udgagora",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620658012391256064",
  "geo" : { },
  "id_str" : "620737731006566400",
  "in_reply_to_user_id" : 745903,
  "text" : "@brlamb Open resources = a wider range of educational choices, which enables instructors to be more flexible with course design. #udgagora",
  "id" : 620737731006566400,
  "in_reply_to_status_id" : 620658012391256064,
  "created_at" : "2015-07-13 23:33:02 +0000",
  "in_reply_to_screen_name" : "brlamb",
  "in_reply_to_user_id_str" : "745903",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620722850677174272",
  "text" : "I am fortunate to design experiences that support a dialog with their audience, which then helps me to continually improve that experience.",
  "id" : 620722850677174272,
  "created_at" : "2015-07-13 22:33:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 3, 18 ],
      "id_str" : "1122631",
      "id" : 1122631
    }, {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 45, 61 ],
      "id_str" : "17349291",
      "id" : 17349291
    }, {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 91, 106 ],
      "id_str" : "1122631",
      "id" : 1122631
    }, {
      "name" : "LadiesThatUX_Van",
      "screen_name" : "LadiesThatUXvan",
      "indices" : [ 118, 134 ],
      "id_str" : "3174853916",
      "id" : 3174853916
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620706063390670848",
  "text" : "RT @MalloryOConnor: Super stoked about this! @HabaneroConsult Come out and hear Habanero's @MalloryOConnor speak on a @LadiesThatUXvan pane\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Habanero",
        "screen_name" : "HabaneroConsult",
        "indices" : [ 25, 41 ],
        "id_str" : "17349291",
        "id" : 17349291
      }, {
        "name" : "Mallory O'Connor",
        "screen_name" : "MalloryOConnor",
        "indices" : [ 71, 86 ],
        "id_str" : "1122631",
        "id" : 1122631
      }, {
        "name" : "LadiesThatUX_Van",
        "screen_name" : "LadiesThatUXvan",
        "indices" : [ 98, 114 ],
        "id_str" : "3174853916",
        "id" : 3174853916
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "620695701941387264",
    "geo" : { },
    "id_str" : "620696171644751872",
    "in_reply_to_user_id" : 17349291,
    "text" : "Super stoked about this! @HabaneroConsult Come out and hear Habanero's @MalloryOConnor speak on a @LadiesThatUXvan panel this Wednesday! #UX",
    "id" : 620696171644751872,
    "in_reply_to_status_id" : 620695701941387264,
    "created_at" : "2015-07-13 20:47:53 +0000",
    "in_reply_to_screen_name" : "HabaneroConsult",
    "in_reply_to_user_id_str" : "17349291",
    "user" : {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "protected" : false,
      "id_str" : "1122631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2261747531\/mallory_thumbnail_normal.png",
      "id" : 1122631,
      "verified" : false
    }
  },
  "id" : 620706063390670848,
  "created_at" : "2015-07-13 21:27:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 108, 116 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5Ezf5aFzpr",
      "expanded_url" : "https:\/\/github.com\/paulhibbitts\/cmpt-363-153-website",
      "display_url" : "github.com\/paulhibbitts\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620648039124840448",
  "text" : "I'll also be sharing the source code for the CMPT 363 course companion on GitHub this time around, built w. @getgrav https:\/\/t.co\/5Ezf5aFzpr",
  "id" : 620648039124840448,
  "created_at" : "2015-07-13 17:36:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 23, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/V4gRb8Cbu3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "620645926500212736",
  "text" : "Looks like CMPT 363 at #SFU for this Fall is starting to fill up, 48 students so far. In-progress course companion at http:\/\/t.co\/V4gRb8Cbu3",
  "id" : 620645926500212736,
  "created_at" : "2015-07-13 17:28:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daryl Claudio",
      "screen_name" : "darylclaudio",
      "indices" : [ 0, 13 ],
      "id_str" : "14256762",
      "id" : 14256762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620368061141364736",
  "geo" : { },
  "id_str" : "620370466537017344",
  "in_reply_to_user_id" : 14256762,
  "text" : "@darylclaudio Let me know if you get a chance to try it... I hate to say it but I found the Windows 8.1 approach much easier to pickup.",
  "id" : 620370466537017344,
  "in_reply_to_status_id" : 620368061141364736,
  "created_at" : "2015-07-12 23:13:39 +0000",
  "in_reply_to_screen_name" : "darylclaudio",
  "in_reply_to_user_id_str" : "14256762",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daryl Claudio",
      "screen_name" : "darylclaudio",
      "indices" : [ 0, 13 ],
      "id_str" : "14256762",
      "id" : 14256762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620365772041269250",
  "geo" : { },
  "id_str" : "620366584226299906",
  "in_reply_to_user_id" : 14256762,
  "text" : "@darylclaudio And on other fronts, have you tried out the Split View feature in the 10.11 Beta? The word atrocious also comes to mind...",
  "id" : 620366584226299906,
  "in_reply_to_status_id" : 620365772041269250,
  "created_at" : "2015-07-12 22:58:14 +0000",
  "in_reply_to_screen_name" : "darylclaudio",
  "in_reply_to_user_id_str" : "14256762",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620009867755941888",
  "text" : "Wow, the Mac El Capitan Beta new split screen mode is a disaster... talk about a convoluted interaction design. How about other Beta users?",
  "id" : 620009867755941888,
  "created_at" : "2015-07-11 23:20:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "619596837603840000",
  "text" : "Still awaiting official word on CMPT 363 this Fall, but in the meantime GitHub \u27A8 DeployHQ \u27A8 Web host is working well http:\/\/t.co\/I7fZ1cnbn3",
  "id" : 619596837603840000,
  "created_at" : "2015-07-10 19:59:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619582570670338048",
  "text" : "ECORE - positive learner experience (LX) qualities:\n\n\u2713Engaging\n\u2713Convenient\n\u2713Organized\n\u2713Relevant\n\u2713Enjoyable",
  "id" : 619582570670338048,
  "created_at" : "2015-07-10 19:02:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 72, 80 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/1tjvw2ekxh",
      "expanded_url" : "https:\/\/twitter.com\/PaulBovis\/status\/619272199455641600",
      "display_url" : "twitter.com\/PaulBovis\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619273527443632128",
  "text" : "Good coffee, friendly company, and talking about education + my fav CMS @GetGrav... it just doesn't get any better! https:\/\/t.co\/1tjvw2ekxh",
  "id" : 619273527443632128,
  "created_at" : "2015-07-09 22:34:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dixon",
      "screen_name" : "cdixon",
      "indices" : [ 3, 10 ],
      "id_str" : "2529971",
      "id" : 2529971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619003850226208769",
  "text" : "RT @cdixon: Open source went from a fringe movement to total domination in &lt;20 years.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618977220007206912",
    "text" : "Open source went from a fringe movement to total domination in &lt;20 years.",
    "id" : 618977220007206912,
    "created_at" : "2015-07-09 02:57:23 +0000",
    "user" : {
      "name" : "Chris Dixon",
      "screen_name" : "cdixon",
      "protected" : false,
      "id_str" : "2529971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683496924104658944\/8Oa5XAso_normal.png",
      "id" : 2529971,
      "verified" : true
    }
  },
  "id" : 619003850226208769,
  "created_at" : "2015-07-09 04:43:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618849412631109632",
  "text" : "Elements that I am finding helpful in supporting more hot swappable course elements: broad learning outcomes, no textbook, &amp; MORE structure.",
  "id" : 618849412631109632,
  "created_at" : "2015-07-08 18:29:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "indices" : [ 3, 15 ],
      "id_str" : "730373",
      "id" : 730373
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/scottjenson\/status\/618605710750928896\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/FDFTTpZnIj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJW6nawUMAA1ihq.png",
      "id_str" : "618605710192947200",
      "id" : 618605710192947200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJW6nawUMAA1ihq.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 779,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 952,
        "resize" : "fit",
        "w" : 1252
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FDFTTpZnIj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/K3kinzEesj",
      "expanded_url" : "http:\/\/www.marketwatch.com\/story\/apple-watch-may-not-be-ticking-with-customers-2015-07-07",
      "display_url" : "marketwatch.com\/story\/apple-wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618622442257424384",
  "text" : "RT @scottjenson: Apple Watch sales plunge 90%\nhttp:\/\/t.co\/K3kinzEesj http:\/\/t.co\/FDFTTpZnIj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/scottjenson\/status\/618605710750928896\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/FDFTTpZnIj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJW6nawUMAA1ihq.png",
        "id_str" : "618605710192947200",
        "id" : 618605710192947200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJW6nawUMAA1ihq.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 779,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 952,
          "resize" : "fit",
          "w" : 1252
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/FDFTTpZnIj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/K3kinzEesj",
        "expanded_url" : "http:\/\/www.marketwatch.com\/story\/apple-watch-may-not-be-ticking-with-customers-2015-07-07",
        "display_url" : "marketwatch.com\/story\/apple-wa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "618605710750928896",
    "text" : "Apple Watch sales plunge 90%\nhttp:\/\/t.co\/K3kinzEesj http:\/\/t.co\/FDFTTpZnIj",
    "id" : 618605710750928896,
    "created_at" : "2015-07-08 02:21:09 +0000",
    "user" : {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "protected" : false,
      "id_str" : "730373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576892785149628416\/FiovXOSs_normal.jpeg",
      "id" : 730373,
      "verified" : true
    }
  },
  "id" : 618622442257424384,
  "created_at" : "2015-07-08 03:27:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Interactive Design",
      "screen_name" : "iDesignProgram",
      "indices" : [ 3, 18 ],
      "id_str" : "120539124",
      "id" : 120539124
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Design",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/KoazAhaA1f",
      "expanded_url" : "http:\/\/flip.it\/DIawG",
      "display_url" : "flip.it\/DIawG"
    } ]
  },
  "geo" : { },
  "id_str" : "618616955805634560",
  "text" : "RT @iDesignProgram: Why Are #Design Firms Stagnating? http:\/\/t.co\/KoazAhaA1f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.flipboard.com\" rel=\"nofollow\"\u003EFlipboard\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Design",
        "indices" : [ 8, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/KoazAhaA1f",
        "expanded_url" : "http:\/\/flip.it\/DIawG",
        "display_url" : "flip.it\/DIawG"
      } ]
    },
    "geo" : { },
    "id_str" : "618609080106680320",
    "text" : "Why Are #Design Firms Stagnating? http:\/\/t.co\/KoazAhaA1f",
    "id" : 618609080106680320,
    "created_at" : "2015-07-08 02:34:32 +0000",
    "user" : {
      "name" : "Interactive Design",
      "screen_name" : "iDesignProgram",
      "protected" : false,
      "id_str" : "120539124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023192623\/IDL_logo_rgb_onwhite_normal.jpg",
      "id" : 120539124,
      "verified" : false
    }
  },
  "id" : 618616955805634560,
  "created_at" : "2015-07-08 03:05:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "indices" : [ 57, 69 ],
      "id_str" : "19812150",
      "id" : 19812150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618516265913548800",
  "text" : "Inspired to make my CMPT 363 course more agile thanks to @drtonybates talk. First pass: hot swappable elements &amp; student-choice assessments.",
  "id" : 618516265913548800,
  "created_at" : "2015-07-07 20:25:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 43, 48 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "indices" : [ 95, 107 ],
      "id_str" : "19812150",
      "id" : 19812150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/qGqt0b7qdN",
      "expanded_url" : "http:\/\/ow.ly\/P60ve",
      "display_url" : "ow.ly\/P60ve"
    } ]
  },
  "geo" : { },
  "id_str" : "618480435853590528",
  "text" : "RT @BCcampus: Today @ 11AM (PDT): The next @etug T.E.L.L. session &gt; Agile Design: A Chat w\/ @drtonybates http:\/\/t.co\/qGqt0b7qdN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 29, 34 ],
        "id_str" : "17102936",
        "id" : 17102936
      }, {
        "name" : "Tony Bates",
        "screen_name" : "drtonybates",
        "indices" : [ 81, 93 ],
        "id_str" : "19812150",
        "id" : 19812150
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/qGqt0b7qdN",
        "expanded_url" : "http:\/\/ow.ly\/P60ve",
        "display_url" : "ow.ly\/P60ve"
      } ]
    },
    "geo" : { },
    "id_str" : "618439504244903936",
    "text" : "Today @ 11AM (PDT): The next @etug T.E.L.L. session &gt; Agile Design: A Chat w\/ @drtonybates http:\/\/t.co\/qGqt0b7qdN",
    "id" : 618439504244903936,
    "created_at" : "2015-07-07 15:20:42 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 618480435853590528,
  "created_at" : "2015-07-07 18:03:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "indices" : [ 91, 103 ],
      "id_str" : "19812150",
      "id" : 19812150
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 39, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/VlW3GEpmZ7",
      "expanded_url" : "http:\/\/ow.ly\/P60ve",
      "display_url" : "ow.ly\/P60ve"
    } ]
  },
  "geo" : { },
  "id_str" : "618449446020345856",
  "text" : "RT @etug: Today @ 11AM (PDT): The next #ETUG T.E.L.L. session &gt; Agile Design: A Chat w\/ @drtonybates http:\/\/t.co\/VlW3GEpmZ7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tony Bates",
        "screen_name" : "drtonybates",
        "indices" : [ 81, 93 ],
        "id_str" : "19812150",
        "id" : 19812150
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ETUG",
        "indices" : [ 29, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/VlW3GEpmZ7",
        "expanded_url" : "http:\/\/ow.ly\/P60ve",
        "display_url" : "ow.ly\/P60ve"
      } ]
    },
    "geo" : { },
    "id_str" : "618446644565123072",
    "text" : "Today @ 11AM (PDT): The next #ETUG T.E.L.L. session &gt; Agile Design: A Chat w\/ @drtonybates http:\/\/t.co\/VlW3GEpmZ7",
    "id" : 618446644565123072,
    "created_at" : "2015-07-07 15:49:04 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 618449446020345856,
  "created_at" : "2015-07-07 16:00:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "effectiveui",
      "screen_name" : "effectiveui",
      "indices" : [ 3, 15 ],
      "id_str" : "14627322",
      "id" : 14627322
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Android",
      "indices" : [ 85, 93 ]
    }, {
      "text" : "MaterialDesign",
      "indices" : [ 122, 137 ]
    }, {
      "text" : "MDL",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/LYaicB4AYy",
      "expanded_url" : "http:\/\/ow.ly\/Pgifc",
      "display_url" : "ow.ly\/Pgifc"
    } ]
  },
  "geo" : { },
  "id_str" : "618430435224240129",
  "text" : "RT @effectiveui: Google unveils Material Design Lite to help websites look more like #Android apps http:\/\/t.co\/LYaicB4AYy #MaterialDesign #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Android",
        "indices" : [ 68, 76 ]
      }, {
        "text" : "MaterialDesign",
        "indices" : [ 105, 120 ]
      }, {
        "text" : "MDL",
        "indices" : [ 121, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/LYaicB4AYy",
        "expanded_url" : "http:\/\/ow.ly\/Pgifc",
        "display_url" : "ow.ly\/Pgifc"
      } ]
    },
    "geo" : { },
    "id_str" : "618429521247772672",
    "text" : "Google unveils Material Design Lite to help websites look more like #Android apps http:\/\/t.co\/LYaicB4AYy #MaterialDesign #MDL",
    "id" : 618429521247772672,
    "created_at" : "2015-07-07 14:41:02 +0000",
    "user" : {
      "name" : "effectiveui",
      "screen_name" : "effectiveui",
      "protected" : false,
      "id_str" : "14627322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760186329514803200\/np6gVDUY_normal.jpg",
      "id" : 14627322,
      "verified" : false
    }
  },
  "id" : 618430435224240129,
  "created_at" : "2015-07-07 14:44:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618192573727797249",
  "text" : "In terms of learner experience (LX), some issues are pedagogical and some are not. For example, relevance (yes) and convenience (no).",
  "id" : 618192573727797249,
  "created_at" : "2015-07-06 22:59:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 29, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618182833186537474",
  "text" : "Once CMPT 363 (UI Design) at #SFU this Fall is confirmed I'll be revising the course once again in the open. Various improvements planned...",
  "id" : 618182833186537474,
  "created_at" : "2015-07-06 22:20:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618155807759151109",
  "text" : "(2\/2) For example, asking for initial impressions of the site after an exploratory task, and words to describe task experiences. Others?",
  "id" : 618155807759151109,
  "created_at" : "2015-07-06 20:33:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618155752889257985",
  "text" : "(1\/2) While unmoderated usability tests tend to naturally focus on task completion &amp; time, also include more qualitative aspects too.",
  "id" : 618155752889257985,
  "created_at" : "2015-07-06 20:33:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moodle",
      "screen_name" : "moodle",
      "indices" : [ 3, 10 ],
      "id_str" : "3948971",
      "id" : 3948971
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moodlecloud",
      "indices" : [ 56, 68 ]
    }, {
      "text" : "moodlepartners",
      "indices" : [ 69, 84 ]
    }, {
      "text" : "moodle",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/SZu4IV97Pl",
      "expanded_url" : "http:\/\/Moodle.com",
      "display_url" : "Moodle.com"
    }, {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/SZu4IV97Pl",
      "expanded_url" : "http:\/\/Moodle.com",
      "display_url" : "Moodle.com"
    } ]
  },
  "geo" : { },
  "id_str" : "617889218971353092",
  "text" : "RT @moodle: See our new http:\/\/t.co\/SZu4IV97Pl site for #moodlecloud #moodlepartners and stories about #moodle! http:\/\/t.co\/SZu4IV97Pl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "moodlecloud",
        "indices" : [ 44, 56 ]
      }, {
        "text" : "moodlepartners",
        "indices" : [ 57, 72 ]
      }, {
        "text" : "moodle",
        "indices" : [ 91, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/SZu4IV97Pl",
        "expanded_url" : "http:\/\/Moodle.com",
        "display_url" : "Moodle.com"
      }, {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/SZu4IV97Pl",
        "expanded_url" : "http:\/\/Moodle.com",
        "display_url" : "Moodle.com"
      } ]
    },
    "geo" : { },
    "id_str" : "617845424427151361",
    "text" : "See our new http:\/\/t.co\/SZu4IV97Pl site for #moodlecloud #moodlepartners and stories about #moodle! http:\/\/t.co\/SZu4IV97Pl",
    "id" : 617845424427151361,
    "created_at" : "2015-07-06 00:00:02 +0000",
    "user" : {
      "name" : "Moodle",
      "screen_name" : "moodle",
      "protected" : false,
      "id_str" : "3948971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620889119036538880\/Xwbnk5YZ_normal.jpg",
      "id" : 3948971,
      "verified" : true
    }
  },
  "id" : 617889218971353092,
  "created_at" : "2015-07-06 02:54:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy L. Bissette",
      "screen_name" : "TLBissette",
      "indices" : [ 3, 14 ],
      "id_str" : "204032180",
      "id" : 204032180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/kRTmQT0ZkQ",
      "expanded_url" : "http:\/\/ow.ly\/30VdU8",
      "display_url" : "ow.ly\/30VdU8"
    } ]
  },
  "geo" : { },
  "id_str" : "617133950876516352",
  "text" : "RT @TLBissette: Students\u2019 Mobile Learning Practices in Higher Education: A Multi-Year Study http:\/\/t.co\/kRTmQT0ZkQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/kRTmQT0ZkQ",
        "expanded_url" : "http:\/\/ow.ly\/30VdU8",
        "display_url" : "ow.ly\/30VdU8"
      } ]
    },
    "geo" : { },
    "id_str" : "617127545562075136",
    "text" : "Students\u2019 Mobile Learning Practices in Higher Education: A Multi-Year Study http:\/\/t.co\/kRTmQT0ZkQ",
    "id" : 617127545562075136,
    "created_at" : "2015-07-04 00:27:27 +0000",
    "user" : {
      "name" : "Tracy L. Bissette",
      "screen_name" : "TLBissette",
      "protected" : false,
      "id_str" : "204032180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410924455\/d736a7d934b7b10b3199fe9dc6e2dfdf_normal.png",
      "id" : 204032180,
      "verified" : false
    }
  },
  "id" : 617133950876516352,
  "created_at" : "2015-07-04 00:52:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Moodle",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617082293161586689",
  "text" : "Things are continuing to take shape for conducting unmoderated usability tests to compare custom #Moodle Clean theme Vs. Snap theme.",
  "id" : 617082293161586689,
  "created_at" : "2015-07-03 21:27:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loop11",
      "screen_name" : "Loop11",
      "indices" : [ 13, 20 ],
      "id_str" : "18822696",
      "id" : 18822696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617080011372105728",
  "text" : "Shout out to @loop11 for their fantastic support as I learn about the ins and outs of their unmoderated usability testing tool.",
  "id" : 617080011372105728,
  "created_at" : "2015-07-03 21:18:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "indices" : [ 3, 15 ],
      "id_str" : "730373",
      "id" : 730373
    }, {
      "name" : "Filament",
      "screen_name" : "FilamentHQ",
      "indices" : [ 115, 126 ],
      "id_str" : "3028770359",
      "id" : 3028770359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/4UwfCyuTr4",
      "expanded_url" : "https:\/\/medium.com\/@FilamentHQ\/a-declaration-of-device-independence-b6f83e8b6441?source=tw-2b1b86e8ce06-1435878556374",
      "display_url" : "medium.com\/@FilamentHQ\/a-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616750040623661057",
  "text" : "RT @scottjenson: Excellent read on how we should approach smart devices \n\u201CA Declaration of Device Independence\u201D by @FilamentHQ https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Filament",
        "screen_name" : "FilamentHQ",
        "indices" : [ 98, 109 ],
        "id_str" : "3028770359",
        "id" : 3028770359
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/4UwfCyuTr4",
        "expanded_url" : "https:\/\/medium.com\/@FilamentHQ\/a-declaration-of-device-independence-b6f83e8b6441?source=tw-2b1b86e8ce06-1435878556374",
        "display_url" : "medium.com\/@FilamentHQ\/a-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "616745805039316993",
    "text" : "Excellent read on how we should approach smart devices \n\u201CA Declaration of Device Independence\u201D by @FilamentHQ https:\/\/t.co\/4UwfCyuTr4",
    "id" : 616745805039316993,
    "created_at" : "2015-07-02 23:10:33 +0000",
    "user" : {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "protected" : false,
      "id_str" : "730373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576892785149628416\/FiovXOSs_normal.jpeg",
      "id" : 730373,
      "verified" : true
    }
  },
  "id" : 616750040623661057,
  "created_at" : "2015-07-02 23:27:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 23, 28 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "indices" : [ 96, 108 ],
      "id_str" : "19812150",
      "id" : 19812150
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BCcampus\/status\/616680378582089729\/photo\/1",
      "indices" : [ 142, 143 ],
      "url" : "http:\/\/t.co\/mMrANOo4Fs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CI7jiUzWUAAMQiT.jpg",
      "id_str" : "616680377835474944",
      "id" : 616680377835474944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CI7jiUzWUAAMQiT.jpg",
      "sizes" : [ {
        "h" : 1360,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mMrANOo4Fs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/qGqt0b7qdN",
      "expanded_url" : "http:\/\/ow.ly\/P60ve",
      "display_url" : "ow.ly\/P60ve"
    } ]
  },
  "geo" : { },
  "id_str" : "616684511213035520",
  "text" : "RT @BCcampus: The next @ETUG T.E.L.L. session, July 7 @ 11AM (PDT) &gt; Agile Design: A Chat w\/ @drtonybates. http:\/\/t.co\/qGqt0b7qdN http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 9, 14 ],
        "id_str" : "17102936",
        "id" : 17102936
      }, {
        "name" : "Tony Bates",
        "screen_name" : "drtonybates",
        "indices" : [ 82, 94 ],
        "id_str" : "19812150",
        "id" : 19812150
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BCcampus\/status\/616680378582089729\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/mMrANOo4Fs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CI7jiUzWUAAMQiT.jpg",
        "id_str" : "616680377835474944",
        "id" : 616680377835474944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CI7jiUzWUAAMQiT.jpg",
        "sizes" : [ {
          "h" : 1360,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mMrANOo4Fs"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/qGqt0b7qdN",
        "expanded_url" : "http:\/\/ow.ly\/P60ve",
        "display_url" : "ow.ly\/P60ve"
      } ]
    },
    "geo" : { },
    "id_str" : "616680378582089729",
    "text" : "The next @ETUG T.E.L.L. session, July 7 @ 11AM (PDT) &gt; Agile Design: A Chat w\/ @drtonybates. http:\/\/t.co\/qGqt0b7qdN http:\/\/t.co\/mMrANOo4Fs",
    "id" : 616680378582089729,
    "created_at" : "2015-07-02 18:50:34 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 616684511213035520,
  "created_at" : "2015-07-02 19:06:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616384552840224768",
  "text" : "Soon moving from learning outcomes and assessments to a BBQ, must be... CANADA DAY! \uD83C\uDF41",
  "id" : 616384552840224768,
  "created_at" : "2015-07-01 23:15:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denim & Steel",
      "screen_name" : "DenimAndSteel",
      "indices" : [ 3, 17 ],
      "id_str" : "386399234",
      "id" : 386399234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Kwq86aM17B",
      "expanded_url" : "http:\/\/kthx.ca\/mU",
      "display_url" : "kthx.ca\/mU"
    } ]
  },
  "geo" : { },
  "id_str" : "616311589713522688",
  "text" : "RT @DenimAndSteel: We can\u2019t talk about this enough. \n\nMedium goes password-less, using just your email to sign in: http:\/\/t.co\/Kwq86aM17B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/Kwq86aM17B",
        "expanded_url" : "http:\/\/kthx.ca\/mU",
        "display_url" : "kthx.ca\/mU"
      } ]
    },
    "geo" : { },
    "id_str" : "616307700381564928",
    "text" : "We can\u2019t talk about this enough. \n\nMedium goes password-less, using just your email to sign in: http:\/\/t.co\/Kwq86aM17B",
    "id" : 616307700381564928,
    "created_at" : "2015-07-01 18:09:40 +0000",
    "user" : {
      "name" : "Denim & Steel",
      "screen_name" : "DenimAndSteel",
      "protected" : false,
      "id_str" : "386399234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487730797659451392\/vphHBnLu_normal.png",
      "id" : 386399234,
      "verified" : false
    }
  },
  "id" : 616311589713522688,
  "created_at" : "2015-07-01 18:25:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niamh Redmond",
      "screen_name" : "nredmond",
      "indices" : [ 0, 9 ],
      "id_str" : "8724262",
      "id" : 8724262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616283960058843136",
  "geo" : { },
  "id_str" : "616293090341470209",
  "in_reply_to_user_id" : 8724262,
  "text" : "@nredmond That's wonderful Niamh, congratulations!",
  "id" : 616293090341470209,
  "in_reply_to_status_id" : 616283960058843136,
  "created_at" : "2015-07-01 17:11:37 +0000",
  "in_reply_to_screen_name" : "nredmond",
  "in_reply_to_user_id_str" : "8724262",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]