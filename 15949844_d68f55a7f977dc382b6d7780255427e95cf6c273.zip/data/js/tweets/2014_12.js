Grailbird.data.tweets_2014_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/4SM6yBVtBB",
      "expanded_url" : "http:\/\/wp-types.com\/",
      "display_url" : "wp-types.com"
    } ]
  },
  "geo" : { },
  "id_str" : "550089613599989760",
  "text" : "I wanted to nerd-out on a flat-file CMS with Twig\/YAML\/Markdown in 2015, but this might get me back into WordPress... http:\/\/t.co\/4SM6yBVtBB",
  "id" : 550089613599989760,
  "created_at" : "2014-12-31 00:42:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learningxproject",
      "indices" : [ 127, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550045025166295041",
  "text" : "What's your ideal digital learning experience? Access to experts, performance support, tutorials &amp; examples are key for me #learningxproject",
  "id" : 550045025166295041,
  "created_at" : "2014-12-30 21:45:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Official imoot news",
      "screen_name" : "imootonline",
      "indices" : [ 3, 15 ],
      "id_str" : "235030875",
      "id" : 235030875
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 17, 32 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imoot2014",
      "indices" : [ 72, 82 ]
    }, {
      "text" : "moodle",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/KmJA7s1zBR",
      "expanded_url" : "http:\/\/youtu.be\/0DZPUkxqkug?a",
      "display_url" : "youtu.be\/0DZPUkxqkug?a"
    } ]
  },
  "geo" : { },
  "id_str" : "550001228160057344",
  "text" : "RT @imootonline: @hibbittsdesign Great session from earlier this year - #imoot2014 #moodle http:\/\/t.co\/KmJA7s1zBR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 0, 15 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "imoot2014",
        "indices" : [ 55, 65 ]
      }, {
        "text" : "moodle",
        "indices" : [ 66, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/KmJA7s1zBR",
        "expanded_url" : "http:\/\/youtu.be\/0DZPUkxqkug?a",
        "display_url" : "youtu.be\/0DZPUkxqkug?a"
      } ]
    },
    "geo" : { },
    "id_str" : "549759008270073856",
    "in_reply_to_user_id" : 15949844,
    "text" : "@hibbittsdesign Great session from earlier this year - #imoot2014 #moodle http:\/\/t.co\/KmJA7s1zBR",
    "id" : 549759008270073856,
    "created_at" : "2014-12-30 02:48:56 +0000",
    "in_reply_to_screen_name" : "hibbittsdesign",
    "in_reply_to_user_id_str" : "15949844",
    "user" : {
      "name" : "Official imoot news",
      "screen_name" : "imootonline",
      "protected" : false,
      "id_str" : "235030875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430291211224502272\/OqJeyJEL_normal.png",
      "id" : 235030875,
      "verified" : false
    }
  },
  "id" : 550001228160057344,
  "created_at" : "2014-12-30 18:51:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robert fabricant",
      "screen_name" : "fabtweet",
      "indices" : [ 3, 12 ],
      "id_str" : "20355636",
      "id" : 20355636
    }, {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 121, 127 ],
      "id_str" : "1344951",
      "id" : 1344951
    }, {
      "name" : "Design Impact Group",
      "screen_name" : "DIG4impact",
      "indices" : [ 128, 139 ],
      "id_str" : "2730635658",
      "id" : 2730635658
    }, {
      "name" : "Dalberg",
      "screen_name" : "DalbergTweet",
      "indices" : [ 139, 140 ],
      "id_str" : "208912793",
      "id" : 208912793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/AoQx08vYWH",
      "expanded_url" : "http:\/\/wrd.cm\/13EFKJT",
      "display_url" : "wrd.cm\/13EFKJT"
    } ]
  },
  "geo" : { },
  "id_str" : "549817363265118209",
  "text" : "RT @fabtweet: \"The Rapidly Disappearing Business of Design\" - reflections on a big year in design http:\/\/t.co\/AoQx08vYWH @WIRED @DIG4impact\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WIRED",
        "screen_name" : "WIRED",
        "indices" : [ 107, 113 ],
        "id_str" : "1344951",
        "id" : 1344951
      }, {
        "name" : "Design Impact Group",
        "screen_name" : "DIG4impact",
        "indices" : [ 114, 125 ],
        "id_str" : "2730635658",
        "id" : 2730635658
      }, {
        "name" : "Dalberg",
        "screen_name" : "DalbergTweet",
        "indices" : [ 126, 139 ],
        "id_str" : "208912793",
        "id" : 208912793
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/AoQx08vYWH",
        "expanded_url" : "http:\/\/wrd.cm\/13EFKJT",
        "display_url" : "wrd.cm\/13EFKJT"
      } ]
    },
    "geo" : { },
    "id_str" : "549583324382248960",
    "text" : "\"The Rapidly Disappearing Business of Design\" - reflections on a big year in design http:\/\/t.co\/AoQx08vYWH @WIRED @DIG4impact @DalbergTweet",
    "id" : 549583324382248960,
    "created_at" : "2014-12-29 15:10:49 +0000",
    "user" : {
      "name" : "robert fabricant",
      "screen_name" : "fabtweet",
      "protected" : false,
      "id_str" : "20355636",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530763561929158656\/nE8Mw-eR_normal.jpeg",
      "id" : 20355636,
      "verified" : false
    }
  },
  "id" : 549817363265118209,
  "created_at" : "2014-12-30 06:40:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Skelton",
      "screen_name" : "bskelton",
      "indices" : [ 3, 12 ],
      "id_str" : "644813",
      "id" : 644813
    }, {
      "name" : "Invoke",
      "screen_name" : "invoke",
      "indices" : [ 92, 99 ],
      "id_str" : "15909507",
      "id" : 15909507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/MbaCmZrqn7",
      "expanded_url" : "https:\/\/www.facebook.com\/media\/set\/?set=a.10152470987756456.1073741828.35589526455&type=1&pnref=story",
      "display_url" : "facebook.com\/media\/set\/?set\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "547193205511307264",
  "text" : "RT @bskelton: Wow. With all the challenges women face in IT it's hard to believe someone at @Invoke thought this was appropriate: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Invoke",
        "screen_name" : "invoke",
        "indices" : [ 78, 85 ],
        "id_str" : "15909507",
        "id" : 15909507
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/MbaCmZrqn7",
        "expanded_url" : "https:\/\/www.facebook.com\/media\/set\/?set=a.10152470987756456.1073741828.35589526455&type=1&pnref=story",
        "display_url" : "facebook.com\/media\/set\/?set\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "547185400423661568",
    "text" : "Wow. With all the challenges women face in IT it's hard to believe someone at @Invoke thought this was appropriate: https:\/\/t.co\/MbaCmZrqn7",
    "id" : 547185400423661568,
    "created_at" : "2014-12-23 00:22:20 +0000",
    "user" : {
      "name" : "Ben Skelton",
      "screen_name" : "bskelton",
      "protected" : false,
      "id_str" : "644813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618855036924227584\/LkjaRAye_normal.jpg",
      "id" : 644813,
      "verified" : false
    }
  },
  "id" : 547193205511307264,
  "created_at" : "2014-12-23 00:53:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Blackshire",
      "screen_name" : "tomblackshire",
      "indices" : [ 0, 14 ],
      "id_str" : "389631402",
      "id" : 389631402
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 46, 54 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "546979820274741248",
  "geo" : { },
  "id_str" : "547168804980011008",
  "in_reply_to_user_id" : 389631402,
  "text" : "@tomblackshire I'd suggest you also check out @getgrav too - very promising!",
  "id" : 547168804980011008,
  "in_reply_to_status_id" : 546979820274741248,
  "created_at" : "2014-12-22 23:16:23 +0000",
  "in_reply_to_screen_name" : "tomblackshire",
  "in_reply_to_user_id_str" : "389631402",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 3, 7 ],
      "id_str" : "1063291",
      "id" : 1063291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/iwQsqiroRv",
      "expanded_url" : "http:\/\/ow.ly\/G7WrA",
      "display_url" : "ow.ly\/G7WrA"
    } ]
  },
  "geo" : { },
  "id_str" : "545964824757141504",
  "text" : "RT @UIE: Hi. Do you have 30 minutes on December 29 to help UIE with some usability testing? - http:\/\/t.co\/iwQsqiroRv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/iwQsqiroRv",
        "expanded_url" : "http:\/\/ow.ly\/G7WrA",
        "display_url" : "ow.ly\/G7WrA"
      } ]
    },
    "geo" : { },
    "id_str" : "545964390630301696",
    "text" : "Hi. Do you have 30 minutes on December 29 to help UIE with some usability testing? - http:\/\/t.co\/iwQsqiroRv",
    "id" : 545964390630301696,
    "created_at" : "2014-12-19 15:30:28 +0000",
    "user" : {
      "name" : "UIE",
      "screen_name" : "UIE",
      "protected" : false,
      "id_str" : "1063291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3759116326\/19308cfcdb0b831111d4ee3fc3e6232c_normal.jpeg",
      "id" : 1063291,
      "verified" : false
    }
  },
  "id" : 545964824757141504,
  "created_at" : "2014-12-19 15:32:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LMS",
      "indices" : [ 23, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545732802646245376",
  "text" : "The page model used by #LMS's has long past its 'best before' date. Exploring more modular structures to benefit students and facilitators.",
  "id" : 545732802646245376,
  "created_at" : "2014-12-19 00:10:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bolt",
      "screen_name" : "BoltCM",
      "indices" : [ 0, 7 ],
      "id_str" : "845970211",
      "id" : 845970211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "545300214270423040",
  "geo" : { },
  "id_str" : "545714330348445696",
  "in_reply_to_user_id" : 845970211,
  "text" : "@BoltCM I've created 3 'resource' content types. Is there a recommended best practice to display 1 of each content type on a page? Thanks!",
  "id" : 545714330348445696,
  "in_reply_to_status_id" : 545300214270423040,
  "created_at" : "2014-12-18 22:56:49 +0000",
  "in_reply_to_screen_name" : "BoltCM",
  "in_reply_to_user_id_str" : "845970211",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 18, 34 ],
      "id_str" : "17462723",
      "id" : 17462723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teamopen",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/A3jKDygMit",
      "expanded_url" : "http:\/\/bit.ly\/1i1Vo71",
      "display_url" : "bit.ly\/1i1Vo71"
    } ]
  },
  "geo" : { },
  "id_str" : "545693929778053121",
  "text" : "I just donated to @creativecommons! http:\/\/t.co\/A3jKDygMit #teamopen",
  "id" : 545693929778053121,
  "created_at" : "2014-12-18 21:35:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 82, 90 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Bolt",
      "screen_name" : "BoltCM",
      "indices" : [ 95, 102 ],
      "id_str" : "845970211",
      "id" : 845970211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545648369176023040",
  "text" : "Two more modern CMS's that I am evaluating for multi-device educational contexts: @GetGrav and @BoltCM, which has 'resource' content types.",
  "id" : 545648369176023040,
  "created_at" : "2014-12-18 18:34:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 3, 18 ],
      "id_str" : "1122631",
      "id" : 1122631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/CX6fffwcNV",
      "expanded_url" : "https:\/\/lnkd.in\/eWr8CTf",
      "display_url" : "lnkd.in\/eWr8CTf"
    } ]
  },
  "geo" : { },
  "id_str" : "545644859265019904",
  "text" : "RT @MalloryOConnor: we're lucky to have this conference in our backyard in Vancouver this August! https:\/\/t.co\/CX6fffwcNV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/CX6fffwcNV",
        "expanded_url" : "https:\/\/lnkd.in\/eWr8CTf",
        "display_url" : "lnkd.in\/eWr8CTf"
      } ]
    },
    "geo" : { },
    "id_str" : "544713840089247744",
    "text" : "we're lucky to have this conference in our backyard in Vancouver this August! https:\/\/t.co\/CX6fffwcNV",
    "id" : 544713840089247744,
    "created_at" : "2014-12-16 04:41:14 +0000",
    "user" : {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "protected" : false,
      "id_str" : "1122631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2261747531\/mallory_thumbnail_normal.png",
      "id" : 1122631,
      "verified" : false
    }
  },
  "id" : 545644859265019904,
  "created_at" : "2014-12-18 18:20:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bolt",
      "screen_name" : "BoltCM",
      "indices" : [ 0, 7 ],
      "id_str" : "845970211",
      "id" : 845970211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "545300214270423040",
  "geo" : { },
  "id_str" : "545305595830484992",
  "in_reply_to_user_id" : 845970211,
  "text" : "@BoltCM Awesome, that's the exact type of thing I am looking for. Thanks very much for the help!",
  "id" : 545305595830484992,
  "in_reply_to_status_id" : 545300214270423040,
  "created_at" : "2014-12-17 19:52:39 +0000",
  "in_reply_to_screen_name" : "BoltCM",
  "in_reply_to_user_id_str" : "845970211",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bolt",
      "screen_name" : "BoltCM",
      "indices" : [ 0, 7 ],
      "id_str" : "845970211",
      "id" : 845970211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/FuStB6JSaF",
      "expanded_url" : "http:\/\/www.informationdesign.org\/",
      "display_url" : "informationdesign.org"
    } ]
  },
  "in_reply_to_status_id_str" : "544978704179290113",
  "geo" : { },
  "id_str" : "544984452024111104",
  "in_reply_to_user_id" : 845970211,
  "text" : "@BoltCM Very helpful info, thanks! I am trying to do something like this http:\/\/t.co\/FuStB6JSaF, where entries point to various resources.",
  "id" : 544984452024111104,
  "in_reply_to_status_id" : 544978704179290113,
  "created_at" : "2014-12-16 22:36:33 +0000",
  "in_reply_to_screen_name" : "BoltCM",
  "in_reply_to_user_id_str" : "845970211",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bolt",
      "screen_name" : "BoltCM",
      "indices" : [ 0, 7 ],
      "id_str" : "845970211",
      "id" : 845970211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544946026881499138",
  "geo" : { },
  "id_str" : "544976863240519682",
  "in_reply_to_user_id" : 845970211,
  "text" : "@BoltCM Great to see, congrats! Could you please point me to learning how to list a bunch of (specific) entries on a page, via Admin panel?",
  "id" : 544976863240519682,
  "in_reply_to_status_id" : 544946026881499138,
  "created_at" : "2014-12-16 22:06:24 +0000",
  "in_reply_to_screen_name" : "BoltCM",
  "in_reply_to_user_id_str" : "845970211",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544910153401630721",
  "text" : "Updated (multi-device) learner experience goals: Engaging, Convenient, Organized, Relevant, and Enjoyable (ECORE). Possible improvements?",
  "id" : 544910153401630721,
  "created_at" : "2014-12-16 17:41:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544607361311047680",
  "text" : "What does it mean to view technology as a primary element of the learner experience, rather than just a method of delivery?",
  "id" : 544607361311047680,
  "created_at" : "2014-12-15 21:38:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544568176508297216",
  "text" : "My multi-device learning experience goals keep aligning with my classroom experience goals: engaging, motivational, structured &amp; delightful.",
  "id" : 544568176508297216,
  "created_at" : "2014-12-15 19:02:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Soverini",
      "screen_name" : "sovesove",
      "indices" : [ 100, 109 ],
      "id_str" : "44917551",
      "id" : 44917551
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 79, 82 ]
    }, {
      "text" : "uxchecklist",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/8aUMZs4rGi",
      "expanded_url" : "http:\/\/uxchecklist.github.io\/",
      "display_url" : "uxchecklist.github.io"
    } ]
  },
  "geo" : { },
  "id_str" : "543479714724069376",
  "text" : "UX Project Checklist: The UX Design Process From A to Z http:\/\/t.co\/8aUMZs4rGi #ux #uxchecklist via @sovesove",
  "id" : 543479714724069376,
  "created_at" : "2014-12-12 18:57:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 15, 23 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543173459313184768",
  "text" : "Really digging @getgrav as a potential multi-device course companion platform! Modern UX, fast, dynamic, no database, and very pliable.",
  "id" : 543173459313184768,
  "created_at" : "2014-12-11 22:40:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Bersin",
      "screen_name" : "Josh_Bersin",
      "indices" : [ 3, 15 ],
      "id_str" : "14211474",
      "id" : 14211474
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Josh_Bersin\/status\/542080404115947521\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/7bnR4cGYlk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4XbD5iCIAAOD_r.png",
      "id_str" : "542080190197669888",
      "id" : 542080190197669888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4XbD5iCIAAOD_r.png",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7bnR4cGYlk"
    } ],
    "hashtags" : [ {
      "text" : "hr",
      "indices" : [ 130, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/h3YmykWbmV",
      "expanded_url" : "http:\/\/marketing.bersin.com\/HR-Technology-2015-120914.html",
      "display_url" : "marketing.bersin.com\/HR-Technology-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542836139376136192",
  "text" : "RT @Josh_Bersin: Meet the modern learner: untethered, demanding, collaborative, empowered. And impatient!  http:\/\/t.co\/h3YmykWbmV #hr http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Josh_Bersin\/status\/542080404115947521\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/7bnR4cGYlk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4XbD5iCIAAOD_r.png",
        "id_str" : "542080190197669888",
        "id" : 542080190197669888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4XbD5iCIAAOD_r.png",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7bnR4cGYlk"
      } ],
      "hashtags" : [ {
        "text" : "hr",
        "indices" : [ 113, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/h3YmykWbmV",
        "expanded_url" : "http:\/\/marketing.bersin.com\/HR-Technology-2015-120914.html",
        "display_url" : "marketing.bersin.com\/HR-Technology-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "542080404115947521",
    "text" : "Meet the modern learner: untethered, demanding, collaborative, empowered. And impatient!  http:\/\/t.co\/h3YmykWbmV #hr http:\/\/t.co\/7bnR4cGYlk",
    "id" : 542080404115947521,
    "created_at" : "2014-12-08 22:16:54 +0000",
    "user" : {
      "name" : "Josh Bersin",
      "screen_name" : "Josh_Bersin",
      "protected" : false,
      "id_str" : "14211474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2869484348\/9ffaeb3cd186c9dc6ff174fa81b4bb9c_normal.jpeg",
      "id" : 14211474,
      "verified" : false
    }
  },
  "id" : 542836139376136192,
  "created_at" : "2014-12-11 00:19:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Nakagawa \uD83C\uDF55\uD83D\uDC51",
      "screen_name" : "ericnakagawa",
      "indices" : [ 3, 16 ],
      "id_str" : "2349251",
      "id" : 2349251
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ericnakagawa\/status\/539516159188410369\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/Ly7FbZbaLk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3y_FotCAAAl_Cx.png",
      "id_str" : "539516158924161024",
      "id" : 539516158924161024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3y_FotCAAAl_Cx.png",
      "sizes" : [ {
        "h" : 316,
        "resize" : "fit",
        "w" : 210
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 210
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 210
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 210
      } ],
      "display_url" : "pic.twitter.com\/Ly7FbZbaLk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542117959959732224",
  "text" : "RT @ericnakagawa: RT if you remember waiting for this to load. http:\/\/t.co\/Ly7FbZbaLk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ericnakagawa\/status\/539516159188410369\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/Ly7FbZbaLk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3y_FotCAAAl_Cx.png",
        "id_str" : "539516158924161024",
        "id" : 539516158924161024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3y_FotCAAAl_Cx.png",
        "sizes" : [ {
          "h" : 316,
          "resize" : "fit",
          "w" : 210
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 316,
          "resize" : "fit",
          "w" : 210
        }, {
          "h" : 316,
          "resize" : "fit",
          "w" : 210
        }, {
          "h" : 316,
          "resize" : "fit",
          "w" : 210
        } ],
        "display_url" : "pic.twitter.com\/Ly7FbZbaLk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539516159188410369",
    "text" : "RT if you remember waiting for this to load. http:\/\/t.co\/Ly7FbZbaLk",
    "id" : 539516159188410369,
    "created_at" : "2014-12-01 20:27:30 +0000",
    "user" : {
      "name" : "Eric Nakagawa \uD83C\uDF55\uD83D\uDC51",
      "screen_name" : "ericnakagawa",
      "protected" : false,
      "id_str" : "2349251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652593354312585217\/clYKiFHL_normal.jpg",
      "id" : 2349251,
      "verified" : false
    }
  },
  "id" : 542117959959732224,
  "created_at" : "2014-12-09 00:46:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Muut",
      "screen_name" : "getmuut",
      "indices" : [ 79, 87 ],
      "id_str" : "93775718",
      "id" : 93775718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542090875782696960",
  "text" : "The state of online discussions pains me greatly in every LMS I've used. Muut (@getmuut) looks like what modern discussion forums should be.",
  "id" : 542090875782696960,
  "created_at" : "2014-12-08 22:58:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542069573093031937",
  "text" : "It's abundantly clear to me, as I explore course platforms for next year, that learning and technology are more intertwined than ever.",
  "id" : 542069573093031937,
  "created_at" : "2014-12-08 21:33:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diigo",
      "screen_name" : "diigo",
      "indices" : [ 0, 6 ],
      "id_str" : "5345032",
      "id" : 5345032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540571690506268674",
  "geo" : { },
  "id_str" : "541044510222864384",
  "in_reply_to_user_id" : 5345032,
  "text" : "@diigo Love the Outliner! Any plans in the future to be able to embed an outline in a HTML page (i.e. via iframe)?",
  "id" : 541044510222864384,
  "in_reply_to_status_id" : 540571690506268674,
  "created_at" : "2014-12-06 01:40:38 +0000",
  "in_reply_to_screen_name" : "diigo",
  "in_reply_to_user_id_str" : "5345032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abi Jones",
      "screen_name" : "jonesabi",
      "indices" : [ 3, 12 ],
      "id_str" : "2990621",
      "id" : 2990621
    }, {
      "name" : "Amy Jackson",
      "screen_name" : "AJacksonTalent",
      "indices" : [ 98, 113 ],
      "id_str" : "132690927",
      "id" : 132690927
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "warmgun",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540636213720281088",
  "text" : "RT @jonesabi: Seriously: \"Don't put stuff in your portfolio that you don't want to do anymore.\" - @ajacksontalent #warmgun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amy Jackson",
        "screen_name" : "AJacksonTalent",
        "indices" : [ 84, 99 ],
        "id_str" : "132690927",
        "id" : 132690927
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "warmgun",
        "indices" : [ 100, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540620315726864385",
    "text" : "Seriously: \"Don't put stuff in your portfolio that you don't want to do anymore.\" - @ajacksontalent #warmgun",
    "id" : 540620315726864385,
    "created_at" : "2014-12-04 21:35:02 +0000",
    "user" : {
      "name" : "Abi Jones",
      "screen_name" : "jonesabi",
      "protected" : false,
      "id_str" : "2990621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736824582867451904\/HaysfjK1_normal.jpg",
      "id" : 2990621,
      "verified" : false
    }
  },
  "id" : 540636213720281088,
  "created_at" : "2014-12-04 22:38:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "curtisblackwell",
      "screen_name" : "_cpb",
      "indices" : [ 0, 5 ],
      "id_str" : "14570201",
      "id" : 14570201
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "statamic",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/BEz1Z5cA3G",
      "expanded_url" : "http:\/\/lodge.statamic.com\/public-house\/826-thoughts-on-implementing-an-articlevideo",
      "display_url" : "lodge.statamic.com\/public-house\/8\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "539911471396708352",
  "geo" : { },
  "id_str" : "540304610414444544",
  "in_reply_to_user_id" : 14570201,
  "text" : "@_cpb Here's my first #statamic question: http:\/\/t.co\/BEz1Z5cA3G Hope it makes sense :-)",
  "id" : 540304610414444544,
  "in_reply_to_status_id" : 539911471396708352,
  "created_at" : "2014-12-04 00:40:32 +0000",
  "in_reply_to_screen_name" : "_cpb",
  "in_reply_to_user_id_str" : "14570201",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "curtisblackwell",
      "screen_name" : "_cpb",
      "indices" : [ 0, 5 ],
      "id_str" : "14570201",
      "id" : 14570201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539911471396708352",
  "geo" : { },
  "id_str" : "540176556736270336",
  "in_reply_to_user_id" : 14570201,
  "text" : "@_cpb Thanks for reaching out, I appreciate that!",
  "id" : 540176556736270336,
  "in_reply_to_status_id" : 539911471396708352,
  "created_at" : "2014-12-03 16:11:41 +0000",
  "in_reply_to_screen_name" : "_cpb",
  "in_reply_to_user_id_str" : "14570201",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wikipedia",
      "indices" : [ 18, 28 ]
    }, {
      "text" : "keepitfree",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/teWA9YoZyV",
      "expanded_url" : "https:\/\/donate.wikimedia.org\/?utm_medium=SocialMedia&utm_campaign=ThankYouPage&utm_source=Twitter",
      "display_url" : "donate.wikimedia.org\/?utm_medium=So\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539901960007061504",
  "text" : "I just donated to #Wikipedia. Help keep it free! #keepitfree https:\/\/t.co\/teWA9YoZyV",
  "id" : 539901960007061504,
  "created_at" : "2014-12-02 22:00:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CraftCMS",
      "indices" : [ 97, 106 ]
    }, {
      "text" : "OctoberCMS",
      "indices" : [ 108, 119 ]
    }, {
      "text" : "Statamic",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539841717914988544",
  "text" : "Exploring some newer CMS's these days for multi-device educational contexts - most promising are #CraftCMS, #OctoberCMS, and no DB #Statamic",
  "id" : 539841717914988544,
  "created_at" : "2014-12-02 18:01:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539484764646809600",
  "text" : "Any suggested approaches to balance having students produce creative commons licensed work vs. personal privacy concerns?",
  "id" : 539484764646809600,
  "created_at" : "2014-12-01 18:22:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]