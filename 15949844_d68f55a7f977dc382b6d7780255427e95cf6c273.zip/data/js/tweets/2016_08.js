Grailbird.data.tweets_2016_08 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 3, 12 ],
      "id_str" : "13046992",
      "id" : 13046992
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 80, 87 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/pc7NlEujFf",
      "expanded_url" : "https:\/\/mashe.hawksey.info\/2016\/08\/keeping-your-twitter-archive-fresh-and-freely-hosted-on-github-pages\/",
      "display_url" : "mashe.hawksey.info\/2016\/08\/keepin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768983687207583745",
  "text" : "RT @mhawksey: It lives! Keeping your Twitter Archive fresh and freely hosted on @Github Pages with a bit of Google Apps Script https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 66, 73 ],
        "id_str" : "13334762",
        "id" : 13334762
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/pc7NlEujFf",
        "expanded_url" : "https:\/\/mashe.hawksey.info\/2016\/08\/keeping-your-twitter-archive-fresh-and-freely-hosted-on-github-pages\/",
        "display_url" : "mashe.hawksey.info\/2016\/08\/keepin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768924527757815812",
    "text" : "It lives! Keeping your Twitter Archive fresh and freely hosted on @Github Pages with a bit of Google Apps Script https:\/\/t.co\/pc7NlEujFf",
    "id" : 768924527757815812,
    "created_at" : "2016-08-25 21:34:28 +0000",
    "user" : {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "protected" : false,
      "id_str" : "13046992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390851993\/xu6aptqy6a8rb2h2w5by_normal.jpeg",
      "id" : 13046992,
      "verified" : false
    }
  },
  "id" : 768983687207583745,
  "created_at" : "2016-08-26 01:29:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MeasuringU",
      "screen_name" : "MeasuringU",
      "indices" : [ 3, 14 ],
      "id_str" : "103951768",
      "id" : 103951768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/n7HK8bvbjl",
      "expanded_url" : "http:\/\/ow.ly\/WWih303u9F2",
      "display_url" : "ow.ly\/WWih303u9F2"
    } ]
  },
  "geo" : { },
  "id_str" : "768888944465354756",
  "text" : "RT @MeasuringU: Essential and Desirable Skills for a UX Designer (UXMatters) https:\/\/t.co\/n7HK8bvbjl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/n7HK8bvbjl",
        "expanded_url" : "http:\/\/ow.ly\/WWih303u9F2",
        "display_url" : "ow.ly\/WWih303u9F2"
      } ]
    },
    "geo" : { },
    "id_str" : "768871071110033408",
    "text" : "Essential and Desirable Skills for a UX Designer (UXMatters) https:\/\/t.co\/n7HK8bvbjl",
    "id" : 768871071110033408,
    "created_at" : "2016-08-25 18:02:02 +0000",
    "user" : {
      "name" : "MeasuringU",
      "screen_name" : "MeasuringU",
      "protected" : false,
      "id_str" : "103951768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768568168553910272\/Qigu06V6_normal.jpg",
      "id" : 103951768,
      "verified" : false
    }
  },
  "id" : 768888944465354756,
  "created_at" : "2016-08-25 19:13:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Brumfield",
      "screen_name" : "Brumface",
      "indices" : [ 3, 12 ],
      "id_str" : "60716903",
      "id" : 60716903
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 93, 108 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AddOnDomain",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/HSQOoA10Qr",
      "expanded_url" : "https:\/\/community.reclaimhosting.com\/t\/how-to-register-and-set-up-an-additional-domain\/249",
      "display_url" : "community.reclaimhosting.com\/t\/how-to-regis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768844247717912576",
  "text" : "RT @Brumface: Registering and setting up your additional domain from start to finish in your @ReclaimHosting account: https:\/\/t.co\/HSQOoA10\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reclaim Hosting",
        "screen_name" : "ReclaimHosting",
        "indices" : [ 79, 94 ],
        "id_str" : "1602053274",
        "id" : 1602053274
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AddOnDomain",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/HSQOoA10Qr",
        "expanded_url" : "https:\/\/community.reclaimhosting.com\/t\/how-to-register-and-set-up-an-additional-domain\/249",
        "display_url" : "community.reclaimhosting.com\/t\/how-to-regis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768843308965572610",
    "text" : "Registering and setting up your additional domain from start to finish in your @ReclaimHosting account: https:\/\/t.co\/HSQOoA10Qr #AddOnDomain",
    "id" : 768843308965572610,
    "created_at" : "2016-08-25 16:11:43 +0000",
    "user" : {
      "name" : "Lauren Brumfield",
      "screen_name" : "Brumface",
      "protected" : false,
      "id_str" : "60716903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754808496831344640\/vm6bbAnx_normal.jpg",
      "id" : 60716903,
      "verified" : false
    }
  },
  "id" : 768844247717912576,
  "created_at" : "2016-08-25 16:15:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "indices" : [ 3, 14 ],
      "id_str" : "27633854",
      "id" : 27633854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/oxKP6gxreA",
      "expanded_url" : "http:\/\/www.thetechedvocate.org\/replacing-teachers-automated-education-lacks-imagination\/",
      "display_url" : "thetechedvocate.org\/replacing-teac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768836065285120000",
  "text" : "RT @JustStormy: Why replacing teachers with automated education lacks imagination https:\/\/t.co\/oxKP6gxreA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/oxKP6gxreA",
        "expanded_url" : "http:\/\/www.thetechedvocate.org\/replacing-teachers-automated-education-lacks-imagination\/",
        "display_url" : "thetechedvocate.org\/replacing-teac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768829443318046720",
    "text" : "Why replacing teachers with automated education lacks imagination https:\/\/t.co\/oxKP6gxreA",
    "id" : 768829443318046720,
    "created_at" : "2016-08-25 15:16:38 +0000",
    "user" : {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "protected" : false,
      "id_str" : "27633854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766452852248109056\/nnq9NFSH_normal.jpg",
      "id" : 27633854,
      "verified" : false
    }
  },
  "id" : 768836065285120000,
  "created_at" : "2016-08-25 15:42:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768660793327923201",
  "geo" : { },
  "id_str" : "768662879721566208",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro I am very similar, except for me it's 4:00pm which is the no-fly zone \uD83D\uDE42",
  "id" : 768662879721566208,
  "in_reply_to_status_id" : 768660793327923201,
  "created_at" : "2016-08-25 04:14:46 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/maY3RHziPT",
      "expanded_url" : "https:\/\/www.elmsln.org\/guiding-principles",
      "display_url" : "elmsln.org\/guiding-princi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768657608345399296",
  "text" : "RT @btopro: \u201CEvery course, author, instructor, learner and context is unique. We celebrate this in the\u2026 architecture\u201D https:\/\/t.co\/maY3RHzi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/maY3RHziPT",
        "expanded_url" : "https:\/\/www.elmsln.org\/guiding-principles",
        "display_url" : "elmsln.org\/guiding-princi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768657049479634949",
    "text" : "\u201CEvery course, author, instructor, learner and context is unique. We celebrate this in the\u2026 architecture\u201D https:\/\/t.co\/maY3RHziPT",
    "id" : 768657049479634949,
    "created_at" : "2016-08-25 03:51:36 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 768657608345399296,
  "created_at" : "2016-08-25 03:53:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 0, 13 ],
      "id_str" : "91939908",
      "id" : 91939908
    }, {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 67, 76 ],
      "id_str" : "890887814",
      "id" : 890887814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768565059433836544",
  "in_reply_to_user_id" : 91939908,
  "text" : "@davidnwright Did you ever check out the markdown-based slides app @swipe_to? Because if not yet you should - they just added GIPHY support\uD83D\uDE42",
  "id" : 768565059433836544,
  "created_at" : "2016-08-24 21:46:04 +0000",
  "in_reply_to_screen_name" : "davidnwright",
  "in_reply_to_user_id_str" : "91939908",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 38, 47 ],
      "id_str" : "890887814",
      "id" : 890887814
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/hibbittsdesign\/status\/768560663824257024\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/zQ7WMEQDsg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqp5aYUUkAAz-i-.jpg",
      "id_str" : "768560180531335168",
      "id" : 768560180531335168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqp5aYUUkAAz-i-.jpg",
      "sizes" : [ {
        "h" : 1629,
        "resize" : "fit",
        "w" : 1202
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 502
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 885
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1629,
        "resize" : "fit",
        "w" : 1202
      } ],
      "display_url" : "pic.twitter.com\/zQ7WMEQDsg"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768560663824257024",
  "text" : "Really \u2764\uFE0F  the 'multi-deck' view that @swipe_to gives me as I build slides for #SFU CMPT-363. Markdown-based too \uD83D\uDC4D https:\/\/t.co\/zQ7WMEQDsg",
  "id" : 768560663824257024,
  "created_at" : "2016-08-24 21:28:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Honeychurch",
      "screen_name" : "NomadWarMachine",
      "indices" : [ 3, 19 ],
      "id_str" : "558091832",
      "id" : 558091832
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 42, 56 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CLMooc",
      "indices" : [ 134, 140 ]
    }, {
      "text" : "DigPed",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "Rhizo16",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/bz3YCSyNDY",
      "expanded_url" : "http:\/\/hackeducation.com\/2016\/08\/23\/domains",
      "display_url" : "hackeducation.com\/2016\/08\/23\/dom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768533635376910336",
  "text" : "RT @NomadWarMachine: Fantastic stuff from @audreywatters about the importance of space, not ownership, online https:\/\/t.co\/bz3YCSyNDY #CLMo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 21, 35 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CLMooc",
        "indices" : [ 113, 120 ]
      }, {
        "text" : "DigPed",
        "indices" : [ 121, 128 ]
      }, {
        "text" : "Rhizo16",
        "indices" : [ 129, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/bz3YCSyNDY",
        "expanded_url" : "http:\/\/hackeducation.com\/2016\/08\/23\/domains",
        "display_url" : "hackeducation.com\/2016\/08\/23\/dom\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768394162064490496",
    "text" : "Fantastic stuff from @audreywatters about the importance of space, not ownership, online https:\/\/t.co\/bz3YCSyNDY #CLMooc #DigPed #Rhizo16",
    "id" : 768394162064490496,
    "created_at" : "2016-08-24 10:26:58 +0000",
    "user" : {
      "name" : "Sarah Honeychurch",
      "screen_name" : "NomadWarMachine",
      "protected" : false,
      "id_str" : "558091832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660495239220748289\/yaCgTOMP_normal.jpg",
      "id" : 558091832,
      "verified" : false
    }
  },
  "id" : 768533635376910336,
  "created_at" : "2016-08-24 19:41:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Rieger",
      "screen_name" : "stephanierieger",
      "indices" : [ 3, 19 ],
      "id_str" : "6868612",
      "id" : 6868612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/YJOOsYrZOW",
      "expanded_url" : "https:\/\/twitter.com\/jnymck\/status\/768518934890893312",
      "display_url" : "twitter.com\/jnymck\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768521021305479168",
  "text" : "RT @stephanierieger: Wow. Really thoughtful design leveraging human skill, simple, learnable affordances, and AR. https:\/\/t.co\/YJOOsYrZOW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/YJOOsYrZOW",
        "expanded_url" : "https:\/\/twitter.com\/jnymck\/status\/768518934890893312",
        "display_url" : "twitter.com\/jnymck\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768520122973638657",
    "text" : "Wow. Really thoughtful design leveraging human skill, simple, learnable affordances, and AR. https:\/\/t.co\/YJOOsYrZOW",
    "id" : 768520122973638657,
    "created_at" : "2016-08-24 18:47:30 +0000",
    "user" : {
      "name" : "Stephanie Rieger",
      "screen_name" : "stephanierieger",
      "protected" : false,
      "id_str" : "6868612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1581672007\/stephanie-rieger_normal.png",
      "id" : 6868612,
      "verified" : false
    }
  },
  "id" : 768521021305479168,
  "created_at" : "2016-08-24 18:51:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Nessler",
      "screen_name" : "nessie420",
      "indices" : [ 82, 92 ],
      "id_str" : "17732474",
      "id" : 17732474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/MeNf88xjEk",
      "expanded_url" : "https:\/\/medium.com\/digital-experience-design\/how-to-apply-a-design-thinking-hcd-ux-or-any-creative-process-from-scratch-b8786efbf812#.y2tfvlsq0",
      "display_url" : "medium.com\/digital-experi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768514606251638784",
  "text" : "\u201CHow to apply a design thinking, HCD, UX or any creative process from scratch\u201D by @nessie420 https:\/\/t.co\/MeNf88xjEk",
  "id" : 768514606251638784,
  "created_at" : "2016-08-24 18:25:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768202451597922308",
  "text" : "Going back and forth about which set of heuristics to use that serve as good design principles too - tending towards Nielsen's vs. ISO 9241.",
  "id" : 768202451597922308,
  "created_at" : "2016-08-23 21:45:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 108, 116 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "D2L",
      "indices" : [ 10, 14 ]
    }, {
      "text" : "Blackboard",
      "indices" : [ 15, 26 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 27, 37 ]
    }, {
      "text" : "Moodle",
      "indices" : [ 38, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/6eSLXDPno4",
      "expanded_url" : "http:\/\/gravcoursehub.org",
      "display_url" : "gravcoursehub.org"
    } ]
  },
  "geo" : { },
  "id_str" : "768174637138137089",
  "text" : "Go beyond #D2L #Blackboard #CanvasLMS #Moodle by flipping your LMS with the open and collaborative platform @getgrav https:\/\/t.co\/6eSLXDPno4",
  "id" : 768174637138137089,
  "created_at" : "2016-08-23 19:54:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niamh Redmond",
      "screen_name" : "nredmond",
      "indices" : [ 3, 12 ],
      "id_str" : "8724262",
      "id" : 8724262
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "radresearch",
      "indices" : [ 109, 121 ]
    }, {
      "text" : "uxresearch",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/cjH7dBJz4E",
      "expanded_url" : "http:\/\/radicalresearchsummit.com",
      "display_url" : "radicalresearchsummit.com"
    } ]
  },
  "geo" : { },
  "id_str" : "767882713218953216",
  "text" : "RT @nredmond: I'm going, see you there? Radical Research Summit: Impacting UX Design &amp; Business Strategy #radresearch #uxresearch https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "radresearch",
        "indices" : [ 95, 107 ]
      }, {
        "text" : "uxresearch",
        "indices" : [ 108, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/cjH7dBJz4E",
        "expanded_url" : "http:\/\/radicalresearchsummit.com",
        "display_url" : "radicalresearchsummit.com"
      } ]
    },
    "geo" : { },
    "id_str" : "767877419139158016",
    "text" : "I'm going, see you there? Radical Research Summit: Impacting UX Design &amp; Business Strategy #radresearch #uxresearch https:\/\/t.co\/cjH7dBJz4E",
    "id" : 767877419139158016,
    "created_at" : "2016-08-23 00:13:37 +0000",
    "user" : {
      "name" : "Niamh Redmond",
      "screen_name" : "nredmond",
      "protected" : false,
      "id_str" : "8724262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565448348153679872\/8xkvMU7E_normal.jpeg",
      "id" : 8724262,
      "verified" : false
    }
  },
  "id" : 767882713218953216,
  "created_at" : "2016-08-23 00:34:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chase Colman",
      "screen_name" : "Chase_the_Dev",
      "indices" : [ 3, 17 ],
      "id_str" : "1044853688",
      "id" : 1044853688
    }, {
      "name" : "GitLab",
      "screen_name" : "gitlab",
      "indices" : [ 20, 27 ],
      "id_str" : "390167291",
      "id" : 390167291
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Chase_the_Dev\/status\/767861710581436416\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/FUknV9voil",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cqf9xIrUIAAkHWe.jpg",
      "id_str" : "767861282074533888",
      "id" : 767861282074533888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cqf9xIrUIAAkHWe.jpg",
      "sizes" : [ {
        "h" : 275,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FUknV9voil"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767871027481161728",
  "text" : "RT @Chase_the_Dev: .@gitlab's latest release has some pretty sick features. No more trello, no more JIRA, just pure excellence. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GitLab",
        "screen_name" : "gitlab",
        "indices" : [ 1, 8 ],
        "id_str" : "390167291",
        "id" : 390167291
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Chase_the_Dev\/status\/767861710581436416\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/FUknV9voil",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cqf9xIrUIAAkHWe.jpg",
        "id_str" : "767861282074533888",
        "id" : 767861282074533888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cqf9xIrUIAAkHWe.jpg",
        "sizes" : [ {
          "h" : 275,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FUknV9voil"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "767861710581436416",
    "text" : ".@gitlab's latest release has some pretty sick features. No more trello, no more JIRA, just pure excellence. https:\/\/t.co\/FUknV9voil",
    "id" : 767861710581436416,
    "created_at" : "2016-08-22 23:11:12 +0000",
    "user" : {
      "name" : "Chase Colman",
      "screen_name" : "Chase_the_Dev",
      "protected" : false,
      "id_str" : "1044853688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582614357063790592\/Ec6diR_N_normal.png",
      "id" : 1044853688,
      "verified" : false
    }
  },
  "id" : 767871027481161728,
  "created_at" : "2016-08-22 23:48:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/X1CPFtrwe6",
      "expanded_url" : "https:\/\/twitter.com\/btopro\/status\/767868747201646592",
      "display_url" : "twitter.com\/btopro\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767870895817830400",
  "text" : "Bingo! Indeed, the LMS can be re-positioned to be a much smaller part of the student experience\uD83D\uDC4D T-minus 15 days. https:\/\/t.co\/X1CPFtrwe6",
  "id" : 767870895817830400,
  "created_at" : "2016-08-22 23:47:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/r8PuKwlBG4",
      "expanded_url" : "https:\/\/calendar.google.com\/calendar\/embed?src=paulhibbitts.com_ccara2sgdb1v8l6juj8tuqqsdk%40group.calendar.google.com&ctz=America\/Vancouver",
      "display_url" : "calendar.google.com\/calendar\/embed\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767855756620070912",
  "text" : "Using event spans in Google Calendar seems to be the best way to visualize CMPT 363 student workload: https:\/\/t.co\/r8PuKwlBG4 Other ideas?",
  "id" : 767855756620070912,
  "created_at" : "2016-08-22 22:47:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 14, 22 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/yJwV2clFWb",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-163\/",
      "display_url" : "paulhibbitts.net\/cmpt-363-163\/"
    } ]
  },
  "geo" : { },
  "id_str" : "767846572579102720",
  "text" : "Thanks to the @getgrav Course Hub, my students and I control our learning space while student data stays in the LMS. https:\/\/t.co\/yJwV2clFWb",
  "id" : 767846572579102720,
  "created_at" : "2016-08-22 22:11:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767837706013466624",
  "text" : "As I redesign CMPT 363 I don't think 'move fast and break things' or 'fail fast, fail often' cut it, but 'learn fast, learn often' does!",
  "id" : 767837706013466624,
  "created_at" : "2016-08-22 21:35:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767835121818796033",
  "text" : "I've always looked at 'move fast and break things' and 'fail fast, fail often' as reeking of privilege. I prefer 'learn fast, learn often'.",
  "id" : 767835121818796033,
  "created_at" : "2016-08-22 21:25:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 3, 11 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Sakai Project",
      "screen_name" : "sakaiproject",
      "indices" : [ 49, 62 ],
      "id_str" : "10768892",
      "id" : 10768892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/70YeZo3tQ1",
      "expanded_url" : "https:\/\/www.sakaiproject.org\/news\/20160822-sakai-accessibility-ra11y-plan-update",
      "display_url" : "sakaiproject.org\/news\/20160822-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767767592085835776",
  "text" : "RT @drchuck: Please help\/contribute to improving @sakaiproject Acessibility - https:\/\/t.co\/70YeZo3tQ1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sakai Project",
        "screen_name" : "sakaiproject",
        "indices" : [ 36, 49 ],
        "id_str" : "10768892",
        "id" : 10768892
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/70YeZo3tQ1",
        "expanded_url" : "https:\/\/www.sakaiproject.org\/news\/20160822-sakai-accessibility-ra11y-plan-update",
        "display_url" : "sakaiproject.org\/news\/20160822-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "767747081951932416",
    "text" : "Please help\/contribute to improving @sakaiproject Acessibility - https:\/\/t.co\/70YeZo3tQ1",
    "id" : 767747081951932416,
    "created_at" : "2016-08-22 15:35:43 +0000",
    "user" : {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "protected" : false,
      "id_str" : "10185562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1396181322\/new-square-pic_normal.jpg",
      "id" : 10185562,
      "verified" : false
    }
  },
  "id" : 767767592085835776,
  "created_at" : "2016-08-22 16:57:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graphic Mint",
      "screen_name" : "Graphic_Mint",
      "indices" : [ 3, 16 ],
      "id_str" : "18087978",
      "id" : 18087978
    }, {
      "name" : "InVision",
      "screen_name" : "InVisionApp",
      "indices" : [ 22, 34 ],
      "id_str" : "256093789",
      "id" : 256093789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/oVXmQafd9X",
      "expanded_url" : "http:\/\/blog.invisionapp.com\/user-testing-guide\/",
      "display_url" : "blog.invisionapp.com\/user-testing-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767415452150603776",
  "text" : "RT @Graphic_Mint: The @InVisionApp blog always has some amazing pieces! Loved \"User Testing Gone Wild: A Guide to Course Correction\" https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "InVision",
        "screen_name" : "InVisionApp",
        "indices" : [ 4, 16 ],
        "id_str" : "256093789",
        "id" : 256093789
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/oVXmQafd9X",
        "expanded_url" : "http:\/\/blog.invisionapp.com\/user-testing-guide\/",
        "display_url" : "blog.invisionapp.com\/user-testing-g\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "767391117310619648",
    "text" : "The @InVisionApp blog always has some amazing pieces! Loved \"User Testing Gone Wild: A Guide to Course Correction\" https:\/\/t.co\/oVXmQafd9X",
    "id" : 767391117310619648,
    "created_at" : "2016-08-21 16:01:14 +0000",
    "user" : {
      "name" : "Graphic Mint",
      "screen_name" : "Graphic_Mint",
      "protected" : false,
      "id_str" : "18087978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685406377766981632\/uVJ7wMrY_normal.jpg",
      "id" : 18087978,
      "verified" : false
    }
  },
  "id" : 767415452150603776,
  "created_at" : "2016-08-21 17:37:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team Canada",
      "screen_name" : "TeamCanada",
      "indices" : [ 3, 14 ],
      "id_str" : "38491229",
      "id" : 38491229
    }, {
      "name" : "Penny Oleksiak",
      "screen_name" : "OleksiakPenny",
      "indices" : [ 17, 31 ],
      "id_str" : "2456684617",
      "id" : 2456684617
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TeamCanada\/status\/767370894939488256\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/cTclceyTEA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqY7DaLWgAUzKUn.jpg",
      "id_str" : "767365716265828357",
      "id" : 767365716265828357,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqY7DaLWgAUzKUn.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 754,
        "resize" : "fit",
        "w" : 1340
      }, {
        "h" : 754,
        "resize" : "fit",
        "w" : 1340
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/cTclceyTEA"
    } ],
    "hashtags" : [ {
      "text" : "TeamCanada",
      "indices" : [ 47, 58 ]
    }, {
      "text" : "Rio2016",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/OK6RpZc9go",
      "expanded_url" : "http:\/\/bit.ly\/2btnASr",
      "display_url" : "bit.ly\/2btnASr"
    } ]
  },
  "geo" : { },
  "id_str" : "767379970632986624",
  "text" : "RT @TeamCanada: .@OleksiakPenny has been named #TeamCanada's #Rio2016 Closing Ceremony flag bearer: https:\/\/t.co\/OK6RpZc9go https:\/\/t.co\/cT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Penny Oleksiak",
        "screen_name" : "OleksiakPenny",
        "indices" : [ 1, 15 ],
        "id_str" : "2456684617",
        "id" : 2456684617
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TeamCanada\/status\/767370894939488256\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/cTclceyTEA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqY7DaLWgAUzKUn.jpg",
        "id_str" : "767365716265828357",
        "id" : 767365716265828357,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqY7DaLWgAUzKUn.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 754,
          "resize" : "fit",
          "w" : 1340
        }, {
          "h" : 754,
          "resize" : "fit",
          "w" : 1340
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/cTclceyTEA"
      } ],
      "hashtags" : [ {
        "text" : "TeamCanada",
        "indices" : [ 31, 42 ]
      }, {
        "text" : "Rio2016",
        "indices" : [ 45, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/OK6RpZc9go",
        "expanded_url" : "http:\/\/bit.ly\/2btnASr",
        "display_url" : "bit.ly\/2btnASr"
      } ]
    },
    "geo" : { },
    "id_str" : "767370894939488256",
    "text" : ".@OleksiakPenny has been named #TeamCanada's #Rio2016 Closing Ceremony flag bearer: https:\/\/t.co\/OK6RpZc9go https:\/\/t.co\/cTclceyTEA",
    "id" : 767370894939488256,
    "created_at" : "2016-08-21 14:40:53 +0000",
    "user" : {
      "name" : "Team Canada",
      "screen_name" : "TeamCanada",
      "protected" : false,
      "id_str" : "38491229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412995539525828608\/h_43xZ8n_normal.png",
      "id" : 38491229,
      "verified" : true
    }
  },
  "id" : 767379970632986624,
  "created_at" : "2016-08-21 15:16:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/hibbittsdesign\/status\/766742719188180992\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/soV8G5hwtJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqQDPPIVYAAu8D7.jpg",
      "id_str" : "766741396854235136",
      "id" : 766741396854235136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqQDPPIVYAAu8D7.jpg",
      "sizes" : [ {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/soV8G5hwtJ"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/hibbittsdesign\/status\/766742719188180992\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/soV8G5hwtJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqQESKbUIAADedr.jpg",
      "id_str" : "766742546642903040",
      "id" : 766742546642903040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqQESKbUIAADedr.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 610
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 610
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 610
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 610
      } ],
      "display_url" : "pic.twitter.com\/soV8G5hwtJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/ui8HooIxlB",
      "expanded_url" : "https:\/\/workflowy.com\/s\/KcrrjOCfwJ",
      "display_url" : "workflowy.com\/s\/KcrrjOCfwJ"
    } ]
  },
  "geo" : { },
  "id_str" : "766742719188180992",
  "text" : "Next up, draft rubrics for CMPT 363 usability inspection and UX topic summary assignments: https:\/\/t.co\/ui8HooIxlB https:\/\/t.co\/soV8G5hwtJ",
  "id" : 766742719188180992,
  "created_at" : "2016-08-19 21:04:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rolling Stone",
      "screen_name" : "RollingStone",
      "indices" : [ 0, 13 ],
      "id_str" : "14780915",
      "id" : 14780915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/wQXYAqSI50",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Christie_Pits_riot",
      "display_url" : "en.wikipedia.org\/wiki\/Christie_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "766653709350731776",
  "geo" : { },
  "id_str" : "766695497612394496",
  "in_reply_to_user_id" : 14780915,
  "text" : "@RollingStone Ah, you've got a pretty significant typo in that article - Christie Pits riot was in 1933, not 1993. https:\/\/t.co\/wQXYAqSI50",
  "id" : 766695497612394496,
  "in_reply_to_status_id" : 766653709350731776,
  "created_at" : "2016-08-19 17:57:05 +0000",
  "in_reply_to_screen_name" : "RollingStone",
  "in_reply_to_user_id_str" : "14780915",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/hibbittsdesign\/status\/766692980837101568\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/mckUPEH7hT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqPXBFBUEAA4zLj.jpg",
      "id_str" : "766692775110643712",
      "id" : 766692775110643712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqPXBFBUEAA4zLj.jpg",
      "sizes" : [ {
        "h" : 364,
        "resize" : "fit",
        "w" : 631
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 631
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 631
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 631
      } ],
      "display_url" : "pic.twitter.com\/mckUPEH7hT"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/hibbittsdesign\/status\/766692980837101568\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/mckUPEH7hT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqPXBFHVYAAKh4i.jpg",
      "id_str" : "766692775135895552",
      "id" : 766692775135895552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqPXBFHVYAAKh4i.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 635
      } ],
      "display_url" : "pic.twitter.com\/mckUPEH7hT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/BSEU27WdfH",
      "expanded_url" : "https:\/\/workflowy.com\/s\/PSB4S1AL4P",
      "display_url" : "workflowy.com\/s\/PSB4S1AL4P"
    } ]
  },
  "geo" : { },
  "id_str" : "766692980837101568",
  "text" : "2nd iteration of rubric items for CMPT 363 open source UX project assignments: https:\/\/t.co\/BSEU27WdfH CC-licensed\uD83D\uDC4D https:\/\/t.co\/mckUPEH7hT",
  "id" : 766692980837101568,
  "created_at" : "2016-08-19 17:47:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "indices" : [ 3, 11 ],
      "id_str" : "783092",
      "id" : 783092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766687389527920640",
  "text" : "RT @benwerd: If we want to fix the Internet, we're going to have to make society a more compassionate, fairer place. They aren't different\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "766685422231564289",
    "geo" : { },
    "id_str" : "766685809978114048",
    "in_reply_to_user_id" : 783092,
    "text" : "If we want to fix the Internet, we're going to have to make society a more compassionate, fairer place. They aren't different places.",
    "id" : 766685809978114048,
    "in_reply_to_status_id" : 766685422231564289,
    "created_at" : "2016-08-19 17:18:36 +0000",
    "in_reply_to_screen_name" : "benwerd",
    "in_reply_to_user_id_str" : "783092",
    "user" : {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "protected" : false,
      "id_str" : "783092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681986174966104064\/t3BubQKk_normal.jpg",
      "id" : 783092,
      "verified" : true
    }
  },
  "id" : 766687389527920640,
  "created_at" : "2016-08-19 17:24:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/BSEU27WdfH",
      "expanded_url" : "https:\/\/workflowy.com\/s\/PSB4S1AL4P",
      "display_url" : "workflowy.com\/s\/PSB4S1AL4P"
    } ]
  },
  "geo" : { },
  "id_str" : "766678455027052544",
  "text" : "Hey fellow UX'ers\/educators - Building rubric criteria for CMPT 363 open source UX project assignments: https:\/\/t.co\/BSEU27WdfH Comments?",
  "id" : 766678455027052544,
  "created_at" : "2016-08-19 16:49:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Typora",
      "screen_name" : "Typora",
      "indices" : [ 3, 10 ],
      "id_str" : "2890926991",
      "id" : 2890926991
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Typora\/status\/766651750380019712\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/2OWl5jcFIo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqOxb8NVMAQeePc.png",
      "id_str" : "766651455159742468",
      "id" : 766651455159742468,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqOxb8NVMAQeePc.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1480,
        "resize" : "fit",
        "w" : 1270
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1030
      }, {
        "h" : 1480,
        "resize" : "fit",
        "w" : 1270
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 584
      } ],
      "display_url" : "pic.twitter.com\/2OWl5jcFIo"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Typora\/status\/766651750380019712\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/2OWl5jcFIo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqOxcVTUAAENQyw.png",
      "id_str" : "766651461895716865",
      "id" : 766651461895716865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqOxcVTUAAENQyw.png",
      "sizes" : [ {
        "h" : 546,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 963,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1914
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1914
      } ],
      "display_url" : "pic.twitter.com\/2OWl5jcFIo"
    } ],
    "hashtags" : [ {
      "text" : "markdown",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766653711401693186",
  "text" : "RT @Typora: New version brings diagram (sequence, flowchart, mermaid) features into our #markdown editor https:\/\/t.co\/2OWl5jcFIo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Typora\/status\/766651750380019712\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/2OWl5jcFIo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqOxb8NVMAQeePc.png",
        "id_str" : "766651455159742468",
        "id" : 766651455159742468,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqOxb8NVMAQeePc.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1480,
          "resize" : "fit",
          "w" : 1270
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1030
        }, {
          "h" : 1480,
          "resize" : "fit",
          "w" : 1270
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 584
        } ],
        "display_url" : "pic.twitter.com\/2OWl5jcFIo"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Typora\/status\/766651750380019712\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/2OWl5jcFIo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqOxcVTUAAENQyw.png",
        "id_str" : "766651461895716865",
        "id" : 766651461895716865,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqOxcVTUAAENQyw.png",
        "sizes" : [ {
          "h" : 546,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 963,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1914
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1914
        } ],
        "display_url" : "pic.twitter.com\/2OWl5jcFIo"
      } ],
      "hashtags" : [ {
        "text" : "markdown",
        "indices" : [ 76, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766651750380019712",
    "text" : "New version brings diagram (sequence, flowchart, mermaid) features into our #markdown editor https:\/\/t.co\/2OWl5jcFIo",
    "id" : 766651750380019712,
    "created_at" : "2016-08-19 15:03:15 +0000",
    "user" : {
      "name" : "Typora",
      "screen_name" : "Typora",
      "protected" : false,
      "id_str" : "2890926991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530007658397315072\/wde9RRJU_normal.png",
      "id" : 2890926991,
      "verified" : false
    }
  },
  "id" : 766653711401693186,
  "created_at" : "2016-08-19 15:11:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/5TS1XzZJCa",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-08-16-a-few-thoughts-about-redesigning-cmpt-363-in-the-open-once-again",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766358686398713856",
  "text" : "New Post: A Few Thoughts About... Redesigning CMPT 363 in the Open (Oh Yes, Once Again) https:\/\/t.co\/5TS1XzZJCa",
  "id" : 766358686398713856,
  "created_at" : "2016-08-18 19:38:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/766335802179620864\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/mXbKe4gEPA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqKRMiBUAAA8OKa.jpg",
      "id_str" : "766334531083173888",
      "id" : 766334531083173888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqKRMiBUAAA8OKa.jpg",
      "sizes" : [ {
        "h" : 460,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/mXbKe4gEPA"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/766335802179620864\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/mXbKe4gEPA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqKRNXLVIAAv3Hh.jpg",
      "id_str" : "766334545352269824",
      "id" : 766334545352269824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqKRNXLVIAAv3Hh.jpg",
      "sizes" : [ {
        "h" : 460,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/mXbKe4gEPA"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/766335802179620864\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/mXbKe4gEPA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqKROHZVYAE8UIo.jpg",
      "id_str" : "766334558295908353",
      "id" : 766334558295908353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqKROHZVYAE8UIo.jpg",
      "sizes" : [ {
        "h" : 460,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/mXbKe4gEPA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766335802179620864",
  "text" : "Trying to balance CMPT-363 workload with desired pedagogical sequence of activities. Event-span visualization helps: https:\/\/t.co\/mXbKe4gEPA",
  "id" : 766335802179620864,
  "created_at" : "2016-08-18 18:07:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/semktZUNWD",
      "expanded_url" : "https:\/\/guides.instructure.com\/m\/4152\/l\/61285-what-is-the-scheduler",
      "display_url" : "guides.instructure.com\/m\/4152\/l\/61285\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766020540213493760",
  "text" : "With CMPT 363 UX open source project work, in-person &amp; virtual office hours are needed. A handy #CanvasLMS feature: https:\/\/t.co\/semktZUNWD\uD83D\uDC4D",
  "id" : 766020540213493760,
  "created_at" : "2016-08-17 21:15:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 3, 11 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/QaetEigFSV",
      "expanded_url" : "http:\/\/www.dr-chuck.com\/csev-blog\/2016\/08\/abstract-building-the-next-generation-digital-learning-environment-ngdle\/",
      "display_url" : "dr-chuck.com\/csev-blog\/2016\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765990704690581504",
  "text" : "RT @drchuck: Abstract: Building the Next Generation Digital Learning Environment (NGDLE) https:\/\/t.co\/QaetEigFSV - For my September trip to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/QaetEigFSV",
        "expanded_url" : "http:\/\/www.dr-chuck.com\/csev-blog\/2016\/08\/abstract-building-the-next-generation-digital-learning-environment-ngdle\/",
        "display_url" : "dr-chuck.com\/csev-blog\/2016\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765960783452704768",
    "text" : "Abstract: Building the Next Generation Digital Learning Environment (NGDLE) https:\/\/t.co\/QaetEigFSV - For my September trip to Korea",
    "id" : 765960783452704768,
    "created_at" : "2016-08-17 17:17:36 +0000",
    "user" : {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "protected" : false,
      "id_str" : "10185562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1396181322\/new-square-pic_normal.jpg",
      "id" : 10185562,
      "verified" : false
    }
  },
  "id" : 765990704690581504,
  "created_at" : "2016-08-17 19:16:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 58, 65 ]
    }, {
      "text" : "cwcon",
      "indices" : [ 66, 72 ]
    }, {
      "text" : "drupal",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "elmsln",
      "indices" : [ 81, 88 ]
    }, {
      "text" : "education",
      "indices" : [ 89, 99 ]
    }, {
      "text" : "ngdle",
      "indices" : [ 100, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/KBO2FsQGWP",
      "expanded_url" : "https:\/\/btopro.wordpress.com\/2016\/08\/17\/we-can-no-longer-turn-our-nose-to-an-industry",
      "display_url" : "btopro.wordpress.com\/2016\/08\/17\/we-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765768030920073216",
  "text" : "RT @btopro: We can no longer turn our nose to an industry #edtech #cwcon #drupal #elmsln #education #ngdle https:\/\/t.co\/KBO2FsQGWP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 46, 53 ]
      }, {
        "text" : "cwcon",
        "indices" : [ 54, 60 ]
      }, {
        "text" : "drupal",
        "indices" : [ 61, 68 ]
      }, {
        "text" : "elmsln",
        "indices" : [ 69, 76 ]
      }, {
        "text" : "education",
        "indices" : [ 77, 87 ]
      }, {
        "text" : "ngdle",
        "indices" : [ 88, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/KBO2FsQGWP",
        "expanded_url" : "https:\/\/btopro.wordpress.com\/2016\/08\/17\/we-can-no-longer-turn-our-nose-to-an-industry",
        "display_url" : "btopro.wordpress.com\/2016\/08\/17\/we-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765745060067454976",
    "text" : "We can no longer turn our nose to an industry #edtech #cwcon #drupal #elmsln #education #ngdle https:\/\/t.co\/KBO2FsQGWP",
    "id" : 765745060067454976,
    "created_at" : "2016-08-17 03:00:23 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 765768030920073216,
  "created_at" : "2016-08-17 04:31:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niamh Redmond",
      "screen_name" : "nredmond",
      "indices" : [ 3, 12 ],
      "id_str" : "8724262",
      "id" : 8724262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/M4FuadJKBa",
      "expanded_url" : "http:\/\/ow.ly\/NU5fY",
      "display_url" : "ow.ly\/NU5fY"
    } ]
  },
  "geo" : { },
  "id_str" : "765764802912346112",
  "text" : "RT @nredmond: \u201CI\u2019m coming to believe that Product Management and UX leadership are indistinguishable.\u201D http:\/\/t.co\/M4FuadJKBa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/M4FuadJKBa",
        "expanded_url" : "http:\/\/ow.ly\/NU5fY",
        "display_url" : "ow.ly\/NU5fY"
      } ]
    },
    "geo" : { },
    "id_str" : "606710667253555201",
    "text" : "\u201CI\u2019m coming to believe that Product Management and UX leadership are indistinguishable.\u201D http:\/\/t.co\/M4FuadJKBa",
    "id" : 606710667253555201,
    "created_at" : "2015-06-05 06:34:29 +0000",
    "user" : {
      "name" : "Niamh Redmond",
      "screen_name" : "nredmond",
      "protected" : false,
      "id_str" : "8724262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565448348153679872\/8xkvMU7E_normal.jpeg",
      "id" : 8724262,
      "verified" : false
    }
  },
  "id" : 765764802912346112,
  "created_at" : "2016-08-17 04:18:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cloud Four",
      "screen_name" : "CloudFour",
      "indices" : [ 3, 13 ],
      "id_str" : "9766702",
      "id" : 9766702
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CloudFour\/status\/763391066028421121\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/voXz8Wr6t7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpgcIJwUIAA0pBu.png",
      "id_str" : "763391063222394880",
      "id" : 763391063222394880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpgcIJwUIAA0pBu.png",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/voXz8Wr6t7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/tyut06KEA4",
      "expanded_url" : "https:\/\/cloudfour.com\/thinks\/designing-responsive-progressive-web-apps\/",
      "display_url" : "cloudfour.com\/thinks\/designi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765656744840142848",
  "text" : "RT @CloudFour: Designing Responsive Progressive Web\u00A0Apps https:\/\/t.co\/tyut06KEA4 https:\/\/t.co\/voXz8Wr6t7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CloudFour\/status\/763391066028421121\/photo\/1",
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/voXz8Wr6t7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpgcIJwUIAA0pBu.png",
        "id_str" : "763391063222394880",
        "id" : 763391063222394880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpgcIJwUIAA0pBu.png",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/voXz8Wr6t7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/tyut06KEA4",
        "expanded_url" : "https:\/\/cloudfour.com\/thinks\/designing-responsive-progressive-web-apps\/",
        "display_url" : "cloudfour.com\/thinks\/designi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763391066028421121",
    "text" : "Designing Responsive Progressive Web\u00A0Apps https:\/\/t.co\/tyut06KEA4 https:\/\/t.co\/voXz8Wr6t7",
    "id" : 763391066028421121,
    "created_at" : "2016-08-10 15:06:27 +0000",
    "user" : {
      "name" : "Cloud Four",
      "screen_name" : "CloudFour",
      "protected" : false,
      "id_str" : "9766702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745025691389825024\/oKWEifgF_normal.jpg",
      "id" : 9766702,
      "verified" : false
    }
  },
  "id" : 765656744840142848,
  "created_at" : "2016-08-16 21:09:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/765620875089498112\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/y3dBbrh0Dw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqAHQquUMAAsSdJ.jpg",
      "id_str" : "765619919580835840",
      "id" : 765619919580835840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqAHQquUMAAsSdJ.jpg",
      "sizes" : [ {
        "h" : 584,
        "resize" : "fit",
        "w" : 949
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 949
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 949
      } ],
      "display_url" : "pic.twitter.com\/y3dBbrh0Dw"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 92, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765620875089498112",
  "text" : "Because outlines aren't enough, I am once again sending out a 'sneak peek' to my registered #SFU CMPT 363 students. https:\/\/t.co\/y3dBbrh0Dw",
  "id" : 765620875089498112,
  "created_at" : "2016-08-16 18:46:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765599381152116736",
  "text" : "Only 3 weeks until the start of term, and CMPT 363 is taking shape. Today's adventure is with the required ethics forms for user research...",
  "id" : 765599381152116736,
  "created_at" : "2016-08-16 17:21:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Recode",
      "screen_name" : "Recode",
      "indices" : [ 3, 10 ],
      "id_str" : "2244340904",
      "id" : 2244340904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/faH9Eo0f7N",
      "expanded_url" : "http:\/\/www.recode.net\/2016\/8\/15\/12475620\/touch-enabled-mac-computer-touchscreen-laptop-imac-macbook",
      "display_url" : "recode.net\/2016\/8\/15\/1247\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765404465771917312",
  "text" : "RT @Recode: \"It\u2019s simply no longer amusing when I absent-mindedly tap on my Macbook Air\u2019s screen.\" https:\/\/t.co\/faH9Eo0f7N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/faH9Eo0f7N",
        "expanded_url" : "http:\/\/www.recode.net\/2016\/8\/15\/12475620\/touch-enabled-mac-computer-touchscreen-laptop-imac-macbook",
        "display_url" : "recode.net\/2016\/8\/15\/1247\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765388867067260929",
    "text" : "\"It\u2019s simply no longer amusing when I absent-mindedly tap on my Macbook Air\u2019s screen.\" https:\/\/t.co\/faH9Eo0f7N",
    "id" : 765388867067260929,
    "created_at" : "2016-08-16 03:25:00 +0000",
    "user" : {
      "name" : "Recode",
      "screen_name" : "Recode",
      "protected" : false,
      "id_str" : "2244340904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729365899828989952\/o0AuZCNW_normal.jpg",
      "id" : 2244340904,
      "verified" : true
    }
  },
  "id" : 765404465771917312,
  "created_at" : "2016-08-16 04:26:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tori Klassen",
      "screen_name" : "ToriKlassen",
      "indices" : [ 0, 12 ],
      "id_str" : "17394205",
      "id" : 17394205
    }, {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 13, 24 ],
      "id_str" : "91634720",
      "id" : 91634720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765333592859774977",
  "geo" : { },
  "id_str" : "765365205073223680",
  "in_reply_to_user_id" : 17394205,
  "text" : "@ToriKlassen @kenjeffery Congratulations!!!",
  "id" : 765365205073223680,
  "in_reply_to_status_id" : 765333592859774977,
  "created_at" : "2016-08-16 01:50:59 +0000",
  "in_reply_to_screen_name" : "ToriKlassen",
  "in_reply_to_user_id_str" : "17394205",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rajiv Jhangiani",
      "screen_name" : "thatpsychprof",
      "indices" : [ 3, 17 ],
      "id_str" : "39835900",
      "id" : 39835900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/mzbqCOttGp",
      "expanded_url" : "https:\/\/qsharingeu.eu.qualtrics.com\/SE\/?SID=SV_2fOdZ08Y6fWB3lX",
      "display_url" : "qsharingeu.eu.qualtrics.com\/SE\/?SID=SV_2fO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765353810260742144",
  "text" : "RT @thatpsychprof: Are you faculty at a BC institution? Pls take this brief survey re: selection of req\u2019d course materials: https:\/\/t.co\/mz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/mzbqCOttGp",
        "expanded_url" : "https:\/\/qsharingeu.eu.qualtrics.com\/SE\/?SID=SV_2fOdZ08Y6fWB3lX",
        "display_url" : "qsharingeu.eu.qualtrics.com\/SE\/?SID=SV_2fO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765352456981127168",
    "text" : "Are you faculty at a BC institution? Pls take this brief survey re: selection of req\u2019d course materials: https:\/\/t.co\/mzbqCOttGp Please RT",
    "id" : 765352456981127168,
    "created_at" : "2016-08-16 01:00:19 +0000",
    "user" : {
      "name" : "Rajiv Jhangiani",
      "screen_name" : "thatpsychprof",
      "protected" : false,
      "id_str" : "39835900",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677017328740122624\/zdAKRH0L_normal.jpg",
      "id" : 39835900,
      "verified" : false
    }
  },
  "id" : 765353810260742144,
  "created_at" : "2016-08-16 01:05:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Adams",
      "screen_name" : "netik",
      "indices" : [ 3, 9 ],
      "id_str" : "899701",
      "id" : 899701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765340606763859969",
  "text" : "RT @netik: There is no Internet of Things. There are only many unpatched, vulnerable small computers on the Internet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765276366304489472",
    "text" : "There is no Internet of Things. There are only many unpatched, vulnerable small computers on the Internet.",
    "id" : 765276366304489472,
    "created_at" : "2016-08-15 19:57:58 +0000",
    "user" : {
      "name" : "John Adams",
      "screen_name" : "netik",
      "protected" : false,
      "id_str" : "899701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1460780682\/me_normal.jpg",
      "id" : 899701,
      "verified" : false
    }
  },
  "id" : 765340606763859969,
  "created_at" : "2016-08-16 00:13:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenton Varda",
      "screen_name" : "KentonVarda",
      "indices" : [ 0, 12 ],
      "id_str" : "17459118",
      "id" : 17459118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/djhUdqJpxB",
      "expanded_url" : "https:\/\/github.com\/simonv3\/quick-survey\/issues\/41",
      "display_url" : "github.com\/simonv3\/quick-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "765334354960584704",
  "geo" : { },
  "id_str" : "765338047990947840",
  "in_reply_to_user_id" : 17459118,
  "text" : "@KentonVarda Really good idea, thanks!\uD83D\uDE42  I've added an issue for Simple Survey: https:\/\/t.co\/djhUdqJpxB",
  "id" : 765338047990947840,
  "in_reply_to_status_id" : 765334354960584704,
  "created_at" : "2016-08-16 00:03:04 +0000",
  "in_reply_to_screen_name" : "KentonVarda",
  "in_reply_to_user_id_str" : "17459118",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/5TS1XzZJCa",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-08-16-a-few-thoughts-about-redesigning-cmpt-363-in-the-open-once-again",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765330707627388928",
  "text" : "A sneak-peek at an upcoming post: A Few Thoughts About... Redesigning CMPT 363 in the Open (Oh Yes, Once Again) https:\/\/t.co\/5TS1XzZJCa",
  "id" : 765330707627388928,
  "created_at" : "2016-08-15 23:33:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765327265160843265",
  "text" : "(4\/5) to contribute concrete UX improvements to. However, students will have the choice to publicly share their project suggestions.",
  "id" : 765327265160843265,
  "created_at" : "2016-08-15 23:20:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/5ferws8h6S",
      "expanded_url" : "https:\/\/www.pearsonhighered.com\/revel\/educators\/",
      "display_url" : "pearsonhighered.com\/revel\/educator\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765322742514057217",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro I'll just leave this here for you: https:\/\/t.co\/5ferws8h6S\nUNREAL",
  "id" : 765322742514057217,
  "created_at" : "2016-08-15 23:02:15 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765319274613186560",
  "geo" : { },
  "id_str" : "765319903276511232",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc x1000 Yuck. Words\/phrases like \"innovation\", \"best thinking in instructional design\" and \"new approach to digital learning\"\u2639\uFE0F",
  "id" : 765319903276511232,
  "in_reply_to_status_id" : 765319274613186560,
  "created_at" : "2016-08-15 22:50:58 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Blickensderfer",
      "screen_name" : "Dan_Blick",
      "indices" : [ 0, 10 ],
      "id_str" : "188554158",
      "id" : 188554158
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 11, 19 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/GlmKo5HFMW",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2015-12-11-using-grav-with-github",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "765313224002723840",
  "geo" : { },
  "id_str" : "765313592749010944",
  "in_reply_to_user_id" : 188554158,
  "text" : "@Dan_Blick @getgrav Awesome! If you have not already run across it, you might find this article helpful: https:\/\/t.co\/GlmKo5HFMW",
  "id" : 765313592749010944,
  "in_reply_to_status_id" : 765313224002723840,
  "created_at" : "2016-08-15 22:25:54 +0000",
  "in_reply_to_screen_name" : "Dan_Blick",
  "in_reply_to_user_id_str" : "188554158",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess McMullin",
      "screen_name" : "jessmcmullin",
      "indices" : [ 3, 16 ],
      "id_str" : "381203",
      "id" : 381203
    }, {
      "name" : "SDN Canada",
      "screen_name" : "SDNCanada",
      "indices" : [ 139, 140 ],
      "id_str" : "3229051105",
      "id" : 3229051105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "servicedesign",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/FQ6aSIOnox",
      "expanded_url" : "https:\/\/search.employment.gov.bc.ca\/cgi-bin\/a\/highlightjob.cgi?jobid=35545",
      "display_url" : "search.employment.gov.bc.ca\/cgi-bin\/a\/high\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765305799908339714",
  "text" : "RT @jessmcmullin: Govt of British Columbia hiring service designers to join established team in Victoria BC https:\/\/t.co\/FQ6aSIOnox #servic\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SDN Canada",
        "screen_name" : "SDNCanada",
        "indices" : [ 129, 139 ],
        "id_str" : "3229051105",
        "id" : 3229051105
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "servicedesign",
        "indices" : [ 114, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/FQ6aSIOnox",
        "expanded_url" : "https:\/\/search.employment.gov.bc.ca\/cgi-bin\/a\/highlightjob.cgi?jobid=35545",
        "display_url" : "search.employment.gov.bc.ca\/cgi-bin\/a\/high\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765305672493785089",
    "text" : "Govt of British Columbia hiring service designers to join established team in Victoria BC https:\/\/t.co\/FQ6aSIOnox #servicedesign @SDNCanada",
    "id" : 765305672493785089,
    "created_at" : "2016-08-15 21:54:25 +0000",
    "user" : {
      "name" : "Jess McMullin",
      "screen_name" : "jessmcmullin",
      "protected" : false,
      "id_str" : "381203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695452125044744192\/tVex0lK2_normal.jpg",
      "id" : 381203,
      "verified" : false
    }
  },
  "id" : 765305799908339714,
  "created_at" : "2016-08-15 21:54:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765305764705558528",
  "text" : "For CMPT 363 this term w 85 students it looks like 5 person groups with F2F consults or 3-4 person groups with virtual consults + a few F2F",
  "id" : 765305764705558528,
  "created_at" : "2016-08-15 21:54:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765304058601091072",
  "text" : "Any fellow instructors out there with 4-person student groups vs 5-person student groups experiences? Sounds like &gt;4 makes a big difference.",
  "id" : 765304058601091072,
  "created_at" : "2016-08-15 21:48:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 0, 8 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765303288971472896",
  "in_reply_to_user_id" : 10185562,
  "text" : "@drchuck Any advice to share regarding in-person vs. virtual office hours using Skype for giving feedback to student project groups?",
  "id" : 765303288971472896,
  "created_at" : "2016-08-15 21:44:57 +0000",
  "in_reply_to_screen_name" : "drchuck",
  "in_reply_to_user_id_str" : "10185562",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 50, 62 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765296136160579586",
  "text" : "Does anyone know of a survey tool compatible with @SandstormIO that provides email notifications of submissions?",
  "id" : 765296136160579586,
  "created_at" : "2016-08-15 21:16:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 20, 28 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 33, 48 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765292876070739973",
  "text" : "Many thanks to both @getgrav and @ReclaimHosting for their awesome support today with my Grav install! What an amazing combination \uD83D\uDC4D",
  "id" : 765292876070739973,
  "created_at" : "2016-08-15 21:03:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Blickensderfer",
      "screen_name" : "Dan_Blick",
      "indices" : [ 0, 10 ],
      "id_str" : "188554158",
      "id" : 188554158
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 11, 19 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765277707768913920",
  "geo" : { },
  "id_str" : "765292014489391104",
  "in_reply_to_user_id" : 188554158,
  "text" : "@Dan_Blick @getgrav If you have any questions or see something of interest please let me know!\uD83D\uDE42",
  "id" : 765292014489391104,
  "in_reply_to_status_id" : 765277707768913920,
  "created_at" : "2016-08-15 21:00:09 +0000",
  "in_reply_to_screen_name" : "Dan_Blick",
  "in_reply_to_user_id_str" : "188554158",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/765291635659845633\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/xiZJOPdknM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp7b2qaUMAEjuuy.jpg",
      "id_str" : "765290718843645953",
      "id" : 765290718843645953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp7b2qaUMAEjuuy.jpg",
      "sizes" : [ {
        "h" : 460,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/xiZJOPdknM"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/765291635659845633\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/xiZJOPdknM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp7b3Y9UAAAvLem.jpg",
      "id_str" : "765290731338465280",
      "id" : 765290731338465280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp7b3Y9UAAAvLem.jpg",
      "sizes" : [ {
        "h" : 460,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/xiZJOPdknM"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/765291635659845633\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/xiZJOPdknM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp7b4KBVUAAfvmH.jpg",
      "id_str" : "765290744508665856",
      "id" : 765290744508665856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp7b4KBVUAAfvmH.jpg",
      "sizes" : [ {
        "h" : 460,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/xiZJOPdknM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765291635659845633",
  "text" : "Mini-rant: Students are not just taking your course, but others too. Visualize course activities to lessen overload\uD83D\uDC4D https:\/\/t.co\/xiZJOPdknM",
  "id" : 765291635659845633,
  "created_at" : "2016-08-15 20:58:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/K7Yabsfe2j",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/20703\/quizzes\/28239",
      "display_url" : "canvas.sfu.ca\/courses\/20703\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765290135705391106",
  "text" : "(5\/5) Hopefully, this will self-regulate the quality of contrib to projects. Draft project choice form: https:\/\/t.co\/K7Yabsfe2j Thoughts?",
  "id" : 765290135705391106,
  "created_at" : "2016-08-15 20:52:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765290039584493568",
  "text" : "(3\/5) various past CMPT 363 students who now work in the industry I will be offering students groups to choose an open source project...",
  "id" : 765290039584493568,
  "created_at" : "2016-08-15 20:52:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765289996391620608",
  "text" : "(2\/5) contribute to open source projects, with the caveat that their UX skill levels would vary greatly. After discussing this with...",
  "id" : 765289996391620608,
  "created_at" : "2016-08-15 20:52:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765289943530811392",
  "text" : "(1\/5) Next up, contributing to open source projects! I've been thinking about having students in my intro UX CMPT 363 course...",
  "id" : 765289943530811392,
  "created_at" : "2016-08-15 20:51:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765261999055904769",
  "text" : "Next rant: getting 3rd year Computing Science students taking an intro UX course to get involved with open source projects! But first, lunch",
  "id" : 765261999055904769,
  "created_at" : "2016-08-15 19:00:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 27, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/7mBhplPWvX",
      "expanded_url" : "https:\/\/1drv.ms\/x\/s!Aoj9Cstt0NJ0kfM1eZMt0DSxtlZotA",
      "display_url" : "1drv.ms\/x\/s!Aoj9Cstt0N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765261463229390849",
  "text" : "Oh, and here is the W.I.P. #UX topics list I've created for my CMPT 363 students as a starting point: https:\/\/t.co\/7mBhplPWvX",
  "id" : 765261463229390849,
  "created_at" : "2016-08-15 18:58:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765260053146324992",
  "text" : "(6\/6) to be used by all students within the course as additional learning resources for the last phase of their term project work. Comments?",
  "id" : 765260053146324992,
  "created_at" : "2016-08-15 18:53:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765260018014822400",
  "text" : "(5\/6) which will be peer-reviewed and then place all students papers in a shared space within #CanvasLMS during the term...",
  "id" : 765260018014822400,
  "created_at" : "2016-08-15 18:53:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765259982161846272",
  "text" : "(4\/6) So, the 'partially open' approach I will try this term is having students choose a UX topic of interest, write summary articles...",
  "id" : 765259982161846272,
  "created_at" : "2016-08-15 18:52:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765259947781201921",
  "text" : "(3\/6) but find this process a daunting one to do properly within 13 weeks of a third year Computer Science UX design course.",
  "id" : 765259947781201921,
  "created_at" : "2016-08-15 18:52:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765259900175781888",
  "text" : "(2\/6) For example, I love the (pedagogical) approach of students editing Wikipedia articles in the open for a writing assignment...",
  "id" : 765259900175781888,
  "created_at" : "2016-08-15 18:52:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765259832249061376",
  "text" : "(1\/6) I myself often fall into the trap of looking at educational resources\/activities in terms of 'closed' vs. 'open'.",
  "id" : 765259832249061376,
  "created_at" : "2016-08-15 18:52:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765249231493877760",
  "text" : "Next rant: the importance of positioning 'open' as a gradient versus a binary switch.",
  "id" : 765249231493877760,
  "created_at" : "2016-08-15 18:10:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/aUxwgZsTqx",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-163\/schedule",
      "display_url" : "paulhibbitts.net\/cmpt-363-163\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765249058554257408",
  "text" : "Any other educators with experiences of shifting from course topics \u279C questions? Changes rolled down to schedule: https:\/\/t.co\/aUxwgZsTqx",
  "id" : 765249058554257408,
  "created_at" : "2016-08-15 18:09:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765248457229467649",
  "text" : "Here's the orig topic list for CMPT 363:\nDesign Research\nUser-Centered Design\nInteraction Design\nMulti-platform Design\nUsability Evaluation\uD83D\uDCA4",
  "id" : 765248457229467649,
  "created_at" : "2016-08-15 18:07:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/QCOrLOLKxf",
      "expanded_url" : "https:\/\/workflowy.com\/s\/0UvwffTinC",
      "display_url" : "workflowy.com\/s\/0UvwffTinC"
    } ]
  },
  "geo" : { },
  "id_str" : "765246141017395200",
  "text" : "While it may sound minor, one of the biggest surprises was the subtle change from course topics to course questions: https:\/\/t.co\/QCOrLOLKxf",
  "id" : 765246141017395200,
  "created_at" : "2016-08-15 17:57:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WorkFlowy",
      "screen_name" : "WorkFlowy",
      "indices" : [ 92, 102 ],
      "id_str" : "82836356",
      "id" : 82836356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765245744844386304",
  "text" : "For the Fall 2016 offering of CMPT 363 I've been sharing WIP course environments plus using @WorkFlowy to share in-progress plans\/outlines.",
  "id" : 765245744844386304,
  "created_at" : "2016-08-15 17:56:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/pvYWEY1V8R",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/etug-spring-2014-developing-a-course-in-the-open-a-case-study#\/",
      "display_url" : "slides.com\/paulhibbitts\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765245237279072256",
  "text" : "Hard to believe it's 3 years since I started developing my courses in the open, and I can't imagine ever stopping. https:\/\/t.co\/pvYWEY1V8R",
  "id" : 765245237279072256,
  "created_at" : "2016-08-15 17:54:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 3, 14 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/Lk2qsIKSt9",
      "expanded_url" : "https:\/\/twitter.com\/berkun\/status\/765219251452084224",
      "display_url" : "twitter.com\/berkun\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765222022683070465",
  "text" : "RT @jimbobtyer: Positive problem solving...I like it.  https:\/\/t.co\/Lk2qsIKSt9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/Lk2qsIKSt9",
        "expanded_url" : "https:\/\/twitter.com\/berkun\/status\/765219251452084224",
        "display_url" : "twitter.com\/berkun\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765220521235668992",
    "text" : "Positive problem solving...I like it.  https:\/\/t.co\/Lk2qsIKSt9",
    "id" : 765220521235668992,
    "created_at" : "2016-08-15 16:16:04 +0000",
    "user" : {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "protected" : false,
      "id_str" : "217880712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444528283523108864\/ZqDcsLoO_normal.jpeg",
      "id" : 217880712,
      "verified" : false
    }
  },
  "id" : 765222022683070465,
  "created_at" : "2016-08-15 16:22:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Feldstein",
      "screen_name" : "mfeldstein67",
      "indices" : [ 3, 16 ],
      "id_str" : "10187072",
      "id" : 10187072
    }, {
      "name" : "Phil Hill",
      "screen_name" : "PhilOnEdTech",
      "indices" : [ 121, 134 ],
      "id_str" : "17997570",
      "id" : 17997570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Eez89f10Ed",
      "expanded_url" : "http:\/\/bit.ly\/2b8dAhf",
      "display_url" : "bit.ly\/2b8dAhf"
    } ]
  },
  "geo" : { },
  "id_str" : "765054409495617536",
  "text" : "RT @mfeldstein67: New post on e-Literate: \"TechCrunch: \u201CEdTech \u2013 2017\u2019s big, untapped and safe investor opportunity\u201D\" by @PhilOnEdTech http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mfeldstein.com\/\" rel=\"nofollow\"\u003Ee-Literate\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Phil Hill",
        "screen_name" : "PhilOnEdTech",
        "indices" : [ 103, 116 ],
        "id_str" : "17997570",
        "id" : 17997570
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Eez89f10Ed",
        "expanded_url" : "http:\/\/bit.ly\/2b8dAhf",
        "display_url" : "bit.ly\/2b8dAhf"
      } ]
    },
    "geo" : { },
    "id_str" : "765048012435521536",
    "text" : "New post on e-Literate: \"TechCrunch: \u201CEdTech \u2013 2017\u2019s big, untapped and safe investor opportunity\u201D\" by @PhilOnEdTech https:\/\/t.co\/Eez89f10Ed",
    "id" : 765048012435521536,
    "created_at" : "2016-08-15 04:50:34 +0000",
    "user" : {
      "name" : "Michael Feldstein",
      "screen_name" : "mfeldstein67",
      "protected" : false,
      "id_str" : "10187072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612670776047603712\/1oUXVo2E_normal.png",
      "id" : 10187072,
      "verified" : false
    }
  },
  "id" : 765054409495617536,
  "created_at" : "2016-08-15 05:15:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team Canada",
      "screen_name" : "TeamCanada",
      "indices" : [ 3, 14 ],
      "id_str" : "38491229",
      "id" : 38491229
    }, {
      "name" : "Andre De Grasse",
      "screen_name" : "De6rasse",
      "indices" : [ 66, 75 ],
      "id_str" : "322871349",
      "id" : 322871349
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TeamCanada\/status\/764999838509457408\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/aoCUGiolyL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp3S8L9XgAAZDf_.jpg",
      "id_str" : "764999443167019008",
      "id" : 764999443167019008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp3S8L9XgAAZDf_.jpg",
      "sizes" : [ {
        "h" : 754,
        "resize" : "fit",
        "w" : 1340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 754,
        "resize" : "fit",
        "w" : 1340
      } ],
      "display_url" : "pic.twitter.com\/aoCUGiolyL"
    } ],
    "hashtags" : [ {
      "text" : "Olympics",
      "indices" : [ 26, 35 ]
    }, {
      "text" : "TeamCanada",
      "indices" : [ 103, 114 ]
    }, {
      "text" : "Rio2016",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/onIpPM2iaW",
      "expanded_url" : "http:\/\/bit.ly\/2aSSrVw",
      "display_url" : "bit.ly\/2aSSrVw"
    } ]
  },
  "geo" : { },
  "id_str" : "765001176261677056",
  "text" : "RT @TeamCanada: The first #Olympics lap of honour for 21-year-old @De6rasse: https:\/\/t.co\/onIpPM2iaW \n\n#TeamCanada #Rio2016 https:\/\/t.co\/ao\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andre De Grasse",
        "screen_name" : "De6rasse",
        "indices" : [ 50, 59 ],
        "id_str" : "322871349",
        "id" : 322871349
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TeamCanada\/status\/764999838509457408\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/aoCUGiolyL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp3S8L9XgAAZDf_.jpg",
        "id_str" : "764999443167019008",
        "id" : 764999443167019008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp3S8L9XgAAZDf_.jpg",
        "sizes" : [ {
          "h" : 754,
          "resize" : "fit",
          "w" : 1340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 754,
          "resize" : "fit",
          "w" : 1340
        } ],
        "display_url" : "pic.twitter.com\/aoCUGiolyL"
      } ],
      "hashtags" : [ {
        "text" : "Olympics",
        "indices" : [ 10, 19 ]
      }, {
        "text" : "TeamCanada",
        "indices" : [ 87, 98 ]
      }, {
        "text" : "Rio2016",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/onIpPM2iaW",
        "expanded_url" : "http:\/\/bit.ly\/2aSSrVw",
        "display_url" : "bit.ly\/2aSSrVw"
      } ]
    },
    "geo" : { },
    "id_str" : "764999838509457408",
    "text" : "The first #Olympics lap of honour for 21-year-old @De6rasse: https:\/\/t.co\/onIpPM2iaW \n\n#TeamCanada #Rio2016 https:\/\/t.co\/aoCUGiolyL",
    "id" : 764999838509457408,
    "created_at" : "2016-08-15 01:39:09 +0000",
    "user" : {
      "name" : "Team Canada",
      "screen_name" : "TeamCanada",
      "protected" : false,
      "id_str" : "38491229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412995539525828608\/h_43xZ8n_normal.png",
      "id" : 38491229,
      "verified" : true
    }
  },
  "id" : 765001176261677056,
  "created_at" : "2016-08-15 01:44:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Richardson",
      "screen_name" : "willrich45",
      "indices" : [ 3, 14 ],
      "id_str" : "1349941",
      "id" : 1349941
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/wtffaPqRCh",
      "expanded_url" : "http:\/\/buff.ly\/2bqNoOI",
      "display_url" : "buff.ly\/2bqNoOI"
    } ]
  },
  "geo" : { },
  "id_str" : "764985869740548096",
  "text" : "RT @willrich45: \u201CThe core premise of Mindstorms is that children learn best when they are in charge\u201D https:\/\/t.co\/wtffaPqRCh Read Mindstorm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/wtffaPqRCh",
        "expanded_url" : "http:\/\/buff.ly\/2bqNoOI",
        "display_url" : "buff.ly\/2bqNoOI"
      } ]
    },
    "geo" : { },
    "id_str" : "764932609524764672",
    "text" : "\u201CThe core premise of Mindstorms is that children learn best when they are in charge\u201D https:\/\/t.co\/wtffaPqRCh Read Mindstorms. Please #edchat",
    "id" : 764932609524764672,
    "created_at" : "2016-08-14 21:12:00 +0000",
    "user" : {
      "name" : "Will Richardson",
      "screen_name" : "willrich45",
      "protected" : false,
      "id_str" : "1349941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707222705519665152\/LHwer5Lh_normal.jpg",
      "id" : 1349941,
      "verified" : false
    }
  },
  "id" : 764985869740548096,
  "created_at" : "2016-08-15 00:43:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764969879858401280",
  "text" : "When you teach a course for almost 20 years, change is essential. Each term holds the possibility of a better experience for my students.",
  "id" : 764969879858401280,
  "created_at" : "2016-08-14 23:40:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764968580911816704",
  "text" : "I'll be sharing lots more details about my on-going work to improve (a.k.a. redesign) my Fall 2016 CMPT 363 UX course in the open this week.",
  "id" : 764968580911816704,
  "created_at" : "2016-08-14 23:34:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Spool",
      "screen_name" : "jmspool",
      "indices" : [ 3, 11 ],
      "id_str" : "849101",
      "id" : 849101
    }, {
      "name" : "Center Centre",
      "screen_name" : "CenterCentre",
      "indices" : [ 26, 39 ],
      "id_str" : "1408609760",
      "id" : 1408609760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/ivy1c1bOWJ",
      "expanded_url" : "http:\/\/centercentre.com\/blog\/2016-08-10-big-news-center-centres-first-students-will-start-on-october-17",
      "display_url" : "centercentre.com\/blog\/2016-08-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764961117898543104",
  "text" : "RT @jmspool: Excited that @CenterCentre is starting in October.\n\nKnow anyone who\u2019d make a great student?\n\nhttps:\/\/t.co\/ivy1c1bOWJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Center Centre",
        "screen_name" : "CenterCentre",
        "indices" : [ 13, 26 ],
        "id_str" : "1408609760",
        "id" : 1408609760
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/ivy1c1bOWJ",
        "expanded_url" : "http:\/\/centercentre.com\/blog\/2016-08-10-big-news-center-centres-first-students-will-start-on-october-17",
        "display_url" : "centercentre.com\/blog\/2016-08-1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764960841401831424",
    "text" : "Excited that @CenterCentre is starting in October.\n\nKnow anyone who\u2019d make a great student?\n\nhttps:\/\/t.co\/ivy1c1bOWJ",
    "id" : 764960841401831424,
    "created_at" : "2016-08-14 23:04:11 +0000",
    "user" : {
      "name" : "Jared Spool",
      "screen_name" : "jmspool",
      "protected" : false,
      "id_str" : "849101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744600845199745025\/azqaoUzM_normal.jpg",
      "id" : 849101,
      "verified" : false
    }
  },
  "id" : 764961117898543104,
  "created_at" : "2016-08-14 23:05:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764929263157903360",
  "text" : "Hmmm.. trying out a reading of user research methods for my \"What does a holistic user experience design process look like?\" Essential item!",
  "id" : 764929263157903360,
  "created_at" : "2016-08-14 20:58:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 3, 11 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "SXSWedu",
      "screen_name" : "SXSWedu",
      "indices" : [ 29, 37 ],
      "id_str" : "189271022",
      "id" : 189271022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/vOIuXwXHX4",
      "expanded_url" : "http:\/\/panelpicker.sxsw.com\/vote\/67294",
      "display_url" : "panelpicker.sxsw.com\/vote\/67294"
    } ]
  },
  "geo" : { },
  "id_str" : "764928421629534208",
  "text" : "RT @drchuck: I am part of an @SXSWedu panel about new ways to teach Computer Science - Please take a look and give us a vote https:\/\/t.co\/v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SXSWedu",
        "screen_name" : "SXSWedu",
        "indices" : [ 16, 24 ],
        "id_str" : "189271022",
        "id" : 189271022
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/vOIuXwXHX4",
        "expanded_url" : "http:\/\/panelpicker.sxsw.com\/vote\/67294",
        "display_url" : "panelpicker.sxsw.com\/vote\/67294"
      } ]
    },
    "geo" : { },
    "id_str" : "764858294821326848",
    "text" : "I am part of an @SXSWedu panel about new ways to teach Computer Science - Please take a look and give us a vote https:\/\/t.co\/vOIuXwXHX4",
    "id" : 764858294821326848,
    "created_at" : "2016-08-14 16:16:42 +0000",
    "user" : {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "protected" : false,
      "id_str" : "10185562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1396181322\/new-square-pic_normal.jpg",
      "id" : 10185562,
      "verified" : false
    }
  },
  "id" : 764928421629534208,
  "created_at" : "2016-08-14 20:55:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathaniel A Conroy",
      "screen_name" : "ConroyNathaniel",
      "indices" : [ 3, 19 ],
      "id_str" : "3328524183",
      "id" : 3328524183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/BL1CuN40NJ",
      "expanded_url" : "http:\/\/www.digitalhumanities.org\/dhq\/vol\/10\/2\/000248\/000248.html",
      "display_url" : "digitalhumanities.org\/dhq\/vol\/10\/2\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764901394373484544",
  "text" : "RT @ConroyNathaniel: Platforms like Wordpress and Drupal aren't neutral. They're arguments in their own right. See Drucker and Svensson: ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/BL1CuN40NJ",
        "expanded_url" : "http:\/\/www.digitalhumanities.org\/dhq\/vol\/10\/2\/000248\/000248.html",
        "display_url" : "digitalhumanities.org\/dhq\/vol\/10\/2\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764853431035109376",
    "text" : "Platforms like Wordpress and Drupal aren't neutral. They're arguments in their own right. See Drucker and Svensson: https:\/\/t.co\/BL1CuN40NJ",
    "id" : 764853431035109376,
    "created_at" : "2016-08-14 15:57:22 +0000",
    "user" : {
      "name" : "Nathaniel A Conroy",
      "screen_name" : "ConroyNathaniel",
      "protected" : false,
      "id_str" : "3328524183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610652344586338304\/9wquvJKY_normal.png",
      "id" : 3328524183,
      "verified" : false
    }
  },
  "id" : 764901394373484544,
  "created_at" : "2016-08-14 19:07:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leisa Reichelt",
      "screen_name" : "leisa",
      "indices" : [ 3, 9 ],
      "id_str" : "34663",
      "id" : 34663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764897350238167040",
  "text" : "RT @leisa: Co-design is often presented as a panacea to user\/citizen engagement. Trick is to understand it is a research tool, not a design\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763265618564919296",
    "text" : "Co-design is often presented as a panacea to user\/citizen engagement. Trick is to understand it is a research tool, not a design approach.",
    "id" : 763265618564919296,
    "created_at" : "2016-08-10 06:47:58 +0000",
    "user" : {
      "name" : "Leisa Reichelt",
      "screen_name" : "leisa",
      "protected" : false,
      "id_str" : "34663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468392909817921537\/b7wBJttj_normal.jpeg",
      "id" : 34663,
      "verified" : false
    }
  },
  "id" : 764897350238167040,
  "created_at" : "2016-08-14 18:51:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/XuDCMb3j7V",
      "expanded_url" : "https:\/\/guides.instructure.com\/m\/4152\/l\/232976-how-do-i-create-rules-for-an-assignment-group",
      "display_url" : "guides.instructure.com\/m\/4152\/l\/23297\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764875676713312256",
  "text" : "I've been using #CanvasLMS for over 2 years and I just discovered that rules can be added to assignment weighting \uD83D\uDC4D https:\/\/t.co\/XuDCMb3j7V",
  "id" : 764875676713312256,
  "created_at" : "2016-08-14 17:25:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Academic Innovation",
      "screen_name" : "UMichiganAI",
      "indices" : [ 3, 15 ],
      "id_str" : "2828086644",
      "id" : 2828086644
    }, {
      "name" : "Colleen van Lent",
      "screen_name" : "ColleenAtUMSI",
      "indices" : [ 72, 86 ],
      "id_str" : "2839563582",
      "id" : 2839563582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/AfJdAVkntp",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=XVGlThHSXq4&index=3&list=PL5-TkQAfAZFY29RveoUL1TRTWnYu0SsrX",
      "display_url" : "youtube.com\/watch?v=XVGlTh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764643772902707200",
  "text" : "RT @UMichiganAI: \"Today you need to feel comfortable with technology\" - @ColleenAtUMSI on importance of learning #tech and coding https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Colleen van Lent",
        "screen_name" : "ColleenAtUMSI",
        "indices" : [ 55, 69 ],
        "id_str" : "2839563582",
        "id" : 2839563582
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tech",
        "indices" : [ 96, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/AfJdAVkntp",
        "expanded_url" : "http:\/\/youtube.com\/watch?v=XVGlThHSXq4&index=3&list=PL5-TkQAfAZFY29RveoUL1TRTWnYu0SsrX",
        "display_url" : "youtube.com\/watch?v=XVGlTh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764601218333282304",
    "text" : "\"Today you need to feel comfortable with technology\" - @ColleenAtUMSI on importance of learning #tech and coding https:\/\/t.co\/AfJdAVkntp",
    "id" : 764601218333282304,
    "created_at" : "2016-08-13 23:15:10 +0000",
    "user" : {
      "name" : "Academic Innovation",
      "screen_name" : "UMichiganAI",
      "protected" : false,
      "id_str" : "2828086644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765245074494124032\/QYx5w9Ow_normal.jpg",
      "id" : 2828086644,
      "verified" : false
    }
  },
  "id" : 764643772902707200,
  "created_at" : "2016-08-14 02:04:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Gibbs",
      "screen_name" : "OnlineCrsLady",
      "indices" : [ 0, 14 ],
      "id_str" : "7044082",
      "id" : 7044082
    }, {
      "name" : "Kevin Buck",
      "screen_name" : "kevinbuck9",
      "indices" : [ 15, 26 ],
      "id_str" : "13743022",
      "id" : 13743022
    }, {
      "name" : "OU CTE",
      "screen_name" : "teachOU",
      "indices" : [ 27, 35 ],
      "id_str" : "1006831573",
      "id" : 1006831573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764614030820515844",
  "geo" : { },
  "id_str" : "764616666240077824",
  "in_reply_to_user_id" : 7044082,
  "text" : "@OnlineCrsLady @kevinbuck9 @teachOU If you see something of interest happy to share anything helpful!",
  "id" : 764616666240077824,
  "in_reply_to_status_id" : 764614030820515844,
  "created_at" : "2016-08-14 00:16:33 +0000",
  "in_reply_to_screen_name" : "OnlineCrsLady",
  "in_reply_to_user_id_str" : "7044082",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Gibbs",
      "screen_name" : "OnlineCrsLady",
      "indices" : [ 0, 14 ],
      "id_str" : "7044082",
      "id" : 7044082
    }, {
      "name" : "Kevin Buck",
      "screen_name" : "kevinbuck9",
      "indices" : [ 15, 26 ],
      "id_str" : "13743022",
      "id" : 13743022
    }, {
      "name" : "OU CTE",
      "screen_name" : "teachOU",
      "indices" : [ 27, 35 ],
      "id_str" : "1006831573",
      "id" : 1006831573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/AS9HK5yGv1",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/20703",
      "display_url" : "canvas.sfu.ca\/courses\/20703"
    } ]
  },
  "in_reply_to_status_id_str" : "764614030820515844",
  "geo" : { },
  "id_str" : "764615468069953537",
  "in_reply_to_user_id" : 7044082,
  "text" : "@OnlineCrsLady @kevinbuck9 @teachOU \uD83D\uDE42  If it helps here is my WIP Canvas site plus Grav CMS course hub front-end https:\/\/t.co\/AS9HK5yGv1",
  "id" : 764615468069953537,
  "in_reply_to_status_id" : 764614030820515844,
  "created_at" : "2016-08-14 00:11:48 +0000",
  "in_reply_to_screen_name" : "OnlineCrsLady",
  "in_reply_to_user_id_str" : "7044082",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Gibbs",
      "screen_name" : "OnlineCrsLady",
      "indices" : [ 0, 14 ],
      "id_str" : "7044082",
      "id" : 7044082
    }, {
      "name" : "Kevin Buck",
      "screen_name" : "kevinbuck9",
      "indices" : [ 15, 26 ],
      "id_str" : "13743022",
      "id" : 13743022
    }, {
      "name" : "OU CTE",
      "screen_name" : "teachOU",
      "indices" : [ 27, 35 ],
      "id_str" : "1006831573",
      "id" : 1006831573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/hFUCPWhZgw",
      "expanded_url" : "https:\/\/community.canvaslms.com\/ideas\/3477",
      "display_url" : "community.canvaslms.com\/ideas\/3477"
    } ]
  },
  "in_reply_to_status_id_str" : "764605655172997121",
  "geo" : { },
  "id_str" : "764607844561715200",
  "in_reply_to_user_id" : 7044082,
  "text" : "@OnlineCrsLady @kevinbuck9 @teachOU I've not seen that ability myself, and it looks like it is a feature request... https:\/\/t.co\/hFUCPWhZgw",
  "id" : 764607844561715200,
  "in_reply_to_status_id" : 764605655172997121,
  "created_at" : "2016-08-13 23:41:30 +0000",
  "in_reply_to_screen_name" : "OnlineCrsLady",
  "in_reply_to_user_id_str" : "7044082",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764583754316730368",
  "text" : "Online learning environments should be open, collaborative and in the full control of participants. Oh, and multi-device friendly. And fast\uD83D\uDE80",
  "id" : 764583754316730368,
  "created_at" : "2016-08-13 22:05:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 15, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764564173443309568",
  "text" : "Most ambitious #SFU CMPT 363 yet?\n\u2713Student chosen FOSS UX project\n\u2713Student chosen UX essays\n\u2713Mid-way design critique\n\u2713Two peer review asgmts",
  "id" : 764564173443309568,
  "created_at" : "2016-08-13 20:47:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rhuk",
      "screen_name" : "rhuk",
      "indices" : [ 3, 8 ],
      "id_str" : "14436881",
      "id" : 14436881
    }, {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 69, 75 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/ViA9upFVGb",
      "expanded_url" : "http:\/\/www.wired.com\/2016\/08\/open-source-won-now\/",
      "display_url" : "wired.com\/2016\/08\/open-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764506232551936000",
  "text" : "RT @rhuk: Open Source Won. So, Now What? https:\/\/t.co\/ViA9upFVGb via @WIRED",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WIRED",
        "screen_name" : "WIRED",
        "indices" : [ 59, 65 ],
        "id_str" : "1344951",
        "id" : 1344951
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/ViA9upFVGb",
        "expanded_url" : "http:\/\/www.wired.com\/2016\/08\/open-source-won-now\/",
        "display_url" : "wired.com\/2016\/08\/open-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764501331864268800",
    "text" : "Open Source Won. So, Now What? https:\/\/t.co\/ViA9upFVGb via @WIRED",
    "id" : 764501331864268800,
    "created_at" : "2016-08-13 16:38:15 +0000",
    "user" : {
      "name" : "rhuk",
      "screen_name" : "rhuk",
      "protected" : false,
      "id_str" : "14436881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459132737320792064\/vPalYA0W_normal.jpeg",
      "id" : 14436881,
      "verified" : false
    }
  },
  "id" : 764506232551936000,
  "created_at" : "2016-08-13 16:57:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764506031879692288",
  "text" : "Online learning environments should be open, collaborative and in the full control of participants. Oh, and multi-device access is a given.",
  "id" : 764506031879692288,
  "created_at" : "2016-08-13 16:56:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Harrelson",
      "screen_name" : "DanHarrelson",
      "indices" : [ 3, 16 ],
      "id_str" : "4200301",
      "id" : 4200301
    }, {
      "name" : "Dan Brown",
      "screen_name" : "brownorama",
      "indices" : [ 73, 84 ],
      "id_str" : "1761051",
      "id" : 1761051
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DanHarrelson\/status\/764195896112414720\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/rs2DqXus1J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cpr4HYNWAAA_Qza.jpg",
      "id_str" : "764195892433911808",
      "id" : 764195892433911808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cpr4HYNWAAA_Qza.jpg",
      "sizes" : [ {
        "h" : 467,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/rs2DqXus1J"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/IJO4qNwmru",
      "expanded_url" : "https:\/\/medium.com\/eightshapes-llc\/how-to-play-surviving-design-projects-5cbe8ac6acd1#---0-130.9kte023ts",
      "display_url" : "medium.com\/eightshapes-ll\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764312130921254912",
  "text" : "RT @DanHarrelson: \u201CThe hardest part of design isn\u2019t doing the design\u2026\u201D\u200A\u2014\u200A@brownorama https:\/\/t.co\/IJO4qNwmru https:\/\/t.co\/rs2DqXus1J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/medium.com\" rel=\"nofollow\"\u003EMedium\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dan Brown",
        "screen_name" : "brownorama",
        "indices" : [ 55, 66 ],
        "id_str" : "1761051",
        "id" : 1761051
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DanHarrelson\/status\/764195896112414720\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/rs2DqXus1J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cpr4HYNWAAA_Qza.jpg",
        "id_str" : "764195892433911808",
        "id" : 764195892433911808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cpr4HYNWAAA_Qza.jpg",
        "sizes" : [ {
          "h" : 467,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/rs2DqXus1J"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/IJO4qNwmru",
        "expanded_url" : "https:\/\/medium.com\/eightshapes-llc\/how-to-play-surviving-design-projects-5cbe8ac6acd1#---0-130.9kte023ts",
        "display_url" : "medium.com\/eightshapes-ll\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764195896112414720",
    "text" : "\u201CThe hardest part of design isn\u2019t doing the design\u2026\u201D\u200A\u2014\u200A@brownorama https:\/\/t.co\/IJO4qNwmru https:\/\/t.co\/rs2DqXus1J",
    "id" : 764195896112414720,
    "created_at" : "2016-08-12 20:24:34 +0000",
    "user" : {
      "name" : "Dan Harrelson",
      "screen_name" : "DanHarrelson",
      "protected" : false,
      "id_str" : "4200301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3430557434\/29a1147c67e3a370b3afb2459ffc992f_normal.png",
      "id" : 4200301,
      "verified" : false
    }
  },
  "id" : 764312130921254912,
  "created_at" : "2016-08-13 04:06:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Lebson",
      "screen_name" : "CoryLebson",
      "indices" : [ 3, 14 ],
      "id_str" : "23367786",
      "id" : 23367786
    }, {
      "name" : "Smashing Magazine",
      "screen_name" : "smashingmag",
      "indices" : [ 28, 40 ],
      "id_str" : "15736190",
      "id" : 15736190
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 81, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/zUG2vXn3MT",
      "expanded_url" : "https:\/\/www.smashingmagazine.com\/2016\/08\/a-beginners-guide-to-progressive-web-apps\/",
      "display_url" : "smashingmagazine.com\/2016\/08\/a-begi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764194509026582528",
  "text" : "RT @CoryLebson: Interesting @smashingmag intro to progressive web apps &amp; why #UX can be better than either mobile web or app options https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Smashing Magazine",
        "screen_name" : "smashingmag",
        "indices" : [ 12, 24 ],
        "id_str" : "15736190",
        "id" : 15736190
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 65, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/zUG2vXn3MT",
        "expanded_url" : "https:\/\/www.smashingmagazine.com\/2016\/08\/a-beginners-guide-to-progressive-web-apps\/",
        "display_url" : "smashingmagazine.com\/2016\/08\/a-begi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764192144659800064",
    "text" : "Interesting @smashingmag intro to progressive web apps &amp; why #UX can be better than either mobile web or app options https:\/\/t.co\/zUG2vXn3MT",
    "id" : 764192144659800064,
    "created_at" : "2016-08-12 20:09:39 +0000",
    "user" : {
      "name" : "Cory Lebson",
      "screen_name" : "CoryLebson",
      "protected" : false,
      "id_str" : "23367786",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583701400854536192\/nxIMA4ji_normal.png",
      "id" : 23367786,
      "verified" : false
    }
  },
  "id" : 764194509026582528,
  "created_at" : "2016-08-12 20:19:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Travis",
      "screen_name" : "userfocus",
      "indices" : [ 3, 13 ],
      "id_str" : "16509110",
      "id" : 16509110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/z7y7bDmZ9m",
      "expanded_url" : "https:\/\/twitter.com\/myddelton\/status\/764069020362534912",
      "display_url" : "twitter.com\/myddelton\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764181872108724224",
  "text" : "RT @userfocus: I love a new user research technique: \"Paired phone interviewing\". https:\/\/t.co\/z7y7bDmZ9m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/z7y7bDmZ9m",
        "expanded_url" : "https:\/\/twitter.com\/myddelton\/status\/764069020362534912",
        "display_url" : "twitter.com\/myddelton\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764180810685710336",
    "text" : "I love a new user research technique: \"Paired phone interviewing\". https:\/\/t.co\/z7y7bDmZ9m",
    "id" : 764180810685710336,
    "created_at" : "2016-08-12 19:24:37 +0000",
    "user" : {
      "name" : "David Travis",
      "screen_name" : "userfocus",
      "protected" : false,
      "id_str" : "16509110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748776721\/Userfocus_blurry_o_normal.png",
      "id" : 16509110,
      "verified" : false
    }
  },
  "id" : 764181872108724224,
  "created_at" : "2016-08-12 19:28:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/Vk0zUiX9Z9",
      "expanded_url" : "https:\/\/getgrav.org\/downloads",
      "display_url" : "getgrav.org\/downloads"
    } ]
  },
  "geo" : { },
  "id_str" : "763885503393337345",
  "text" : "RT @getgrav: Grav 1.1.2 and Admin Plugin 1.1.3 released! https:\/\/t.co\/Vk0zUiX9Z9 -&gt; Bug fixes, improvements, News Feed + Notifications dash\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/Vk0zUiX9Z9",
        "expanded_url" : "https:\/\/getgrav.org\/downloads",
        "display_url" : "getgrav.org\/downloads"
      } ]
    },
    "geo" : { },
    "id_str" : "763855645023928320",
    "text" : "Grav 1.1.2 and Admin Plugin 1.1.3 released! https:\/\/t.co\/Vk0zUiX9Z9 -&gt; Bug fixes, improvements, News Feed + Notifications dashboard widgets",
    "id" : 763855645023928320,
    "created_at" : "2016-08-11 21:52:32 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 763885503393337345,
  "created_at" : "2016-08-11 23:51:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InVision",
      "screen_name" : "InVisionApp",
      "indices" : [ 3, 15 ],
      "id_str" : "256093789",
      "id" : 256093789
    }, {
      "name" : "Magyon, Inc.",
      "screen_name" : "MagyonHQ",
      "indices" : [ 35, 44 ],
      "id_str" : "2479193844",
      "id" : 2479193844
    }, {
      "name" : "UX Mastery",
      "screen_name" : "uxmastery",
      "indices" : [ 48, 58 ],
      "id_str" : "631741925",
      "id" : 631741925
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/InVisionApp\/status\/763777256158326784\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/q9O8gFyqO0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cpl7XZXXgAAOyDA.jpg",
      "id_str" : "763777253692112896",
      "id" : 763777253692112896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cpl7XZXXgAAOyDA.jpg",
      "sizes" : [ {
        "h" : 716,
        "resize" : "fit",
        "w" : 1074
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 1074
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 1074
      } ],
      "display_url" : "pic.twitter.com\/q9O8gFyqO0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/FAzXnCPluO",
      "expanded_url" : "http:\/\/bit.ly\/2aJMDxT",
      "display_url" : "bit.ly\/2aJMDxT"
    } ]
  },
  "geo" : { },
  "id_str" : "763854863260196864",
  "text" : "RT @InVisionApp: Fantastic read by @MagyonHQ on @uxmastery\u2014The difference between good and great designers https:\/\/t.co\/FAzXnCPluO https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Magyon, Inc.",
        "screen_name" : "MagyonHQ",
        "indices" : [ 18, 27 ],
        "id_str" : "2479193844",
        "id" : 2479193844
      }, {
        "name" : "UX Mastery",
        "screen_name" : "uxmastery",
        "indices" : [ 31, 41 ],
        "id_str" : "631741925",
        "id" : 631741925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/InVisionApp\/status\/763777256158326784\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/q9O8gFyqO0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cpl7XZXXgAAOyDA.jpg",
        "id_str" : "763777253692112896",
        "id" : 763777253692112896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cpl7XZXXgAAOyDA.jpg",
        "sizes" : [ {
          "h" : 716,
          "resize" : "fit",
          "w" : 1074
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 1074
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 1074
        } ],
        "display_url" : "pic.twitter.com\/q9O8gFyqO0"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/FAzXnCPluO",
        "expanded_url" : "http:\/\/bit.ly\/2aJMDxT",
        "display_url" : "bit.ly\/2aJMDxT"
      } ]
    },
    "geo" : { },
    "id_str" : "763777256158326784",
    "text" : "Fantastic read by @MagyonHQ on @uxmastery\u2014The difference between good and great designers https:\/\/t.co\/FAzXnCPluO https:\/\/t.co\/q9O8gFyqO0",
    "id" : 763777256158326784,
    "created_at" : "2016-08-11 16:41:02 +0000",
    "user" : {
      "name" : "InVision",
      "screen_name" : "InVisionApp",
      "protected" : false,
      "id_str" : "256093789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593893225045200896\/r9uL4jWU_normal.png",
      "id" : 256093789,
      "verified" : false
    }
  },
  "id" : 763854863260196864,
  "created_at" : "2016-08-11 21:49:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 0, 14 ],
      "id_str" : "41268670",
      "id" : 41268670
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 15, 22 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763820025434234880",
  "geo" : { },
  "id_str" : "763821977593262080",
  "in_reply_to_user_id" : 41268670,
  "text" : "@_mike_collins @btopro But most often utilize a new Browser tab.",
  "id" : 763821977593262080,
  "in_reply_to_status_id" : 763820025434234880,
  "created_at" : "2016-08-11 19:38:45 +0000",
  "in_reply_to_screen_name" : "_mike_collins",
  "in_reply_to_user_id_str" : "41268670",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 0, 14 ],
      "id_str" : "41268670",
      "id" : 41268670
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 15, 22 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 28, 36 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763820025434234880",
  "geo" : { },
  "id_str" : "763821200787185665",
  "in_reply_to_user_id" : 41268670,
  "text" : "@_mike_collins @btopro With @getgrav I can avoid typical poor iFrame behavior by embedding JavaScript script objects \u263A",
  "id" : 763821200787185665,
  "in_reply_to_status_id" : 763820025434234880,
  "created_at" : "2016-08-11 19:35:40 +0000",
  "in_reply_to_screen_name" : "_mike_collins",
  "in_reply_to_user_id_str" : "41268670",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763808563475189760",
  "geo" : { },
  "id_str" : "763819411299983360",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro More info?",
  "id" : 763819411299983360,
  "in_reply_to_status_id" : 763808563475189760,
  "created_at" : "2016-08-11 19:28:33 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catriona Shedd",
      "screen_name" : "inspireUX",
      "indices" : [ 3, 13 ],
      "id_str" : "15325945",
      "id" : 15325945
    }, {
      "name" : "Jesse James Garrett",
      "screen_name" : "jjg",
      "indices" : [ 109, 113 ],
      "id_str" : "757664",
      "id" : 757664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uxweek16",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/UlmYbfAIUQ",
      "expanded_url" : "https:\/\/medium.com\/iq-design\/an-interview-with-jesse-james-garrett-3258a91e9cc#.w9kkpo7pb",
      "display_url" : "medium.com\/iq-design\/an-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763797137255567361",
  "text" : "RT @inspireUX: \u201CWe are all collectively more empowered than we ever have been in the history of the field\u201D - @jjg https:\/\/t.co\/UlmYbfAIUQ #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jesse James Garrett",
        "screen_name" : "jjg",
        "indices" : [ 94, 98 ],
        "id_str" : "757664",
        "id" : 757664
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "uxweek16",
        "indices" : [ 123, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/UlmYbfAIUQ",
        "expanded_url" : "https:\/\/medium.com\/iq-design\/an-interview-with-jesse-james-garrett-3258a91e9cc#.w9kkpo7pb",
        "display_url" : "medium.com\/iq-design\/an-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763794697189924864",
    "text" : "\u201CWe are all collectively more empowered than we ever have been in the history of the field\u201D - @jjg https:\/\/t.co\/UlmYbfAIUQ #uxweek16",
    "id" : 763794697189924864,
    "created_at" : "2016-08-11 17:50:21 +0000",
    "user" : {
      "name" : "Catriona Shedd",
      "screen_name" : "inspireUX",
      "protected" : false,
      "id_str" : "15325945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3583107610\/22970983042e614f78fd022359b9c453_normal.jpeg",
      "id" : 15325945,
      "verified" : false
    }
  },
  "id" : 763797137255567361,
  "created_at" : "2016-08-11 18:00:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 3, 19 ],
      "id_str" : "17462723",
      "id" : 17462723
    }, {
      "name" : "Unsplash",
      "screen_name" : "unsplash",
      "indices" : [ 54, 63 ],
      "id_str" : "1520228526",
      "id" : 1520228526
    }, {
      "name" : "Naeema",
      "screen_name" : "Naeema",
      "indices" : [ 69, 76 ],
      "id_str" : "14359586",
      "id" : 14359586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/guBgdHQMDo",
      "expanded_url" : "https:\/\/twitter.com\/Naeema\/status\/763778479787745280",
      "display_url" : "twitter.com\/Naeema\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763794271145111553",
  "text" : "RT @creativecommons: Fantastic article on our friends @unsplash! h\/t @Naeema  https:\/\/t.co\/guBgdHQMDo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Unsplash",
        "screen_name" : "unsplash",
        "indices" : [ 33, 42 ],
        "id_str" : "1520228526",
        "id" : 1520228526
      }, {
        "name" : "Naeema",
        "screen_name" : "Naeema",
        "indices" : [ 48, 55 ],
        "id_str" : "14359586",
        "id" : 14359586
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/guBgdHQMDo",
        "expanded_url" : "https:\/\/twitter.com\/Naeema\/status\/763778479787745280",
        "display_url" : "twitter.com\/Naeema\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763789132397096960",
    "text" : "Fantastic article on our friends @unsplash! h\/t @Naeema  https:\/\/t.co\/guBgdHQMDo",
    "id" : 763789132397096960,
    "created_at" : "2016-08-11 17:28:14 +0000",
    "user" : {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "protected" : false,
      "id_str" : "17462723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525970164341153792\/vbReKnbf_normal.png",
      "id" : 17462723,
      "verified" : true
    }
  },
  "id" : 763794271145111553,
  "created_at" : "2016-08-11 17:48:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Appert",
      "screen_name" : "Lucyappert",
      "indices" : [ 3, 14 ],
      "id_str" : "153617129",
      "id" : 153617129
    }, {
      "name" : "Apereo Foundation",
      "screen_name" : "ApereoOrg",
      "indices" : [ 104, 114 ],
      "id_str" : "1117619618",
      "id" : 1117619618
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opensource",
      "indices" : [ 56, 67 ]
    }, {
      "text" : "edtech",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/CRzb9WBbMw",
      "expanded_url" : "https:\/\/twitter.com\/drchuck\/status\/763551459258556416",
      "display_url" : "twitter.com\/drchuck\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763788285223194624",
  "text" : "RT @Lucyappert: So excited to see dev happening on this #opensource next-generation #edtech tool model! @ApereoOrg  https:\/\/t.co\/CRzb9WBbMw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Apereo Foundation",
        "screen_name" : "ApereoOrg",
        "indices" : [ 88, 98 ],
        "id_str" : "1117619618",
        "id" : 1117619618
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opensource",
        "indices" : [ 40, 51 ]
      }, {
        "text" : "edtech",
        "indices" : [ 68, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/CRzb9WBbMw",
        "expanded_url" : "https:\/\/twitter.com\/drchuck\/status\/763551459258556416",
        "display_url" : "twitter.com\/drchuck\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763690408132091904",
    "text" : "So excited to see dev happening on this #opensource next-generation #edtech tool model! @ApereoOrg  https:\/\/t.co\/CRzb9WBbMw",
    "id" : 763690408132091904,
    "created_at" : "2016-08-11 10:55:56 +0000",
    "user" : {
      "name" : "Lucy Appert",
      "screen_name" : "Lucyappert",
      "protected" : false,
      "id_str" : "153617129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000727595709\/fe3b8fbb3cd6df497f752056dde39207_normal.jpeg",
      "id" : 153617129,
      "verified" : false
    }
  },
  "id" : 763788285223194624,
  "created_at" : "2016-08-11 17:24:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Blickensderfer",
      "screen_name" : "Dan_Blick",
      "indices" : [ 3, 13 ],
      "id_str" : "188554158",
      "id" : 188554158
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 62, 77 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 106, 121 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 122, 134 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "VersionPress",
      "screen_name" : "versionpress",
      "indices" : [ 135, 140 ],
      "id_str" : "2343545670",
      "id" : 2343545670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/8kdYQKicFr",
      "expanded_url" : "https:\/\/twitter.com\/dan_blick\/status\/750731440502018050",
      "display_url" : "twitter.com\/dan_blick\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763438699015045120",
  "text" : "RT @Dan_Blick: Had a great tweet exchange about this recently @ReclaimHosting: https:\/\/t.co\/8kdYQKicFr cc @hibbittsdesign @billymeinke @ver\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reclaim Hosting",
        "screen_name" : "ReclaimHosting",
        "indices" : [ 47, 62 ],
        "id_str" : "1602053274",
        "id" : 1602053274
      }, {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 91, 106 ],
        "id_str" : "15949844",
        "id" : 15949844
      }, {
        "name" : "Bi\u1ECA\u1ECAy Meinke",
        "screen_name" : "billymeinke",
        "indices" : [ 107, 119 ],
        "id_str" : "296003222",
        "id" : 296003222
      }, {
        "name" : "VersionPress",
        "screen_name" : "versionpress",
        "indices" : [ 120, 133 ],
        "id_str" : "2343545670",
        "id" : 2343545670
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/8kdYQKicFr",
        "expanded_url" : "https:\/\/twitter.com\/dan_blick\/status\/750731440502018050",
        "display_url" : "twitter.com\/dan_blick\/stat\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "763424582158184449",
    "geo" : { },
    "id_str" : "763435468990087168",
    "in_reply_to_user_id" : 1602053274,
    "text" : "Had a great tweet exchange about this recently @ReclaimHosting: https:\/\/t.co\/8kdYQKicFr cc @hibbittsdesign @billymeinke @versionpress",
    "id" : 763435468990087168,
    "in_reply_to_status_id" : 763424582158184449,
    "created_at" : "2016-08-10 18:02:54 +0000",
    "in_reply_to_screen_name" : "ReclaimHosting",
    "in_reply_to_user_id_str" : "1602053274",
    "user" : {
      "name" : "Dan Blickensderfer",
      "screen_name" : "Dan_Blick",
      "protected" : false,
      "id_str" : "188554158",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000638002183\/e6388b44edcc11c2dc7d525139192b23_normal.jpeg",
      "id" : 188554158,
      "verified" : false
    }
  },
  "id" : 763438699015045120,
  "created_at" : "2016-08-10 18:15:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "indices" : [ 3, 16 ],
      "id_str" : "1891806212",
      "id" : 1891806212
    }, {
      "name" : "Crazy Scientist, PhD",
      "screen_name" : "wandedob",
      "indices" : [ 53, 62 ],
      "id_str" : "253685928",
      "id" : 253685928
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AcademicsSay\/status\/762629852461670401\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/HjYlUF9870",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpVnzkKWgAAFEXw.jpg",
      "id_str" : "762629847487250432",
      "id" : 762629847487250432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpVnzkKWgAAFEXw.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 529
      } ],
      "display_url" : "pic.twitter.com\/HjYlUF9870"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763422516668878848",
  "text" : "RT @AcademicsSay: The Academic Olympics. Courtesy of @wandedob. https:\/\/t.co\/HjYlUF9870",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Crazy Scientist, PhD",
        "screen_name" : "wandedob",
        "indices" : [ 35, 44 ],
        "id_str" : "253685928",
        "id" : 253685928
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AcademicsSay\/status\/762629852461670401\/photo\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/HjYlUF9870",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpVnzkKWgAAFEXw.jpg",
        "id_str" : "762629847487250432",
        "id" : 762629847487250432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpVnzkKWgAAFEXw.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 529
        } ],
        "display_url" : "pic.twitter.com\/HjYlUF9870"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762629852461670401",
    "text" : "The Academic Olympics. Courtesy of @wandedob. https:\/\/t.co\/HjYlUF9870",
    "id" : 762629852461670401,
    "created_at" : "2016-08-08 12:41:40 +0000",
    "user" : {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "protected" : false,
      "id_str" : "1891806212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748151916836716546\/Ldn_dhiC_normal.jpg",
      "id" : 1891806212,
      "verified" : false
    }
  },
  "id" : 763422516668878848,
  "created_at" : "2016-08-10 17:11:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Groom",
      "screen_name" : "jimgroom",
      "indices" : [ 3, 12 ],
      "id_str" : "3362981",
      "id" : 3362981
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 62, 77 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 111, 119 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/VvhMX7Osoq",
      "expanded_url" : "https:\/\/community.reclaimhosting.com\/t\/grav-course-hub-installer-now-available\/146\/1",
      "display_url" : "community.reclaimhosting.com\/t\/grav-course-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763416632664305664",
  "text" : "RT @jimgroom: Interested in experimenting with flat file CMS? @hibbittsdesign provides a brilliant overview of @getgrav here: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 48, 63 ],
        "id_str" : "15949844",
        "id" : 15949844
      }, {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 97, 105 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/VvhMX7Osoq",
        "expanded_url" : "https:\/\/community.reclaimhosting.com\/t\/grav-course-hub-installer-now-available\/146\/1",
        "display_url" : "community.reclaimhosting.com\/t\/grav-course-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763304836477714432",
    "text" : "Interested in experimenting with flat file CMS? @hibbittsdesign provides a brilliant overview of @getgrav here: https:\/\/t.co\/VvhMX7Osoq",
    "id" : 763304836477714432,
    "created_at" : "2016-08-10 09:23:49 +0000",
    "user" : {
      "name" : "Jim Groom",
      "screen_name" : "jimgroom",
      "protected" : false,
      "id_str" : "3362981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626944793302581248\/TxzPTAYL_normal.jpg",
      "id" : 3362981,
      "verified" : false
    }
  },
  "id" : 763416632664305664,
  "created_at" : "2016-08-10 16:48:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rock Leung PhD",
      "screen_name" : "rockleung",
      "indices" : [ 3, 13 ],
      "id_str" : "257694380",
      "id" : 257694380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/ATcQetnyrQ",
      "expanded_url" : "http:\/\/radicalresearchsummit.com\/",
      "display_url" : "radicalresearchsummit.com"
    } ]
  },
  "geo" : { },
  "id_str" : "763086029087662080",
  "text" : "RT @rockleung: Calling all UX Researchers in the Vancouver area to a day-long event on Sept 30, 2016 that you'll want to come to: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/ATcQetnyrQ",
        "expanded_url" : "http:\/\/radicalresearchsummit.com\/",
        "display_url" : "radicalresearchsummit.com"
      } ]
    },
    "geo" : { },
    "id_str" : "763080109389647872",
    "text" : "Calling all UX Researchers in the Vancouver area to a day-long event on Sept 30, 2016 that you'll want to come to: https:\/\/t.co\/ATcQetnyrQ",
    "id" : 763080109389647872,
    "created_at" : "2016-08-09 18:30:50 +0000",
    "user" : {
      "name" : "Rock Leung PhD",
      "screen_name" : "rockleung",
      "protected" : false,
      "id_str" : "257694380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661236757103448064\/n7gr8y1e_normal.jpg",
      "id" : 257694380,
      "verified" : false
    }
  },
  "id" : 763086029087662080,
  "created_at" : "2016-08-09 18:54:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 3, 15 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "co",
      "indices" : [ 43, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/L4KIkGqpTm",
      "expanded_url" : "http:\/\/ow.ly\/QIq03034yE8",
      "display_url" : "ow.ly\/QIq03034yE8"
    } ]
  },
  "geo" : { },
  "id_str" : "763044327710863360",
  "text" : "RT @openroadies: What does it take to do a #co-op at OpenRoad? Find out from our intern, Charles Shin: https:\/\/t.co\/L4KIkGqpTm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "co",
        "indices" : [ 26, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/L4KIkGqpTm",
        "expanded_url" : "http:\/\/ow.ly\/QIq03034yE8",
        "display_url" : "ow.ly\/QIq03034yE8"
      } ]
    },
    "geo" : { },
    "id_str" : "763042308505862146",
    "text" : "What does it take to do a #co-op at OpenRoad? Find out from our intern, Charles Shin: https:\/\/t.co\/L4KIkGqpTm",
    "id" : 763042308505862146,
    "created_at" : "2016-08-09 16:00:37 +0000",
    "user" : {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "protected" : false,
      "id_str" : "66913866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554783440747237376\/HA2Svg4h_normal.png",
      "id" : 66913866,
      "verified" : false
    }
  },
  "id" : 763044327710863360,
  "created_at" : "2016-08-09 16:08:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762741567044067328",
  "geo" : { },
  "id_str" : "762746869701152768",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro I enjoyed working with that Framework - built my first Grav course site with a theme based on it \u263A",
  "id" : 762746869701152768,
  "in_reply_to_status_id" : 762741567044067328,
  "created_at" : "2016-08-08 20:26:39 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Skvorc",
      "screen_name" : "bitfalls",
      "indices" : [ 3, 12 ],
      "id_str" : "125083073",
      "id" : 125083073
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 55, 63 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Varnish Cache",
      "screen_name" : "varnishcache",
      "indices" : [ 99, 112 ],
      "id_str" : "93152968",
      "id" : 93152968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/1tlRMnqRiD",
      "expanded_url" : "http:\/\/bit.ly\/2aGO8Q0",
      "display_url" : "bit.ly\/2aGO8Q0"
    } ]
  },
  "geo" : { },
  "id_str" : "762731008085020672",
  "text" : "RT @bitfalls: Having been able to spend more time with @getgrav, here\u2019s 6 more tweaks, including a @varnishcache boost! https:\/\/t.co\/1tlRMn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 41, 49 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      }, {
        "name" : "Varnish Cache",
        "screen_name" : "varnishcache",
        "indices" : [ 85, 98 ],
        "id_str" : "93152968",
        "id" : 93152968
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/1tlRMnqRiD",
        "expanded_url" : "http:\/\/bit.ly\/2aGO8Q0",
        "display_url" : "bit.ly\/2aGO8Q0"
      } ]
    },
    "geo" : { },
    "id_str" : "762688399438385152",
    "text" : "Having been able to spend more time with @getgrav, here\u2019s 6 more tweaks, including a @varnishcache boost! https:\/\/t.co\/1tlRMnqRiD",
    "id" : 762688399438385152,
    "created_at" : "2016-08-08 16:34:19 +0000",
    "user" : {
      "name" : "Bruno Skvorc",
      "screen_name" : "bitfalls",
      "protected" : false,
      "id_str" : "125083073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605035701088821249\/PfWRyYat_normal.jpg",
      "id" : 125083073,
      "verified" : false
    }
  },
  "id" : 762731008085020672,
  "created_at" : "2016-08-08 19:23:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstsevenjobs",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762055294943801344",
  "text" : "#firstsevenjobs\nNewspaper route\nApple Computer dealership\nDB developer\nHyperCard developer\nFreelance Mac developer\nTeacher\nUI designer",
  "id" : 762055294943801344,
  "created_at" : "2016-08-06 22:38:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lori Bouzane",
      "screen_name" : "llbouzane",
      "indices" : [ 0, 10 ],
      "id_str" : "60199905",
      "id" : 60199905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761908149691506688",
  "geo" : { },
  "id_str" : "761952186947346432",
  "in_reply_to_user_id" : 60199905,
  "text" : "@llbouzane Hi Lori, I am not familiar with the Moodle Forest theme. The Snap theme supports a wide range of standard Moodle elements.",
  "id" : 761952186947346432,
  "in_reply_to_status_id" : 761908149691506688,
  "created_at" : "2016-08-06 15:48:52 +0000",
  "in_reply_to_screen_name" : "llbouzane",
  "in_reply_to_user_id_str" : "60199905",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 3, 18 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 48, 56 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 71, 86 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/YFp68vmMgM",
      "expanded_url" : "https:\/\/community.reclaimhosting.com\/t\/grav-course-hub-installer-now-available\/146",
      "display_url" : "community.reclaimhosting.com\/t\/grav-course-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761742066623717376",
  "text" : "RT @ReclaimHosting: A great introduction to the @getgrav Course Hub by @hibbittsdesign now available right within Reclaim Hosting! https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 28, 36 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      }, {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 51, 66 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/YFp68vmMgM",
        "expanded_url" : "https:\/\/community.reclaimhosting.com\/t\/grav-course-hub-installer-now-available\/146",
        "display_url" : "community.reclaimhosting.com\/t\/grav-course-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761741398102212609",
    "text" : "A great introduction to the @getgrav Course Hub by @hibbittsdesign now available right within Reclaim Hosting! https:\/\/t.co\/YFp68vmMgM",
    "id" : 761741398102212609,
    "created_at" : "2016-08-06 01:51:16 +0000",
    "user" : {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "protected" : false,
      "id_str" : "1602053274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710868507144167424\/Aj9k9RM2_normal.jpg",
      "id" : 1602053274,
      "verified" : false
    }
  },
  "id" : 761742066623717376,
  "created_at" : "2016-08-06 01:53:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761740399912292352",
  "geo" : { },
  "id_str" : "761741877422862336",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy Thanks, it will be a bit of a work-in-progress\uD83D\uDE42 Depending on interest, I could see a step-by-step guide specific to Reclaim too.",
  "id" : 761741877422862336,
  "in_reply_to_status_id" : 761740399912292352,
  "created_at" : "2016-08-06 01:53:10 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761736524958470145",
  "geo" : { },
  "id_str" : "761739928984137728",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy Awesome, thanks! When convenient, please take a peek and let me know if this is the type of thing you had in mind \uD83D\uDE42",
  "id" : 761739928984137728,
  "in_reply_to_status_id" : 761736524958470145,
  "created_at" : "2016-08-06 01:45:26 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761718986438537216",
  "geo" : { },
  "id_str" : "761736183650983936",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy Thanks again for the offer to post about the Grav Course Hub\uD83D\uDE42 Looks like new users can only include 2 links, can you override?TY",
  "id" : 761736183650983936,
  "in_reply_to_status_id" : 761718986438537216,
  "created_at" : "2016-08-06 01:30:33 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761718986438537216",
  "geo" : { },
  "id_str" : "761722524782632960",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy I'll put together a draft post and share a preview with you for feedback \u263A",
  "id" : 761722524782632960,
  "in_reply_to_status_id" : 761718986438537216,
  "created_at" : "2016-08-06 00:36:16 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 4, 12 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/761693253691330565\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/67KxDxUnVV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpISCHzUIAARwAx.jpg",
      "id_str" : "761691114642350080",
      "id" : 761691114642350080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpISCHzUIAARwAx.jpg",
      "sizes" : [ {
        "h" : 557,
        "resize" : "fit",
        "w" : 1176
      }, {
        "h" : 557,
        "resize" : "fit",
        "w" : 1176
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 557,
        "resize" : "fit",
        "w" : 1176
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/67KxDxUnVV"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/761693253691330565\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/67KxDxUnVV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpITFoJUkAASweE.jpg",
      "id_str" : "761692274375823360",
      "id" : 761692274375823360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpITFoJUkAASweE.jpg",
      "sizes" : [ {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1009
      } ],
      "display_url" : "pic.twitter.com\/67KxDxUnVV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761693253691330565",
  "text" : "The @getgrav Course Hub project is now 5 months old, and this commit graph reflects improvements for the Fall term.\uD83D\uDE4C https:\/\/t.co\/67KxDxUnVV",
  "id" : 761693253691330565,
  "created_at" : "2016-08-05 22:39:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SitePoint PHP",
      "screen_name" : "SitePointPHP",
      "indices" : [ 3, 16 ],
      "id_str" : "360392942",
      "id" : 360392942
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 30, 38 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SitePointPHP\/status\/761625565329821696\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/vwlqlkUmoD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpHWaYLW8AASzEx.png",
      "id_str" : "761625560657358848",
      "id" : 761625560657358848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpHWaYLW8AASzEx.png",
      "sizes" : [ {
        "h" : 186,
        "resize" : "fit",
        "w" : 671
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 671
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 671
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 671
      } ],
      "display_url" : "pic.twitter.com\/vwlqlkUmoD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/UdXfACQwD4",
      "expanded_url" : "http:\/\/bit.ly\/2azC7bP",
      "display_url" : "bit.ly\/2azC7bP"
    } ]
  },
  "geo" : { },
  "id_str" : "761628619223339008",
  "text" : "RT @SitePointPHP: 8 Must-have @getgrav plugins to round off your personal development blog\u2019s installation: https:\/\/t.co\/UdXfACQwD4 https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 12, 20 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SitePointPHP\/status\/761625565329821696\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/vwlqlkUmoD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpHWaYLW8AASzEx.png",
        "id_str" : "761625560657358848",
        "id" : 761625560657358848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpHWaYLW8AASzEx.png",
        "sizes" : [ {
          "h" : 186,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 186,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 186,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 186,
          "resize" : "fit",
          "w" : 671
        } ],
        "display_url" : "pic.twitter.com\/vwlqlkUmoD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/UdXfACQwD4",
        "expanded_url" : "http:\/\/bit.ly\/2azC7bP",
        "display_url" : "bit.ly\/2azC7bP"
      } ]
    },
    "geo" : { },
    "id_str" : "761625565329821696",
    "text" : "8 Must-have @getgrav plugins to round off your personal development blog\u2019s installation: https:\/\/t.co\/UdXfACQwD4 https:\/\/t.co\/vwlqlkUmoD",
    "id" : 761625565329821696,
    "created_at" : "2016-08-05 18:10:59 +0000",
    "user" : {
      "name" : "SitePoint PHP",
      "screen_name" : "SitePointPHP",
      "protected" : false,
      "id_str" : "360392942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000277266034\/584125b37807b5ca1eff1528acfd8bc4_normal.png",
      "id" : 360392942,
      "verified" : false
    }
  },
  "id" : 761628619223339008,
  "created_at" : "2016-08-05 18:23:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "will engle",
      "screen_name" : "infology",
      "indices" : [ 3, 12 ],
      "id_str" : "93031146",
      "id" : 93031146
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UBC",
      "indices" : [ 27, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 147, 148 ],
      "url" : "https:\/\/t.co\/Aij4bVEbyo",
      "expanded_url" : "http:\/\/open.ubc.ca",
      "display_url" : "open.ubc.ca"
    } ]
  },
  "geo" : { },
  "id_str" : "761612613272805376",
  "text" : "RT @infology: The new Open #UBC site is great! Resources for faculty &amp; students about the why, what, &amp; how of open ed practices https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UBC",
        "indices" : [ 13, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 145 ],
        "url" : "https:\/\/t.co\/Aij4bVEbyo",
        "expanded_url" : "http:\/\/open.ubc.ca",
        "display_url" : "open.ubc.ca"
      } ]
    },
    "geo" : { },
    "id_str" : "761609999206322176",
    "text" : "The new Open #UBC site is great! Resources for faculty &amp; students about the why, what, &amp; how of open ed practices https:\/\/t.co\/Aij4bVEbyo",
    "id" : 761609999206322176,
    "created_at" : "2016-08-05 17:09:08 +0000",
    "user" : {
      "name" : "will engle",
      "screen_name" : "infology",
      "protected" : false,
      "id_str" : "93031146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1598136377\/icon_normal.jpg",
      "id" : 93031146,
      "verified" : false
    }
  },
  "id" : 761612613272805376,
  "created_at" : "2016-08-05 17:19:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 0, 11 ],
      "id_str" : "91634720",
      "id" : 91634720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761611257434832897",
  "geo" : { },
  "id_str" : "761612389464756224",
  "in_reply_to_user_id" : 91634720,
  "text" : "@kenjeffery Longest time I've gone w\/o upgrading (MacBook Air), because frankly Apple has yet to produce something worthy of upgrading to.",
  "id" : 761612389464756224,
  "in_reply_to_status_id" : 761611257434832897,
  "created_at" : "2016-08-05 17:18:38 +0000",
  "in_reply_to_screen_name" : "kenjeffery",
  "in_reply_to_user_id_str" : "91634720",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/7RpXTYvd3u",
      "expanded_url" : "https:\/\/twitter.com\/humanfactors\/status\/761610315402506241",
      "display_url" : "twitter.com\/humanfactors\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761610892400177152",
  "text" : "For me, it was when the Apple Newton was not just cool but the future \uD83D\uDE42 https:\/\/t.co\/7RpXTYvd3u",
  "id" : 761610892400177152,
  "created_at" : "2016-08-05 17:12:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 22, 30 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LMS",
      "indices" : [ 74, 78 ]
    }, {
      "text" : "GravEdu",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/QFNLDeMCfb",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-07-29-introducing-grav-course-hub-for-mac",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761607232534433792",
  "text" : "New Post: Introducing @getgrav Course Hub for Mac https:\/\/t.co\/QFNLDeMCfb #LMS #GravEdu",
  "id" : 761607232534433792,
  "created_at" : "2016-08-05 16:58:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/761357037921894401\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/iXq7Gw0YW7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpDh7fsVYAA_stL.jpg",
      "id_str" : "761356749261594624",
      "id" : 761356749261594624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpDh7fsVYAA_stL.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com\/iXq7Gw0YW7"
    } ],
    "hashtags" : [ {
      "text" : "UI",
      "indices" : [ 68, 71 ]
    }, {
      "text" : "SFU",
      "indices" : [ 88, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/QCOrLOLKxf",
      "expanded_url" : "https:\/\/workflowy.com\/s\/0UvwffTinC",
      "display_url" : "workflowy.com\/s\/0UvwffTinC"
    } ]
  },
  "geo" : { },
  "id_str" : "761357037921894401",
  "text" : "A few more tweaks to the 'topics as questions' outline for CMPT 363 #UI Design course @ #SFU https:\/\/t.co\/QCOrLOLKxf https:\/\/t.co\/iXq7Gw0YW7",
  "id" : 761357037921894401,
  "created_at" : "2016-08-05 00:23:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/761338144817975296\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/vWtpn4soAb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpDQuMsUsAAUteu.jpg",
      "id_str" : "761337829125304320",
      "id" : 761337829125304320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpDQuMsUsAAUteu.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 4096,
        "resize" : "fit",
        "w" : 2304
      } ],
      "display_url" : "pic.twitter.com\/vWtpn4soAb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760320896603074560",
  "geo" : { },
  "id_str" : "761338144817975296",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters Always inspired by you and your work. I've just got this little gem for my next summer reading: https:\/\/t.co\/vWtpn4soAb",
  "id" : 761338144817975296,
  "in_reply_to_status_id" : 760320896603074560,
  "created_at" : "2016-08-04 23:08:53 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761307980725833728",
  "geo" : { },
  "id_str" : "761308522118127617",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Thanks! I've never found a good remote tool for journey map creation, but this looks quite promising \uD83D\uDE42",
  "id" : 761308522118127617,
  "in_reply_to_status_id" : 761307980725833728,
  "created_at" : "2016-08-04 21:11:10 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761297986588585984",
  "geo" : { },
  "id_str" : "761303106336333824",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Looks pretty useful - looking forward to hearing your thoughts after you've used it more extensively!",
  "id" : 761303106336333824,
  "in_reply_to_status_id" : 761297986588585984,
  "created_at" : "2016-08-04 20:49:39 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Blickensderfer",
      "screen_name" : "Dan_Blick",
      "indices" : [ 3, 13 ],
      "id_str" : "188554158",
      "id" : 188554158
    }, {
      "name" : "George",
      "screen_name" : "georgekroner",
      "indices" : [ 136, 140 ],
      "id_str" : "9128102",
      "id" : 9128102
    }, {
      "name" : "Ford Motor Company",
      "screen_name" : "Ford",
      "indices" : [ 139, 140 ],
      "id_str" : "15676492",
      "id" : 15676492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/61A0EUZjCE",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/josephsteinberg\/2015\/05\/12\/vulnerability-in-car-keyless-entry-systems-allows-anyone-to-open-and-steal-your-car\/#46283e384b7c",
      "display_url" : "forbes.com\/sites\/josephst\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761264008355655681",
  "text" : "RT @Dan_Blick: In an outdoor retail shop I saw small Faraday bags for sale. I did not understand why until now. https:\/\/t.co\/61A0EUZjCE @ge\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George",
        "screen_name" : "georgekroner",
        "indices" : [ 121, 134 ],
        "id_str" : "9128102",
        "id" : 9128102
      }, {
        "name" : "Ford Motor Company",
        "screen_name" : "Ford",
        "indices" : [ 135, 140 ],
        "id_str" : "15676492",
        "id" : 15676492
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/61A0EUZjCE",
        "expanded_url" : "http:\/\/www.forbes.com\/sites\/josephsteinberg\/2015\/05\/12\/vulnerability-in-car-keyless-entry-systems-allows-anyone-to-open-and-steal-your-car\/#46283e384b7c",
        "display_url" : "forbes.com\/sites\/josephst\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "761259549332471808",
    "geo" : { },
    "id_str" : "761262101717454848",
    "in_reply_to_user_id" : 9128102,
    "text" : "In an outdoor retail shop I saw small Faraday bags for sale. I did not understand why until now. https:\/\/t.co\/61A0EUZjCE @georgekroner @Ford",
    "id" : 761262101717454848,
    "in_reply_to_status_id" : 761259549332471808,
    "created_at" : "2016-08-04 18:06:43 +0000",
    "in_reply_to_screen_name" : "georgekroner",
    "in_reply_to_user_id_str" : "9128102",
    "user" : {
      "name" : "Dan Blickensderfer",
      "screen_name" : "Dan_Blick",
      "protected" : false,
      "id_str" : "188554158",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000638002183\/e6388b44edcc11c2dc7d525139192b23_normal.jpeg",
      "id" : 188554158,
      "verified" : false
    }
  },
  "id" : 761264008355655681,
  "created_at" : "2016-08-04 18:14:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George",
      "screen_name" : "georgekroner",
      "indices" : [ 0, 13 ],
      "id_str" : "9128102",
      "id" : 9128102
    }, {
      "name" : "Ford Motor Company",
      "screen_name" : "Ford",
      "indices" : [ 111, 116 ],
      "id_str" : "15676492",
      "id" : 15676492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761259549332471808",
  "geo" : { },
  "id_str" : "761261209379147776",
  "in_reply_to_user_id" : 9128102,
  "text" : "@georgekroner I am so sorry to hear that George! Glad to hear she is safe but what an awful experience. I hope @Ford responds to this.",
  "id" : 761261209379147776,
  "in_reply_to_status_id" : 761259549332471808,
  "created_at" : "2016-08-04 18:03:10 +0000",
  "in_reply_to_screen_name" : "georgekroner",
  "in_reply_to_user_id_str" : "9128102",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 10, 18 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/QYEZCoTAvO",
      "expanded_url" : "http:\/\/hibbittsdesign.org",
      "display_url" : "hibbittsdesign.org"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/029P0jOYh5",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide#setting-up-a-course",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761259344738463744",
  "text" : "Thanks to @getgrav the Grav Course Hub guides @ https:\/\/t.co\/QYEZCoTAvO can now be collaboratively edited w. GitHub: https:\/\/t.co\/029P0jOYh5",
  "id" : 761259344738463744,
  "created_at" : "2016-08-04 17:55:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Aldrich",
      "screen_name" : "jma245",
      "indices" : [ 0, 7 ],
      "id_str" : "32696488",
      "id" : 32696488
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 87, 95 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/nQdDGWsXbg",
      "expanded_url" : "http:\/\/livecode.com",
      "display_url" : "livecode.com"
    } ]
  },
  "in_reply_to_status_id_str" : "760962238320553984",
  "geo" : { },
  "id_str" : "760963802867216385",
  "in_reply_to_user_id" : 32696488,
  "text" : "@jma245 How about you? I've kept an eye on https:\/\/t.co\/nQdDGWsXbg but it was Twig and @getgrav that got me back into 'scripting' mode \uD83D\uDE09",
  "id" : 760963802867216385,
  "in_reply_to_status_id" : 760962238320553984,
  "created_at" : "2016-08-03 22:21:23 +0000",
  "in_reply_to_screen_name" : "jma245",
  "in_reply_to_user_id_str" : "32696488",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Aldrich",
      "screen_name" : "jma245",
      "indices" : [ 0, 7 ],
      "id_str" : "32696488",
      "id" : 32696488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760961317918302208",
  "in_reply_to_user_id" : 32696488,
  "text" : "@jma245 You bet! Co-developed a HyperCard software product called Exploring Media 1989-90. First software job and it led to my love of UX \uD83D\uDE42",
  "id" : 760961317918302208,
  "created_at" : "2016-08-03 22:11:30 +0000",
  "in_reply_to_screen_name" : "jma245",
  "in_reply_to_user_id_str" : "32696488",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760948728400220160",
  "text" : "Just added a new resource to my CMPT 363 UX Techniques Guide in &lt; 30 seconds. As an instructor many times simple efficiency = delightful UX.",
  "id" : 760948728400220160,
  "created_at" : "2016-08-03 21:21:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 3, 7 ],
      "id_str" : "1063291",
      "id" : 1063291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/Asg6V5R7V2",
      "expanded_url" : "http:\/\/ow.ly\/GAaO302RiOZ",
      "display_url" : "ow.ly\/GAaO302RiOZ"
    } ]
  },
  "geo" : { },
  "id_str" : "760937623590363136",
  "text" : "RT @UIE: Questions to Ask Yourself When Reading About Design\nhttps:\/\/t.co\/Asg6V5R7V2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/Asg6V5R7V2",
        "expanded_url" : "http:\/\/ow.ly\/GAaO302RiOZ",
        "display_url" : "ow.ly\/GAaO302RiOZ"
      } ]
    },
    "geo" : { },
    "id_str" : "760935970464206853",
    "text" : "Questions to Ask Yourself When Reading About Design\nhttps:\/\/t.co\/Asg6V5R7V2",
    "id" : 760935970464206853,
    "created_at" : "2016-08-03 20:30:47 +0000",
    "user" : {
      "name" : "UIE",
      "screen_name" : "UIE",
      "protected" : false,
      "id_str" : "1063291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3759116326\/19308cfcdb0b831111d4ee3fc3e6232c_normal.jpeg",
      "id" : 1063291,
      "verified" : false
    }
  },
  "id" : 760937623590363136,
  "created_at" : "2016-08-03 20:37:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/L4vgd29InC",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760852121835085824",
  "text" : "Fall term starts in 5 weeks. Looking to move beyond your LMS? Flip it with the open &amp; collaborative Grav Course Hub: https:\/\/t.co\/L4vgd29InC",
  "id" : 760852121835085824,
  "created_at" : "2016-08-03 14:57:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760633298485776384",
  "text" : "Using questions to outline a course vs. topics also helps shift an instructor to more of a facilitator, and even more so to a co-learner.",
  "id" : 760633298485776384,
  "created_at" : "2016-08-03 00:28:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760632748327350272",
  "text" : "I am finding that using questions to outline a course vs. topics helps move things towards discussions and explorations vs. presentations.",
  "id" : 760632748327350272,
  "created_at" : "2016-08-03 00:25:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 9, 13 ]
    }, {
      "text" : "UX",
      "indices" : [ 100, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/QCOrLOLKxf",
      "expanded_url" : "https:\/\/workflowy.com\/s\/0UvwffTinC",
      "display_url" : "workflowy.com\/s\/0UvwffTinC"
    } ]
  },
  "geo" : { },
  "id_str" : "760553588779126785",
  "text" : "Updated: #SFU CMPT 363 course schedule as questions to support student participation on open source #UX projects: https:\/\/t.co\/QCOrLOLKxf",
  "id" : 760553588779126785,
  "created_at" : "2016-08-02 19:11:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Allen",
      "screen_name" : "PaulGAllen",
      "indices" : [ 3, 14 ],
      "id_str" : "24167314",
      "id" : 24167314
    }, {
      "name" : "LivingComputers",
      "screen_name" : "LivingComputers",
      "indices" : [ 43, 59 ],
      "id_str" : "488844086",
      "id" : 488844086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/ESbOXOhcUv",
      "expanded_url" : "https:\/\/medium.com\/@PaulGAllen\/xerox-alto-is-rebuilt-and-reconnected-by-the-living-computer-museum-e56a7e86be91#.7exzlwdbb",
      "display_url" : "medium.com\/@PaulGAllen\/xe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760547159062089728",
  "text" : "RT @PaulGAllen: Tech enthusiasts: Read how @LivingComputers revived a Xerox Alto &amp; created emulator to bring it to life on your PC https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LivingComputers",
        "screen_name" : "LivingComputers",
        "indices" : [ 27, 43 ],
        "id_str" : "488844086",
        "id" : 488844086
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/ESbOXOhcUv",
        "expanded_url" : "https:\/\/medium.com\/@PaulGAllen\/xerox-alto-is-rebuilt-and-reconnected-by-the-living-computer-museum-e56a7e86be91#.7exzlwdbb",
        "display_url" : "medium.com\/@PaulGAllen\/xe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760509454546644992",
    "text" : "Tech enthusiasts: Read how @LivingComputers revived a Xerox Alto &amp; created emulator to bring it to life on your PC https:\/\/t.co\/ESbOXOhcUv",
    "id" : 760509454546644992,
    "created_at" : "2016-08-02 16:15:58 +0000",
    "user" : {
      "name" : "Paul Allen",
      "screen_name" : "PaulGAllen",
      "protected" : false,
      "id_str" : "24167314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558434025954488320\/E4r4Rlc__normal.jpeg",
      "id" : 24167314,
      "verified" : true
    }
  },
  "id" : 760547159062089728,
  "created_at" : "2016-08-02 18:45:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logo Foundation",
      "screen_name" : "LogoFoundation",
      "indices" : [ 3, 18 ],
      "id_str" : "731177283889864704",
      "id" : 731177283889864704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760224088107339776",
  "text" : "RT @LogoFoundation: Sad to report that Seymour Papert died yesterday.He inspired people around the word to be joyful and creative learners\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760057041687830528",
    "text" : "Sad to report that Seymour Papert died yesterday.He inspired people around the word to be joyful and creative learners and teachers.",
    "id" : 760057041687830528,
    "created_at" : "2016-08-01 10:18:14 +0000",
    "user" : {
      "name" : "Logo Foundation",
      "screen_name" : "LogoFoundation",
      "protected" : false,
      "id_str" : "731177283889864704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731180149715144706\/G_mgpZe9_normal.jpg",
      "id" : 731177283889864704,
      "verified" : false
    }
  },
  "id" : 760224088107339776,
  "created_at" : "2016-08-01 21:22:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David J Bland",
      "screen_name" : "davidjbland",
      "indices" : [ 3, 15 ],
      "id_str" : "14409265",
      "id" : 14409265
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/davidjbland\/status\/725119174368976897\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/FTPg4KnFDT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChAkC92UgAAIKYQ.jpg",
      "id_str" : "725119173387386880",
      "id" : 725119173387386880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChAkC92UgAAIKYQ.jpg",
      "sizes" : [ {
        "h" : 349,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 595,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1174
      } ],
      "display_url" : "pic.twitter.com\/FTPg4KnFDT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760154770833145857",
  "text" : "RT @davidjbland: I've analyzed the Silicon Valley Bot Startup trend and created a handy venn diagram to help explain it. https:\/\/t.co\/FTPg4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/davidjbland\/status\/725119174368976897\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/FTPg4KnFDT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChAkC92UgAAIKYQ.jpg",
        "id_str" : "725119173387386880",
        "id" : 725119173387386880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChAkC92UgAAIKYQ.jpg",
        "sizes" : [ {
          "h" : 349,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 595,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1174
        } ],
        "display_url" : "pic.twitter.com\/FTPg4KnFDT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725119174368976897",
    "text" : "I've analyzed the Silicon Valley Bot Startup trend and created a handy venn diagram to help explain it. https:\/\/t.co\/FTPg4KnFDT",
    "id" : 725119174368976897,
    "created_at" : "2016-04-27 00:27:37 +0000",
    "user" : {
      "name" : "David J Bland",
      "screen_name" : "davidjbland",
      "protected" : false,
      "id_str" : "14409265",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755842954015547392\/v10U6DEy_normal.jpg",
      "id" : 14409265,
      "verified" : false
    }
  },
  "id" : 760154770833145857,
  "created_at" : "2016-08-01 16:46:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]