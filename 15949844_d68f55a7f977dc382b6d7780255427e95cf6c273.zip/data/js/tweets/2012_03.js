Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rosenfeld Media",
      "screen_name" : "RosenfeldMedia",
      "indices" : [ 3, 18 ],
      "id_str" : "22375745",
      "id" : 22375745
    }, {
      "name" : "Rachel Hinman",
      "screen_name" : "Hinman",
      "indices" : [ 78, 85 ],
      "id_str" : "1132421",
      "id" : 1132421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/XXnHcPTS",
      "expanded_url" : "http:\/\/bit.ly\/AdR0mw",
      "display_url" : "bit.ly\/AdR0mw"
    } ]
  },
  "geo" : { },
  "id_str" : "180389717613883392",
  "text" : "RT @RosenfeldMedia: The next Next Step virtual seminar (3\/27): Rachel Hinman (@hinman) on UX design in the Mobile Frontier: http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rachel Hinman",
        "screen_name" : "Hinman",
        "indices" : [ 58, 65 ],
        "id_str" : "1132421",
        "id" : 1132421
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/XXnHcPTS",
        "expanded_url" : "http:\/\/bit.ly\/AdR0mw",
        "display_url" : "bit.ly\/AdR0mw"
      } ]
    },
    "geo" : { },
    "id_str" : "180388403873980416",
    "text" : "The next Next Step virtual seminar (3\/27): Rachel Hinman (@hinman) on UX design in the Mobile Frontier: http:\/\/t.co\/XXnHcPTS",
    "id" : 180388403873980416,
    "created_at" : "2012-03-15 20:22:01 +0000",
    "user" : {
      "name" : "Rosenfeld Media",
      "screen_name" : "RosenfeldMedia",
      "protected" : false,
      "id_str" : "22375745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2555932285\/ockyeyj3920saqbohipq_normal.jpeg",
      "id" : 22375745,
      "verified" : false
    }
  },
  "id" : 180389717613883392,
  "created_at" : "2012-03-15 20:27:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180100856740458497",
  "geo" : { },
  "id_str" : "180311671254958080",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Yes, for occasional interactive prototypes that I need to build. Overtime the tool has become quite capable on the mobile side.",
  "id" : 180311671254958080,
  "in_reply_to_status_id" : 180100856740458497,
  "created_at" : "2012-03-15 15:17:07 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Ab2vuan1",
      "expanded_url" : "http:\/\/www.runrev.com\/products\/mobile-deployment\/overview\/",
      "display_url" : "runrev.com\/products\/mobil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180083861114466306",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Thanks for sharing your mobile learning app experiences! LiveCode Mobile might also be something of interest http:\/\/t.co\/Ab2vuan1",
  "id" : 180083861114466306,
  "created_at" : "2012-03-15 00:11:52 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 3, 10 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/TXAlL8hd",
      "expanded_url" : "http:\/\/bit.ly\/wliv9B",
      "display_url" : "bit.ly\/wliv9B"
    } ]
  },
  "geo" : { },
  "id_str" : "180082227701493760",
  "text" : "RT @tanbob: creating a mobile learning app...what we learned, what's left to learn http:\/\/t.co\/TXAlL8hd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/TXAlL8hd",
        "expanded_url" : "http:\/\/bit.ly\/wliv9B",
        "display_url" : "bit.ly\/wliv9B"
      } ]
    },
    "geo" : { },
    "id_str" : "179941657549094913",
    "text" : "creating a mobile learning app...what we learned, what's left to learn http:\/\/t.co\/TXAlL8hd",
    "id" : 179941657549094913,
    "created_at" : "2012-03-14 14:46:48 +0000",
    "user" : {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "protected" : false,
      "id_str" : "10817782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530559772\/twitterProfilePhoto_normal.jpg",
      "id" : 10817782,
      "verified" : false
    }
  },
  "id" : 180082227701493760,
  "created_at" : "2012-03-15 00:05:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Porter",
      "screen_name" : "dendroglyph",
      "indices" : [ 0, 12 ],
      "id_str" : "15170764",
      "id" : 15170764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179751078991118336",
  "geo" : { },
  "id_str" : "179959692238393344",
  "in_reply_to_user_id" : 15170764,
  "text" : "@dendroglyph Thanks very much, I really enjoyed the online learning showcase too. Thanks also for sharing that mLearning report!",
  "id" : 179959692238393344,
  "in_reply_to_status_id" : 179751078991118336,
  "created_at" : "2012-03-14 15:58:28 +0000",
  "in_reply_to_screen_name" : "dendroglyph",
  "in_reply_to_user_id_str" : "15170764",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Porter",
      "screen_name" : "dendroglyph",
      "indices" : [ 0, 12 ],
      "id_str" : "15170764",
      "id" : 15170764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179709408094330880",
  "in_reply_to_user_id" : 15170764,
  "text" : "@dendroglyph Thanks for the RT!",
  "id" : 179709408094330880,
  "created_at" : "2012-03-13 23:23:56 +0000",
  "in_reply_to_screen_name" : "dendroglyph",
  "in_reply_to_user_id_str" : "15170764",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Heasley",
      "screen_name" : "BmoreUX",
      "indices" : [ 0, 8 ],
      "id_str" : "16698194",
      "id" : 16698194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179672273542844416",
  "geo" : { },
  "id_str" : "179709293044568064",
  "in_reply_to_user_id" : 16698194,
  "text" : "@BmoreUX Thanks for the feedback, something more to think about...",
  "id" : 179709293044568064,
  "in_reply_to_status_id" : 179672273542844416,
  "created_at" : "2012-03-13 23:23:28 +0000",
  "in_reply_to_screen_name" : "BmoreUX",
  "in_reply_to_user_id_str" : "16698194",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlearning",
      "indices" : [ 126, 136 ]
    }, {
      "text" : "ux",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/cOMnwPOK",
      "expanded_url" : "http:\/\/www.gliffy.com\/publish\/3363991\/",
      "display_url" : "gliffy.com\/publish\/336399\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "179645829521473537",
  "text" : "My 1st attempt to illustrate the role of user experience with mobile learning http:\/\/t.co\/cOMnwPOK Comments are most welcome. #mlearning #ux",
  "id" : 179645829521473537,
  "created_at" : "2012-03-13 19:11:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/8mDwo8HX",
      "expanded_url" : "http:\/\/dlvr.it\/1JfgjD",
      "display_url" : "dlvr.it\/1JfgjD"
    } ]
  },
  "geo" : { },
  "id_str" : "179363736295981056",
  "text" : "RT @LEARNatCTLT: News Item: Top 20 Uses for Mobile Online Learning http:\/\/t.co\/8mDwo8HX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/8mDwo8HX",
        "expanded_url" : "http:\/\/dlvr.it\/1JfgjD",
        "display_url" : "dlvr.it\/1JfgjD"
      } ]
    },
    "geo" : { },
    "id_str" : "179363031883579392",
    "text" : "News Item: Top 20 Uses for Mobile Online Learning http:\/\/t.co\/8mDwo8HX",
    "id" : 179363031883579392,
    "created_at" : "2012-03-13 00:27:33 +0000",
    "user" : {
      "name" : "UBC CTLT",
      "screen_name" : "UBC_CTLT",
      "protected" : false,
      "id_str" : "16368476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669315281815105536\/xJtGMvol_normal.jpg",
      "id" : 16368476,
      "verified" : false
    }
  },
  "id" : 179363736295981056,
  "created_at" : "2012-03-13 00:30:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Michael",
      "screen_name" : "Netvenlig",
      "indices" : [ 3, 13 ],
      "id_str" : "487721928",
      "id" : 487721928
    }, {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 34, 40 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mobile",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/BXDTuDUD",
      "expanded_url" : "http:\/\/goo.gl\/nNaeb",
      "display_url" : "goo.gl\/nNaeb"
    } ]
  },
  "geo" : { },
  "id_str" : "178267133296377856",
  "text" : "RT @Netvenlig: 1 hour well spent: @lukew on designing for #mobile first http:\/\/t.co\/BXDTuDUD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Luke Wroblewski",
        "screen_name" : "lukew",
        "indices" : [ 19, 25 ],
        "id_str" : "13889622",
        "id" : 13889622
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mobile",
        "indices" : [ 43, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/BXDTuDUD",
        "expanded_url" : "http:\/\/goo.gl\/nNaeb",
        "display_url" : "goo.gl\/nNaeb"
      } ]
    },
    "geo" : { },
    "id_str" : "178246356018798592",
    "text" : "1 hour well spent: @lukew on designing for #mobile first http:\/\/t.co\/BXDTuDUD",
    "id" : 178246356018798592,
    "created_at" : "2012-03-09 22:30:17 +0000",
    "user" : {
      "name" : "Lars Michael",
      "screen_name" : "Netvenlig",
      "protected" : false,
      "id_str" : "487721928",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815597179\/netvenlig_logo_normal.jpg",
      "id" : 487721928,
      "verified" : false
    }
  },
  "id" : 178267133296377856,
  "created_at" : "2012-03-09 23:52:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Underwood",
      "screen_name" : "BduSF",
      "indices" : [ 3, 9 ],
      "id_str" : "506326733",
      "id" : 506326733
    }, {
      "name" : "Cooper",
      "screen_name" : "cooper",
      "indices" : [ 44, 51 ],
      "id_str" : "17223242",
      "id" : 17223242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "alchemyarc",
      "indices" : [ 52, 63 ]
    }, {
      "text" : "sxsw",
      "indices" : [ 64, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178266624023994369",
  "text" : "RT @BduSF: Stakeholders &gt; shareholders. -@cooper #alchemyarc #sxsw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cooper",
        "screen_name" : "cooper",
        "indices" : [ 33, 40 ],
        "id_str" : "17223242",
        "id" : 17223242
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "alchemyarc",
        "indices" : [ 41, 52 ]
      }, {
        "text" : "sxsw",
        "indices" : [ 53, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "178262193865891840",
    "text" : "Stakeholders &gt; shareholders. -@cooper #alchemyarc #sxsw",
    "id" : 178262193865891840,
    "created_at" : "2012-03-09 23:33:13 +0000",
    "user" : {
      "name" : "Brian Underwood",
      "screen_name" : "BduSF",
      "protected" : false,
      "id_str" : "506326733",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1858619308\/BDU_at_desk_2012_crop_normal.jpg",
      "id" : 506326733,
      "verified" : false
    }
  },
  "id" : 178266624023994369,
  "created_at" : "2012-03-09 23:50:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Fielding",
      "screen_name" : "n00btorious",
      "indices" : [ 0, 12 ],
      "id_str" : "463192893",
      "id" : 463192893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177646642030329857",
  "geo" : { },
  "id_str" : "177809874351177728",
  "in_reply_to_user_id" : 463192893,
  "text" : "@n00btorious It was my pleasure to join your BCIT class last night!",
  "id" : 177809874351177728,
  "in_reply_to_status_id" : 177646642030329857,
  "created_at" : "2012-03-08 17:35:52 +0000",
  "in_reply_to_screen_name" : "n00btorious",
  "in_reply_to_user_id_str" : "463192893",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Grange",
      "screen_name" : "GrangeSteve",
      "indices" : [ 0, 12 ],
      "id_str" : "291889357",
      "id" : 291889357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177090695654424577",
  "in_reply_to_user_id" : 291889357,
  "text" : "@GrangeSteve Thanks very much for the RT!",
  "id" : 177090695654424577,
  "created_at" : "2012-03-06 17:58:06 +0000",
  "in_reply_to_screen_name" : "GrangeSteve",
  "in_reply_to_user_id_str" : "291889357",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/vrLXAE57",
      "expanded_url" : "http:\/\/prezi.com\/7iju5aragadl\/mobile-ux-design-a-mobile-learning-case-study\/",
      "display_url" : "prezi.com\/7iju5aragadl\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "176805950034939906",
  "text" : "My \"Mobile UX Design: A Mobile Learning Case Study\" slides for BCIT's Intro to Web Dev & Design class this Wednesday http:\/\/t.co\/vrLXAE57",
  "id" : 176805950034939906,
  "created_at" : "2012-03-05 23:06:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BraveNewCode",
      "screen_name" : "BraveNewCode",
      "indices" : [ 0, 13 ],
      "id_str" : "89039840",
      "id" : 89039840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/MId8YZh4",
      "expanded_url" : "http:\/\/www.lukew.com\/ff\/entry.asp?1509",
      "display_url" : "lukew.com\/ff\/entry.asp?1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "175641789351469056",
  "in_reply_to_user_id" : 15478959,
  "text" : "@bravenewcode This article might be of interest to you http:\/\/t.co\/MId8YZh4 I am combining WPtouch w. responsive theme to achieve \"RESS\"",
  "id" : 175641789351469056,
  "created_at" : "2012-03-02 18:00:40 +0000",
  "in_reply_to_screen_name" : "wptouch",
  "in_reply_to_user_id_str" : "15478959",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/MId8YZh4",
      "expanded_url" : "http:\/\/www.lukew.com\/ff\/entry.asp?1509",
      "display_url" : "lukew.com\/ff\/entry.asp?1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "175639660104646656",
  "text" : "Which One: Responsive Design, Device Experiences, or RESS?: http:\/\/t.co\/MId8YZh4 &lt;-I am exploring catch-all responsive + key device specific",
  "id" : 175639660104646656,
  "created_at" : "2012-03-02 17:52:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]