Grailbird.data.tweets_2011_04 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Perez",
      "screen_name" : "sarahintampa",
      "indices" : [ 56, 69 ],
      "id_str" : "683113",
      "id" : 683113
    }, {
      "name" : "ReadWrite",
      "screen_name" : "RWW",
      "indices" : [ 94, 98 ],
      "id_str" : "4641021",
      "id" : 4641021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 89 ],
      "url" : "http:\/\/t.co\/EAD1SrL",
      "expanded_url" : "http:\/\/rww.to\/fFHbmX",
      "display_url" : "rww.to\/fFHbmX"
    } ]
  },
  "geo" : { },
  "id_str" : "63284649002139648",
  "text" : "LiveCode Extends Its Development Platform to Android by @sarahintampa http:\/\/t.co\/EAD1SrL via @RWW",
  "id" : 63284649002139648,
  "created_at" : "2011-04-27 16:53:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaminda Jayasekara",
      "screen_name" : "chamindaj",
      "indices" : [ 0, 10 ],
      "id_str" : "22717633",
      "id" : 22717633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62741127257788416",
  "geo" : { },
  "id_str" : "62910334805094401",
  "in_reply_to_user_id" : 22717633,
  "text" : "@chamindaj Thanks very much for the encouraging words regarding the presentation!",
  "id" : 62910334805094401,
  "in_reply_to_status_id" : 62741127257788416,
  "created_at" : "2011-04-26 16:06:07 +0000",
  "in_reply_to_screen_name" : "chamindaj",
  "in_reply_to_user_id_str" : "22717633",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/U06Af3A",
      "expanded_url" : "http:\/\/www.paulhibbitts.com\/behindthescreens-siat",
      "display_url" : "paulhibbitts.com\/behindthescree\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "62657774374486016",
  "text" : "Draft slides for my upcoming SFU SIAT presentation \"Behind the Screens: Lessons from a User Experience Consultant\" http:\/\/t.co\/U06Af3A",
  "id" : 62657774374486016,
  "created_at" : "2011-04-25 23:22:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62621683223240704",
  "text" : "I've said it once, and I'll say it again - the term \"User Experience Designer\" is quite pompous. UX design is almost always a team effort.",
  "id" : 62621683223240704,
  "created_at" : "2011-04-25 20:59:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UX Magazine",
      "screen_name" : "uxmag",
      "indices" : [ 44, 50 ],
      "id_str" : "15056788",
      "id" : 15056788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58223497180217345",
  "text" : "Paper-in-Screen Prototyping on UX Magazine (@uxmag) http:\/\/bit.ly\/ecb4Oo &lt;- Great approach for adding device context to usability tests!",
  "id" : 58223497180217345,
  "created_at" : "2011-04-13 17:42:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Travis",
      "screen_name" : "userfocus",
      "indices" : [ 3, 13 ],
      "id_str" : "16509110",
      "id" : 16509110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 104, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54951015421714432",
  "text" : "RT @userfocus: Pixar's motto (\"Going From Suck to Nonsuck\") is an almost perfect metaphor for how to do #UX design. http:\/\/bit.ly\/gmQJQN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 89, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54944572257746944",
    "text" : "Pixar's motto (\"Going From Suck to Nonsuck\") is an almost perfect metaphor for how to do #UX design. http:\/\/bit.ly\/gmQJQN",
    "id" : 54944572257746944,
    "created_at" : "2011-04-04 16:33:01 +0000",
    "user" : {
      "name" : "David Travis",
      "screen_name" : "userfocus",
      "protected" : false,
      "id_str" : "16509110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748776721\/Userfocus_blurry_o_normal.png",
      "id" : 16509110,
      "verified" : false
    }
  },
  "id" : 54951015421714432,
  "created_at" : "2011-04-04 16:58:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53975091796647936",
  "text" : "Any recommendations of recruiting agencies for Vancouver-area usability test participants?",
  "id" : 53975091796647936,
  "created_at" : "2011-04-02 00:20:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/4J6rjsh",
      "expanded_url" : "http:\/\/mobiledesign.org\/toc",
      "display_url" : "mobiledesign.org\/toc"
    } ]
  },
  "geo" : { },
  "id_str" : "53878446471905280",
  "text" : "Mobile Design and Development by Brian Fling is now free for anyone to read! http:\/\/t.co\/4J6rjsh Most content is still quite relevant.",
  "id" : 53878446471905280,
  "created_at" : "2011-04-01 17:56:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]