Grailbird.data.tweets_2014_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Schwartz",
      "screen_name" : "uxisthepoint",
      "indices" : [ 3, 16 ],
      "id_str" : "16665508",
      "id" : 16665508
    }, {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "indices" : [ 109, 123 ],
      "id_str" : "1236101",
      "id" : 1236101
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "platform",
      "indices" : [ 22, 31 ]
    }, {
      "text" : "postPC",
      "indices" : [ 124, 131 ]
    }, {
      "text" : "smartphone",
      "indices" : [ 132, 140 ]
    }, {
      "text" : "tablet",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/0X5agK2ksa",
      "expanded_url" : "http:\/\/buff.ly\/1jPy1zN",
      "display_url" : "buff.ly\/1jPy1zN"
    } ]
  },
  "geo" : { },
  "id_str" : "450754984070508544",
  "text" : "RT @uxisthepoint: The #platform wars are fun to talk about, but this is what matters. http:\/\/t.co\/0X5agK2ksa @BenedictEvans #postPC #smartp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Benedict Evans",
        "screen_name" : "BenedictEvans",
        "indices" : [ 91, 105 ],
        "id_str" : "1236101",
        "id" : 1236101
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "platform",
        "indices" : [ 4, 13 ]
      }, {
        "text" : "postPC",
        "indices" : [ 106, 113 ]
      }, {
        "text" : "smartphone",
        "indices" : [ 114, 125 ]
      }, {
        "text" : "tablet",
        "indices" : [ 126, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/0X5agK2ksa",
        "expanded_url" : "http:\/\/buff.ly\/1jPy1zN",
        "display_url" : "buff.ly\/1jPy1zN"
      } ]
    },
    "geo" : { },
    "id_str" : "450754589848264704",
    "text" : "The #platform wars are fun to talk about, but this is what matters. http:\/\/t.co\/0X5agK2ksa @BenedictEvans #postPC #smartphone #tablet",
    "id" : 450754589848264704,
    "created_at" : "2014-03-31 22:00:43 +0000",
    "user" : {
      "name" : "Jon Schwartz",
      "screen_name" : "uxisthepoint",
      "protected" : false,
      "id_str" : "16665508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1186859761\/70756_694955928_3593625_n_normal.jpg",
      "id" : 16665508,
      "verified" : false
    }
  },
  "id" : 450754984070508544,
  "created_at" : "2014-03-31 22:02:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UBC Robson Square",
      "screen_name" : "UBCRobsonSquare",
      "indices" : [ 99, 115 ],
      "id_str" : "210914069",
      "id" : 210914069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/DrVE497Viq",
      "expanded_url" : "http:\/\/slid.es\/paulhibbitts\/iy103-w14-fundamentals-slides",
      "display_url" : "slid.es\/paulhibbitts\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450717001573359616",
  "text" : "Draft slides for Fundamentals topic in upcoming Designing Multi-device Learning Experiences course @UBCRobsonSquare http:\/\/t.co\/DrVE497Viq",
  "id" : 450717001573359616,
  "created_at" : "2014-03-31 19:31:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450208072133533696",
  "geo" : { },
  "id_str" : "450323474066595840",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Awesome, thanks for doing that!",
  "id" : 450323474066595840,
  "in_reply_to_status_id" : 450208072133533696,
  "created_at" : "2014-03-30 17:27:37 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everett McKay",
      "screen_name" : "UXDesignEdge",
      "indices" : [ 0, 13 ],
      "id_str" : "205411420",
      "id" : 205411420
    }, {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 40, 50 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/LeNhSYF9G4",
      "expanded_url" : "http:\/\/slid.es\/paulhibbitts\/designing-a-multi-device-moodle-course-site-a-case-study",
      "display_url" : "slid.es\/paulhibbitts\/d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "450058419698163712",
  "geo" : { },
  "id_str" : "450059792187277313",
  "in_reply_to_user_id" : 205411420,
  "text" : "@UXDesignEdge You should also check out @slidesapp for multi-device + cloud + live streaming for HTML5 slides. Demo: http:\/\/t.co\/LeNhSYF9G4",
  "id" : 450059792187277313,
  "in_reply_to_status_id" : 450058419698163712,
  "created_at" : "2014-03-29 23:59:50 +0000",
  "in_reply_to_screen_name" : "UXDesignEdge",
  "in_reply_to_user_id_str" : "205411420",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449841156218961920",
  "geo" : { },
  "id_str" : "449922472599511040",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp For 15 secs it says \u201CDeleting\u2026\u201D w. spinning GIF then a red message lower right \u201CFailed to Delete\u201D. \u201CDeleting\u2026 status msg stays.",
  "id" : 449922472599511040,
  "in_reply_to_status_id" : 449841156218961920,
  "created_at" : "2014-03-29 14:54:11 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/WEwUxxN3D7",
      "expanded_url" : "http:\/\/slid.es\/paulhibbitts\/iy103-w14-fundamentals-backup",
      "display_url" : "slid.es\/paulhibbitts\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449716478116245505",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp In the process of duplicating &amp; renaming decks, I cannot seem to delete http:\/\/t.co\/WEwUxxN3D7 Is it possible to delete? Thanks!",
  "id" : 449716478116245505,
  "created_at" : "2014-03-29 01:15:38 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Space Archaeology",
      "screen_name" : "spacearcheology",
      "indices" : [ 3, 19 ],
      "id_str" : "59077428",
      "id" : 59077428
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/spacearcheology\/status\/448613150267428864\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/DtTvg93tNK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjnLSIeCUAAaw7n.jpg",
      "id_str" : "448613150271623168",
      "id" : 448613150271623168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjnLSIeCUAAaw7n.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DtTvg93tNK"
    } ],
    "hashtags" : [ {
      "text" : "facebook",
      "indices" : [ 109, 118 ]
    }, {
      "text" : "OculusRift",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448904734926069760",
  "text" : "RT @spacearcheology: If you want a picture of the future, imagine a feed updating on a human face \u2014 forever. #facebook #OculusRift http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/spacearcheology\/status\/448613150267428864\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/DtTvg93tNK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjnLSIeCUAAaw7n.jpg",
        "id_str" : "448613150271623168",
        "id" : 448613150271623168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjnLSIeCUAAaw7n.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DtTvg93tNK"
      } ],
      "hashtags" : [ {
        "text" : "facebook",
        "indices" : [ 88, 97 ]
      }, {
        "text" : "OculusRift",
        "indices" : [ 98, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448613150267428864",
    "text" : "If you want a picture of the future, imagine a feed updating on a human face \u2014 forever. #facebook #OculusRift http:\/\/t.co\/DtTvg93tNK",
    "id" : 448613150267428864,
    "created_at" : "2014-03-26 00:11:24 +0000",
    "user" : {
      "name" : "Space Archaeology",
      "screen_name" : "spacearcheology",
      "protected" : false,
      "id_str" : "59077428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740500967246823424\/gCARWzEN_normal.jpg",
      "id" : 59077428,
      "verified" : false
    }
  },
  "id" : 448904734926069760,
  "created_at" : "2014-03-26 19:30:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/LeNhSYF9G4",
      "expanded_url" : "http:\/\/slid.es\/paulhibbitts\/designing-a-multi-device-moodle-course-site-a-case-study",
      "display_url" : "slid.es\/paulhibbitts\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448565803260985344",
  "text" : "Slides for today's presentation about multi-device experience design with Moodle http:\/\/t.co\/LeNhSYF9G4",
  "id" : 448565803260985344,
  "created_at" : "2014-03-25 21:03:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 89, 99 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/448508916532801536\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/NB46NXIj1J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjlse7KIgAADFvl.jpg",
      "id_str" : "448508916432142336",
      "id" : 448508916432142336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjlse7KIgAADFvl.jpg",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com\/NB46NXIj1J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448508916532801536",
  "text" : "My preso toolkit for today: Surface 2 (w Twitter split screen), HTML5 slides streaming w @SlidesApp &amp; Logitech 800R. http:\/\/t.co\/NB46NXIj1J",
  "id" : 448508916532801536,
  "created_at" : "2014-03-25 17:17:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/YHPp7lZBr9",
      "expanded_url" : "http:\/\/bit.ly\/1ixgQzf",
      "display_url" : "bit.ly\/1ixgQzf"
    } ]
  },
  "geo" : { },
  "id_str" : "448505961750089728",
  "text" : "RT @etug: Tell Session today at Noon. Join @paulhibbittsUBC for \"Designing a Multi-device Moodle course site\" Here's the link: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/YHPp7lZBr9",
        "expanded_url" : "http:\/\/bit.ly\/1ixgQzf",
        "display_url" : "bit.ly\/1ixgQzf"
      } ]
    },
    "geo" : { },
    "id_str" : "448505035219939329",
    "text" : "Tell Session today at Noon. Join @paulhibbittsUBC for \"Designing a Multi-device Moodle course site\" Here's the link: http:\/\/t.co\/YHPp7lZBr9",
    "id" : 448505035219939329,
    "created_at" : "2014-03-25 17:01:47 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 448505961750089728,
  "created_at" : "2014-03-25 17:05:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Travis",
      "screen_name" : "userfocus",
      "indices" : [ 3, 13 ],
      "id_str" : "16509110",
      "id" : 16509110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "useful",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/BEjXdgd4d2",
      "expanded_url" : "http:\/\/bit.ly\/1hlok4W",
      "display_url" : "bit.ly\/1hlok4W"
    } ]
  },
  "geo" : { },
  "id_str" : "448464133139099648",
  "text" : "RT @userfocus: An online UX planning tool. #useful http:\/\/t.co\/BEjXdgd4d2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "useful",
        "indices" : [ 28, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/BEjXdgd4d2",
        "expanded_url" : "http:\/\/bit.ly\/1hlok4W",
        "display_url" : "bit.ly\/1hlok4W"
      } ]
    },
    "geo" : { },
    "id_str" : "448457776675975168",
    "text" : "An online UX planning tool. #useful http:\/\/t.co\/BEjXdgd4d2",
    "id" : 448457776675975168,
    "created_at" : "2014-03-25 13:54:00 +0000",
    "user" : {
      "name" : "David Travis",
      "screen_name" : "userfocus",
      "protected" : false,
      "id_str" : "16509110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748776721\/Userfocus_blurry_o_normal.png",
      "id" : 16509110,
      "verified" : false
    }
  },
  "id" : 448464133139099648,
  "created_at" : "2014-03-25 14:19:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Ridden",
      "screen_name" : "moodleman",
      "indices" : [ 0, 10 ],
      "id_str" : "33704369",
      "id" : 33704369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/LeNhSYF9G4",
      "expanded_url" : "http:\/\/slid.es\/paulhibbitts\/designing-a-multi-device-moodle-course-site-a-case-study",
      "display_url" : "slid.es\/paulhibbitts\/d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "446975363982180352",
  "geo" : { },
  "id_str" : "448250239493742592",
  "in_reply_to_user_id" : 9198142,
  "text" : "@moodleman Thanks for Elegance! I'll be including it in my Designing a Multi-device Moodle Course Site: A Case Study http:\/\/t.co\/LeNhSYF9G4",
  "id" : 448250239493742592,
  "in_reply_to_status_id" : 446975363982180352,
  "created_at" : "2014-03-25 00:09:19 +0000",
  "in_reply_to_screen_name" : "EduRidden",
  "in_reply_to_user_id_str" : "9198142",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/u1RTECCMjr",
      "expanded_url" : "https:\/\/speakerdeck.com\/hibbittsdesign\/etug-t-dot-e-l-dot-l-designing-a-multi-device-moodle-course-site-a-case-study",
      "display_url" : "speakerdeck.com\/hibbittsdesign\u2026"
    }, {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/LeNhSYF9G4",
      "expanded_url" : "http:\/\/slid.es\/paulhibbitts\/designing-a-multi-device-moodle-course-site-a-case-study",
      "display_url" : "slid.es\/paulhibbitts\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448227979601014784",
  "text" : "Old school slides (last Friday) https:\/\/t.co\/u1RTECCMjr New school slides (today) http:\/\/t.co\/LeNhSYF9G4 Amazing multi-device possibilities!",
  "id" : 448227979601014784,
  "created_at" : "2014-03-24 22:40:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 53, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/U9wwo2KzpU",
      "expanded_url" : "http:\/\/etug.ca\/2014\/03\/03\/t-e-l-l-march-designing-a-multi-device-moodle-course-site-a-case-study\/",
      "display_url" : "etug.ca\/2014\/03\/03\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448186690255851520",
  "text" : "Really looking forward to delivering tomorrow's free #ETUG webinar on multi-device design with Moodle! More info at http:\/\/t.co\/U9wwo2KzpU",
  "id" : 448186690255851520,
  "created_at" : "2014-03-24 19:56:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448185485584642048",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Speaker view seems to be working again. Thanks again for such a fantastic new set of features!",
  "id" : 448185485584642048,
  "created_at" : "2014-03-24 19:52:01 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448160697252208640",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Loving the new presentation  features! Speaker view seems to result in a black screen but slides are still presented. Any ideas?",
  "id" : 448160697252208640,
  "created_at" : "2014-03-24 18:13:31 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 48, 58 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blackboard",
      "indices" : [ 4, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Q4mZq4wy2H",
      "expanded_url" : "http:\/\/blog.slid.es\/post\/80262061637\/introducing-a-new-way-to-present",
      "display_url" : "blog.slid.es\/post\/802620616\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448131176629153792",
  "text" : "Use #Blackboard Collaborate? You must check out @SlidesApp live streaming presentation + BC Web Tour (w. Follow Me) http:\/\/t.co\/Q4mZq4wy2H",
  "id" : 448131176629153792,
  "created_at" : "2014-03-24 16:16:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Responsive Design",
      "screen_name" : "RWD",
      "indices" : [ 3, 7 ],
      "id_str" : "348664405",
      "id" : 348664405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/K1jwcVRPi4",
      "expanded_url" : "http:\/\/timkadlec.com\/2014\/03\/why-rwd-looks-like-rwd\/",
      "display_url" : "timkadlec.com\/2014\/03\/why-rw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447448480600965120",
  "text" : "RT @RWD: \u201CThe more multi-device work you do, the more you discover\u2026the toughest problems [aren\u2019t] related to technology.\u201D http:\/\/t.co\/K1jwc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/K1jwcVRPi4",
        "expanded_url" : "http:\/\/timkadlec.com\/2014\/03\/why-rwd-looks-like-rwd\/",
        "display_url" : "timkadlec.com\/2014\/03\/why-rw\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "445984703485853696",
    "text" : "\u201CThe more multi-device work you do, the more you discover\u2026the toughest problems [aren\u2019t] related to technology.\u201D http:\/\/t.co\/K1jwcVRPi4",
    "id" : 445984703485853696,
    "created_at" : "2014-03-18 18:06:53 +0000",
    "user" : {
      "name" : "Responsive Design",
      "screen_name" : "RWD",
      "protected" : false,
      "id_str" : "348664405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539462074808561664\/PgmryUKs_normal.png",
      "id" : 348664405,
      "verified" : false
    }
  },
  "id" : 447448480600965120,
  "created_at" : "2014-03-22 19:03:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 1, 11 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/Q4mZq4wy2H",
      "expanded_url" : "http:\/\/blog.slid.es\/post\/80262061637\/introducing-a-new-way-to-present",
      "display_url" : "blog.slid.es\/post\/802620616\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447193210649993218",
  "text" : "\u201C@SlidesApp: Introducing a new way to Present http:\/\/t.co\/Q4mZq4wy2H\u201D &lt;- This is totally awesome, and multi-device friendly to boot!",
  "id" : 447193210649993218,
  "created_at" : "2014-03-22 02:09:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "effectiveui",
      "screen_name" : "effectiveui",
      "indices" : [ 3, 15 ],
      "id_str" : "14627322",
      "id" : 14627322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/km4w3kozxZ",
      "expanded_url" : "http:\/\/ow.ly\/uQnTD",
      "display_url" : "ow.ly\/uQnTD"
    } ]
  },
  "geo" : { },
  "id_str" : "447168284517888000",
  "text" : "RT @effectiveui: Next-Generation Book Publishing: Of the HTML, by the HTML, for the HTML http:\/\/t.co\/km4w3kozxZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/km4w3kozxZ",
        "expanded_url" : "http:\/\/ow.ly\/uQnTD",
        "display_url" : "ow.ly\/uQnTD"
      } ]
    },
    "geo" : { },
    "id_str" : "447167117348306944",
    "text" : "Next-Generation Book Publishing: Of the HTML, by the HTML, for the HTML http:\/\/t.co\/km4w3kozxZ",
    "id" : 447167117348306944,
    "created_at" : "2014-03-22 00:25:23 +0000",
    "user" : {
      "name" : "effectiveui",
      "screen_name" : "effectiveui",
      "protected" : false,
      "id_str" : "14627322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760186329514803200\/np6gVDUY_normal.jpg",
      "id" : 14627322,
      "verified" : false
    }
  },
  "id" : 447168284517888000,
  "created_at" : "2014-03-22 00:30:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/5Tazgt8zmm",
      "expanded_url" : "http:\/\/www.slideshare.net\/hibbittsdesign\/designing-a-multidevice-moodle-course-site-a-case-study",
      "display_url" : "slideshare.net\/hibbittsdesign\u2026"
    }, {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/U9wwo2KzpU",
      "expanded_url" : "http:\/\/etug.ca\/2014\/03\/03\/t-e-l-l-march-designing-a-multi-device-moodle-course-site-a-case-study\/",
      "display_url" : "etug.ca\/2014\/03\/03\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446339919602917377",
  "text" : "Updated slides for my March 25th #ETUG webinar on multi-device design with Moodle http:\/\/t.co\/5Tazgt8zmm More info http:\/\/t.co\/U9wwo2KzpU",
  "id" : 446339919602917377,
  "created_at" : "2014-03-19 17:38:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UBC Robson Square",
      "screen_name" : "UBCRobsonSquare",
      "indices" : [ 101, 117 ],
      "id_str" : "210914069",
      "id" : 210914069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/QAZDgXiHWw",
      "expanded_url" : "http:\/\/www.cstudies.ubc.ca\/a\/Course\/Designing-Multi-device-Learning-Experiences\/IY103\/",
      "display_url" : "cstudies.ubc.ca\/a\/Course\/Desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445972335510556672",
  "text" : "Interested in designing better multi-device learning experiences? Space still available in my course @UBCRobsonSquare http:\/\/t.co\/QAZDgXiHWw",
  "id" : 445972335510556672,
  "created_at" : "2014-03-18 17:17:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MeasuringU",
      "screen_name" : "MeasuringU",
      "indices" : [ 3, 14 ],
      "id_str" : "103951768",
      "id" : 103951768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/sW7GLsEHzO",
      "expanded_url" : "http:\/\/ow.ly\/twe5u",
      "display_url" : "ow.ly\/twe5u"
    } ]
  },
  "geo" : { },
  "id_str" : "444602444886986753",
  "text" : "RT @MeasuringU: Rating the Severity of Usability Problems http:\/\/t.co\/sW7GLsEHzO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/sW7GLsEHzO",
        "expanded_url" : "http:\/\/ow.ly\/twe5u",
        "display_url" : "ow.ly\/twe5u"
      } ]
    },
    "geo" : { },
    "id_str" : "444601732086370305",
    "text" : "Rating the Severity of Usability Problems http:\/\/t.co\/sW7GLsEHzO",
    "id" : 444601732086370305,
    "created_at" : "2014-03-14 22:31:27 +0000",
    "user" : {
      "name" : "MeasuringU",
      "screen_name" : "MeasuringU",
      "protected" : false,
      "id_str" : "103951768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768568168553910272\/Qigu06V6_normal.jpg",
      "id" : 103951768,
      "verified" : false
    }
  },
  "id" : 444602444886986753,
  "created_at" : "2014-03-14 22:34:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/DhkAGq0Hwk",
      "expanded_url" : "http:\/\/info.cern.ch\/hypertext\/WWW\/TheProject.html",
      "display_url" : "info.cern.ch\/hypertext\/WWW\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443864799315632129",
  "text" : "The Web is 25 years old today, and interestingly the first web page http:\/\/t.co\/DhkAGq0Hwk is more multi-device friendly than many now.",
  "id" : 443864799315632129,
  "created_at" : "2014-03-12 21:43:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Weisblatt",
      "screen_name" : "weisblatt",
      "indices" : [ 3, 13 ],
      "id_str" : "17156081",
      "id" : 17156081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443802066645823488",
  "text" : "RT @weisblatt: Learning design and development is not something separate from other domains of design. We forget that sometimes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443801257120366592",
    "text" : "Learning design and development is not something separate from other domains of design. We forget that sometimes.",
    "id" : 443801257120366592,
    "created_at" : "2014-03-12 17:30:39 +0000",
    "user" : {
      "name" : "Adam Weisblatt",
      "screen_name" : "weisblatt",
      "protected" : false,
      "id_str" : "17156081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000637920088\/4f12030be9b0f1165a4bc6bcf7ed1559_normal.jpeg",
      "id" : 17156081,
      "verified" : false
    }
  },
  "id" : 443802066645823488,
  "created_at" : "2014-03-12 17:33:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 31, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/5Tazgt8zmm",
      "expanded_url" : "http:\/\/www.slideshare.net\/hibbittsdesign\/designing-a-multidevice-moodle-course-site-a-case-study",
      "display_url" : "slideshare.net\/hibbittsdesign\u2026"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/U9wwo2KzpU",
      "expanded_url" : "http:\/\/etug.ca\/2014\/03\/03\/t-e-l-l-march-designing-a-multi-device-moodle-course-site-a-case-study\/",
      "display_url" : "etug.ca\/2014\/03\/03\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443793789891518464",
  "text" : "Draft slides for my March 25th #ETUG webinar on multi-device design with Moodle http:\/\/t.co\/5Tazgt8zmm More info at http:\/\/t.co\/U9wwo2KzpU",
  "id" : 443793789891518464,
  "created_at" : "2014-03-12 17:00:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Mark Bullen)))",
      "screen_name" : "markbullen",
      "indices" : [ 0, 11 ],
      "id_str" : "14080697",
      "id" : 14080697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443532494638309376",
  "geo" : { },
  "id_str" : "443532837073858560",
  "in_reply_to_user_id" : 14080697,
  "text" : "@markbullen Oh, it is a Moodle-built site.",
  "id" : 443532837073858560,
  "in_reply_to_status_id" : 443532494638309376,
  "created_at" : "2014-03-11 23:44:03 +0000",
  "in_reply_to_screen_name" : "markbullen",
  "in_reply_to_user_id_str" : "14080697",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Mark Bullen)))",
      "screen_name" : "markbullen",
      "indices" : [ 0, 11 ],
      "id_str" : "14080697",
      "id" : 14080697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/oMfMbr244c",
      "expanded_url" : "http:\/\/iy103-w14.hibbittsdesign.com\/",
      "display_url" : "iy103-w14.hibbittsdesign.com"
    } ]
  },
  "in_reply_to_status_id_str" : "443482890307780608",
  "geo" : { },
  "id_str" : "443484333727154176",
  "in_reply_to_user_id" : 14080697,
  "text" : "@markbullen It is possible to resuscitate the patient, to a degree :-) Here is my most recent effort to do so: http:\/\/t.co\/oMfMbr244c",
  "id" : 443484333727154176,
  "in_reply_to_status_id" : 443482890307780608,
  "created_at" : "2014-03-11 20:31:19 +0000",
  "in_reply_to_screen_name" : "markbullen",
  "in_reply_to_user_id_str" : "14080697",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 0, 7 ],
      "id_str" : "745903",
      "id" : 745903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443443835431968768",
  "geo" : { },
  "id_str" : "443444969907683328",
  "in_reply_to_user_id" : 745903,
  "text" : "@brlamb I really enjoyed our chat today too, looking forward to learning more from you in the future!",
  "id" : 443444969907683328,
  "in_reply_to_status_id" : 443443835431968768,
  "created_at" : "2014-03-11 17:54:54 +0000",
  "in_reply_to_screen_name" : "brlamb",
  "in_reply_to_user_id_str" : "745903",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 122, 126 ]
    }, {
      "text" : "open",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/QKBw98n4Po",
      "expanded_url" : "http:\/\/www.mindmeister.com\/387130789\/designing-a-course-in-the-open-a-case-study",
      "display_url" : "mindmeister.com\/387130789\/desi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443431539724914688",
  "text" : "First draft visual map for a proposed talk entitled \u201CDesigning a Course in the Open: A Case Study\u201D http:\/\/t.co\/QKBw98n4Po #OER #open",
  "id" : 443431539724914688,
  "created_at" : "2014-03-11 17:01:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/VDlZdVxOmA",
      "expanded_url" : "http:\/\/www.mindmeister.com\/385523095\/designing-a-multi-device-moodle-course-site-a-case-study",
      "display_url" : "mindmeister.com\/385523095\/desi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443127373517848576",
  "text" : "First draft visual map for my #ETUG webinar \u201CDesigning a Multi-device Moodle Course Site: A Case Study\u201D http:\/\/t.co\/VDlZdVxOmA",
  "id" : 443127373517848576,
  "created_at" : "2014-03-10 20:52:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    }, {
      "name" : "will engle",
      "screen_name" : "infology",
      "indices" : [ 14, 23 ],
      "id_str" : "93031146",
      "id" : 93031146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/9HrevXh4Q1",
      "expanded_url" : "https:\/\/onedrive.live.com\/redir?resid=74D2D06DCB0AFD88!139273&authkey=!AOk1YyDZelkgVfk&ithint=folder%2c.docx",
      "display_url" : "onedrive.live.com\/redir?resid=74\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "442101052175687681",
  "geo" : { },
  "id_str" : "442109163439923200",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde @infology Love this! I'm experimenting with CC licenses on all my UBC Cont. Studies course worksheets. https:\/\/t.co\/9HrevXh4Q1",
  "id" : 442109163439923200,
  "in_reply_to_status_id" : 442101052175687681,
  "created_at" : "2014-03-08 01:26:53 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marketingcharts",
      "screen_name" : "marketingcharts",
      "indices" : [ 90, 106 ],
      "id_str" : "12621792",
      "id" : 12621792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/CCFwnsu7vm",
      "expanded_url" : "http:\/\/www.marketingcharts.com\/wp\/online\/multi-device-users-typically-complete-tasks-on-larger-screens-41229\/",
      "display_url" : "marketingcharts.com\/wp\/online\/mult\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "442039273278021632",
  "text" : "Multi-Device Users Typically Complete Tasks on Larger Screens: http:\/\/t.co\/CCFwnsu7vm via @marketingcharts",
  "id" : 442039273278021632,
  "created_at" : "2014-03-07 20:49:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441982632058843136",
  "text" : "Attributes (my) students value for a course companion: comprehensive, relevant, interactive, clean, organized, efficient, and convenient.",
  "id" : 441982632058843136,
  "created_at" : "2014-03-07 17:04:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 3, 15 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/VRZzZwrStg",
      "expanded_url" : "http:\/\/ow.ly\/ukaJR",
      "display_url" : "ow.ly\/ukaJR"
    } ]
  },
  "geo" : { },
  "id_str" : "441734604144123905",
  "text" : "RT @openroadies: We're Hiring: We're looking for a talented, friendly and passionate designer to become part of our award-winning team http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/VRZzZwrStg",
        "expanded_url" : "http:\/\/ow.ly\/ukaJR",
        "display_url" : "ow.ly\/ukaJR"
      } ]
    },
    "geo" : { },
    "id_str" : "441708875138760704",
    "text" : "We're Hiring: We're looking for a talented, friendly and passionate designer to become part of our award-winning team http:\/\/t.co\/VRZzZwrStg",
    "id" : 441708875138760704,
    "created_at" : "2014-03-06 22:56:17 +0000",
    "user" : {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "protected" : false,
      "id_str" : "66913866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554783440747237376\/HA2Svg4h_normal.png",
      "id" : 66913866,
      "verified" : false
    }
  },
  "id" : 441734604144123905,
  "created_at" : "2014-03-07 00:38:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David J Bland",
      "screen_name" : "davidjbland",
      "indices" : [ 3, 15 ],
      "id_str" : "14409265",
      "id" : 14409265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441294529266606080",
  "text" : "RT @davidjbland: Your projects are really experiments. The sooner we openly admit to this, the better off we'll be in managing expectations.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.891213785, -122.1321974 ]
    },
    "id_str" : "441275072183951360",
    "text" : "Your projects are really experiments. The sooner we openly admit to this, the better off we'll be in managing expectations.",
    "id" : 441275072183951360,
    "created_at" : "2014-03-05 18:12:30 +0000",
    "user" : {
      "name" : "David J Bland",
      "screen_name" : "davidjbland",
      "protected" : false,
      "id_str" : "14409265",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755842954015547392\/v10U6DEy_normal.jpg",
      "id" : 14409265,
      "verified" : false
    }
  },
  "id" : 441294529266606080,
  "created_at" : "2014-03-05 19:29:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 0, 11 ],
      "id_str" : "28429477",
      "id" : 28429477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441033550662344704",
  "geo" : { },
  "id_str" : "441034380882874368",
  "in_reply_to_user_id" : 28429477,
  "text" : "@chadleaman I won't expect to see you on the attendees list then ;-) Enjoy your trip!",
  "id" : 441034380882874368,
  "in_reply_to_status_id" : 441033550662344704,
  "created_at" : "2014-03-05 02:16:05 +0000",
  "in_reply_to_screen_name" : "chadleaman",
  "in_reply_to_user_id_str" : "28429477",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 0, 11 ],
      "id_str" : "28429477",
      "id" : 28429477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440996783049555968",
  "geo" : { },
  "id_str" : "441032308980600832",
  "in_reply_to_user_id" : 28429477,
  "text" : "@chadleaman Thanks for helping share the word about the workshop!",
  "id" : 441032308980600832,
  "in_reply_to_status_id" : 440996783049555968,
  "created_at" : "2014-03-05 02:07:51 +0000",
  "in_reply_to_screen_name" : "chadleaman",
  "in_reply_to_user_id_str" : "28429477",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 0, 11 ],
      "id_str" : "28429477",
      "id" : 28429477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440915756859920384",
  "geo" : { },
  "id_str" : "440972992688844800",
  "in_reply_to_user_id" : 28429477,
  "text" : "@chadleaman Just put in a proposal for a session on developing a course in the open, hope you are in the program too :-)",
  "id" : 440972992688844800,
  "in_reply_to_status_id" : 440915756859920384,
  "created_at" : "2014-03-04 22:12:09 +0000",
  "in_reply_to_screen_name" : "chadleaman",
  "in_reply_to_user_id_str" : "28429477",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 18, 23 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/JJ2F93XYyi",
      "expanded_url" : "http:\/\/bit.ly\/1cnxSuw",
      "display_url" : "bit.ly\/1cnxSuw"
    } ]
  },
  "geo" : { },
  "id_str" : "440972669127639040",
  "text" : "RT @etug: Calling @etug! We want proposals for \"20\/20\" workshop. Share your hindsight\/foresight\/insight on ed tech. Celebrate! http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 8, 13 ],
        "id_str" : "17102936",
        "id" : 17102936
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/JJ2F93XYyi",
        "expanded_url" : "http:\/\/bit.ly\/1cnxSuw",
        "display_url" : "bit.ly\/1cnxSuw"
      } ]
    },
    "geo" : { },
    "id_str" : "440912529951191040",
    "text" : "Calling @etug! We want proposals for \"20\/20\" workshop. Share your hindsight\/foresight\/insight on ed tech. Celebrate! http:\/\/t.co\/JJ2F93XYyi",
    "id" : 440912529951191040,
    "created_at" : "2014-03-04 18:11:53 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 440972669127639040,
  "created_at" : "2014-03-04 22:10:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/FHeuErc9MY",
      "expanded_url" : "http:\/\/ift.tt\/NOoD0o",
      "display_url" : "ift.tt\/NOoD0o"
    } ]
  },
  "geo" : { },
  "id_str" : "440902261170909184",
  "text" : "RT @etug: New post! [T.E.L.L March] Designing a Multi-device Moodle Course Site: A Case Study http:\/\/t.co\/FHeuErc9MY #ETUG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ETUG",
        "indices" : [ 107, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/FHeuErc9MY",
        "expanded_url" : "http:\/\/ift.tt\/NOoD0o",
        "display_url" : "ift.tt\/NOoD0o"
      } ]
    },
    "geo" : { },
    "id_str" : "440633187904258049",
    "text" : "New post! [T.E.L.L March] Designing a Multi-device Moodle Course Site: A Case Study http:\/\/t.co\/FHeuErc9MY #ETUG",
    "id" : 440633187904258049,
    "created_at" : "2014-03-03 23:41:53 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 440902261170909184,
  "created_at" : "2014-03-04 17:31:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/GRwhhDloFO",
      "expanded_url" : "http:\/\/iy103-w14.hibbittsdesign.com\/mod\/glossary\/view.php?id=6",
      "display_url" : "iy103-w14.hibbittsdesign.com\/mod\/glossary\/v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440596564851974144",
  "text" : "Almost 60 resources are now available in the glossary for my course on designing multi-device learning experiences http:\/\/t.co\/GRwhhDloFO",
  "id" : 440596564851974144,
  "created_at" : "2014-03-03 21:16:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]