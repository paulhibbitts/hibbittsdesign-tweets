Grailbird.data.tweets_2013_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/396047158438141953\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/scy7Gewhh8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX8KyrpCQAAxh1p.jpg",
      "id_str" : "396047158056468480",
      "id" : 396047158056468480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX8KyrpCQAAxh1p.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/scy7Gewhh8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396047158438141953",
  "text" : "Definitely a Halloween treat! http:\/\/t.co\/scy7Gewhh8",
  "id" : 396047158438141953,
  "created_at" : "2013-10-31 22:52:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 7, 17 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/jU5O4cCdcB",
      "expanded_url" : "http:\/\/slid.es\/explore",
      "display_url" : "slid.es\/explore"
    } ]
  },
  "geo" : { },
  "id_str" : "395954620360425472",
  "text" : "Thanks @SlidesApp for featuring my mobile and multi-device design preso http:\/\/t.co\/jU5O4cCdcB Incl. one-page touch interaction guidelines",
  "id" : 395954620360425472,
  "created_at" : "2013-10-31 16:45:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Pelikan",
      "screen_name" : "MartinPelikan",
      "indices" : [ 0, 14 ],
      "id_str" : "74681345",
      "id" : 74681345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/IvbfzByzDb",
      "expanded_url" : "http:\/\/blogs.balsamiq.com\/product\/2013\/10\/24\/colorpicker\/",
      "display_url" : "blogs.balsamiq.com\/product\/2013\/1\u2026"
    }, {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/XVgwbJU7eR",
      "expanded_url" : "http:\/\/community.balsamiq.com\/balsamiq\/products\/balsamiq_mybalsamiq",
      "display_url" : "community.balsamiq.com\/balsamiq\/produ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "394648838570405888",
  "geo" : { },
  "id_str" : "394917085521784832",
  "in_reply_to_user_id" : 74681345,
  "text" : "@MartinPelikan Last update seems to be Oct 24 http:\/\/t.co\/IvbfzByzDb Let me know if it persists * also see forum: http:\/\/t.co\/XVgwbJU7eR",
  "id" : 394917085521784832,
  "in_reply_to_status_id" : 394648838570405888,
  "created_at" : "2013-10-28 20:02:25 +0000",
  "in_reply_to_screen_name" : "MartinPelikan",
  "in_reply_to_user_id_str" : "74681345",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Lewis",
      "screen_name" : "aerotwist",
      "indices" : [ 3, 13 ],
      "id_str" : "42614508",
      "id" : 42614508
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "perfmatters",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393799575573889024",
  "text" : "RT @aerotwist: I don't like \"mobile web\" as a term. It's \"the web\" and it runs on lots of devices. We should make it run well on all of the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "perfmatters",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393776161240535040",
    "text" : "I don't like \"mobile web\" as a term. It's \"the web\" and it runs on lots of devices. We should make it run well on all of them #perfmatters",
    "id" : 393776161240535040,
    "created_at" : "2013-10-25 16:28:47 +0000",
    "user" : {
      "name" : "Paul Lewis",
      "screen_name" : "aerotwist",
      "protected" : false,
      "id_str" : "42614508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692819773147652096\/sHmbiKlK_normal.jpg",
      "id" : 42614508,
      "verified" : false
    }
  },
  "id" : 393799575573889024,
  "created_at" : "2013-10-25 18:01:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 3, 11 ],
      "id_str" : "10675",
      "id" : 10675
    }, {
      "name" : "ThoughtFarmer",
      "screen_name" : "thoughtfarmer",
      "indices" : [ 23, 37 ],
      "id_str" : "13743032",
      "id" : 13743032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 122, 127 ]
    }, {
      "text" : "Vancouver",
      "indices" : [ 128, 138 ]
    }, {
      "text" : "jobs",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/l7S6pHmZYQ",
      "expanded_url" : "http:\/\/www.bctechnology.com\/scripts\/show_job.cfm?id=105078&j=801574159125641&showdesc=0&perpage=10&page=1&startrow=1",
      "display_url" : "bctechnology.com\/scripts\/show_j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393516013154603008",
  "text" : "RT @gordonr: Come join @thoughtfarmer to make work better. Apply for our training specialist job:  http:\/\/t.co\/l7S6pHmZYQ #tech #Vancouver \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ThoughtFarmer",
        "screen_name" : "thoughtfarmer",
        "indices" : [ 10, 24 ],
        "id_str" : "13743032",
        "id" : 13743032
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tech",
        "indices" : [ 109, 114 ]
      }, {
        "text" : "Vancouver",
        "indices" : [ 115, 125 ]
      }, {
        "text" : "jobs",
        "indices" : [ 126, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/l7S6pHmZYQ",
        "expanded_url" : "http:\/\/www.bctechnology.com\/scripts\/show_job.cfm?id=105078&j=801574159125641&showdesc=0&perpage=10&page=1&startrow=1",
        "display_url" : "bctechnology.com\/scripts\/show_j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393504662751436800",
    "text" : "Come join @thoughtfarmer to make work better. Apply for our training specialist job:  http:\/\/t.co\/l7S6pHmZYQ #tech #Vancouver #jobs",
    "id" : 393504662751436800,
    "created_at" : "2013-10-24 22:29:57 +0000",
    "user" : {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "protected" : false,
      "id_str" : "10675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723725303218991104\/GhSmJXhv_normal.jpg",
      "id" : 10675,
      "verified" : false
    }
  },
  "id" : 393516013154603008,
  "created_at" : "2013-10-24 23:15:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393473458002083840",
  "text" : "Is \u201Cdumbing down the desktop\u201D now a standard element of multi-device design strategy? I am looking at you Apple Keynote 6.0. Other examples?",
  "id" : 393473458002083840,
  "created_at" : "2013-10-24 20:25:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393142388660502528",
  "text" : "Teaching used to be more about creating content. Now more about creating a narrative, interactions, and access to course facilitator + PLN.",
  "id" : 393142388660502528,
  "created_at" : "2013-10-23 22:30:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "indices" : [ 3, 17 ],
      "id_str" : "1236101",
      "id" : 1236101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393069876777979904",
  "text" : "RT @BenedictEvans: We used to talk about 'media' and 'new media'. Now it's 'media' and 'old media'. When do we stop saying 'mobile internet\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393062792531836928",
    "text" : "We used to talk about 'media' and 'new media'. Now it's 'media' and 'old media'. When do we stop saying 'mobile internet'?",
    "id" : 393062792531836928,
    "created_at" : "2013-10-23 17:14:07 +0000",
    "user" : {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "protected" : false,
      "id_str" : "1236101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544407411193163776\/vGSguvLd_normal.jpeg",
      "id" : 1236101,
      "verified" : false
    }
  },
  "id" : 393069876777979904,
  "created_at" : "2013-10-23 17:42:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392795076797022208",
  "geo" : { },
  "id_str" : "392795472105971712",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh Don\u2019t you know? Contrast has a bad reputation for not being elegant :-)",
  "id" : 392795472105971712,
  "in_reply_to_status_id" : 392795076797022208,
  "created_at" : "2013-10-22 23:31:52 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 0, 11 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392767344142848000",
  "geo" : { },
  "id_str" : "392768199927689216",
  "in_reply_to_user_id" : 217880712,
  "text" : "@jimbobtyer Congratulations! My wife and I found the book Healthy Sleep Habits, Happy Child extremely helpful. Your mileage may vary :-)",
  "id" : 392768199927689216,
  "in_reply_to_status_id" : 392767344142848000,
  "created_at" : "2013-10-22 21:43:30 +0000",
  "in_reply_to_screen_name" : "jimbobtyer",
  "in_reply_to_user_id_str" : "217880712",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392752435090825216",
  "text" : "Free is nice of course, but I have to wonder what Apple has cooking behind the scenes that will require Macs to have at least Mavericks OS?",
  "id" : 392752435090825216,
  "created_at" : "2013-10-22 20:40:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392734039909486592",
  "geo" : { },
  "id_str" : "392750395207864321",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Thanks very much! I love slid.es and always point people to your app :-)",
  "id" : 392750395207864321,
  "in_reply_to_status_id" : 392734039909486592,
  "created_at" : "2013-10-22 20:32:45 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392705621226553344",
  "geo" : { },
  "id_str" : "392716164205277184",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Quick update - I was just able to export the PDF :-)",
  "id" : 392716164205277184,
  "in_reply_to_status_id" : 392705621226553344,
  "created_at" : "2013-10-22 18:16:44 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/O6A6iSDjZt",
      "expanded_url" : "http:\/\/slid.es\/paulhibbitts\/cmpt-363-133-mobile-and-multi-device-design",
      "display_url" : "slid.es\/paulhibbitts\/c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "392705621226553344",
  "geo" : { },
  "id_str" : "392712232045273088",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Thanks so much for the quick follow-up! The slide deck is at http:\/\/t.co\/O6A6iSDjZt",
  "id" : 392712232045273088,
  "in_reply_to_status_id" : 392705621226553344,
  "created_at" : "2013-10-22 18:01:07 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392703422341709824",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Is there something up with the Export to PDF feature? I cannot seem to export any slide decks this morning.",
  "id" : 392703422341709824,
  "created_at" : "2013-10-22 17:26:06 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/2DqxykPPcv",
      "expanded_url" : "https:\/\/chrome.google.com\/webstore\/detail\/cmpt-363-fall-2013-course\/makeeghaichkhojfhcioclgdnonhecph?hl=en-US&gl=CA",
      "display_url" : "chrome.google.com\/webstore\/detai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392378953089814528",
  "text" : "Google Chrome Apps can enhance access to performance support oriented web apps. Here\u2019s my CMPT 363 Course Companion: https:\/\/t.co\/2DqxykPPcv",
  "id" : 392378953089814528,
  "created_at" : "2013-10-21 19:56:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 3, 19 ],
      "id_str" : "17349291",
      "id" : 17349291
    }, {
      "name" : "John Robert Allan",
      "screen_name" : "johnrobertallan",
      "indices" : [ 47, 63 ],
      "id_str" : "24031564",
      "id" : 24031564
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rwd",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/A2K51x133N",
      "expanded_url" : "http:\/\/hbn.ro\/18CGnTC",
      "display_url" : "hbn.ro\/18CGnTC"
    } ]
  },
  "geo" : { },
  "id_str" : "392317808328966144",
  "text" : "RT @HabaneroConsult: User experience developer @johnrobertallan introduces our new light-responsive approach in this Insights post: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Robert Allan",
        "screen_name" : "johnrobertallan",
        "indices" : [ 26, 42 ],
        "id_str" : "24031564",
        "id" : 24031564
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rwd",
        "indices" : [ 134, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/A2K51x133N",
        "expanded_url" : "http:\/\/hbn.ro\/18CGnTC",
        "display_url" : "hbn.ro\/18CGnTC"
      } ]
    },
    "geo" : { },
    "id_str" : "392312450684420096",
    "text" : "User experience developer @johnrobertallan introduces our new light-responsive approach in this Insights post: http:\/\/t.co\/A2K51x133N #rwd",
    "id" : 392312450684420096,
    "created_at" : "2013-10-21 15:32:31 +0000",
    "user" : {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "protected" : false,
      "id_str" : "17349291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768212660244537344\/z_mWqOrE_normal.jpg",
      "id" : 17349291,
      "verified" : false
    }
  },
  "id" : 392317808328966144,
  "created_at" : "2013-10-21 15:53:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeus XXXXXX",
      "screen_name" : "EdTechEmpowers",
      "indices" : [ 3, 18 ],
      "id_str" : "17545016",
      "id" : 17545016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "edtech",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391595177418035200",
  "text" : "RT @EdTechEmpowers: \"It is the instant access to the entire world that has degraded the importance of classrooms and experts,\" - Gary Woodi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "education",
        "indices" : [ 122, 132 ]
      }, {
        "text" : "edtech",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "237651076575277056",
    "text" : "\"It is the instant access to the entire world that has degraded the importance of classrooms and experts,\" - Gary Woodill #education #edtech",
    "id" : 237651076575277056,
    "created_at" : "2012-08-20 20:43:26 +0000",
    "user" : {
      "name" : "Brian C. Bailey",
      "screen_name" : "21stCenEducator",
      "protected" : false,
      "id_str" : "366283556",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1524228167\/P1000047__641x641__normal.JPG",
      "id" : 366283556,
      "verified" : false
    }
  },
  "id" : 391595177418035200,
  "created_at" : "2013-10-19 16:02:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alix Cote",
      "screen_name" : "alixcote",
      "indices" : [ 0, 9 ],
      "id_str" : "17200697",
      "id" : 17200697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390835743641202690",
  "geo" : { },
  "id_str" : "390858565834907648",
  "in_reply_to_user_id" : 17200697,
  "text" : "@alixcote Thanks for your feedback. If you would like, email me directly and I will share some of my favourite resources on those topics.",
  "id" : 390858565834907648,
  "in_reply_to_status_id" : 390835743641202690,
  "created_at" : "2013-10-17 15:15:18 +0000",
  "in_reply_to_screen_name" : "alixcote",
  "in_reply_to_user_id_str" : "17200697",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alix Cote",
      "screen_name" : "alixcote",
      "indices" : [ 0, 9 ],
      "id_str" : "17200697",
      "id" : 17200697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/QgFOQvIvkE",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/6ee596e4-0d7d-50d6-41f1-e5911a4227cc\/",
      "display_url" : "workflowy.com\/shared\/6ee596e\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "390564951095398400",
  "geo" : { },
  "id_str" : "390580488710422528",
  "in_reply_to_user_id" : 17200697,
  "text" : "@alixcote Thanks Alix! Here is my in-progress topic outline - what topics look most valuable for you? https:\/\/t.co\/QgFOQvIvkE",
  "id" : 390580488710422528,
  "in_reply_to_status_id" : 390564951095398400,
  "created_at" : "2013-10-16 20:50:19 +0000",
  "in_reply_to_screen_name" : "alixcote",
  "in_reply_to_user_id_str" : "17200697",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 122, 125 ]
    }, {
      "text" : "mlearning",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390558571186106368",
  "text" : "Thinking about launching a new series of workshops about designing the multi-device learner experience - topic interests? #ux  #mlearning",
  "id" : 390558571186106368,
  "created_at" : "2013-10-16 19:23:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marissa Weber",
      "screen_name" : "floatlearning",
      "indices" : [ 3, 17 ],
      "id_str" : "4444594579",
      "id" : 4444594579
    }, {
      "name" : "Moodle",
      "screen_name" : "moodle",
      "indices" : [ 35, 42 ],
      "id_str" : "3948971",
      "id" : 3948971
    }, {
      "name" : "Gary Woodill",
      "screen_name" : "gwoodill",
      "indices" : [ 89, 98 ],
      "id_str" : "15256573",
      "id" : 15256573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/h6MYKTNsoC",
      "expanded_url" : "http:\/\/hub.am\/1beXTg0",
      "display_url" : "hub.am\/1beXTg0"
    } ]
  },
  "geo" : { },
  "id_str" : "388722632935231488",
  "text" : "RT @floatlearning: New book alert: @Moodle for Mobile Learning http:\/\/t.co\/h6MYKTNsoC by @gwoodill",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Moodle",
        "screen_name" : "moodle",
        "indices" : [ 16, 23 ],
        "id_str" : "3948971",
        "id" : 3948971
      }, {
        "name" : "Gary Woodill",
        "screen_name" : "gwoodill",
        "indices" : [ 70, 79 ],
        "id_str" : "15256573",
        "id" : 15256573
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/h6MYKTNsoC",
        "expanded_url" : "http:\/\/hub.am\/1beXTg0",
        "display_url" : "hub.am\/1beXTg0"
      } ]
    },
    "geo" : { },
    "id_str" : "388335148988923904",
    "text" : "New book alert: @Moodle for Mobile Learning http:\/\/t.co\/h6MYKTNsoC by @gwoodill",
    "id" : 388335148988923904,
    "created_at" : "2013-10-10 16:08:09 +0000",
    "user" : {
      "name" : "Float",
      "screen_name" : "gowithfloat",
      "protected" : false,
      "id_str" : "118754860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671448041275023360\/SWlRDbjN_normal.png",
      "id" : 118754860,
      "verified" : false
    }
  },
  "id" : 388722632935231488,
  "created_at" : "2013-10-11 17:47:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 3, 19 ],
      "id_str" : "17349291",
      "id" : 17349291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vancouver",
      "indices" : [ 21, 31 ]
    }, {
      "text" : "Calgary",
      "indices" : [ 36, 44 ]
    }, {
      "text" : "jobs",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/UQXA8uahnj",
      "expanded_url" : "http:\/\/hbn.ro\/1brs7Q4",
      "display_url" : "hbn.ro\/1brs7Q4"
    } ]
  },
  "geo" : { },
  "id_str" : "388722183108710400",
  "text" : "RT @HabaneroConsult: #Vancouver and #Calgary students and new grads, we're looking for co-ops and interns! Learn more here: http:\/\/t.co\/UQX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Vancouver",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "Calgary",
        "indices" : [ 15, 23 ]
      }, {
        "text" : "jobs",
        "indices" : [ 126, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/UQXA8uahnj",
        "expanded_url" : "http:\/\/hbn.ro\/1brs7Q4",
        "display_url" : "hbn.ro\/1brs7Q4"
      } ]
    },
    "geo" : { },
    "id_str" : "388721627694784512",
    "text" : "#Vancouver and #Calgary students and new grads, we're looking for co-ops and interns! Learn more here: http:\/\/t.co\/UQXA8uahnj #jobs",
    "id" : 388721627694784512,
    "created_at" : "2013-10-11 17:43:52 +0000",
    "user" : {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "protected" : false,
      "id_str" : "17349291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768212660244537344\/z_mWqOrE_normal.jpg",
      "id" : 17349291,
      "verified" : false
    }
  },
  "id" : 388722183108710400,
  "created_at" : "2013-10-11 17:46:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kimberly Voll",
      "screen_name" : "zanytomato",
      "indices" : [ 3, 14 ],
      "id_str" : "199980153",
      "id" : 199980153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/RSyWau9z1C",
      "expanded_url" : "http:\/\/zanytomato.tumblr.com\/post\/63679982430\/the-problem-with-failure-tm",
      "display_url" : "zanytomato.tumblr.com\/post\/636799824\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388472108998602752",
  "text" : "RT @zanytomato: The problem with failure... my latest blog entry: http:\/\/t.co\/RSyWau9z1C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/RSyWau9z1C",
        "expanded_url" : "http:\/\/zanytomato.tumblr.com\/post\/63679982430\/the-problem-with-failure-tm",
        "display_url" : "zanytomato.tumblr.com\/post\/636799824\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "388434997473849344",
    "text" : "The problem with failure... my latest blog entry: http:\/\/t.co\/RSyWau9z1C",
    "id" : 388434997473849344,
    "created_at" : "2013-10-10 22:44:54 +0000",
    "user" : {
      "name" : "Kimberly Voll",
      "screen_name" : "zanytomato",
      "protected" : false,
      "id_str" : "199980153",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643854888657649669\/lxeJvwds_normal.jpg",
      "id" : 199980153,
      "verified" : false
    }
  },
  "id" : 388472108998602752,
  "created_at" : "2013-10-11 01:12:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kimberly Voll",
      "screen_name" : "zanytomato",
      "indices" : [ 0, 11 ],
      "id_str" : "199980153",
      "id" : 199980153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388434997473849344",
  "geo" : { },
  "id_str" : "388470777164464128",
  "in_reply_to_user_id" : 199980153,
  "text" : "@zanytomato Liked your article! In 363 this term first-round sketches not graded but critical feedback will be shared in class. Results TBD.",
  "id" : 388470777164464128,
  "in_reply_to_status_id" : 388434997473849344,
  "created_at" : "2013-10-11 01:07:05 +0000",
  "in_reply_to_screen_name" : "zanytomato",
  "in_reply_to_user_id_str" : "199980153",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cmpt363",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/ifsBm2PPI8",
      "expanded_url" : "http:\/\/cmpt-363-133.hibbittsdesign.com\/media-library\/one-page-touch-interaction-design-checklist\/",
      "display_url" : "cmpt-363-133.hibbittsdesign.com\/media-library\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387337879262724096",
  "text" : "Made a few updates to my one-page touch interaction design checklist for #cmpt363 students http:\/\/t.co\/ifsBm2PPI8 Any suggested changes?",
  "id" : 387337879262724096,
  "created_at" : "2013-10-07 22:05:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RWD",
      "indices" : [ 23, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387311074006937600",
  "text" : "Responsive web design (#RWD) is not about how a site looks, but rather how a site works in a wider range of possible situations.",
  "id" : 387311074006937600,
  "created_at" : "2013-10-07 20:18:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/BbDbfbb9xK",
      "expanded_url" : "http:\/\/designmodo.com\/ux-responsive-design-navigation\/",
      "display_url" : "designmodo.com\/ux-responsive-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385886791523241984",
  "text" : "What\u2019s your favorite detailed article on responsive web design (non-technical) these days? My current recommendation: http:\/\/t.co\/BbDbfbb9xK",
  "id" : 385886791523241984,
  "created_at" : "2013-10-03 21:59:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385854717898682369",
  "text" : "I am looking for examples of course companion websites that are more performance support oriented - anyone know of any publicly available?",
  "id" : 385854717898682369,
  "created_at" : "2013-10-03 19:51:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Whitby",
      "screen_name" : "tomwhitby",
      "indices" : [ 3, 13 ],
      "id_str" : "17762060",
      "id" : 17762060
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CEM",
      "indices" : [ 25, 29 ]
    }, {
      "text" : "Edchat",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/rSrDFqHtV1",
      "expanded_url" : "http:\/\/bit.ly\/18TiwyE",
      "display_url" : "bit.ly\/18TiwyE"
    } ]
  },
  "geo" : { },
  "id_str" : "385834484924289024",
  "text" : "RT @tomwhitby: My latest #CEM Post: The Connected Educator Culture http:\/\/t.co\/rSrDFqHtV1 #Edchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CEM",
        "indices" : [ 10, 14 ]
      }, {
        "text" : "Edchat",
        "indices" : [ 75, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/rSrDFqHtV1",
        "expanded_url" : "http:\/\/bit.ly\/18TiwyE",
        "display_url" : "bit.ly\/18TiwyE"
      } ]
    },
    "geo" : { },
    "id_str" : "385821927996416000",
    "text" : "My latest #CEM Post: The Connected Educator Culture http:\/\/t.co\/rSrDFqHtV1 #Edchat",
    "id" : 385821927996416000,
    "created_at" : "2013-10-03 17:41:30 +0000",
    "user" : {
      "name" : "Tom Whitby",
      "screen_name" : "tomwhitby",
      "protected" : false,
      "id_str" : "17762060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601591035\/twitter_pic_1__normal.jpg",
      "id" : 17762060,
      "verified" : false
    }
  },
  "id" : 385834484924289024,
  "created_at" : "2013-10-03 18:31:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385533195854172160",
  "text" : "When I stop learning from my students it is time to pack up the teaching bag.",
  "id" : 385533195854172160,
  "created_at" : "2013-10-02 22:34:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/lKNWfvj1SO",
      "expanded_url" : "http:\/\/cmpt-363-133.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-133.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "385523731847577600",
  "text" : "I love rapid iterations - students highlighted some issues last week and revised multi-device course companion now up http:\/\/t.co\/lKNWfvj1SO",
  "id" : 385523731847577600,
  "created_at" : "2013-10-02 21:56:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]