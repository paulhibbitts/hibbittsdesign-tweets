Grailbird.data.tweets_2009_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6244870386",
  "text" : "XMind (open source mind mapping tool - http:\/\/www.xmind.net\/) works pretty well for affinity diagramming with client collaboration",
  "id" : 6244870386,
  "created_at" : "2009-12-01 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis Rosenfeld",
      "screen_name" : "louisrosenfeld",
      "indices" : [ 0, 15 ],
      "id_str" : "1760431",
      "id" : 1760431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6039539473",
  "in_reply_to_user_id" : 1760431,
  "text" : "@louisrosenfeld I find total of 2-3 hrs per consultation can be ok, to include scheduling and follow-up. TimeDriver a key scheduling tool.",
  "id" : 6039539473,
  "created_at" : "2009-11-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "louisrosenfeld",
  "in_reply_to_user_id_str" : "1760431",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Wise",
      "screen_name" : "ewise",
      "indices" : [ 0, 6 ],
      "id_str" : "14142221",
      "id" : 14142221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6015508469",
  "in_reply_to_user_id" : 14142221,
  "text" : "@ewise I prefer links for page-to-page navigation and depending on context secondary actions. Buttons for primary actions or taskflow nav.",
  "id" : 6015508469,
  "created_at" : "2009-11-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "ewise",
  "in_reply_to_user_id_str" : "14142221",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Wise",
      "screen_name" : "ewise",
      "indices" : [ 0, 6 ],
      "id_str" : "14142221",
      "id" : 14142221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6015601550",
  "in_reply_to_user_id" : 14142221,
  "text" : "@ewise You might also be interested in Nielsen's summary at http:\/\/bit.ly\/8wjXLv and this SmashingMag article http:\/\/bit.ly\/eS5a (item#9)",
  "id" : 6015601550,
  "created_at" : "2009-11-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "ewise",
  "in_reply_to_user_id_str" : "14142221",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Wise",
      "screen_name" : "ewise",
      "indices" : [ 0, 6 ],
      "id_str" : "14142221",
      "id" : 14142221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5874252625",
  "in_reply_to_user_id" : 14142221,
  "text" : "@ewise Wroblewski\u2019s form design book earned a spot in my library as well! Jarrett\u2019s and Gaffney\u2019s \u201CForms that Work\u201D is a great companion.",
  "id" : 5874252625,
  "created_at" : "2009-11-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ewise",
  "in_reply_to_user_id_str" : "14142221",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Zaki Warfel",
      "screen_name" : "zakiwarfel",
      "indices" : [ 10, 21 ],
      "id_str" : "12298822",
      "id" : 12298822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5864244199",
  "text" : "Recommend @zakiwarfel's prototyping book - contains valuable info on not just the \"how\" but more importantly the \"why\" http:\/\/bit.ly\/4qRLuV",
  "id" : 5864244199,
  "created_at" : "2009-11-19 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Jursa",
      "screen_name" : "IATV",
      "indices" : [ 0, 5 ],
      "id_str" : "17151314",
      "id" : 17151314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5810384769",
  "in_reply_to_user_id" : 17151314,
  "text" : "@IATV PowerPoint (ubiquitous) with pre-made UI widgets + DocVerse. Familiar tool, local\/cloud sync, group edits, comments & versioning.",
  "id" : 5810384769,
  "created_at" : "2009-11-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "IATV",
  "in_reply_to_user_id_str" : "17151314",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5770812573",
  "text" : "A pattern-based usability inspection (w. smaller tasks) can be an effective complement to a contextual-inquiry (w. larger tasks).",
  "id" : 5770812573,
  "created_at" : "2009-11-16 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBM Design",
      "screen_name" : "ibmdesign",
      "indices" : [ 102, 112 ],
      "id_str" : "17503114",
      "id" : 17503114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5771110427",
  "text" : "\"The user\u2019s time is more valuable than ours. Respect it. Good UI design is humble.\u201D Jono DiCarlo (via @ibmdesign)",
  "id" : 5771110427,
  "created_at" : "2009-11-16 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Cadsawan",
      "screen_name" : "rainer3",
      "indices" : [ 27, 35 ],
      "id_str" : "11201492",
      "id" : 11201492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5696540239",
  "text" : "Very insightful UX tip: RT @rainer3: \"Understanding your client is as important as understanding their audience.\" http:\/\/bit.ly\/26JaA1",
  "id" : 5696540239,
  "created_at" : "2009-11-14 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5488772547",
  "text" : "Excellent collection of search-related articles posted at UC Berkeley http:\/\/flamenco.berkeley.edu\/pubs.html",
  "id" : 5488772547,
  "created_at" : "2009-11-06 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5377473430",
  "text" : "Very extensive list of tips for working in virtual teams via Requirements Defined\/Thiagi http:\/\/bit.ly\/1qcUA7",
  "id" : 5377473430,
  "created_at" : "2009-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]