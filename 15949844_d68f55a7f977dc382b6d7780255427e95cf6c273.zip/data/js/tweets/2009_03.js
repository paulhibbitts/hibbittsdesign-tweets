Grailbird.data.tweets_2009_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "axure rp",
      "screen_name" : "axurerp",
      "indices" : [ 11, 19 ],
      "id_str" : "18772894",
      "id" : 18772894
    }, {
      "name" : "Jim Callender",
      "screen_name" : "JimCallender",
      "indices" : [ 24, 37 ],
      "id_str" : "12854",
      "id" : 12854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1389167987",
  "text" : "Retweeting @axurerp: RT @JimCallender: 16 Design Tools for Prototyping & Wireframing http:\/\/tinyurl.com\/c4e4mu fav? Axure RP, Sketches ( ...",
  "id" : 1389167987,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 71, 74 ]
    }, {
      "text" : "usability",
      "indices" : [ 75, 85 ]
    }, {
      "text" : "ucd",
      "indices" : [ 86, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1378469871",
  "text" : "Just added myself to the http:\/\/wefollow.com twitter directory under:  #ux #usability #ucd",
  "id" : 1378469871,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1350229170",
  "text" : "Exploring the just released Expression Blend 3 preview http:\/\/is.gd\/nTXM",
  "id" : 1350229170,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1281322242",
  "text" : "Mobile UI design resources wiki http:\/\/tinyurl.com\/9b7nr3 via www.diigo.com\/~paulhibbitts",
  "id" : 1281322242,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]