Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/o82m1Pf4",
      "expanded_url" : "http:\/\/www.lukew.com\/ff\/entry.asp?1594",
      "display_url" : "lukew.com\/ff\/entry.asp?1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "228643684965564417",
  "text" : "RT @lukew: Yep. I agree, this is exciting stuff :)\nhttp:\/\/t.co\/o82m1Pf4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/o82m1Pf4",
        "expanded_url" : "http:\/\/www.lukew.com\/ff\/entry.asp?1594",
        "display_url" : "lukew.com\/ff\/entry.asp?1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "228639006643068928",
    "text" : "Yep. I agree, this is exciting stuff :)\nhttp:\/\/t.co\/o82m1Pf4",
    "id" : 228639006643068928,
    "created_at" : "2012-07-26 23:52:41 +0000",
    "user" : {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "protected" : false,
      "id_str" : "13889622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477610446917103616\/_cjU3_ga_normal.png",
      "id" : 13889622,
      "verified" : false
    }
  },
  "id" : 228643684965564417,
  "created_at" : "2012-07-27 00:11:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtain Revenue",
      "screen_name" : "corvustweets",
      "indices" : [ 0, 13 ],
      "id_str" : "2503692858",
      "id" : 2503692858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228627554884534275",
  "text" : "@corvustweets Perhaps we should look at things as multi-display UX in addition to multi-device? Multi-display UX is more what I am thinking.",
  "id" : 228627554884534275,
  "created_at" : "2012-07-26 23:07:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BraveNewCode",
      "screen_name" : "BraveNewCode",
      "indices" : [ 0, 13 ],
      "id_str" : "89039840",
      "id" : 89039840
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WPtouchProTips",
      "indices" : [ 35, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/Gp1vNnPd",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/mobilelearningux-demo\/",
      "display_url" : "hibbittsdesign.com\/courses\/mobile\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "228608227363913728",
  "in_reply_to_user_id" : 15478959,
  "text" : "@bravenewcode http:\/\/t.co\/Gp1vNnPd #WPtouchProTips Using WPtouch for device specific (Apple) + responsive design theme for Android &amp; others",
  "id" : 228608227363913728,
  "created_at" : "2012-07-26 21:50:23 +0000",
  "in_reply_to_screen_name" : "wptouch",
  "in_reply_to_user_id_str" : "15478959",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtain Revenue",
      "screen_name" : "corvustweets",
      "indices" : [ 0, 13 ],
      "id_str" : "2503692858",
      "id" : 2503692858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228585467149434881",
  "text" : "@corvustweets I did not notice this at first, thanks for pointing it out! Love to see multi-device experiences start to get some love.",
  "id" : 228585467149434881,
  "created_at" : "2012-07-26 20:19:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228277604174663680",
  "text" : "Favourite tool combination for my current web app UX analysis project: Evernote + Skitch. Smooth note taking and annotation workflow.",
  "id" : 228277604174663680,
  "created_at" : "2012-07-25 23:56:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtain Revenue",
      "screen_name" : "corvustweets",
      "indices" : [ 0, 13 ],
      "id_str" : "2503692858",
      "id" : 2503692858
    }, {
      "name" : "Tylor Sherman",
      "screen_name" : "tylorsherman",
      "indices" : [ 47, 60 ],
      "id_str" : "6274112",
      "id" : 6274112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227928736044052480",
  "text" : "@corvustweets It was my pleasure. Nice to meet @tylorsherman as well!",
  "id" : 227928736044052480,
  "created_at" : "2012-07-25 00:50:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227927218158989312",
  "text" : "It's really not enough to be just mobile-friendly - consider how best to support mobility and deliver multi-screen user experiences.",
  "id" : 227927218158989312,
  "created_at" : "2012-07-25 00:44:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/rU5r7Gpw",
      "expanded_url" : "http:\/\/cstudies.ubc.ca\/a\/Course\/Essentials-of-User-Experience-Design-for-Mobile-Learning-New\/IY101\/",
      "display_url" : "cstudies.ubc.ca\/a\/Course\/Essen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "227821963358375936",
  "text" : "My upcoming workshop on mobile learning UX has just been opened for registration at http:\/\/t.co\/rU5r7Gpw",
  "id" : 227821963358375936,
  "created_at" : "2012-07-24 17:46:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/NN6Tugyi",
      "expanded_url" : "http:\/\/chronicle.com\/blogs\/profhacker\/planning-a-class-with-backward-design\/33625",
      "display_url" : "chronicle.com\/blogs\/profhack\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223533402534584321",
  "text" : "From an instructional design viewpoint, Backward Design (Wiggins &amp; McTighe) really resonates w. me for mobile learning http:\/\/t.co\/NN6Tugyi",
  "id" : 223533402534584321,
  "created_at" : "2012-07-12 21:44:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/XEdXswJq",
      "expanded_url" : "http:\/\/www.mindmeister.com\/158973865\/essentials-of-user-experience-design-for-mobile-learning",
      "display_url" : "mindmeister.com\/158973865\/esse\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223163621495144448",
  "text" : "Outline for my Essentials of User Experience Design for Mobile Learning Workshop http:\/\/t.co\/XEdXswJq Comments or suggestions appreciated.",
  "id" : 223163621495144448,
  "created_at" : "2012-07-11 21:15:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlearning",
      "indices" : [ 113, 123 ]
    }, {
      "text" : "ux",
      "indices" : [ 124, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223132648992817153",
  "text" : "Other than learning goals, is there anything more important than user experience when designing mobile learning? #mlearning #ux",
  "id" : 223132648992817153,
  "created_at" : "2012-07-11 19:12:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/Fo0mhhzM",
      "expanded_url" : "http:\/\/wpsurvey.polldaddy.com\/s\/wp-2012?src=pio",
      "display_url" : "wpsurvey.polldaddy.com\/s\/wp-2012?src=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222895604190298112",
  "text" : "I've just taken the WordPress 2012 User and Developer Survey, have you? http:\/\/t.co\/Fo0mhhzM (pass it on!)",
  "id" : 222895604190298112,
  "created_at" : "2012-07-11 03:30:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 3, 19 ],
      "id_str" : "17349291",
      "id" : 17349291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 112, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/Jfe3Q2DW",
      "expanded_url" : "http:\/\/www.habaneroconsulting.com\/WorkHere\/?gnk=job&gni=8ad8dbd138488f9301384ec055082ae5&gns=Twitter",
      "display_url" : "habaneroconsulting.com\/WorkHere\/?gnk=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222803537963393024",
  "text" : "RT @HabaneroConsult: We're looking to hire an interaction design co-op student in Calgary! http:\/\/t.co\/Jfe3Q2DW #ux",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ux",
        "indices" : [ 91, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/Jfe3Q2DW",
        "expanded_url" : "http:\/\/www.habaneroconsulting.com\/WorkHere\/?gnk=job&gni=8ad8dbd138488f9301384ec055082ae5&gns=Twitter",
        "display_url" : "habaneroconsulting.com\/WorkHere\/?gnk=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "222801140616667136",
    "text" : "We're looking to hire an interaction design co-op student in Calgary! http:\/\/t.co\/Jfe3Q2DW #ux",
    "id" : 222801140616667136,
    "created_at" : "2012-07-10 21:15:06 +0000",
    "user" : {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "protected" : false,
      "id_str" : "17349291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768212660244537344\/z_mWqOrE_normal.jpg",
      "id" : 17349291,
      "verified" : false
    }
  },
  "id" : 222803537963393024,
  "created_at" : "2012-07-10 21:24:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/Gp1vNnPd",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/mobilelearningux-demo\/",
      "display_url" : "hibbittsdesign.com\/courses\/mobile\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222391512942641153",
  "text" : "Example device specific (Apple) + responsive design (Android &amp; others) mobile course companion for mlearning ux course http:\/\/t.co\/Gp1vNnPd",
  "id" : 222391512942641153,
  "created_at" : "2012-07-09 18:07:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Usabilla",
      "screen_name" : "usabilla",
      "indices" : [ 75, 84 ],
      "id_str" : "16601140",
      "id" : 16601140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/5Z7rNdTy",
      "expanded_url" : "http:\/\/blog.usabilla.com\/how-to-design-for-the-user-experience\/",
      "display_url" : "blog.usabilla.com\/how-to-design-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "220171314143559680",
  "text" : "Why The User Experience Can Or Cannot Be Designed http:\/\/t.co\/5Z7rNdTy via @usabilla &lt;- I fully agree with the viewpoint of designing for UX",
  "id" : 220171314143559680,
  "created_at" : "2012-07-03 15:05:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]