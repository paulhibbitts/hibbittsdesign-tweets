Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "effectiveui",
      "screen_name" : "effectiveui",
      "indices" : [ 3, 15 ],
      "id_str" : "14627322",
      "id" : 14627322
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ixd13",
      "indices" : [ 21, 27 ]
    }, {
      "text" : "EffectiveUI",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/MCGwJdUm",
      "expanded_url" : "http:\/\/effectiveuiatixd13.tumblr.com\/",
      "display_url" : "effectiveuiatixd13.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "297128476308291585",
  "text" : "RT @effectiveui: See #ixd13 daily insights from the #EffectiveUI team at http:\/\/t.co\/MCGwJdUm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ixd13",
        "indices" : [ 4, 10 ]
      }, {
        "text" : "EffectiveUI",
        "indices" : [ 35, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/MCGwJdUm",
        "expanded_url" : "http:\/\/effectiveuiatixd13.tumblr.com\/",
        "display_url" : "effectiveuiatixd13.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "297127163252068352",
    "text" : "See #ixd13 daily insights from the #EffectiveUI team at http:\/\/t.co\/MCGwJdUm",
    "id" : 297127163252068352,
    "created_at" : "2013-01-31 23:40:10 +0000",
    "user" : {
      "name" : "effectiveui",
      "screen_name" : "effectiveui",
      "protected" : false,
      "id_str" : "14627322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760186329514803200\/np6gVDUY_normal.jpg",
      "id" : 14627322,
      "verified" : false
    }
  },
  "id" : 297128476308291585,
  "created_at" : "2013-01-31 23:45:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanadaMoot",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/u1WKn6U1",
      "expanded_url" : "http:\/\/uxfundamentals.com\/moodle\/",
      "display_url" : "uxfundamentals.com\/moodle\/"
    } ]
  },
  "geo" : { },
  "id_str" : "297114519522652161",
  "text" : "A preview of my multi-screen friendly Moodle demo site for #CanadaMoot now at http:\/\/t.co\/u1WKn6U1 Thanks to all past CMPT-363 students!",
  "id" : 297114519522652161,
  "created_at" : "2013-01-31 22:49:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 0, 11 ],
      "id_str" : "28429477",
      "id" : 28429477
    }, {
      "name" : "Lambda Solutions",
      "screen_name" : "lambdasolutions",
      "indices" : [ 12, 28 ],
      "id_str" : "86378776",
      "id" : 86378776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297112516008505344",
  "in_reply_to_user_id" : 28429477,
  "text" : "@chadleaman @lambdasolutions Thanks very much for inviting me to the Canada MoodleMoot Preview Webinar today. Greatly enjoyed it!",
  "id" : 297112516008505344,
  "created_at" : "2013-01-31 22:41:58 +0000",
  "in_reply_to_screen_name" : "chadleaman",
  "in_reply_to_user_id_str" : "28429477",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IDEO",
      "screen_name" : "ideo",
      "indices" : [ 3, 8 ],
      "id_str" : "23462787",
      "id" : 23462787
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edu",
      "indices" : [ 114, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/sjuY9RZo",
      "expanded_url" : "http:\/\/ideo.is\/WeljNz",
      "display_url" : "ideo.is\/WeljNz"
    } ]
  },
  "geo" : { },
  "id_str" : "296750887727165441",
  "text" : "RT @ideo: Have you checked out the 2nd edition of the Design Thinking for Educators toolkit? http:\/\/t.co\/sjuY9RZo #edu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edu",
        "indices" : [ 104, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/sjuY9RZo",
        "expanded_url" : "http:\/\/ideo.is\/WeljNz",
        "display_url" : "ideo.is\/WeljNz"
      } ]
    },
    "geo" : { },
    "id_str" : "296459063989006336",
    "text" : "Have you checked out the 2nd edition of the Design Thinking for Educators toolkit? http:\/\/t.co\/sjuY9RZo #edu",
    "id" : 296459063989006336,
    "created_at" : "2013-01-30 03:25:23 +0000",
    "user" : {
      "name" : "IDEO",
      "screen_name" : "ideo",
      "protected" : false,
      "id_str" : "23462787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760208707682603008\/HgqAWOLi_normal.jpg",
      "id" : 23462787,
      "verified" : true
    }
  },
  "id" : 296750887727165441,
  "created_at" : "2013-01-30 22:44:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lambda Solutions",
      "screen_name" : "lambdasolutions",
      "indices" : [ 3, 19 ],
      "id_str" : "86378776",
      "id" : 86378776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moodle",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/kycbsglj",
      "expanded_url" : "http:\/\/bit.ly\/SXlY5k",
      "display_url" : "bit.ly\/SXlY5k"
    } ]
  },
  "geo" : { },
  "id_str" : "296745515238961152",
  "text" : "MT @lambdasolutions Blog Post: Preview the 2013 Canada Moodle Moot - Free Webinar http:\/\/t.co\/kycbsglj #moodle  &lt;-Looking forward to it!",
  "id" : 296745515238961152,
  "created_at" : "2013-01-30 22:23:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eLearning Learning",
      "screen_name" : "elearningPosts",
      "indices" : [ 3, 18 ],
      "id_str" : "31521133",
      "id" : 31521133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/F92AFWDr",
      "expanded_url" : "http:\/\/bit.ly\/VgrU8m",
      "display_url" : "bit.ly\/VgrU8m"
    } ]
  },
  "geo" : { },
  "id_str" : "295909650346418176",
  "text" : "RT @elearningPosts: LearnDash Launches The WordPress LMS Total Solution http:\/\/t.co\/F92AFWDr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/F92AFWDr",
        "expanded_url" : "http:\/\/bit.ly\/VgrU8m",
        "display_url" : "bit.ly\/VgrU8m"
      } ]
    },
    "geo" : { },
    "id_str" : "295838209496190976",
    "text" : "LearnDash Launches The WordPress LMS Total Solution http:\/\/t.co\/F92AFWDr",
    "id" : 295838209496190976,
    "created_at" : "2013-01-28 10:18:20 +0000",
    "user" : {
      "name" : "eLearning Learning",
      "screen_name" : "elearningPosts",
      "protected" : false,
      "id_str" : "31521133",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755849131982073860\/r3MdXSlP_normal.jpg",
      "id" : 31521133,
      "verified" : false
    }
  },
  "id" : 295909650346418176,
  "created_at" : "2013-01-28 15:02:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "selma zafar",
      "screen_name" : "selmaz",
      "indices" : [ 0, 7 ],
      "id_str" : "36598690",
      "id" : 36598690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294943889394126849",
  "geo" : { },
  "id_str" : "294946467108499457",
  "in_reply_to_user_id" : 36598690,
  "text" : "@selmaz That's a really good list! While touched upon, perhaps communication and collaboration might deserve to be separately highlighted?",
  "id" : 294946467108499457,
  "in_reply_to_status_id" : 294943889394126849,
  "created_at" : "2013-01-25 23:14:52 +0000",
  "in_reply_to_screen_name" : "selmaz",
  "in_reply_to_user_id_str" : "36598690",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294881646031802368",
  "text" : "Any recommendations for a freelance visual interface designer in Vancouver who also has experience with SharePoint?",
  "id" : 294881646031802368,
  "created_at" : "2013-01-25 18:57:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "indices" : [ 45, 55 ],
      "id_str" : "18983561",
      "id" : 18983561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanadaMoot",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/mZjjB9XB",
      "expanded_url" : "http:\/\/twitpic.com\/bxp4fa",
      "display_url" : "twitpic.com\/bxp4fa"
    } ]
  },
  "geo" : { },
  "id_str" : "294219288712196096",
  "text" : "Sneak peek of my RWD\/mobile Moodle demo with @basbrands open source Bootstrap theme. More to share at #CanadaMoot http:\/\/t.co\/mZjjB9XB",
  "id" : 294219288712196096,
  "created_at" : "2013-01-23 23:05:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Lee",
      "screen_name" : "riacale",
      "indices" : [ 3, 11 ],
      "id_str" : "15093343",
      "id" : 15093343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/1yatA5Hc",
      "expanded_url" : "http:\/\/www.woothemes.com\/2013\/01\/teaching-with-wordpress-just-got-easy\/",
      "display_url" : "woothemes.com\/2013\/01\/teachi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "293755487902638082",
  "text" : "RT @riacale: Sensei: a WordPress LMS plugin http:\/\/t.co\/1yatA5Hc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/1yatA5Hc",
        "expanded_url" : "http:\/\/www.woothemes.com\/2013\/01\/teaching-with-wordpress-just-got-easy\/",
        "display_url" : "woothemes.com\/2013\/01\/teachi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "293477033416200192",
    "text" : "Sensei: a WordPress LMS plugin http:\/\/t.co\/1yatA5Hc",
    "id" : 293477033416200192,
    "created_at" : "2013-01-21 21:55:51 +0000",
    "user" : {
      "name" : "Zack Lee",
      "screen_name" : "riacale",
      "protected" : false,
      "id_str" : "15093343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438305981013819394\/7lOP91uk_normal.jpeg",
      "id" : 15093343,
      "verified" : false
    }
  },
  "id" : 293755487902638082,
  "created_at" : "2013-01-22 16:22:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 0, 11 ],
      "id_str" : "28429477",
      "id" : 28429477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290537894098128896",
  "geo" : { },
  "id_str" : "290624639909126144",
  "in_reply_to_user_id" : 28429477,
  "text" : "@chadleaman Thanks very much for the kind offer! Please email me (paul at paulhibbitts dot com) and we can take things from there.",
  "id" : 290624639909126144,
  "in_reply_to_status_id" : 290537894098128896,
  "created_at" : "2013-01-14 01:01:28 +0000",
  "in_reply_to_screen_name" : "chadleaman",
  "in_reply_to_user_id_str" : "28429477",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289786605739331584",
  "text" : "After a few days with a Lenovo IdeaPad Yoga my MacBook Air sure seems quaint without a touchscreen.",
  "id" : 289786605739331584,
  "created_at" : "2013-01-11 17:31:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 3, 7 ],
      "id_str" : "1063291",
      "id" : 1063291
    }, {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 37, 43 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uievs",
      "indices" : [ 89, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/5WuOzzue",
      "expanded_url" : "http:\/\/ar.gy\/2~fL",
      "display_url" : "ar.gy\/2~fL"
    } ]
  },
  "geo" : { },
  "id_str" : "289422780007591936",
  "text" : "RT @UIE Today's Virtual Seminar with @lukew starts in just a few hours.  Follow along at #uievs http:\/\/t.co\/5WuOzzue &lt;-Looking forward to it",
  "id" : 289422780007591936,
  "created_at" : "2013-01-10 17:25:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/UdaEeU7e",
      "expanded_url" : "http:\/\/uxmag.com\/articles\/re-introducing-page-description-diagrams#.UO4cbrtvxiQ.twitter",
      "display_url" : "uxmag.com\/articles\/re-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289186269978820608",
  "text" : "Re-Introducing Page Description Diagrams http:\/\/t.co\/UdaEeU7e &lt;- One of my long-term favorite techniques!",
  "id" : 289186269978820608,
  "created_at" : "2013-01-10 01:45:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Croydon",
      "screen_name" : "mc",
      "indices" : [ 3, 6 ],
      "id_str" : "753",
      "id" : 753
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mc\/status\/289090058919768065\/photo\/1",
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/sMYjdWNp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAMN4H5CcAA7k66.jpg",
      "id_str" : "289090058923962368",
      "id" : 289090058923962368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAMN4H5CcAA7k66.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/sMYjdWNp"
    } ],
    "hashtags" : [ {
      "text" : "bornmobile",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289119503013523456",
  "text" : "RT @mc: Qualcomm totally gets mobile. #bornmobile http:\/\/t.co\/sMYjdWNp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mc\/status\/289090058919768065\/photo\/1",
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/sMYjdWNp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BAMN4H5CcAA7k66.jpg",
        "id_str" : "289090058923962368",
        "id" : 289090058923962368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAMN4H5CcAA7k66.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/sMYjdWNp"
      } ],
      "hashtags" : [ {
        "text" : "bornmobile",
        "indices" : [ 30, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289090058919768065",
    "text" : "Qualcomm totally gets mobile. #bornmobile http:\/\/t.co\/sMYjdWNp",
    "id" : 289090058919768065,
    "created_at" : "2013-01-09 19:23:36 +0000",
    "user" : {
      "name" : "Matt Croydon",
      "screen_name" : "mc",
      "protected" : false,
      "id_str" : "753",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755726874874028032\/a5vcogvY_normal.jpg",
      "id" : 753,
      "verified" : false
    }
  },
  "id" : 289119503013523456,
  "created_at" : "2013-01-09 21:20:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 3, 15 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 122, 125 ]
    }, {
      "text" : "jobs",
      "indices" : [ 126, 131 ]
    }, {
      "text" : "vancouver",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/2wiCcHzu",
      "expanded_url" : "http:\/\/bit.ly\/WzwOdG",
      "display_url" : "bit.ly\/WzwOdG"
    } ]
  },
  "geo" : { },
  "id_str" : "289072079410720769",
  "text" : "RT @openroadies: Have a passion for user experience design? Want to join a great team? We're hiring. http:\/\/t.co\/2wiCcHzu #ux #jobs #van ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ux",
        "indices" : [ 105, 108 ]
      }, {
        "text" : "jobs",
        "indices" : [ 109, 114 ]
      }, {
        "text" : "vancouver",
        "indices" : [ 115, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/2wiCcHzu",
        "expanded_url" : "http:\/\/bit.ly\/WzwOdG",
        "display_url" : "bit.ly\/WzwOdG"
      } ]
    },
    "geo" : { },
    "id_str" : "289067808095076353",
    "text" : "Have a passion for user experience design? Want to join a great team? We're hiring. http:\/\/t.co\/2wiCcHzu #ux #jobs #vancouver",
    "id" : 289067808095076353,
    "created_at" : "2013-01-09 17:55:10 +0000",
    "user" : {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "protected" : false,
      "id_str" : "66913866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554783440747237376\/HA2Svg4h_normal.png",
      "id" : 66913866,
      "verified" : false
    }
  },
  "id" : 289072079410720769,
  "created_at" : "2013-01-09 18:12:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/CzIMj2IM",
      "expanded_url" : "http:\/\/www.mindmeister.com\/233818108\/moodlemoot-2013-canada-mobile-learning-ux",
      "display_url" : "mindmeister.com\/233818108\/mood\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288760582360944642",
  "text" : "An updated visual outline for my Canada MoodleMoot 2013 presentation on mobile learning user experience (UX) design http:\/\/t.co\/CzIMj2IM",
  "id" : 288760582360944642,
  "created_at" : "2013-01-08 21:34:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baldwin",
      "screen_name" : "benry",
      "indices" : [ 3, 9 ],
      "id_str" : "1969441",
      "id" : 1969441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/L4FVg3dv",
      "expanded_url" : "http:\/\/central1.com\/jobs\/displayjob.php?sp=565&type=SE&jid=0",
      "display_url" : "central1.com\/jobs\/displayjo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288682257491832833",
  "text" : "RT @benry: I'm hiring a BA for a 1-year mat leave. If you know anyone let me know, apply here: http:\/\/t.co\/L4FVg3dv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/L4FVg3dv",
        "expanded_url" : "http:\/\/central1.com\/jobs\/displayjob.php?sp=565&type=SE&jid=0",
        "display_url" : "central1.com\/jobs\/displayjo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "288666989348659200",
    "text" : "I'm hiring a BA for a 1-year mat leave. If you know anyone let me know, apply here: http:\/\/t.co\/L4FVg3dv",
    "id" : 288666989348659200,
    "created_at" : "2013-01-08 15:22:28 +0000",
    "user" : {
      "name" : "Scott Baldwin",
      "screen_name" : "benry",
      "protected" : false,
      "id_str" : "1969441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573733440186511360\/TYW5qsNh_normal.png",
      "id" : 1969441,
      "verified" : false
    }
  },
  "id" : 288682257491832833,
  "created_at" : "2013-01-08 16:23:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "indices" : [ 3, 13 ],
      "id_str" : "18983561",
      "id" : 18983561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moodle",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 95 ],
      "url" : "https:\/\/t.co\/agyw4eZi",
      "expanded_url" : "https:\/\/moodle.org\/plugins\/view.php?plugin=theme_bootstrap",
      "display_url" : "moodle.org\/plugins\/view.p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287323863723954176",
  "text" : "RT @basbrands: I have just released a new version of the bootstrap theme: https:\/\/t.co\/agyw4eZi for #moodle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "moodle",
        "indices" : [ 85, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 80 ],
        "url" : "https:\/\/t.co\/agyw4eZi",
        "expanded_url" : "https:\/\/moodle.org\/plugins\/view.php?plugin=theme_bootstrap",
        "display_url" : "moodle.org\/plugins\/view.p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "286789913783988224",
    "text" : "I have just released a new version of the bootstrap theme: https:\/\/t.co\/agyw4eZi for #moodle",
    "id" : 286789913783988224,
    "created_at" : "2013-01-03 11:03:38 +0000",
    "user" : {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "protected" : false,
      "id_str" : "18983561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570499815742521344\/KPZ0dxP5_normal.png",
      "id" : 18983561,
      "verified" : false
    }
  },
  "id" : 287323863723954176,
  "created_at" : "2013-01-04 22:25:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/ViNhYMvl",
      "expanded_url" : "http:\/\/www.the-mobile-book.com\/",
      "display_url" : "the-mobile-book.com"
    } ]
  },
  "geo" : { },
  "id_str" : "286536120416747520",
  "text" : "First read of the new year http:\/\/t.co\/ViNhYMvl Especially looking forward to chapters by Stephanie Rieger, Brad Frost, and Josh Clark.",
  "id" : 286536120416747520,
  "created_at" : "2013-01-02 18:15:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]