Grailbird.data.tweets_2014_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Neeman",
      "screen_name" : "usabilitycounts",
      "indices" : [ 3, 19 ],
      "id_str" : "14340145",
      "id" : 14340145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494645764824391680",
  "text" : "RT @usabilitycounts: Your users may not care about a beautiful UI, they might just want to get work done quickly and easily. Remember that.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494622544255655937",
    "text" : "Your users may not care about a beautiful UI, they might just want to get work done quickly and easily. Remember that.",
    "id" : 494622544255655937,
    "created_at" : "2014-07-30 23:16:18 +0000",
    "user" : {
      "name" : "Patrick Neeman",
      "screen_name" : "usabilitycounts",
      "protected" : false,
      "id_str" : "14340145",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760320782241181696\/ovdisD-2_normal.jpg",
      "id" : 14340145,
      "verified" : false
    }
  },
  "id" : 494645764824391680,
  "created_at" : "2014-07-31 00:48:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 39, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/fzz85FsBA3",
      "expanded_url" : "http:\/\/www.gliffy.com\/go\/publish\/6005307",
      "display_url" : "gliffy.com\/go\/publish\/600\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494153368017702913",
  "text" : "Updated design process and toolkit for #SFU CMPT-363 course this September http:\/\/t.co\/fzz85FsBA3",
  "id" : 494153368017702913,
  "created_at" : "2014-07-29 16:11:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493853660846518272",
  "text" : "Pretty happy with the results of using empathy maps + job stories as alternative to personas + user stories. Any similar experiences?",
  "id" : 493853660846518272,
  "created_at" : "2014-07-28 20:21:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/qOGufDAexb",
      "expanded_url" : "http:\/\/uxmag.com\/articles\/creating-outstanding-experiences-for-digital-natives?utm_source=feedblitz&utm_medium=FeedBlitzRss&utm_campaign=uxm",
      "display_url" : "uxmag.com\/articles\/creat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "492792362200883201",
  "text" : "Creating Outstanding Experiences for Digital Natives | UX Magazine http:\/\/t.co\/qOGufDAexb",
  "id" : 492792362200883201,
  "created_at" : "2014-07-25 22:03:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 50, 59 ],
      "id_str" : "837060721",
      "id" : 837060721
    }, {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 63, 72 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/zflJ2JKA31",
      "expanded_url" : "http:\/\/www.linkedin.com\/today\/post\/article\/20140725201405-7662998-if-you-see-the-l2-data-on-the-road-kill-it",
      "display_url" : "linkedin.com\/today\/post\/art\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "492788954429534209",
  "text" : "\"If You See the L2 Data on the Road, Kill It.\" by @m_travin on @LinkedIn http:\/\/t.co\/zflJ2JKA31",
  "id" : 492788954429534209,
  "created_at" : "2014-07-25 21:50:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/xXLuhlCQ5V",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/16304\/",
      "display_url" : "canvas.sfu.ca\/courses\/16304\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492391024472256512",
  "text" : "#SFU Fall term open enrollment begins Saturday. Students interested in CMPT-363 can preview the course companion https:\/\/t.co\/xXLuhlCQ5V",
  "id" : 492391024472256512,
  "created_at" : "2014-07-24 19:29:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Elliot",
      "screen_name" : "Pellio",
      "indices" : [ 3, 10 ],
      "id_str" : "23626629",
      "id" : 23626629
    }, {
      "name" : "UXPin",
      "screen_name" : "uxpin",
      "indices" : [ 106, 112 ],
      "id_str" : "211100214",
      "id" : 211100214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/4JPc9IybW2",
      "expanded_url" : "http:\/\/uxpin.com\/knowledge.html",
      "display_url" : "uxpin.com\/knowledge.html"
    } ]
  },
  "geo" : { },
  "id_str" : "492078993446043648",
  "text" : "RT @Pellio: Five free books on UX, mobile UI design patterns and wireframing to download from the folk at @uxpin http:\/\/t.co\/4JPc9IybW2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UXPin",
        "screen_name" : "uxpin",
        "indices" : [ 94, 100 ],
        "id_str" : "211100214",
        "id" : 211100214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/4JPc9IybW2",
        "expanded_url" : "http:\/\/uxpin.com\/knowledge.html",
        "display_url" : "uxpin.com\/knowledge.html"
      } ]
    },
    "geo" : { },
    "id_str" : "490064810269478912",
    "text" : "Five free books on UX, mobile UI design patterns and wireframing to download from the folk at @uxpin http:\/\/t.co\/4JPc9IybW2",
    "id" : 490064810269478912,
    "created_at" : "2014-07-18 09:25:30 +0000",
    "user" : {
      "name" : "Paul Elliot",
      "screen_name" : "Pellio",
      "protected" : false,
      "id_str" : "23626629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651158576262545408\/UXhE2TvW_normal.jpg",
      "id" : 23626629,
      "verified" : false
    }
  },
  "id" : 492078993446043648,
  "created_at" : "2014-07-23 22:49:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 23, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/41IQ2x63S0",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/a87abf5f-0af8-2554-73e3-e86bdddac667\/",
      "display_url" : "workflowy.com\/shared\/a87abf5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "492077349249495040",
  "text" : "Updated topic list for #SFU CMPT-363 https:\/\/t.co\/41IQ2x63S0",
  "id" : 492077349249495040,
  "created_at" : "2014-07-23 22:42:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491593752457129984",
  "geo" : { },
  "id_str" : "491695741031555072",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Sounds like a plan, have a great vacation!",
  "id" : 491695741031555072,
  "in_reply_to_status_id" : 491593752457129984,
  "created_at" : "2014-07-22 21:26:14 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491584223724072962",
  "geo" : { },
  "id_str" : "491588045628387328",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Indeed it is \u263A Giving a multi-device learning experiences workshop in Victoria. We are due for a coffee in Van sometime soon!",
  "id" : 491588045628387328,
  "in_reply_to_status_id" : 491584223724072962,
  "created_at" : "2014-07-22 14:18:18 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/491583951807332353\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/5BDYIH5QOB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtJ0_TqCIAAotrR.jpg",
      "id_str" : "491583940293959680",
      "id" : 491583940293959680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtJ0_TqCIAAotrR.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5BDYIH5QOB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491583951807332353",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Channeling you this morning Holly. http:\/\/t.co\/5BDYIH5QOB",
  "id" : 491583951807332353,
  "created_at" : "2014-07-22 14:02:01 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491330291407917056",
  "text" : "Teaching to me in 2014:\n\u25AA Curation, not content creation\n\u25AA Discussions, not presentations\n\u25AA Actual work products, not throw-away assignments",
  "id" : 491330291407917056,
  "created_at" : "2014-07-21 21:14:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/eL1oK7iHSc",
      "expanded_url" : "http:\/\/www.feld.com\/archives\/2011\/08\/the-techstars-mentor-manifesto.html",
      "display_url" : "feld.com\/archives\/2011\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "491279186468667392",
  "text" : "The TechStars Mentor Manifesto http:\/\/t.co\/eL1oK7iHSc Really digging these as practical guiding principles for mentoring!",
  "id" : 491279186468667392,
  "created_at" : "2014-07-21 17:51:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/s9OKVHd1dh",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/multi-device-moodle-learning-experiences-open-school-bc",
      "display_url" : "slides.com\/paulhibbitts\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489531128575836160",
  "text" : "Final draft slides for my multi-device Moodle learning experiences workshop at Open School BC next week http:\/\/t.co\/s9OKVHd1dh",
  "id" : 489531128575836160,
  "created_at" : "2014-07-16 22:04:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kato.im",
      "screen_name" : "kato_im",
      "indices" : [ 13, 21 ],
      "id_str" : "1026990656",
      "id" : 1026990656
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/489529537982517248\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/EI9zjzzX1K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BssohR7CYAAH4u9.png",
      "id_str" : "489529536711647232",
      "id" : 489529536711647232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BssohR7CYAAH4u9.png",
      "sizes" : [ {
        "h" : 838,
        "resize" : "fit",
        "w" : 1219
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EI9zjzzX1K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489529537982517248",
  "text" : "More plans w @kato_im in CMPT-363 course; private mentoring\/coaching, student groups, course forum, &amp; class liveblogs http:\/\/t.co\/EI9zjzzX1K",
  "id" : 489529537982517248,
  "created_at" : "2014-07-16 21:58:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/1jCI2vILRd",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/70689867-6f5e-6f1c-fca9-ba0396959552\/",
      "display_url" : "workflowy.com\/shared\/7068986\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "488822115273949185",
  "text" : "Updated relationship + tool\/platform success factors for online mentoring and coaching: https:\/\/t.co\/1jCI2vILRd",
  "id" : 488822115273949185,
  "created_at" : "2014-07-14 23:07:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walt Mossberg",
      "screen_name" : "waltmossberg",
      "indices" : [ 3, 16 ],
      "id_str" : "5746452",
      "id" : 5746452
    }, {
      "name" : "Walt Mossberg",
      "screen_name" : "waltmossberg",
      "indices" : [ 101, 114 ],
      "id_str" : "5746452",
      "id" : 5746452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/neUOYwBlY2",
      "expanded_url" : "http:\/\/on.recode.net\/1pXdsEC",
      "display_url" : "on.recode.net\/1pXdsEC"
    } ]
  },
  "geo" : { },
  "id_str" : "487019084379209730",
  "text" : "RT @waltmossberg: Apple, Google begin blending the smartphone and the PC. http:\/\/t.co\/neUOYwBlY2 via @waltmossberg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Walt Mossberg",
        "screen_name" : "waltmossberg",
        "indices" : [ 83, 96 ],
        "id_str" : "5746452",
        "id" : 5746452
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/neUOYwBlY2",
        "expanded_url" : "http:\/\/on.recode.net\/1pXdsEC",
        "display_url" : "on.recode.net\/1pXdsEC"
      } ]
    },
    "geo" : { },
    "id_str" : "487018447318945792",
    "text" : "Apple, Google begin blending the smartphone and the PC. http:\/\/t.co\/neUOYwBlY2 via @waltmossberg",
    "id" : 487018447318945792,
    "created_at" : "2014-07-09 23:40:20 +0000",
    "user" : {
      "name" : "Walt Mossberg",
      "screen_name" : "waltmossberg",
      "protected" : false,
      "id_str" : "5746452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463735129698205696\/lgV8ScFe_normal.jpeg",
      "id" : 5746452,
      "verified" : true
    }
  },
  "id" : 487019084379209730,
  "created_at" : "2014-07-09 23:42:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 0, 11 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486978290566307840",
  "geo" : { },
  "id_str" : "486979003547275265",
  "in_reply_to_user_id" : 217880712,
  "text" : "@jimbobtyer For sure! The process for building trust with remote teams was always a continual learning experience.",
  "id" : 486979003547275265,
  "in_reply_to_status_id" : 486978290566307840,
  "created_at" : "2014-07-09 21:03:36 +0000",
  "in_reply_to_screen_name" : "jimbobtyer",
  "in_reply_to_user_id_str" : "217880712",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 0, 11 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486956256838819840",
  "geo" : { },
  "id_str" : "486960661360951296",
  "in_reply_to_user_id" : 217880712,
  "text" : "@jimbobtyer I found audio fidelity of discussions with remote teams a key factor for helping build rapport - what are your experiences?",
  "id" : 486960661360951296,
  "in_reply_to_status_id" : 486956256838819840,
  "created_at" : "2014-07-09 19:50:43 +0000",
  "in_reply_to_screen_name" : "jimbobtyer",
  "in_reply_to_user_id_str" : "217880712",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486949891198160897",
  "text" : "Redefining \"mobile learning\" in a multi-device connected world:\n\u25AA Ubiquitous\n\u25AA Situational\n\u25AA Connected\n\u25AA Personal",
  "id" : 486949891198160897,
  "created_at" : "2014-07-09 19:07:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486551929590255617",
  "geo" : { },
  "id_str" : "486562403673337856",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard I'd say likewise \u263A",
  "id" : 486562403673337856,
  "in_reply_to_status_id" : 486551929590255617,
  "created_at" : "2014-07-08 17:28:11 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/TK2ZFrRr1Q",
      "expanded_url" : "http:\/\/1drv.ms\/1ms0Di1",
      "display_url" : "1drv.ms\/1ms0Di1"
    } ]
  },
  "geo" : { },
  "id_str" : "486544438668173312",
  "text" : "First complete draft notebook for upcoming multi-device Moodle learning experiences workshop, w. slides &amp; worksheets.\nhttp:\/\/t.co\/TK2ZFrRr1Q",
  "id" : 486544438668173312,
  "created_at" : "2014-07-08 16:16:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ChilledMoodle",
      "screen_name" : "ChilledMoodle",
      "indices" : [ 3, 17 ],
      "id_str" : "2558230777",
      "id" : 2558230777
    }, {
      "name" : "(((Paul Hibbitts)))",
      "screen_name" : "paulhibbitts",
      "indices" : [ 130, 140 ],
      "id_str" : "18174513",
      "id" : 18174513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486341951222861824",
  "text" : "RT @ChilledMoodle: Now to convince bosses that I should create an open course... baby steps towards creating a course in the open @PaulHibb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "(((Paul Hibbitts)))",
        "screen_name" : "paulhibbitts",
        "indices" : [ 111, 124 ],
        "id_str" : "18174513",
        "id" : 18174513
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "485923429409763328",
    "text" : "Now to convince bosses that I should create an open course... baby steps towards creating a course in the open @PaulHibbitts style",
    "id" : 485923429409763328,
    "created_at" : "2014-07-06 23:09:08 +0000",
    "user" : {
      "name" : "ChilledMoodle",
      "screen_name" : "ChilledMoodle",
      "protected" : false,
      "id_str" : "2558230777",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479865540790321153\/NDdXQPvX_normal.jpeg",
      "id" : 2558230777,
      "verified" : false
    }
  },
  "id" : 486341951222861824,
  "created_at" : "2014-07-08 02:52:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Tran",
      "screen_name" : "dianavtran",
      "indices" : [ 3, 14 ],
      "id_str" : "33505193",
      "id" : 33505193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/YHLXnWZdg8",
      "expanded_url" : "http:\/\/google.com\/design",
      "display_url" : "google.com\/design"
    } ]
  },
  "geo" : { },
  "id_str" : "485484558012264448",
  "text" : "RT @dianavtran: As a designer at Google, I have to say it feels really great to be able to type http:\/\/t.co\/YHLXnWZdg8 into my browser and \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/YHLXnWZdg8",
        "expanded_url" : "http:\/\/google.com\/design",
        "display_url" : "google.com\/design"
      } ]
    },
    "geo" : { },
    "id_str" : "483731928051224577",
    "text" : "As a designer at Google, I have to say it feels really great to be able to type http:\/\/t.co\/YHLXnWZdg8 into my browser and it's real.",
    "id" : 483731928051224577,
    "created_at" : "2014-06-30 22:00:53 +0000",
    "user" : {
      "name" : "Diana Tran",
      "screen_name" : "dianavtran",
      "protected" : false,
      "id_str" : "33505193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482628104355971072\/Kufyb_2w_normal.jpeg",
      "id" : 33505193,
      "verified" : false
    }
  },
  "id" : 485484558012264448,
  "created_at" : "2014-07-05 18:05:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "frank fucile",
      "screen_name" : "frankfucile",
      "indices" : [ 0, 12 ],
      "id_str" : "153586453",
      "id" : 153586453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485440736804880384",
  "geo" : { },
  "id_str" : "485471577484431360",
  "in_reply_to_user_id" : 153586453,
  "text" : "@frankfucile Enjoy the Moot Frank! Sorry I missed you at the ETUG Spring workshop.",
  "id" : 485471577484431360,
  "in_reply_to_status_id" : 485440736804880384,
  "created_at" : "2014-07-05 17:13:38 +0000",
  "in_reply_to_screen_name" : "frankfucile",
  "in_reply_to_user_id_str" : "153586453",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485190409396576257",
  "text" : "Revised outline for meaningful communicating the process of UX design in only four words:\n\u25AA Empathize\n\u25AA Think\n\u25AA Create\n\u25AA Refine",
  "id" : 485190409396576257,
  "created_at" : "2014-07-04 22:36:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kato.im",
      "screen_name" : "kato_im",
      "indices" : [ 107, 115 ],
      "id_str" : "1026990656",
      "id" : 1026990656
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/484832745323888640\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/E60O2VZHIb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Brp4z-jCQAMLJSU.png",
      "id_str" : "484832744254357507",
      "id" : 484832744254357507,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Brp4z-jCQAMLJSU.png",
      "sizes" : [ {
        "h" : 357,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 873,
        "resize" : "fit",
        "w" : 1467
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/E60O2VZHIb"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 64, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484832745323888640",
  "text" : "Third iteration of a coaching\/mentoring space to complement f2f #SFU course, using real-time messaging app @kato_im http:\/\/t.co\/E60O2VZHIb",
  "id" : 484832745323888640,
  "created_at" : "2014-07-03 22:55:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SAP North America",
      "screen_name" : "SAPNorthAmerica",
      "indices" : [ 102, 118 ],
      "id_str" : "116792723",
      "id" : 116792723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484492673579880448",
  "text" : "Really looking forward to discussing UX education fundamentals with the super smart Vancouver UX Team @SAPNorthAmerica tomorrow!",
  "id" : 484492673579880448,
  "created_at" : "2014-07-03 00:23:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484407338967658496",
  "text" : "The three aspects of creating better learner experiences?\n\n\u25AA Processes\n\u25AA Competencies\n\u25AA Culture\n\nCulture is always lurking, and can kill LX!",
  "id" : 484407338967658496,
  "created_at" : "2014-07-02 18:44:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/LbEcd23IvR",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/3a4557a5-08c4-c6b4-38a5-70ec4d37a253\/",
      "display_url" : "workflowy.com\/shared\/3a4557a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484403594666332161",
  "text" : "An industry-appropriate processes, concepts, principles and techniques inventory for a 13 week intro to UX course? https:\/\/t.co\/LbEcd23IvR",
  "id" : 484403594666332161,
  "created_at" : "2014-07-02 18:29:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484401212461023234",
  "text" : "The most beneficial way to categorize key elements (a.k.a. competencies) of UX Design?\n\n\u25AA Processes\n\u25AA Concepts\n\u25AA Principles\n\u25AA Techniques",
  "id" : 484401212461023234,
  "created_at" : "2014-07-02 18:20:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484399540338819075",
  "text" : "The most meaningful way to communicate the process of UX design in only four words?\n\n\u25AA Learn\n\u25AA Think\n\u25AA Create\n\u25AA Assess",
  "id" : 484399540338819075,
  "created_at" : "2014-07-02 18:13:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]