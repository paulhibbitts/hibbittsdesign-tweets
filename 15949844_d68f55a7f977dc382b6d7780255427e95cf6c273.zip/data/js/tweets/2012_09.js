Grailbird.data.tweets_2012_09 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smashing Magazine",
      "screen_name" : "smashingmag",
      "indices" : [ 95, 107 ],
      "id_str" : "15736190",
      "id" : 15736190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/BZM0XeBQ",
      "expanded_url" : "http:\/\/www.smashingmagazine.com\/2012\/09\/28\/better-client-participation-in-responsive-design-projects\/",
      "display_url" : "smashingmagazine.com\/2012\/09\/28\/bet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "251769226262630400",
  "text" : "Encouraging Better Client Participation In Responsive Design Projects http:\/\/t.co\/BZM0XeBQ via @smashingmag",
  "id" : 251769226262630400,
  "created_at" : "2012-09-28 19:43:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Lau",
      "screen_name" : "gordlau",
      "indices" : [ 0, 8 ],
      "id_str" : "161389362",
      "id" : 161389362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/ybo7VVst",
      "expanded_url" : "http:\/\/services.google.com\/fh\/files\/misc\/multiscreenworld_final.pdf",
      "display_url" : "services.google.com\/fh\/files\/misc\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "251758483605704705",
  "geo" : { },
  "id_str" : "251767670419103745",
  "in_reply_to_user_id" : 161389362,
  "text" : "@gordlau Certainly as a starting point - the key issue to me is that we need to design for a wide range of screens http:\/\/t.co\/ybo7VVst",
  "id" : 251767670419103745,
  "in_reply_to_status_id" : 251758483605704705,
  "created_at" : "2012-09-28 19:37:44 +0000",
  "in_reply_to_screen_name" : "gordlau",
  "in_reply_to_user_id_str" : "161389362",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251728737077444609",
  "text" : "\"Multi-screen First\" just does not have the same ring to it as \"Mobile First\"\u2026",
  "id" : 251728737077444609,
  "created_at" : "2012-09-28 17:03:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/rnU3RaTQ",
      "expanded_url" : "http:\/\/etug.ca\/2012\/09\/22\/etug-fall-workshop-2012-accommodation\/",
      "display_url" : "etug.ca\/2012\/09\/22\/etu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "251109491439988736",
  "text" : "RT @etug: ETUG Fall workshop Nov 2nd at BCIT DTC and hotel block is at St. Regis Hotel across the way. Book before Oct. 7th http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/rnU3RaTQ",
        "expanded_url" : "http:\/\/etug.ca\/2012\/09\/22\/etug-fall-workshop-2012-accommodation\/",
        "display_url" : "etug.ca\/2012\/09\/22\/etu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "250362858473394176",
    "text" : "ETUG Fall workshop Nov 2nd at BCIT DTC and hotel block is at St. Regis Hotel across the way. Book before Oct. 7th http:\/\/t.co\/rnU3RaTQ",
    "id" : 250362858473394176,
    "created_at" : "2012-09-24 22:35:31 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 251109491439988736,
  "created_at" : "2012-09-27 00:02:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Dickerson",
      "screen_name" : "JosephDickerson",
      "indices" : [ 15, 31 ],
      "id_str" : "14407107",
      "id" : 14407107
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 34, 37 ]
    }, {
      "text" : "Kickstarter",
      "indices" : [ 38, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/sMDZ5P7X",
      "expanded_url" : "http:\/\/tinyurl.com\/9u4jxcr",
      "display_url" : "tinyurl.com\/9u4jxcr"
    } ]
  },
  "geo" : { },
  "id_str" : "250328030256451584",
  "text" : "Please support @josephdickerson's #UX #Kickstarter project &amp; help him write UX101: A Primer on User Experience http:\/\/t.co\/sMDZ5P7X",
  "id" : 250328030256451584,
  "created_at" : "2012-09-24 20:17:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248568211992346624",
  "geo" : { },
  "id_str" : "248569802355003392",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Thanks a lot for the info, much appreciated!",
  "id" : 248569802355003392,
  "in_reply_to_status_id" : 248568211992346624,
  "created_at" : "2012-09-19 23:50:33 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248563148221718529",
  "geo" : { },
  "id_str" : "248565640129048577",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Thanks for sharing that info Glen - hope all is well in Vernon\/Kelowna these days!",
  "id" : 248565640129048577,
  "in_reply_to_status_id" : 248563148221718529,
  "created_at" : "2012-09-19 23:34:01 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248561212449751040",
  "geo" : { },
  "id_str" : "248562198316720128",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Do you know of any example responsive design websites using Moodle?",
  "id" : 248562198316720128,
  "in_reply_to_status_id" : 248561212449751040,
  "created_at" : "2012-09-19 23:20:20 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 3, 7 ],
      "id_str" : "1063291",
      "id" : 1063291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/NC01hlkh",
      "expanded_url" : "http:\/\/ar.gy\/1t6q",
      "display_url" : "ar.gy\/1t6q"
    } ]
  },
  "geo" : { },
  "id_str" : "248531703100997635",
  "text" : "RT @UIE: Do you know about the variety of podcast interviews available at UIE's website?  http:\/\/t.co\/NC01hlkh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/reach.me\" rel=\"nofollow\"\u003EReach.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/NC01hlkh",
        "expanded_url" : "http:\/\/ar.gy\/1t6q",
        "display_url" : "ar.gy\/1t6q"
      } ]
    },
    "geo" : { },
    "id_str" : "248531135519399936",
    "text" : "Do you know about the variety of podcast interviews available at UIE's website?  http:\/\/t.co\/NC01hlkh",
    "id" : 248531135519399936,
    "created_at" : "2012-09-19 21:16:54 +0000",
    "user" : {
      "name" : "UIE",
      "screen_name" : "UIE",
      "protected" : false,
      "id_str" : "1063291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3759116326\/19308cfcdb0b831111d4ee3fc3e6232c_normal.jpeg",
      "id" : 1063291,
      "verified" : false
    }
  },
  "id" : 248531703100997635,
  "created_at" : "2012-09-19 21:19:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/2AmKtocf",
      "expanded_url" : "http:\/\/www.paulhibbitts.com\/workshops.html#mobilelearningux",
      "display_url" : "paulhibbitts.com\/workshops.html\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "248514086210502656",
  "text" : "Excited about the first presentation of my user experience design for mobile learning workshop @ UBC tomorrow! http:\/\/t.co\/2AmKtocf",
  "id" : 248514086210502656,
  "created_at" : "2012-09-19 20:09:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gayle Mavor",
      "screen_name" : "Mavorini",
      "indices" : [ 0, 9 ],
      "id_str" : "410849605",
      "id" : 410849605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248501246972006400",
  "geo" : { },
  "id_str" : "248510978650697728",
  "in_reply_to_user_id" : 410849605,
  "text" : "@Mavorini Thanks very much for the mention Gayle!",
  "id" : 248510978650697728,
  "in_reply_to_status_id" : 248501246972006400,
  "created_at" : "2012-09-19 19:56:49 +0000",
  "in_reply_to_screen_name" : "Mavorini",
  "in_reply_to_user_id_str" : "410849605",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "E-Learning Council",
      "screen_name" : "learningcouncil",
      "indices" : [ 3, 19 ],
      "id_str" : "19455487",
      "id" : 19455487
    }, {
      "name" : "Ray Schroeder",
      "screen_name" : "rayschroeder",
      "indices" : [ 24, 37 ],
      "id_str" : "8227892",
      "id" : 8227892
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "elearning",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/NYwdxLhn",
      "expanded_url" : "http:\/\/ht.ly\/dGkeV",
      "display_url" : "ht.ly\/dGkeV"
    } ]
  },
  "geo" : { },
  "id_str" : "248087542883287040",
  "text" : "RT @learningcouncil: RT @rayschroeder: Many-to-One vs. One-to-Many: An Opinionated Guide to Educational Technology http:\/\/t.co\/NYwdxLhn  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ray Schroeder",
        "screen_name" : "rayschroeder",
        "indices" : [ 3, 16 ],
        "id_str" : "8227892",
        "id" : 8227892
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 115, 122 ]
      }, {
        "text" : "elearning",
        "indices" : [ 123, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/NYwdxLhn",
        "expanded_url" : "http:\/\/ht.ly\/dGkeV",
        "display_url" : "ht.ly\/dGkeV"
      } ]
    },
    "geo" : { },
    "id_str" : "248062591082049539",
    "text" : "RT @rayschroeder: Many-to-One vs. One-to-Many: An Opinionated Guide to Educational Technology http:\/\/t.co\/NYwdxLhn #edtech #elearning...",
    "id" : 248062591082049539,
    "created_at" : "2012-09-18 14:15:05 +0000",
    "user" : {
      "name" : "E-Learning Council",
      "screen_name" : "learningcouncil",
      "protected" : false,
      "id_str" : "19455487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1460828898\/ELCLightbulb_normal.png",
      "id" : 19455487,
      "verified" : false
    }
  },
  "id" : 248087542883287040,
  "created_at" : "2012-09-18 15:54:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlearning",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/cRHeOh8R",
      "expanded_url" : "http:\/\/www.gliffy.com\/go\/publish\/3363991\/",
      "display_url" : "gliffy.com\/go\/publish\/336\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "245960348224585729",
  "text" : "The role of user experience (UX) with mobile learning http:\/\/t.co\/cRHeOh8R #mlearning",
  "id" : 245960348224585729,
  "created_at" : "2012-09-12 19:01:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlearning",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 127 ],
      "url" : "https:\/\/t.co\/7T4h0X8H",
      "expanded_url" : "https:\/\/speakerdeck.com\/u\/hibbittsdesign\/p\/essentials-of-mobile-learning-ux-preview",
      "display_url" : "speakerdeck.com\/u\/hibbittsdesi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "245621959633821696",
  "text" : "Sneak peek of slides for Essentials of Mobile Learning UX workshops this Fall. Any feedback about topics? https:\/\/t.co\/7T4h0X8H \u2026 #mlearning",
  "id" : 245621959633821696,
  "created_at" : "2012-09-11 20:36:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IDEO",
      "screen_name" : "ideo",
      "indices" : [ 3, 8 ],
      "id_str" : "23462787",
      "id" : 23462787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/HsqT9vwj",
      "expanded_url" : "http:\/\/bit.ly\/TysfEd",
      "display_url" : "bit.ly\/TysfEd"
    } ]
  },
  "geo" : { },
  "id_str" : "244845460588740608",
  "text" : "RT @ideo: Bill Moggridge 1943-2012. You will be missed by all. http:\/\/t.co\/HsqT9vwj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/HsqT9vwj",
        "expanded_url" : "http:\/\/bit.ly\/TysfEd",
        "display_url" : "bit.ly\/TysfEd"
      } ]
    },
    "geo" : { },
    "id_str" : "244835601847816192",
    "text" : "Bill Moggridge 1943-2012. You will be missed by all. http:\/\/t.co\/HsqT9vwj",
    "id" : 244835601847816192,
    "created_at" : "2012-09-09 16:32:10 +0000",
    "user" : {
      "name" : "IDEO",
      "screen_name" : "ideo",
      "protected" : false,
      "id_str" : "23462787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760208707682603008\/HgqAWOLi_normal.jpg",
      "id" : 23462787,
      "verified" : true
    }
  },
  "id" : 244845460588740608,
  "created_at" : "2012-09-09 17:11:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor van Gorp",
      "screen_name" : "trevvg",
      "indices" : [ 0, 7 ],
      "id_str" : "14180907",
      "id" : 14180907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244168214504955904",
  "in_reply_to_user_id" : 14180907,
  "text" : "@trevvg Thanks for the RT! Really looking forward to reading your book.",
  "id" : 244168214504955904,
  "created_at" : "2012-09-07 20:20:13 +0000",
  "in_reply_to_screen_name" : "trevvg",
  "in_reply_to_user_id_str" : "14180907",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/Gp1vNnPd",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/mobilelearningux-demo\/",
      "display_url" : "hibbittsdesign.com\/courses\/mobile\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243812413076549632",
  "text" : "New resources added about design thinking (Building Blocks) and designing for emotion and flow (Mobile Learning UX) - http:\/\/t.co\/Gp1vNnPd",
  "id" : 243812413076549632,
  "created_at" : "2012-09-06 20:46:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Kim",
      "screen_name" : "oryankim",
      "indices" : [ 75, 84 ],
      "id_str" : "28181012",
      "id" : 28181012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/1VNfwIe7",
      "expanded_url" : "http:\/\/gigaom.com\/2012\/08\/29\/multi-screen-mania-how-our-devices-work-together\/",
      "display_url" : "gigaom.com\/2012\/08\/29\/mul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243477070997495809",
  "text" : "Multi-screen mania: how our devices work\u00A0together http:\/\/t.co\/1VNfwIe7 via @oryankim",
  "id" : 243477070997495809,
  "created_at" : "2012-09-05 22:33:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 0, 8 ],
      "id_str" : "10675",
      "id" : 10675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242823868086091778",
  "geo" : { },
  "id_str" : "242826522791124993",
  "in_reply_to_user_id" : 10675,
  "text" : "@gordonr Re: new years eve I fully concur!",
  "id" : 242826522791124993,
  "in_reply_to_status_id" : 242823868086091778,
  "created_at" : "2012-09-04 03:28:49 +0000",
  "in_reply_to_screen_name" : "gordonr",
  "in_reply_to_user_id_str" : "10675",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]