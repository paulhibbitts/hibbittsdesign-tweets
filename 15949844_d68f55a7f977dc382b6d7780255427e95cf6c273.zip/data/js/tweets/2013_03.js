Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/YYReWeGgY2",
      "expanded_url" : "http:\/\/uxmag.com\/articles\/looking-into-the-screens-of-the-future#.UVTF6bX_faQ.twitter",
      "display_url" : "uxmag.com\/articles\/looki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317405059421982720",
  "text" : "Looking Into the Screens of the Future http:\/\/t.co\/YYReWeGgY2",
  "id" : 317405059421982720,
  "created_at" : "2013-03-28 22:37:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Cohn",
      "screen_name" : "mikewcohn",
      "indices" : [ 3, 13 ],
      "id_str" : "55573320",
      "id" : 55573320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/KxpSXvzGU7",
      "expanded_url" : "http:\/\/bit.ly\/YgBn2n",
      "display_url" : "bit.ly\/YgBn2n"
    } ]
  },
  "geo" : { },
  "id_str" : "317398537824501762",
  "text" : "RT @mikewcohn: I just learned I can do free Kano analysis surveys here: http:\/\/t.co\/KxpSXvzGU7 Awesome!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/KxpSXvzGU7",
        "expanded_url" : "http:\/\/bit.ly\/YgBn2n",
        "display_url" : "bit.ly\/YgBn2n"
      } ]
    },
    "geo" : { },
    "id_str" : "317105632450846723",
    "text" : "I just learned I can do free Kano analysis surveys here: http:\/\/t.co\/KxpSXvzGU7 Awesome!",
    "id" : 317105632450846723,
    "created_at" : "2013-03-28 02:47:28 +0000",
    "user" : {
      "name" : "Mike Cohn",
      "screen_name" : "mikewcohn",
      "protected" : false,
      "id_str" : "55573320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753667616317673472\/mCz4R6dl_normal.jpg",
      "id" : 55573320,
      "verified" : false
    }
  },
  "id" : 317398537824501762,
  "created_at" : "2013-03-28 22:11:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317382048044175361",
  "text" : "ResEdit and Bundle Bits FTW!",
  "id" : 317382048044175361,
  "created_at" : "2013-03-28 21:05:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Poulos",
      "screen_name" : "dawnpoulos",
      "indices" : [ 3, 14 ],
      "id_str" : "15770877",
      "id" : 15770877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/DZm3MaKAf7",
      "expanded_url" : "http:\/\/ow.ly\/jtuqI",
      "display_url" : "ow.ly\/jtuqI"
    } ]
  },
  "geo" : { },
  "id_str" : "317030627650191360",
  "text" : "RT @dawnpoulos: The future of mobile - 100+ slides of very useful data. http:\/\/t.co\/DZm3MaKAf7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/DZm3MaKAf7",
        "expanded_url" : "http:\/\/ow.ly\/jtuqI",
        "display_url" : "ow.ly\/jtuqI"
      } ]
    },
    "geo" : { },
    "id_str" : "316980265811578880",
    "text" : "The future of mobile - 100+ slides of very useful data. http:\/\/t.co\/DZm3MaKAf7",
    "id" : 316980265811578880,
    "created_at" : "2013-03-27 18:29:19 +0000",
    "user" : {
      "name" : "Dawn Poulos",
      "screen_name" : "dawnpoulos",
      "protected" : false,
      "id_str" : "15770877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2681205655\/5f9e894dc689bba8cde713ce1768367a_normal.png",
      "id" : 15770877,
      "verified" : false
    }
  },
  "id" : 317030627650191360,
  "created_at" : "2013-03-27 21:49:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316965439332839424",
  "text" : "Acid test: Would these 8 mobile design principles hold their own in relation to Google Glass? Mobile no longer defined as small touchscreens",
  "id" : 316965439332839424,
  "created_at" : "2013-03-27 17:30:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316963383280807936",
  "text" : "7.Consider all data connection states 8.Think ecosystem, not just one device",
  "id" : 316963383280807936,
  "created_at" : "2013-03-27 17:22:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316963022998474752",
  "text" : "4.Follow platform conventions 5.Leverage available sensors 6.Support social activities (when appropriate)",
  "id" : 316963022998474752,
  "created_at" : "2013-03-27 17:20:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316962879523917826",
  "text" : "Updated set of (now 8) mobile design principles:1.Consider context of use 2.Keep key tasks simple and quick 3.Choose content over navigation",
  "id" : 316962879523917826,
  "created_at" : "2013-03-27 17:20:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 3, 12 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ocTEL",
      "indices" : [ 76, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/dsILX95Q6q",
      "expanded_url" : "http:\/\/mashe.hawksey.info\/2013\/03\/mooc-in-a-box-turning-wordpress-into-an-open-course-reader-octel\/",
      "display_url" : "mashe.hawksey.info\/2013\/03\/mooc-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316940686115082240",
  "text" : "RT @mhawksey: (M)OOC in a Box: Turning WordPress into an Open Course Reader #ocTEL http:\/\/t.co\/dsILX95Q6q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ocTEL",
        "indices" : [ 62, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/dsILX95Q6q",
        "expanded_url" : "http:\/\/mashe.hawksey.info\/2013\/03\/mooc-in-a-box-turning-wordpress-into-an-open-course-reader-octel\/",
        "display_url" : "mashe.hawksey.info\/2013\/03\/mooc-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "316931945680486400",
    "text" : "(M)OOC in a Box: Turning WordPress into an Open Course Reader #ocTEL http:\/\/t.co\/dsILX95Q6q",
    "id" : 316931945680486400,
    "created_at" : "2013-03-27 15:17:18 +0000",
    "user" : {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "protected" : false,
      "id_str" : "13046992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390851993\/xu6aptqy6a8rb2h2w5by_normal.jpeg",
      "id" : 13046992,
      "verified" : false
    }
  },
  "id" : 316940686115082240,
  "created_at" : "2013-03-27 15:52:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "indices" : [ 3, 17 ],
      "id_str" : "153597392",
      "id" : 153597392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 98, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/xipXDlIJ10",
      "expanded_url" : "http:\/\/bit.ly\/1584XIB",
      "display_url" : "bit.ly\/1584XIB"
    } ]
  },
  "geo" : { },
  "id_str" : "316694599685009408",
  "text" : "RT @SFUteachlearn: Tomorrow at noon. Panel discussion: How will MOOCs affect higher education and #SFU? Register: http:\/\/t.co\/xipXDlIJ10",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SFU",
        "indices" : [ 79, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/xipXDlIJ10",
        "expanded_url" : "http:\/\/bit.ly\/1584XIB",
        "display_url" : "bit.ly\/1584XIB"
      } ]
    },
    "geo" : { },
    "id_str" : "316693602942218241",
    "text" : "Tomorrow at noon. Panel discussion: How will MOOCs affect higher education and #SFU? Register: http:\/\/t.co\/xipXDlIJ10",
    "id" : 316693602942218241,
    "created_at" : "2013-03-26 23:30:13 +0000",
    "user" : {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "protected" : false,
      "id_str" : "153597392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1011990133\/twitter_badge_teach_learn2_normal.jpg",
      "id" : 153597392,
      "verified" : false
    }
  },
  "id" : 316694599685009408,
  "created_at" : "2013-03-26 23:34:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316684408126054400",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Thanks for the RT's Holly!",
  "id" : 316684408126054400,
  "created_at" : "2013-03-26 22:53:41 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316674995940118528",
  "geo" : { },
  "id_str" : "316678006871572480",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Thanks for sharing your thoughts, I'll be revising #5 for sure.",
  "id" : 316678006871572480,
  "in_reply_to_status_id" : 316674995940118528,
  "created_at" : "2013-03-26 22:28:15 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316670753112195074",
  "geo" : { },
  "id_str" : "316671812383690753",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Thanks Tannis! Good point, might be the case for the classic \"(as appropriate)\" for #5?",
  "id" : 316671812383690753,
  "in_reply_to_status_id" : 316670753112195074,
  "created_at" : "2013-03-26 22:03:38 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316670083390906370",
  "text" : "Items to add or remove? Design for multi-touch and (smaller) screen sizes to be addressed separately.",
  "id" : 316670083390906370,
  "created_at" : "2013-03-26 21:56:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316669729559412736",
  "text" : "4. Follow platform conventions 5.Support social activities 6.Consider all data connection states 7.Think ecosystem, not just one device",
  "id" : 316669729559412736,
  "created_at" : "2013-03-26 21:55:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316669619123400704",
  "text" : "Draft set of 7 mobile design principles: 1.Consider context of use 2.Keep key tasks simple and quick 3.Choose content over navigation\u2026",
  "id" : 316669619123400704,
  "created_at" : "2013-03-26 21:54:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Skosnik",
      "screen_name" : "thinkingmaven",
      "indices" : [ 0, 14 ],
      "id_str" : "419728487",
      "id" : 419728487
    }, {
      "name" : "AGLOBALWAY",
      "screen_name" : "aglobalway",
      "indices" : [ 15, 26 ],
      "id_str" : "1276877132",
      "id" : 1276877132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315500834815361025",
  "geo" : { },
  "id_str" : "316315099688218625",
  "in_reply_to_user_id" : 419728487,
  "text" : "@thinkingmaven @aglobalway Congratulations! You highlight open source advantages and your own core beliefs very nicely.",
  "id" : 316315099688218625,
  "in_reply_to_status_id" : 315500834815361025,
  "created_at" : "2013-03-25 22:26:11 +0000",
  "in_reply_to_screen_name" : "thinkingmaven",
  "in_reply_to_user_id_str" : "419728487",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 14, 19 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/eo1DQFAtaI",
      "expanded_url" : "http:\/\/etug.ca\/2013\/03\/19\/last-call-for-etug-spring-proposals\/",
      "display_url" : "etug.ca\/2013\/03\/19\/las\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316304568793317378",
  "text" : "RT @etug: Hey @etug we'll say it again: Last Call!! http:\/\/t.co\/eo1DQFAtaI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 4, 9 ],
        "id_str" : "17102936",
        "id" : 17102936
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/eo1DQFAtaI",
        "expanded_url" : "http:\/\/etug.ca\/2013\/03\/19\/last-call-for-etug-spring-proposals\/",
        "display_url" : "etug.ca\/2013\/03\/19\/las\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "316282688564760576",
    "text" : "Hey @etug we'll say it again: Last Call!! http:\/\/t.co\/eo1DQFAtaI",
    "id" : 316282688564760576,
    "created_at" : "2013-03-25 20:17:23 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 316304568793317378,
  "created_at" : "2013-03-25 21:44:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Pontefract",
      "screen_name" : "dpontefract",
      "indices" : [ 21, 33 ],
      "id_str" : "18343116",
      "id" : 18343116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/5uGSdx18U5",
      "expanded_url" : "http:\/\/www.flatarmy.com\/",
      "display_url" : "flatarmy.com"
    } ]
  },
  "geo" : { },
  "id_str" : "316234072835887105",
  "text" : "Reading Flat Army by @dpontefract http:\/\/t.co\/5uGSdx18U5 Love observation about need to \"cultivate and coordinate\" vs \"command and control\".",
  "id" : 316234072835887105,
  "created_at" : "2013-03-25 17:04:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Hart",
      "screen_name" : "C4LPT",
      "indices" : [ 3, 9 ],
      "id_str" : "14192174",
      "id" : 14192174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/DlBzTckxl3",
      "expanded_url" : "http:\/\/www.c4lpt.co.uk\/blog\/2013\/03\/23\/10-reasons-not-to-creat-a-course-and-10-options\/",
      "display_url" : "c4lpt.co.uk\/blog\/2013\/03\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "315561911569772545",
  "text" : "RT @C4LPT: 10 good reasons NOT to create a course http:\/\/t.co\/DlBzTckxl3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/DlBzTckxl3",
        "expanded_url" : "http:\/\/www.c4lpt.co.uk\/blog\/2013\/03\/23\/10-reasons-not-to-creat-a-course-and-10-options\/",
        "display_url" : "c4lpt.co.uk\/blog\/2013\/03\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "315552345700319232",
    "text" : "10 good reasons NOT to create a course http:\/\/t.co\/DlBzTckxl3",
    "id" : 315552345700319232,
    "created_at" : "2013-03-23 19:55:16 +0000",
    "user" : {
      "name" : "Jane Hart",
      "screen_name" : "C4LPT",
      "protected" : false,
      "id_str" : "14192174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635396281641340928\/qOqqMYNe_normal.jpg",
      "id" : 14192174,
      "verified" : false
    }
  },
  "id" : 315561911569772545,
  "created_at" : "2013-03-23 20:33:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/y51W5RATCq",
      "expanded_url" : "http:\/\/www.mindmeister.com\/273528276\/etug-spring-2013-designing-for-touch-not-just-for-mobile-anymore",
      "display_url" : "mindmeister.com\/273528276\/etug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314855629665734657",
  "text" : "Just submitted my proposal \"Designing for Touch: Not Just for Mobile Anymore\" for ETUG Spring Workshop. Outline at http:\/\/t.co\/y51W5RATCq",
  "id" : 314855629665734657,
  "created_at" : "2013-03-21 21:46:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Corbett",
      "screen_name" : "kevin_corbett",
      "indices" : [ 3, 17 ],
      "id_str" : "15460202",
      "id" : 15460202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eLearning",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "higherEd",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/orCfwJUErR",
      "expanded_url" : "http:\/\/ow.ly\/jhRDt",
      "display_url" : "ow.ly\/jhRDt"
    } ]
  },
  "geo" : { },
  "id_str" : "314779810389975042",
  "text" : "RT @kevin_corbett: MBOOC: Massively BORING Open Online Learning http:\/\/t.co\/orCfwJUErR Need MORE than simply \"classroom online\" in #eLea ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eLearning",
        "indices" : [ 112, 122 ]
      }, {
        "text" : "higherEd",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/orCfwJUErR",
        "expanded_url" : "http:\/\/ow.ly\/jhRDt",
        "display_url" : "ow.ly\/jhRDt"
      } ]
    },
    "geo" : { },
    "id_str" : "314773625364418560",
    "text" : "MBOOC: Massively BORING Open Online Learning http:\/\/t.co\/orCfwJUErR Need MORE than simply \"classroom online\" in #eLearning and #higherEd",
    "id" : 314773625364418560,
    "created_at" : "2013-03-21 16:20:55 +0000",
    "user" : {
      "name" : "Kevin Corbett",
      "screen_name" : "kevin_corbett",
      "protected" : false,
      "id_str" : "15460202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664345202715291648\/GtT1EymL_normal.png",
      "id" : 15460202,
      "verified" : false
    }
  },
  "id" : 314779810389975042,
  "created_at" : "2013-03-21 16:45:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Debenham",
      "screen_name" : "anna_debenham",
      "indices" : [ 3, 17 ],
      "id_str" : "9655342",
      "id" : 9655342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314066889582194688",
  "text" : "RT @anna_debenham: T\u0336h\u0336e\u0336 \u0336m\u0336o\u0336b\u0336i\u0336l\u0336e\u0336 \u0336w\u0336e\u0336b\u0336 The web.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314056959005429760",
    "text" : "T\u0336h\u0336e\u0336 \u0336m\u0336o\u0336b\u0336i\u0336l\u0336e\u0336 \u0336w\u0336e\u0336b\u0336 The web.",
    "id" : 314056959005429760,
    "created_at" : "2013-03-19 16:53:08 +0000",
    "user" : {
      "name" : "Anna Debenham",
      "screen_name" : "anna_debenham",
      "protected" : false,
      "id_str" : "9655342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660807871156887552\/qDyGT6Dx_normal.png",
      "id" : 9655342,
      "verified" : false
    }
  },
  "id" : 314066889582194688,
  "created_at" : "2013-03-19 17:32:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marketing Land",
      "screen_name" : "Marketingland",
      "indices" : [ 98, 112 ],
      "id_str" : "12553672",
      "id" : 12553672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/EgORHjkN7S",
      "expanded_url" : "http:\/\/marketingland.com\/microsoft-study-multi-screen-behavior-and-what-it-means-for-marketer-36456?utm_source=twbutton&utm_medium=twitter&utm_campaign=tweet",
      "display_url" : "marketingland.com\/microsoft-stud\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314028689862062080",
  "text" : "Microsoft Study: Multi-Screen Behavior And What It Means For Marketers http:\/\/t.co\/EgORHjkN7S via @marketingland",
  "id" : 314028689862062080,
  "created_at" : "2013-03-19 15:00:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eLearn Magazine",
      "screen_name" : "eLearnMag",
      "indices" : [ 3, 13 ],
      "id_str" : "48439456",
      "id" : 48439456
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LSCON",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312302681622454272",
  "text" : "RT @eLearnMag: When designing learning for mobile keep in mind more than 50% of people have at least 3 different mobile devices ~Robert  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LSCON",
        "indices" : [ 126, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312283737410904064",
    "text" : "When designing learning for mobile keep in mind more than 50% of people have at least 3 different mobile devices ~Robert Gadd #LSCON",
    "id" : 312283737410904064,
    "created_at" : "2013-03-14 19:26:59 +0000",
    "user" : {
      "name" : "eLearn Magazine",
      "screen_name" : "eLearnMag",
      "protected" : false,
      "id_str" : "48439456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588371262260535296\/nKFj3DnM_normal.jpg",
      "id" : 48439456,
      "verified" : false
    }
  },
  "id" : 312302681622454272,
  "created_at" : "2013-03-14 20:42:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Rieger",
      "screen_name" : "stephanierieger",
      "indices" : [ 3, 19 ],
      "id_str" : "6868612",
      "id" : 6868612
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/stephanierieger\/status\/312267539541540864\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/YPIE7OC4Dl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFVlrDnCQAAPKoi.png",
      "id_str" : "312267539549929472",
      "id" : 312267539549929472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFVlrDnCQAAPKoi.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 310
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 310
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 310
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 310
      } ],
      "display_url" : "pic.twitter.com\/YPIE7OC4Dl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312287430210363393",
  "text" : "RT @stephanierieger: That publishers see web, smartphone &amp; tablet as separate things is both a symptom and cause of current problems ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/stephanierieger\/status\/312267539541540864\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/YPIE7OC4Dl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BFVlrDnCQAAPKoi.png",
        "id_str" : "312267539549929472",
        "id" : 312267539549929472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFVlrDnCQAAPKoi.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 310
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 310
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 310
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 310
        } ],
        "display_url" : "pic.twitter.com\/YPIE7OC4Dl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312267539541540864",
    "text" : "That publishers see web, smartphone &amp; tablet as separate things is both a symptom and cause of current problems. http:\/\/t.co\/YPIE7OC4Dl",
    "id" : 312267539541540864,
    "created_at" : "2013-03-14 18:22:37 +0000",
    "user" : {
      "name" : "Stephanie Rieger",
      "screen_name" : "stephanierieger",
      "protected" : false,
      "id_str" : "6868612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1581672007\/stephanie-rieger_normal.png",
      "id" : 6868612,
      "verified" : false
    }
  },
  "id" : 312287430210363393,
  "created_at" : "2013-03-14 19:41:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    }, {
      "name" : "Eric Meyer",
      "screen_name" : "meyerweb",
      "indices" : [ 74, 83 ],
      "id_str" : "646533",
      "id" : 646533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/Gmy2RXHmLu",
      "expanded_url" : "http:\/\/instagram.com\/p\/W2FCksR9-e\/",
      "display_url" : "instagram.com\/p\/W2FCksR9-e\/"
    } ]
  },
  "geo" : { },
  "id_str" : "312260342770180096",
  "text" : "RT @lukew: Sure you don't care about mobile? \nhttp:\/\/t.co\/Gmy2RXHmLu\n\nht\/ @meyerweb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eric Meyer",
        "screen_name" : "meyerweb",
        "indices" : [ 63, 72 ],
        "id_str" : "646533",
        "id" : 646533
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/Gmy2RXHmLu",
        "expanded_url" : "http:\/\/instagram.com\/p\/W2FCksR9-e\/",
        "display_url" : "instagram.com\/p\/W2FCksR9-e\/"
      } ]
    },
    "geo" : { },
    "id_str" : "312259287588171776",
    "text" : "Sure you don't care about mobile? \nhttp:\/\/t.co\/Gmy2RXHmLu\n\nht\/ @meyerweb",
    "id" : 312259287588171776,
    "created_at" : "2013-03-14 17:49:50 +0000",
    "user" : {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "protected" : false,
      "id_str" : "13889622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477610446917103616\/_cjU3_ga_normal.png",
      "id" : 13889622,
      "verified" : false
    }
  },
  "id" : 312260342770180096,
  "created_at" : "2013-03-14 17:54:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312255823084662784",
  "geo" : { },
  "id_str" : "312256700243660800",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Have a smooth flight!",
  "id" : 312256700243660800,
  "in_reply_to_status_id" : 312255823084662784,
  "created_at" : "2013-03-14 17:39:33 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/5ocY7moFwD",
      "expanded_url" : "http:\/\/elearnmag.acm.org\/blog\/?p=445",
      "display_url" : "elearnmag.acm.org\/blog\/?p=445"
    } ]
  },
  "in_reply_to_status_id_str" : "311894420087771136",
  "geo" : { },
  "id_str" : "311956184024379393",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Thanks for sharing \"A New Pedagogy\" article. You might also be interested in this related list\u2026 http:\/\/t.co\/5ocY7moFwD",
  "id" : 311956184024379393,
  "in_reply_to_status_id" : 311894420087771136,
  "created_at" : "2013-03-13 21:45:24 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Balsamiq",
      "screen_name" : "balsamiq",
      "indices" : [ 3, 12 ],
      "id_str" : "14361698",
      "id" : 14361698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/5mQ7tFjD5z",
      "expanded_url" : "http:\/\/blogs.balsamiq.com\/ux\/2013\/03\/12\/uxapprentice\/",
      "display_url" : "blogs.balsamiq.com\/ux\/2013\/03\/12\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311950464377827328",
  "text" : "RT @balsamiq: Meet UX Apprentice, a new site we made to help you learn about UX Design! http:\/\/t.co\/5mQ7tFjD5z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/5mQ7tFjD5z",
        "expanded_url" : "http:\/\/blogs.balsamiq.com\/ux\/2013\/03\/12\/uxapprentice\/",
        "display_url" : "blogs.balsamiq.com\/ux\/2013\/03\/12\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "311587211093086208",
    "text" : "Meet UX Apprentice, a new site we made to help you learn about UX Design! http:\/\/t.co\/5mQ7tFjD5z",
    "id" : 311587211093086208,
    "created_at" : "2013-03-12 21:19:14 +0000",
    "user" : {
      "name" : "Balsamiq",
      "screen_name" : "balsamiq",
      "protected" : false,
      "id_str" : "14361698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476802805185777664\/LJf-7p3B_normal.png",
      "id" : 14361698,
      "verified" : true
    }
  },
  "id" : 311950464377827328,
  "created_at" : "2013-03-13 21:22:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/OpGbyRapEb",
      "expanded_url" : "http:\/\/www.mindmeister.com\/270619896\/mobile-learning-user-experience-ux-design-with-moodle",
      "display_url" : "mindmeister.com\/270619896\/mobi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311933064571924481",
  "text" : "Visual outline of a full-day workshop about mobile learning user experience (UX) design with Moodle http:\/\/t.co\/OpGbyRapEb Feedback welcome!",
  "id" : 311933064571924481,
  "created_at" : "2013-03-13 20:13:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 0, 5 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311232178954588160",
  "geo" : { },
  "id_str" : "311280730330251264",
  "in_reply_to_user_id" : 17102936,
  "text" : "@etug Thanks very much for the RT!",
  "id" : 311280730330251264,
  "in_reply_to_status_id" : 311232178954588160,
  "created_at" : "2013-03-12 01:01:24 +0000",
  "in_reply_to_screen_name" : "etug",
  "in_reply_to_user_id_str" : "17102936",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/yMqRjpT8zR",
      "expanded_url" : "http:\/\/www.paulhibbitts.com\/mobilelearningux\/index.html",
      "display_url" : "paulhibbitts.com\/mobilelearning\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311212795100286976",
  "text" : "My mobile learning UX presentations, multi-screen demo courses (Moodle + WP), and SFU case study are now available at http:\/\/t.co\/yMqRjpT8zR",
  "id" : 311212795100286976,
  "created_at" : "2013-03-11 20:31:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ranvir Bahl",
      "screen_name" : "bahl",
      "indices" : [ 0, 5 ],
      "id_str" : "16232686",
      "id" : 16232686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/EJELK4wFHB",
      "expanded_url" : "http:\/\/paulhibbitts.com",
      "display_url" : "paulhibbitts.com"
    } ]
  },
  "in_reply_to_status_id_str" : "310257877770199040",
  "geo" : { },
  "id_str" : "311188445122924544",
  "in_reply_to_user_id" : 16232686,
  "text" : "@bahl Hi Ranvir, your last tweet got cut-off. Still more than happy to help out if you email me details at paul(at)http:\/\/t.co\/EJELK4wFHB.",
  "id" : 311188445122924544,
  "in_reply_to_status_id" : 310257877770199040,
  "created_at" : "2013-03-11 18:54:41 +0000",
  "in_reply_to_screen_name" : "bahl",
  "in_reply_to_user_id_str" : "16232686",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Lambert",
      "screen_name" : "prlambert",
      "indices" : [ 0, 10 ],
      "id_str" : "17029883",
      "id" : 17029883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/EJELK4wFHB",
      "expanded_url" : "http:\/\/paulhibbitts.com",
      "display_url" : "paulhibbitts.com"
    } ]
  },
  "in_reply_to_status_id_str" : "310517515979743234",
  "geo" : { },
  "id_str" : "311138347139600385",
  "in_reply_to_user_id" : 17029883,
  "text" : "@prlambert Awesome. Please email me at paul(at)http:\/\/t.co\/EJELK4wFHB and we can arrange to meet up. Cheers!",
  "id" : 311138347139600385,
  "in_reply_to_status_id" : 310517515979743234,
  "created_at" : "2013-03-11 15:35:37 +0000",
  "in_reply_to_screen_name" : "prlambert",
  "in_reply_to_user_id_str" : "17029883",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/carbonandroid\" rel=\"nofollow\"\u003ECarbon for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ranvir Bahl",
      "screen_name" : "bahl",
      "indices" : [ 0, 5 ],
      "id_str" : "16232686",
      "id" : 16232686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310175608468545536",
  "geo" : { },
  "id_str" : "310193385468223488",
  "in_reply_to_user_id" : 16232686,
  "text" : "@bahl Please email me with more details and I'll have a better idea what might be of most help",
  "id" : 310193385468223488,
  "in_reply_to_status_id" : 310175608468545536,
  "created_at" : "2013-03-09 01:00:40 +0000",
  "in_reply_to_screen_name" : "bahl",
  "in_reply_to_user_id_str" : "16232686",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Education Northwest",
      "screen_name" : "educationnw",
      "indices" : [ 3, 15 ],
      "id_str" : "93920452",
      "id" : 93920452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MOOC",
      "indices" : [ 21, 26 ]
    }, {
      "text" : "SXSWedu",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/qn8AzU0DOy",
      "expanded_url" : "http:\/\/sxswedu.com\/live",
      "display_url" : "sxswedu.com\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "309434458015137792",
  "text" : "RT @educationnw: The #MOOC keynote is streaming live right now! http:\/\/t.co\/qn8AzU0DOy #SXSWedu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MOOC",
        "indices" : [ 4, 9 ]
      }, {
        "text" : "SXSWedu",
        "indices" : [ 70, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/qn8AzU0DOy",
        "expanded_url" : "http:\/\/sxswedu.com\/live",
        "display_url" : "sxswedu.com\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "309434191899144192",
    "text" : "The #MOOC keynote is streaming live right now! http:\/\/t.co\/qn8AzU0DOy #SXSWedu",
    "id" : 309434191899144192,
    "created_at" : "2013-03-06 22:43:55 +0000",
    "user" : {
      "name" : "Education Northwest",
      "screen_name" : "educationnw",
      "protected" : false,
      "id_str" : "93920452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466346911876665344\/mEKThofA_normal.png",
      "id" : 93920452,
      "verified" : false
    }
  },
  "id" : 309434458015137792,
  "created_at" : "2013-03-06 22:44:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "indices" : [ 3, 10 ],
      "id_str" : "14321959",
      "id" : 14321959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/vc0vRjESeE",
      "expanded_url" : "http:\/\/bit.ly\/1065msc",
      "display_url" : "bit.ly\/1065msc"
    } ]
  },
  "geo" : { },
  "id_str" : "309421386328322048",
  "text" : "RT @umairh: While we're on the topic, here's my latest little essay, on Great Ideas vs TED Thinking. http:\/\/t.co\/vc0vRjESeE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/vc0vRjESeE",
        "expanded_url" : "http:\/\/bit.ly\/1065msc",
        "display_url" : "bit.ly\/1065msc"
      } ]
    },
    "geo" : { },
    "id_str" : "309377716669530113",
    "text" : "While we're on the topic, here's my latest little essay, on Great Ideas vs TED Thinking. http:\/\/t.co\/vc0vRjESeE",
    "id" : 309377716669530113,
    "created_at" : "2013-03-06 18:59:30 +0000",
    "user" : {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "protected" : false,
      "id_str" : "14321959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759755033336434688\/ENaLMj0w_normal.jpg",
      "id" : 14321959,
      "verified" : true
    }
  },
  "id" : 309421386328322048,
  "created_at" : "2013-03-06 21:53:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jac de Haan",
      "screen_name" : "techwithintent",
      "indices" : [ 3, 18 ],
      "id_str" : "296854436",
      "id" : 296854436
    }, {
      "name" : "Jaime Casap",
      "screen_name" : "jcasap",
      "indices" : [ 120, 127 ],
      "id_str" : "14517467",
      "id" : 14517467
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sxswedu",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309419894640869376",
  "text" : "RT @techwithintent: \"Your awesome smart phone is the crappiest tech your child will ever see. It's their Commadore 64.\" @jcasap #sxswedu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jaime Casap",
        "screen_name" : "jcasap",
        "indices" : [ 100, 107 ],
        "id_str" : "14517467",
        "id" : 14517467
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sxswedu",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309412380452986880",
    "text" : "\"Your awesome smart phone is the crappiest tech your child will ever see. It's their Commadore 64.\" @jcasap #sxswedu",
    "id" : 309412380452986880,
    "created_at" : "2013-03-06 21:17:14 +0000",
    "user" : {
      "name" : "Jac de Haan",
      "screen_name" : "techwithintent",
      "protected" : false,
      "id_str" : "296854436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2720204810\/1a39dc50cfe2d3329ed9d2e974e304e8_normal.png",
      "id" : 296854436,
      "verified" : false
    }
  },
  "id" : 309419894640869376,
  "created_at" : "2013-03-06 21:47:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308759440939704320",
  "geo" : { },
  "id_str" : "308759713326182400",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 Looking forward to reading it!",
  "id" : 308759713326182400,
  "in_reply_to_status_id" : 308759440939704320,
  "created_at" : "2013-03-05 02:03:46 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Learndot",
      "screen_name" : "Learndot",
      "indices" : [ 0, 9 ],
      "id_str" : "44676673",
      "id" : 44676673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308723536288169987",
  "geo" : { },
  "id_str" : "308725482990469121",
  "in_reply_to_user_id" : 44676673,
  "text" : "@Learndot Love to meet up sometime to share our experiences with mobile learning. DM or email me if your interested.",
  "id" : 308725482990469121,
  "in_reply_to_status_id" : 308723536288169987,
  "created_at" : "2013-03-04 23:47:45 +0000",
  "in_reply_to_screen_name" : "Learndot",
  "in_reply_to_user_id_str" : "44676673",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/dSG9sgy8XN",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/mobilelearningux-demo\/",
      "display_url" : "hibbittsdesign.com\/courses\/mobile\u2026"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/XsBr1B7Kgh",
      "expanded_url" : "http:\/\/uxfundamentals.com\/moodle\/course\/view.php?id=2",
      "display_url" : "uxfundamentals.com\/moodle\/course\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308723824914993153",
  "text" : "Any recos for self-hosted CMS\/LMS for mobile learning? So far I've used WordPress http:\/\/t.co\/dSG9sgy8XN and Moodle http:\/\/t.co\/XsBr1B7Kgh",
  "id" : 308723824914993153,
  "created_at" : "2013-03-04 23:41:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Ridden",
      "screen_name" : "moodleman",
      "indices" : [ 3, 13 ],
      "id_str" : "33704369",
      "id" : 33704369
    }, {
      "name" : "Martin Dougiamas",
      "screen_name" : "moodler",
      "indices" : [ 15, 23 ],
      "id_str" : "16444716",
      "id" : 16444716
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bootstrap",
      "indices" : [ 38, 48 ]
    }, {
      "text" : "Moodle",
      "indices" : [ 78, 85 ]
    }, {
      "text" : "responsive",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307538458715496449",
  "text" : "RT @moodleman: @moodler confirms that #bootstrap will soon be a base theme in #Moodle for other theme designers to build upon. #responsi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Martin Dougiamas",
        "screen_name" : "moodler",
        "indices" : [ 0, 8 ],
        "id_str" : "16444716",
        "id" : 16444716
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bootstrap",
        "indices" : [ 23, 33 ]
      }, {
        "text" : "Moodle",
        "indices" : [ 63, 70 ]
      }, {
        "text" : "responsive",
        "indices" : [ 112, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 48.1547348661, 11.5560097884 ]
    },
    "id_str" : "307483527975419905",
    "in_reply_to_user_id" : 16444716,
    "text" : "@moodler confirms that #bootstrap will soon be a base theme in #Moodle for other theme designers to build upon. #responsive design ahoy!",
    "id" : 307483527975419905,
    "created_at" : "2013-03-01 13:32:40 +0000",
    "in_reply_to_screen_name" : "moodler",
    "in_reply_to_user_id_str" : "16444716",
    "user" : {
      "name" : "Julian Ridden",
      "screen_name" : "EduRidden",
      "protected" : false,
      "id_str" : "9198142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755434524066971648\/AcgB4rwn_normal.jpg",
      "id" : 9198142,
      "verified" : false
    }
  },
  "id" : 307538458715496449,
  "created_at" : "2013-03-01 17:10:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]