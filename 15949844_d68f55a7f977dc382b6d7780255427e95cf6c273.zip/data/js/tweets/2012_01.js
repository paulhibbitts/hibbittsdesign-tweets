Grailbird.data.tweets_2012_01 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ReadWrite",
      "screen_name" : "RWW",
      "indices" : [ 83, 87 ],
      "id_str" : "4641021",
      "id" : 4641021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/NJH9gell",
      "expanded_url" : "http:\/\/rww.to\/zdxjOa",
      "display_url" : "rww.to\/zdxjOa"
    } ]
  },
  "geo" : { },
  "id_str" : "163013730383314945",
  "text" : "Like a Gangly 8-Year-Old, the Mobile Web Needs to Grow Up http:\/\/t.co\/NJH9gell via @RWW",
  "id" : 163013730383314945,
  "created_at" : "2012-01-27 21:41:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlearning",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/D1MzRaav",
      "expanded_url" : "http:\/\/www.slideshare.net\/hibbittsdesign\/mobile-learningux",
      "display_url" : "slideshare.net\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "161866210722594816",
  "text" : "Draft slides for \"Mobile Learning UX Design: A Case Study of Performance Support\" http:\/\/t.co\/D1MzRaav Comments are appreciated! #mlearning",
  "id" : 161866210722594816,
  "created_at" : "2012-01-24 17:41:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 3, 11 ],
      "id_str" : "1550251",
      "id" : 1550251
    }, {
      "name" : "Marty Cagan",
      "screen_name" : "cagan",
      "indices" : [ 65, 71 ],
      "id_str" : "18847562",
      "id" : 18847562
    }, {
      "name" : "Craig Villamor",
      "screen_name" : "cvilly",
      "indices" : [ 97, 104 ],
      "id_str" : "4763791",
      "id" : 4763791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "li",
      "indices" : [ 105, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/oSOc66B0",
      "expanded_url" : "http:\/\/www.svpg.com\/product-management-then-and-now\/",
      "display_url" : "svpg.com\/product-manage\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "161535013123403777",
  "text" : "RT @dmitryn: Product Management Then and Now: Great blog post by @cagan http:\/\/t.co\/oSOc66B0 via @cvilly #li",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marty Cagan",
        "screen_name" : "cagan",
        "indices" : [ 52, 58 ],
        "id_str" : "18847562",
        "id" : 18847562
      }, {
        "name" : "Craig Villamor",
        "screen_name" : "cvilly",
        "indices" : [ 84, 91 ],
        "id_str" : "4763791",
        "id" : 4763791
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "li",
        "indices" : [ 92, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/oSOc66B0",
        "expanded_url" : "http:\/\/www.svpg.com\/product-management-then-and-now\/",
        "display_url" : "svpg.com\/product-manage\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "161509414619185152",
    "text" : "Product Management Then and Now: Great blog post by @cagan http:\/\/t.co\/oSOc66B0 via @cvilly #li",
    "id" : 161509414619185152,
    "created_at" : "2012-01-23 18:03:39 +0000",
    "user" : {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "protected" : false,
      "id_str" : "1550251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623216199791329280\/hoNAcmrW_normal.jpg",
      "id" : 1550251,
      "verified" : false
    }
  },
  "id" : 161535013123403777,
  "created_at" : "2012-01-23 19:45:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/6tDFJHxs",
      "expanded_url" : "http:\/\/delicious.com\/stacks\/view\/QUaraZ",
      "display_url" : "delicious.com\/stacks\/view\/QU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "160431589833187329",
  "text" : "For my (in-progress) \"Mobile Learning UX Design\" presentation I've created this Delicious stack of related resources http:\/\/t.co\/6tDFJHxs",
  "id" : 160431589833187329,
  "created_at" : "2012-01-20 18:40:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WorldIADay Vancouver",
      "screen_name" : "WIAD_Vancouver",
      "indices" : [ 3, 18 ],
      "id_str" : "425940138",
      "id" : 425940138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/X26zmQkO",
      "expanded_url" : "http:\/\/worldiadayvancouver.eventbrite.com",
      "display_url" : "worldiadayvancouver.eventbrite.com"
    } ]
  },
  "geo" : { },
  "id_str" : "157881851938222080",
  "text" : "RT @WIAD_Vancouver: A *full day* of IA & UX awesome in the beautiful W2 complex? Yes please! Register now--we're 1\/2 sold out already! h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/X26zmQkO",
        "expanded_url" : "http:\/\/worldiadayvancouver.eventbrite.com",
        "display_url" : "worldiadayvancouver.eventbrite.com"
      } ]
    },
    "geo" : { },
    "id_str" : "157710592466100224",
    "text" : "A *full day* of IA & UX awesome in the beautiful W2 complex? Yes please! Register now--we're 1\/2 sold out already! http:\/\/t.co\/X26zmQkO",
    "id" : 157710592466100224,
    "created_at" : "2012-01-13 06:28:30 +0000",
    "user" : {
      "name" : "WorldIADay Vancouver",
      "screen_name" : "WIAD_Vancouver",
      "protected" : false,
      "id_str" : "425940138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1668077502\/WIAD_Canada_normal.png",
      "id" : 425940138,
      "verified" : false
    }
  },
  "id" : 157881851938222080,
  "created_at" : "2012-01-13 17:49:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 0, 8 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157566845950492672",
  "in_reply_to_user_id" : 1550251,
  "text" : "@dmitryn Thanks for the RT!",
  "id" : 157566845950492672,
  "created_at" : "2012-01-12 20:57:18 +0000",
  "in_reply_to_screen_name" : "dmitryn",
  "in_reply_to_user_id_str" : "1550251",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/g5tRgIKz",
      "expanded_url" : "http:\/\/www.mindmeister.com\/132638751\/mobile-learning-ux-presentation-outline",
      "display_url" : "mindmeister.com\/132638751\/mobi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "157527272901967872",
  "text" : "Interested in mobile learning UX? Working on a presentation about my experiences so far - feedback\/comments welcome. http:\/\/t.co\/g5tRgIKz",
  "id" : 157527272901967872,
  "created_at" : "2012-01-12 18:20:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BraveNewCode",
      "screen_name" : "BraveNewCode",
      "indices" : [ 0, 13 ],
      "id_str" : "89039840",
      "id" : 89039840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ToXu9R4W",
      "expanded_url" : "http:\/\/www.mindmeister.com\/132638751?title=mobile-learning-x-presentation-outline",
      "display_url" : "mindmeister.com\/132638751?titl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "157265028171579392",
  "geo" : { },
  "id_str" : "157268388585025536",
  "in_reply_to_user_id" : 15478959,
  "text" : "@bravenewcode Planning to share with others more details about my mobile learning UX techniques soon, incl. WPtouch Pro http:\/\/t.co\/ToXu9R4W",
  "id" : 157268388585025536,
  "in_reply_to_status_id" : 157265028171579392,
  "created_at" : "2012-01-12 01:11:20 +0000",
  "in_reply_to_screen_name" : "wptouch",
  "in_reply_to_user_id_str" : "15478959",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BraveNewCode",
      "screen_name" : "BraveNewCode",
      "indices" : [ 0, 13 ],
      "id_str" : "89039840",
      "id" : 89039840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157248702975717376",
  "geo" : { },
  "id_str" : "157261291105419264",
  "in_reply_to_user_id" : 15478959,
  "text" : "@bravenewcode Thanks very much for your tweet about my SFU mobile course companion website - it would not have been possible without you!",
  "id" : 157261291105419264,
  "in_reply_to_status_id" : 157248702975717376,
  "created_at" : "2012-01-12 00:43:08 +0000",
  "in_reply_to_screen_name" : "wptouch",
  "in_reply_to_user_id_str" : "15478959",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Breker",
      "screen_name" : "melissabreker",
      "indices" : [ 0, 14 ],
      "id_str" : "23722577",
      "id" : 23722577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156901954235285504",
  "geo" : { },
  "id_str" : "156902807876812800",
  "in_reply_to_user_id" : 23722577,
  "text" : "@melissabreker Audiences that are only somewhat familiar with UX concepts in general, who need to factor-in stakeholder viewpoints\/opinions",
  "id" : 156902807876812800,
  "in_reply_to_status_id" : 156901954235285504,
  "created_at" : "2012-01-11 00:58:39 +0000",
  "in_reply_to_screen_name" : "melissabreker",
  "in_reply_to_user_id_str" : "23722577",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 116, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/6umjOYHB",
      "expanded_url" : "http:\/\/www.slideshare.net\/hibbittsdesign\/involving-stakeholdersinux",
      "display_url" : "slideshare.net\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "156899751575552000",
  "text" : "Second draft of my \"Involving Stakeholders in User Experience (UX) Design\" presentation. Feedback\/comments welcome. #UX http:\/\/t.co\/6umjOYHB",
  "id" : 156899751575552000,
  "created_at" : "2012-01-11 00:46:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/JuB94I1t",
      "expanded_url" : "http:\/\/wp.me\/paWCB-tK",
      "display_url" : "wp.me\/paWCB-tK"
    } ]
  },
  "geo" : { },
  "id_str" : "155419414144098304",
  "text" : "10MobileLearningTrendsfor\u00A02012 http:\/\/t.co\/JuB94I1t",
  "id" : 155419414144098304,
  "created_at" : "2012-01-06 22:44:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 0, 8 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155051349912977408",
  "geo" : { },
  "id_str" : "155078113091530752",
  "in_reply_to_user_id" : 1550251,
  "text" : "@dmitryn Greatly appreciate the offer! I will contact you directly.",
  "id" : 155078113091530752,
  "in_reply_to_status_id" : 155051349912977408,
  "created_at" : "2012-01-06 00:07:58 +0000",
  "in_reply_to_screen_name" : "dmitryn",
  "in_reply_to_user_id_str" : "1550251",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154725038589874176",
  "text" : "Outcomes, not outputs.",
  "id" : 154725038589874176,
  "created_at" : "2012-01-05 00:44:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/mBk1uLM4",
      "expanded_url" : "http:\/\/fluidproject.org\/projects\/",
      "display_url" : "fluidproject.org\/projects\/"
    } ]
  },
  "in_reply_to_status_id_str" : "154711120559607808",
  "geo" : { },
  "id_str" : "154719239721332736",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Have you checked out http:\/\/t.co\/mBk1uLM4, esp. design handbook? iTunesU might have a few items of interest too...",
  "id" : 154719239721332736,
  "in_reply_to_status_id" : 154711120559607808,
  "created_at" : "2012-01-05 00:21:55 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154689320228360192",
  "geo" : { },
  "id_str" : "154705030195314688",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob I might be able to point you to some relevant resources if you could tell me a bit more about what you are looking for.",
  "id" : 154705030195314688,
  "in_reply_to_status_id" : 154689320228360192,
  "created_at" : "2012-01-04 23:25:28 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154684299109609472",
  "text" : "Looking for some feedback on draft presentation about engaging stakeholders in user experience design. If interested please dm or email me.",
  "id" : 154684299109609472,
  "created_at" : "2012-01-04 22:03:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]