Grailbird.data.tweets_2015_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naz Maghsoudi",
      "screen_name" : "NazMaghsoudi",
      "indices" : [ 0, 13 ],
      "id_str" : "373610994",
      "id" : 373610994
    }, {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 14, 21 ],
      "id_str" : "10817782",
      "id" : 10817782
    }, {
      "name" : "Helen Lee",
      "screen_name" : "heli_tomato",
      "indices" : [ 22, 34 ],
      "id_str" : "26872162",
      "id" : 26872162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/KgGagMe3JE",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/sfu-demofest-2015-flipping-the-lms#\/",
      "display_url" : "slides.com\/paulhibbitts\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "671437983891914757",
  "geo" : { },
  "id_str" : "671441092181651456",
  "in_reply_to_user_id" : 373610994,
  "text" : "@NazMaghsoudi @tanbob @heli_tomato Awesome \uD83D\uDE03 You can read more about my experiences using a flat-file CMS for this @ https:\/\/t.co\/KgGagMe3JE",
  "id" : 671441092181651456,
  "in_reply_to_status_id" : 671437983891914757,
  "created_at" : "2015-11-30 21:30:05 +0000",
  "in_reply_to_screen_name" : "NazMaghsoudi",
  "in_reply_to_user_id_str" : "373610994",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671433331402252293",
  "text" : "A flipped-LMS approach is where an open platform,\nin the control of instructors &amp; students,\nserves as a front-end to the institutional LMS.",
  "id" : 671433331402252293,
  "created_at" : "2015-11-30 20:59:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/cbV6X2LmKg",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/traditional-vs-flipped-lms",
      "display_url" : "hibbittsdesign.org\/blog\/tradition\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671406500288536576",
  "text" : "A few thoughts on traditional LMS usage vs. a flipped-LMS approach https:\/\/t.co\/cbV6X2LmKg",
  "id" : 671406500288536576,
  "created_at" : "2015-11-30 19:12:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giansimon Diblas",
      "screen_name" : "giansi72",
      "indices" : [ 0, 9 ],
      "id_str" : "3230477368",
      "id" : 3230477368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "670503618513133568",
  "geo" : { },
  "id_str" : "670742359978713088",
  "in_reply_to_user_id" : 3230477368,
  "text" : "@giansi72 Interesting plugin! Any thoughts\/plans for bootstrap 4 support?",
  "id" : 670742359978713088,
  "in_reply_to_status_id" : 670503618513133568,
  "created_at" : "2015-11-28 23:13:35 +0000",
  "in_reply_to_screen_name" : "giansi72",
  "in_reply_to_user_id_str" : "3230477368",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Word Cloud Bot \u2601",
      "screen_name" : "wordnuvola",
      "indices" : [ 0, 11 ],
      "id_str" : "2896395513",
      "id" : 2896395513
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wordcloud",
      "indices" : [ 12, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670450706520932353",
  "in_reply_to_user_id" : 2896395513,
  "text" : "@wordnuvola #wordcloud",
  "id" : 670450706520932353,
  "created_at" : "2015-11-28 03:54:39 +0000",
  "in_reply_to_screen_name" : "wordnuvola",
  "in_reply_to_user_id_str" : "2896395513",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 3, 7 ],
      "id_str" : "1063291",
      "id" : 1063291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/Dm4mUOKIDv",
      "expanded_url" : "http:\/\/ow.ly\/VaaHY",
      "display_url" : "ow.ly\/VaaHY"
    } ]
  },
  "geo" : { },
  "id_str" : "670344273594679296",
  "text" : "RT @UIE: There is no mobile internet. https:\/\/t.co\/Dm4mUOKIDv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/Dm4mUOKIDv",
        "expanded_url" : "http:\/\/ow.ly\/VaaHY",
        "display_url" : "ow.ly\/VaaHY"
      } ]
    },
    "geo" : { },
    "id_str" : "670338913567973376",
    "text" : "There is no mobile internet. https:\/\/t.co\/Dm4mUOKIDv",
    "id" : 670338913567973376,
    "created_at" : "2015-11-27 20:30:25 +0000",
    "user" : {
      "name" : "UIE",
      "screen_name" : "UIE",
      "protected" : false,
      "id_str" : "1063291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3759116326\/19308cfcdb0b831111d4ee3fc3e6232c_normal.jpeg",
      "id" : 1063291,
      "verified" : false
    }
  },
  "id" : 670344273594679296,
  "created_at" : "2015-11-27 20:51:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Pearson",
      "screen_name" : "shinchpearson",
      "indices" : [ 23, 37 ],
      "id_str" : "17138416",
      "id" : 17138416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/2YkqOTp7gK",
      "expanded_url" : "https:\/\/medium.com\/made-with-creative-commons\/open-for-business-2d4579c7664d#.8tzjr2tnf",
      "display_url" : "medium.com\/made-with-crea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670039904110309378",
  "text" : "\u201COpen for Business\u201D by @shinchpearson https:\/\/t.co\/2YkqOTp7gK",
  "id" : 670039904110309378,
  "created_at" : "2015-11-27 00:42:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/cbV6X2tLlG",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/traditional-vs-flipped-lms",
      "display_url" : "hibbittsdesign.org\/blog\/tradition\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670013837555269632",
  "text" : "A few thoughts on traditional LMS usage vs. a flipped-LMS approach https:\/\/t.co\/cbV6X2tLlG",
  "id" : 670013837555269632,
  "created_at" : "2015-11-26 22:58:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EdMedia @SFU",
      "screen_name" : "EdMediaSFU",
      "indices" : [ 3, 14 ],
      "id_str" : "1428999450",
      "id" : 1428999450
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openedmedia",
      "indices" : [ 135, 140 ]
    }, {
      "text" : "oer",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/nweVDyBuxl",
      "expanded_url" : "http:\/\/edmedia.tlc.sfu.ca\/faculty-showcase\/",
      "display_url" : "edmedia.tlc.sfu.ca\/faculty-showca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669960390655131648",
  "text" : "RT @EdMediaSFU: Sharing a new round of faculty\/staff created OER's, PLUS launching the new 'faculty showcase'! https:\/\/t.co\/nweVDyBuxl #ope\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openedmedia",
        "indices" : [ 119, 131 ]
      }, {
        "text" : "oer",
        "indices" : [ 132, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/nweVDyBuxl",
        "expanded_url" : "http:\/\/edmedia.tlc.sfu.ca\/faculty-showcase\/",
        "display_url" : "edmedia.tlc.sfu.ca\/faculty-showca\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669956637063426048",
    "text" : "Sharing a new round of faculty\/staff created OER's, PLUS launching the new 'faculty showcase'! https:\/\/t.co\/nweVDyBuxl #openedmedia #oer",
    "id" : 669956637063426048,
    "created_at" : "2015-11-26 19:11:24 +0000",
    "user" : {
      "name" : "EdMedia @SFU",
      "screen_name" : "EdMediaSFU",
      "protected" : false,
      "id_str" : "1428999450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604344596206768129\/ZQq4-HyL_normal.jpg",
      "id" : 1428999450,
      "verified" : false
    }
  },
  "id" : 669960390655131648,
  "created_at" : "2015-11-26 19:26:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BobRockefeller",
      "screen_name" : "BobRockefeller",
      "indices" : [ 3, 18 ],
      "id_str" : "1875751",
      "id" : 1875751
    }, {
      "name" : "Typora",
      "screen_name" : "Typora",
      "indices" : [ 20, 27 ],
      "id_str" : "2890926991",
      "id" : 2890926991
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 43, 51 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/IqV30eBnw9",
      "expanded_url" : "http:\/\/www.bobrockefeller.com\/blog\/using-typora-with-grav",
      "display_url" : "bobrockefeller.com\/blog\/using-typ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669678507312570368",
  "text" : "RT @BobRockefeller: @Typora goes well with @getgrav : https:\/\/t.co\/IqV30eBnw9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Typora",
        "screen_name" : "Typora",
        "indices" : [ 0, 7 ],
        "id_str" : "2890926991",
        "id" : 2890926991
      }, {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 23, 31 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/IqV30eBnw9",
        "expanded_url" : "http:\/\/www.bobrockefeller.com\/blog\/using-typora-with-grav",
        "display_url" : "bobrockefeller.com\/blog\/using-typ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669676063530876928",
    "in_reply_to_user_id" : 2890926991,
    "text" : "@Typora goes well with @getgrav : https:\/\/t.co\/IqV30eBnw9",
    "id" : 669676063530876928,
    "created_at" : "2015-11-26 00:36:30 +0000",
    "in_reply_to_screen_name" : "Typora",
    "in_reply_to_user_id_str" : "2890926991",
    "user" : {
      "name" : "BobRockefeller",
      "screen_name" : "BobRockefeller",
      "protected" : false,
      "id_str" : "1875751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459286729065627648\/kftAly_D_normal.jpeg",
      "id" : 1875751,
      "verified" : false
    }
  },
  "id" : 669678507312570368,
  "created_at" : "2015-11-26 00:46:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFUDEMOfest",
      "indices" : [ 23, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/KgGagMvEBc",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/sfu-demofest-2015-flipping-the-lms#\/",
      "display_url" : "slides.com\/paulhibbitts\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669640894195232768",
  "text" : "Slides for yesterday's #SFUDEMOfest presentation \"Flipping the LMS\" are posted at https:\/\/t.co\/KgGagMvEBc Thanks to everyone who attended!",
  "id" : 669640894195232768,
  "created_at" : "2015-11-25 22:16:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla",
      "screen_name" : "mozilla",
      "indices" : [ 13, 21 ],
      "id_str" : "106682853",
      "id" : 106682853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lovetheweb",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/YT15sEHK5T",
      "expanded_url" : "https:\/\/donate.mozilla.org\/en-US\/",
      "display_url" : "donate.mozilla.org\/en-US\/"
    } ]
  },
  "geo" : { },
  "id_str" : "669318631877013504",
  "text" : "I donated to @mozilla today because I #lovetheweb. Join me and help build + protect the Web forever https:\/\/t.co\/YT15sEHK5T",
  "id" : 669318631877013504,
  "created_at" : "2015-11-25 00:56:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Rinaldi",
      "screen_name" : "remotesynth",
      "indices" : [ 3, 15 ],
      "id_str" : "6773532",
      "id" : 6773532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/vp1kEuDazT",
      "expanded_url" : "http:\/\/bit.ly\/1QsgVa5",
      "display_url" : "bit.ly\/1QsgVa5"
    } ]
  },
  "geo" : { },
  "id_str" : "669318408584867841",
  "text" : "RT @remotesynth: Grav is an open source flat-file CMS and Djamil Legato shows how it works. https:\/\/t.co\/vp1kEuDazT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/vp1kEuDazT",
        "expanded_url" : "http:\/\/bit.ly\/1QsgVa5",
        "display_url" : "bit.ly\/1QsgVa5"
      } ]
    },
    "geo" : { },
    "id_str" : "666650781886599168",
    "text" : "Grav is an open source flat-file CMS and Djamil Legato shows how it works. https:\/\/t.co\/vp1kEuDazT",
    "id" : 666650781886599168,
    "created_at" : "2015-11-17 16:15:06 +0000",
    "user" : {
      "name" : "Brian Rinaldi",
      "screen_name" : "remotesynth",
      "protected" : false,
      "id_str" : "6773532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704786565860499456\/eJ8GzX6n_normal.jpg",
      "id" : 6773532,
      "verified" : false
    }
  },
  "id" : 669318408584867841,
  "created_at" : "2015-11-25 00:55:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 13, 21 ],
      "id_str" : "5690792",
      "id" : 5690792
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 129, 137 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669316006859288576",
  "text" : "Shout-out to @draggin for seeing the potential of supporting multiple course facilitators collab with flipped-LMS approach using @getgrav. \uD83D\uDCE3",
  "id" : 669316006859288576,
  "created_at" : "2015-11-25 00:45:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669294605507018754",
  "text" : "Ironic? A flipped-LMS approach increases instructor control, which then can enable more student control over their own learning environment.",
  "id" : 669294605507018754,
  "created_at" : "2015-11-24 23:20:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFUDEMOFest",
      "indices" : [ 31, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669287182826237952",
  "text" : "Thanks to everyone involved in #SFUDEMOFest, great format!",
  "id" : 669287182826237952,
  "created_at" : "2015-11-24 22:51:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/GPwA4HJPjK",
      "expanded_url" : "https:\/\/twitter.com\/EdMediaSFU\/status\/669263493208535040",
      "display_url" : "twitter.com\/EdMediaSFU\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669283428425052160",
  "text" : "What's old is new again, but now with a fully open and collaborative ecosystem to empower it (e.g. GitHub\/GitLab). https:\/\/t.co\/GPwA4HJPjK",
  "id" : 669283428425052160,
  "created_at" : "2015-11-24 22:36:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 0, 9 ],
      "id_str" : "837060721",
      "id" : 837060721
    }, {
      "name" : "InteractionDesignOrg",
      "screen_name" : "interacting",
      "indices" : [ 10, 22 ],
      "id_str" : "24160604",
      "id" : 24160604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669249667054497792",
  "geo" : { },
  "id_str" : "669281206731587584",
  "in_reply_to_user_id" : 837060721,
  "text" : "@m_travin @interacting Thanks for sharing!",
  "id" : 669281206731587584,
  "in_reply_to_status_id" : 669249667054497792,
  "created_at" : "2015-11-24 22:27:28 +0000",
  "in_reply_to_screen_name" : "m_travin",
  "in_reply_to_user_id_str" : "837060721",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 3, 11 ],
      "id_str" : "5690792",
      "id" : 5690792
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 41, 56 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFUDEMOfest",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669280462871752704",
  "text" : "RT @draggin: Great to finally get to see @hibbittsdesign drop his flipped LMS on the people... \"Control goes from the institution, to you\".\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 28, 43 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SFUDEMOfest",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669262532260044801",
    "text" : "Great to finally get to see @hibbittsdesign drop his flipped LMS on the people... \"Control goes from the institution, to you\". #SFUDEMOfest",
    "id" : 669262532260044801,
    "created_at" : "2015-11-24 21:13:16 +0000",
    "user" : {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "protected" : false,
      "id_str" : "5690792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749667549248270336\/7VoQZUTn_normal.jpg",
      "id" : 5690792,
      "verified" : false
    }
  },
  "id" : 669280462871752704,
  "created_at" : "2015-11-24 22:24:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 0, 8 ],
      "id_str" : "5690792",
      "id" : 5690792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669262532260044801",
  "geo" : { },
  "id_str" : "669280378654330881",
  "in_reply_to_user_id" : 5690792,
  "text" : "@draggin Thanks for joining us! Awesome insight re: multi-facilitator course \u263A",
  "id" : 669280378654330881,
  "in_reply_to_status_id" : 669262532260044801,
  "created_at" : "2015-11-24 22:24:11 +0000",
  "in_reply_to_screen_name" : "draggin",
  "in_reply_to_user_id_str" : "5690792",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669218849997332480",
  "geo" : { },
  "id_str" : "669219029844791296",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro sounds pretty sweet!",
  "id" : 669219029844791296,
  "in_reply_to_status_id" : 669218849997332480,
  "created_at" : "2015-11-24 18:20:24 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFUDEMOFest",
      "indices" : [ 14, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669218143886143488",
  "text" : "Heading up to #SFUDEMOFest. My Flipped-LMS presentation is at 1:00pm, and I will have a table demo setup from noon to 2:00pm.",
  "id" : 669218143886143488,
  "created_at" : "2015-11-24 18:16:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669157503578587137",
  "geo" : { },
  "id_str" : "669205741287243782",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Awesome to hear!",
  "id" : 669205741287243782,
  "in_reply_to_status_id" : 669157503578587137,
  "created_at" : "2015-11-24 17:27:36 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668943893531140098",
  "geo" : { },
  "id_str" : "668946085826551808",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro If you have a GitHub account, clicking button will also auto-flow to forking and making page editable :-) Please feel free to try!",
  "id" : 668946085826551808,
  "in_reply_to_status_id" : 668943893531140098,
  "created_at" : "2015-11-24 00:15:49 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/PkrOOf5uIJ",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/resources",
      "display_url" : "cmpt-363-153.hibbittsdesign.com\/resources"
    } ]
  },
  "in_reply_to_status_id_str" : "668943893531140098",
  "geo" : { },
  "id_str" : "668945738924093442",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Yes, right now only on some pages. For example, check out bottom of this page: https:\/\/t.co\/PkrOOf5uIJ. Also top level GitHub icon.",
  "id" : 668945738924093442,
  "in_reply_to_status_id" : 668943893531140098,
  "created_at" : "2015-11-24 00:14:27 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668939560424992768",
  "geo" : { },
  "id_str" : "668939988763963392",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Thanks. Yes, I think now w. GitHub Desktop the required skills and effort has moved down a good chunk. At least that is my hope :-)",
  "id" : 668939988763963392,
  "in_reply_to_status_id" : 668939560424992768,
  "created_at" : "2015-11-23 23:51:36 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 12, 27 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/MpaXZ3GAtf",
      "expanded_url" : "http:\/\/www.wolverton-mountain.com\/articles\/platos-allegory-of-the-cave.html",
      "display_url" : "wolverton-mountain.com\/articles\/plato\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668939969814138880",
  "text" : "RT @btopro: @hibbittsdesign for you, for me, I agree; but we're out of the cave. how to get fellow educators to question https:\/\/t.co\/MpaXZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 0, 15 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/MpaXZ3GAtf",
        "expanded_url" : "http:\/\/www.wolverton-mountain.com\/articles\/platos-allegory-of-the-cave.html",
        "display_url" : "wolverton-mountain.com\/articles\/plato\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "668939391809683456",
    "geo" : { },
    "id_str" : "668939845704749056",
    "in_reply_to_user_id" : 15949844,
    "text" : "@hibbittsdesign for you, for me, I agree; but we're out of the cave. how to get fellow educators to question https:\/\/t.co\/MpaXZ3GAtf",
    "id" : 668939845704749056,
    "in_reply_to_status_id" : 668939391809683456,
    "created_at" : "2015-11-23 23:51:02 +0000",
    "in_reply_to_screen_name" : "hibbittsdesign",
    "in_reply_to_user_id_str" : "15949844",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 668939969814138880,
  "created_at" : "2015-11-23 23:51:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668938884705841152",
  "geo" : { },
  "id_str" : "668939391809683456",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Ideally I agree, but practically I think this is an issue which is a shorter-term challenge. Key for me is making BENEFIT &gt; EFFORT.",
  "id" : 668939391809683456,
  "in_reply_to_status_id" : 668938884705841152,
  "created_at" : "2015-11-23 23:49:13 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668937472399835136",
  "geo" : { },
  "id_str" : "668938086592614400",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Indeed. And really getting students to contribute to any open source projects more effective re: public good + education.",
  "id" : 668938086592614400,
  "in_reply_to_status_id" : 668937472399835136,
  "created_at" : "2015-11-23 23:44:02 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668905871980695552",
  "geo" : { },
  "id_str" : "668937750121308160",
  "in_reply_to_user_id" : 15949844,
  "text" : "@btopro Thanks for the RT. Do you think the way I am framing a flipped-LMS will resonate with educators? Skill-level comments?",
  "id" : 668937750121308160,
  "in_reply_to_status_id" : 668905871980695552,
  "created_at" : "2015-11-23 23:42:42 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 21, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668936110332968960",
  "text" : "Almost giddy with my #SFU CMPT 363 students submitting their design projects today. Future goal: participation in open source projects?",
  "id" : 668936110332968960,
  "created_at" : "2015-11-23 23:36:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/eT75WNKQxh",
      "expanded_url" : "http:\/\/clintlalonde.net\/2015\/11\/23\/the-open-future-is-here-its-just-not-evenly-distributed\/",
      "display_url" : "clintlalonde.net\/2015\/11\/23\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668917171175620608",
  "text" : "RT @clintlalonde: The (open) future is here, it\u2019s just not evenly\u00A0distributed https:\/\/t.co\/eT75WNKQxh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/eT75WNKQxh",
        "expanded_url" : "http:\/\/clintlalonde.net\/2015\/11\/23\/the-open-future-is-here-its-just-not-evenly-distributed\/",
        "display_url" : "clintlalonde.net\/2015\/11\/23\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "668916190366973952",
    "text" : "The (open) future is here, it\u2019s just not evenly\u00A0distributed https:\/\/t.co\/eT75WNKQxh",
    "id" : 668916190366973952,
    "created_at" : "2015-11-23 22:17:02 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 668917171175620608,
  "created_at" : "2015-11-23 22:20:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFUDEMOfest",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/5V3pYzgItm",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/sfu-demofest-2015-flipping-the-lms#\/4",
      "display_url" : "slides.com\/paulhibbitts\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668905871980695552",
  "text" : "More updates to my #SFUDEMOfest Flipped-LMS presentation: Experience Design Goals for Students and Facilitators. https:\/\/t.co\/5V3pYzgItm",
  "id" : 668905871980695552,
  "created_at" : "2015-11-23 21:36:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Woodward",
      "screen_name" : "twoodwar",
      "indices" : [ 3, 12 ],
      "id_str" : "10076902",
      "id" : 10076902
    }, {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 15, 22 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 23, 35 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openuptru",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668871310349484032",
  "text" : "RT @twoodwar: .@brlamb @grantpotter the sandstorm stuff is truly world changing - I'm going to have to do this #openuptru",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian Lamb",
        "screen_name" : "brlamb",
        "indices" : [ 1, 8 ],
        "id_str" : "745903",
        "id" : 745903
      }, {
        "name" : "Grant Potter",
        "screen_name" : "grantpotter",
        "indices" : [ 9, 21 ],
        "id_str" : "6271482",
        "id" : 6271482
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openuptru",
        "indices" : [ 97, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668865039814623233",
    "text" : ".@brlamb @grantpotter the sandstorm stuff is truly world changing - I'm going to have to do this #openuptru",
    "id" : 668865039814623233,
    "created_at" : "2015-11-23 18:53:47 +0000",
    "user" : {
      "name" : "Tom Woodward",
      "screen_name" : "twoodwar",
      "protected" : false,
      "id_str" : "10076902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3607940841\/6d6fca6643e447bc5a76bc9c1cbab4b2_normal.jpeg",
      "id" : 10076902,
      "verified" : false
    }
  },
  "id" : 668871310349484032,
  "created_at" : "2015-11-23 19:18:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucas Wright",
      "screen_name" : "Lucwrite",
      "indices" : [ 0, 9 ],
      "id_str" : "36246383",
      "id" : 36246383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668653747229229056",
  "geo" : { },
  "id_str" : "668662009202765824",
  "in_reply_to_user_id" : 36246383,
  "text" : "@Lucwrite Enjoy your break! Nice to see you again at opened.",
  "id" : 668662009202765824,
  "in_reply_to_status_id" : 668653747229229056,
  "created_at" : "2015-11-23 05:27:00 +0000",
  "in_reply_to_screen_name" : "Lucwrite",
  "in_reply_to_user_id_str" : "36246383",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668575220496646144",
  "text" : "With the title of my preso being \"Flipping the LMS\" some subtitles come to mind:\nThe Best of Both Worlds\nSleeping with the Enemy\n...others?",
  "id" : 668575220496646144,
  "created_at" : "2015-11-22 23:42:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 0, 10 ],
      "id_str" : "12219232",
      "id" : 12219232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668570735342817280",
  "geo" : { },
  "id_str" : "668571343181381632",
  "in_reply_to_user_id" : 12219232,
  "text" : "@dkernohan \uD83D\uDC4D",
  "id" : 668571343181381632,
  "in_reply_to_status_id" : 668570735342817280,
  "created_at" : "2015-11-22 23:26:44 +0000",
  "in_reply_to_screen_name" : "dkernohan",
  "in_reply_to_user_id_str" : "12219232",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668571208401620992",
  "text" : "I've got # of reasons for flipping the LMS down to 3:\n\u2713unmet pedagogical goals\n\u2713access, sharing &amp; collab\n\u2713better student (&amp; facilitator) UX",
  "id" : 668571208401620992,
  "created_at" : "2015-11-22 23:26:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 74, 84 ],
      "id_str" : "12219232",
      "id" : 12219232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668539593826824192",
  "text" : "Why am I looking up old Kenny Loggins songs on a Sunday afternoon? Oh ya, @dkernohan, right. #opened15",
  "id" : 668539593826824192,
  "created_at" : "2015-11-22 21:20:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFUDEMOfest",
      "indices" : [ 14, 26 ]
    }, {
      "text" : "opened15",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/3Y2OZ8BtAY",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/sfu-demofest-2015-flipping-the-lms#\/3",
      "display_url" : "slides.com\/paulhibbitts\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668212355956805633",
  "text" : "Working on my #SFUDEMOfest slides after being so inspired (and humbled) by #opened15. Revising: Why a flipped-LMS? https:\/\/t.co\/3Y2OZ8BtAY",
  "id" : 668212355956805633,
  "created_at" : "2015-11-21 23:40:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/M07tnaMxYS",
      "expanded_url" : "http:\/\/getgrav.org\/downloads",
      "display_url" : "getgrav.org\/downloads"
    } ]
  },
  "geo" : { },
  "id_str" : "667881114896216064",
  "text" : "RT @getgrav: Grav 1.0.0 RC.5 released along with Admin Plugin 1.0.0 RC.5. new Nonce support + many other fixes and improvements! https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/M07tnaMxYS",
        "expanded_url" : "http:\/\/getgrav.org\/downloads",
        "display_url" : "getgrav.org\/downloads"
      } ]
    },
    "geo" : { },
    "id_str" : "667880081746845696",
    "text" : "Grav 1.0.0 RC.5 released along with Admin Plugin 1.0.0 RC.5. new Nonce support + many other fixes and improvements! https:\/\/t.co\/M07tnaMxYS",
    "id" : 667880081746845696,
    "created_at" : "2015-11-21 01:39:54 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 667881114896216064,
  "created_at" : "2015-11-21 01:44:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 5, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667837034304663552",
  "text" : "Dear #opened15, you have totally amazed and inspired me over the past three days. Thank you.",
  "id" : 667837034304663552,
  "created_at" : "2015-11-20 22:48:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/GvTXpRvuEB",
      "expanded_url" : "https:\/\/twitter.com\/actualham\/status\/667822504333864960",
      "display_url" : "twitter.com\/actualham\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667823462111547392",
  "text" : "With a flat-file CMS hosted on GitHub the elements of a CMS w. personal control and collaboration are also possible. https:\/\/t.co\/GvTXpRvuEB",
  "id" : 667823462111547392,
  "created_at" : "2015-11-20 21:54:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667819835259138048",
  "text" : "Is it better or worse to view open practice (for both students and teachers) as a pedagogical goal? #opened15",
  "id" : 667819835259138048,
  "created_at" : "2015-11-20 21:40:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beck Pitt",
      "screen_name" : "BeckPitt",
      "indices" : [ 3, 12 ],
      "id_str" : "176841064",
      "id" : 176841064
    }, {
      "name" : "Rob Farrow",
      "screen_name" : "philosopher1978",
      "indices" : [ 14, 30 ],
      "id_str" : "64362109",
      "id" : 64362109
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667786020440551424",
  "text" : "RT @BeckPitt: @philosopher1978 gets philosophical: \"there's no essence of openness... [it's] the removal of restriction of activity\" #opene\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rob Farrow",
        "screen_name" : "philosopher1978",
        "indices" : [ 0, 16 ],
        "id_str" : "64362109",
        "id" : 64362109
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened15",
        "indices" : [ 119, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667785849795293184",
    "in_reply_to_user_id" : 64362109,
    "text" : "@philosopher1978 gets philosophical: \"there's no essence of openness... [it's] the removal of restriction of activity\" #opened15",
    "id" : 667785849795293184,
    "created_at" : "2015-11-20 19:25:28 +0000",
    "in_reply_to_screen_name" : "philosopher1978",
    "in_reply_to_user_id_str" : "64362109",
    "user" : {
      "name" : "Beck Pitt",
      "screen_name" : "BeckPitt",
      "protected" : false,
      "id_str" : "176841064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592607954131640320\/2Rh6LFeL_normal.jpg",
      "id" : 176841064,
      "verified" : false
    }
  },
  "id" : 667786020440551424,
  "created_at" : "2015-11-20 19:26:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/j5eqPD5NJc",
      "expanded_url" : "https:\/\/twitter.com\/actualham\/status\/667784290105593856",
      "display_url" : "twitter.com\/actualham\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667784547870773248",
  "text" : "D.I.Y. https:\/\/t.co\/j5eqPD5NJc",
  "id" : 667784547870773248,
  "created_at" : "2015-11-20 19:20:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly McElroy",
      "screen_name" : "kellymce",
      "indices" : [ 3, 12 ],
      "id_str" : "57138421",
      "id" : 57138421
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notyetness",
      "indices" : [ 14, 25 ]
    }, {
      "text" : "opened15",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667781391203958784",
  "text" : "RT @kellymce: #notyetness #opened15: openness alone is not an educational virtue.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "notyetness",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "opened15",
        "indices" : [ 12, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667781254394175488",
    "text" : "#notyetness #opened15: openness alone is not an educational virtue.",
    "id" : 667781254394175488,
    "created_at" : "2015-11-20 19:07:12 +0000",
    "user" : {
      "name" : "Kelly McElroy",
      "screen_name" : "kellymce",
      "protected" : false,
      "id_str" : "57138421",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1831421135\/libcard_normal.jpg",
      "id" : 57138421,
      "verified" : false
    }
  },
  "id" : 667781391203958784,
  "created_at" : "2015-11-20 19:07:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 3, 13 ],
      "id_str" : "12219232",
      "id" : 12219232
    }, {
      "name" : "Jen Ross",
      "screen_name" : "jar",
      "indices" : [ 45, 49 ],
      "id_str" : "1350231",
      "id" : 1350231
    }, {
      "name" : "Amy Collier",
      "screen_name" : "amcollier",
      "indices" : [ 54, 64 ],
      "id_str" : "17300374",
      "id" : 17300374
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/8D0GG0eWu0",
      "expanded_url" : "http:\/\/ejournals.library.ualberta.ca\/index.php\/complicity\/article\/viewFile\/16532\/13214",
      "display_url" : "ejournals.library.ualberta.ca\/index.php\/comp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667781104439422976",
  "text" : "RT @dkernohan: Key critical perspective from @jar and @amcollier : Noel Gough on \"Complexity Reduction\": https:\/\/t.co\/8D0GG0eWu0 #opened15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jen Ross",
        "screen_name" : "jar",
        "indices" : [ 30, 34 ],
        "id_str" : "1350231",
        "id" : 1350231
      }, {
        "name" : "Amy Collier",
        "screen_name" : "amcollier",
        "indices" : [ 39, 49 ],
        "id_str" : "17300374",
        "id" : 17300374
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened15",
        "indices" : [ 114, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/8D0GG0eWu0",
        "expanded_url" : "http:\/\/ejournals.library.ualberta.ca\/index.php\/complicity\/article\/viewFile\/16532\/13214",
        "display_url" : "ejournals.library.ualberta.ca\/index.php\/comp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667780868006514688",
    "text" : "Key critical perspective from @jar and @amcollier : Noel Gough on \"Complexity Reduction\": https:\/\/t.co\/8D0GG0eWu0 #opened15",
    "id" : 667780868006514688,
    "created_at" : "2015-11-20 19:05:40 +0000",
    "user" : {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "protected" : false,
      "id_str" : "12219232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757702202437804032\/4Xrm7IIe_normal.jpg",
      "id" : 12219232,
      "verified" : false
    }
  },
  "id" : 667781104439422976,
  "created_at" : "2015-11-20 19:06:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Woodward",
      "screen_name" : "twoodwar",
      "indices" : [ 3, 12 ],
      "id_str" : "10076902",
      "id" : 10076902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667768356506701825",
  "text" : "RT @twoodwar: ~\"The learner should know how they learn best rather than an algorithm\" #opened15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened15",
        "indices" : [ 72, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667768199371358208",
    "text" : "~\"The learner should know how they learn best rather than an algorithm\" #opened15",
    "id" : 667768199371358208,
    "created_at" : "2015-11-20 18:15:19 +0000",
    "user" : {
      "name" : "Tom Woodward",
      "screen_name" : "twoodwar",
      "protected" : false,
      "id_str" : "10076902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3607940841\/6d6fca6643e447bc5a76bc9c1cbab4b2_normal.jpeg",
      "id" : 10076902,
      "verified" : false
    }
  },
  "id" : 667768356506701825,
  "created_at" : "2015-11-20 18:15:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667759650561888257",
  "text" : "Open is not binary. HT Jeff Miller #opened15",
  "id" : 667759650561888257,
  "created_at" : "2015-11-20 17:41:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamison Miller",
      "screen_name" : "MillerJamison",
      "indices" : [ 3, 17 ],
      "id_str" : "236947131",
      "id" : 236947131
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 93, 97 ]
    }, {
      "text" : "opened15",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667755701234601984",
  "text" : "RT @MillerJamison: Tenure &amp; promotion comes up in thinking of faculty incentivization in #OER. What about adjuncts\/sessionals? #opened15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OER",
        "indices" : [ 74, 78 ]
      }, {
        "text" : "opened15",
        "indices" : [ 112, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667755191773499392",
    "text" : "Tenure &amp; promotion comes up in thinking of faculty incentivization in #OER. What about adjuncts\/sessionals? #opened15",
    "id" : 667755191773499392,
    "created_at" : "2015-11-20 17:23:38 +0000",
    "user" : {
      "name" : "Jamison Miller",
      "screen_name" : "MillerJamison",
      "protected" : false,
      "id_str" : "236947131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694146966486433793\/i_Nygr36_normal.png",
      "id" : 236947131,
      "verified" : false
    }
  },
  "id" : 667755701234601984,
  "created_at" : "2015-11-20 17:25:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin DeRosa",
      "screen_name" : "actualham",
      "indices" : [ 3, 13 ],
      "id_str" : "2182862052",
      "id" : 2182862052
    }, {
      "name" : "Rajiv Jhangiani",
      "screen_name" : "thatpsychprof",
      "indices" : [ 46, 60 ],
      "id_str" : "39835900",
      "id" : 39835900
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667755533508579332",
  "text" : "RT @actualham: \"Pedagogy is not a hard sell.\" @thatpsychprof It's not a pitch, it's how we fly. What a beautiful end to the keynote! #opene\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rajiv Jhangiani",
        "screen_name" : "thatpsychprof",
        "indices" : [ 31, 45 ],
        "id_str" : "39835900",
        "id" : 39835900
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened15",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667754345102864384",
    "text" : "\"Pedagogy is not a hard sell.\" @thatpsychprof It's not a pitch, it's how we fly. What a beautiful end to the keynote! #opened15",
    "id" : 667754345102864384,
    "created_at" : "2015-11-20 17:20:16 +0000",
    "user" : {
      "name" : "Robin DeRosa",
      "screen_name" : "actualham",
      "protected" : false,
      "id_str" : "2182862052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479442862648475648\/SlBCXbg7_normal.jpeg",
      "id" : 2182862052,
      "verified" : false
    }
  },
  "id" : 667755533508579332,
  "created_at" : "2015-11-20 17:25:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Bliss",
      "screen_name" : "tjbliss",
      "indices" : [ 3, 11 ],
      "id_str" : "40286676",
      "id" : 40286676
    }, {
      "name" : "David Porter",
      "screen_name" : "dendroglyph",
      "indices" : [ 59, 71 ],
      "id_str" : "15170764",
      "id" : 15170764
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 72, 81 ]
    }, {
      "text" : "hearhear",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667751594465759237",
  "text" : "RT @tjbliss: \"The time has come to make open the default.\" @dendroglyph #opened15 #hearhear",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Porter",
        "screen_name" : "dendroglyph",
        "indices" : [ 46, 58 ],
        "id_str" : "15170764",
        "id" : 15170764
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened15",
        "indices" : [ 59, 68 ]
      }, {
        "text" : "hearhear",
        "indices" : [ 69, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667751348398501888",
    "text" : "\"The time has come to make open the default.\" @dendroglyph #opened15 #hearhear",
    "id" : 667751348398501888,
    "created_at" : "2015-11-20 17:08:22 +0000",
    "user" : {
      "name" : "TJ Bliss",
      "screen_name" : "tjbliss",
      "protected" : false,
      "id_str" : "40286676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765393453928685568\/7MOWy4xa_normal.jpg",
      "id" : 40286676,
      "verified" : false
    }
  },
  "id" : 667751594465759237,
  "created_at" : "2015-11-20 17:09:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BCcampus\/status\/667750886098112512\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/GAPQ6OZy4i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CURT4kqUcAAKecE.jpg",
      "id_str" : "667750876136632320",
      "id" : 667750876136632320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CURT4kqUcAAKecE.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GAPQ6OZy4i"
    } ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 51, 55 ]
    }, {
      "text" : "OpenEd15",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667751010014638080",
  "text" : "RT @BCcampus: Mary Burgess, sharing the history of #OER in B.C. #OpenEd15 https:\/\/t.co\/GAPQ6OZy4i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BCcampus\/status\/667750886098112512\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/GAPQ6OZy4i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CURT4kqUcAAKecE.jpg",
        "id_str" : "667750876136632320",
        "id" : 667750876136632320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CURT4kqUcAAKecE.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/GAPQ6OZy4i"
      } ],
      "hashtags" : [ {
        "text" : "OER",
        "indices" : [ 37, 41 ]
      }, {
        "text" : "OpenEd15",
        "indices" : [ 50, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667750886098112512",
    "text" : "Mary Burgess, sharing the history of #OER in B.C. #OpenEd15 https:\/\/t.co\/GAPQ6OZy4i",
    "id" : 667750886098112512,
    "created_at" : "2015-11-20 17:06:32 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 667751010014638080,
  "created_at" : "2015-11-20 17:07:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viv Rolfe",
      "screen_name" : "VivienRolfe",
      "indices" : [ 3, 15 ],
      "id_str" : "214901910",
      "id" : 214901910
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667749952852914176",
  "text" : "RT @VivienRolfe: Love the transition - content to culture to practice. #opened15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened15",
        "indices" : [ 54, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667747898734473216",
    "text" : "Love the transition - content to culture to practice. #opened15",
    "id" : 667747898734473216,
    "created_at" : "2015-11-20 16:54:39 +0000",
    "user" : {
      "name" : "Viv Rolfe",
      "screen_name" : "VivienRolfe",
      "protected" : false,
      "id_str" : "214901910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751158600010174464\/XqYg6I4q_normal.jpg",
      "id" : 214901910,
      "verified" : false
    }
  },
  "id" : 667749952852914176,
  "created_at" : "2015-11-20 17:02:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Porter",
      "screen_name" : "dendroglyph",
      "indices" : [ 12, 24 ],
      "id_str" : "15170764",
      "id" : 15170764
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667745125615833088",
  "text" : "I loved how @dendroglyph positioned the keynote in terms of open practice. #opened15",
  "id" : 667745125615833088,
  "created_at" : "2015-11-20 16:43:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Coolidge",
      "screen_name" : "acoolidge",
      "indices" : [ 3, 13 ],
      "id_str" : "17416175",
      "id" : 17416175
    }, {
      "name" : "David Porter",
      "screen_name" : "dendroglyph",
      "indices" : [ 37, 49 ],
      "id_str" : "15170764",
      "id" : 15170764
    }, {
      "name" : "Mary Burgess",
      "screen_name" : "maryeburgess",
      "indices" : [ 54, 67 ],
      "id_str" : "24827526",
      "id" : 24827526
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667726996265263105",
  "text" : "RT @acoolidge: Extremely excited for @dendroglyph and @maryeburgess keynote this morning!!  #opened15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Porter",
        "screen_name" : "dendroglyph",
        "indices" : [ 22, 34 ],
        "id_str" : "15170764",
        "id" : 15170764
      }, {
        "name" : "Mary Burgess",
        "screen_name" : "maryeburgess",
        "indices" : [ 39, 52 ],
        "id_str" : "24827526",
        "id" : 24827526
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened15",
        "indices" : [ 77, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667714296390905860",
    "text" : "Extremely excited for @dendroglyph and @maryeburgess keynote this morning!!  #opened15",
    "id" : 667714296390905860,
    "created_at" : "2015-11-20 14:41:08 +0000",
    "user" : {
      "name" : "Amanda Coolidge",
      "screen_name" : "acoolidge",
      "protected" : false,
      "id_str" : "17416175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674352077020073984\/88hyOiSP_normal.jpg",
      "id" : 17416175,
      "verified" : false
    }
  },
  "id" : 667726996265263105,
  "created_at" : "2015-11-20 15:31:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny Bentley",
      "screen_name" : "penpln",
      "indices" : [ 0, 7 ],
      "id_str" : "139954634",
      "id" : 139954634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/gqayF07OGo",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/sfu-demofest-2015-flipping-the-lms",
      "display_url" : "slides.com\/paulhibbitts\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "667475900603084801",
  "geo" : { },
  "id_str" : "667489216918503424",
  "in_reply_to_user_id" : 139954634,
  "text" : "@penpln Plan to share experiences of my flipped-LMS approach next month or two. In the meantime, in-progress slides https:\/\/t.co\/gqayF07OGo",
  "id" : 667489216918503424,
  "in_reply_to_status_id" : 667475900603084801,
  "created_at" : "2015-11-19 23:46:45 +0000",
  "in_reply_to_screen_name" : "penpln",
  "in_reply_to_user_id_str" : "139954634",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CMS Critic",
      "screen_name" : "cmscritic",
      "indices" : [ 3, 13 ],
      "id_str" : "16147963",
      "id" : 16147963
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 61, 69 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Joomla!",
      "screen_name" : "joomla",
      "indices" : [ 70, 77 ],
      "id_str" : "18924866",
      "id" : 18924866
    }, {
      "name" : "October CMS",
      "screen_name" : "octobercms",
      "indices" : [ 78, 89 ],
      "id_str" : "1909956446",
      "id" : 1909956446
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Free",
      "indices" : [ 48, 53 ]
    }, {
      "text" : "CMS",
      "indices" : [ 54, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/NLX6oZu88R",
      "expanded_url" : "http:\/\/awards.cmscritic.com\/vote\/",
      "display_url" : "awards.cmscritic.com\/vote\/"
    } ]
  },
  "geo" : { },
  "id_str" : "667483004483186689",
  "text" : "RT @cmscritic: Announcing the nominees for Best #Free #CMS - @getgrav @joomla @octobercms - vote here: https:\/\/t.co\/NLX6oZu88R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 46, 54 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      }, {
        "name" : "Joomla!",
        "screen_name" : "joomla",
        "indices" : [ 55, 62 ],
        "id_str" : "18924866",
        "id" : 18924866
      }, {
        "name" : "October CMS",
        "screen_name" : "octobercms",
        "indices" : [ 63, 74 ],
        "id_str" : "1909956446",
        "id" : 1909956446
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Free",
        "indices" : [ 33, 38 ]
      }, {
        "text" : "CMS",
        "indices" : [ 39, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/NLX6oZu88R",
        "expanded_url" : "http:\/\/awards.cmscritic.com\/vote\/",
        "display_url" : "awards.cmscritic.com\/vote\/"
      } ]
    },
    "geo" : { },
    "id_str" : "667402751618494465",
    "text" : "Announcing the nominees for Best #Free #CMS - @getgrav @joomla @octobercms - vote here: https:\/\/t.co\/NLX6oZu88R",
    "id" : 667402751618494465,
    "created_at" : "2015-11-19 18:03:10 +0000",
    "user" : {
      "name" : "CMS Critic",
      "screen_name" : "cmscritic",
      "protected" : false,
      "id_str" : "16147963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650486867448737792\/VgUfaW4N_normal.png",
      "id" : 16147963,
      "verified" : false
    }
  },
  "id" : 667483004483186689,
  "created_at" : "2015-11-19 23:22:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 25, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "667482568686637056",
  "text" : "Virtual office hours for #SFU CMPT 363 start in 10 minutes at https:\/\/t.co\/I7fZ1cnbn3.",
  "id" : 667482568686637056,
  "created_at" : "2015-11-19 23:20:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Tepe",
      "screen_name" : "l_tepe",
      "indices" : [ 3, 10 ],
      "id_str" : "369650447",
      "id" : 369650447
    }, {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 124, 140 ],
      "id_str" : "17462723",
      "id" : 17462723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/RWaV3OPzs5",
      "expanded_url" : "https:\/\/wikieducator.org\/OERu\/Open_business_model_canvases\/Open_business_model_canvas_with_questions",
      "display_url" : "wikieducator.org\/OERu\/Open_busi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667471518012604420",
  "text" : "RT @l_tepe: Since there's only 30 copies, here's a digital copy of the Open Business Model Canvas   https:\/\/t.co\/RWaV3OPzs5 @creativecommon\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Creative Commons",
        "screen_name" : "creativecommons",
        "indices" : [ 112, 128 ],
        "id_str" : "17462723",
        "id" : 17462723
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened15",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/RWaV3OPzs5",
        "expanded_url" : "https:\/\/wikieducator.org\/OERu\/Open_business_model_canvases\/Open_business_model_canvas_with_questions",
        "display_url" : "wikieducator.org\/OERu\/Open_busi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667470502953246720",
    "text" : "Since there's only 30 copies, here's a digital copy of the Open Business Model Canvas   https:\/\/t.co\/RWaV3OPzs5 @creativecommons #opened15",
    "id" : 667470502953246720,
    "created_at" : "2015-11-19 22:32:23 +0000",
    "user" : {
      "name" : "Lindsey Tepe",
      "screen_name" : "l_tepe",
      "protected" : false,
      "id_str" : "369650447",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741754548201660416\/a4H4UVqX_normal.jpg",
      "id" : 369650447,
      "verified" : false
    }
  },
  "id" : 667471518012604420,
  "created_at" : "2015-11-19 22:36:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/667468975077388288\/photo\/1",
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/7XoSJlhrI0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUNTfMEUwAEm1qB.jpg",
      "id_str" : "667468965061378049",
      "id" : 667468965061378049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUNTfMEUwAEm1qB.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7XoSJlhrI0"
    } ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667468975077388288",
  "text" : "Excellent to see! #opened15 https:\/\/t.co\/7XoSJlhrI0",
  "id" : 667468975077388288,
  "created_at" : "2015-11-19 22:26:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667465739964579841",
  "text" : "Also, seeing that with a flat-CMS stored on GitHub raw content is more accessible for reuse (i.e.not locked in database). #opened15",
  "id" : 667465739964579841,
  "created_at" : "2015-11-19 22:13:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/1PYhr6HGTm",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/redefining-a-flipped-lms-approach",
      "display_url" : "hibbittsdesign.org\/blog\/redefinin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667464961581449216",
  "text" : "Realizing a flipped-LMS approach also naturally supports reuse term-over-term. https:\/\/t.co\/1PYhr6HGTm #opened15",
  "id" : 667464961581449216,
  "created_at" : "2015-11-19 22:10:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "novak rogic",
      "screen_name" : "supernova_k",
      "indices" : [ 0, 12 ],
      "id_str" : "3446221",
      "id" : 3446221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667464058765881344",
  "in_reply_to_user_id" : 3446221,
  "text" : "@supernova_k  Really enjoyed your #opened15 presentation Novak!",
  "id" : 667464058765881344,
  "created_at" : "2015-11-19 22:06:47 +0000",
  "in_reply_to_screen_name" : "supernova_k",
  "in_reply_to_user_id_str" : "3446221",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/667460848563044352\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/Kb5f7Zq7Wg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUNMF94UcAEgGBU.jpg",
      "id_str" : "667460835174805505",
      "id" : 667460835174805505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUNMF94UcAEgGBU.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Kb5f7Zq7Wg"
    } ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 8, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667460848563044352",
  "text" : "Preach. #opened15 https:\/\/t.co\/Kb5f7Zq7Wg",
  "id" : 667460848563044352,
  "created_at" : "2015-11-19 21:54:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667445000427462661",
  "text" : "Really looking forward to the next three presentations about sustainability models @ #opened15!",
  "id" : 667445000427462661,
  "created_at" : "2015-11-19 20:51:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667433884083216384",
  "text" : "5 years ago my course materials were closed, now they are open. Why? Because, as an educator, it is now more beneficial to do so. #opened15",
  "id" : 667433884083216384,
  "created_at" : "2015-11-19 20:06:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 3, 15 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opensource",
      "indices" : [ 111, 122 ]
    }, {
      "text" : "opened15",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/cIFa09PNoV",
      "expanded_url" : "http:\/\/oet.tru.ca",
      "display_url" : "oet.tru.ca"
    } ]
  },
  "geo" : { },
  "id_str" : "667426438493138948",
  "text" : "RT @grantpotter: 28 active users with 85 grains so far at https:\/\/t.co\/cIFa09PNoV - come take a look at the 42 #opensource applications ava\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/known.networkeffects.ca\" rel=\"nofollow\"\u003Eknown-twitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opensource",
        "indices" : [ 94, 105 ]
      }, {
        "text" : "opened15",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/cIFa09PNoV",
        "expanded_url" : "http:\/\/oet.tru.ca",
        "display_url" : "oet.tru.ca"
      } ]
    },
    "geo" : { },
    "id_str" : "667426310944329728",
    "text" : "28 active users with 85 grains so far at https:\/\/t.co\/cIFa09PNoV - come take a look at the 42 #opensource applications available #opened15",
    "id" : 667426310944329728,
    "created_at" : "2015-11-19 19:36:47 +0000",
    "user" : {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "protected" : false,
      "id_str" : "6271482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639833921228640256\/S63CDenk_normal.jpg",
      "id" : 6271482,
      "verified" : false
    }
  },
  "id" : 667426438493138948,
  "created_at" : "2015-11-19 19:37:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667421799102173185",
  "text" : "More and more I am tempted to remove the word \"education\" altogether. \"Open Practices\" sits well with me right now. #opened15",
  "id" : 667421799102173185,
  "created_at" : "2015-11-19 19:18:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamison Miller",
      "screen_name" : "MillerJamison",
      "indices" : [ 3, 17 ],
      "id_str" : "236947131",
      "id" : 236947131
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 50, 54 ]
    }, {
      "text" : "opened15",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667416267192598528",
  "text" : "RT @MillerJamison: Is faculty reluctance to adopt #OER and open pedagogy exposing pedagogical malpractice? #opened15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OER",
        "indices" : [ 31, 35 ]
      }, {
        "text" : "opened15",
        "indices" : [ 88, 97 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "667412765284265986",
    "geo" : { },
    "id_str" : "667413145032388608",
    "in_reply_to_user_id" : 236947131,
    "text" : "Is faculty reluctance to adopt #OER and open pedagogy exposing pedagogical malpractice? #opened15",
    "id" : 667413145032388608,
    "in_reply_to_status_id" : 667412765284265986,
    "created_at" : "2015-11-19 18:44:28 +0000",
    "in_reply_to_screen_name" : "MillerJamison",
    "in_reply_to_user_id_str" : "236947131",
    "user" : {
      "name" : "Jamison Miller",
      "screen_name" : "MillerJamison",
      "protected" : false,
      "id_str" : "236947131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694146966486433793\/i_Nygr36_normal.png",
      "id" : 236947131,
      "verified" : false
    }
  },
  "id" : 667416267192598528,
  "created_at" : "2015-11-19 18:56:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin DeRosa",
      "screen_name" : "actualham",
      "indices" : [ 3, 13 ],
      "id_str" : "2182862052",
      "id" : 2182862052
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 15, 30 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667415957900431360",
  "text" : "RT @actualham: @hibbittsdesign And \"adoption\" is also an underwhelming word...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 0, 15 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "667411598697369601",
    "geo" : { },
    "id_str" : "667415733559627776",
    "in_reply_to_user_id" : 15949844,
    "text" : "@hibbittsdesign And \"adoption\" is also an underwhelming word...",
    "id" : 667415733559627776,
    "in_reply_to_status_id" : 667411598697369601,
    "created_at" : "2015-11-19 18:54:45 +0000",
    "in_reply_to_screen_name" : "hibbittsdesign",
    "in_reply_to_user_id_str" : "15949844",
    "user" : {
      "name" : "Robin DeRosa",
      "screen_name" : "actualham",
      "protected" : false,
      "id_str" : "2182862052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479442862648475648\/SlBCXbg7_normal.jpeg",
      "id" : 2182862052,
      "verified" : false
    }
  },
  "id" : 667415957900431360,
  "created_at" : "2015-11-19 18:55:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667413300632653824",
  "text" : "My approach to OER: open source software, open collab tools like GitHub, open course development, and public access. Textbooks: 0% #opened15",
  "id" : 667413300632653824,
  "created_at" : "2015-11-19 18:45:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667411598697369601",
  "text" : "When talking about faculty adoption of OER, are we too focused on textbooks? #opened15",
  "id" : 667411598697369601,
  "created_at" : "2015-11-19 18:38:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 3, 13 ],
      "id_str" : "12219232",
      "id" : 12219232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667408493830270976",
  "text" : "RT @dkernohan: Day 2 emerging theme is delegates disagreeing with a cost-saving focus and highlighting need for pedagogic focus #opened15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened15",
        "indices" : [ 113, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667403655461535744",
    "text" : "Day 2 emerging theme is delegates disagreeing with a cost-saving focus and highlighting need for pedagogic focus #opened15",
    "id" : 667403655461535744,
    "created_at" : "2015-11-19 18:06:45 +0000",
    "user" : {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "protected" : false,
      "id_str" : "12219232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757702202437804032\/4Xrm7IIe_normal.jpg",
      "id" : 12219232,
      "verified" : false
    }
  },
  "id" : 667408493830270976,
  "created_at" : "2015-11-19 18:25:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/FdV2jKRzeg",
      "expanded_url" : "https:\/\/twitter.com\/okalrelsrv\/status\/667405422077194241",
      "display_url" : "twitter.com\/okalrelsrv\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667405857076875264",
  "text" : "Along with faculty learning, one would hope. https:\/\/t.co\/FdV2jKRzeg",
  "id" : 667405857076875264,
  "created_at" : "2015-11-19 18:15:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 0, 13 ],
      "id_str" : "91939908",
      "id" : 91939908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667402458256179200",
  "geo" : { },
  "id_str" : "667404814460960768",
  "in_reply_to_user_id" : 91939908,
  "text" : "@davidnwright I have aspirations to help other educators get going with open source re: Grav, GitHub etc. in the New Year - mulling options.",
  "id" : 667404814460960768,
  "in_reply_to_status_id" : 667402458256179200,
  "created_at" : "2015-11-19 18:11:22 +0000",
  "in_reply_to_screen_name" : "davidnwright",
  "in_reply_to_user_id_str" : "91939908",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 0, 13 ],
      "id_str" : "91939908",
      "id" : 91939908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667400781717352448",
  "geo" : { },
  "id_str" : "667402214684680192",
  "in_reply_to_user_id" : 91939908,
  "text" : "@davidnwright Thanks for sharing your thoughts, it's interesting for me as a open source developer + educator.",
  "id" : 667402214684680192,
  "in_reply_to_status_id" : 667400781717352448,
  "created_at" : "2015-11-19 18:01:02 +0000",
  "in_reply_to_screen_name" : "davidnwright",
  "in_reply_to_user_id_str" : "91939908",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 0, 13 ],
      "id_str" : "91939908",
      "id" : 91939908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667396935834140672",
  "geo" : { },
  "id_str" : "667400036704108545",
  "in_reply_to_user_id" : 91939908,
  "text" : "@davidnwright What's your sense so far?",
  "id" : 667400036704108545,
  "in_reply_to_status_id" : 667396935834140672,
  "created_at" : "2015-11-19 17:52:23 +0000",
  "in_reply_to_screen_name" : "davidnwright",
  "in_reply_to_user_id_str" : "91939908",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin DeRosa",
      "screen_name" : "actualham",
      "indices" : [ 3, 13 ],
      "id_str" : "2182862052",
      "id" : 2182862052
    }, {
      "name" : "David Wiley, PhD",
      "screen_name" : "opencontent",
      "indices" : [ 20, 32 ],
      "id_str" : "4514361",
      "id" : 4514361
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 100, 104 ]
    }, {
      "text" : "OpenEd15",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667397596663537664",
  "text" : "RT @actualham: Love @opencontent catching himself and replacing the word \"quality\" with \"efficacy.\" #OER is not a product, but a tool. #Ope\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Wiley, PhD",
        "screen_name" : "opencontent",
        "indices" : [ 5, 17 ],
        "id_str" : "4514361",
        "id" : 4514361
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OER",
        "indices" : [ 85, 89 ]
      }, {
        "text" : "OpenEd15",
        "indices" : [ 120, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667390594080092160",
    "text" : "Love @opencontent catching himself and replacing the word \"quality\" with \"efficacy.\" #OER is not a product, but a tool. #OpenEd15",
    "id" : 667390594080092160,
    "created_at" : "2015-11-19 17:14:51 +0000",
    "user" : {
      "name" : "Robin DeRosa",
      "screen_name" : "actualham",
      "protected" : false,
      "id_str" : "2182862052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479442862648475648\/SlBCXbg7_normal.jpeg",
      "id" : 2182862052,
      "verified" : false
    }
  },
  "id" : 667397596663537664,
  "created_at" : "2015-11-19 17:42:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667206747522662400",
  "geo" : { },
  "id_str" : "667208317614166016",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Good luck with the session!",
  "id" : 667208317614166016,
  "in_reply_to_status_id" : 667206747522662400,
  "created_at" : "2015-11-19 05:10:33 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667197484280647681",
  "geo" : { },
  "id_str" : "667206471956860928",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Better than 5:00am edits though \uD83D\uDE09",
  "id" : 667206471956860928,
  "in_reply_to_status_id" : 667197484280647681,
  "created_at" : "2015-11-19 05:03:13 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Presant",
      "screen_name" : "donpresant",
      "indices" : [ 0, 11 ],
      "id_str" : "22250075",
      "id" : 22250075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667188475616063488",
  "in_reply_to_user_id" : 22250075,
  "text" : "@donpresant It was a pleasure to meet you today Don, thanks for saying hello!",
  "id" : 667188475616063488,
  "created_at" : "2015-11-19 03:51:43 +0000",
  "in_reply_to_screen_name" : "donpresant",
  "in_reply_to_user_id_str" : "22250075",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "indices" : [ 3, 8 ],
      "id_str" : "12534",
      "id" : 12534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/05rLbGohkV",
      "expanded_url" : "http:\/\/abookapart.com\/products\/responsive-design-patterns-principles",
      "display_url" : "abookapart.com\/products\/respo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667179275217342465",
  "text" : "RT @beep: Hello!\n\nI wrote a new book. It\u2019s called \u201CResponsive Design: Patterns and Principles\u201D: https:\/\/t.co\/05rLbGohkV\n\nI really hope you \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/05rLbGohkV",
        "expanded_url" : "http:\/\/abookapart.com\/products\/responsive-design-patterns-principles",
        "display_url" : "abookapart.com\/products\/respo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667006890694582278",
    "text" : "Hello!\n\nI wrote a new book. It\u2019s called \u201CResponsive Design: Patterns and Principles\u201D: https:\/\/t.co\/05rLbGohkV\n\nI really hope you like it.",
    "id" : 667006890694582278,
    "created_at" : "2015-11-18 15:50:09 +0000",
    "user" : {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "protected" : false,
      "id_str" : "12534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653657521559896065\/VWzlUwPL_normal.png",
      "id" : 12534,
      "verified" : false
    }
  },
  "id" : 667179275217342465,
  "created_at" : "2015-11-19 03:15:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 0, 9 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667142428516839424",
  "geo" : { },
  "id_str" : "667159370728247296",
  "in_reply_to_user_id" : 93710949,
  "text" : "@BCcampus Simple: \uD83D\uDC4D",
  "id" : 667159370728247296,
  "in_reply_to_status_id" : 667142428516839424,
  "created_at" : "2015-11-19 01:56:03 +0000",
  "in_reply_to_screen_name" : "BCcampus",
  "in_reply_to_user_id_str" : "93710949",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 69, 77 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 16, 20 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 78, 88 ]
    }, {
      "text" : "SFUDEMOfest",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/DkDxCVmdNc",
      "expanded_url" : "https:\/\/www.sfu.ca\/tlc\/programming\/special\/demofest-2015.html",
      "display_url" : "sfu.ca\/tlc\/programmin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667142338561466368",
  "text" : "I'll be part of #SFU DEMOFest, sharing my flipped-LMS approach using @getgrav #CanvasLMS. More info: https:\/\/t.co\/DkDxCVmdNc #SFUDEMOfest",
  "id" : 667142338561466368,
  "created_at" : "2015-11-19 00:48:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 0, 10 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667079084346892288",
  "geo" : { },
  "id_str" : "667140879069528064",
  "in_reply_to_user_id" : 887742962,
  "text" : "@keroleenl Thanks for sharing \uD83D\uDE00",
  "id" : 667140879069528064,
  "in_reply_to_status_id" : 667079084346892288,
  "created_at" : "2015-11-19 00:42:35 +0000",
  "in_reply_to_screen_name" : "keroleenl",
  "in_reply_to_user_id_str" : "887742962",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 111, 126 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667066547236528128",
  "geo" : { },
  "id_str" : "667138744516898816",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv Thanks for sharing Lynda\uD83D\uDE00 Hope to talk with you next week about sandstorm.io effort underway. FYI, @hibbittsdesign main account.",
  "id" : 667138744516898816,
  "in_reply_to_status_id" : 667066547236528128,
  "created_at" : "2015-11-19 00:34:06 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Coolidge",
      "screen_name" : "acoolidge",
      "indices" : [ 0, 10 ],
      "id_str" : "17416175",
      "id" : 17416175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667041191586742272",
  "geo" : { },
  "id_str" : "667137628886536192",
  "in_reply_to_user_id" : 17416175,
  "text" : "@acoolidge Great to hear, enjoyed your session this AM! Always trying to practice better UDL \uD83D\uDE00",
  "id" : 667137628886536192,
  "in_reply_to_status_id" : 667041191586742272,
  "created_at" : "2015-11-19 00:29:40 +0000",
  "in_reply_to_screen_name" : "acoolidge",
  "in_reply_to_user_id_str" : "17416175",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Irwin DeVries",
      "screen_name" : "IrwinDev",
      "indices" : [ 0, 9 ],
      "id_str" : "120194872",
      "id" : 120194872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667116876753932288",
  "geo" : { },
  "id_str" : "667134622581456897",
  "in_reply_to_user_id" : 120194872,
  "text" : "@IrwinDev Really enjoyed your session! Loved to hear\/see Faculty talk about their experiences, excellent.",
  "id" : 667134622581456897,
  "in_reply_to_status_id" : 667116876753932288,
  "created_at" : "2015-11-19 00:17:43 +0000",
  "in_reply_to_screen_name" : "IrwinDev",
  "in_reply_to_user_id_str" : "120194872",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 3, 13 ],
      "id_str" : "12219232",
      "id" : 12219232
    }, {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 77, 84 ],
      "id_str" : "745903",
      "id" : 745903
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667122468209864704",
  "text" : "RT @dkernohan: The raw power of site cloning with standstorm demonstrated by @brlamb - like a site, deploy it! #opened15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian Lamb",
        "screen_name" : "brlamb",
        "indices" : [ 62, 69 ],
        "id_str" : "745903",
        "id" : 745903
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened15",
        "indices" : [ 96, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667117098624225280",
    "text" : "The raw power of site cloning with standstorm demonstrated by @brlamb - like a site, deploy it! #opened15",
    "id" : 667117098624225280,
    "created_at" : "2015-11-18 23:08:05 +0000",
    "user" : {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "protected" : false,
      "id_str" : "12219232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757702202437804032\/4Xrm7IIe_normal.jpg",
      "id" : 12219232,
      "verified" : false
    }
  },
  "id" : 667122468209864704,
  "created_at" : "2015-11-18 23:29:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D'Arcy Hutchings",
      "screen_name" : "poindekster",
      "indices" : [ 3, 15 ],
      "id_str" : "218789809",
      "id" : 218789809
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/poindekster\/status\/667030966905528320\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Sz8mmAjZ3H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUHFIUoXIAAO86w.jpg",
      "id_str" : "667030966595166208",
      "id" : 667030966595166208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUHFIUoXIAAO86w.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 669,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 669,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/Sz8mmAjZ3H"
    } ],
    "hashtags" : [ {
      "text" : "oer",
      "indices" : [ 119, 123 ]
    }, {
      "text" : "opened",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667112992308236288",
  "text" : "RT @poindekster: Love this image! Those of us on the far left of the spectrum need to help colleagues cross the chasm. #oer #opened https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/poindekster\/status\/667030966905528320\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/Sz8mmAjZ3H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUHFIUoXIAAO86w.jpg",
        "id_str" : "667030966595166208",
        "id" : 667030966595166208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUHFIUoXIAAO86w.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 669,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 669,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/Sz8mmAjZ3H"
      } ],
      "hashtags" : [ {
        "text" : "oer",
        "indices" : [ 102, 106 ]
      }, {
        "text" : "opened",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667030966905528320",
    "text" : "Love this image! Those of us on the far left of the spectrum need to help colleagues cross the chasm. #oer #opened https:\/\/t.co\/Sz8mmAjZ3H",
    "id" : 667030966905528320,
    "created_at" : "2015-11-18 17:25:50 +0000",
    "user" : {
      "name" : "D'Arcy Hutchings",
      "screen_name" : "poindekster",
      "protected" : false,
      "id_str" : "218789809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1297245035\/image_normal.jpg",
      "id" : 218789809,
      "verified" : false
    }
  },
  "id" : 667112992308236288,
  "created_at" : "2015-11-18 22:51:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kylemackie",
      "screen_name" : "kylemackie",
      "indices" : [ 3, 14 ],
      "id_str" : "18153298",
      "id" : 18153298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 82, 91 ]
    }, {
      "text" : "a11y",
      "indices" : [ 92, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667112741623062528",
  "text" : "RT @kylemackie: worth repeating: accessible\/universal design is just good design. #opened15 #a11y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened15",
        "indices" : [ 66, 75 ]
      }, {
        "text" : "a11y",
        "indices" : [ 76, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667056218343473152",
    "text" : "worth repeating: accessible\/universal design is just good design. #opened15 #a11y",
    "id" : 667056218343473152,
    "created_at" : "2015-11-18 19:06:10 +0000",
    "user" : {
      "name" : "kylemackie",
      "screen_name" : "kylemackie",
      "protected" : false,
      "id_str" : "18153298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000643935998\/d50903524cbc5b5f4affd312b6c92257_normal.png",
      "id" : 18153298,
      "verified" : false
    }
  },
  "id" : 667112741623062528,
  "created_at" : "2015-11-18 22:50:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jj johnson",
      "screen_name" : "jjjohnson01",
      "indices" : [ 3, 15 ],
      "id_str" : "16474241",
      "id" : 16474241
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/msRRmAVakH",
      "expanded_url" : "https:\/\/twitter.com\/quill_west\/status\/667062246175064065",
      "display_url" : "twitter.com\/quill_west\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667068236651868160",
  "text" : "RT @jjjohnson01: Faculty testimonies are a great way to spread the word.  #opened15  https:\/\/t.co\/msRRmAVakH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened15",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/msRRmAVakH",
        "expanded_url" : "https:\/\/twitter.com\/quill_west\/status\/667062246175064065",
        "display_url" : "twitter.com\/quill_west\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667067316883038208",
    "text" : "Faculty testimonies are a great way to spread the word.  #opened15  https:\/\/t.co\/msRRmAVakH",
    "id" : 667067316883038208,
    "created_at" : "2015-11-18 19:50:16 +0000",
    "user" : {
      "name" : "jj johnson",
      "screen_name" : "jjjohnson01",
      "protected" : false,
      "id_str" : "16474241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2396929548\/xxx8pjauya2mpt31k1ie_normal.jpeg",
      "id" : 16474241,
      "verified" : false
    }
  },
  "id" : 667068236651868160,
  "created_at" : "2015-11-18 19:53:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viv Rolfe",
      "screen_name" : "VivienRolfe",
      "indices" : [ 3, 15 ],
      "id_str" : "214901910",
      "id" : 214901910
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 107, 116 ]
    }, {
      "text" : "analytics",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667067953930596354",
  "text" : "RT @VivienRolfe: I fear we will build the education system that we can measure - not the one that we need. #opened15 #analytics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened15",
        "indices" : [ 90, 99 ]
      }, {
        "text" : "analytics",
        "indices" : [ 100, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667048229767278592",
    "text" : "I fear we will build the education system that we can measure - not the one that we need. #opened15 #analytics",
    "id" : 667048229767278592,
    "created_at" : "2015-11-18 18:34:25 +0000",
    "user" : {
      "name" : "Viv Rolfe",
      "screen_name" : "VivienRolfe",
      "protected" : false,
      "id_str" : "214901910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751158600010174464\/XqYg6I4q_normal.jpg",
      "id" : 214901910,
      "verified" : false
    }
  },
  "id" : 667067953930596354,
  "created_at" : "2015-11-18 19:52:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole Allen",
      "screen_name" : "txtbks",
      "indices" : [ 3, 10 ],
      "id_str" : "22797514",
      "id" : 22797514
    }, {
      "name" : "Michael Feldstein",
      "screen_name" : "mfeldstein67",
      "indices" : [ 13, 26 ],
      "id_str" : "10187072",
      "id" : 10187072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 86, 90 ]
    }, {
      "text" : "opened15",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667035959397974016",
  "text" : "RT @txtbks: .@mfeldstein67 hits the nail on the head: what is our goal as a movement? #OER is the means not the end - need to define the en\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Feldstein",
        "screen_name" : "mfeldstein67",
        "indices" : [ 1, 14 ],
        "id_str" : "10187072",
        "id" : 10187072
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OER",
        "indices" : [ 74, 78 ]
      }, {
        "text" : "opened15",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667031141233336320",
    "text" : ".@mfeldstein67 hits the nail on the head: what is our goal as a movement? #OER is the means not the end - need to define the end #opened15",
    "id" : 667031141233336320,
    "created_at" : "2015-11-18 17:26:31 +0000",
    "user" : {
      "name" : "Nicole Allen",
      "screen_name" : "txtbks",
      "protected" : false,
      "id_str" : "22797514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652911878390329344\/aBxKHKrx_normal.png",
      "id" : 22797514,
      "verified" : false
    }
  },
  "id" : 667035959397974016,
  "created_at" : "2015-11-18 17:45:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/1PYhr6HGTm",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/redefining-a-flipped-lms-approach",
      "display_url" : "hibbittsdesign.org\/blog\/redefinin\u2026"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ChDmQGRhJh",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/my-dream-workflow-as-an-instructor",
      "display_url" : "hibbittsdesign.org\/blog\/my-dream-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666781600118534145",
  "text" : "Updated definition of a flipped-LMS https:\/\/t.co\/1PYhr6HGTm and an example GitHub-powered workflow for instructors https:\/\/t.co\/ChDmQGRhJh",
  "id" : 666781600118534145,
  "created_at" : "2015-11-18 00:54:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 136, 144 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666694913669492736",
  "text" : "Excited about #opened15 tomorrow! Hoping to connect with others about flipping the LMS with an open platform &amp; share experiences w. @getgrav",
  "id" : 666694913669492736,
  "created_at" : "2015-11-17 19:10:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "666674622851510272",
  "text" : "#SFU CMPT 363 week 10 materials, and Nov 23rd class preparations, are now available on the course companion site at https:\/\/t.co\/I7fZ1cnbn3",
  "id" : 666674622851510272,
  "created_at" : "2015-11-17 17:49:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 107, 115 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 5, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/4XcpTgxyqz",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/running-grav-locally-with-mamp",
      "display_url" : "hibbittsdesign.org\/blog\/running-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666356957628858368",
  "text" : "With #opened15 in Vancouver this week it seems timely to publish another post on the open source no-DB CMS @getgrav https:\/\/t.co\/4XcpTgxyqz",
  "id" : 666356957628858368,
  "created_at" : "2015-11-16 20:47:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 3, 10 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/jp9CwI56Uf",
      "expanded_url" : "https:\/\/github.com\/blog\/2085-a-new-look-for-repositories",
      "display_url" : "github.com\/blog\/2085-a-ne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666347086728704000",
  "text" : "RT @github: Introducing a new look for repositories: https:\/\/t.co\/jp9CwI56Uf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/hubot.github.com\/\" rel=\"nofollow\"\u003EThe Danger Room\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/jp9CwI56Uf",
        "expanded_url" : "https:\/\/github.com\/blog\/2085-a-new-look-for-repositories",
        "display_url" : "github.com\/blog\/2085-a-ne\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666336698373152768",
    "text" : "Introducing a new look for repositories: https:\/\/t.co\/jp9CwI56Uf",
    "id" : 666336698373152768,
    "created_at" : "2015-11-16 19:27:03 +0000",
    "user" : {
      "name" : "GitHub",
      "screen_name" : "github",
      "protected" : false,
      "id_str" : "13334762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616309728688238592\/pBeeJQDQ_normal.png",
      "id" : 13334762,
      "verified" : true
    }
  },
  "id" : 666347086728704000,
  "created_at" : "2015-11-16 20:08:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/4XcpTgxyqz",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/running-grav-locally-with-mamp",
      "display_url" : "hibbittsdesign.org\/blog\/running-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666066183729250305",
  "text" : "Sneak peek at a new blog post - Running Grav CMS Locally with MAMP https:\/\/t.co\/4XcpTgxyqz",
  "id" : 666066183729250305,
  "created_at" : "2015-11-16 01:32:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 3, 18 ],
      "id_str" : "1122631",
      "id" : 1122631
    }, {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "indices" : [ 139, 140 ],
      "id_str" : "944913038",
      "id" : 944913038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VanUXAwards",
      "indices" : [ 20, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/lq5h71VfeA",
      "expanded_url" : "http:\/\/www.vancouveruxawards.com",
      "display_url" : "vancouveruxawards.com"
    } ]
  },
  "geo" : { },
  "id_str" : "666059365086990336",
  "text" : "RT @MalloryOConnor: #VanUXAwards Finalists announced and People's Choice voting now open! And don't forget to get gala tix! https:\/\/t.co\/lq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VanUE",
        "screen_name" : "Van_UE",
        "indices" : [ 128, 135 ],
        "id_str" : "944913038",
        "id" : 944913038
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VanUXAwards",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/lq5h71VfeA",
        "expanded_url" : "http:\/\/www.vancouveruxawards.com",
        "display_url" : "vancouveruxawards.com"
      } ]
    },
    "geo" : { },
    "id_str" : "666025685056557056",
    "text" : "#VanUXAwards Finalists announced and People's Choice voting now open! And don't forget to get gala tix! https:\/\/t.co\/lq5h71VfeA @Van_UE",
    "id" : 666025685056557056,
    "created_at" : "2015-11-15 22:51:12 +0000",
    "user" : {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "protected" : false,
      "id_str" : "1122631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2261747531\/mallory_thumbnail_normal.png",
      "id" : 1122631,
      "verified" : false
    }
  },
  "id" : 666059365086990336,
  "created_at" : "2015-11-16 01:05:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harjit Sajjan",
      "screen_name" : "HarjitSajjan",
      "indices" : [ 3, 16 ],
      "id_str" : "413802355",
      "id" : 413802355
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Paris",
      "indices" : [ 53, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665339927547088896",
  "text" : "RT @HarjitSajjan: My thoughts are with the people of #Paris following today's horrific attacks. Canada mourns your losses.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Paris",
        "indices" : [ 35, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665327950548500480",
    "text" : "My thoughts are with the people of #Paris following today's horrific attacks. Canada mourns your losses.",
    "id" : 665327950548500480,
    "created_at" : "2015-11-14 00:38:39 +0000",
    "user" : {
      "name" : "Harjit Sajjan",
      "screen_name" : "HarjitSajjan",
      "protected" : false,
      "id_str" : "413802355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661304049556320260\/wx5wEiXk_normal.jpg",
      "id" : 413802355,
      "verified" : true
    }
  },
  "id" : 665339927547088896,
  "created_at" : "2015-11-14 01:26:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Bitnami",
      "screen_name" : "bitnami",
      "indices" : [ 35, 43 ],
      "id_str" : "41486415",
      "id" : 41486415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/xSahkyv0bo",
      "expanded_url" : "https:\/\/bitnami.com\/stack\/grav",
      "display_url" : "bitnami.com\/stack\/grav"
    } ]
  },
  "geo" : { },
  "id_str" : "665297270066143232",
  "text" : "RT @getgrav: Help Grav get its own @bitnami stack - https:\/\/t.co\/xSahkyv0bo - takes 2 secs to vote!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bitnami",
        "screen_name" : "bitnami",
        "indices" : [ 22, 30 ],
        "id_str" : "41486415",
        "id" : 41486415
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/xSahkyv0bo",
        "expanded_url" : "https:\/\/bitnami.com\/stack\/grav",
        "display_url" : "bitnami.com\/stack\/grav"
      } ]
    },
    "geo" : { },
    "id_str" : "665297145784696832",
    "text" : "Help Grav get its own @bitnami stack - https:\/\/t.co\/xSahkyv0bo - takes 2 secs to vote!",
    "id" : 665297145784696832,
    "created_at" : "2015-11-13 22:36:14 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 665297270066143232,
  "created_at" : "2015-11-13 22:36:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 59, 67 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/nS8uzOF60T",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/a-few-thoughts-about-flat-file-cms",
      "display_url" : "hibbittsdesign.org\/blog\/a-few-tho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "665252149606002688",
  "text" : "A few of my recent thoughts about flat-file CMS's (such as @getgrav), especially for educators and students. https:\/\/t.co\/nS8uzOF60T",
  "id" : 665252149606002688,
  "created_at" : "2015-11-13 19:37:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665245264379187201",
  "text" : "The fact that a flat-file CMS uses files vs. database is secondary: the game changer is the ECOSYSTEM available, i.e. GitHub, Markdown, etc.",
  "id" : 665245264379187201,
  "created_at" : "2015-11-13 19:10:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Lebson",
      "screen_name" : "CoryLebson",
      "indices" : [ 3, 14 ],
      "id_str" : "23367786",
      "id" : 23367786
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 55, 62 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Zoltan Kollin",
      "screen_name" : "kollinz",
      "indices" : [ 73, 81 ],
      "id_str" : "2183931",
      "id" : 2183931
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 40, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/FmfXhyIpo8",
      "expanded_url" : "https:\/\/medium.com\/@kollinz\/misused-mobile-ux-patterns-84d2b6930570",
      "display_url" : "medium.com\/@kollinz\/misus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "665229884642299904",
  "text" : "RT @CoryLebson: So true! Misused mobile #UX patterns - @medium post from @kollinz https:\/\/t.co\/FmfXhyIpo8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 39, 46 ],
        "id_str" : "571202103",
        "id" : 571202103
      }, {
        "name" : "Zoltan Kollin",
        "screen_name" : "kollinz",
        "indices" : [ 57, 65 ],
        "id_str" : "2183931",
        "id" : 2183931
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 24, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/FmfXhyIpo8",
        "expanded_url" : "https:\/\/medium.com\/@kollinz\/misused-mobile-ux-patterns-84d2b6930570",
        "display_url" : "medium.com\/@kollinz\/misus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "665228748351004673",
    "text" : "So true! Misused mobile #UX patterns - @medium post from @kollinz https:\/\/t.co\/FmfXhyIpo8",
    "id" : 665228748351004673,
    "created_at" : "2015-11-13 18:04:27 +0000",
    "user" : {
      "name" : "Cory Lebson",
      "screen_name" : "CoryLebson",
      "protected" : false,
      "id_str" : "23367786",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583701400854536192\/nxIMA4ji_normal.png",
      "id" : 23367786,
      "verified" : false
    }
  },
  "id" : 665229884642299904,
  "created_at" : "2015-11-13 18:08:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "System Concepts UX",
      "screen_name" : "SystemConcepts",
      "indices" : [ 3, 18 ],
      "id_str" : "45109020",
      "id" : 45109020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/By3b2NxIqw",
      "expanded_url" : "http:\/\/www.uxmatters.com\/mt\/archives\/2015\/11\/10-user-research-myths-and-misconceptions.php",
      "display_url" : "uxmatters.com\/mt\/archives\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664860285602152448",
  "text" : "RT @SystemConcepts: \"There are still many misconceptions about how to gain an understanding of users and their needs\" https:\/\/t.co\/By3b2NxI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/By3b2NxIqw",
        "expanded_url" : "http:\/\/www.uxmatters.com\/mt\/archives\/2015\/11\/10-user-research-myths-and-misconceptions.php",
        "display_url" : "uxmatters.com\/mt\/archives\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "664859708591706113",
    "text" : "\"There are still many misconceptions about how to gain an understanding of users and their needs\" https:\/\/t.co\/By3b2NxIqw",
    "id" : 664859708591706113,
    "created_at" : "2015-11-12 17:38:01 +0000",
    "user" : {
      "name" : "System Concepts UX",
      "screen_name" : "SystemConcepts",
      "protected" : false,
      "id_str" : "45109020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735147753022619649\/VsBq9-lf_normal.jpg",
      "id" : 45109020,
      "verified" : false
    }
  },
  "id" : 664860285602152448,
  "created_at" : "2015-11-12 17:40:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664853954887421955",
  "text" : "More and more I see flat-file CMS's as a solid candidate for e-portfolios too: no database, portable, and simple to install\/transfer\/backup.",
  "id" : 664853954887421955,
  "created_at" : "2015-11-12 17:15:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Travis",
      "screen_name" : "userfocus",
      "indices" : [ 3, 13 ],
      "id_str" : "16509110",
      "id" : 16509110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/zICOoebyxX",
      "expanded_url" : "http:\/\/bit.ly\/1Mp9tGN",
      "display_url" : "bit.ly\/1Mp9tGN"
    } ]
  },
  "geo" : { },
  "id_str" : "664823102975537154",
  "text" : "RT @userfocus: Happy World Usability Day! Grab these eBooks, free for 24hrs. https:\/\/t.co\/zICOoebyxX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/zICOoebyxX",
        "expanded_url" : "http:\/\/bit.ly\/1Mp9tGN",
        "display_url" : "bit.ly\/1Mp9tGN"
      } ]
    },
    "geo" : { },
    "id_str" : "664744949091581952",
    "text" : "Happy World Usability Day! Grab these eBooks, free for 24hrs. https:\/\/t.co\/zICOoebyxX",
    "id" : 664744949091581952,
    "created_at" : "2015-11-12 10:02:00 +0000",
    "user" : {
      "name" : "David Travis",
      "screen_name" : "userfocus",
      "protected" : false,
      "id_str" : "16509110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748776721\/Userfocus_blurry_o_normal.png",
      "id" : 16509110,
      "verified" : false
    }
  },
  "id" : 664823102975537154,
  "created_at" : "2015-11-12 15:12:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 0, 14 ],
      "id_str" : "41268670",
      "id" : 41268670
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 15, 22 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664238642475491328",
  "geo" : { },
  "id_str" : "664238865004130304",
  "in_reply_to_user_id" : 41268670,
  "text" : "@_mike_collins @btopro Isn't that a trick question anyways? \uD83D\uDE09",
  "id" : 664238865004130304,
  "in_reply_to_status_id" : 664238642475491328,
  "created_at" : "2015-11-11 00:31:01 +0000",
  "in_reply_to_screen_name" : "_mike_collins",
  "in_reply_to_user_id_str" : "41268670",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/clintlalonde\/status\/664236435059245056\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/xcmmNmJbli",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTfXf4xWIAAGcau.png",
      "id_str" : "664236412875710464",
      "id" : 664236412875710464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTfXf4xWIAAGcau.png",
      "sizes" : [ {
        "h" : 672,
        "resize" : "fit",
        "w" : 973
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 672,
        "resize" : "fit",
        "w" : 973
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xcmmNmJbli"
    } ],
    "hashtags" : [ {
      "text" : "opened15",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664237350017351680",
  "text" : "RT @clintlalonde: Hey #opened15 where you all from? https:\/\/t.co\/xcmmNmJbli",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/clintlalonde\/status\/664236435059245056\/photo\/1",
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/xcmmNmJbli",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTfXf4xWIAAGcau.png",
        "id_str" : "664236412875710464",
        "id" : 664236412875710464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTfXf4xWIAAGcau.png",
        "sizes" : [ {
          "h" : 672,
          "resize" : "fit",
          "w" : 973
        }, {
          "h" : 235,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 672,
          "resize" : "fit",
          "w" : 973
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/xcmmNmJbli"
      } ],
      "hashtags" : [ {
        "text" : "opened15",
        "indices" : [ 4, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664236435059245056",
    "text" : "Hey #opened15 where you all from? https:\/\/t.co\/xcmmNmJbli",
    "id" : 664236435059245056,
    "created_at" : "2015-11-11 00:21:21 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 664237350017351680,
  "created_at" : "2015-11-11 00:24:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 12, 27 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664234788979535872",
  "text" : "RT @btopro: @hibbittsdesign faculty owns their material and is all on github then university basically just pulls it in to look like their \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 0, 15 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "664231174479286272",
    "geo" : { },
    "id_str" : "664231687493128192",
    "in_reply_to_user_id" : 15949844,
    "text" : "@hibbittsdesign faculty owns their material and is all on github then university basically just pulls it in to look like their stuff :)",
    "id" : 664231687493128192,
    "in_reply_to_status_id" : 664231174479286272,
    "created_at" : "2015-11-11 00:02:29 +0000",
    "in_reply_to_screen_name" : "hibbittsdesign",
    "in_reply_to_user_id_str" : "15949844",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 664234788979535872,
  "created_at" : "2015-11-11 00:14:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/oq6YryBygk",
      "expanded_url" : "https:\/\/twitter.com\/hibbittsdesign\/status\/663497928338608128",
      "display_url" : "twitter.com\/hibbittsdesign\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "664231687493128192",
  "geo" : { },
  "id_str" : "664232258019049472",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Exactly \uD83D\uDE09  Also see https:\/\/t.co\/oq6YryBygk",
  "id" : 664232258019049472,
  "in_reply_to_status_id" : 664231687493128192,
  "created_at" : "2015-11-11 00:04:45 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664230152084303872",
  "geo" : { },
  "id_str" : "664231174479286272",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro It supports GitLab, which led me to discovering my own univ supports that which is a dream for flipped-LMS re: student contribs",
  "id" : 664231174479286272,
  "in_reply_to_status_id" : 664230152084303872,
  "created_at" : "2015-11-11 00:00:27 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 46, 58 ],
      "id_str" : "6271482",
      "id" : 6271482
    }, {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 63, 70 ],
      "id_str" : "745903",
      "id" : 745903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664230152084303872",
  "geo" : { },
  "id_str" : "664230778394402816",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Just starting to explore it thanks to @grantpotter and @brlamb for educational purposes here in BC. Lots of possibilities!",
  "id" : 664230778394402816,
  "in_reply_to_status_id" : 664230152084303872,
  "created_at" : "2015-11-10 23:58:53 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/6KmNPFPFzd",
      "expanded_url" : "https:\/\/sandstorm.io\/",
      "display_url" : "sandstorm.io"
    } ]
  },
  "in_reply_to_status_id_str" : "664229051457019904",
  "geo" : { },
  "id_str" : "664229803491364864",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro BTW, have you checked out https:\/\/t.co\/6KmNPFPFzd?",
  "id" : 664229803491364864,
  "in_reply_to_status_id" : 664229051457019904,
  "created_at" : "2015-11-10 23:55:00 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664229051457019904",
  "geo" : { },
  "id_str" : "664229676294889472",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Thanks for the heads-up. Often updating a small # of files with the flat-file CMS I use, rare high-end maybe several 100 for me.",
  "id" : 664229676294889472,
  "in_reply_to_status_id" : 664229051457019904,
  "created_at" : "2015-11-10 23:54:30 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 25, 32 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "get lab",
      "screen_name" : "getlab",
      "indices" : [ 46, 53 ],
      "id_str" : "256943340",
      "id" : 256943340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/BDlj55xfLE",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/22639815\/does-github-for-windows-work-with-gitlab\/22639891#22639891",
      "display_url" : "stackoverflow.com\/questions\/2263\u2026"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Xv8rAi0xDp",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/25548236\/can-we-use-the-github-mac-app-with-gitlab",
      "display_url" : "stackoverflow.com\/questions\/2554\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664224084633391105",
  "text" : "So cool that you can use @GitHub Desktop with @GetLab! Win instructions: https:\/\/t.co\/BDlj55xfLE Mac instructions: https:\/\/t.co\/Xv8rAi0xDp",
  "id" : 664224084633391105,
  "created_at" : "2015-11-10 23:32:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/ChDmQGRhJh",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/my-dream-workflow-as-an-instructor",
      "display_url" : "hibbittsdesign.org\/blog\/my-dream-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664209482994479104",
  "text" : "New development... I think I've got my workflow https:\/\/t.co\/ChDmQGRhJh to work with SFU's hosted GitLab! FIPPA compliant student collab \uD83D\uDE00",
  "id" : 664209482994479104,
  "created_at" : "2015-11-10 22:34:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 0, 12 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    }, {
      "name" : "Jade Q Wang",
      "screen_name" : "qiqing",
      "indices" : [ 37, 44 ],
      "id_str" : "14594292",
      "id" : 14594292
    }, {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 121, 133 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "663923734495891456",
  "geo" : { },
  "id_str" : "664152377528750080",
  "in_reply_to_user_id" : 14594292,
  "text" : "@SandstormIO Thanks for reaching out @qiqing, will do. Looks like you are already in contact with lead project developer @grantpotter too.",
  "id" : 664152377528750080,
  "in_reply_to_status_id" : 663923734495891456,
  "created_at" : "2015-11-10 18:47:20 +0000",
  "in_reply_to_screen_name" : "qiqing",
  "in_reply_to_user_id_str" : "14594292",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "664133976508907520",
  "text" : "#SFU CMPT 363 week 9 materials, and Nov 16th class preparations, are now available on the course companion site at https:\/\/t.co\/I7fZ1cnbn3",
  "id" : 664133976508907520,
  "created_at" : "2015-11-10 17:34:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darren Nerland",
      "screen_name" : "dnerland",
      "indices" : [ 0, 9 ],
      "id_str" : "14218141",
      "id" : 14218141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "663883415335243777",
  "geo" : { },
  "id_str" : "663884825896448000",
  "in_reply_to_user_id" : 14218141,
  "text" : "@dnerland You do not wany to be throwing the Catchbox around when laptops can get hit, or also coffees...",
  "id" : 663884825896448000,
  "in_reply_to_status_id" : 663883415335243777,
  "created_at" : "2015-11-10 01:04:11 +0000",
  "in_reply_to_screen_name" : "dnerland",
  "in_reply_to_user_id_str" : "14218141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darren Nerland",
      "screen_name" : "dnerland",
      "indices" : [ 0, 9 ],
      "id_str" : "14218141",
      "id" : 14218141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "663883415335243777",
  "geo" : { },
  "id_str" : "663884391320457216",
  "in_reply_to_user_id" : 14218141,
  "text" : "@dnerland I've been using one for my CMPT 363 class w. 80 students and have found the experience positive overall. No laptop policy helps \uD83D\uDE00",
  "id" : 663884391320457216,
  "in_reply_to_status_id" : 663883415335243777,
  "created_at" : "2015-11-10 01:02:27 +0000",
  "in_reply_to_screen_name" : "dnerland",
  "in_reply_to_user_id_str" : "14218141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 83, 93 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/ElwUriyVwO",
      "expanded_url" : "https:\/\/shar.es\/15wqyn",
      "display_url" : "shar.es\/15wqyn"
    } ]
  },
  "geo" : { },
  "id_str" : "663863734427762688",
  "text" : "10 User Research Myths and Misconceptions :: UXmatters https:\/\/t.co\/ElwUriyVwO via @sharethis",
  "id" : 663863734427762688,
  "created_at" : "2015-11-09 23:40:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 50, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/ChDmQGRhJh",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/my-dream-workflow-as-an-instructor",
      "display_url" : "hibbittsdesign.org\/blog\/my-dream-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663842964460847104",
  "text" : "Full details of the workflow I demonstrated in my #etug \"Flipping the LMS\" session on Friday are available at https:\/\/t.co\/ChDmQGRhJh",
  "id" : 663842964460847104,
  "created_at" : "2015-11-09 22:17:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/EY58irIdCr",
      "expanded_url" : "http:\/\/hackeducation.com\/2015\/11\/09\/revenge\/",
      "display_url" : "hackeducation.com\/2015\/11\/09\/rev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663790809351778304",
  "text" : "RT @audreywatters: My latest book: The Revenge of the Monsters of Education Technology https:\/\/t.co\/EY58irIdCr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/withknown.com\/\" rel=\"nofollow\"\u003EKnown Twitter Syndication\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/EY58irIdCr",
        "expanded_url" : "http:\/\/hackeducation.com\/2015\/11\/09\/revenge\/",
        "display_url" : "hackeducation.com\/2015\/11\/09\/rev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "663788630444367873",
    "text" : "My latest book: The Revenge of the Monsters of Education Technology https:\/\/t.co\/EY58irIdCr",
    "id" : 663788630444367873,
    "created_at" : "2015-11-09 18:41:56 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 663790809351778304,
  "created_at" : "2015-11-09 18:50:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 87, 95 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 50, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/gqayF07OGo",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/sfu-demofest-2015-flipping-the-lms",
      "display_url" : "slides.com\/paulhibbitts\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663789626956484608",
  "text" : "For anyone who missed this earlier, slides for my #etug session on flipping the LMS w. @getgrav CMS + GitHub are at https:\/\/t.co\/gqayF07OGo.",
  "id" : 663789626956484608,
  "created_at" : "2015-11-09 18:45:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IDEO",
      "screen_name" : "ideo",
      "indices" : [ 3, 8 ],
      "id_str" : "23462787",
      "id" : 23462787
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ideolabs",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/oP4LEylAIg",
      "expanded_url" : "http:\/\/ideo.to\/8V13Kg",
      "display_url" : "ideo.to\/8V13Kg"
    } ]
  },
  "geo" : { },
  "id_str" : "663786346280914944",
  "text" : "RT @ideo: Stop Critiquing, Start Creating: https:\/\/t.co\/oP4LEylAIg #ideolabs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ideolabs",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/oP4LEylAIg",
        "expanded_url" : "http:\/\/ideo.to\/8V13Kg",
        "display_url" : "ideo.to\/8V13Kg"
      } ]
    },
    "geo" : { },
    "id_str" : "663786041749409792",
    "text" : "Stop Critiquing, Start Creating: https:\/\/t.co\/oP4LEylAIg #ideolabs",
    "id" : 663786041749409792,
    "created_at" : "2015-11-09 18:31:39 +0000",
    "user" : {
      "name" : "IDEO",
      "screen_name" : "ideo",
      "protected" : false,
      "id_str" : "23462787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760208707682603008\/HgqAWOLi_normal.jpg",
      "id" : 23462787,
      "verified" : true
    }
  },
  "id" : 663786346280914944,
  "created_at" : "2015-11-09 18:32:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Materialize",
      "screen_name" : "MaterializeCSS",
      "indices" : [ 3, 18 ],
      "id_str" : "2874337545",
      "id" : 2874337545
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MaterializeCSS\/status\/663526031412740096\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/O7yP5UcY87",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CTVRaM_UwAABFUa.png",
      "id_str" : "663526030712291328",
      "id" : 663526030712291328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CTVRaM_UwAABFUa.png",
      "sizes" : [ {
        "h" : 357,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 846
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 846
      } ],
      "display_url" : "pic.twitter.com\/O7yP5UcY87"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663528134210293761",
  "text" : "RT @MaterializeCSS: Version 0.97.2 has just been shipped! This release includes tweaks, and a much needed fix to our Meteor package. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MaterializeCSS\/status\/663526031412740096\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/O7yP5UcY87",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CTVRaM_UwAABFUa.png",
        "id_str" : "663526030712291328",
        "id" : 663526030712291328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CTVRaM_UwAABFUa.png",
        "sizes" : [ {
          "h" : 357,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 503,
          "resize" : "fit",
          "w" : 846
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 202,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 503,
          "resize" : "fit",
          "w" : 846
        } ],
        "display_url" : "pic.twitter.com\/O7yP5UcY87"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663526031412740096",
    "text" : "Version 0.97.2 has just been shipped! This release includes tweaks, and a much needed fix to our Meteor package. https:\/\/t.co\/O7yP5UcY87",
    "id" : 663526031412740096,
    "created_at" : "2015-11-09 01:18:28 +0000",
    "user" : {
      "name" : "Materialize",
      "screen_name" : "MaterializeCSS",
      "protected" : false,
      "id_str" : "2874337545",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/532662364613525504\/GN559Lfb_normal.png",
      "id" : 2874337545,
      "verified" : false
    }
  },
  "id" : 663528134210293761,
  "created_at" : "2015-11-09 01:26:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 52, 60 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 8, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663497928338608128",
  "text" : "Another #etug highlight was that a flipped-LMS with @getgrav keeps content in the hands of the instructor, which THEN can be openly shared.",
  "id" : 663497928338608128,
  "created_at" : "2015-11-08 23:26:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 123, 131 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663497675216564224",
  "text" : "During last week's #etug Workshop the issue of LMS data lock-in came up, which a flipped-LMS approach with no-database CMS @getgrav avoids.",
  "id" : 663497675216564224,
  "created_at" : "2015-11-08 23:25:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 75, 83 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 11, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663492597852172288",
  "text" : "Discovered #SFU has a GitLab server, which means a flipped-LMS approach w. @getgrav can store student-identified data w. FIPPA compliance. \uD83D\uDC4D",
  "id" : 663492597852172288,
  "created_at" : "2015-11-08 23:05:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Troy Welch",
      "screen_name" : "TroyWelch1",
      "indices" : [ 0, 11 ],
      "id_str" : "331120877",
      "id" : 331120877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663485671965749248",
  "in_reply_to_user_id" : 331120877,
  "text" : "@TroyWelch1 It was nice to meet you at ETUG Troy! Hope we may connect again sometime.",
  "id" : 663485671965749248,
  "created_at" : "2015-11-08 22:38:05 +0000",
  "in_reply_to_screen_name" : "TroyWelch1",
  "in_reply_to_user_id_str" : "331120877",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenna Clarke Gray",
      "screen_name" : "brennacgray",
      "indices" : [ 0, 12 ],
      "id_str" : "14109848",
      "id" : 14109848
    }, {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 13, 26 ],
      "id_str" : "91939908",
      "id" : 91939908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663485299708702720",
  "in_reply_to_user_id" : 14109848,
  "text" : "@brennacgray @davidnwright Enjoyed your session at ETUG! If either of you further check-out the Grav CMS love to hear your thoughts.",
  "id" : 663485299708702720,
  "created_at" : "2015-11-08 22:36:37 +0000",
  "in_reply_to_screen_name" : "brennacgray",
  "in_reply_to_user_id_str" : "14109848",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Potter",
      "screen_name" : "hey__MP",
      "indices" : [ 0, 8 ],
      "id_str" : "1448965550",
      "id" : 1448965550
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 9, 16 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/6KmNPFPFzd",
      "expanded_url" : "https:\/\/sandstorm.io\/",
      "display_url" : "sandstorm.io"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ChDmQGRhJh",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/my-dream-workflow-as-an-instructor",
      "display_url" : "hibbittsdesign.org\/blog\/my-dream-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "663412407495237632",
  "geo" : { },
  "id_str" : "663468778001338368",
  "in_reply_to_user_id" : 1448965550,
  "text" : "@hey__MP @btopro Thanks very much! FYI, this is in context of using https:\/\/t.co\/6KmNPFPFzd to support this workflow https:\/\/t.co\/ChDmQGRhJh",
  "id" : 663468778001338368,
  "in_reply_to_status_id" : 663412407495237632,
  "created_at" : "2015-11-08 21:30:57 +0000",
  "in_reply_to_screen_name" : "hey__MP",
  "in_reply_to_user_id_str" : "1448965550",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663162780178997248",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Hope this Q. makes sense \uD83D\uDE00 Is it possible for Vagrant SDK to contain GitLab + flat-file CMS, and to updated files w. GitLab push? TY",
  "id" : 663162780178997248,
  "created_at" : "2015-11-08 01:15:02 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "indices" : [ 3, 11 ],
      "id_str" : "783092",
      "id" : 783092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indieweb",
      "indices" : [ 49, 58 ]
    }, {
      "text" : "opensource",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/t9LpnF8TqB",
      "expanded_url" : "http:\/\/werd.io\/2015\/open-issues-lessons-learned-building-an-open-source-business",
      "display_url" : "werd.io\/2015\/open-issu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663151386058555392",
  "text" : "RT @benwerd: I'm interested in feedback from the #indieweb and #opensource communities. Building an open source business: https:\/\/t.co\/t9Lp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/werd.io\/\" rel=\"nofollow\"\u003Ewerd.io\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "indieweb",
        "indices" : [ 36, 45 ]
      }, {
        "text" : "opensource",
        "indices" : [ 50, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/t9LpnF8TqB",
        "expanded_url" : "http:\/\/werd.io\/2015\/open-issues-lessons-learned-building-an-open-source-business",
        "display_url" : "werd.io\/2015\/open-issu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "663133806828720128",
    "text" : "I'm interested in feedback from the #indieweb and #opensource communities. Building an open source business: https:\/\/t.co\/t9LpnF8TqB",
    "id" : 663133806828720128,
    "created_at" : "2015-11-07 23:19:54 +0000",
    "user" : {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "protected" : false,
      "id_str" : "783092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681986174966104064\/t3BubQKk_normal.jpg",
      "id" : 783092,
      "verified" : true
    }
  },
  "id" : 663151386058555392,
  "created_at" : "2015-11-08 00:29:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clark Quinn",
      "screen_name" : "Quinnovator",
      "indices" : [ 3, 15 ],
      "id_str" : "15312626",
      "id" : 15312626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/LJhFKBK1t0",
      "expanded_url" : "http:\/\/blog.learnlets.com\/?p=4617",
      "display_url" : "blog.learnlets.com\/?p=4617"
    } ]
  },
  "geo" : { },
  "id_str" : "663143046809124864",
  "text" : "RT @Quinnovator: Latest Learnlet: Vale Jay Cross: https:\/\/t.co\/LJhFKBK1t0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/LJhFKBK1t0",
        "expanded_url" : "http:\/\/blog.learnlets.com\/?p=4617",
        "display_url" : "blog.learnlets.com\/?p=4617"
      } ]
    },
    "geo" : { },
    "id_str" : "663100795831750656",
    "text" : "Latest Learnlet: Vale Jay Cross: https:\/\/t.co\/LJhFKBK1t0",
    "id" : 663100795831750656,
    "created_at" : "2015-11-07 21:08:44 +0000",
    "user" : {
      "name" : "Clark Quinn",
      "screen_name" : "Quinnovator",
      "protected" : false,
      "id_str" : "15312626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639121092083224576\/9rAOP3Tq_normal.jpg",
      "id" : 15312626,
      "verified" : false
    }
  },
  "id" : 663143046809124864,
  "created_at" : "2015-11-07 23:56:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 69, 77 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/KgGagMvEBc",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/sfu-demofest-2015-flipping-the-lms#\/",
      "display_url" : "slides.com\/paulhibbitts\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "662788760682172416",
  "text" : "Slides to today's #etug session on Flipping the LMS with open source @getgrav CMS: https:\/\/t.co\/KgGagMvEBc Thanks to everyone who attended!",
  "id" : 662788760682172416,
  "created_at" : "2015-11-07 00:28:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 14, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662781732643434496",
  "text" : "Another great #etug Fall Workshop, thanks to everyone involved! Lots to reflect upon.",
  "id" : 662781732643434496,
  "created_at" : "2015-11-07 00:00:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prollster",
      "screen_name" : "prollsters",
      "indices" : [ 0, 11 ],
      "id_str" : "3016570948",
      "id" : 3016570948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662753296998887425",
  "geo" : { },
  "id_str" : "662755341873094656",
  "in_reply_to_user_id" : 3016570948,
  "text" : "@prollsters Thanks very much!",
  "id" : 662755341873094656,
  "in_reply_to_status_id" : 662753296998887425,
  "created_at" : "2015-11-06 22:16:01 +0000",
  "in_reply_to_screen_name" : "prollsters",
  "in_reply_to_user_id_str" : "3016570948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 40, 45 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/TrHXbUSfDB",
      "expanded_url" : "https:\/\/twitter.com\/brlamb\/status\/662748953885061120",
      "display_url" : "twitter.com\/brlamb\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "662755250252742656",
  "text" : "It was a pleasure to share this work at @etug! https:\/\/t.co\/TrHXbUSfDB",
  "id" : 662755250252742656,
  "created_at" : "2015-11-06 22:15:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    }, {
      "name" : "AMS Student Society",
      "screen_name" : "AMS_UBC",
      "indices" : [ 121, 129 ],
      "id_str" : "25581363",
      "id" : 25581363
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662737050114785281",
  "text" : "RT @clintlalonde: Great to see UBC student leaders Jenna Omassi and Daniel Munro talking open textbook advocacy at #etug @AMS_UBC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AMS Student Society",
        "screen_name" : "AMS_UBC",
        "indices" : [ 103, 111 ],
        "id_str" : "25581363",
        "id" : 25581363
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 97, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662699922697773057",
    "text" : "Great to see UBC student leaders Jenna Omassi and Daniel Munro talking open textbook advocacy at #etug @AMS_UBC",
    "id" : 662699922697773057,
    "created_at" : "2015-11-06 18:35:48 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 662737050114785281,
  "created_at" : "2015-11-06 21:03:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VCC's CID News feed",
      "screen_name" : "CIDvcc",
      "indices" : [ 3, 10 ],
      "id_str" : "50566264",
      "id" : 50566264
    }, {
      "name" : "EdMedia @SFU",
      "screen_name" : "EdMediaSFU",
      "indices" : [ 13, 24 ],
      "id_str" : "1428999450",
      "id" : 1428999450
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/EdMediaSFU\/status\/662678079798579202\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/Fo2QkZFhoq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTJOMuWUAAA8peL.jpg",
      "id_str" : "662678075683897344",
      "id" : 662678075683897344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTJOMuWUAAA8peL.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Fo2QkZFhoq"
    } ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 26, 31 ]
    }, {
      "text" : "vcc",
      "indices" : [ 58, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662686986558312448",
  "text" : "RT @CIDvcc: \"@EdMediaSFU: #etug getting things started at #vcc https:\/\/t.co\/Fo2QkZFhoq\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EdMedia @SFU",
        "screen_name" : "EdMediaSFU",
        "indices" : [ 1, 12 ],
        "id_str" : "1428999450",
        "id" : 1428999450
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/EdMediaSFU\/status\/662678079798579202\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/Fo2QkZFhoq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTJOMuWUAAA8peL.jpg",
        "id_str" : "662678075683897344",
        "id" : 662678075683897344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTJOMuWUAAA8peL.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Fo2QkZFhoq"
      } ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 14, 19 ]
      }, {
        "text" : "vcc",
        "indices" : [ 46, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662684358734540801",
    "text" : "\"@EdMediaSFU: #etug getting things started at #vcc https:\/\/t.co\/Fo2QkZFhoq\"",
    "id" : 662684358734540801,
    "created_at" : "2015-11-06 17:33:57 +0000",
    "user" : {
      "name" : "VCC's CID News feed",
      "screen_name" : "CIDvcc",
      "protected" : false,
      "id_str" : "50566264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1689446460\/CID_Logo_Final_60px_normal.gif",
      "id" : 50566264,
      "verified" : false
    }
  },
  "id" : 662686986558312448,
  "created_at" : "2015-11-06 17:44:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulund",
      "screen_name" : "paulund",
      "indices" : [ 3, 11 ],
      "id_str" : "24149025",
      "id" : 24149025
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WebDev",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/iZc0wFxam1",
      "expanded_url" : "http:\/\/bit.ly\/1PbR9Xw",
      "display_url" : "bit.ly\/1PbR9Xw"
    } ]
  },
  "geo" : { },
  "id_str" : "662510449615761408",
  "text" : "RT @paulund: Why Static Website Generators Are The Next Big Thing \u2013 Smashing Magazine https:\/\/t.co\/iZc0wFxam1 #WebDev",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WebDev",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/iZc0wFxam1",
        "expanded_url" : "http:\/\/bit.ly\/1PbR9Xw",
        "display_url" : "bit.ly\/1PbR9Xw"
      } ]
    },
    "geo" : { },
    "id_str" : "662270440157638656",
    "text" : "Why Static Website Generators Are The Next Big Thing \u2013 Smashing Magazine https:\/\/t.co\/iZc0wFxam1 #WebDev",
    "id" : 662270440157638656,
    "created_at" : "2015-11-05 14:09:11 +0000",
    "user" : {
      "name" : "Paulund",
      "screen_name" : "paulund",
      "protected" : false,
      "id_str" : "24149025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451008161579692034\/auDA_uKV_normal.jpeg",
      "id" : 24149025,
      "verified" : false
    }
  },
  "id" : 662510449615761408,
  "created_at" : "2015-11-06 06:02:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 89, 97 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662504984315998209",
  "text" : "Nice to kickoff the #etug Fall Workshop at Library Square tonight! Flipping the LMS with @getgrav might yet be in the mix for tomorrow.",
  "id" : 662504984315998209,
  "created_at" : "2015-11-06 05:41:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 0, 8 ],
      "id_str" : "5690792",
      "id" : 5690792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662456234327470080",
  "in_reply_to_user_id" : 5690792,
  "text" : "@draggin I spy with my little eye...",
  "id" : 662456234327470080,
  "created_at" : "2015-11-06 02:27:28 +0000",
  "in_reply_to_screen_name" : "draggin",
  "in_reply_to_user_id_str" : "5690792",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/argEtdQ3Fo",
      "expanded_url" : "https:\/\/twitter.com\/userfocus\/status\/662337144141279232",
      "display_url" : "twitter.com\/userfocus\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "662380812541624321",
  "text" : "If you teach an introductory UX\/UI design course I think the linked syllabus is especially well worth a look. https:\/\/t.co\/argEtdQ3Fo",
  "id" : 662380812541624321,
  "created_at" : "2015-11-05 21:27:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662366130720256000",
  "text" : "RT @jasonfried: \"Beautiful\" is a word software co's use to describe their apps. Beautiful isn't a word customers use to describe what they'\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662305690048950272",
    "text" : "\"Beautiful\" is a word software co's use to describe their apps. Beautiful isn't a word customers use to describe what they're trying to do.",
    "id" : 662305690048950272,
    "created_at" : "2015-11-05 16:29:16 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 662366130720256000,
  "created_at" : "2015-11-05 20:29:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 25, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "662362669458952192",
  "text" : "Virtual office hours for #SFU CMPT 363 start in 45 minutes at https:\/\/t.co\/I7fZ1cnbn3.",
  "id" : 662362669458952192,
  "created_at" : "2015-11-05 20:15:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/ChDmQGzGRJ",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/my-dream-workflow-as-an-instructor",
      "display_url" : "hibbittsdesign.org\/blog\/my-dream-\u2026"
    }, {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/mf8waj2O7E",
      "expanded_url" : "https:\/\/github.com\/showcases\/",
      "display_url" : "github.com\/showcases\/"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/XmWYikhsiJ",
      "expanded_url" : "https:\/\/education.github.com\/",
      "display_url" : "education.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "662033725421654017",
  "text" : "Learn about my GitHub workflow at https:\/\/t.co\/ChDmQGzGRJ, uses of GitHub https:\/\/t.co\/mf8waj2O7E, and GitHub Edu https:\/\/t.co\/XmWYikhsiJ",
  "id" : 662033725421654017,
  "created_at" : "2015-11-04 22:28:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662032069359443969",
  "text" : "GitHub is not only for devs., esp. with progress of GitHub Desktop the power of version control + collab is open to Web-savvy instructors.",
  "id" : 662032069359443969,
  "created_at" : "2015-11-04 22:21:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662030545250029568",
  "text" : "Hosting a flat-file (no DB) CMS course site on GitHub not only puts everything  in the open, but also streamlines workflow + enables collab.",
  "id" : 662030545250029568,
  "created_at" : "2015-11-04 22:15:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662027952641736704",
  "text" : "I think many educators default to WordPress because, well it's WP. Flat-file CMS's enable GitHub collab and don't lock-in content into a DB.",
  "id" : 662027952641736704,
  "created_at" : "2015-11-04 22:05:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Responsive Design",
      "screen_name" : "RWD",
      "indices" : [ 3, 7 ],
      "id_str" : "348664405",
      "id" : 348664405
    }, {
      "name" : "Charlotte Jackson",
      "screen_name" : "Lottejackson",
      "indices" : [ 39, 52 ],
      "id_str" : "50288691",
      "id" : 50288691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/zm97t8UpyP",
      "expanded_url" : "http:\/\/alistapart.com\/article\/from-pages-to-patterns-an-exercise-for-everyone",
      "display_url" : "alistapart.com\/article\/from-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661636851267055616",
  "text" : "RT @RWD: A simply stellar article from @Lottejackson on translating web \u201Cpages\u201D into reusable *patterns*: https:\/\/t.co\/zm97t8UpyP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charlotte Jackson",
        "screen_name" : "Lottejackson",
        "indices" : [ 30, 43 ],
        "id_str" : "50288691",
        "id" : 50288691
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/zm97t8UpyP",
        "expanded_url" : "http:\/\/alistapart.com\/article\/from-pages-to-patterns-an-exercise-for-everyone",
        "display_url" : "alistapart.com\/article\/from-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661635537225297920",
    "text" : "A simply stellar article from @Lottejackson on translating web \u201Cpages\u201D into reusable *patterns*: https:\/\/t.co\/zm97t8UpyP",
    "id" : 661635537225297920,
    "created_at" : "2015-11-03 20:06:19 +0000",
    "user" : {
      "name" : "Responsive Design",
      "screen_name" : "RWD",
      "protected" : false,
      "id_str" : "348664405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539462074808561664\/PgmryUKs_normal.png",
      "id" : 348664405,
      "verified" : false
    }
  },
  "id" : 661636851267055616,
  "created_at" : "2015-11-03 20:11:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A List Apart",
      "screen_name" : "alistapart",
      "indices" : [ 52, 63 ],
      "id_str" : "18776131",
      "id" : 18776131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/MB0wX0jhZo",
      "expanded_url" : "http:\/\/alistapart.com\/article\/how-we-hold-our-gadgets",
      "display_url" : "alistapart.com\/article\/how-we\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661626748627357696",
  "text" : "How We Hold Our Gadgets https:\/\/t.co\/MB0wX0jhZo via @alistapart",
  "id" : 661626748627357696,
  "created_at" : "2015-11-03 19:31:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "661610866354331648",
  "geo" : { },
  "id_str" : "661613283246387201",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro LOL \uD83D\uDE00 It's interesting that a type of device is first thought of when really it is more often whatever device is close at hand.",
  "id" : 661613283246387201,
  "in_reply_to_status_id" : 661610866354331648,
  "created_at" : "2015-11-03 18:37:53 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661610444293931008",
  "text" : "Shared my view on the term 'Mobile' with CMPT 363 students yesterday as not being based on screen size or device but 'being close at hand'.",
  "id" : 661610444293931008,
  "created_at" : "2015-11-03 18:26:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "661597882907168768",
  "text" : "#SFU CMPT 363 week 8 materials, and Nov 9th class preparations, are now available on the course companion site at https:\/\/t.co\/I7fZ1cnbn3",
  "id" : 661597882907168768,
  "created_at" : "2015-11-03 17:36:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/wB7FjYoM63",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/alternative-to-the-term-learner-experience-design",
      "display_url" : "hibbittsdesign.org\/blog\/alternati\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661343824782884864",
  "text" : "Alternative to the term Learner Experience Design? https:\/\/t.co\/wB7FjYoM63",
  "id" : 661343824782884864,
  "created_at" : "2015-11-03 00:47:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 0, 8 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/rM7m3Iq7dx",
      "expanded_url" : "https:\/\/github.com\/trending?l=php",
      "display_url" : "github.com\/trending?l=php"
    } ]
  },
  "in_reply_to_status_id_str" : "661311891357077504",
  "geo" : { },
  "id_str" : "661314658804981761",
  "in_reply_to_user_id" : 2737573033,
  "text" : "@getgrav Did you notice this today also? https:\/\/t.co\/rM7m3Iq7dx Awesome to see and so very deserved!",
  "id" : 661314658804981761,
  "in_reply_to_status_id" : 661311891357077504,
  "created_at" : "2015-11-02 22:51:15 +0000",
  "in_reply_to_screen_name" : "getgrav",
  "in_reply_to_user_id_str" : "2737573033",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 0, 8 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "661295454143954948",
  "geo" : { },
  "id_str" : "661299554403246080",
  "in_reply_to_user_id" : 2737573033,
  "text" : "@getgrav Thanks Andy! Lots of big plans for Grav as you know \uD83D\uDE0A",
  "id" : 661299554403246080,
  "in_reply_to_status_id" : 661295454143954948,
  "created_at" : "2015-11-02 21:51:14 +0000",
  "in_reply_to_screen_name" : "getgrav",
  "in_reply_to_user_id_str" : "2737573033",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 3, 7 ],
      "id_str" : "1063291",
      "id" : 1063291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/Wk5oKlObMM",
      "expanded_url" : "http:\/\/ow.ly\/U97Y1",
      "display_url" : "ow.ly\/U97Y1"
    } ]
  },
  "geo" : { },
  "id_str" : "661292538620350464",
  "text" : "RT @UIE: Responsive design mistakes you don\u2019t want to make https:\/\/t.co\/Wk5oKlObMM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/Wk5oKlObMM",
        "expanded_url" : "http:\/\/ow.ly\/U97Y1",
        "display_url" : "ow.ly\/U97Y1"
      } ]
    },
    "geo" : { },
    "id_str" : "661290553154379778",
    "text" : "Responsive design mistakes you don\u2019t want to make https:\/\/t.co\/Wk5oKlObMM",
    "id" : 661290553154379778,
    "created_at" : "2015-11-02 21:15:28 +0000",
    "user" : {
      "name" : "UIE",
      "screen_name" : "UIE",
      "protected" : false,
      "id_str" : "1063291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3759116326\/19308cfcdb0b831111d4ee3fc3e6232c_normal.jpeg",
      "id" : 1063291,
      "verified" : false
    }
  },
  "id" : 661292538620350464,
  "created_at" : "2015-11-02 21:23:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Bovis",
      "screen_name" : "PaulBovis",
      "indices" : [ 3, 13 ],
      "id_str" : "1004346642",
      "id" : 1004346642
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 36, 44 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "\uD83D\uDC31 Product Hunt",
      "screen_name" : "ProductHunt",
      "indices" : [ 88, 100 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/0EzacGiHB1",
      "expanded_url" : "https:\/\/www.producthunt.com\/e\/most-loved-products-in-october",
      "display_url" : "producthunt.com\/e\/most-loved-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661288219309305856",
  "text" : "RT @PaulBovis: No surprises here as @getgrav is on the - Most Loved Products in October @ProductHunt https:\/\/t.co\/0EzacGiHB1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 21, 29 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      }, {
        "name" : "\uD83D\uDC31 Product Hunt",
        "screen_name" : "ProductHunt",
        "indices" : [ 73, 85 ],
        "id_str" : "2208027565",
        "id" : 2208027565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/0EzacGiHB1",
        "expanded_url" : "https:\/\/www.producthunt.com\/e\/most-loved-products-in-october",
        "display_url" : "producthunt.com\/e\/most-loved-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661211078911766528",
    "text" : "No surprises here as @getgrav is on the - Most Loved Products in October @ProductHunt https:\/\/t.co\/0EzacGiHB1",
    "id" : 661211078911766528,
    "created_at" : "2015-11-02 15:59:40 +0000",
    "user" : {
      "name" : "Paul Bovis",
      "screen_name" : "PaulBovis",
      "protected" : false,
      "id_str" : "1004346642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2979990175\/b7845035adfa0bf87f7521f05c550356_normal.jpeg",
      "id" : 1004346642,
      "verified" : false
    }
  },
  "id" : 661288219309305856,
  "created_at" : "2015-11-02 21:06:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 69, 77 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/mDJ9E4VNAs",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/",
      "display_url" : "hibbittsdesign.org"
    } ]
  },
  "geo" : { },
  "id_str" : "661269123528196096",
  "text" : "Bit by (binary) bit my new little blog is taking shape...  exploring @getgrav, GitHub collab, and flipping the LMS https:\/\/t.co\/mDJ9E4VNAs",
  "id" : 661269123528196096,
  "created_at" : "2015-11-02 19:50:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "technkl (retired)",
      "screen_name" : "technkl",
      "indices" : [ 0, 8 ],
      "id_str" : "4203476904",
      "id" : 4203476904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/wB7FjYoM63",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/alternative-to-the-term-learner-experience-design",
      "display_url" : "hibbittsdesign.org\/blog\/alternati\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "660346593661456384",
  "geo" : { },
  "id_str" : "661228031134961665",
  "in_reply_to_user_id" : 17132766,
  "text" : "@technkl Nice to connect! I wrote some similar thoughts https:\/\/t.co\/wB7FjYoM63 Comments are more than welcome.",
  "id" : 661228031134961665,
  "in_reply_to_status_id" : 660346593661456384,
  "created_at" : "2015-11-02 17:07:02 +0000",
  "in_reply_to_screen_name" : "nick_leffler",
  "in_reply_to_user_id_str" : "17132766",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "indices" : [ 3, 16 ],
      "id_str" : "35943",
      "id" : 35943
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/karenmcgrane\/status\/661206163132964864\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/RmkZ6sHPY9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS0TgIgXIAQTARz.png",
      "id_str" : "661206163053289476",
      "id" : 661206163053289476,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS0TgIgXIAQTARz.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 674
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 674
      } ],
      "display_url" : "pic.twitter.com\/RmkZ6sHPY9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/cyE7IzW2zf",
      "expanded_url" : "http:\/\/bit.ly\/1RoYqRp",
      "display_url" : "bit.ly\/1RoYqRp"
    } ]
  },
  "geo" : { },
  "id_str" : "661208163157348352",
  "text" : "RT @karenmcgrane: I'll say it again: every responsive design project is also a content strategy project: https:\/\/t.co\/cyE7IzW2zf https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/karenmcgrane\/status\/661206163132964864\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/RmkZ6sHPY9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS0TgIgXIAQTARz.png",
        "id_str" : "661206163053289476",
        "id" : 661206163053289476,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS0TgIgXIAQTARz.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 344,
          "resize" : "fit",
          "w" : 674
        }, {
          "h" : 174,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 344,
          "resize" : "fit",
          "w" : 674
        } ],
        "display_url" : "pic.twitter.com\/RmkZ6sHPY9"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/cyE7IzW2zf",
        "expanded_url" : "http:\/\/bit.ly\/1RoYqRp",
        "display_url" : "bit.ly\/1RoYqRp"
      } ]
    },
    "geo" : { },
    "id_str" : "661206163132964864",
    "text" : "I'll say it again: every responsive design project is also a content strategy project: https:\/\/t.co\/cyE7IzW2zf https:\/\/t.co\/RmkZ6sHPY9",
    "id" : 661206163132964864,
    "created_at" : "2015-11-02 15:40:08 +0000",
    "user" : {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "protected" : false,
      "id_str" : "35943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720948130867449857\/DR8tPuqM_normal.jpg",
      "id" : 35943,
      "verified" : false
    }
  },
  "id" : 661208163157348352,
  "created_at" : "2015-11-02 15:48:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/uDC5Ge5jtA",
      "expanded_url" : "https:\/\/medium.com\/google-design\/designing-a-ux-for-learning-ebed4fa0a798#.l8rydlrrw",
      "display_url" : "medium.com\/google-design\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660997200776851456",
  "text" : "https:\/\/t.co\/uDC5Ge5jtA",
  "id" : 660997200776851456,
  "created_at" : "2015-11-02 01:49:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Bovis",
      "screen_name" : "PaulBovis",
      "indices" : [ 3, 13 ],
      "id_str" : "1004346642",
      "id" : 1004346642
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 31, 39 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/8dzroM88YM",
      "expanded_url" : "http:\/\/www.webdesignerdepot.com\/2015\/11\/popular-design-news-of-the-week-october-26-2015-november-1-2015\/",
      "display_url" : "webdesignerdepot.com\/2015\/11\/popula\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660984047473049600",
  "text" : "RT @PaulBovis: Congratulations @getgrav RT: Popular design news of the week: October 26, 2015 \u2013 November 1, 2015 https:\/\/t.co\/8dzroM88YM vi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 16, 24 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/8dzroM88YM",
        "expanded_url" : "http:\/\/www.webdesignerdepot.com\/2015\/11\/popular-design-news-of-the-week-october-26-2015-november-1-2015\/",
        "display_url" : "webdesignerdepot.com\/2015\/11\/popula\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "660747407093665793",
    "text" : "Congratulations @getgrav RT: Popular design news of the week: October 26, 2015 \u2013 November 1, 2015 https:\/\/t.co\/8dzroM88YM via designerdepot",
    "id" : 660747407093665793,
    "created_at" : "2015-11-01 09:17:12 +0000",
    "user" : {
      "name" : "Paul Bovis",
      "screen_name" : "PaulBovis",
      "protected" : false,
      "id_str" : "1004346642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2979990175\/b7845035adfa0bf87f7521f05c550356_normal.jpeg",
      "id" : 1004346642,
      "verified" : false
    }
  },
  "id" : 660984047473049600,
  "created_at" : "2015-11-02 00:57:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660971073916145666",
  "text" : "\"Experience Design for Open Learning Environments\" feels like a good start to describe my goal to combine UX, open [source] and education.",
  "id" : 660971073916145666,
  "created_at" : "2015-11-02 00:05:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]