Grailbird.data.tweets_2016_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "indices" : [ 3, 11 ],
      "id_str" : "783092",
      "id" : 783092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opensource",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/z11qDGlgDA",
      "expanded_url" : "https:\/\/words.werd.io\/what-is-open-source-cfbe3ccd22ea#.mrsaan578",
      "display_url" : "words.werd.io\/what-is-open-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759890391545982976",
  "text" : "RT @benwerd: What is #opensource? Is it a viable alternative? What are the issues? An explainer: https:\/\/t.co\/z11qDGlgDA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/werd.io\/\" rel=\"nofollow\"\u003Ewerd.io\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opensource",
        "indices" : [ 8, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/z11qDGlgDA",
        "expanded_url" : "https:\/\/words.werd.io\/what-is-open-source-cfbe3ccd22ea#.mrsaan578",
        "display_url" : "words.werd.io\/what-is-open-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759491572148817920",
    "text" : "What is #opensource? Is it a viable alternative? What are the issues? An explainer: https:\/\/t.co\/z11qDGlgDA",
    "id" : 759491572148817920,
    "created_at" : "2016-07-30 20:51:16 +0000",
    "user" : {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "protected" : false,
      "id_str" : "783092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681986174966104064\/t3BubQKk_normal.jpg",
      "id" : 783092,
      "verified" : true
    }
  },
  "id" : 759890391545982976,
  "created_at" : "2016-07-31 23:16:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "indices" : [ 3, 15 ],
      "id_str" : "730373",
      "id" : 730373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759881504503705600",
  "text" : "RT @scottjenson: I appreciate that closed systems move faster and can \"look prettier\" but ones which create value, improve, grow, and last\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "759776545783226368",
    "text" : "I appreciate that closed systems move faster and can \"look prettier\" but ones which create value, improve, grow, and last must be open",
    "id" : 759776545783226368,
    "created_at" : "2016-07-31 15:43:39 +0000",
    "user" : {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "protected" : false,
      "id_str" : "730373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576892785149628416\/FiovXOSs_normal.jpeg",
      "id" : 730373,
      "verified" : true
    }
  },
  "id" : 759881504503705600,
  "created_at" : "2016-07-31 22:40:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Shapiro",
      "screen_name" : "philshapiro",
      "indices" : [ 3, 15 ],
      "id_str" : "40720843",
      "id" : 40720843
    }, {
      "name" : "Open Source Way",
      "screen_name" : "opensourceway",
      "indices" : [ 102, 116 ],
      "id_str" : "80589255",
      "id" : 80589255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/WmE3Lvm6GG",
      "expanded_url" : "https:\/\/opensource.com\/education\/16\/7\/open-solution-improving-21st-century-education",
      "display_url" : "opensource.com\/education\/16\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759839345150824448",
  "text" : "RT @philshapiro: Open is the solution to improving 21st century education https:\/\/t.co\/WmE3Lvm6GG via @opensourceway",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Open Source Way",
        "screen_name" : "opensourceway",
        "indices" : [ 85, 99 ],
        "id_str" : "80589255",
        "id" : 80589255
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/WmE3Lvm6GG",
        "expanded_url" : "https:\/\/opensource.com\/education\/16\/7\/open-solution-improving-21st-century-education",
        "display_url" : "opensource.com\/education\/16\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759787245989756928",
    "text" : "Open is the solution to improving 21st century education https:\/\/t.co\/WmE3Lvm6GG via @opensourceway",
    "id" : 759787245989756928,
    "created_at" : "2016-07-31 16:26:10 +0000",
    "user" : {
      "name" : "Phil Shapiro",
      "screen_name" : "philshapiro",
      "protected" : false,
      "id_str" : "40720843",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718722605570768896\/LjKZjF17_normal.jpg",
      "id" : 40720843,
      "verified" : false
    }
  },
  "id" : 759839345150824448,
  "created_at" : "2016-07-31 19:53:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "indices" : [ 0, 12 ],
      "id_str" : "730373",
      "id" : 730373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759534435742035968",
  "geo" : { },
  "id_str" : "759535001016737792",
  "in_reply_to_user_id" : 730373,
  "text" : "@scottjenson Would sandstorm.io qualify with what you are thinking of?",
  "id" : 759535001016737792,
  "in_reply_to_status_id" : 759534435742035968,
  "created_at" : "2016-07-30 23:43:50 +0000",
  "in_reply_to_screen_name" : "scottjenson",
  "in_reply_to_user_id_str" : "730373",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Source Way",
      "screen_name" : "opensourceway",
      "indices" : [ 77, 91 ],
      "id_str" : "80589255",
      "id" : 80589255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/m5BBkUVKtK",
      "expanded_url" : "https:\/\/opensource.com\/community\/16\/6\/mattermost-shows-oss-has-be-better",
      "display_url" : "opensource.com\/community\/16\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759455502786977793",
  "text" : "Open source software has to sell user experience https:\/\/t.co\/m5BBkUVKtK via @opensourceway",
  "id" : 759455502786977793,
  "created_at" : "2016-07-30 18:27:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/QFNLDeMCfb",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-07-29-introducing-grav-course-hub-for-mac",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "759112846386921472",
  "geo" : { },
  "id_str" : "759116269698158592",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke Here is a preview of the blog post: https:\/\/t.co\/QFNLDeMCfb",
  "id" : 759116269698158592,
  "in_reply_to_status_id" : 759112846386921472,
  "created_at" : "2016-07-29 19:59:57 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 13, 21 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759112846386921472",
  "geo" : { },
  "id_str" : "759113507128287232",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @getgrav Thanks, please let me know how it goes\uD83D\uDE42. Writing an accompanying blog post too...",
  "id" : 759113507128287232,
  "in_reply_to_status_id" : 759112846386921472,
  "created_at" : "2016-07-29 19:48:58 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 13, 21 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759109450217029633",
  "geo" : { },
  "id_str" : "759112150728126465",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @getgrav Hi Billy, for a local Mac install it should be 4 with the new Course Hub install package - did your 'mileage' vary?",
  "id" : 759112150728126465,
  "in_reply_to_status_id" : 759109450217029633,
  "created_at" : "2016-07-29 19:43:35 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/Gno6MDcicE",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/downloads\/GravCourseHubforMac.zip",
      "display_url" : "hibbittsdesign.org\/blog\/downloads\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759080181768200193",
  "text" : "Use a Mac and curious about the Grav Course Hub? The Grav Course Hub for Mac installer is now available: https:\/\/t.co\/Gno6MDcicE #GravEdu",
  "id" : 759080181768200193,
  "created_at" : "2016-07-29 17:36:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 35, 43 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/759071157131718656\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/qMwFd3jYeL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CojDJ6qUIAAYj8g.jpg",
      "id_str" : "759071112344903680",
      "id" : 759071112344903680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CojDJ6qUIAAYj8g.jpg",
      "sizes" : [ {
        "h" : 503,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/qMwFd3jYeL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759071157131718656",
  "text" : "Cooking up a faster way to get the @getgrav Course Hub up and running on a Mac... https:\/\/t.co\/qMwFd3jYeL",
  "id" : 759071157131718656,
  "created_at" : "2016-07-29 17:00:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/yJwV2clFWb",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-163\/",
      "display_url" : "paulhibbitts.net\/cmpt-363-163\/"
    } ]
  },
  "geo" : { },
  "id_str" : "758769708053045248",
  "text" : "Interested in seeing a real-life example of flipping an LMS (i.e. #CanvasLMS) with an open + collaborative platform? https:\/\/t.co\/yJwV2clFWb",
  "id" : 758769708053045248,
  "created_at" : "2016-07-28 21:02:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/758768703357849600\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/zEpf8dvBc4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoevRPaUEAEa86L.jpg",
      "id_str" : "758767772964753409",
      "id" : 758767772964753409,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoevRPaUEAEa86L.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1213
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 711
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2102,
        "resize" : "fit",
        "w" : 1245
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/zEpf8dvBc4"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/758768703357849600\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/zEpf8dvBc4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoevYS9UEAAxKsL.jpg",
      "id_str" : "758767894175944704",
      "id" : 758767894175944704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoevYS9UEAAxKsL.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 327
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 984
      }, {
        "h" : 2591,
        "resize" : "fit",
        "w" : 1245
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/zEpf8dvBc4"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/758768703357849600\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/zEpf8dvBc4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoevZQzVUAAyZMP.jpg",
      "id_str" : "758767910777081856",
      "id" : 758767910777081856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoevZQzVUAAyZMP.jpg",
      "sizes" : [ {
        "h" : 1716,
        "resize" : "fit",
        "w" : 1245
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 871
      }, {
        "h" : 1716,
        "resize" : "fit",
        "w" : 1245
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 493
      } ],
      "display_url" : "pic.twitter.com\/zEpf8dvBc4"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/758768703357849600\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/zEpf8dvBc4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoevaAjUsAA77yv.jpg",
      "id_str" : "758767923594833920",
      "id" : 758767923594833920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoevaAjUsAA77yv.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 1757,
        "resize" : "fit",
        "w" : 1245
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 482
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1757,
        "resize" : "fit",
        "w" : 1245
      } ],
      "display_url" : "pic.twitter.com\/zEpf8dvBc4"
    } ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 71, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758768703357849600",
  "text" : "Further aligning the CMPT 363 course schedule with performance support #UX Guide (+ shared content on weekly pages). https:\/\/t.co\/zEpf8dvBc4",
  "id" : 758768703357849600,
  "created_at" : "2016-07-28 20:58:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Data & Society",
      "screen_name" : "datasociety",
      "indices" : [ 82, 94 ],
      "id_str" : "1894231788",
      "id" : 1894231788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/N81YsWlW1q",
      "expanded_url" : "http:\/\/www.datasociety.net\/pubs\/ecl\/PersonalizedLearning_primer_2016.pdf",
      "display_url" : "datasociety.net\/pubs\/ecl\/Perso\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758758338846871552",
  "text" : "RT @audreywatters: \u201CPersonalized Learning: The Conversations We\u2019re Not Having\u201D by @datasociety https:\/\/t.co\/N81YsWlW1q \uD83D\uDCAF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Data & Society",
        "screen_name" : "datasociety",
        "indices" : [ 63, 75 ],
        "id_str" : "1894231788",
        "id" : 1894231788
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/N81YsWlW1q",
        "expanded_url" : "http:\/\/www.datasociety.net\/pubs\/ecl\/PersonalizedLearning_primer_2016.pdf",
        "display_url" : "datasociety.net\/pubs\/ecl\/Perso\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758748216976289792",
    "text" : "\u201CPersonalized Learning: The Conversations We\u2019re Not Having\u201D by @datasociety https:\/\/t.co\/N81YsWlW1q \uD83D\uDCAF",
    "id" : 758748216976289792,
    "created_at" : "2016-07-28 19:37:26 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 758758338846871552,
  "created_at" : "2016-07-28 20:17:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 57, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/JHTWeNGqvt",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-07-14-the-beauty-of-combining-canvas-lms-with-grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/kpKep8Asin",
      "expanded_url" : "https:\/\/twitter.com\/LisaMLane\/status\/758678133335666688",
      "display_url" : "twitter.com\/LisaMLane\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758723403134013440",
  "text" : "I've encountered these issues too, and ended up flipping #CanvasLMS with an open platform: https:\/\/t.co\/JHTWeNGqvt https:\/\/t.co\/kpKep8Asin",
  "id" : 758723403134013440,
  "created_at" : "2016-07-28 17:58:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758718113395331074",
  "geo" : { },
  "id_str" : "758718371156275203",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro LOL \uD83D\uDE09",
  "id" : 758718371156275203,
  "in_reply_to_status_id" : 758718113395331074,
  "created_at" : "2016-07-28 17:38:50 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 10, 25 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 76, 84 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/GSBtZoNMJ6",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=R1D17iHs8pk",
      "display_url" : "youtube.com\/watch?v=R1D17i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758717854216704003",
  "text" : "Thanks to @reclaimhosting my fellow instructors can install and try out the @getgrav Course Hub in under 60 seconds\uD83D\uDC4D https:\/\/t.co\/GSBtZoNMJ6",
  "id" : 758717854216704003,
  "created_at" : "2016-07-28 17:36:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UXPA International",
      "screen_name" : "UXPA_Int",
      "indices" : [ 3, 12 ],
      "id_str" : "47451021",
      "id" : 47451021
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/UXPA_Int\/status\/758419713793851392\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/YsMVdZoVt4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZytSDWAAEHHBF.png",
      "id_str" : "758419709524049921",
      "id" : 758419709524049921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZytSDWAAEHHBF.png",
      "sizes" : [ {
        "h" : 232,
        "resize" : "fit",
        "w" : 284
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 284
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 284
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 284
      } ],
      "display_url" : "pic.twitter.com\/YsMVdZoVt4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/O8kEKOI01h",
      "expanded_url" : "http:\/\/uxpamagazine.org\/tag\/methods\/",
      "display_url" : "uxpamagazine.org\/tag\/methods\/"
    } ]
  },
  "geo" : { },
  "id_str" : "758420456579796993",
  "text" : "RT @UXPA_Int: Try something new: https:\/\/t.co\/O8kEKOI01h https:\/\/t.co\/YsMVdZoVt4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/UXPA_Int\/status\/758419713793851392\/photo\/1",
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/YsMVdZoVt4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZytSDWAAEHHBF.png",
        "id_str" : "758419709524049921",
        "id" : 758419709524049921,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZytSDWAAEHHBF.png",
        "sizes" : [ {
          "h" : 232,
          "resize" : "fit",
          "w" : 284
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 284
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 284
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 284
        } ],
        "display_url" : "pic.twitter.com\/YsMVdZoVt4"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/O8kEKOI01h",
        "expanded_url" : "http:\/\/uxpamagazine.org\/tag\/methods\/",
        "display_url" : "uxpamagazine.org\/tag\/methods\/"
      } ]
    },
    "geo" : { },
    "id_str" : "758419713793851392",
    "text" : "Try something new: https:\/\/t.co\/O8kEKOI01h https:\/\/t.co\/YsMVdZoVt4",
    "id" : 758419713793851392,
    "created_at" : "2016-07-27 21:52:05 +0000",
    "user" : {
      "name" : "UXPA International",
      "screen_name" : "UXPA_Int",
      "protected" : false,
      "id_str" : "47451021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2281300583\/5ka9izwtlid5e423qik1_normal.png",
      "id" : 47451021,
      "verified" : false
    }
  },
  "id" : 758420456579796993,
  "created_at" : "2016-07-27 21:55:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/758392969409933312\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ubHpoiquII",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZZsE_VYAAUba3.jpg",
      "id_str" : "758392201047007232",
      "id" : 758392201047007232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZZsE_VYAAUba3.jpg",
      "sizes" : [ {
        "h" : 1408,
        "resize" : "fit",
        "w" : 796
      }, {
        "h" : 1408,
        "resize" : "fit",
        "w" : 796
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 678
      } ],
      "display_url" : "pic.twitter.com\/ubHpoiquII"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 12, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758392969409933312",
  "text" : "In-progress #SFU CMPT 363 course schedule to align expected student learning needs with open source UX project work. https:\/\/t.co\/ubHpoiquII",
  "id" : 758392969409933312,
  "created_at" : "2016-07-27 20:05:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Marcotte",
      "screen_name" : "jungshadow",
      "indices" : [ 3, 14 ],
      "id_str" : "16316738",
      "id" : 16316738
    }, {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "indices" : [ 81, 86 ],
      "id_str" : "12534",
      "id" : 12534
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aeadc",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758385400318562304",
  "text" : "RT @jungshadow: \u201C\u2018Desktop\u2019 doesn\u2019t mean \u2018more.\u2019 \u2018Mobile\u2019 doesn\u2019t mean \u2018less.\u2019\u201D \u2013 @beep #aeadc \n\nAmen.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ethan Marcotte",
        "screen_name" : "beep",
        "indices" : [ 65, 70 ],
        "id_str" : "12534",
        "id" : 12534
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aeadc",
        "indices" : [ 71, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758363339147927552",
    "text" : "\u201C\u2018Desktop\u2019 doesn\u2019t mean \u2018more.\u2019 \u2018Mobile\u2019 doesn\u2019t mean \u2018less.\u2019\u201D \u2013 @beep #aeadc \n\nAmen.",
    "id" : 758363339147927552,
    "created_at" : "2016-07-27 18:08:04 +0000",
    "user" : {
      "name" : "Jared Marcotte",
      "screen_name" : "jungshadow",
      "protected" : false,
      "id_str" : "16316738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713417532238086146\/OgYCtYMp_normal.jpg",
      "id" : 16316738,
      "verified" : false
    }
  },
  "id" : 758385400318562304,
  "created_at" : "2016-07-27 19:35:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/FmAOyZYsrY",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/5_Whys",
      "display_url" : "en.wikipedia.org\/wiki\/5_Whys"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/wTbkaGeoFy",
      "expanded_url" : "https:\/\/twitter.com\/intercom\/status\/758377930791739392",
      "display_url" : "twitter.com\/intercom\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758380023761874945",
  "text" : "Nicely put! I always highlight the '5 Whys' to students taking my introductory UX course. https:\/\/t.co\/FmAOyZYsrY https:\/\/t.co\/wTbkaGeoFy",
  "id" : 758380023761874945,
  "created_at" : "2016-07-27 19:14:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Havemann",
      "screen_name" : "leohavemann",
      "indices" : [ 3, 15 ],
      "id_str" : "14788950",
      "id" : 14788950
    }, {
      "name" : "Martin Weller",
      "screen_name" : "mweller",
      "indices" : [ 84, 92 ],
      "id_str" : "7127162",
      "id" : 7127162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oer",
      "indices" : [ 117, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/PvQn0vU1d1",
      "expanded_url" : "http:\/\/sco.lt\/8SYcq1",
      "display_url" : "sco.lt\/8SYcq1"
    } ]
  },
  "geo" : { },
  "id_str" : "758357669455417344",
  "text" : "RT @leohavemann: The Open Flip \u2013 a digital economic model for education | JL4D | by @mweller https:\/\/t.co\/PvQn0vU1d1 #oer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.scoop.it\" rel=\"nofollow\"\u003EScoop.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Martin Weller",
        "screen_name" : "mweller",
        "indices" : [ 67, 75 ],
        "id_str" : "7127162",
        "id" : 7127162
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oer",
        "indices" : [ 100, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/PvQn0vU1d1",
        "expanded_url" : "http:\/\/sco.lt\/8SYcq1",
        "display_url" : "sco.lt\/8SYcq1"
      } ]
    },
    "geo" : { },
    "id_str" : "757138668549201920",
    "text" : "The Open Flip \u2013 a digital economic model for education | JL4D | by @mweller https:\/\/t.co\/PvQn0vU1d1 #oer",
    "id" : 757138668549201920,
    "created_at" : "2016-07-24 09:01:40 +0000",
    "user" : {
      "name" : "Leo Havemann",
      "screen_name" : "leohavemann",
      "protected" : false,
      "id_str" : "14788950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743386940750331904\/lQ07OK4W_normal.jpg",
      "id" : 14788950,
      "verified" : false
    }
  },
  "id" : 758357669455417344,
  "created_at" : "2016-07-27 17:45:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 3, 18 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 40, 48 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 116, 131 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/vNWGJHSDft",
      "expanded_url" : "http:\/\/gravcoursehub.org\/",
      "display_url" : "gravcoursehub.org"
    } ]
  },
  "geo" : { },
  "id_str" : "758352171372904448",
  "text" : "RT @ReclaimHosting: Pleased to announce @getgrav 1.1.1 rolling out to servers today with new Course Hub skeleton by @hibbittsdesign https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 20, 28 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      }, {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 96, 111 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/vNWGJHSDft",
        "expanded_url" : "http:\/\/gravcoursehub.org\/",
        "display_url" : "gravcoursehub.org"
      } ]
    },
    "geo" : { },
    "id_str" : "758350633602846720",
    "text" : "Pleased to announce @getgrav 1.1.1 rolling out to servers today with new Course Hub skeleton by @hibbittsdesign https:\/\/t.co\/vNWGJHSDft",
    "id" : 758350633602846720,
    "created_at" : "2016-07-27 17:17:35 +0000",
    "user" : {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "protected" : false,
      "id_str" : "1602053274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710868507144167424\/Aj9k9RM2_normal.jpg",
      "id" : 1602053274,
      "verified" : false
    }
  },
  "id" : 758352171372904448,
  "created_at" : "2016-07-27 17:23:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 0, 15 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 16, 24 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758350633602846720",
  "geo" : { },
  "id_str" : "758352149726191618",
  "in_reply_to_user_id" : 1602053274,
  "text" : "@ReclaimHosting @getgrav AMAZING NEWS! Thanks so much for this update, and will help spread the word \uD83D\uDE42",
  "id" : 758352149726191618,
  "in_reply_to_status_id" : 758350633602846720,
  "created_at" : "2016-07-27 17:23:36 +0000",
  "in_reply_to_screen_name" : "ReclaimHosting",
  "in_reply_to_user_id_str" : "1602053274",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 27, 31 ]
    }, {
      "text" : "UX",
      "indices" : [ 106, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/QCOrLOLKxf",
      "expanded_url" : "https:\/\/workflowy.com\/s\/0UvwffTinC",
      "display_url" : "workflowy.com\/s\/0UvwffTinC"
    } ]
  },
  "geo" : { },
  "id_str" : "758343856911900672",
  "text" : "First pass at re-organized #SFU CMPT 363 course structure to support student participation on open source #UX projs: https:\/\/t.co\/QCOrLOLKxf",
  "id" : 758343856911900672,
  "created_at" : "2016-07-27 16:50:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758338219834355712",
  "text" : "Course redesign should always bring some anxiety along for the ride, or so I would like to believe.",
  "id" : 758338219834355712,
  "created_at" : "2016-07-27 16:28:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akendi",
      "screen_name" : "akendi",
      "indices" : [ 3, 10 ],
      "id_str" : "28865522",
      "id" : 28865522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/2dFR1KdBDb",
      "expanded_url" : "http:\/\/buff.ly\/2a6rUp8",
      "display_url" : "buff.ly\/2a6rUp8"
    } ]
  },
  "geo" : { },
  "id_str" : "758039870593830912",
  "text" : "RT @akendi: Solving the Right Problem: The Importance of Task Analysis https:\/\/t.co\/2dFR1KdBDb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/2dFR1KdBDb",
        "expanded_url" : "http:\/\/buff.ly\/2a6rUp8",
        "display_url" : "buff.ly\/2a6rUp8"
      } ]
    },
    "geo" : { },
    "id_str" : "758036928050651136",
    "text" : "Solving the Right Problem: The Importance of Task Analysis https:\/\/t.co\/2dFR1KdBDb",
    "id" : 758036928050651136,
    "created_at" : "2016-07-26 20:31:01 +0000",
    "user" : {
      "name" : "Akendi",
      "screen_name" : "akendi",
      "protected" : false,
      "id_str" : "28865522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569950332256391168\/sqjj3WP7_normal.png",
      "id" : 28865522,
      "verified" : false
    }
  },
  "id" : 758039870593830912,
  "created_at" : "2016-07-26 20:42:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/tGqAe5ly8o",
      "expanded_url" : "https:\/\/twitter.com\/melissabreker\/status\/758018829939273729",
      "display_url" : "twitter.com\/melissabreker\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758024597908271104",
  "text" : "Agree! Yet another reason why I prefer empathy maps. If personas are required then empathy map -&gt; persona creation. https:\/\/t.co\/tGqAe5ly8o",
  "id" : 758024597908271104,
  "created_at" : "2016-07-26 19:42:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fredrik Matheson",
      "screen_name" : "movito",
      "indices" : [ 3, 10 ],
      "id_str" : "700593",
      "id" : 700593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758023768270700545",
  "text" : "RT @movito: UX hasn't had enough qualified people for decades, so we're flying semi-blind while building the software that's eating the wor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758020268547801088",
    "text" : "UX hasn't had enough qualified people for decades, so we're flying semi-blind while building the software that's eating the world.",
    "id" : 758020268547801088,
    "created_at" : "2016-07-26 19:24:50 +0000",
    "user" : {
      "name" : "Fredrik Matheson",
      "screen_name" : "movito",
      "protected" : false,
      "id_str" : "700593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460457076204916736\/jey8mT4q_normal.png",
      "id" : 700593,
      "verified" : false
    }
  },
  "id" : 758023768270700545,
  "created_at" : "2016-07-26 19:38:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jiri Jerabek",
      "screen_name" : "JiriJerabek",
      "indices" : [ 3, 15 ],
      "id_str" : "49653401",
      "id" : 49653401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757694388302512128",
  "text" : "RT @JiriJerabek: A good designer considers different opinions. A great designer recognises the difference between an opinion and an insight.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757623796492865540",
    "text" : "A good designer considers different opinions. A great designer recognises the difference between an opinion and an insight.",
    "id" : 757623796492865540,
    "created_at" : "2016-07-25 17:09:23 +0000",
    "user" : {
      "name" : "Jiri Jerabek",
      "screen_name" : "JiriJerabek",
      "protected" : false,
      "id_str" : "49653401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2827421435\/bfe2e4dc6cdf7ac3dadaedc92f774e98_normal.jpeg",
      "id" : 49653401,
      "verified" : false
    }
  },
  "id" : 757694388302512128,
  "created_at" : "2016-07-25 21:49:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/Pn1UF0kHtM",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-07-18-setting-up-your-grav-course-hub",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757684243233406977",
  "text" : "Updated Post: Setting Up a Course in the Grav Course Hub (Admin Panel and Working Directly with Files) https:\/\/t.co\/Pn1UF0kHtM #GravEdu",
  "id" : 757684243233406977,
  "created_at" : "2016-07-25 21:09:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 0, 15 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755080950376239104",
  "geo" : { },
  "id_str" : "757672517985112064",
  "in_reply_to_user_id" : 1602053274,
  "text" : "@ReclaimHosting I've still got my fingers crossed for a Grav Installatron update + Course Hub skeleton... only 6 weeks until start of term \uD83D\uDE42",
  "id" : 757672517985112064,
  "in_reply_to_status_id" : 755080950376239104,
  "created_at" : "2016-07-25 20:22:59 +0000",
  "in_reply_to_screen_name" : "ReclaimHosting",
  "in_reply_to_user_id_str" : "1602053274",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 43, 52 ],
      "id_str" : "890887814",
      "id" : 890887814
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/757663559031541760\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/MM4YNXzgDQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoPC6y2UMAARXgy.jpg",
      "id_str" : "757663477666164736",
      "id" : 757663477666164736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoPC6y2UMAARXgy.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 197
      }, {
        "h" : 2892,
        "resize" : "fit",
        "w" : 839
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 348
      } ],
      "display_url" : "pic.twitter.com\/MM4YNXzgDQ"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/757663559031541760\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/MM4YNXzgDQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoPC9uSVIAE-KFh.jpg",
      "id_str" : "757663527981096961",
      "id" : 757663527981096961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoPC9uSVIAE-KFh.jpg",
      "sizes" : [ {
        "h" : 478,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 759,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 759,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 759,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/MM4YNXzgDQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757663559031541760",
  "text" : "Really enjoying the editing environment of @swipe_to with bird's-eye view across slidedecks and content in Markdown. https:\/\/t.co\/MM4YNXzgDQ",
  "id" : 757663559031541760,
  "created_at" : "2016-07-25 19:47:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Lampe",
      "screen_name" : "Situationalist",
      "indices" : [ 0, 15 ],
      "id_str" : "316862691",
      "id" : 316862691
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 16, 23 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/79N8bLYDGe",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2015-12-18-flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    }, {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/qTgCdG6ZPM",
      "expanded_url" : "http:\/\/demo.hibbittsdesign.org\/grav-course-hub\/",
      "display_url" : "demo.hibbittsdesign.org\/grav-course-hu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "757569513709793280",
  "geo" : { },
  "id_str" : "757616326059843585",
  "in_reply_to_user_id" : 316862691,
  "text" : "@Situationalist @btopro I've had success 'flipping' the LMS... https:\/\/t.co\/79N8bLYDGe Demo: https:\/\/t.co\/qTgCdG6ZPM",
  "id" : 757616326059843585,
  "in_reply_to_status_id" : 757569513709793280,
  "created_at" : "2016-07-25 16:39:42 +0000",
  "in_reply_to_screen_name" : "Situationalist",
  "in_reply_to_user_id_str" : "316862691",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 3, 11 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/29drJS5jvs",
      "expanded_url" : "https:\/\/youtu.be\/53RZQVynmMQ",
      "display_url" : "youtu.be\/53RZQVynmMQ"
    } ]
  },
  "geo" : { },
  "id_str" : "757361543801479168",
  "text" : "RT @drchuck: Introducing Sakai 11 https:\/\/t.co\/29drJS5jvs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/29drJS5jvs",
        "expanded_url" : "https:\/\/youtu.be\/53RZQVynmMQ",
        "display_url" : "youtu.be\/53RZQVynmMQ"
      } ]
    },
    "geo" : { },
    "id_str" : "757358721785663490",
    "text" : "Introducing Sakai 11 https:\/\/t.co\/29drJS5jvs",
    "id" : 757358721785663490,
    "created_at" : "2016-07-24 23:36:04 +0000",
    "user" : {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "protected" : false,
      "id_str" : "10185562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1396181322\/new-square-pic_normal.jpg",
      "id" : 10185562,
      "verified" : false
    }
  },
  "id" : 757361543801479168,
  "created_at" : "2016-07-24 23:47:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Peter",
      "screen_name" : "danieljpeter",
      "indices" : [ 3, 16 ],
      "id_str" : "58560915",
      "id" : 58560915
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/danieljpeter\/status\/757115807331516416\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/NtD9UzJ2JE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoHQzuwVYAAIIkw.jpg",
      "id_str" : "757115799517618176",
      "id" : 757115799517618176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoHQzuwVYAAIIkw.jpg",
      "sizes" : [ {
        "h" : 289,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 289,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 289,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 289,
        "resize" : "fit",
        "w" : 350
      } ],
      "display_url" : "pic.twitter.com\/NtD9UzJ2JE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757357725164576768",
  "text" : "RT @danieljpeter: RT if you've ever typed AT commands like ATDT to control a modem https:\/\/t.co\/NtD9UzJ2JE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/danieljpeter\/status\/757115807331516416\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/NtD9UzJ2JE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoHQzuwVYAAIIkw.jpg",
        "id_str" : "757115799517618176",
        "id" : 757115799517618176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoHQzuwVYAAIIkw.jpg",
        "sizes" : [ {
          "h" : 289,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 289,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 289,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 289,
          "resize" : "fit",
          "w" : 350
        } ],
        "display_url" : "pic.twitter.com\/NtD9UzJ2JE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757115807331516416",
    "text" : "RT if you've ever typed AT commands like ATDT to control a modem https:\/\/t.co\/NtD9UzJ2JE",
    "id" : 757115807331516416,
    "created_at" : "2016-07-24 07:30:49 +0000",
    "user" : {
      "name" : "Daniel Peter",
      "screen_name" : "danieljpeter",
      "protected" : false,
      "id_str" : "58560915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759409212023681024\/EGHJ3lPS_normal.jpg",
      "id" : 58560915,
      "verified" : false
    }
  },
  "id" : 757357725164576768,
  "created_at" : "2016-07-24 23:32:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Norton",
      "screen_name" : "kennethn",
      "indices" : [ 3, 12 ],
      "id_str" : "17106845",
      "id" : 17106845
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kennethn\/status\/757232106342785024\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/j04CCeDtYp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoI6j1WUkAADCjZ.jpg",
      "id_str" : "757232074642198528",
      "id" : 757232074642198528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoI6j1WUkAADCjZ.jpg",
      "sizes" : [ {
        "h" : 185,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 630
      } ],
      "display_url" : "pic.twitter.com\/j04CCeDtYp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/STkT6XF7Pv",
      "expanded_url" : "http:\/\/www.geekwire.com\/2016\/ray-kurzweil-world-isnt-getting-worse-information-getting-better\/",
      "display_url" : "geekwire.com\/2016\/ray-kurzw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757269498365739008",
  "text" : "RT @kennethn: The world isn't getting worse, our information is getting better \u2013 Ray Kurzweil https:\/\/t.co\/STkT6XF7Pv https:\/\/t.co\/j04CCeDt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kennethn\/status\/757232106342785024\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/j04CCeDtYp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoI6j1WUkAADCjZ.jpg",
        "id_str" : "757232074642198528",
        "id" : 757232074642198528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoI6j1WUkAADCjZ.jpg",
        "sizes" : [ {
          "h" : 185,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 630
        } ],
        "display_url" : "pic.twitter.com\/j04CCeDtYp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/STkT6XF7Pv",
        "expanded_url" : "http:\/\/www.geekwire.com\/2016\/ray-kurzweil-world-isnt-getting-worse-information-getting-better\/",
        "display_url" : "geekwire.com\/2016\/ray-kurzw\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757232106342785024",
    "text" : "The world isn't getting worse, our information is getting better \u2013 Ray Kurzweil https:\/\/t.co\/STkT6XF7Pv https:\/\/t.co\/j04CCeDtYp",
    "id" : 757232106342785024,
    "created_at" : "2016-07-24 15:12:57 +0000",
    "user" : {
      "name" : "Ken Norton",
      "screen_name" : "kennethn",
      "protected" : false,
      "id_str" : "17106845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680951995495104512\/M-OZiDpQ_normal.jpg",
      "id" : 17106845,
      "verified" : true
    }
  },
  "id" : 757269498365739008,
  "created_at" : "2016-07-24 17:41:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Webster",
      "screen_name" : "FionaWebster1",
      "indices" : [ 3, 17 ],
      "id_str" : "449194290",
      "id" : 449194290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/Ua1WW9GUxF",
      "expanded_url" : "https:\/\/twitter.com\/dk_munro\/status\/756946919721734144",
      "display_url" : "twitter.com\/dk_munro\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757009789998116870",
  "text" : "RT @FionaWebster1: The passing of a truly inspiring scientist and pioneer for all women academics. Thank you Ursula Franklin! https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/Ua1WW9GUxF",
        "expanded_url" : "https:\/\/twitter.com\/dk_munro\/status\/756946919721734144",
        "display_url" : "twitter.com\/dk_munro\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "756999702835585024",
    "text" : "The passing of a truly inspiring scientist and pioneer for all women academics. Thank you Ursula Franklin! https:\/\/t.co\/Ua1WW9GUxF",
    "id" : 756999702835585024,
    "created_at" : "2016-07-23 23:49:28 +0000",
    "user" : {
      "name" : "Fiona Webster",
      "screen_name" : "FionaWebster1",
      "protected" : false,
      "id_str" : "449194290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/633094467931795457\/jnQnd88u_normal.jpg",
      "id" : 449194290,
      "verified" : false
    }
  },
  "id" : 757009789998116870,
  "created_at" : "2016-07-24 00:29:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin DeRosa",
      "screen_name" : "actualham",
      "indices" : [ 0, 10 ],
      "id_str" : "2182862052",
      "id" : 2182862052
    }, {
      "name" : "Dan Blickensderfer",
      "screen_name" : "Dan_Blick",
      "indices" : [ 11, 21 ],
      "id_str" : "188554158",
      "id" : 188554158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/JHTWeNGqvt",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-07-14-the-beauty-of-combining-canvas-lms-with-grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "756882725735370752",
  "geo" : { },
  "id_str" : "756896100334698496",
  "in_reply_to_user_id" : 2182862052,
  "text" : "@actualham @Dan_Blick I've been exploring providing downloadable file + raw Markdown links, eg see bottom of post -&gt; https:\/\/t.co\/JHTWeNGqvt",
  "id" : 756896100334698496,
  "in_reply_to_status_id" : 756882725735370752,
  "created_at" : "2016-07-23 16:57:47 +0000",
  "in_reply_to_screen_name" : "actualham",
  "in_reply_to_user_id_str" : "2182862052",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Cooper",
      "screen_name" : "MrAlanCooper",
      "indices" : [ 0, 13 ],
      "id_str" : "103920270",
      "id" : 103920270
    }, {
      "name" : "Wimp.com",
      "screen_name" : "Wimpcom",
      "indices" : [ 14, 22 ],
      "id_str" : "97329856",
      "id" : 97329856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756222824545525760",
  "geo" : { },
  "id_str" : "756224293936111616",
  "in_reply_to_user_id" : 103920270,
  "text" : "@MrAlanCooper @Wimpcom I remember seeing a version of this in high school, circa 1981. I wonder how many kids know of her now?",
  "id" : 756224293936111616,
  "in_reply_to_status_id" : 756222824545525760,
  "created_at" : "2016-07-21 20:28:16 +0000",
  "in_reply_to_screen_name" : "MrAlanCooper",
  "in_reply_to_user_id_str" : "103920270",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/755921937352699904\/photo\/1",
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/6XkjHszLvq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn2S_lZUkAA9Kdj.jpg",
      "id_str" : "755921933535842304",
      "id" : 755921933535842304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn2S_lZUkAA9Kdj.jpg",
      "sizes" : [ {
        "h" : 554,
        "resize" : "fit",
        "w" : 1028
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 554,
        "resize" : "fit",
        "w" : 1028
      }, {
        "h" : 554,
        "resize" : "fit",
        "w" : 1028
      } ],
      "display_url" : "pic.twitter.com\/6XkjHszLvq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/e6IoGucUlH",
      "expanded_url" : "https:\/\/learn.getgrav.org\/themes\/theme-tutorial",
      "display_url" : "learn.getgrav.org\/themes\/theme-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755975289763528704",
  "text" : "RT @getgrav: The Theme Tutorial rewritten to use Grav's new DevTools plugin. Now Pure.css powered!https:\/\/t.co\/e6IoGucUlH https:\/\/t.co\/6Xkj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/755921937352699904\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/6XkjHszLvq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn2S_lZUkAA9Kdj.jpg",
        "id_str" : "755921933535842304",
        "id" : 755921933535842304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn2S_lZUkAA9Kdj.jpg",
        "sizes" : [ {
          "h" : 554,
          "resize" : "fit",
          "w" : 1028
        }, {
          "h" : 366,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 554,
          "resize" : "fit",
          "w" : 1028
        }, {
          "h" : 554,
          "resize" : "fit",
          "w" : 1028
        } ],
        "display_url" : "pic.twitter.com\/6XkjHszLvq"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/e6IoGucUlH",
        "expanded_url" : "https:\/\/learn.getgrav.org\/themes\/theme-tutorial",
        "display_url" : "learn.getgrav.org\/themes\/theme-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755921937352699904",
    "text" : "The Theme Tutorial rewritten to use Grav's new DevTools plugin. Now Pure.css powered!https:\/\/t.co\/e6IoGucUlH https:\/\/t.co\/6XkjHszLvq",
    "id" : 755921937352699904,
    "created_at" : "2016-07-21 00:26:48 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 755975289763528704,
  "created_at" : "2016-07-21 03:58:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 37, 45 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/Pn1UF0Cilk",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-07-18-setting-up-your-grav-course-hub",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755864109757759488",
  "text" : "New Post: Setting Up a Course in the @getgrav Course Hub https:\/\/t.co\/Pn1UF0Cilk Course Hub options will be in Admin Panel soon! #GravEdu",
  "id" : 755864109757759488,
  "created_at" : "2016-07-20 20:37:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755859946261053440",
  "text" : "Hey my fellow Mac-heads, what screen recorder do you find produces the clearest movies for sharing on Twitter?",
  "id" : 755859946261053440,
  "created_at" : "2016-07-20 20:20:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/755857480006012928\/video\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/a1mwWspgiW",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/755857263298957313\/pu\/img\/zEq-feOPgMAwmgUa.jpg",
      "id_str" : "755857263298957313",
      "id" : 755857263298957313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/755857263298957313\/pu\/img\/zEq-feOPgMAwmgUa.jpg",
      "sizes" : [ {
        "h" : 264,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 464
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 464
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/a1mwWspgiW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755857480006012928",
  "text" : "So just how easy will it be to enable GitHub\/GitLab editing of materials in Grav Course Hub soon? Watch and see... https:\/\/t.co\/a1mwWspgiW",
  "id" : 755857480006012928,
  "created_at" : "2016-07-20 20:10:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 32, 40 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/755828743084519428\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ytohlGw30i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn09yt8VMAAySTG.jpg",
      "id_str" : "755828254003507200",
      "id" : 755828254003507200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn09yt8VMAAySTG.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 836,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 836,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 836,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/ytohlGw30i"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755828743084519428",
  "text" : "Thanks to the amazing design of @getgrav the next release of the Grav Course Gub will provide a site config form.\uD83D\uDC4D https:\/\/t.co\/ytohlGw30i",
  "id" : 755828743084519428,
  "created_at" : "2016-07-20 18:16:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gravstrap",
      "screen_name" : "gravstrap",
      "indices" : [ 3, 13 ],
      "id_str" : "701343168558669824",
      "id" : 701343168558669824
    }, {
      "name" : "Gravstrap",
      "screen_name" : "gravstrap",
      "indices" : [ 29, 39 ],
      "id_str" : "701343168558669824",
      "id" : 701343168558669824
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 78, 86 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "grav",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/pn8M9q7q2T",
      "expanded_url" : "https:\/\/github.com\/giansi\/gravstrap-theme-skeleton\/releases\/download\/v1.2.0\/gravstrap-skeleton.zip",
      "display_url" : "github.com\/giansi\/gravstr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755575843263393792",
  "text" : "RT @gravstrap: Just released @gravstrap skeleton, updated to latest #grav \/cc @getgrav https:\/\/t.co\/pn8M9q7q2T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gravstrap",
        "screen_name" : "gravstrap",
        "indices" : [ 14, 24 ],
        "id_str" : "701343168558669824",
        "id" : 701343168558669824
      }, {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 63, 71 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "grav",
        "indices" : [ 53, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/pn8M9q7q2T",
        "expanded_url" : "https:\/\/github.com\/giansi\/gravstrap-theme-skeleton\/releases\/download\/v1.2.0\/gravstrap-skeleton.zip",
        "display_url" : "github.com\/giansi\/gravstr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755442960565755905",
    "text" : "Just released @gravstrap skeleton, updated to latest #grav \/cc @getgrav https:\/\/t.co\/pn8M9q7q2T",
    "id" : 755442960565755905,
    "created_at" : "2016-07-19 16:43:31 +0000",
    "user" : {
      "name" : "Gravstrap",
      "screen_name" : "gravstrap",
      "protected" : false,
      "id_str" : "701343168558669824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704008901663047681\/wXrpVz9s_normal.jpg",
      "id" : 701343168558669824,
      "verified" : false
    }
  },
  "id" : 755575843263393792,
  "created_at" : "2016-07-20 01:31:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "indices" : [ 3, 15 ],
      "id_str" : "19812150",
      "id" : 19812150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/39cypSYVT5",
      "expanded_url" : "http:\/\/tonybates.ca",
      "display_url" : "tonybates.ca"
    } ]
  },
  "geo" : { },
  "id_str" : "755572378621534209",
  "text" : "RT @drtonybates: New series of posts: online learning for beginners at https:\/\/t.co\/39cypSYVT5. Please pass on to instructors thinking abou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/39cypSYVT5",
        "expanded_url" : "http:\/\/tonybates.ca",
        "display_url" : "tonybates.ca"
      } ]
    },
    "geo" : { },
    "id_str" : "755570881401720832",
    "text" : "New series of posts: online learning for beginners at https:\/\/t.co\/39cypSYVT5. Please pass on to instructors thinking about online learning",
    "id" : 755570881401720832,
    "created_at" : "2016-07-20 01:11:50 +0000",
    "user" : {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "protected" : false,
      "id_str" : "19812150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2563456751\/wicaixr93w2lri2wsarw_normal.jpeg",
      "id" : 19812150,
      "verified" : false
    }
  },
  "id" : 755572378621534209,
  "created_at" : "2016-07-20 01:17:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 84, 92 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/Pn1UF0Cilk",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-07-18-setting-up-your-grav-course-hub",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755495885346254848",
  "text" : "Sneak peek (really a rough draft) of the long overdue guide for setting up your own @getgrav Course Hub: https:\/\/t.co\/Pn1UF0Cilk Comments?",
  "id" : 755495885346254848,
  "created_at" : "2016-07-19 20:13:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 3, 11 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "remote",
      "indices" : [ 52, 59 ]
    }, {
      "text" : "UX",
      "indices" : [ 60, 63 ]
    }, {
      "text" : "design",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/8y1ofIJ8k0",
      "expanded_url" : "https:\/\/mural.co\/tour\/",
      "display_url" : "mural.co\/tour\/"
    } ]
  },
  "geo" : { },
  "id_str" : "755238685948252160",
  "text" : "RT @dmitryn: This looks like a pretty cool tool for #remote #UX #design: https:\/\/t.co\/8y1ofIJ8k0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "remote",
        "indices" : [ 39, 46 ]
      }, {
        "text" : "UX",
        "indices" : [ 47, 50 ]
      }, {
        "text" : "design",
        "indices" : [ 51, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/8y1ofIJ8k0",
        "expanded_url" : "https:\/\/mural.co\/tour\/",
        "display_url" : "mural.co\/tour\/"
      } ]
    },
    "geo" : { },
    "id_str" : "755209870484307968",
    "text" : "This looks like a pretty cool tool for #remote #UX #design: https:\/\/t.co\/8y1ofIJ8k0",
    "id" : 755209870484307968,
    "created_at" : "2016-07-19 01:17:18 +0000",
    "user" : {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "protected" : false,
      "id_str" : "1550251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623216199791329280\/hoNAcmrW_normal.jpg",
      "id" : 1550251,
      "verified" : false
    }
  },
  "id" : 755238685948252160,
  "created_at" : "2016-07-19 03:11:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/C3BwMWCW38",
      "expanded_url" : "https:\/\/workflowy.com\/s\/i4Aa6rtIie",
      "display_url" : "workflowy.com\/s\/i4Aa6rtIie"
    } ]
  },
  "geo" : { },
  "id_str" : "755150869406949376",
  "text" : "There's now enough momentum with my Grav Course Hub project to write an article about setting up a course - outline: https:\/\/t.co\/C3BwMWCW38",
  "id" : 755150869406949376,
  "created_at" : "2016-07-18 21:22:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 18, 33 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755117733251997696",
  "text" : "RT @btopro: well, @hibbittsdesign would be proud; at least I found 2 courses that have 1st page in canvas course say \u201CLINK TO COURSE\u201D and g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 6, 21 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755114368522653696",
    "text" : "well, @hibbittsdesign would be proud; at least I found 2 courses that have 1st page in canvas course say \u201CLINK TO COURSE\u201D and go external",
    "id" : 755114368522653696,
    "created_at" : "2016-07-18 18:57:49 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 755117733251997696,
  "created_at" : "2016-07-18 19:11:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 3, 15 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SandstormIO\/status\/755103310349303808\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/y1hTBEjT5g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnqqdLUWIAAtFJg.jpg",
      "id_str" : "755103305769033728",
      "id" : 755103305769033728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnqqdLUWIAAtFJg.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/y1hTBEjT5g"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/pP7i7Bd732",
      "expanded_url" : "https:\/\/sandstorm.io\/news\/2016-07-13-whats-new",
      "display_url" : "sandstorm.io\/news\/2016-07-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755104122819325952",
  "text" : "RT @SandstormIO: What's new in Sandstorm? Guided tour improvements &amp; more. See our June changelog for details https:\/\/t.co\/pP7i7Bd732 https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SandstormIO\/status\/755103310349303808\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/y1hTBEjT5g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnqqdLUWIAAtFJg.jpg",
        "id_str" : "755103305769033728",
        "id" : 755103305769033728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnqqdLUWIAAtFJg.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/y1hTBEjT5g"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/pP7i7Bd732",
        "expanded_url" : "https:\/\/sandstorm.io\/news\/2016-07-13-whats-new",
        "display_url" : "sandstorm.io\/news\/2016-07-1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755103310349303808",
    "text" : "What's new in Sandstorm? Guided tour improvements &amp; more. See our June changelog for details https:\/\/t.co\/pP7i7Bd732 https:\/\/t.co\/y1hTBEjT5g",
    "id" : 755103310349303808,
    "created_at" : "2016-07-18 18:13:52 +0000",
    "user" : {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "protected" : false,
      "id_str" : "2476570038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463413707150589952\/s17ccuOO_normal.png",
      "id" : 2476570038,
      "verified" : false
    }
  },
  "id" : 755104122819325952,
  "created_at" : "2016-07-18 18:17:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flavio Copes",
      "screen_name" : "flaviocopes",
      "indices" : [ 3, 15 ],
      "id_str" : "9011502",
      "id" : 9011502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/TVxVnxZ0Lq",
      "expanded_url" : "https:\/\/www.producthunt.com\/tech\/grav-v1-1-an-open-source-flat-file-cms",
      "display_url" : "producthunt.com\/tech\/grav-v1-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755094871107522560",
  "text" : "RT @flaviocopes: Please RT and upvote Grav on Product Hunt :) https:\/\/t.co\/TVxVnxZ0Lq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/TVxVnxZ0Lq",
        "expanded_url" : "https:\/\/www.producthunt.com\/tech\/grav-v1-1-an-open-source-flat-file-cms",
        "display_url" : "producthunt.com\/tech\/grav-v1-1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755088044064182277",
    "text" : "Please RT and upvote Grav on Product Hunt :) https:\/\/t.co\/TVxVnxZ0Lq",
    "id" : 755088044064182277,
    "created_at" : "2016-07-18 17:13:13 +0000",
    "user" : {
      "name" : "Flavio Copes",
      "screen_name" : "flaviocopes",
      "protected" : false,
      "id_str" : "9011502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603302280243347458\/tgF_XZ_J_normal.jpg",
      "id" : 9011502,
      "verified" : false
    }
  },
  "id" : 755094871107522560,
  "created_at" : "2016-07-18 17:40:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/L4vgd29InC",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755084351969202176",
  "text" : "Fall term starts in 7 weeks. Looking to move beyond your LMS? Flip it with the open &amp; collaborative Grav Course Hub: https:\/\/t.co\/L4vgd29InC",
  "id" : 755084351969202176,
  "created_at" : "2016-07-18 16:58:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 0, 15 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    }, {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 16, 30 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755080950376239104",
  "geo" : { },
  "id_str" : "755081456066572288",
  "in_reply_to_user_id" : 1602053274,
  "text" : "@ReclaimHosting @clhendricksbc Thanks so much, that would be great to see!",
  "id" : 755081456066572288,
  "in_reply_to_status_id" : 755080950376239104,
  "created_at" : "2016-07-18 16:47:02 +0000",
  "in_reply_to_screen_name" : "ReclaimHosting",
  "in_reply_to_user_id_str" : "1602053274",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 0, 15 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    }, {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 16, 30 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755079871974506497",
  "geo" : { },
  "id_str" : "755080654853771264",
  "in_reply_to_user_id" : 1602053274,
  "text" : "@ReclaimHosting @clhendricksbc It would be super awesome to see a Grav 1.1 installer too \uD83D\uDE42",
  "id" : 755080654853771264,
  "in_reply_to_status_id" : 755079871974506497,
  "created_at" : "2016-07-18 16:43:51 +0000",
  "in_reply_to_screen_name" : "ReclaimHosting",
  "in_reply_to_user_id_str" : "1602053274",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 15, 30 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755079687903195136",
  "geo" : { },
  "id_str" : "755080261872734208",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc @ReclaimHosting You can update everything in the Admin Panel, I would suggest updating Grav first, then plugins\/themes.",
  "id" : 755080261872734208,
  "in_reply_to_status_id" : 755079687903195136,
  "created_at" : "2016-07-18 16:42:17 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/L4vgd29InC",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/TJoTJOUcZz",
      "expanded_url" : "https:\/\/twitter.com\/designernewsbot\/status\/755075588952645632",
      "display_url" : "twitter.com\/designernewsbo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755077611533979648",
  "text" : "The Grav Course Hub skeleton package is also updated and all ready to go with Grav v1.1 https:\/\/t.co\/L4vgd29InC https:\/\/t.co\/TJoTJOUcZz",
  "id" : 755077611533979648,
  "created_at" : "2016-07-18 16:31:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Bovis",
      "screen_name" : "PaulBovis",
      "indices" : [ 44, 54 ],
      "id_str" : "1004346642",
      "id" : 1004346642
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 93, 101 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/JLH3G5eBK0",
      "expanded_url" : "https:\/\/twitter.com\/PaulBovis\/status\/754753052607864832",
      "display_url" : "twitter.com\/PaulBovis\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754756506889756672",
  "text" : "I'll second that second! Awesome to see you @PaulBovis and continue our plotting to leverage @getgrav in EDU space.\uD83D\uDC4D https:\/\/t.co\/JLH3G5eBK0",
  "id" : 754756506889756672,
  "created_at" : "2016-07-17 19:15:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 53, 61 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Paul Bovis",
      "screen_name" : "PaulBovis",
      "indices" : [ 91, 101 ],
      "id_str" : "1004346642",
      "id" : 1004346642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754421393316470787",
  "text" : "Really looking forward to the second annual Canadian @getgrav CMS meetup in Vancouver with @PaulBovis tomorrow \uD83D\uDE80",
  "id" : 754421393316470787,
  "created_at" : "2016-07-16 21:04:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/neS5EnTcAc",
      "expanded_url" : "https:\/\/getgrav.org\/blog\/cms-critic-award-nominations-2016",
      "display_url" : "getgrav.org\/blog\/cms-criti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754017505392275456",
  "text" : "RT @getgrav: Please nominate \"Grav\" for \"Best [Free, Open Source, and Education] CMS\" in the 2016 CMS Critics Award Nominations https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/neS5EnTcAc",
        "expanded_url" : "https:\/\/getgrav.org\/blog\/cms-critic-award-nominations-2016",
        "display_url" : "getgrav.org\/blog\/cms-criti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753595436292726785",
    "text" : "Please nominate \"Grav\" for \"Best [Free, Open Source, and Education] CMS\" in the 2016 CMS Critics Award Nominations https:\/\/t.co\/neS5EnTcAc",
    "id" : 753595436292726785,
    "created_at" : "2016-07-14 14:22:07 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 754017505392275456,
  "created_at" : "2016-07-15 18:19:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 0, 12 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754007205205184512",
  "geo" : { },
  "id_str" : "754010629317414912",
  "in_reply_to_user_id" : 6271482,
  "text" : "@grantpotter Lovely! I have very fond memories of Keji as a kid, camping there with a friend's family. Enjoy your stay.",
  "id" : 754010629317414912,
  "in_reply_to_status_id" : 754007205205184512,
  "created_at" : "2016-07-15 17:51:57 +0000",
  "in_reply_to_screen_name" : "grantpotter",
  "in_reply_to_user_id_str" : "6271482",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barish Golland",
      "screen_name" : "BarishGolland",
      "indices" : [ 0, 14 ],
      "id_str" : "32352319",
      "id" : 32352319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/JHTWeNGqvt",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-07-14-the-beauty-of-combining-canvas-lms-with-grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754004427187429376",
  "in_reply_to_user_id" : 32352319,
  "text" : "@BarishGolland I thought you might be interested in this new post about Canvas. Because rumors. https:\/\/t.co\/JHTWeNGqvt Improvements?",
  "id" : 754004427187429376,
  "created_at" : "2016-07-15 17:27:18 +0000",
  "in_reply_to_screen_name" : "BarishGolland",
  "in_reply_to_user_id_str" : "32352319",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 79, 87 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 57, 61 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/JHTWeNGqvt",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-07-14-the-beauty-of-combining-canvas-lms-with-grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754003404733546496",
  "text" : "Second draft of an upcoming post about my experiences at #SFU with #CanvasLMS, @getgrav and the Grav Course Hub: https:\/\/t.co\/JHTWeNGqvt",
  "id" : 754003404733546496,
  "created_at" : "2016-07-15 17:23:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 0, 11 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/JHTWeNGqvt",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-07-14-the-beauty-of-combining-canvas-lms-with-grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753983000019296256",
  "in_reply_to_user_id" : 1983141,
  "text" : "@okalrelsrv Hi Lynda, I just wrote a post about Canvas and Grav that might be of interest to you: https:\/\/t.co\/JHTWeNGqvt. Comments welcome\uD83D\uDE42",
  "id" : 753983000019296256,
  "created_at" : "2016-07-15 16:02:10 +0000",
  "in_reply_to_screen_name" : "okalrelsrv",
  "in_reply_to_user_id_str" : "1983141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 68, 76 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/JHTWeNGqvt",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-07-14-the-beauty-of-combining-canvas-lms-with-grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753735102887174145",
  "text" : "Sneak peek at a new blog post about my experiences with #CanvasLMS, @getgrav and the Grav Course Hub project: https:\/\/t.co\/JHTWeNGqvt",
  "id" : 753735102887174145,
  "created_at" : "2016-07-14 23:37:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/C4bK8Q8fFU",
      "expanded_url" : "https:\/\/twitter.com\/getgrav\/status\/753699645902114816",
      "display_url" : "twitter.com\/getgrav\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753709237180641281",
  "text" : "Fantastic news! Keep an eye open for a new release of the Grav Course Hub for Grav 1.1\uD83D\uDE80 https:\/\/t.co\/C4bK8Q8fFU",
  "id" : 753709237180641281,
  "created_at" : "2016-07-14 21:54:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Wendt",
      "screen_name" : "stanwendt",
      "indices" : [ 40, 50 ],
      "id_str" : "52510472",
      "id" : 52510472
    }, {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 51, 60 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 61, 74 ],
      "id_str" : "12991032",
      "id" : 12991032
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 119, 127 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 21, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753682571385380864",
  "text" : "Thanks for the great #CanvasLMS session @stanwendt @BCcampus @clintlalonde! Working on a blog post about my Canvas and @getgrav experiences.",
  "id" : 753682571385380864,
  "created_at" : "2016-07-14 20:08:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aidan Feldman",
      "screen_name" : "aidanfeldman",
      "indices" : [ 3, 16 ],
      "id_str" : "18061835",
      "id" : 18061835
    }, {
      "name" : "Ed Mullen",
      "screen_name" : "edmullen",
      "indices" : [ 100, 109 ],
      "id_str" : "19805527",
      "id" : 19805527
    }, {
      "name" : "18F",
      "screen_name" : "18F",
      "indices" : [ 110, 114 ],
      "id_str" : "2366194867",
      "id" : 2366194867
    }, {
      "name" : "Civic Hall",
      "screen_name" : "CivicHall",
      "indices" : [ 115, 125 ],
      "id_str" : "2830254912",
      "id" : 2830254912
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/aidanfeldman\/status\/753635192175202305\/photo\/1",
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/BLRNSNRNq9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnVzM25XEAIQYBs.jpg",
      "id_str" : "753635177386151938",
      "id" : 753635177386151938,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnVzM25XEAIQYBs.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/BLRNSNRNq9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753678983191900160",
  "text" : "RT @aidanfeldman: \"when working with incumbent stakeholders, be humble. assume competence. listen.\" @edmullen @18F @CivicHall https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ed Mullen",
        "screen_name" : "edmullen",
        "indices" : [ 82, 91 ],
        "id_str" : "19805527",
        "id" : 19805527
      }, {
        "name" : "18F",
        "screen_name" : "18F",
        "indices" : [ 92, 96 ],
        "id_str" : "2366194867",
        "id" : 2366194867
      }, {
        "name" : "Civic Hall",
        "screen_name" : "CivicHall",
        "indices" : [ 97, 107 ],
        "id_str" : "2830254912",
        "id" : 2830254912
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/aidanfeldman\/status\/753635192175202305\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/BLRNSNRNq9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnVzM25XEAIQYBs.jpg",
        "id_str" : "753635177386151938",
        "id" : 753635177386151938,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnVzM25XEAIQYBs.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/BLRNSNRNq9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753635192175202305",
    "text" : "\"when working with incumbent stakeholders, be humble. assume competence. listen.\" @edmullen @18F @CivicHall https:\/\/t.co\/BLRNSNRNq9",
    "id" : 753635192175202305,
    "created_at" : "2016-07-14 17:00:06 +0000",
    "user" : {
      "name" : "Aidan Feldman",
      "screen_name" : "aidanfeldman",
      "protected" : false,
      "id_str" : "18061835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3777679925\/db63dd69ac5f7c77fb5f941c35fcf7f1_normal.jpeg",
      "id" : 18061835,
      "verified" : false
    }
  },
  "id" : 753678983191900160,
  "created_at" : "2016-07-14 19:54:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin DeRosa",
      "screen_name" : "actualham",
      "indices" : [ 3, 13 ],
      "id_str" : "2182862052",
      "id" : 2182862052
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Digped",
      "indices" : [ 15, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/a45PKHlo7c",
      "expanded_url" : "https:\/\/www.edsurge.com\/news\/2015-08-10-do-i-own-my-domain-if-you-grade-it",
      "display_url" : "edsurge.com\/news\/2015-08-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753653383169400832",
  "text" : "RT @actualham: #Digped Networks folks might want to look at this essay by an undergrad, in concert with Audrey's piece: https:\/\/t.co\/a45PKH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Digped",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/a45PKHlo7c",
        "expanded_url" : "https:\/\/www.edsurge.com\/news\/2015-08-10-do-i-own-my-domain-if-you-grade-it",
        "display_url" : "edsurge.com\/news\/2015-08-1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753561047823425536",
    "text" : "#Digped Networks folks might want to look at this essay by an undergrad, in concert with Audrey's piece: https:\/\/t.co\/a45PKHlo7c",
    "id" : 753561047823425536,
    "created_at" : "2016-07-14 12:05:28 +0000",
    "user" : {
      "name" : "Robin DeRosa",
      "screen_name" : "actualham",
      "protected" : false,
      "id_str" : "2182862052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479442862648475648\/SlBCXbg7_normal.jpeg",
      "id" : 2182862052,
      "verified" : false
    }
  },
  "id" : 753653383169400832,
  "created_at" : "2016-07-14 18:12:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H5P",
      "screen_name" : "H5PTechnology",
      "indices" : [ 3, 17 ],
      "id_str" : "2216405440",
      "id" : 2216405440
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/H5PTechnology\/status\/753650747573735424\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/eTMlIQT2zd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnWBIXrXYAA07W4.png",
      "id_str" : "753650493449265152",
      "id" : 753650493449265152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnWBIXrXYAA07W4.png",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/eTMlIQT2zd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/HQ6p8F1MZy",
      "expanded_url" : "https:\/\/h5p.org\/blog\/h5p-for-moodle-is-ready",
      "display_url" : "h5p.org\/blog\/h5p-for-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753652932864684032",
  "text" : "RT @H5PTechnology: H5P for Moodle is finally ready! https:\/\/t.co\/HQ6p8F1MZy https:\/\/t.co\/eTMlIQT2zd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/H5PTechnology\/status\/753650747573735424\/photo\/1",
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/eTMlIQT2zd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnWBIXrXYAA07W4.png",
        "id_str" : "753650493449265152",
        "id" : 753650493449265152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnWBIXrXYAA07W4.png",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/eTMlIQT2zd"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/HQ6p8F1MZy",
        "expanded_url" : "https:\/\/h5p.org\/blog\/h5p-for-moodle-is-ready",
        "display_url" : "h5p.org\/blog\/h5p-for-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753650747573735424",
    "text" : "H5P for Moodle is finally ready! https:\/\/t.co\/HQ6p8F1MZy https:\/\/t.co\/eTMlIQT2zd",
    "id" : 753650747573735424,
    "created_at" : "2016-07-14 18:01:55 +0000",
    "user" : {
      "name" : "H5P",
      "screen_name" : "H5PTechnology",
      "protected" : false,
      "id_str" : "2216405440",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453821604435210240\/MsPMRMXu_normal.jpeg",
      "id" : 2216405440,
      "verified" : false
    }
  },
  "id" : 753652932864684032,
  "created_at" : "2016-07-14 18:10:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "indices" : [ 3, 17 ],
      "id_str" : "3296136369",
      "id" : 3296136369
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RocketChatApp\/status\/753646557778575360\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/22y2DR35Jl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnV9jFLWYAAEZjp.jpg",
      "id_str" : "753646554293100544",
      "id" : 753646554293100544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnV9jFLWYAAEZjp.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 319,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/22y2DR35Jl"
    } ],
    "hashtags" : [ {
      "text" : "rocketfund",
      "indices" : [ 58, 69 ]
    }, {
      "text" : "opensource",
      "indices" : [ 70, 81 ]
    }, {
      "text" : "crowdfunding",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753648362340036608",
  "text" : "RT @RocketChatApp: We\u2019ve got something big in the works \u2026 #rocketfund #opensource #crowdfunding https:\/\/t.co\/22y2DR35Jl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RocketChatApp\/status\/753646557778575360\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/22y2DR35Jl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnV9jFLWYAAEZjp.jpg",
        "id_str" : "753646554293100544",
        "id" : 753646554293100544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnV9jFLWYAAEZjp.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 319,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/22y2DR35Jl"
      } ],
      "hashtags" : [ {
        "text" : "rocketfund",
        "indices" : [ 39, 50 ]
      }, {
        "text" : "opensource",
        "indices" : [ 51, 62 ]
      }, {
        "text" : "crowdfunding",
        "indices" : [ 63, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753646557778575360",
    "text" : "We\u2019ve got something big in the works \u2026 #rocketfund #opensource #crowdfunding https:\/\/t.co\/22y2DR35Jl",
    "id" : 753646557778575360,
    "created_at" : "2016-07-14 17:45:16 +0000",
    "user" : {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "protected" : false,
      "id_str" : "3296136369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/633362741735096320\/tCSKtjoq_normal.png",
      "id" : 3296136369,
      "verified" : false
    }
  },
  "id" : 753648362340036608,
  "created_at" : "2016-07-14 17:52:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    }, {
      "name" : "Canvas LMS",
      "screen_name" : "CanvasLMS",
      "indices" : [ 38, 48 ],
      "id_str" : "41847236",
      "id" : 41847236
    }, {
      "name" : "Stan Wendt",
      "screen_name" : "stanwendt",
      "indices" : [ 54, 64 ],
      "id_str" : "52510472",
      "id" : 52510472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/MZ8wDi74ty",
      "expanded_url" : "http:\/\/bit.ly\/29RvZQ3",
      "display_url" : "bit.ly\/29RvZQ3"
    } ]
  },
  "geo" : { },
  "id_str" : "753633874568093700",
  "text" : "RT @clintlalonde: Free EdTech Demo of @CanvasLMS with @stanwendt starting at 10am PST in BlueJeans https:\/\/t.co\/MZ8wDi74ty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Canvas LMS",
        "screen_name" : "CanvasLMS",
        "indices" : [ 20, 30 ],
        "id_str" : "41847236",
        "id" : 41847236
      }, {
        "name" : "Stan Wendt",
        "screen_name" : "stanwendt",
        "indices" : [ 36, 46 ],
        "id_str" : "52510472",
        "id" : 52510472
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/MZ8wDi74ty",
        "expanded_url" : "http:\/\/bit.ly\/29RvZQ3",
        "display_url" : "bit.ly\/29RvZQ3"
      } ]
    },
    "geo" : { },
    "id_str" : "753633211683516416",
    "text" : "Free EdTech Demo of @CanvasLMS with @stanwendt starting at 10am PST in BlueJeans https:\/\/t.co\/MZ8wDi74ty",
    "id" : 753633211683516416,
    "created_at" : "2016-07-14 16:52:14 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 753633874568093700,
  "created_at" : "2016-07-14 16:54:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Porter",
      "screen_name" : "dendroglyph",
      "indices" : [ 0, 12 ],
      "id_str" : "15170764",
      "id" : 15170764
    }, {
      "name" : "eCampusOntario",
      "screen_name" : "eCampusOntario",
      "indices" : [ 13, 28 ],
      "id_str" : "3429881050",
      "id" : 3429881050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753586697770721280",
  "geo" : { },
  "id_str" : "753616440175976448",
  "in_reply_to_user_id" : 15170764,
  "text" : "@dendroglyph @eCampusOntario Great to see this news David, congratulations!",
  "id" : 753616440175976448,
  "in_reply_to_status_id" : 753586697770721280,
  "created_at" : "2016-07-14 15:45:35 +0000",
  "in_reply_to_screen_name" : "dendroglyph",
  "in_reply_to_user_id_str" : "15170764",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "H5P",
      "screen_name" : "H5PTechnology",
      "indices" : [ 32, 46 ],
      "id_str" : "2216405440",
      "id" : 2216405440
    }, {
      "name" : "Learning Locker",
      "screen_name" : "Learning_Locker",
      "indices" : [ 57, 73 ],
      "id_str" : "1453739006",
      "id" : 1453739006
    }, {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 76, 83 ],
      "id_str" : "236846178",
      "id" : 236846178
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drupal",
      "indices" : [ 22, 29 ]
    }, {
      "text" : "xAPI",
      "indices" : [ 49, 54 ]
    }, {
      "text" : "ngdle",
      "indices" : [ 86, 92 ]
    }, {
      "text" : "learninganalytics",
      "indices" : [ 94, 112 ]
    }, {
      "text" : "edtech",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/VStRCt2XZY",
      "expanded_url" : "https:\/\/drupal.psu.edu\/blog\/post\/drupal-xapi-h5p-track-user-feedback",
      "display_url" : "drupal.psu.edu\/blog\/post\/drup\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753318846149169152",
  "text" : "RT @btopro: New post: #drupal + @H5PTechnology + #xAPI + @Learning_Locker + @elmsln = #ngdle. #learninganalytics https:\/\/t.co\/VStRCt2XZY #e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "H5P",
        "screen_name" : "H5PTechnology",
        "indices" : [ 20, 34 ],
        "id_str" : "2216405440",
        "id" : 2216405440
      }, {
        "name" : "Learning Locker",
        "screen_name" : "Learning_Locker",
        "indices" : [ 45, 61 ],
        "id_str" : "1453739006",
        "id" : 1453739006
      }, {
        "name" : "ELMS:LN",
        "screen_name" : "elmsln",
        "indices" : [ 64, 71 ],
        "id_str" : "236846178",
        "id" : 236846178
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drupal",
        "indices" : [ 10, 17 ]
      }, {
        "text" : "xAPI",
        "indices" : [ 37, 42 ]
      }, {
        "text" : "ngdle",
        "indices" : [ 74, 80 ]
      }, {
        "text" : "learninganalytics",
        "indices" : [ 82, 100 ]
      }, {
        "text" : "edtech",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/VStRCt2XZY",
        "expanded_url" : "https:\/\/drupal.psu.edu\/blog\/post\/drupal-xapi-h5p-track-user-feedback",
        "display_url" : "drupal.psu.edu\/blog\/post\/drup\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752595533663916032",
    "text" : "New post: #drupal + @H5PTechnology + #xAPI + @Learning_Locker + @elmsln = #ngdle. #learninganalytics https:\/\/t.co\/VStRCt2XZY #edtech",
    "id" : 752595533663916032,
    "created_at" : "2016-07-11 20:08:52 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 753318846149169152,
  "created_at" : "2016-07-13 20:03:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
      "screen_name" : "Bali_Maha",
      "indices" : [ 3, 13 ],
      "id_str" : "1535273520",
      "id" : 1535273520
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 29, 43 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DigPed",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Ovb47tk6qx",
      "expanded_url" : "http:\/\/livestream.com\/accounts\/7623967\/events\/5814387",
      "display_url" : "livestream.com\/accounts\/76239\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753298627850739712",
  "text" : "RT @Bali_Maha: Livestream of @audreywatters keynote from #DigPed PEI will be here https:\/\/t.co\/Ovb47tk6qx starts... soon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 14, 28 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DigPed",
        "indices" : [ 42, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/Ovb47tk6qx",
        "expanded_url" : "http:\/\/livestream.com\/accounts\/7623967\/events\/5814387",
        "display_url" : "livestream.com\/accounts\/76239\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753280907252002816",
    "text" : "Livestream of @audreywatters keynote from #DigPed PEI will be here https:\/\/t.co\/Ovb47tk6qx starts... soon",
    "id" : 753280907252002816,
    "created_at" : "2016-07-13 17:32:18 +0000",
    "user" : {
      "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
      "screen_name" : "Bali_Maha",
      "protected" : false,
      "id_str" : "1535273520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523419361185234944\/kWBLJiqq_normal.jpeg",
      "id" : 1535273520,
      "verified" : false
    }
  },
  "id" : 753298627850739712,
  "created_at" : "2016-07-13 18:42:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/yJwV2c454D",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-163\/",
      "display_url" : "paulhibbitts.net\/cmpt-363-163\/"
    } ]
  },
  "in_reply_to_status_id_str" : "753270851651284992",
  "geo" : { },
  "id_str" : "753271810645454849",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc You bet\uD83D\uDE42  I've been 'eating my own dogfood' too and just finished my own course site for Fall at SFU https:\/\/t.co\/yJwV2c454D",
  "id" : 753271810645454849,
  "in_reply_to_status_id" : 753270851651284992,
  "created_at" : "2016-07-13 16:56:09 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753270182441734145",
  "geo" : { },
  "id_str" : "753271206808281088",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Let me know if I can be of help. I released an update to the Course Hub themes as well, \"Check for Updates\" in Admin Panel.",
  "id" : 753271206808281088,
  "in_reply_to_status_id" : 753270182441734145,
  "created_at" : "2016-07-13 16:53:45 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753267093932535808",
  "geo" : { },
  "id_str" : "753270033963446273",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Happy Birthday Christina! \uD83C\uDF82",
  "id" : 753270033963446273,
  "in_reply_to_status_id" : 753267093932535808,
  "created_at" : "2016-07-13 16:49:05 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UX Magazine",
      "screen_name" : "uxmag",
      "indices" : [ 3, 9 ],
      "id_str" : "15056788",
      "id" : 15056788
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "designers",
      "indices" : [ 17, 27 ]
    }, {
      "text" : "UX",
      "indices" : [ 132, 135 ]
    }, {
      "text" : "UXEducation",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/b0TbWCoiO2",
      "expanded_url" : "http:\/\/uxm.ag\/2ma",
      "display_url" : "uxm.ag\/2ma"
    } ]
  },
  "geo" : { },
  "id_str" : "753251354248933377",
  "text" : "RT @uxmag: Great #designers justify every decision they make along the way to getting to the final product. https:\/\/t.co\/b0TbWCoiO2 #UX #UX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "designers",
        "indices" : [ 6, 16 ]
      }, {
        "text" : "UX",
        "indices" : [ 121, 124 ]
      }, {
        "text" : "UXEducation",
        "indices" : [ 125, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/b0TbWCoiO2",
        "expanded_url" : "http:\/\/uxm.ag\/2ma",
        "display_url" : "uxm.ag\/2ma"
      } ]
    },
    "geo" : { },
    "id_str" : "753235105490100224",
    "text" : "Great #designers justify every decision they make along the way to getting to the final product. https:\/\/t.co\/b0TbWCoiO2 #UX #UXEducation",
    "id" : 753235105490100224,
    "created_at" : "2016-07-13 14:30:18 +0000",
    "user" : {
      "name" : "UX Magazine",
      "screen_name" : "uxmag",
      "protected" : false,
      "id_str" : "15056788",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227292956\/twitter_logo_normal.png",
      "id" : 15056788,
      "verified" : false
    }
  },
  "id" : 753251354248933377,
  "created_at" : "2016-07-13 15:34:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 3, 10 ],
      "id_str" : "236846178",
      "id" : 236846178
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 25, 32 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Michael Potter",
      "screen_name" : "hey__MP",
      "indices" : [ 35, 43 ],
      "id_str" : "1448965550",
      "id" : 1448965550
    }, {
      "name" : "Lullabot",
      "screen_name" : "lullabot",
      "indices" : [ 59, 68 ],
      "id_str" : "2731801",
      "id" : 2731801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elmsln",
      "indices" : [ 95, 102 ]
    }, {
      "text" : "drupal",
      "indices" : [ 103, 110 ]
    }, {
      "text" : "edtech",
      "indices" : [ 111, 118 ]
    }, {
      "text" : "ngdle",
      "indices" : [ 119, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753078117586141184",
  "text" : "RT @elmsln: Core members @btopro \/ @hey__mp will be on the @lullabot podcast Wednesday to talk #elmsln #drupal #edtech #ngdle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bryan Ollendyke",
        "screen_name" : "btopro",
        "indices" : [ 13, 20 ],
        "id_str" : "16847370",
        "id" : 16847370
      }, {
        "name" : "Michael Potter",
        "screen_name" : "hey__MP",
        "indices" : [ 23, 31 ],
        "id_str" : "1448965550",
        "id" : 1448965550
      }, {
        "name" : "Lullabot",
        "screen_name" : "lullabot",
        "indices" : [ 47, 56 ],
        "id_str" : "2731801",
        "id" : 2731801
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elmsln",
        "indices" : [ 83, 90 ]
      }, {
        "text" : "drupal",
        "indices" : [ 91, 98 ]
      }, {
        "text" : "edtech",
        "indices" : [ 99, 106 ]
      }, {
        "text" : "ngdle",
        "indices" : [ 107, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753072890891767809",
    "text" : "Core members @btopro \/ @hey__mp will be on the @lullabot podcast Wednesday to talk #elmsln #drupal #edtech #ngdle",
    "id" : 753072890891767809,
    "created_at" : "2016-07-13 03:45:43 +0000",
    "user" : {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "protected" : false,
      "id_str" : "236846178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601925668025278465\/4j0l2bWZ_normal.png",
      "id" : 236846178,
      "verified" : false
    }
  },
  "id" : 753078117586141184,
  "created_at" : "2016-07-13 04:06:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/753063003407343616\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/3H2Zm8a8Pt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnNqocQUAAE1ArB.jpg",
      "id_str" : "753062805712928769",
      "id" : 753062805712928769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnNqocQUAAE1ArB.jpg",
      "sizes" : [ {
        "h" : 248,
        "resize" : "fit",
        "w" : 370
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 370
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 370
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 370
      } ],
      "display_url" : "pic.twitter.com\/3H2Zm8a8Pt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/YIBNjnlrmj",
      "expanded_url" : "http:\/\/arstechnica.com\/apple\/2016\/07\/apple-swift-playgrounds-not-hypercard\/",
      "display_url" : "arstechnica.com\/apple\/2016\/07\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753063003407343616",
  "text" : "Apple\u2019s Swift Playgrounds can help you learn to code, but it\u2019s no HyperCard https:\/\/t.co\/YIBNjnlrmj Takes me back... https:\/\/t.co\/3H2Zm8a8Pt",
  "id" : 753063003407343616,
  "created_at" : "2016-07-13 03:06:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George",
      "screen_name" : "georgekroner",
      "indices" : [ 3, 16 ],
      "id_str" : "9128102",
      "id" : 9128102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/n7G6Ts4W57",
      "expanded_url" : "https:\/\/www.insidehighered.com\/blogs\/technology-and-learning\/why-higher-ed-must-resist-",
      "display_url" : "insidehighered.com\/blogs\/technolo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753056029030518784",
  "text" : "RT @georgekroner: \"Learning is best accomplished in the context of a human relationship btw educator &amp; student\" https:\/\/t.co\/n7G6Ts4W57\u2018pla\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/n7G6Ts4W57",
        "expanded_url" : "https:\/\/www.insidehighered.com\/blogs\/technology-and-learning\/why-higher-ed-must-resist-",
        "display_url" : "insidehighered.com\/blogs\/technolo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753049836514004992",
    "text" : "\"Learning is best accomplished in the context of a human relationship btw educator &amp; student\" https:\/\/t.co\/n7G6Ts4W57\u2018platform-revolution\u2019",
    "id" : 753049836514004992,
    "created_at" : "2016-07-13 02:14:06 +0000",
    "user" : {
      "name" : "George",
      "screen_name" : "georgekroner",
      "protected" : false,
      "id_str" : "9128102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/470252277425385472\/NVdbYHMk_normal.png",
      "id" : 9128102,
      "verified" : false
    }
  },
  "id" : 753056029030518784,
  "created_at" : "2016-07-13 02:38:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Jarche",
      "screen_name" : "hjarche",
      "indices" : [ 3, 11 ],
      "id_str" : "11698322",
      "id" : 11698322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/THEquLCBpz",
      "expanded_url" : "https:\/\/www.theguardian.com\/media\/2016\/jul\/12\/how-technology-disrupted-the-truth",
      "display_url" : "theguardian.com\/media\/2016\/jul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753021989032427525",
  "text" : "RT @hjarche: Does the truth matter any more? https:\/\/t.co\/THEquLCBpz \"the era of post-truth politics\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/THEquLCBpz",
        "expanded_url" : "https:\/\/www.theguardian.com\/media\/2016\/jul\/12\/how-technology-disrupted-the-truth",
        "display_url" : "theguardian.com\/media\/2016\/jul\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753020281451446273",
    "text" : "Does the truth matter any more? https:\/\/t.co\/THEquLCBpz \"the era of post-truth politics\"",
    "id" : 753020281451446273,
    "created_at" : "2016-07-13 00:16:40 +0000",
    "user" : {
      "name" : "Harold Jarche",
      "screen_name" : "hjarche",
      "protected" : false,
      "id_str" : "11698322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608362206468710401\/aLkYjv31_normal.png",
      "id" : 11698322,
      "verified" : false
    }
  },
  "id" : 753021989032427525,
  "created_at" : "2016-07-13 00:23:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "indices" : [ 38, 52 ],
      "id_str" : "3296136369",
      "id" : 3296136369
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 121, 136 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 24, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/KWAeUOKVA5",
      "expanded_url" : "http:\/\/oet.sandcats.io",
      "display_url" : "oet.sandcats.io"
    } ]
  },
  "geo" : { },
  "id_str" : "753003418667581448",
  "text" : "Fully FIPPA-friendly:\n\u2705 #SFU GitLab\n\u2705 @RocketChatApp (\uD83C\uDDE8\uD83C\uDDE6  server)\n\u2705 https:\/\/t.co\/KWAeUOKVA5 Survey Form\nand can even use @ReclaimHosting FTW",
  "id" : 753003418667581448,
  "created_at" : "2016-07-12 23:09:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/752992637104324608\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/s3LAA7FOWF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnMo3ERUsAE217t.jpg",
      "id_str" : "752990489205321729",
      "id" : 752990489205321729,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnMo3ERUsAE217t.jpg",
      "sizes" : [ {
        "h" : 86,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 86,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 86,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 86,
        "resize" : "crop",
        "w" : 86
      }, {
        "h" : 86,
        "resize" : "fit",
        "w" : 474
      } ],
      "display_url" : "pic.twitter.com\/s3LAA7FOWF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752992637104324608",
  "text" : "Reading about the history of ARM... exactly my approach to developing the Grav Course Hub \u27A4 Min code for Max benefit https:\/\/t.co\/s3LAA7FOWF",
  "id" : 752992637104324608,
  "created_at" : "2016-07-12 22:26:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rajiv Jhangiani",
      "screen_name" : "thatpsychprof",
      "indices" : [ 3, 17 ],
      "id_str" : "39835900",
      "id" : 39835900
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 72, 76 ]
    }, {
      "text" : "opentextbooks",
      "indices" : [ 77, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/kmhO2FKu8w",
      "expanded_url" : "https:\/\/open.bccampus.ca\/2016\/07\/11\/calling-bc-oer-advocates\/",
      "display_url" : "open.bccampus.ca\/2016\/07\/11\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752972819684741120",
  "text" : "RT @thatpsychprof: Attn: BC post-secondary faculty: share your exp with #OER #opentextbooks https:\/\/t.co\/kmhO2FKu8w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OER",
        "indices" : [ 53, 57 ]
      }, {
        "text" : "opentextbooks",
        "indices" : [ 58, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/kmhO2FKu8w",
        "expanded_url" : "https:\/\/open.bccampus.ca\/2016\/07\/11\/calling-bc-oer-advocates\/",
        "display_url" : "open.bccampus.ca\/2016\/07\/11\/cal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752970892901167104",
    "text" : "Attn: BC post-secondary faculty: share your exp with #OER #opentextbooks https:\/\/t.co\/kmhO2FKu8w",
    "id" : 752970892901167104,
    "created_at" : "2016-07-12 21:00:25 +0000",
    "user" : {
      "name" : "Rajiv Jhangiani",
      "screen_name" : "thatpsychprof",
      "protected" : false,
      "id_str" : "39835900",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677017328740122624\/zdAKRH0L_normal.jpg",
      "id" : 39835900,
      "verified" : false
    }
  },
  "id" : 752972819684741120,
  "created_at" : "2016-07-12 21:08:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 62, 70 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/KE7mQCTGxn",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-07-11-a-few-thoughts-about-who-the-grav-course-hub-is-designed-for",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752926729014882305",
  "text" : "In case you missed it yesterday: A Few Thoughts About Who the @getgrav Course Hub is Designed For https:\/\/t.co\/KE7mQCTGxn",
  "id" : 752926729014882305,
  "created_at" : "2016-07-12 18:04:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InVision",
      "screen_name" : "InVisionApp",
      "indices" : [ 3, 15 ],
      "id_str" : "256093789",
      "id" : 256093789
    }, {
      "name" : "Jennifer Aldrich",
      "screen_name" : "jma245",
      "indices" : [ 110, 117 ],
      "id_str" : "32696488",
      "id" : 32696488
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/InVisionApp\/status\/752895497191428097\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/UBMKny6Lyk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnLSdf0WgAAAAUc.jpg",
      "id_str" : "752895491923410944",
      "id" : 752895491923410944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnLSdf0WgAAAAUc.jpg",
      "sizes" : [ {
        "h" : 403,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1214,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2170,
        "resize" : "fit",
        "w" : 3660
      }, {
        "h" : 711,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/UBMKny6Lyk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/9KArzNB0ku",
      "expanded_url" : "http:\/\/invs.io\/29A4B7j",
      "display_url" : "invs.io\/29A4B7j"
    } ]
  },
  "geo" : { },
  "id_str" : "752903864328695810",
  "text" : "RT @InVisionApp: \u201CDon\u2019t just give clients what they ask for\u2014solve their problems.\u201D https:\/\/t.co\/9KArzNB0ku by @jma245 https:\/\/t.co\/UBMKny6L\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jennifer Aldrich",
        "screen_name" : "jma245",
        "indices" : [ 93, 100 ],
        "id_str" : "32696488",
        "id" : 32696488
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/InVisionApp\/status\/752895497191428097\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/UBMKny6Lyk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnLSdf0WgAAAAUc.jpg",
        "id_str" : "752895491923410944",
        "id" : 752895491923410944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnLSdf0WgAAAAUc.jpg",
        "sizes" : [ {
          "h" : 403,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1214,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2170,
          "resize" : "fit",
          "w" : 3660
        }, {
          "h" : 711,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/UBMKny6Lyk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/9KArzNB0ku",
        "expanded_url" : "http:\/\/invs.io\/29A4B7j",
        "display_url" : "invs.io\/29A4B7j"
      } ]
    },
    "geo" : { },
    "id_str" : "752895497191428097",
    "text" : "\u201CDon\u2019t just give clients what they ask for\u2014solve their problems.\u201D https:\/\/t.co\/9KArzNB0ku by @jma245 https:\/\/t.co\/UBMKny6Lyk",
    "id" : 752895497191428097,
    "created_at" : "2016-07-12 16:00:49 +0000",
    "user" : {
      "name" : "InVision",
      "screen_name" : "InVisionApp",
      "protected" : false,
      "id_str" : "256093789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593893225045200896\/r9uL4jWU_normal.png",
      "id" : 256093789,
      "verified" : false
    }
  },
  "id" : 752903864328695810,
  "created_at" : "2016-07-12 16:34:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Bashaw",
      "screen_name" : "nbashaw",
      "indices" : [ 65, 73 ],
      "id_str" : "17424947",
      "id" : 17424947
    }, {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "indices" : [ 77, 89 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/eIuNzNLOsA",
      "expanded_url" : "https:\/\/www.producthunt.com\/tech\/hummingbird-by-olark",
      "display_url" : "producthunt.com\/tech\/hummingbi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752899110655537152",
  "text" : "Hummingbird by Olark: A mobile-friendly live chat experience via @nbashaw on @ProductHunt https:\/\/t.co\/eIuNzNLOsA Really nice improvements \uD83D\uDC4D",
  "id" : 752899110655537152,
  "created_at" : "2016-07-12 16:15:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/neS5EnTcAc",
      "expanded_url" : "https:\/\/getgrav.org\/blog\/cms-critic-award-nominations-2016",
      "display_url" : "getgrav.org\/blog\/cms-criti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752634784929632257",
  "text" : "RT @getgrav: Please nominate Grav for \"Best [Free, Open Source, and Education] CMS\" in the 2016 CMS Critics Award Nominations - https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/neS5EnTcAc",
        "expanded_url" : "https:\/\/getgrav.org\/blog\/cms-critic-award-nominations-2016",
        "display_url" : "getgrav.org\/blog\/cms-criti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752631934438649857",
    "text" : "Please nominate Grav for \"Best [Free, Open Source, and Education] CMS\" in the 2016 CMS Critics Award Nominations - https:\/\/t.co\/neS5EnTcAc",
    "id" : 752631934438649857,
    "created_at" : "2016-07-11 22:33:31 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 752634784929632257,
  "created_at" : "2016-07-11 22:44:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    }, {
      "name" : "Rajiv Jhangiani",
      "screen_name" : "thatpsychprof",
      "indices" : [ 64, 78 ],
      "id_str" : "39835900",
      "id" : 39835900
    }, {
      "name" : "Dani Paradis",
      "screen_name" : "DaniParadis",
      "indices" : [ 85, 97 ],
      "id_str" : "31343866",
      "id" : 31343866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 58, 62 ]
    }, {
      "text" : "bcoetc",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 144 ],
      "url" : "https:\/\/t.co\/MyXSZsDehI",
      "expanded_url" : "http:\/\/bit.ly\/29tSBlQ",
      "display_url" : "bit.ly\/29tSBlQ"
    } ]
  },
  "geo" : { },
  "id_str" : "752623702697648128",
  "text" : "RT @clintlalonde: Are you an educator who has worked with #OER? @thatpsychprof &amp; @DaniParadis would love to speak with you https:\/\/t.co\/MyX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rajiv Jhangiani",
        "screen_name" : "thatpsychprof",
        "indices" : [ 46, 60 ],
        "id_str" : "39835900",
        "id" : 39835900
      }, {
        "name" : "Dani Paradis",
        "screen_name" : "DaniParadis",
        "indices" : [ 67, 79 ],
        "id_str" : "31343866",
        "id" : 31343866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OER",
        "indices" : [ 40, 44 ]
      }, {
        "text" : "bcoetc",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/MyXSZsDehI",
        "expanded_url" : "http:\/\/bit.ly\/29tSBlQ",
        "display_url" : "bit.ly\/29tSBlQ"
      } ]
    },
    "geo" : { },
    "id_str" : "752621452675784704",
    "text" : "Are you an educator who has worked with #OER? @thatpsychprof &amp; @DaniParadis would love to speak with you https:\/\/t.co\/MyXSZsDehI #bcoetc",
    "id" : 752621452675784704,
    "created_at" : "2016-07-11 21:51:52 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 752623702697648128,
  "created_at" : "2016-07-11 22:00:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/clzE1Sh0DJ",
      "expanded_url" : "http:\/\/www.uxforthemasses.com\/great-ux-ideas\/",
      "display_url" : "uxforthemasses.com\/great-ux-ideas\/"
    } ]
  },
  "geo" : { },
  "id_str" : "752621678820151296",
  "text" : "How to come up with great UX ideas https:\/\/t.co\/clzE1Sh0DJ",
  "id" : 752621678820151296,
  "created_at" : "2016-07-11 21:52:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 65, 73 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752615428552204288",
  "text" : "The Grav Course Hub enables tech-savvy educators to use the open @getgrav platform along with the LMS to reach unmet pedagogical &amp; UX goals.",
  "id" : 752615428552204288,
  "created_at" : "2016-07-11 21:27:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752615349619552257",
  "text" : "Ok, so creating a problem statement of your product with 140 characters is pretty tricky but a worthy exercise. Here's what I've got so far:",
  "id" : 752615349619552257,
  "created_at" : "2016-07-11 21:27:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 91, 99 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/VuG3m4D7q1",
      "expanded_url" : "https:\/\/twitter.com\/4goggas\/status\/752602843580919808",
      "display_url" : "twitter.com\/4goggas\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752607326624821248",
  "text" : "#GravEdu is the hashtag for tweets about the use of the modern flat-file (no-database) CMS @getgrav in Higher Ed. https:\/\/t.co\/VuG3m4D7q1",
  "id" : 752607326624821248,
  "created_at" : "2016-07-11 20:55:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "D2L",
      "indices" : [ 95, 99 ]
    }, {
      "text" : "Blackboard",
      "indices" : [ 100, 111 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 112, 122 ]
    }, {
      "text" : "Moodle",
      "indices" : [ 123, 130 ]
    }, {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/KE7mQCTGxn",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-07-11-a-few-thoughts-about-who-the-grav-course-hub-is-designed-for",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752601103020068864",
  "text" : "New Post: A Few Thoughts About Who the Grav Course Hub is Designed For https:\/\/t.co\/KE7mQCTGxn #D2L #Blackboard #CanvasLMS #Moodle #GravEdu",
  "id" : 752601103020068864,
  "created_at" : "2016-07-11 20:31:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/qTgCdG6ZPM",
      "expanded_url" : "http:\/\/demo.hibbittsdesign.org\/grav-course-hub\/",
      "display_url" : "demo.hibbittsdesign.org\/grav-course-hu\u2026"
    }, {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/L4vgd29InC",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752556633377517569",
  "text" : "(10\/10) Explore a demo of the Grav Course Hub at https:\/\/t.co\/qTgCdG6ZPM and read the Getting Started Guide https:\/\/t.co\/L4vgd29InC\n#GravEdu",
  "id" : 752556633377517569,
  "created_at" : "2016-07-11 17:34:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752556584950128640",
  "text" : "(9\/10) For educators who want a better multi-device user experience for their students and themselves.\n#GravEdu",
  "id" : 752556584950128640,
  "created_at" : "2016-07-11 17:34:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752556549944467456",
  "text" : "(8\/10) For educators who want to reuse content in different contexts of the same course, and also between multiple related courses.\n#GravEdu",
  "id" : 752556549944467456,
  "created_at" : "2016-07-11 17:33:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752556492222377984",
  "text" : "(7\/10) For educators who want students to actively shape their shared online environment.\n#GravEdu",
  "id" : 752556492222377984,
  "created_at" : "2016-07-11 17:33:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752556452938592257",
  "text" : "(6\/10) For educators who want to have more control of the online environment for their students and themselves.\n#GravEdu",
  "id" : 752556452938592257,
  "created_at" : "2016-07-11 17:33:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752556422919909381",
  "text" : "(5\/10) For educators who want to provide access to their course and materials beyond the scope of term start and end dates.\n#GravEdu",
  "id" : 752556422919909381,
  "created_at" : "2016-07-11 17:33:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752556391395495936",
  "text" : "(4\/10) For educators who want to provide their course and materials in the open but still keep sensitive student data in the LMS.\n#GravEdu",
  "id" : 752556391395495936,
  "created_at" : "2016-07-11 17:33:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752556349808996352",
  "text" : "(3\/10) For educators who have unmet pedagogical goals due to the constraints of their LMS.\n#GravEdu",
  "id" : 752556349808996352,
  "created_at" : "2016-07-11 17:33:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 11, 19 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752556316887883776",
  "text" : "(2\/10) The @getgrav Course Hub is designed for moderately tech-savvy educators with the following needs:\n#GravEdu",
  "id" : 752556316887883776,
  "created_at" : "2016-07-11 17:33:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752556260239613952",
  "text" : "(1\/10) So, just who is the open source Grav Course Hub designed for anyway?\n#GravEdu",
  "id" : 752556260239613952,
  "created_at" : "2016-07-11 17:32:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 61, 69 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/vL9lZ9GMg2",
      "expanded_url" : "https:\/\/twitter.com\/drchuck\/status\/752508287296294913",
      "display_url" : "twitter.com\/drchuck\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752519654145306624",
  "text" : "\"Learning is a human thing.\" Nicely stated and demonstrated, @drchuck. https:\/\/t.co\/vL9lZ9GMg2",
  "id" : 752519654145306624,
  "created_at" : "2016-07-11 15:07:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UX Mastery",
      "screen_name" : "uxmastery",
      "indices" : [ 3, 13 ],
      "id_str" : "631741925",
      "id" : 631741925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 56, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/b2oRca7juR",
      "expanded_url" : "http:\/\/community.uxmastery.com\/t\/how-shall-we-crowdsource-the-masters-of-ux-reading-list\/1358",
      "display_url" : "community.uxmastery.com\/t\/how-shall-we\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752307171547750400",
  "text" : "RT @uxmastery: How shall we crowdsource the \"Masters of #UX\" reading list? https:\/\/t.co\/b2oRca7juR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 41, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/b2oRca7juR",
        "expanded_url" : "http:\/\/community.uxmastery.com\/t\/how-shall-we-crowdsource-the-masters-of-ux-reading-list\/1358",
        "display_url" : "community.uxmastery.com\/t\/how-shall-we\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752306623666880513",
    "text" : "How shall we crowdsource the \"Masters of #UX\" reading list? https:\/\/t.co\/b2oRca7juR",
    "id" : 752306623666880513,
    "created_at" : "2016-07-11 01:00:50 +0000",
    "user" : {
      "name" : "UX Mastery",
      "screen_name" : "uxmastery",
      "protected" : false,
      "id_str" : "631741925",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724856215910625285\/yKvLknw6_normal.jpg",
      "id" : 631741925,
      "verified" : false
    }
  },
  "id" : 752307171547750400,
  "created_at" : "2016-07-11 01:03:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 3, 13 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/keroleenl\/status\/748686651975610368\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/VZkH9rEGJ8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmPeha9VMAAHVq2.jpg",
      "id_str" : "748686628827246592",
      "id" : 748686628827246592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmPeha9VMAAHVq2.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 464
      }, {
        "h" : 3300,
        "resize" : "fit",
        "w" : 1275
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 791
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 263
      } ],
      "display_url" : "pic.twitter.com\/VZkH9rEGJ8"
    } ],
    "hashtags" : [ {
      "text" : "UDL",
      "indices" : [ 32, 36 ]
    }, {
      "text" : "edmedia",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751843085420638208",
  "text" : "RT @keroleenl: Infographic of 9 #UDL principles from my presentation #edmedia https:\/\/t.co\/VZkH9rEGJ8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/keroleenl\/status\/748686651975610368\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/VZkH9rEGJ8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmPeha9VMAAHVq2.jpg",
        "id_str" : "748686628827246592",
        "id" : 748686628827246592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmPeha9VMAAHVq2.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 464
        }, {
          "h" : 3300,
          "resize" : "fit",
          "w" : 1275
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 791
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 263
        } ],
        "display_url" : "pic.twitter.com\/VZkH9rEGJ8"
      } ],
      "hashtags" : [ {
        "text" : "UDL",
        "indices" : [ 17, 21 ]
      }, {
        "text" : "edmedia",
        "indices" : [ 54, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748686651975610368",
    "text" : "Infographic of 9 #UDL principles from my presentation #edmedia https:\/\/t.co\/VZkH9rEGJ8",
    "id" : 748686651975610368,
    "created_at" : "2016-07-01 01:16:22 +0000",
    "user" : {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "protected" : false,
      "id_str" : "887742962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515581656686546944\/Q76DpwVe_normal.png",
      "id" : 887742962,
      "verified" : false
    }
  },
  "id" : 751843085420638208,
  "created_at" : "2016-07-09 18:18:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Delaney",
      "screen_name" : "delaney",
      "indices" : [ 3, 11 ],
      "id_str" : "21687414",
      "id" : 21687414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/7ZjqNasHGs",
      "expanded_url" : "http:\/\/qz.com\/726338",
      "display_url" : "qz.com\/726338"
    } ]
  },
  "geo" : { },
  "id_str" : "751838523649503232",
  "text" : "RT @delaney: The code that took America to the moon was just published to GitHub, and it\u2019s like a 1960s time capsule https:\/\/t.co\/7ZjqNasHGs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/7ZjqNasHGs",
        "expanded_url" : "http:\/\/qz.com\/726338",
        "display_url" : "qz.com\/726338"
      } ]
    },
    "geo" : { },
    "id_str" : "751806297335562240",
    "text" : "The code that took America to the moon was just published to GitHub, and it\u2019s like a 1960s time capsule https:\/\/t.co\/7ZjqNasHGs",
    "id" : 751806297335562240,
    "created_at" : "2016-07-09 15:52:43 +0000",
    "user" : {
      "name" : "Kevin Delaney",
      "screen_name" : "delaney",
      "protected" : false,
      "id_str" : "21687414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2646875844\/e4bc184cd920143889f09b7fa6eb4d63_normal.png",
      "id" : 21687414,
      "verified" : true
    }
  },
  "id" : 751838523649503232,
  "created_at" : "2016-07-09 18:00:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/751571834198298624\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/nJz6Sbcvbf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm4eIalVMAABJ7P.jpg",
      "id_str" : "751571317741137920",
      "id" : 751571317741137920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm4eIalVMAABJ7P.jpg",
      "sizes" : [ {
        "h" : 693,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 693,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 693,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nJz6Sbcvbf"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 25, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/yJwV2clFWb",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-163\/",
      "display_url" : "paulhibbitts.net\/cmpt-363-163\/"
    } ]
  },
  "geo" : { },
  "id_str" : "751571834198298624",
  "text" : "Exactly one spot left in #SFU CMPT 363 course right now. Course Hub preview for students at https:\/\/t.co\/yJwV2clFWb. https:\/\/t.co\/nJz6Sbcvbf",
  "id" : 751571834198298624,
  "created_at" : "2016-07-09 00:21:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 3, 15 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reactjs",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "YVR",
      "indices" : [ 125, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/yptl6O5ny3",
      "expanded_url" : "http:\/\/ow.ly\/W8Py301Wxkc",
      "display_url" : "ow.ly\/W8Py301Wxkc"
    } ]
  },
  "geo" : { },
  "id_str" : "751484707641057284",
  "text" : "RT @openroadies: We're looking for a C# \/ JavaScript developer to join our team! Apply now: https:\/\/t.co\/yptl6O5ny3 #reactjs #YVR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "reactjs",
        "indices" : [ 99, 107 ]
      }, {
        "text" : "YVR",
        "indices" : [ 108, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/yptl6O5ny3",
        "expanded_url" : "http:\/\/ow.ly\/W8Py301Wxkc",
        "display_url" : "ow.ly\/W8Py301Wxkc"
      } ]
    },
    "geo" : { },
    "id_str" : "751476372787388416",
    "text" : "We're looking for a C# \/ JavaScript developer to join our team! Apply now: https:\/\/t.co\/yptl6O5ny3 #reactjs #YVR",
    "id" : 751476372787388416,
    "created_at" : "2016-07-08 18:01:43 +0000",
    "user" : {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "protected" : false,
      "id_str" : "66913866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554783440747237376\/HA2Svg4h_normal.png",
      "id" : 66913866,
      "verified" : false
    }
  },
  "id" : 751484707641057284,
  "created_at" : "2016-07-08 18:34:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D2L",
      "screen_name" : "D2L",
      "indices" : [ 3, 7 ],
      "id_str" : "29375475",
      "id" : 29375475
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UDL",
      "indices" : [ 73, 77 ]
    }, {
      "text" : "Edchat",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/zjgdbgLqxE",
      "expanded_url" : "http:\/\/ow.ly\/3aqV3023kLV",
      "display_url" : "ow.ly\/3aqV3023kLV"
    } ]
  },
  "geo" : { },
  "id_str" : "751484572223676416",
  "text" : "RT @D2L: Universal Design for Learning is a Philosophy \u2013 Not a Practice: #UDL #Edchat https:\/\/t.co\/zjgdbgLqxE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UDL",
        "indices" : [ 64, 68 ]
      }, {
        "text" : "Edchat",
        "indices" : [ 69, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/zjgdbgLqxE",
        "expanded_url" : "http:\/\/ow.ly\/3aqV3023kLV",
        "display_url" : "ow.ly\/3aqV3023kLV"
      } ]
    },
    "geo" : { },
    "id_str" : "751477255445082113",
    "text" : "Universal Design for Learning is a Philosophy \u2013 Not a Practice: #UDL #Edchat https:\/\/t.co\/zjgdbgLqxE",
    "id" : 751477255445082113,
    "created_at" : "2016-07-08 18:05:14 +0000",
    "user" : {
      "name" : "D2L",
      "screen_name" : "D2L",
      "protected" : false,
      "id_str" : "29375475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716959107522150400\/xVJJ5Kq6_normal.jpg",
      "id" : 29375475,
      "verified" : true
    }
  },
  "id" : 751484572223676416,
  "created_at" : "2016-07-08 18:34:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lawrie Phipps",
      "screen_name" : "Lawrie",
      "indices" : [ 3, 10 ],
      "id_str" : "3250741",
      "id" : 3250741
    }, {
      "name" : "Paul Kleiman at Ciel",
      "screen_name" : "CielEducation",
      "indices" : [ 58, 72 ],
      "id_str" : "2739712677",
      "id" : 2739712677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/eXKmrDcq6E",
      "expanded_url" : "http:\/\/lawriephipps.co.uk\/?p=8143",
      "display_url" : "lawriephipps.co.uk\/?p=8143"
    } ]
  },
  "geo" : { },
  "id_str" : "751436744378028034",
  "text" : "RT @Lawrie: When the comment is better than the post :-)  @CielEducation https:\/\/t.co\/eXKmrDcq6E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Kleiman at Ciel",
        "screen_name" : "CielEducation",
        "indices" : [ 46, 60 ],
        "id_str" : "2739712677",
        "id" : 2739712677
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/eXKmrDcq6E",
        "expanded_url" : "http:\/\/lawriephipps.co.uk\/?p=8143",
        "display_url" : "lawriephipps.co.uk\/?p=8143"
      } ]
    },
    "geo" : { },
    "id_str" : "751430311007883264",
    "text" : "When the comment is better than the post :-)  @CielEducation https:\/\/t.co\/eXKmrDcq6E",
    "id" : 751430311007883264,
    "created_at" : "2016-07-08 14:58:41 +0000",
    "user" : {
      "name" : "Lawrie Phipps",
      "screen_name" : "Lawrie",
      "protected" : false,
      "id_str" : "3250741",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746446593054875648\/6vgHoGec_normal.jpg",
      "id" : 3250741,
      "verified" : false
    }
  },
  "id" : 751436744378028034,
  "created_at" : "2016-07-08 15:24:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751213944392421376",
  "geo" : { },
  "id_str" : "751237864155848709",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Sunday won't work really but I will try to take a peek once and a while on your Twitter feed \uD83D\uDE42",
  "id" : 751237864155848709,
  "in_reply_to_status_id" : 751213944392421376,
  "created_at" : "2016-07-08 02:13:58 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 8, 22 ],
      "id_str" : "41268670",
      "id" : 41268670
    }, {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 23, 30 ],
      "id_str" : "236846178",
      "id" : 236846178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751201969008578560",
  "geo" : { },
  "id_str" : "751208384989278208",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @_mike_collins @elmsln Let me know what you are thinking of \uD83D\uDE42",
  "id" : 751208384989278208,
  "in_reply_to_status_id" : 751201969008578560,
  "created_at" : "2016-07-08 00:16:50 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xeni Jardin \uD83E\uDD84",
      "screen_name" : "xeni",
      "indices" : [ 3, 8 ],
      "id_str" : "767",
      "id" : 767
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PhilandoCastile",
      "indices" : [ 31, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/ECNEM79ssZ",
      "expanded_url" : "http:\/\/boingboing.net\/2016\/07\/07\/philando-castiles-death-a-re.html",
      "display_url" : "boingboing.net\/2016\/07\/07\/phi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751207988078096384",
  "text" : "RT @xeni: What kind of man was #PhilandoCastile? He memorized names of 500 kids he served daily, with their food allergies. https:\/\/t.co\/EC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PhilandoCastile",
        "indices" : [ 21, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/ECNEM79ssZ",
        "expanded_url" : "http:\/\/boingboing.net\/2016\/07\/07\/philando-castiles-death-a-re.html",
        "display_url" : "boingboing.net\/2016\/07\/07\/phi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751162868129599488",
    "text" : "What kind of man was #PhilandoCastile? He memorized names of 500 kids he served daily, with their food allergies. https:\/\/t.co\/ECNEM79ssZ",
    "id" : 751162868129599488,
    "created_at" : "2016-07-07 21:15:58 +0000",
    "user" : {
      "name" : "Xeni Jardin \uD83E\uDD84",
      "screen_name" : "xeni",
      "protected" : false,
      "id_str" : "767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768094849681625089\/cyD_1h0K_normal.jpg",
      "id" : 767,
      "verified" : true
    }
  },
  "id" : 751207988078096384,
  "created_at" : "2016-07-08 00:15:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Source Way",
      "screen_name" : "opensourceway",
      "indices" : [ 3, 17 ],
      "id_str" : "80589255",
      "id" : 80589255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/OK8l1kxRfC",
      "expanded_url" : "http:\/\/red.ht\/29p07DX",
      "display_url" : "red.ht\/29p07DX"
    } ]
  },
  "geo" : { },
  "id_str" : "751197247862296577",
  "text" : "RT @opensourceway: What is Git, and how can you use it to maintain your files in an organized way? https:\/\/t.co\/OK8l1kxRfC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/OK8l1kxRfC",
        "expanded_url" : "http:\/\/red.ht\/29p07DX",
        "display_url" : "red.ht\/29p07DX"
      } ]
    },
    "geo" : { },
    "id_str" : "751196851802550272",
    "text" : "What is Git, and how can you use it to maintain your files in an organized way? https:\/\/t.co\/OK8l1kxRfC",
    "id" : 751196851802550272,
    "created_at" : "2016-07-07 23:31:00 +0000",
    "user" : {
      "name" : "Open Source Way",
      "screen_name" : "opensourceway",
      "protected" : false,
      "id_str" : "80589255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469124275572453376\/8fd3035c_normal.png",
      "id" : 80589255,
      "verified" : false
    }
  },
  "id" : 751197247862296577,
  "created_at" : "2016-07-07 23:32:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 8, 15 ],
      "id_str" : "236846178",
      "id" : 236846178
    }, {
      "name" : "Apereo Foundation",
      "screen_name" : "ApereoOrg",
      "indices" : [ 16, 26 ],
      "id_str" : "1117619618",
      "id" : 1117619618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751193275445317632",
  "geo" : { },
  "id_str" : "751195530810650625",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @elmsln @ApereoOrg Awesome to see this, good luck with the application!",
  "id" : 751195530810650625,
  "in_reply_to_status_id" : 751193275445317632,
  "created_at" : "2016-07-07 23:25:45 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UX Magazine",
      "screen_name" : "uxmag",
      "indices" : [ 3, 9 ],
      "id_str" : "15056788",
      "id" : 15056788
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 77, 80 ]
    }, {
      "text" : "UX",
      "indices" : [ 89, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/hv2z9JWj7u",
      "expanded_url" : "http:\/\/uxm.ag\/2m7",
      "display_url" : "uxm.ag\/2m7"
    } ]
  },
  "geo" : { },
  "id_str" : "751151761084194816",
  "text" : "RT @uxmag: Technical debt comprises two subcategories:Back-End and Front-End #UX Debt.\n5 #UX Gaps  https:\/\/t.co\/hv2z9JWj7u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 66, 69 ]
      }, {
        "text" : "UX",
        "indices" : [ 78, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/hv2z9JWj7u",
        "expanded_url" : "http:\/\/uxm.ag\/2m7",
        "display_url" : "uxm.ag\/2m7"
      } ]
    },
    "geo" : { },
    "id_str" : "751148815760105472",
    "text" : "Technical debt comprises two subcategories:Back-End and Front-End #UX Debt.\n5 #UX Gaps  https:\/\/t.co\/hv2z9JWj7u",
    "id" : 751148815760105472,
    "created_at" : "2016-07-07 20:20:08 +0000",
    "user" : {
      "name" : "UX Magazine",
      "screen_name" : "uxmag",
      "protected" : false,
      "id_str" : "15056788",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227292956\/twitter_logo_normal.png",
      "id" : 15056788,
      "verified" : false
    }
  },
  "id" : 751151761084194816,
  "created_at" : "2016-07-07 20:31:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Braden",
      "screen_name" : "andybraden",
      "indices" : [ 3, 14 ],
      "id_str" : "32505408",
      "id" : 32505408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mtmoot",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751114165050191872",
  "text" : "RT @andybraden: Listening to Dan Clark talking about (gasp) asking students what they like and what they need. #mtmoot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mtmoot",
        "indices" : [ 95, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751110467175653376",
    "text" : "Listening to Dan Clark talking about (gasp) asking students what they like and what they need. #mtmoot",
    "id" : 751110467175653376,
    "created_at" : "2016-07-07 17:47:44 +0000",
    "user" : {
      "name" : "Andy Braden",
      "screen_name" : "andybraden",
      "protected" : false,
      "id_str" : "32505408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619352728645402624\/DAQr1yWi_normal.jpg",
      "id" : 32505408,
      "verified" : false
    }
  },
  "id" : 751114165050191872,
  "created_at" : "2016-07-07 18:02:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriela K Hajduk",
      "screen_name" : "AmidstScience",
      "indices" : [ 0, 14 ],
      "id_str" : "78420357",
      "id" : 78420357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/44XXAMel40",
      "expanded_url" : "https:\/\/www.swipe.to\/home",
      "display_url" : "swipe.to\/home"
    } ]
  },
  "in_reply_to_status_id_str" : "751082143405703169",
  "geo" : { },
  "id_str" : "751083066211250176",
  "in_reply_to_user_id" : 78420357,
  "text" : "@AmidstScience I even recently found an online slide deck app that uses Markdown too! https:\/\/t.co\/44XXAMel40 Planning to use it next term.",
  "id" : 751083066211250176,
  "in_reply_to_status_id" : 751082143405703169,
  "created_at" : "2016-07-07 15:58:52 +0000",
  "in_reply_to_screen_name" : "AmidstScience",
  "in_reply_to_user_id_str" : "78420357",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriela K Hajduk",
      "screen_name" : "AmidstScience",
      "indices" : [ 0, 14 ],
      "id_str" : "78420357",
      "id" : 78420357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751082143405703169",
  "geo" : { },
  "id_str" : "751082678468816898",
  "in_reply_to_user_id" : 78420357,
  "text" : "@AmidstScience A very good point, especially with the use of Markdown content migration is usually much easier \uD83D\uDE42",
  "id" : 751082678468816898,
  "in_reply_to_status_id" : 751082143405703169,
  "created_at" : "2016-07-07 15:57:19 +0000",
  "in_reply_to_screen_name" : "AmidstScience",
  "in_reply_to_user_id_str" : "78420357",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriela K Hajduk",
      "screen_name" : "AmidstScience",
      "indices" : [ 0, 14 ],
      "id_str" : "78420357",
      "id" : 78420357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751080593195229185",
  "geo" : { },
  "id_str" : "751080906555699201",
  "in_reply_to_user_id" : 78420357,
  "text" : "@AmidstScience To host in GitHub or GitLab yes, you need a static site - which could be a great fit for you depending on your needs.",
  "id" : 751080906555699201,
  "in_reply_to_status_id" : 751080593195229185,
  "created_at" : "2016-07-07 15:50:17 +0000",
  "in_reply_to_screen_name" : "AmidstScience",
  "in_reply_to_user_id_str" : "78420357",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriela K Hajduk",
      "screen_name" : "AmidstScience",
      "indices" : [ 0, 14 ],
      "id_str" : "78420357",
      "id" : 78420357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751079938124546048",
  "geo" : { },
  "id_str" : "751080695892549632",
  "in_reply_to_user_id" : 78420357,
  "text" : "@AmidstScience For my course site I often have a lot of updates, so more an issue of steps and time. Site is more dynamic in nature too.",
  "id" : 751080695892549632,
  "in_reply_to_status_id" : 751079938124546048,
  "created_at" : "2016-07-07 15:49:26 +0000",
  "in_reply_to_screen_name" : "AmidstScience",
  "in_reply_to_user_id_str" : "78420357",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriela K Hajduk",
      "screen_name" : "AmidstScience",
      "indices" : [ 0, 14 ],
      "id_str" : "78420357",
      "id" : 78420357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/vIdN2Yz0PP",
      "expanded_url" : "https:\/\/getgrav.org\/forum#!\/general:how-is-grav-diffbetter-the",
      "display_url" : "getgrav.org\/forum#!\/genera\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "751077762128023552",
  "geo" : { },
  "id_str" : "751080045544747008",
  "in_reply_to_user_id" : 78420357,
  "text" : "@AmidstScience This thread might be helpful too: https:\/\/t.co\/vIdN2Yz0PP",
  "id" : 751080045544747008,
  "in_reply_to_status_id" : 751077762128023552,
  "created_at" : "2016-07-07 15:46:51 +0000",
  "in_reply_to_screen_name" : "AmidstScience",
  "in_reply_to_user_id_str" : "78420357",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriela K Hajduk",
      "screen_name" : "AmidstScience",
      "indices" : [ 0, 14 ],
      "id_str" : "78420357",
      "id" : 78420357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751077762128023552",
  "geo" : { },
  "id_str" : "751079661132587010",
  "in_reply_to_user_id" : 78420357,
  "text" : "@AmidstScience Static site generators usually require a full site rebuild for updates, which is why I do not find them a good fit for me.",
  "id" : 751079661132587010,
  "in_reply_to_status_id" : 751077762128023552,
  "created_at" : "2016-07-07 15:45:20 +0000",
  "in_reply_to_screen_name" : "AmidstScience",
  "in_reply_to_user_id_str" : "78420357",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriela K Hajduk",
      "screen_name" : "AmidstScience",
      "indices" : [ 0, 14 ],
      "id_str" : "78420357",
      "id" : 78420357
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 53, 61 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750960168150728704",
  "geo" : { },
  "id_str" : "751076274580254721",
  "in_reply_to_user_id" : 78420357,
  "text" : "@AmidstScience Thanks for sharing your thoughts. Did @getgrav and\/or my Course Hub skeleton work out for you?",
  "id" : 751076274580254721,
  "in_reply_to_status_id" : 750960168150728704,
  "created_at" : "2016-07-07 15:31:52 +0000",
  "in_reply_to_screen_name" : "AmidstScience",
  "in_reply_to_user_id_str" : "78420357",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Veletsianos",
      "screen_name" : "veletsianos",
      "indices" : [ 3, 15 ],
      "id_str" : "17883918",
      "id" : 17883918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/ddIfrfsYv0",
      "expanded_url" : "http:\/\/bit.ly\/29tpeCg",
      "display_url" : "bit.ly\/29tpeCg"
    } ]
  },
  "geo" : { },
  "id_str" : "750860262152900608",
  "text" : "RT @veletsianos: New Blog post: Theories for Learning with Emerging Technologies https:\/\/t.co\/ddIfrfsYv0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/ddIfrfsYv0",
        "expanded_url" : "http:\/\/bit.ly\/29tpeCg",
        "display_url" : "bit.ly\/29tpeCg"
      } ]
    },
    "geo" : { },
    "id_str" : "750858231660945408",
    "text" : "New Blog post: Theories for Learning with Emerging Technologies https:\/\/t.co\/ddIfrfsYv0",
    "id" : 750858231660945408,
    "created_at" : "2016-07-07 01:05:27 +0000",
    "user" : {
      "name" : "George Veletsianos",
      "screen_name" : "veletsianos",
      "protected" : false,
      "id_str" : "17883918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2252880258\/veletsianos_george_bio_photo_normal.jpg",
      "id" : 17883918,
      "verified" : false
    }
  },
  "id" : 750860262152900608,
  "created_at" : "2016-07-07 01:13:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 74, 82 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750790664040828928",
  "text" : "Before automation is possible, might educators pay for a service to setup @getgrav Course Hub on their computer with GitHub\/GitLab collab?",
  "id" : 750790664040828928,
  "created_at" : "2016-07-06 20:36:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 21, 29 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750786977666994176",
  "text" : "Suggested skills for @getgrav Course Hub?\n\u2713Markdown or HTML\n\u2713Creating relative links\n\u2713Webserver FTP\n\u2713Text editor usage\n\u2713GitHub\/GitLab basics",
  "id" : 750786977666994176,
  "created_at" : "2016-07-06 20:22:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Dan Blickensderfer",
      "screen_name" : "Dan_Blick",
      "indices" : [ 13, 23 ],
      "id_str" : "188554158",
      "id" : 188554158
    }, {
      "name" : "Gerard Gravallese",
      "screen_name" : "grav",
      "indices" : [ 24, 29 ],
      "id_str" : "14111453",
      "id" : 14111453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750780135884763136",
  "geo" : { },
  "id_str" : "750783498118541312",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @Dan_Blick @grav I am always exploring more ways to streamline things esp. initial setup but dev\/prod servers easier than WP.",
  "id" : 750783498118541312,
  "in_reply_to_status_id" : 750780135884763136,
  "created_at" : "2016-07-06 20:08:29 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "University Affairs",
      "screen_name" : "UA_magazine",
      "indices" : [ 3, 15 ],
      "id_str" : "80344952",
      "id" : 80344952
    }, {
      "name" : "Brenna Clarke Gray",
      "screen_name" : "brennacgray",
      "indices" : [ 40, 52 ],
      "id_str" : "14109848",
      "id" : 14109848
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/UA_magazine\/status\/750688163513851904\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/ytFS7r9OII",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cmr65k_VIAARFPP.jpg",
      "id_str" : "750688154999398400",
      "id" : 750688154999398400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cmr65k_VIAARFPP.jpg",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 250
      } ],
      "display_url" : "pic.twitter.com\/ytFS7r9OII"
    } ],
    "hashtags" : [ {
      "text" : "cdnpse",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/y5aSYe8PAf",
      "expanded_url" : "http:\/\/www.universityaffairs.ca\/features\/feature-article\/personal-newsletters-can-boon-academic-life-writing\/",
      "display_url" : "universityaffairs.ca\/features\/featu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750778610886152192",
  "text" : "RT @UA_magazine: We have a Q&amp;A with @brennacgray about her TinyLetter: https:\/\/t.co\/y5aSYe8PAf #cdnpse https:\/\/t.co\/ytFS7r9OII",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brenna Clarke Gray",
        "screen_name" : "brennacgray",
        "indices" : [ 23, 35 ],
        "id_str" : "14109848",
        "id" : 14109848
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/UA_magazine\/status\/750688163513851904\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/ytFS7r9OII",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cmr65k_VIAARFPP.jpg",
        "id_str" : "750688154999398400",
        "id" : 750688154999398400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cmr65k_VIAARFPP.jpg",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 250
        } ],
        "display_url" : "pic.twitter.com\/ytFS7r9OII"
      } ],
      "hashtags" : [ {
        "text" : "cdnpse",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/y5aSYe8PAf",
        "expanded_url" : "http:\/\/www.universityaffairs.ca\/features\/feature-article\/personal-newsletters-can-boon-academic-life-writing\/",
        "display_url" : "universityaffairs.ca\/features\/featu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750688163513851904",
    "text" : "We have a Q&amp;A with @brennacgray about her TinyLetter: https:\/\/t.co\/y5aSYe8PAf #cdnpse https:\/\/t.co\/ytFS7r9OII",
    "id" : 750688163513851904,
    "created_at" : "2016-07-06 13:49:39 +0000",
    "user" : {
      "name" : "University Affairs",
      "screen_name" : "UA_magazine",
      "protected" : false,
      "id_str" : "80344952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528275917349466113\/ywAfVt1n_normal.png",
      "id" : 80344952,
      "verified" : false
    }
  },
  "id" : 750778610886152192,
  "created_at" : "2016-07-06 19:49:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 97, 105 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/yJwV2clFWb",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-163\/",
      "display_url" : "paulhibbitts.net\/cmpt-363-163\/"
    } ]
  },
  "geo" : { },
  "id_str" : "750775579520036865",
  "text" : "Want to move beyond your LMS with an open + collaborative platform? Here's an example built with @getgrav Course Hub https:\/\/t.co\/yJwV2clFWb",
  "id" : 750775579520036865,
  "created_at" : "2016-07-06 19:37:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Blickensderfer",
      "screen_name" : "Dan_Blick",
      "indices" : [ 0, 10 ],
      "id_str" : "188554158",
      "id" : 188554158
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 87, 95 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/aTSTdLVAJw",
      "expanded_url" : "http:\/\/www.hibbittsdesign.org\/blog\/posts\/2016-05-09-a-few-thoughts-about-what-problems-grav-can-solve-for-instructors",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "750731440502018050",
  "geo" : { },
  "id_str" : "750761470946734081",
  "in_reply_to_user_id" : 188554158,
  "text" : "@Dan_Blick Here is a collection of tweets capturing the problems that a flat-file CMS (@getgrav) solved for me https:\/\/t.co\/aTSTdLVAJw",
  "id" : 750761470946734081,
  "in_reply_to_status_id" : 750731440502018050,
  "created_at" : "2016-07-06 18:40:57 +0000",
  "in_reply_to_screen_name" : "Dan_Blick",
  "in_reply_to_user_id_str" : "188554158",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Blickensderfer",
      "screen_name" : "Dan_Blick",
      "indices" : [ 0, 10 ],
      "id_str" : "188554158",
      "id" : 188554158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750731440502018050",
  "geo" : { },
  "id_str" : "750760461008662529",
  "in_reply_to_user_id" : 188554158,
  "text" : "@Dan_Blick Is a flat-file (no database) CMS an option? Once you get rid of the database requirement lots more options for version control...",
  "id" : 750760461008662529,
  "in_reply_to_status_id" : 750731440502018050,
  "created_at" : "2016-07-06 18:36:57 +0000",
  "in_reply_to_screen_name" : "Dan_Blick",
  "in_reply_to_user_id_str" : "188554158",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 3, 7 ],
      "id_str" : "1063291",
      "id" : 1063291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/gi9znme8c7",
      "expanded_url" : "http:\/\/ow.ly\/Yxrh301YYcm",
      "display_url" : "ow.ly\/Yxrh301YYcm"
    } ]
  },
  "geo" : { },
  "id_str" : "750728640367726592",
  "text" : "RT @UIE: Bootstrap 4: A Visual Guide\nSee What\u2019s New in the Next Bootstrap\nhttps:\/\/t.co\/gi9znme8c7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/gi9znme8c7",
        "expanded_url" : "http:\/\/ow.ly\/Yxrh301YYcm",
        "display_url" : "ow.ly\/Yxrh301YYcm"
      } ]
    },
    "geo" : { },
    "id_str" : "750724786414821376",
    "text" : "Bootstrap 4: A Visual Guide\nSee What\u2019s New in the Next Bootstrap\nhttps:\/\/t.co\/gi9znme8c7",
    "id" : 750724786414821376,
    "created_at" : "2016-07-06 16:15:11 +0000",
    "user" : {
      "name" : "UIE",
      "screen_name" : "UIE",
      "protected" : false,
      "id_str" : "1063291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3759116326\/19308cfcdb0b831111d4ee3fc3e6232c_normal.jpeg",
      "id" : 1063291,
      "verified" : false
    }
  },
  "id" : 750728640367726592,
  "created_at" : "2016-07-06 16:30:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 34, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/hvdG8uJRkk",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-163\/ux-techniques-guide#collapseTwo",
      "display_url" : "paulhibbitts.net\/cmpt-363-163\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750490859620044800",
  "text" : "Cooking up UX enhancements for my #SFU CMPT 363 UX Techniques Guide page - for example, auto-expanded panels via URL https:\/\/t.co\/hvdG8uJRkk",
  "id" : 750490859620044800,
  "created_at" : "2016-07-06 00:45:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 59, 67 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/ZeEZU1Ryw3",
      "expanded_url" : "http:\/\/fontawesome.io\/accessibility\/",
      "display_url" : "fontawesome.io\/accessibility\/"
    } ]
  },
  "geo" : { },
  "id_str" : "750446707998019589",
  "text" : "I've been working on accessibility with Font Awesome in my @getgrav Course Hub and found this page very helpful: https:\/\/t.co\/ZeEZU1Ryw3",
  "id" : 750446707998019589,
  "created_at" : "2016-07-05 21:50:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MeasuringU",
      "screen_name" : "MeasuringU",
      "indices" : [ 3, 14 ],
      "id_str" : "103951768",
      "id" : 103951768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/Ecw7zvlZWh",
      "expanded_url" : "http:\/\/ow.ly\/ECaA301rYRA",
      "display_url" : "ow.ly\/ECaA301rYRA"
    } ]
  },
  "geo" : { },
  "id_str" : "750117828250918912",
  "text" : "RT @MeasuringU: The Expert Review Is More Than A Second-Rate Usability Test (MeasuringU) https:\/\/t.co\/Ecw7zvlZWh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/Ecw7zvlZWh",
        "expanded_url" : "http:\/\/ow.ly\/ECaA301rYRA",
        "display_url" : "ow.ly\/ECaA301rYRA"
      } ]
    },
    "geo" : { },
    "id_str" : "750094525658431489",
    "text" : "The Expert Review Is More Than A Second-Rate Usability Test (MeasuringU) https:\/\/t.co\/Ecw7zvlZWh",
    "id" : 750094525658431489,
    "created_at" : "2016-07-04 22:30:45 +0000",
    "user" : {
      "name" : "MeasuringU",
      "screen_name" : "MeasuringU",
      "protected" : false,
      "id_str" : "103951768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768568168553910272\/Qigu06V6_normal.jpg",
      "id" : 103951768,
      "verified" : false
    }
  },
  "id" : 750117828250918912,
  "created_at" : "2016-07-05 00:03:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/NTfkiw2HfS",
      "expanded_url" : "http:\/\/hackeducation.com\/2016\/07\/02\/virtual-reality",
      "display_url" : "hackeducation.com\/2016\/07\/02\/vir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749733986595840001",
  "text" : "RT @audreywatters: (Marketing) Virtual Reality in Education: A History https:\/\/t.co\/NTfkiw2HfS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/NTfkiw2HfS",
        "expanded_url" : "http:\/\/hackeducation.com\/2016\/07\/02\/virtual-reality",
        "display_url" : "hackeducation.com\/2016\/07\/02\/vir\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "749391727652249600",
    "text" : "(Marketing) Virtual Reality in Education: A History https:\/\/t.co\/NTfkiw2HfS",
    "id" : 749391727652249600,
    "created_at" : "2016-07-02 23:58:05 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 749733986595840001,
  "created_at" : "2016-07-03 22:38:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2935\uFE0E",
      "screen_name" : "CodyBrown",
      "indices" : [ 3, 13 ],
      "id_str" : "10950722",
      "id" : 10950722
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CodyBrown\/status\/746466783331131396\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/NOzS8TpWaC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Clv7SOxVAAAtmJw.jpg",
      "id_str" : "746466453881159680",
      "id" : 746466453881159680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clv7SOxVAAAtmJw.jpg",
      "sizes" : [ {
        "h" : 772,
        "resize" : "fit",
        "w" : 980
      }, {
        "h" : 772,
        "resize" : "fit",
        "w" : 980
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 772,
        "resize" : "fit",
        "w" : 980
      }, {
        "h" : 536,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/NOzS8TpWaC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749457967162925056",
  "text" : "RT @CodyBrown: This is so real. And an argument this is so completely evaded by leadership at Facebook and Twitter. https:\/\/t.co\/NOzS8TpWaC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CodyBrown\/status\/746466783331131396\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/NOzS8TpWaC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Clv7SOxVAAAtmJw.jpg",
        "id_str" : "746466453881159680",
        "id" : 746466453881159680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clv7SOxVAAAtmJw.jpg",
        "sizes" : [ {
          "h" : 772,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 772,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 772,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 536,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/NOzS8TpWaC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746466783331131396",
    "text" : "This is so real. And an argument this is so completely evaded by leadership at Facebook and Twitter. https:\/\/t.co\/NOzS8TpWaC",
    "id" : 746466783331131396,
    "created_at" : "2016-06-24 22:15:24 +0000",
    "user" : {
      "name" : "\u2935\uFE0E",
      "screen_name" : "CodyBrown",
      "protected" : false,
      "id_str" : "10950722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654143112105865216\/q1biIqh7_normal.jpg",
      "id" : 10950722,
      "verified" : false
    }
  },
  "id" : 749457967162925056,
  "created_at" : "2016-07-03 04:21:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess McMullin",
      "screen_name" : "jessmcmullin",
      "indices" : [ 0, 13 ],
      "id_str" : "381203",
      "id" : 381203
    }, {
      "name" : "Zoom",
      "screen_name" : "zoom_us",
      "indices" : [ 42, 50 ],
      "id_str" : "522701657",
      "id" : 522701657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749381325325348864",
  "geo" : { },
  "id_str" : "749383624613441537",
  "in_reply_to_user_id" : 381203,
  "text" : "@jessmcmullin I've been pretty happy with @zoom_us overall but have not had a video call with more than 2 people myself.",
  "id" : 749383624613441537,
  "in_reply_to_status_id" : 749381325325348864,
  "created_at" : "2016-07-02 23:25:53 +0000",
  "in_reply_to_screen_name" : "jessmcmullin",
  "in_reply_to_user_id_str" : "381203",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 10, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/yJwV2clFWb",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-163\/",
      "display_url" : "paulhibbitts.net\/cmpt-363-163\/"
    } ]
  },
  "geo" : { },
  "id_str" : "749352881887645696",
  "text" : "Are you a #SFU student considering CMPT 363 (UI Design) this Fall term? Explore course details incl. project work at https:\/\/t.co\/yJwV2clFWb",
  "id" : 749352881887645696,
  "created_at" : "2016-07-02 21:23:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03C6\u03C1\u03B1\u03BD\u03C3\u03B5\u03C3\u03BA",
      "screen_name" : "francesc",
      "indices" : [ 3, 12 ],
      "id_str" : "122053508",
      "id" : 122053508
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/francesc\/status\/748937923173625856\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/FXtAI44U0v",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CmTDAE4VIAAhoZ2.jpg",
      "id_str" : "748937844127768576",
      "id" : 748937844127768576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CmTDAE4VIAAhoZ2.jpg",
      "sizes" : [ {
        "h" : 516,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FXtAI44U0v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749297902233595904",
  "text" : "RT @francesc: That's not honey! https:\/\/t.co\/FXtAI44U0v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/francesc\/status\/748937923173625856\/photo\/1",
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/FXtAI44U0v",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CmTDAE4VIAAhoZ2.jpg",
        "id_str" : "748937844127768576",
        "id" : 748937844127768576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CmTDAE4VIAAhoZ2.jpg",
        "sizes" : [ {
          "h" : 516,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FXtAI44U0v"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748937923173625856",
    "text" : "That's not honey! https:\/\/t.co\/FXtAI44U0v",
    "id" : 748937923173625856,
    "created_at" : "2016-07-01 17:54:50 +0000",
    "user" : {
      "name" : "francesc",
      "screen_name" : "francesc",
      "protected" : false,
      "id_str" : "122053508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736311101286014977\/MFZSmFUV_normal.jpg",
      "id" : 122053508,
      "verified" : false
    }
  },
  "id" : 749297902233595904,
  "created_at" : "2016-07-02 17:45:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Ruberry",
      "screen_name" : "erinruberry",
      "indices" : [ 3, 15 ],
      "id_str" : "62502942",
      "id" : 62502942
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/erinruberry\/status\/748849104487342080\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/hh98TBaK87",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmRySWAXgAEUv0r.jpg",
      "id_str" : "748849097520676865",
      "id" : 748849097520676865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmRySWAXgAEUv0r.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/hh98TBaK87"
    } ],
    "hashtags" : [ {
      "text" : "CanadaDay",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748945317635059712",
  "text" : "RT @erinruberry: Excuse me, do you have a moment to talk about #CanadaDay? https:\/\/t.co\/hh98TBaK87",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/erinruberry\/status\/748849104487342080\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/hh98TBaK87",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmRySWAXgAEUv0r.jpg",
        "id_str" : "748849097520676865",
        "id" : 748849097520676865,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmRySWAXgAEUv0r.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/hh98TBaK87"
      } ],
      "hashtags" : [ {
        "text" : "CanadaDay",
        "indices" : [ 46, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748849104487342080",
    "text" : "Excuse me, do you have a moment to talk about #CanadaDay? https:\/\/t.co\/hh98TBaK87",
    "id" : 748849104487342080,
    "created_at" : "2016-07-01 12:01:54 +0000",
    "user" : {
      "name" : "Erin Ruberry",
      "screen_name" : "erinruberry",
      "protected" : false,
      "id_str" : "62502942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661147247531458560\/LBG_ABbh_normal.jpg",
      "id" : 62502942,
      "verified" : true
    }
  },
  "id" : 748945317635059712,
  "created_at" : "2016-07-01 18:24:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]