Grailbird.data.tweets_2010_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20280467160825856",
  "text" : "Helping other people become better designers (and seeing it happen!) is one of the most rewarding aspects of a collaborative work style.",
  "id" : 20280467160825856,
  "created_at" : "2010-12-30 00:50:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hagan Rivers",
      "screen_name" : "haganrivers",
      "indices" : [ 28, 40 ],
      "id_str" : "11996722",
      "id" : 11996722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19823683967127552",
  "text" : "Finding application maps by @haganrivers a great method to illustrate navigation + conceptual model issues of Web apps http:\/\/bit.ly\/92mYob",
  "id" : 19823683967127552,
  "created_at" : "2010-12-28 18:35:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd",
      "screen_name" : "toddsieling",
      "indices" : [ 0, 12 ],
      "id_str" : "7415622",
      "id" : 7415622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14360702584094721",
  "geo" : { },
  "id_str" : "14363359830867968",
  "in_reply_to_user_id" : 7415622,
  "text" : "@toddsieling I don't use most card sets in a client facing way, interested to hear more! Excp. for me are MS Product Reaction Cards, etc.",
  "id" : 14363359830867968,
  "in_reply_to_status_id" : 14360702584094721,
  "created_at" : "2010-12-13 16:57:46 +0000",
  "in_reply_to_screen_name" : "toddsieling",
  "in_reply_to_user_id_str" : "7415622",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Travis",
      "screen_name" : "userfocus",
      "indices" : [ 79, 89 ],
      "id_str" : "16509110",
      "id" : 16509110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14360468374167552",
  "text" : "Usability 'card sets' seem v. popular at the moment. http:\/\/bit.ly\/exfXCG (via @userfocus) 'Don\u2019t push methods, get the team to pull' YES!!",
  "id" : 14360468374167552,
  "created_at" : "2010-12-13 16:46:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12710396989280256",
  "text" : "Really looking forward to Leah Buley's Lean Methods for a UX Team Of One virtual seminar tomorrow! http:\/\/bit.ly\/hOKDrH",
  "id" : 12710396989280256,
  "created_at" : "2010-12-09 03:29:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12195156140756992",
  "text" : "Creating Collaboration Takes More Than Technology http:\/\/bit.ly\/cAUeNb Company culture is a key factor, just as it is in all design efforts.",
  "id" : 12195156140756992,
  "created_at" : "2010-12-07 17:22:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seilevel",
      "screen_name" : "Seilevel",
      "indices" : [ 77, 86 ],
      "id_str" : "14858529",
      "id" : 14858529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10484802637533184",
  "text" : "The Move to Agile \u2013 The Impact on Business Analysts  http:\/\/dld.bz\/85hp (via @Seilevel) Comments are well worth reading too!",
  "id" : 10484802637533184,
  "created_at" : "2010-12-03 00:05:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]