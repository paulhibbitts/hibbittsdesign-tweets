Grailbird.data.tweets_2015_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Skelton",
      "screen_name" : "bskelton",
      "indices" : [ 0, 9 ],
      "id_str" : "644813",
      "id" : 644813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616059100745605120",
  "geo" : { },
  "id_str" : "616087554664722436",
  "in_reply_to_user_id" : 644813,
  "text" : "@bskelton It had a good run, but the love affair is long gone.",
  "id" : 616087554664722436,
  "in_reply_to_status_id" : 616059100745605120,
  "created_at" : "2015-07-01 03:34:54 +0000",
  "in_reply_to_screen_name" : "bskelton",
  "in_reply_to_user_id_str" : "644813",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sameroom HQ",
      "screen_name" : "sameroomhq",
      "indices" : [ 49, 60 ],
      "id_str" : "3016611945",
      "id" : 3016611945
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 69, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616022878249586689",
  "text" : "Really jazzed about plans taking shape for using @sameroomhq with my #SFU students next term. Involves students retaining data, more later!",
  "id" : 616022878249586689,
  "created_at" : "2015-06-30 23:17:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "indices" : [ 103, 111 ],
      "id_str" : "15022225",
      "id" : 15022225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/5UY58C0caK",
      "expanded_url" : "http:\/\/www.nngroup.com\/articles\/unmoderated-user-testing-tools\/",
      "display_url" : "nngroup.com\/articles\/unmod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615998339050385408",
  "text" : "Lots of helpful information for people interested in learning about unmoderated usability testing, via @NNgroup http:\/\/t.co\/5UY58C0caK",
  "id" : 615998339050385408,
  "created_at" : "2015-06-30 21:40:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loop11",
      "screen_name" : "Loop11",
      "indices" : [ 6, 13 ],
      "id_str" : "18822696",
      "id" : 18822696
    }, {
      "name" : "Validately",
      "screen_name" : "Validately",
      "indices" : [ 47, 58 ],
      "id_str" : "1080401130",
      "id" : 1080401130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Opxx2TXGH1",
      "expanded_url" : "https:\/\/validately.com\/feedback\/4d23aedc-96c3-4dc5-8d3c-07ea5cc91eca",
      "display_url" : "validately.com\/feedback\/4d23a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615992437513662464",
  "text" : "While @loop11 focuses more on task completion, @Validately brings qualitative feedback via screen + audio recording https:\/\/t.co\/Opxx2TXGH1",
  "id" : 615992437513662464,
  "created_at" : "2015-06-30 21:16:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loop11",
      "screen_name" : "Loop11",
      "indices" : [ 10, 17 ],
      "id_str" : "18822696",
      "id" : 18822696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/4acH8XjJfY",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/canvas-prototype\/?l11_uid=26844",
      "display_url" : "hibbittsdesign.com\/courses\/canvas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615977560367763456",
  "text" : "Exploring @loop11 to get rapid feedback on course website designs. If you had 5 mins. I'd greatly appreciate it! http:\/\/t.co\/4acH8XjJfY",
  "id" : 615977560367763456,
  "created_at" : "2015-06-30 20:17:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 63, 78 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 85, 94 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/615928077244174336\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/LlJl3t1ZvE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIw3Un3UMAA3AGt.png",
      "id_str" : "615928076480819200",
      "id" : 615928076480819200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIw3Un3UMAA3AGt.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      } ],
      "display_url" : "pic.twitter.com\/LlJl3t1ZvE"
    } ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 96, 103 ]
    }, {
      "text" : "edchat",
      "indices" : [ 104, 111 ]
    }, {
      "text" : "mlearn",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615928077244174336",
  "text" : "It's official: the foundations of Learner Experience Design by @hibbittsdesign &amp; @m_travin. #edtech #edchat #mlearn http:\/\/t.co\/LlJl3t1ZvE",
  "id" : 615928077244174336,
  "created_at" : "2015-06-30 17:01:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ipt76uhyA2",
      "expanded_url" : "http:\/\/etug.ca\/2015\/06\/22\/t-e-l-l-summer-agile-design-a-chat-with-tony-bates\/",
      "display_url" : "etug.ca\/2015\/06\/22\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615727605300330498",
  "text" : "RT @etug: Bring the iced tea and come for a Tell chat with Tony Bates on agile course design july 7 at 11 am #etug http:\/\/t.co\/ipt76uhyA2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 99, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/ipt76uhyA2",
        "expanded_url" : "http:\/\/etug.ca\/2015\/06\/22\/t-e-l-l-summer-agile-design-a-chat-with-tony-bates\/",
        "display_url" : "etug.ca\/2015\/06\/22\/t-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "615694976148570112",
    "text" : "Bring the iced tea and come for a Tell chat with Tony Bates on agile course design july 7 at 11 am #etug http:\/\/t.co\/ipt76uhyA2",
    "id" : 615694976148570112,
    "created_at" : "2015-06-30 01:34:56 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 615727605300330498,
  "created_at" : "2015-06-30 03:44:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "indices" : [ 3, 16 ],
      "id_str" : "35943",
      "id" : 35943
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/karenmcgrane\/status\/615540255299649537\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/QTdWM8fCfv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIrWmdLXAAA1rwy.png",
      "id_str" : "615540255245139968",
      "id" : 615540255245139968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIrWmdLXAAA1rwy.png",
      "sizes" : [ {
        "h" : 214,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/QTdWM8fCfv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/na43x2ES9F",
      "expanded_url" : "http:\/\/bit.ly\/1BQIy7d",
      "display_url" : "bit.ly\/1BQIy7d"
    } ]
  },
  "geo" : { },
  "id_str" : "615586750908338176",
  "text" : "RT @karenmcgrane: The Atlantic: Phone vs. desktop is not either\/or. It's both. http:\/\/t.co\/na43x2ES9F http:\/\/t.co\/QTdWM8fCfv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/karenmcgrane\/status\/615540255299649537\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/QTdWM8fCfv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIrWmdLXAAA1rwy.png",
        "id_str" : "615540255245139968",
        "id" : 615540255245139968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIrWmdLXAAA1rwy.png",
        "sizes" : [ {
          "h" : 214,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/QTdWM8fCfv"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/na43x2ES9F",
        "expanded_url" : "http:\/\/bit.ly\/1BQIy7d",
        "display_url" : "bit.ly\/1BQIy7d"
      } ]
    },
    "geo" : { },
    "id_str" : "615540255299649537",
    "text" : "The Atlantic: Phone vs. desktop is not either\/or. It's both. http:\/\/t.co\/na43x2ES9F http:\/\/t.co\/QTdWM8fCfv",
    "id" : 615540255299649537,
    "created_at" : "2015-06-29 15:20:07 +0000",
    "user" : {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "protected" : false,
      "id_str" : "35943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720948130867449857\/DR8tPuqM_normal.jpg",
      "id" : 35943,
      "verified" : false
    }
  },
  "id" : 615586750908338176,
  "created_at" : "2015-06-29 18:24:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615271669507096576",
  "geo" : { },
  "id_str" : "615299571191681024",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Awesome, that takes me way back too.",
  "id" : 615299571191681024,
  "in_reply_to_status_id" : 615271669507096576,
  "created_at" : "2015-06-28 23:23:44 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vala Afshar",
      "screen_name" : "ValaAfshar",
      "indices" : [ 3, 14 ],
      "id_str" : "259725229",
      "id" : 259725229
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ValaAfshar\/status\/603610810624147456\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ucrtmWWG5x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGB01FmUEAAjmWj.jpg",
      "id_str" : "603610805452410880",
      "id" : 603610805452410880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGB01FmUEAAjmWj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ucrtmWWG5x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614883830218907649",
  "text" : "RT @ValaAfshar: 51% of total time spent on the Internet is on mobile devices - first time ever mobile is #1. http:\/\/t.co\/ucrtmWWG5x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ValaAfshar\/status\/603610810624147456\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/ucrtmWWG5x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGB01FmUEAAjmWj.jpg",
        "id_str" : "603610805452410880",
        "id" : 603610805452410880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGB01FmUEAAjmWj.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ucrtmWWG5x"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614822752931819520",
    "text" : "51% of total time spent on the Internet is on mobile devices - first time ever mobile is #1. http:\/\/t.co\/ucrtmWWG5x",
    "id" : 614822752931819520,
    "created_at" : "2015-06-27 15:49:01 +0000",
    "user" : {
      "name" : "Vala Afshar",
      "screen_name" : "ValaAfshar",
      "protected" : false,
      "id_str" : "259725229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1259558245\/vala_300dpi_normal.jpg",
      "id" : 259725229,
      "verified" : true
    }
  },
  "id" : 614883830218907649,
  "created_at" : "2015-06-27 19:51:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "istedesign",
      "indices" : [ 116, 127 ]
    }, {
      "text" : "moodle",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614879093717233664",
  "text" : "Another learner experience tip: think of your online course websites in terms of services (activities) vs. content. #istedesign #moodle",
  "id" : 614879093717233664,
  "created_at" : "2015-06-27 19:32:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Klein",
      "screen_name" : "lauraklein",
      "indices" : [ 69, 80 ],
      "id_str" : "14804195",
      "id" : 14804195
    }, {
      "name" : "Validately",
      "screen_name" : "Validately",
      "indices" : [ 87, 98 ],
      "id_str" : "1080401130",
      "id" : 1080401130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buildbetterproduct",
      "indices" : [ 99, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/kEpB7QIh1Q",
      "expanded_url" : "http:\/\/bit.ly\/1SprBFU",
      "display_url" : "bit.ly\/1SprBFU"
    } ]
  },
  "geo" : { },
  "id_str" : "614211014654054400",
  "text" : "Build better products with moderated research. Upcoming webinar with @lauraklein &amp; @validately #buildbetterproduct http:\/\/t.co\/kEpB7QIh1Q",
  "id" : 614211014654054400,
  "created_at" : "2015-06-25 23:18:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JTBD",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614160705781010432",
  "text" : "I really like the #JTBD framework, but I find job statements including context less than effective. I prefer the format action\/object\/goal.",
  "id" : 614160705781010432,
  "created_at" : "2015-06-25 19:58:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 3, 12 ],
      "id_str" : "837060721",
      "id" : 837060721
    }, {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 63, 70 ],
      "id_str" : "20793816",
      "id" : 20793816
    }, {
      "name" : "MakingBetter\u2122",
      "screen_name" : "mkngbttr",
      "indices" : [ 75, 84 ],
      "id_str" : "2274647630",
      "id" : 2274647630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/O8IbHe70Yt",
      "expanded_url" : "http:\/\/connectionsforum.com\/xapi-camp-seattle\/",
      "display_url" : "connectionsforum.com\/xapi-camp-seat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614144370024009732",
  "text" : "RT @m_travin: Happy xAPI Camper: http:\/\/t.co\/O8IbHe70Yt Thanks @amazon and @mkngbttr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amazon",
        "screen_name" : "amazon",
        "indices" : [ 49, 56 ],
        "id_str" : "20793816",
        "id" : 20793816
      }, {
        "name" : "MakingBetter\u2122",
        "screen_name" : "mkngbttr",
        "indices" : [ 61, 70 ],
        "id_str" : "2274647630",
        "id" : 2274647630
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/O8IbHe70Yt",
        "expanded_url" : "http:\/\/connectionsforum.com\/xapi-camp-seattle\/",
        "display_url" : "connectionsforum.com\/xapi-camp-seat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613785140947349505",
    "text" : "Happy xAPI Camper: http:\/\/t.co\/O8IbHe70Yt Thanks @amazon and @mkngbttr",
    "id" : 613785140947349505,
    "created_at" : "2015-06-24 19:05:55 +0000",
    "user" : {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "protected" : false,
      "id_str" : "837060721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765287050069159936\/eekFNEG5_normal.jpg",
      "id" : 837060721,
      "verified" : false
    }
  },
  "id" : 614144370024009732,
  "created_at" : "2015-06-25 18:53:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614120896156950528",
  "text" : "Excited about an upcoming Moodle learner experience improvement project - will involve activity-centred design &amp; unmoderated usability tests",
  "id" : 614120896156950528,
  "created_at" : "2015-06-25 17:20:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/uzuMX7quBs",
      "expanded_url" : "https:\/\/twitter.com\/balsamiq\/status\/613733195142537217",
      "display_url" : "twitter.com\/balsamiq\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614114445439078400",
  "text" : "Very creative use of myBalsamiq Mockups by Jay Bennett, a past CMPT 363 student at SFU. Well done Jay! https:\/\/t.co\/uzuMX7quBs",
  "id" : 614114445439078400,
  "created_at" : "2015-06-25 16:54:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Weeks",
      "screen_name" : "scweeker",
      "indices" : [ 0, 9 ],
      "id_str" : "15670483",
      "id" : 15670483
    }, {
      "name" : "Moodlerooms",
      "screen_name" : "Moodlerooms",
      "indices" : [ 10, 22 ],
      "id_str" : "19984985",
      "id" : 19984985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613696521285038080",
  "geo" : { },
  "id_str" : "613912360642686976",
  "in_reply_to_user_id" : 15670483,
  "text" : "@scweeker @Moodlerooms Loving Snap so far. Know of any student feedback? Hope to share HigherEd student feedback with upcoming project.",
  "id" : 613912360642686976,
  "in_reply_to_status_id" : 613696521285038080,
  "created_at" : "2015-06-25 03:31:27 +0000",
  "in_reply_to_screen_name" : "scweeker",
  "in_reply_to_user_id_str" : "15670483",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lewiscarr",
      "screen_name" : "lewiscarr",
      "indices" : [ 3, 13 ],
      "id_str" : "15168677",
      "id" : 15168677
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/lewiscarr\/status\/606019287552258048\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/PZAEIowVV8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGkDVHLWcAElBQM.png",
      "id_str" : "606019286096834561",
      "id" : 606019286096834561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGkDVHLWcAElBQM.png",
      "sizes" : [ {
        "h" : 724,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2479,
        "resize" : "fit",
        "w" : 3508
      } ],
      "display_url" : "pic.twitter.com\/PZAEIowVV8"
    } ],
    "hashtags" : [ {
      "text" : "Moodle",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613910066748526592",
  "text" : "RT @lewiscarr: Sharing my new #Moodle Learning Pyramid.  Learners respond better when learning with others http:\/\/t.co\/PZAEIowVV8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lewiscarr\/status\/606019287552258048\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/PZAEIowVV8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGkDVHLWcAElBQM.png",
        "id_str" : "606019286096834561",
        "id" : 606019286096834561,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGkDVHLWcAElBQM.png",
        "sizes" : [ {
          "h" : 724,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2479,
          "resize" : "fit",
          "w" : 3508
        } ],
        "display_url" : "pic.twitter.com\/PZAEIowVV8"
      } ],
      "hashtags" : [ {
        "text" : "Moodle",
        "indices" : [ 15, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606019287552258048",
    "text" : "Sharing my new #Moodle Learning Pyramid.  Learners respond better when learning with others http:\/\/t.co\/PZAEIowVV8",
    "id" : 606019287552258048,
    "created_at" : "2015-06-03 08:47:12 +0000",
    "user" : {
      "name" : "lewiscarr",
      "screen_name" : "lewiscarr",
      "protected" : false,
      "id_str" : "15168677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697439205857878016\/D7Y48E40_normal.png",
      "id" : 15168677,
      "verified" : false
    }
  },
  "id" : 613910066748526592,
  "created_at" : "2015-06-25 03:22:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/613445937231364096\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/XfeljnWLeo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CINl1ElVAAQ5SZH.png",
      "id_str" : "613445936690298884",
      "id" : 613445936690298884,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CINl1ElVAAQ5SZH.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      } ],
      "display_url" : "pic.twitter.com\/XfeljnWLeo"
    } ],
    "hashtags" : [ {
      "text" : "elearning",
      "indices" : [ 69, 79 ]
    }, {
      "text" : "edtech",
      "indices" : [ 80, 87 ]
    }, {
      "text" : "mlearning",
      "indices" : [ 88, 98 ]
    }, {
      "text" : "lxdesign",
      "indices" : [ 99, 108 ]
    }, {
      "text" : "etug",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613445937231364096",
  "text" : "The need for this perspective has been on my mind for quite a while. #elearning #edtech #mlearning #lxdesign #etug http:\/\/t.co\/XfeljnWLeo",
  "id" : 613445937231364096,
  "created_at" : "2015-06-23 20:38:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/GwkWZfVe5v",
      "expanded_url" : "http:\/\/getgrav.org\/blog\/grav-0.9.29-released",
      "display_url" : "getgrav.org\/blog\/grav-0.9.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613444773915983872",
  "text" : "RT @getgrav: Grav 0.9.29 released today with some minor new features, some community PRs, and a few bug fixes: http:\/\/t.co\/GwkWZfVe5v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/GwkWZfVe5v",
        "expanded_url" : "http:\/\/getgrav.org\/blog\/grav-0.9.29-released",
        "display_url" : "getgrav.org\/blog\/grav-0.9.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613150110600445952",
    "text" : "Grav 0.9.29 released today with some minor new features, some community PRs, and a few bug fixes: http:\/\/t.co\/GwkWZfVe5v",
    "id" : 613150110600445952,
    "created_at" : "2015-06-23 01:02:32 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 613444773915983872,
  "created_at" : "2015-06-23 20:33:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 30, 45 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 50, 59 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/SWNZgqYfuf",
      "expanded_url" : "http:\/\/ow.ly\/OG4pP",
      "display_url" : "ow.ly\/OG4pP"
    } ]
  },
  "geo" : { },
  "id_str" : "613379274129575936",
  "text" : "RT @BCcampus: Great info from @hibbittsdesign and @m_travin about the learning ecology framework http:\/\/t.co\/SWNZgqYfuf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 16, 31 ],
        "id_str" : "15949844",
        "id" : 15949844
      }, {
        "name" : "Myra T Travin",
        "screen_name" : "m_travin",
        "indices" : [ 36, 45 ],
        "id_str" : "837060721",
        "id" : 837060721
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/SWNZgqYfuf",
        "expanded_url" : "http:\/\/ow.ly\/OG4pP",
        "display_url" : "ow.ly\/OG4pP"
      } ]
    },
    "geo" : { },
    "id_str" : "613377300479000577",
    "text" : "Great info from @hibbittsdesign and @m_travin about the learning ecology framework http:\/\/t.co\/SWNZgqYfuf",
    "id" : 613377300479000577,
    "created_at" : "2015-06-23 16:05:19 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 613379274129575936,
  "created_at" : "2015-06-23 16:13:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 0, 9 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 10, 19 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613377300479000577",
  "geo" : { },
  "id_str" : "613379253376147456",
  "in_reply_to_user_id" : 93710949,
  "text" : "@BCcampus @m_travin Thanks to everyone involved with BCcampus for making this happen!",
  "id" : 613379253376147456,
  "in_reply_to_status_id" : 613377300479000577,
  "created_at" : "2015-06-23 16:13:04 +0000",
  "in_reply_to_screen_name" : "BCcampus",
  "in_reply_to_user_id_str" : "93710949",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 87, 102 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 107, 116 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/613203487145357312\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/yvmzk4UZwW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIKJUnvUwAU4Ybf.png",
      "id_str" : "613203486633672709",
      "id" : 613203486633672709,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIKJUnvUwAU4Ybf.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      } ],
      "display_url" : "pic.twitter.com\/yvmzk4UZwW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613203487145357312",
  "text" : "Late night preview: The foundations of Learner Experience (LX) Design as visualized by @hibbittsdesign and @m_travin. http:\/\/t.co\/yvmzk4UZwW",
  "id" : 613203487145357312,
  "created_at" : "2015-06-23 04:34:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613075211462709248",
  "text" : "When designing learning environments, I have found the use of personas less effective and prefer to use empathy maps + JTBD (or scenarios).",
  "id" : 613075211462709248,
  "created_at" : "2015-06-22 20:04:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Core77",
      "screen_name" : "core77",
      "indices" : [ 101, 108 ],
      "id_str" : "20236725",
      "id" : 20236725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/KzTsRw60r7",
      "expanded_url" : "http:\/\/www.core77.com\/posts\/37039\/",
      "display_url" : "core77.com\/posts\/37039\/"
    } ]
  },
  "geo" : { },
  "id_str" : "612641164122984448",
  "text" : "Introducing Our New Series on Great Female Designers of the 20th Century  http:\/\/t.co\/KzTsRw60r7 via @Core77",
  "id" : 612641164122984448,
  "created_at" : "2015-06-21 15:20:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "will engle",
      "screen_name" : "infology",
      "indices" : [ 0, 9 ],
      "id_str" : "93031146",
      "id" : 93031146
    }, {
      "name" : "Cindy Underhill",
      "screen_name" : "cindyu",
      "indices" : [ 10, 17 ],
      "id_str" : "5540542",
      "id" : 5540542
    }, {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 18, 32 ],
      "id_str" : "260919324",
      "id" : 260919324
    }, {
      "name" : "Lucas Wright",
      "screen_name" : "Lucwrite",
      "indices" : [ 33, 42 ],
      "id_str" : "36246383",
      "id" : 36246383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612040307765456896",
  "geo" : { },
  "id_str" : "612042988391235584",
  "in_reply_to_user_id" : 93031146,
  "text" : "@infology @cindyu @clhendricksbc @Lucwrite A tough nut to crack :-) Happy to meet at UBC, please email me to arrange that if interested.",
  "id" : 612042988391235584,
  "in_reply_to_status_id" : 612040307765456896,
  "created_at" : "2015-06-19 23:43:14 +0000",
  "in_reply_to_screen_name" : "infology",
  "in_reply_to_user_id_str" : "93031146",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Wuetherick",
      "screen_name" : "bwuetherick",
      "indices" : [ 3, 15 ],
      "id_str" : "107227275",
      "id" : 107227275
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612017118041673728",
  "text" : "RT @bwuetherick: ML: challenge with much data from learning technology - we want to know what students learn, rather than what they do\/comp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STLHE2015",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611219513351106560",
    "text" : "ML: challenge with much data from learning technology - we want to know what students learn, rather than what they do\/complete #STLHE2015",
    "id" : 611219513351106560,
    "created_at" : "2015-06-17 17:11:02 +0000",
    "user" : {
      "name" : "Brad Wuetherick",
      "screen_name" : "bwuetherick",
      "protected" : false,
      "id_str" : "107227275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3623608264\/6b4f00b373c6fd37d14d01673e49ae78_normal.jpeg",
      "id" : 107227275,
      "verified" : false
    }
  },
  "id" : 612017118041673728,
  "created_at" : "2015-06-19 22:00:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611992760283889664",
  "text" : "What does mobile mean in 2015? Nothing (we have to now design for all devices) and everything (it's where all our students are)! #STLHE2015",
  "id" : 611992760283889664,
  "created_at" : "2015-06-19 20:23:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy Underhill",
      "screen_name" : "cindyu",
      "indices" : [ 0, 7 ],
      "id_str" : "5540542",
      "id" : 5540542
    }, {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 8, 22 ],
      "id_str" : "260919324",
      "id" : 260919324
    }, {
      "name" : "will engle",
      "screen_name" : "infology",
      "indices" : [ 23, 32 ],
      "id_str" : "93031146",
      "id" : 93031146
    }, {
      "name" : "Lucas Wright",
      "screen_name" : "Lucwrite",
      "indices" : [ 33, 42 ],
      "id_str" : "36246383",
      "id" : 36246383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611991999936204800",
  "in_reply_to_user_id" : 5540542,
  "text" : "@cindyu @clhendricksbc @infology @Lucwrite Really enjoyed your session today! Love to talk more about open course development sometime too.",
  "id" : 611991999936204800,
  "created_at" : "2015-06-19 20:20:37 +0000",
  "in_reply_to_screen_name" : "cindyu",
  "in_reply_to_user_id_str" : "5540542",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Padlet",
      "screen_name" : "padlet",
      "indices" : [ 0, 7 ],
      "id_str" : "24564180",
      "id" : 24564180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611991288066412544",
  "in_reply_to_user_id" : 24564180,
  "text" : "@padlet Can I have a Padlet board publicly viewable *and* be only writeable by those with password? If not, that would be super feature!",
  "id" : 611991288066412544,
  "created_at" : "2015-06-19 20:17:47 +0000",
  "in_reply_to_screen_name" : "padlet",
  "in_reply_to_user_id_str" : "24564180",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 22, 31 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/a8C8SPNUqq",
      "expanded_url" : "http:\/\/padlet.com\/paulhibbitts\/stlhe2015",
      "display_url" : "padlet.com\/paulhibbitts\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611990653631791104",
  "text" : "Insightful answers by @m_travin to \"From Mobile Access to Multi-device Learning Ecologies\" participants http:\/\/t.co\/a8C8SPNUqq #STLHE2015",
  "id" : 611990653631791104,
  "created_at" : "2015-06-19 20:15:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611971793511788544",
  "text" : "A great morning to wrap up a great conference! Both humbled and inspired by the many thoughtful talks and people at #STLHE2015",
  "id" : 611971793511788544,
  "created_at" : "2015-06-19 19:00:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rajiv Jhangiani",
      "screen_name" : "thatpsychprof",
      "indices" : [ 3, 17 ],
      "id_str" : "39835900",
      "id" : 39835900
    }, {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 67, 81 ],
      "id_str" : "260919324",
      "id" : 260919324
    }, {
      "name" : "STLHE",
      "screen_name" : "STLHE",
      "indices" : [ 82, 88 ],
      "id_str" : "334216731",
      "id" : 334216731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opentextbooks",
      "indices" : [ 116, 130 ]
    }, {
      "text" : "OER",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "stlhe2015",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611896792314064896",
  "text" : "RT @thatpsychprof: Looking forward to presenting this morning with @clhendricksbc @STLHE on Enhancing Pedagogy with #opentextbooks and othe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christina Hendricks",
        "screen_name" : "clhendricksbc",
        "indices" : [ 48, 62 ],
        "id_str" : "260919324",
        "id" : 260919324
      }, {
        "name" : "STLHE",
        "screen_name" : "STLHE",
        "indices" : [ 63, 69 ],
        "id_str" : "334216731",
        "id" : 334216731
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opentextbooks",
        "indices" : [ 97, 111 ]
      }, {
        "text" : "OER",
        "indices" : [ 122, 126 ]
      }, {
        "text" : "stlhe2015",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611892063584432133",
    "text" : "Looking forward to presenting this morning with @clhendricksbc @STLHE on Enhancing Pedagogy with #opentextbooks and other #OER #stlhe2015",
    "id" : 611892063584432133,
    "created_at" : "2015-06-19 13:43:31 +0000",
    "user" : {
      "name" : "Rajiv Jhangiani",
      "screen_name" : "thatpsychprof",
      "protected" : false,
      "id_str" : "39835900",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677017328740122624\/zdAKRH0L_normal.jpg",
      "id" : 39835900,
      "verified" : false
    }
  },
  "id" : 611896792314064896,
  "created_at" : "2015-06-19 14:02:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 0, 10 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611689376934985729",
  "geo" : { },
  "id_str" : "611689609026650112",
  "in_reply_to_user_id" : 887742962,
  "text" : "@keroleenl Very promising then, thanks for sharing!",
  "id" : 611689609026650112,
  "in_reply_to_status_id" : 611689376934985729,
  "created_at" : "2015-06-19 00:19:02 +0000",
  "in_reply_to_screen_name" : "keroleenl",
  "in_reply_to_user_id_str" : "887742962",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 0, 10 ],
      "id_str" : "887742962",
      "id" : 887742962
    }, {
      "name" : "Erica Curry",
      "screen_name" : "Erica_Noel_",
      "indices" : [ 11, 23 ],
      "id_str" : "1146719162",
      "id" : 1146719162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611680355599405056",
  "geo" : { },
  "id_str" : "611683728847319041",
  "in_reply_to_user_id" : 887742962,
  "text" : "@keroleenl @Erica_Noel_ Looks good! Is it responsive?",
  "id" : 611683728847319041,
  "in_reply_to_status_id" : 611680355599405056,
  "created_at" : "2015-06-18 23:55:40 +0000",
  "in_reply_to_screen_name" : "keroleenl",
  "in_reply_to_user_id_str" : "887742962",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/5DXiTmKiHD",
      "expanded_url" : "https:\/\/twitter.com\/getgrav\/status\/611615205177450496",
      "display_url" : "twitter.com\/getgrav\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611648801049153536",
  "text" : "Awesome addition to an already awesome CMS. https:\/\/t.co\/5DXiTmKiHD",
  "id" : 611648801049153536,
  "created_at" : "2015-06-18 21:36:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janet Dhanani",
      "screen_name" : "ElevateEfficacy",
      "indices" : [ 3, 19 ],
      "id_str" : "1661219018",
      "id" : 1661219018
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/PoaE3PUflx",
      "expanded_url" : "http:\/\/opencontent.org\/blog\/archives\/2975",
      "display_url" : "opencontent.org\/blog\/archives\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611643343047491585",
  "text" : "RT @ElevateEfficacy: Killing the Disposable Assignment David Wiley: http:\/\/t.co\/PoaE3PUflx #STLHE2015 Meaningful assessment session",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STLHE2015",
        "indices" : [ 70, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/PoaE3PUflx",
        "expanded_url" : "http:\/\/opencontent.org\/blog\/archives\/2975",
        "display_url" : "opencontent.org\/blog\/archives\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611609852230565888",
    "text" : "Killing the Disposable Assignment David Wiley: http:\/\/t.co\/PoaE3PUflx #STLHE2015 Meaningful assessment session",
    "id" : 611609852230565888,
    "created_at" : "2015-06-18 19:02:06 +0000",
    "user" : {
      "name" : "Janet Dhanani",
      "screen_name" : "ElevateEfficacy",
      "protected" : false,
      "id_str" : "1661219018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560908601028399104\/xHj_JXTo_normal.jpeg",
      "id" : 1661219018,
      "verified" : false
    }
  },
  "id" : 611643343047491585,
  "created_at" : "2015-06-18 21:15:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Padlet",
      "screen_name" : "padlet",
      "indices" : [ 0, 7 ],
      "id_str" : "24564180",
      "id" : 24564180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611638324621541376",
  "geo" : { },
  "id_str" : "611639100857257986",
  "in_reply_to_user_id" : 24564180,
  "text" : "@padlet I will hope so to, it was really a bad situation. I will do some more tests on my own before trying it again during a presentation.",
  "id" : 611639100857257986,
  "in_reply_to_status_id" : 611638324621541376,
  "created_at" : "2015-06-18 20:58:20 +0000",
  "in_reply_to_screen_name" : "padlet",
  "in_reply_to_user_id_str" : "24564180",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Padlet",
      "screen_name" : "padlet",
      "indices" : [ 0, 7 ],
      "id_str" : "24564180",
      "id" : 24564180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611324102620516352",
  "geo" : { },
  "id_str" : "611637368622325760",
  "in_reply_to_user_id" : 24564180,
  "text" : "@padlet Any news re: data loss issue with remote participant yesterday? Thanks.",
  "id" : 611637368622325760,
  "in_reply_to_status_id" : 611324102620516352,
  "created_at" : "2015-06-18 20:51:27 +0000",
  "in_reply_to_screen_name" : "padlet",
  "in_reply_to_user_id_str" : "24564180",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WorkFlowy",
      "screen_name" : "WorkFlowy",
      "indices" : [ 0, 10 ],
      "id_str" : "82836356",
      "id" : 82836356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611565528520351744",
  "in_reply_to_user_id" : 82836356,
  "text" : "@WorkFlowy Any plans for embeddable WorkFlowy lists (beyond using a basic iFrame as-is)? Or adding ability for viewer comments?",
  "id" : 611565528520351744,
  "created_at" : "2015-06-18 16:05:58 +0000",
  "in_reply_to_screen_name" : "WorkFlowy",
  "in_reply_to_user_id_str" : "82836356",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catherine Rawn",
      "screen_name" : "cdrawn",
      "indices" : [ 3, 10 ],
      "id_str" : "69613882",
      "id" : 69613882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stlhe2015",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/RAkCugt9RH",
      "expanded_url" : "http:\/\/psi.sagepub.com\/content\/9\/3\/105.abstract",
      "display_url" : "psi.sagepub.com\/content\/9\/3\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611562752499322880",
  "text" : "RT @cdrawn: Every time I see the words \"Learning styles,\" I feel morally obligated to post this. http:\/\/t.co\/RAkCugt9RH #stlhe2015",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "stlhe2015",
        "indices" : [ 108, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/RAkCugt9RH",
        "expanded_url" : "http:\/\/psi.sagepub.com\/content\/9\/3\/105.abstract",
        "display_url" : "psi.sagepub.com\/content\/9\/3\/10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611561999835598848",
    "text" : "Every time I see the words \"Learning styles,\" I feel morally obligated to post this. http:\/\/t.co\/RAkCugt9RH #stlhe2015",
    "id" : 611561999835598848,
    "created_at" : "2015-06-18 15:51:57 +0000",
    "user" : {
      "name" : "Catherine Rawn",
      "screen_name" : "cdrawn",
      "protected" : false,
      "id_str" : "69613882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658749675281907712\/P_eHaaOX_normal.jpg",
      "id" : 69613882,
      "verified" : false
    }
  },
  "id" : 611562752499322880,
  "created_at" : "2015-06-18 15:54:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611372616863973376",
  "text" : "In the company of fellow educators always inspires me! Moving into action with a series of new projects within weeks, stay tuned. #STLHE2015",
  "id" : 611372616863973376,
  "created_at" : "2015-06-18 03:19:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Padlet",
      "screen_name" : "padlet",
      "indices" : [ 0, 7 ],
      "id_str" : "24564180",
      "id" : 24564180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611323869048082432",
  "geo" : { },
  "id_str" : "611326220119093249",
  "in_reply_to_user_id" : 24564180,
  "text" : "@padlet This happened between 12:00 - 12:30pm PST (UTC\/GMT -7 hours). I've been working on the manual update for the past 30 minutes or so.",
  "id" : 611326220119093249,
  "in_reply_to_status_id" : 611323869048082432,
  "created_at" : "2015-06-18 00:15:03 +0000",
  "in_reply_to_screen_name" : "padlet",
  "in_reply_to_user_id_str" : "24564180",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/MRxYpvGeTX",
      "expanded_url" : "http:\/\/1drv.ms\/1Ionzbs",
      "display_url" : "1drv.ms\/1Ionzbs"
    } ]
  },
  "geo" : { },
  "id_str" : "611325051279798272",
  "text" : "Missed \"From Mobile Access to Multi-device Learning Ecologies: A Case Study\" today? All resources are at http:\/\/t.co\/MRxYpvGeTX #STLHE2015",
  "id" : 611325051279798272,
  "created_at" : "2015-06-18 00:10:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rubeli",
      "screen_name" : "drubeli",
      "indices" : [ 0, 8 ],
      "id_str" : "17217620",
      "id" : 17217620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611321399349633024",
  "geo" : { },
  "id_str" : "611323754791071744",
  "in_reply_to_user_id" : 17217620,
  "text" : "@drubeli Hope to, best of luck with the session!",
  "id" : 611323754791071744,
  "in_reply_to_status_id" : 611321399349633024,
  "created_at" : "2015-06-18 00:05:15 +0000",
  "in_reply_to_screen_name" : "drubeli",
  "in_reply_to_user_id_str" : "17217620",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Padlet",
      "screen_name" : "padlet",
      "indices" : [ 0, 7 ],
      "id_str" : "24564180",
      "id" : 24564180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611318028752400385",
  "geo" : { },
  "id_str" : "611321976825643008",
  "in_reply_to_user_id" : 24564180,
  "text" : "@padlet As I manually re-added things they first seemed to disappear, but after a Browser refresh then they came back. Subsequent adds OK.",
  "id" : 611321976825643008,
  "in_reply_to_status_id" : 611318028752400385,
  "created_at" : "2015-06-17 23:58:11 +0000",
  "in_reply_to_screen_name" : "padlet",
  "in_reply_to_user_id_str" : "24564180",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Padlet",
      "screen_name" : "padlet",
      "indices" : [ 0, 7 ],
      "id_str" : "24564180",
      "id" : 24564180
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/611321446502019072\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ZAd0USDGyS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHvZnbcUMAAut9w.png",
      "id_str" : "611321445843480576",
      "id" : 611321445843480576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHvZnbcUMAAut9w.png",
      "sizes" : [ {
        "h" : 199,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 721,
        "resize" : "fit",
        "w" : 1230
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZAd0USDGyS"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/611321446502019072\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ZAd0USDGyS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHvZnQ_UcAAu6UN.png",
      "id_str" : "611321443037507584",
      "id" : 611321443037507584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHvZnQ_UcAAu6UN.png",
      "sizes" : [ {
        "h" : 545,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 1231
      }, {
        "h" : 319,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZAd0USDGyS"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/611321446502019072\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ZAd0USDGyS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHvZnGrUEAArQJQ.png",
      "id_str" : "611321440269242368",
      "id" : 611321440269242368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHvZnGrUEAArQJQ.png",
      "sizes" : [ {
        "h" : 469,
        "resize" : "fit",
        "w" : 1193
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 134,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZAd0USDGyS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611318028752400385",
  "geo" : { },
  "id_str" : "611321446502019072",
  "in_reply_to_user_id" : 24564180,
  "text" : "@padlet Here are screen snaps to show original issue, remote participant took screen captures (thank goodness!)... http:\/\/t.co\/ZAd0USDGyS",
  "id" : 611321446502019072,
  "in_reply_to_status_id" : 611318028752400385,
  "created_at" : "2015-06-17 23:56:05 +0000",
  "in_reply_to_screen_name" : "padlet",
  "in_reply_to_user_id_str" : "24564180",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Padlet",
      "screen_name" : "padlet",
      "indices" : [ 0, 7 ],
      "id_str" : "24564180",
      "id" : 24564180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/a8C8SPNUqq",
      "expanded_url" : "http:\/\/padlet.com\/paulhibbitts\/stlhe2015",
      "display_url" : "padlet.com\/paulhibbitts\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "611318028752400385",
  "geo" : { },
  "id_str" : "611321189114384384",
  "in_reply_to_user_id" : 24564180,
  "text" : "@padlet Sure, it is http:\/\/t.co\/a8C8SPNUqq. At first my manual adds were not working, but now things are better.",
  "id" : 611321189114384384,
  "in_reply_to_status_id" : 611318028752400385,
  "created_at" : "2015-06-17 23:55:03 +0000",
  "in_reply_to_screen_name" : "padlet",
  "in_reply_to_user_id_str" : "24564180",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Padlet",
      "screen_name" : "padlet",
      "indices" : [ 0, 7 ],
      "id_str" : "24564180",
      "id" : 24564180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611314668473331712",
  "in_reply_to_user_id" : 24564180,
  "text" : "@padlet Incredibly, I just now tried to manually re-enter the posted answers and the first one literally just disappeared! Refund time?",
  "id" : 611314668473331712,
  "created_at" : "2015-06-17 23:29:09 +0000",
  "in_reply_to_screen_name" : "padlet",
  "in_reply_to_user_id_str" : "24564180",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Padlet",
      "screen_name" : "padlet",
      "indices" : [ 0, 7 ],
      "id_str" : "24564180",
      "id" : 24564180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/a8C8SPwjyS",
      "expanded_url" : "http:\/\/padlet.com\/paulhibbitts\/stlhe2015",
      "display_url" : "padlet.com\/paulhibbitts\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611308383619166208",
  "in_reply_to_user_id" : 24564180,
  "text" : "@padlet All posts entered by a remote participant at http:\/\/t.co\/a8C8SPwjyS have been lost. Can they be recovered? What happened?",
  "id" : 611308383619166208,
  "created_at" : "2015-06-17 23:04:10 +0000",
  "in_reply_to_screen_name" : "padlet",
  "in_reply_to_user_id_str" : "24564180",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Astorino",
      "screen_name" : "maryastorino",
      "indices" : [ 3, 16 ],
      "id_str" : "18876365",
      "id" : 18876365
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 18, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611307214586970113",
  "text" : "RT @maryastorino: #STLHE2015 Paul Hibbitts defines mobile learning as ubiquitous, situational, connected, and personal!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STLHE2015",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611248462491877376",
    "text" : "#STLHE2015 Paul Hibbitts defines mobile learning as ubiquitous, situational, connected, and personal!",
    "id" : 611248462491877376,
    "created_at" : "2015-06-17 19:06:04 +0000",
    "user" : {
      "name" : "Mary Astorino",
      "screen_name" : "maryastorino",
      "protected" : false,
      "id_str" : "18876365",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1325626654\/MaryHeadshot_normal.jpg",
      "id" : 18876365,
      "verified" : false
    }
  },
  "id" : 611307214586970113,
  "created_at" : "2015-06-17 22:59:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Ysq90efFzp",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/stlhe-2015-from-mobile-access-to-multidevice-learning-ecologies#\/",
      "display_url" : "slides.com\/paulhibbitts\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611297527409823746",
  "text" : "Thanks so much to everyone who attended today's session on multi-device learning ecologies! Slides are at http:\/\/t.co\/Ysq90efFzp #STLHE2015",
  "id" : 611297527409823746,
  "created_at" : "2015-06-17 22:21:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/B8vw8XojcA",
      "expanded_url" : "http:\/\/sched.co\/3NGi",
      "display_url" : "sched.co\/3NGi"
    } ]
  },
  "geo" : { },
  "id_str" : "611189182661136386",
  "text" : "What's happening in Salon 3 at noon today? Two new learning models, redefining mobile learning and more! http:\/\/t.co\/B8vw8XojcA #STLHE2015",
  "id" : 611189182661136386,
  "created_at" : "2015-06-17 15:10:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610950710075752450",
  "text" : "Looking forward to learning lots at #STLHE2015! Hope to discuss learning ecologies, dev. process, learner experience &amp; multi-device design.",
  "id" : 610950710075752450,
  "created_at" : "2015-06-16 23:22:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clifford Levy",
      "screen_name" : "cliffordlevy",
      "indices" : [ 3, 16 ],
      "id_str" : "54885334",
      "id" : 54885334
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 46, 54 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/cliffordlevy\/status\/609400254639812608\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/AVu9RBm98F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHUGLzXUsAA17tk.png",
      "id_str" : "609400124414930944",
      "id" : 609400124414930944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHUGLzXUsAA17tk.png",
      "sizes" : [ {
        "h" : 362,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AVu9RBm98F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610873470428270593",
  "text" : "RT @cliffordlevy: How important is mobile for @nytimes? We\u2019re blocking access to our home page on desktop in our building. http:\/\/t.co\/AVu9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 28, 36 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/cliffordlevy\/status\/609400254639812608\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/AVu9RBm98F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHUGLzXUsAA17tk.png",
        "id_str" : "609400124414930944",
        "id" : 609400124414930944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHUGLzXUsAA17tk.png",
        "sizes" : [ {
          "h" : 362,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/AVu9RBm98F"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609400254639812608",
    "text" : "How important is mobile for @nytimes? We\u2019re blocking access to our home page on desktop in our building. http:\/\/t.co\/AVu9RBm98F",
    "id" : 609400254639812608,
    "created_at" : "2015-06-12 16:41:57 +0000",
    "user" : {
      "name" : "Clifford Levy",
      "screen_name" : "cliffordlevy",
      "protected" : false,
      "id_str" : "54885334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688464541315911681\/0nqU6IwH_normal.png",
      "id" : 54885334,
      "verified" : true
    }
  },
  "id" : 610873470428270593,
  "created_at" : "2015-06-16 18:15:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 29, 38 ],
      "id_str" : "837060721",
      "id" : 837060721
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 43, 58 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/610848909875769344\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/NVWdiBsBtt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHor1qWUsAEeaLn.png",
      "id_str" : "610848900363104257",
      "id" : 610848900363104257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHor1qWUsAEeaLn.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/NVWdiBsBtt"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/610848909875769344\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/NVWdiBsBtt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHor2LLUAAEFmtI.png",
      "id_str" : "610848909175291905",
      "id" : 610848909175291905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHor2LLUAAEFmtI.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NVWdiBsBtt"
    } ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610848909875769344",
  "text" : "These two learning models by @m_travin and @hibbittsdesign will be explored Wednesday at noon in Salon 3. #STLHE2015 http:\/\/t.co\/NVWdiBsBtt",
  "id" : 610848909875769344,
  "created_at" : "2015-06-16 16:38:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610540484348350464",
  "text" : "As educators we need to redefine mobile learning for our multi-device connected world. Interested? Join me at #STLHE2015 this Wed (CON02.01)",
  "id" : 610540484348350464,
  "created_at" : "2015-06-15 20:12:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 0, 11 ],
      "id_str" : "91634720",
      "id" : 91634720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610521435384057856",
  "geo" : { },
  "id_str" : "610528136317374464",
  "in_reply_to_user_id" : 91634720,
  "text" : "@kenjeffery Wow, blogging about your experiences would be even better :-) I'd love to share your posts with my network too!",
  "id" : 610528136317374464,
  "in_reply_to_status_id" : 610521435384057856,
  "created_at" : "2015-06-15 19:23:45 +0000",
  "in_reply_to_screen_name" : "kenjeffery",
  "in_reply_to_user_id_str" : "91634720",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 3, 14 ],
      "id_str" : "91634720",
      "id" : 91634720
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 83, 98 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/6BF626c1bY",
      "expanded_url" : "http:\/\/bit.ly\/1Ig3Qbh",
      "display_url" : "bit.ly\/1Ig3Qbh"
    } ]
  },
  "geo" : { },
  "id_str" : "610518451258392576",
  "text" : "RT @kenjeffery: I'm working on some instructional design for the fall, and finding @hibbittsdesign ID model to be very helpful.\nhttp:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 67, 82 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/6BF626c1bY",
        "expanded_url" : "http:\/\/bit.ly\/1Ig3Qbh",
        "display_url" : "bit.ly\/1Ig3Qbh"
      } ]
    },
    "geo" : { },
    "id_str" : "610514565630001152",
    "text" : "I'm working on some instructional design for the fall, and finding @hibbittsdesign ID model to be very helpful.\nhttp:\/\/t.co\/6BF626c1bY",
    "id" : 610514565630001152,
    "created_at" : "2015-06-15 18:29:49 +0000",
    "user" : {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "protected" : false,
      "id_str" : "91634720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444954820244275200\/ojUn8z4n_normal.jpeg",
      "id" : 91634720,
      "verified" : false
    }
  },
  "id" : 610518451258392576,
  "created_at" : "2015-06-15 18:45:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 0, 11 ],
      "id_str" : "91634720",
      "id" : 91634720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610514565630001152",
  "geo" : { },
  "id_str" : "610517058804035584",
  "in_reply_to_user_id" : 91634720,
  "text" : "@kenjeffery Thanks Ken, I'd love to learn more about your experiences with the model.",
  "id" : 610517058804035584,
  "in_reply_to_status_id" : 610514565630001152,
  "created_at" : "2015-06-15 18:39:44 +0000",
  "in_reply_to_screen_name" : "kenjeffery",
  "in_reply_to_user_id_str" : "91634720",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinforest",
      "screen_name" : "tinforest",
      "indices" : [ 0, 10 ],
      "id_str" : "7337252",
      "id" : 7337252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610478689835356160",
  "in_reply_to_user_id" : 7337252,
  "text" : "@tinforest Thanks for the kind words kele. The ETUG Spring Workshop was really in top form (once again) too!",
  "id" : 610478689835356160,
  "created_at" : "2015-06-15 16:07:16 +0000",
  "in_reply_to_screen_name" : "tinforest",
  "in_reply_to_user_id_str" : "7337252",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 85, 93 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/1O8XrhyU1U",
      "expanded_url" : "https:\/\/twitter.com\/maryeburgess\/status\/609390417587535872",
      "display_url" : "twitter.com\/maryeburgess\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609487235486871552",
  "text" : "Lots to think about... looking forward to the Fall when I try out a BOBW approach w. @getgrav and #CanvasLMS at SFU. https:\/\/t.co\/1O8XrhyU1U",
  "id" : 609487235486871552,
  "created_at" : "2015-06-12 22:27:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609109878884278272",
  "geo" : { },
  "id_str" : "609110867162988544",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh Maybe I am too optimistic :-)",
  "id" : 609110867162988544,
  "in_reply_to_status_id" : 609109878884278272,
  "created_at" : "2015-06-11 21:32:02 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/eXJEeOS7eG",
      "expanded_url" : "https:\/\/twitter.com\/diesh\/status\/609104989508632577",
      "display_url" : "twitter.com\/diesh\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609105487171207169",
  "text" : "Finally! https:\/\/t.co\/eXJEeOS7eG",
  "id" : 609105487171207169,
  "created_at" : "2015-06-11 21:10:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UMW Moodle",
      "screen_name" : "UMWMoodle",
      "indices" : [ 0, 10 ],
      "id_str" : "330528923",
      "id" : 330528923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607921712319983617",
  "geo" : { },
  "id_str" : "609105310863654914",
  "in_reply_to_user_id" : 330528923,
  "text" : "@UMWMoodle I'd love to hear about your experiences! I am considering running unmoderated usability tests to help assess theme change issues.",
  "id" : 609105310863654914,
  "in_reply_to_status_id" : 607921712319983617,
  "created_at" : "2015-06-11 21:09:57 +0000",
  "in_reply_to_screen_name" : "UMWMoodle",
  "in_reply_to_user_id_str" : "330528923",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 130, 138 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 47, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609090025628631041",
  "text" : "Things are looking up for teaching CMPT 363 at #SFU this Fall. Big plans to take the online course companion to the next level w. @getgrav.",
  "id" : 609090025628631041,
  "created_at" : "2015-06-11 20:09:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/tXArLFpNeC",
      "expanded_url" : "https:\/\/workflowy.com\/s\/x5IjZIaAAP",
      "display_url" : "workflowy.com\/s\/x5IjZIaAAP"
    } ]
  },
  "geo" : { },
  "id_str" : "609060687550087168",
  "text" : "Outline for @STLHE2015 presentation \"From Mobile Access to Multi-device Learning Ecologies: A Case Study\" https:\/\/t.co\/tXArLFpNeC #STLHE2015",
  "id" : 609060687550087168,
  "created_at" : "2015-06-11 18:12:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Merholz",
      "screen_name" : "peterme",
      "indices" : [ 3, 11 ],
      "id_str" : "1154",
      "id" : 1154
    }, {
      "name" : "Bob Baxley",
      "screen_name" : "bbaxley",
      "indices" : [ 31, 39 ],
      "id_str" : "14161605",
      "id" : 14161605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/7QzEINIPlD",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=02VWKgNI1p4&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=02VWKg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609036650258178049",
  "text" : "RT @peterme: In three minutes, @bbaxley says more meaningful stuff about design, biz, and tech than most do in whole books:\nhttps:\/\/t.co\/7Q\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bob Baxley",
        "screen_name" : "bbaxley",
        "indices" : [ 18, 26 ],
        "id_str" : "14161605",
        "id" : 14161605
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/7QzEINIPlD",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=02VWKgNI1p4&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=02VWKg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "609033060890247168",
    "text" : "In three minutes, @bbaxley says more meaningful stuff about design, biz, and tech than most do in whole books:\nhttps:\/\/t.co\/7QzEINIPlD",
    "id" : 609033060890247168,
    "created_at" : "2015-06-11 16:22:51 +0000",
    "user" : {
      "name" : "Peter Merholz",
      "screen_name" : "peterme",
      "protected" : false,
      "id_str" : "1154",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766259960011370496\/e9t34B07_normal.jpg",
      "id" : 1154,
      "verified" : false
    }
  },
  "id" : 609036650258178049,
  "created_at" : "2015-06-11 16:37:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judy Chan",
      "screen_name" : "judycchan",
      "indices" : [ 0, 10 ],
      "id_str" : "46447378",
      "id" : 46447378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609031444585775108",
  "in_reply_to_user_id" : 46447378,
  "text" : "@judycchan Hi Judy, is there an official (or recommended) Twitter hashtag for the STLHE Vancouver conference?",
  "id" : 609031444585775108,
  "created_at" : "2015-06-11 16:16:26 +0000",
  "in_reply_to_screen_name" : "judycchan",
  "in_reply_to_user_id_str" : "46447378",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheTechChat",
      "screen_name" : "TheTechChat",
      "indices" : [ 3, 15 ],
      "id_str" : "19929470",
      "id" : 19929470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608684598009151488",
  "text" : "RT @TheTechChat: Consider: you can get an 84\" Surface Hub for only a few thousand dollars more than an Apple Watch edition. Two 55\" inch Hu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608673961895796736",
    "text" : "Consider: you can get an 84\" Surface Hub for only a few thousand dollars more than an Apple Watch edition. Two 55\" inch Hubs for a bit less.",
    "id" : 608673961895796736,
    "created_at" : "2015-06-10 16:35:55 +0000",
    "user" : {
      "name" : "TheTechChat",
      "screen_name" : "TheTechChat",
      "protected" : false,
      "id_str" : "19929470",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510926283316813824\/DS56E9Nb_normal.jpeg",
      "id" : 19929470,
      "verified" : false
    }
  },
  "id" : 608684598009151488,
  "created_at" : "2015-06-10 17:18:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 30, 39 ],
      "id_str" : "837060721",
      "id" : 837060721
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 44, 59 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/608669572502147072\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/V7GcWfisG4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHJtv_eUwAE03Ez.jpg",
      "id_str" : "608669570908340225",
      "id" : 608669570908340225,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHJtv_eUwAE03Ez.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/V7GcWfisG4"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/608669572502147072\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/V7GcWfisG4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHJtwDXUgAAj7M_.jpg",
      "id_str" : "608669571952705536",
      "id" : 608669571952705536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHJtwDXUgAAj7M_.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/V7GcWfisG4"
    } ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 79, 89 ]
    }, {
      "text" : "YVR",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608669572502147072",
  "text" : "A sneak peek at the models by @m_travin and @hibbittsdesign to be presented at #STLHE2015 in #YVR next Wed (CON02.01) http:\/\/t.co\/V7GcWfisG4",
  "id" : 608669572502147072,
  "created_at" : "2015-06-10 16:18:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 0, 11 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608308899192651778",
  "geo" : { },
  "id_str" : "608310299628666880",
  "in_reply_to_user_id" : 217880712,
  "text" : "@jimbobtyer I've decided to also include reference to the Kemp model as related background. Design-based Research model was also suggested.",
  "id" : 608310299628666880,
  "in_reply_to_status_id" : 608308899192651778,
  "created_at" : "2015-06-09 16:30:51 +0000",
  "in_reply_to_screen_name" : "jimbobtyer",
  "in_reply_to_user_id_str" : "217880712",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 0, 11 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608307694949310464",
  "geo" : { },
  "id_str" : "608308829990719488",
  "in_reply_to_user_id" : 217880712,
  "text" : "@jimbobtyer Quite well overall, thanks! I learned a lot. The Learning + Technology Development Model seemed to resonate the most.",
  "id" : 608308829990719488,
  "in_reply_to_status_id" : 608307694949310464,
  "created_at" : "2015-06-09 16:25:01 +0000",
  "in_reply_to_screen_name" : "jimbobtyer",
  "in_reply_to_user_id_str" : "217880712",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 10, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/qMHkXkUBkG",
      "expanded_url" : "http:\/\/1drv.ms\/1GwVu49",
      "display_url" : "1drv.ms\/1GwVu49"
    } ]
  },
  "geo" : { },
  "id_str" : "608307566678900736",
  "text" : "During my #etug session I mentioned a set of positive learner experience (LX) qualities - here is a worksheet to help http:\/\/t.co\/qMHkXkUBkG",
  "id" : 608307566678900736,
  "created_at" : "2015-06-09 16:20:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608305120644726784",
  "text" : "Creating digital learner experiences? The 3 core competencies to me are UX design, learning\/instructional design and technology development.",
  "id" : 608305120644726784,
  "created_at" : "2015-06-09 16:10:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/5STOjde0wN",
      "expanded_url" : "http:\/\/bit.ly\/1FMeJ32",
      "display_url" : "bit.ly\/1FMeJ32"
    } ]
  },
  "geo" : { },
  "id_str" : "608030149016027136",
  "text" : "RT @clintlalonde: Were you at #etug last week? Leave your feedback on the event http:\/\/t.co\/5STOjde0wN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/5STOjde0wN",
        "expanded_url" : "http:\/\/bit.ly\/1FMeJ32",
        "display_url" : "bit.ly\/1FMeJ32"
      } ]
    },
    "geo" : { },
    "id_str" : "608027858116603905",
    "text" : "Were you at #etug last week? Leave your feedback on the event http:\/\/t.co\/5STOjde0wN",
    "id" : 608027858116603905,
    "created_at" : "2015-06-08 21:48:32 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 608030149016027136,
  "created_at" : "2015-06-08 21:57:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 3, 15 ],
      "id_str" : "6271482",
      "id" : 6271482
    }, {
      "name" : "OpenEdUofG",
      "screen_name" : "OpenEdUofG",
      "indices" : [ 111, 122 ],
      "id_str" : "709981127080017923",
      "id" : 709981127080017923
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uofg",
      "indices" : [ 123, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/PbBogBZE41",
      "expanded_url" : "http:\/\/opened.uoguelph.ca\/news.aspx",
      "display_url" : "opened.uoguelph.ca\/news.aspx"
    } ]
  },
  "geo" : { },
  "id_str" : "608029472084746240",
  "text" : "RT @grantpotter: \"University of Guelph is taking steps to release the official mark in its entirety\" thank you @OpenEdUofG #uofg http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/known.networkeffects.ca\" rel=\"nofollow\"\u003Eknown-twitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenEdUofG",
        "screen_name" : "OpenEdUofG",
        "indices" : [ 94, 105 ],
        "id_str" : "709981127080017923",
        "id" : 709981127080017923
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "uofg",
        "indices" : [ 106, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/PbBogBZE41",
        "expanded_url" : "http:\/\/opened.uoguelph.ca\/news.aspx",
        "display_url" : "opened.uoguelph.ca\/news.aspx"
      } ]
    },
    "geo" : { },
    "id_str" : "607988396590546946",
    "text" : "\"University of Guelph is taking steps to release the official mark in its entirety\" thank you @OpenEdUofG #uofg http:\/\/t.co\/PbBogBZE41",
    "id" : 607988396590546946,
    "created_at" : "2015-06-08 19:11:44 +0000",
    "user" : {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "protected" : false,
      "id_str" : "6271482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639833921228640256\/S63CDenk_normal.jpg",
      "id" : 6271482,
      "verified" : false
    }
  },
  "id" : 608029472084746240,
  "created_at" : "2015-06-08 21:54:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/eDi9kWqtJT",
      "expanded_url" : "http:\/\/clintlalonde.net\/2015\/06\/08\/positive-moves-from-university-of-guelph-on-opened\/",
      "display_url" : "clintlalonde.net\/2015\/06\/08\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607969309189533697",
  "text" : "RT @clintlalonde: Positive moves from University of Guelph on\u00A0OpenEd http:\/\/t.co\/eDi9kWqtJT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/eDi9kWqtJT",
        "expanded_url" : "http:\/\/clintlalonde.net\/2015\/06\/08\/positive-moves-from-university-of-guelph-on-opened\/",
        "display_url" : "clintlalonde.net\/2015\/06\/08\/pos\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "607969136493260800",
    "text" : "Positive moves from University of Guelph on\u00A0OpenEd http:\/\/t.co\/eDi9kWqtJT",
    "id" : 607969136493260800,
    "created_at" : "2015-06-08 17:55:12 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 607969309189533697,
  "created_at" : "2015-06-08 17:55:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ZoE1bznLXg",
      "expanded_url" : "http:\/\/1drv.ms\/1EQqIM4",
      "display_url" : "1drv.ms\/1EQqIM4"
    } ]
  },
  "geo" : { },
  "id_str" : "607947663149916161",
  "text" : "Participant feedback\/questions about the learning models discussed in the closing #etug plenary are now available at http:\/\/t.co\/ZoE1bznLXg",
  "id" : 607947663149916161,
  "created_at" : "2015-06-08 16:29:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 3, 17 ],
      "id_str" : "260919324",
      "id" : 260919324
    }, {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 24, 31 ],
      "id_str" : "740343",
      "id" : 740343
    }, {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 38, 45 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TWP15",
      "indices" : [ 151, 152 ]
    } ],
    "urls" : [ {
      "indices" : [ 138, 152 ],
      "url" : "http:\/\/t.co\/qgCKxrNers",
      "expanded_url" : "http:\/\/blogs.ubc.ca\/teachwordpress\/2015\/06\/05\/week-2-join-us-for-a-hangout-on-june-8th\/",
      "display_url" : "blogs.ubc.ca\/teachwordpress\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607663193830203392",
  "text" : "RT @clhendricksbc: Join @cogdog &amp; @tanbob &amp; I for discussion of WordPress in teaching &amp; learning June 8, 12 Pacific\/3 Eastern http:\/\/t.co\/q\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alan Levine",
        "screen_name" : "cogdog",
        "indices" : [ 5, 12 ],
        "id_str" : "740343",
        "id" : 740343
      }, {
        "name" : "Tannis Morgan",
        "screen_name" : "tanbob",
        "indices" : [ 19, 26 ],
        "id_str" : "10817782",
        "id" : 10817782
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TWP15",
        "indices" : [ 142, 148 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/qgCKxrNers",
        "expanded_url" : "http:\/\/blogs.ubc.ca\/teachwordpress\/2015\/06\/05\/week-2-join-us-for-a-hangout-on-june-8th\/",
        "display_url" : "blogs.ubc.ca\/teachwordpress\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "607660860689907712",
    "text" : "Join @cogdog &amp; @tanbob &amp; I for discussion of WordPress in teaching &amp; learning June 8, 12 Pacific\/3 Eastern http:\/\/t.co\/qgCKxrNers #TWP15",
    "id" : 607660860689907712,
    "created_at" : "2015-06-07 21:30:13 +0000",
    "user" : {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "protected" : false,
      "id_str" : "260919324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726838525086208000\/46wx7Jih_normal.jpg",
      "id" : 260919324,
      "verified" : false
    }
  },
  "id" : 607663193830203392,
  "created_at" : "2015-06-07 21:39:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maureen Mackey",
      "screen_name" : "maureenamackey",
      "indices" : [ 0, 15 ],
      "id_str" : "43961502",
      "id" : 43961502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606928565020459008",
  "geo" : { },
  "id_str" : "607581159476756481",
  "in_reply_to_user_id" : 43961502,
  "text" : "@maureenamackey Thanks Maureen, it was my pleasure! I've also just posted all the collected feedback to the shared OneDrive folder.",
  "id" : 607581159476756481,
  "in_reply_to_status_id" : 606928565020459008,
  "created_at" : "2015-06-07 16:13:31 +0000",
  "in_reply_to_screen_name" : "maureenamackey",
  "in_reply_to_user_id_str" : "43961502",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "E. John Love",
      "screen_name" : "ejohnlove",
      "indices" : [ 0, 10 ],
      "id_str" : "33522674",
      "id" : 33522674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607028715676049409",
  "geo" : { },
  "id_str" : "607032483759034368",
  "in_reply_to_user_id" : 33522674,
  "text" : "@ejohnlove Many thanks for the kind words John!",
  "id" : 607032483759034368,
  "in_reply_to_status_id" : 607028715676049409,
  "created_at" : "2015-06-06 03:53:16 +0000",
  "in_reply_to_screen_name" : "ejohnlove",
  "in_reply_to_user_id_str" : "33522674",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 39, 44 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/0h7W2CV590",
      "expanded_url" : "http:\/\/twitter.com\/kenjeffery\/status\/606952190532386816",
      "display_url" : "twitter.com\/kenjeffery\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606965007939534848",
  "text" : "RT @BCcampus: Until next year! Thanks, @ETUG. http:\/\/t.co\/0h7W2CV590",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 25, 30 ],
        "id_str" : "17102936",
        "id" : 17102936
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/0h7W2CV590",
        "expanded_url" : "http:\/\/twitter.com\/kenjeffery\/status\/606952190532386816",
        "display_url" : "twitter.com\/kenjeffery\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606955490594168832",
    "text" : "Until next year! Thanks, @ETUG. http:\/\/t.co\/0h7W2CV590",
    "id" : 606955490594168832,
    "created_at" : "2015-06-05 22:47:20 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 606965007939534848,
  "created_at" : "2015-06-05 23:25:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/cIpUOe2jZo",
      "expanded_url" : "https:\/\/twitter.com\/clhendricksbc\/status\/606951933237039104",
      "display_url" : "twitter.com\/clhendricksbc\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606962650254147584",
  "text" : "Thanks to everyone who attended, it was a privilege to deliver the closing #etug plenary! https:\/\/t.co\/cIpUOe2jZo",
  "id" : 606962650254147584,
  "created_at" : "2015-06-05 23:15:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Linkletter",
      "screen_name" : "Linkletter",
      "indices" : [ 0, 11 ],
      "id_str" : "804325",
      "id" : 804325
    }, {
      "name" : "Slides",
      "screen_name" : "slides",
      "indices" : [ 30, 37 ],
      "id_str" : "813740730",
      "id" : 813740730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606887689644699648",
  "geo" : { },
  "id_str" : "606888504455340032",
  "in_reply_to_user_id" : 804325,
  "text" : "@Linkletter Awesome :-) Hakim @slides is an amazing developer!",
  "id" : 606888504455340032,
  "in_reply_to_status_id" : 606887689644699648,
  "created_at" : "2015-06-05 18:21:09 +0000",
  "in_reply_to_screen_name" : "Linkletter",
  "in_reply_to_user_id_str" : "804325",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Linkletter",
      "screen_name" : "Linkletter",
      "indices" : [ 0, 11 ],
      "id_str" : "804325",
      "id" : 804325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/abG6zmYU9l",
      "expanded_url" : "http:\/\/slides.com",
      "display_url" : "slides.com"
    } ]
  },
  "geo" : { },
  "id_str" : "606887186319835136",
  "in_reply_to_user_id" : 804325,
  "text" : "@Linkletter  Great to see there is another fan of http:\/\/t.co\/abG6zmYU9l :-)",
  "id" : 606887186319835136,
  "created_at" : "2015-06-05 18:15:55 +0000",
  "in_reply_to_screen_name" : "Linkletter",
  "in_reply_to_user_id_str" : "804325",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 3, 11 ],
      "id_str" : "739293",
      "id" : 739293
    }, {
      "name" : "University of Guelph",
      "screen_name" : "uofg",
      "indices" : [ 17, 22 ],
      "id_str" : "16134692",
      "id" : 16134692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenEd",
      "indices" : [ 96, 103 ]
    }, {
      "text" : "higherEd",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/NdDCnO8bZ3",
      "expanded_url" : "http:\/\/clintlalonde.net\/2015\/06\/01\/on-using-opened-an-opportunity\/",
      "display_url" : "clintlalonde.net\/2015\/06\/01\/on-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606690749703290880",
  "text" : "RT @courosa: The @uofg move to trademark the term 'OpenEd' is absolutely shameful; an insult to #OpenEd &amp; #higherEd communities. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "University of Guelph",
        "screen_name" : "uofg",
        "indices" : [ 4, 9 ],
        "id_str" : "16134692",
        "id" : 16134692
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenEd",
        "indices" : [ 83, 90 ]
      }, {
        "text" : "higherEd",
        "indices" : [ 97, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/NdDCnO8bZ3",
        "expanded_url" : "http:\/\/clintlalonde.net\/2015\/06\/01\/on-using-opened-an-opportunity\/",
        "display_url" : "clintlalonde.net\/2015\/06\/01\/on-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606627556750561280",
    "text" : "The @uofg move to trademark the term 'OpenEd' is absolutely shameful; an insult to #OpenEd &amp; #higherEd communities. http:\/\/t.co\/NdDCnO8bZ3",
    "id" : 606627556750561280,
    "created_at" : "2015-06-05 01:04:14 +0000",
    "user" : {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "protected" : false,
      "id_str" : "739293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480186733221249027\/bzI2RIfo_normal.jpeg",
      "id" : 739293,
      "verified" : false
    }
  },
  "id" : 606690749703290880,
  "created_at" : "2015-06-05 05:15:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 3, 10 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "University of Guelph",
      "screen_name" : "uofg",
      "indices" : [ 33, 38 ],
      "id_str" : "16134692",
      "id" : 16134692
    }, {
      "name" : "OpenEdUofG",
      "screen_name" : "OpenEdUofG",
      "indices" : [ 98, 109 ],
      "id_str" : "709981127080017923",
      "id" : 709981127080017923
    }, {
      "name" : "Michelle Fach",
      "screen_name" : "MichelleFach",
      "indices" : [ 110, 123 ],
      "id_str" : "99817149",
      "id" : 99817149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uofg",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "opened",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/uMmagdnTVU",
      "expanded_url" : "http:\/\/abject.ca\/questionsforuofg\/",
      "display_url" : "abject.ca\/questionsforuo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606684990496083968",
  "text" : "RT @brlamb: I have questions for @uofg on its trademark of \"OpenEd\": http:\/\/t.co\/uMmagdnTVU #uofg @OpenEdUofG @MichelleFach #opened",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "University of Guelph",
        "screen_name" : "uofg",
        "indices" : [ 21, 26 ],
        "id_str" : "16134692",
        "id" : 16134692
      }, {
        "name" : "OpenEdUofG",
        "screen_name" : "OpenEdUofG",
        "indices" : [ 86, 97 ],
        "id_str" : "709981127080017923",
        "id" : 709981127080017923
      }, {
        "name" : "Michelle Fach",
        "screen_name" : "MichelleFach",
        "indices" : [ 98, 111 ],
        "id_str" : "99817149",
        "id" : 99817149
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "uofg",
        "indices" : [ 80, 85 ]
      }, {
        "text" : "opened",
        "indices" : [ 112, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/uMmagdnTVU",
        "expanded_url" : "http:\/\/abject.ca\/questionsforuofg\/",
        "display_url" : "abject.ca\/questionsforuo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606673575358156800",
    "text" : "I have questions for @uofg on its trademark of \"OpenEd\": http:\/\/t.co\/uMmagdnTVU #uofg @OpenEdUofG @MichelleFach #opened",
    "id" : 606673575358156800,
    "created_at" : "2015-06-05 04:07:06 +0000",
    "user" : {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "protected" : false,
      "id_str" : "745903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671910130498203649\/btEUG3ES_normal.jpg",
      "id" : 745903,
      "verified" : false
    }
  },
  "id" : 606684990496083968,
  "created_at" : "2015-06-05 04:52:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/606620325141282816\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/AW3faZn1EL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGsl-KOUcAAC8za.png",
      "id_str" : "606620324637995008",
      "id" : 606620324637995008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGsl-KOUcAAC8za.png",
      "sizes" : [ {
        "h" : 196,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 1048
      }, {
        "h" : 590,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/AW3faZn1EL"
    } ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 53, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606620325141282816",
  "text" : "Status: Inspired by the people and sessions today at #etug slide revisions are in full swing for the closing plenary! http:\/\/t.co\/AW3faZn1EL",
  "id" : 606620325141282816,
  "created_at" : "2015-06-05 00:35:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Yip",
      "screen_name" : "denniskdyip",
      "indices" : [ 3, 15 ],
      "id_str" : "174739964",
      "id" : 174739964
    }, {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "indices" : [ 35, 47 ],
      "id_str" : "19812150",
      "id" : 19812150
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 67, 72 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/denniskdyip\/status\/606540010427277313\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/dKXJstyKFS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGrc69cUAAAvFWN.jpg",
      "id_str" : "606540005318590464",
      "id" : 606540005318590464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGrc69cUAAAvFWN.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dKXJstyKFS"
    } ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 51, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606589614887804928",
  "text" : "RT @denniskdyip: Inspiring talk by @drtonybates at #ETUG workshop. @etug http:\/\/t.co\/dKXJstyKFS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tony Bates",
        "screen_name" : "drtonybates",
        "indices" : [ 18, 30 ],
        "id_str" : "19812150",
        "id" : 19812150
      }, {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 50, 55 ],
        "id_str" : "17102936",
        "id" : 17102936
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/denniskdyip\/status\/606540010427277313\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/dKXJstyKFS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGrc69cUAAAvFWN.jpg",
        "id_str" : "606540005318590464",
        "id" : 606540005318590464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGrc69cUAAAvFWN.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dKXJstyKFS"
      } ],
      "hashtags" : [ {
        "text" : "ETUG",
        "indices" : [ 34, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606540010427277313",
    "text" : "Inspiring talk by @drtonybates at #ETUG workshop. @etug http:\/\/t.co\/dKXJstyKFS",
    "id" : 606540010427277313,
    "created_at" : "2015-06-04 19:16:22 +0000",
    "user" : {
      "name" : "Dennis Yip",
      "screen_name" : "denniskdyip",
      "protected" : false,
      "id_str" : "174739964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703760154945171456\/ERFlFxby_normal.jpg",
      "id" : 174739964,
      "verified" : false
    }
  },
  "id" : 606589614887804928,
  "created_at" : "2015-06-04 22:33:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606586128519421952",
  "text" : "Showtime in less than 24 hours.",
  "id" : 606586128519421952,
  "created_at" : "2015-06-04 22:19:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606584211198205955",
  "text" : "Each and every session attended at #etug today has been wonderful! Lots of interesting discussions and friendly faces too.",
  "id" : 606584211198205955,
  "created_at" : "2015-06-04 22:12:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Griffiths",
      "screen_name" : "brettgri",
      "indices" : [ 3, 12 ],
      "id_str" : "32252744",
      "id" : 32252744
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/brettgri\/status\/606555158848208896\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/1uqbrS1Zmg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGrqlILUYAANuVr.jpg",
      "id_str" : "606555023405768704",
      "id" : 606555023405768704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGrqlILUYAANuVr.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1uqbrS1Zmg"
    } ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 14, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606565492258504704",
  "text" : "RT @brettgri: #etug SFU observatory http:\/\/t.co\/1uqbrS1Zmg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/brettgri\/status\/606555158848208896\/photo\/1",
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/1uqbrS1Zmg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGrqlILUYAANuVr.jpg",
        "id_str" : "606555023405768704",
        "id" : 606555023405768704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGrqlILUYAANuVr.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1uqbrS1Zmg"
      } ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606555158848208896",
    "text" : "#etug SFU observatory http:\/\/t.co\/1uqbrS1Zmg",
    "id" : 606555158848208896,
    "created_at" : "2015-06-04 20:16:33 +0000",
    "user" : {
      "name" : "Brett Griffiths",
      "screen_name" : "brettgri",
      "protected" : false,
      "id_str" : "32252744",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609098493395779584\/cjPByie-_normal.jpg",
      "id" : 32252744,
      "verified" : false
    }
  },
  "id" : 606565492258504704,
  "created_at" : "2015-06-04 20:57:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Burgess",
      "screen_name" : "maryeburgess",
      "indices" : [ 3, 16 ],
      "id_str" : "24827526",
      "id" : 24827526
    }, {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "indices" : [ 31, 43 ],
      "id_str" : "19812150",
      "id" : 19812150
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606557305484644353",
  "text" : "RT @maryeburgess: Not only did @drtonybates publish his textbook openly, he wrote it openly too, asked for feedback. Seeing more of this an\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tony Bates",
        "screen_name" : "drtonybates",
        "indices" : [ 13, 25 ],
        "id_str" : "19812150",
        "id" : 19812150
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606523899283685377",
    "text" : "Not only did @drtonybates publish his textbook openly, he wrote it openly too, asked for feedback. Seeing more of this and love it. #etug",
    "id" : 606523899283685377,
    "created_at" : "2015-06-04 18:12:20 +0000",
    "user" : {
      "name" : "Mary Burgess",
      "screen_name" : "maryeburgess",
      "protected" : false,
      "id_str" : "24827526",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2929023927\/c6f0384e82b21e780712fd0b023c024c_normal.jpeg",
      "id" : 24827526,
      "verified" : false
    }
  },
  "id" : 606557305484644353,
  "created_at" : "2015-06-04 20:25:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 3, 14 ],
      "id_str" : "91634720",
      "id" : 91634720
    }, {
      "name" : "Simon Bates",
      "screen_name" : "simonpbates",
      "indices" : [ 105, 117 ],
      "id_str" : "138373277",
      "id" : 138373277
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kenjeffery\/status\/606495147220557825\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/W8hmzVMh7B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGq0HrVUYAAMa2S.jpg",
      "id_str" : "606495143818977280",
      "id" : 606495143818977280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGq0HrVUYAAMa2S.jpg",
      "sizes" : [ {
        "h" : 754,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 754,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/W8hmzVMh7B"
    } ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 118, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606557196244033537",
  "text" : "RT @kenjeffery: Changing how we teach through technology. Increased through digital reach and unbundling @simonpbates #ETUG http:\/\/t.co\/W8h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Simon Bates",
        "screen_name" : "simonpbates",
        "indices" : [ 89, 101 ],
        "id_str" : "138373277",
        "id" : 138373277
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kenjeffery\/status\/606495147220557825\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/W8hmzVMh7B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGq0HrVUYAAMa2S.jpg",
        "id_str" : "606495143818977280",
        "id" : 606495143818977280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGq0HrVUYAAMa2S.jpg",
        "sizes" : [ {
          "h" : 754,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 754,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/W8hmzVMh7B"
      } ],
      "hashtags" : [ {
        "text" : "ETUG",
        "indices" : [ 102, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606495147220557825",
    "text" : "Changing how we teach through technology. Increased through digital reach and unbundling @simonpbates #ETUG http:\/\/t.co\/W8hmzVMh7B",
    "id" : 606495147220557825,
    "created_at" : "2015-06-04 16:18:05 +0000",
    "user" : {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "protected" : false,
      "id_str" : "91634720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444954820244275200\/ojUn8z4n_normal.jpeg",
      "id" : 91634720,
      "verified" : false
    }
  },
  "id" : 606557196244033537,
  "created_at" : "2015-06-04 20:24:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 3, 11 ],
      "id_str" : "5690792",
      "id" : 5690792
    }, {
      "name" : "EdMedia @SFU",
      "screen_name" : "EdMediaSFU",
      "indices" : [ 51, 62 ],
      "id_str" : "1428999450",
      "id" : 1428999450
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 13, 18 ]
    }, {
      "text" : "periscope",
      "indices" : [ 93, 103 ]
    }, {
      "text" : "meerkat",
      "indices" : [ 105, 113 ]
    }, {
      "text" : "ds106radio",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/1IzwcA5NKr",
      "expanded_url" : "http:\/\/etug.ca\/2015\/05\/19\/spring-workshop-2015-keynote-and-facilitators\/",
      "display_url" : "etug.ca\/2015\/05\/19\/spr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606480548404432896",
  "text" : "RT @draggin: #ETUG day 2 is in full effect! Follow @EdMediaSFU for coverage via live tweets, #periscope, #meerkat, #ds106radio http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EdMedia @SFU",
        "screen_name" : "EdMediaSFU",
        "indices" : [ 38, 49 ],
        "id_str" : "1428999450",
        "id" : 1428999450
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ETUG",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "periscope",
        "indices" : [ 80, 90 ]
      }, {
        "text" : "meerkat",
        "indices" : [ 92, 100 ]
      }, {
        "text" : "ds106radio",
        "indices" : [ 102, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/1IzwcA5NKr",
        "expanded_url" : "http:\/\/etug.ca\/2015\/05\/19\/spring-workshop-2015-keynote-and-facilitators\/",
        "display_url" : "etug.ca\/2015\/05\/19\/spr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606477058865111040",
    "text" : "#ETUG day 2 is in full effect! Follow @EdMediaSFU for coverage via live tweets, #periscope, #meerkat, #ds106radio http:\/\/t.co\/1IzwcA5NKr",
    "id" : 606477058865111040,
    "created_at" : "2015-06-04 15:06:13 +0000",
    "user" : {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "protected" : false,
      "id_str" : "5690792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749667549248270336\/7VoQZUTn_normal.jpg",
      "id" : 5690792,
      "verified" : false
    }
  },
  "id" : 606480548404432896,
  "created_at" : "2015-06-04 15:20:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daryl Claudio",
      "screen_name" : "darylclaudio",
      "indices" : [ 0, 13 ],
      "id_str" : "14256762",
      "id" : 14256762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606292174443937792",
  "geo" : { },
  "id_str" : "606299930974519296",
  "in_reply_to_user_id" : 14256762,
  "text" : "@darylclaudio I've been super happy with Grav too!",
  "id" : 606299930974519296,
  "in_reply_to_status_id" : 606292174443937792,
  "created_at" : "2015-06-04 03:22:22 +0000",
  "in_reply_to_screen_name" : "darylclaudio",
  "in_reply_to_user_id_str" : "14256762",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Irvine",
      "screen_name" : "_valeriei",
      "indices" : [ 3, 13 ],
      "id_str" : "40426722",
      "id" : 40426722
    }, {
      "name" : "University of Guelph",
      "screen_name" : "uofg",
      "indices" : [ 15, 20 ],
      "id_str" : "16134692",
      "id" : 16134692
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 60, 73 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uofg",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "etug",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606156028195971074",
  "text" : "RT @_valeriei: @uofg Every. Single. Day. I'm going to tweet @clintlalonde's post on ur pathetic move to obscure open practices to a tag\/per\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "University of Guelph",
        "screen_name" : "uofg",
        "indices" : [ 0, 5 ],
        "id_str" : "16134692",
        "id" : 16134692
      }, {
        "name" : "Clint Lalonde",
        "screen_name" : "clintlalonde",
        "indices" : [ 45, 58 ],
        "id_str" : "12991032",
        "id" : 12991032
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "uofg",
        "indices" : [ 128, 133 ]
      }, {
        "text" : "etug",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605898298851880962",
    "in_reply_to_user_id" : 16134692,
    "text" : "@uofg Every. Single. Day. I'm going to tweet @clintlalonde's post on ur pathetic move to obscure open practices to a tag\/person #uofg #etug",
    "id" : 605898298851880962,
    "created_at" : "2015-06-03 00:46:26 +0000",
    "in_reply_to_screen_name" : "uofg",
    "in_reply_to_user_id_str" : "16134692",
    "user" : {
      "name" : "Valerie Irvine",
      "screen_name" : "_valeriei",
      "protected" : false,
      "id_str" : "40426722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2855532095\/f4cd524272ad93e655bfa9f215f4b363_normal.jpeg",
      "id" : 40426722,
      "verified" : false
    }
  },
  "id" : 606156028195971074,
  "created_at" : "2015-06-03 17:50:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606142346829258752",
  "text" : "Finding that a hypothesis is not just a means to view design decisions, but also as a way to frame entire (re)design projects. Comments?",
  "id" : 606142346829258752,
  "created_at" : "2015-06-03 16:56:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rubeli",
      "screen_name" : "drubeli",
      "indices" : [ 0, 8 ],
      "id_str" : "17217620",
      "id" : 17217620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606118587791601664",
  "geo" : { },
  "id_str" : "606118836782260224",
  "in_reply_to_user_id" : 17217620,
  "text" : "@drubeli Sounds great, cheers!",
  "id" : 606118836782260224,
  "in_reply_to_status_id" : 606118587791601664,
  "created_at" : "2015-06-03 15:22:46 +0000",
  "in_reply_to_screen_name" : "drubeli",
  "in_reply_to_user_id_str" : "17217620",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rubeli",
      "screen_name" : "drubeli",
      "indices" : [ 0, 8 ],
      "id_str" : "17217620",
      "id" : 17217620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606117566302449664",
  "geo" : { },
  "id_str" : "606118271050391554",
  "in_reply_to_user_id" : 17217620,
  "text" : "@drubeli I won't be at BBY until the Workshop. Let's try to connect again soon, maybe STLHE?",
  "id" : 606118271050391554,
  "in_reply_to_status_id" : 606117566302449664,
  "created_at" : "2015-06-03 15:20:31 +0000",
  "in_reply_to_screen_name" : "drubeli",
  "in_reply_to_user_id_str" : "17217620",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rubeli",
      "screen_name" : "drubeli",
      "indices" : [ 0, 8 ],
      "id_str" : "17217620",
      "id" : 17217620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605936188273225728",
  "geo" : { },
  "id_str" : "606116937806979072",
  "in_reply_to_user_id" : 17217620,
  "text" : "@drubeli Thanks David! Will you be attending the Spring Workshop?",
  "id" : 606116937806979072,
  "in_reply_to_status_id" : 605936188273225728,
  "created_at" : "2015-06-03 15:15:13 +0000",
  "in_reply_to_screen_name" : "drubeli",
  "in_reply_to_user_id_str" : "17217620",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 3, 10 ],
      "id_str" : "745903",
      "id" : 745903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/3vF7ntz8zx",
      "expanded_url" : "http:\/\/clintlalonde.net\/2015\/06\/01\/on-using-opened-an-opportunity\/",
      "display_url" : "clintlalonde.net\/2015\/06\/01\/on-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605894067411550209",
  "text" : "RT @brlamb: Has anyone from the University of Guelph addressed why they needed to trademark term \"OpenED\" and restrict its use? http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/3vF7ntz8zx",
        "expanded_url" : "http:\/\/clintlalonde.net\/2015\/06\/01\/on-using-opened-an-opportunity\/",
        "display_url" : "clintlalonde.net\/2015\/06\/01\/on-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605766576013328384",
    "text" : "Has anyone from the University of Guelph addressed why they needed to trademark term \"OpenED\" and restrict its use? http:\/\/t.co\/3vF7ntz8zx",
    "id" : 605766576013328384,
    "created_at" : "2015-06-02 16:03:00 +0000",
    "user" : {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "protected" : false,
      "id_str" : "745903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671910130498203649\/btEUG3ES_normal.jpg",
      "id" : 745903,
      "verified" : false
    }
  },
  "id" : 605894067411550209,
  "created_at" : "2015-06-03 00:29:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 3, 15 ],
      "id_str" : "6271482",
      "id" : 6271482
    }, {
      "name" : "OpenEdUofG",
      "screen_name" : "OpenEdUofG",
      "indices" : [ 21, 32 ],
      "id_str" : "709981127080017923",
      "id" : 709981127080017923
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "openeducation",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/ypw6OeobVk",
      "expanded_url" : "http:\/\/known.networkeffects.ca\/2015\/hey-openeduofg-doesnt-trademarking-the-term-opened-run-counter-to",
      "display_url" : "known.networkeffects.ca\/2015\/hey-opene\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605880876187066368",
  "text" : "RT @grantpotter: hey @OpenEdUofG ... doesn't trademarking the term #opened run counter to #openeducation values &amp; practice? Please .. http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/known.networkeffects.ca\" rel=\"nofollow\"\u003Eknown-twitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenEdUofG",
        "screen_name" : "OpenEdUofG",
        "indices" : [ 4, 15 ],
        "id_str" : "709981127080017923",
        "id" : 709981127080017923
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened",
        "indices" : [ 50, 57 ]
      }, {
        "text" : "openeducation",
        "indices" : [ 73, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/ypw6OeobVk",
        "expanded_url" : "http:\/\/known.networkeffects.ca\/2015\/hey-openeduofg-doesnt-trademarking-the-term-opened-run-counter-to",
        "display_url" : "known.networkeffects.ca\/2015\/hey-opene\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605805209013485570",
    "text" : "hey @OpenEdUofG ... doesn't trademarking the term #opened run counter to #openeducation values &amp; practice? Please .. http:\/\/t.co\/ypw6OeobVk",
    "id" : 605805209013485570,
    "created_at" : "2015-06-02 18:36:31 +0000",
    "user" : {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "protected" : false,
      "id_str" : "6271482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639833921228640256\/S63CDenk_normal.jpg",
      "id" : 6271482,
      "verified" : false
    }
  },
  "id" : 605880876187066368,
  "created_at" : "2015-06-02 23:37:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605838103425613828",
  "text" : "Positive learner experience goals:\n\u2713Engaging\n\u2713Convenient\n\u2713Organized\n\u2713Relevant\n\u2713Enjoyable\n\nMore to share at #etug Spring15 plenary on Friday!",
  "id" : 605838103425613828,
  "created_at" : "2015-06-02 20:47:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Skelton",
      "screen_name" : "bskelton",
      "indices" : [ 3, 12 ],
      "id_str" : "644813",
      "id" : 644813
    }, {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 81, 97 ],
      "id_str" : "17349291",
      "id" : 17349291
    }, {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 100, 115 ],
      "id_str" : "1122631",
      "id" : 1122631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/vsLLcgmVDE",
      "expanded_url" : "http:\/\/www.designcontentconf.com",
      "display_url" : "designcontentconf.com"
    } ]
  },
  "geo" : { },
  "id_str" : "605825024398794753",
  "text" : "RT @bskelton: Awesome lineup at the Design + Content conference in YVR including @HabaneroConsult's @MalloryOConnor. http:\/\/t.co\/vsLLcgmVDE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Habanero",
        "screen_name" : "HabaneroConsult",
        "indices" : [ 67, 83 ],
        "id_str" : "17349291",
        "id" : 17349291
      }, {
        "name" : "Mallory O'Connor",
        "screen_name" : "MalloryOConnor",
        "indices" : [ 86, 101 ],
        "id_str" : "1122631",
        "id" : 1122631
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/vsLLcgmVDE",
        "expanded_url" : "http:\/\/www.designcontentconf.com",
        "display_url" : "designcontentconf.com"
      } ]
    },
    "geo" : { },
    "id_str" : "605379231745482753",
    "text" : "Awesome lineup at the Design + Content conference in YVR including @HabaneroConsult's @MalloryOConnor. http:\/\/t.co\/vsLLcgmVDE",
    "id" : 605379231745482753,
    "created_at" : "2015-06-01 14:23:50 +0000",
    "user" : {
      "name" : "Ben Skelton",
      "screen_name" : "bskelton",
      "protected" : false,
      "id_str" : "644813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618855036924227584\/LkjaRAye_normal.jpg",
      "id" : 644813,
      "verified" : false
    }
  },
  "id" : 605825024398794753,
  "created_at" : "2015-06-02 19:55:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 105, 113 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/FEuk11jmBS",
      "expanded_url" : "http:\/\/etug.ca\/2015\/05\/28\/t-e-l-l-summary-may-enhancing-the-online-experience-for-students-and-instructors-with-a-modern-flat-file-cms\/",
      "display_url" : "etug.ca\/2015\/05\/28\/t-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605824390777831426",
  "text" : "View my recorded presentation about enhancing student experience w. a modern flat-file CMS (in this case @getgrav) http:\/\/t.co\/FEuk11jmBS",
  "id" : 605824390777831426,
  "created_at" : "2015-06-02 19:52:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth Walton",
      "screen_name" : "BethWalton81",
      "indices" : [ 0, 13 ],
      "id_str" : "321759856",
      "id" : 321759856
    }, {
      "name" : "Embedly",
      "screen_name" : "embedly",
      "indices" : [ 14, 22 ],
      "id_str" : "82485597",
      "id" : 82485597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605544087215861760",
  "geo" : { },
  "id_str" : "605555464466661376",
  "in_reply_to_user_id" : 321759856,
  "text" : "@BethWalton81 @embedly Yes, by adding &lt;style&gt;iframe.embedly-card\u007Bfloat:left;\u007D&lt;\/style&gt; before the embedly object, HTH.",
  "id" : 605555464466661376,
  "in_reply_to_status_id" : 605544087215861760,
  "created_at" : "2015-06-02 02:04:08 +0000",
  "in_reply_to_screen_name" : "BethWalton81",
  "in_reply_to_user_id_str" : "321759856",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/oTK388UjwR",
      "expanded_url" : "http:\/\/www.pexels.com\/",
      "display_url" : "pexels.com"
    } ]
  },
  "geo" : { },
  "id_str" : "605493594485424128",
  "text" : "RT @cogdog: Just stumbled into Pexels-- stock photos site, all licensed CC0 http:\/\/t.co\/oTK388UjwR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/oTK388UjwR",
        "expanded_url" : "http:\/\/www.pexels.com\/",
        "display_url" : "pexels.com"
      } ]
    },
    "geo" : { },
    "id_str" : "605450990062432256",
    "text" : "Just stumbled into Pexels-- stock photos site, all licensed CC0 http:\/\/t.co\/oTK388UjwR",
    "id" : 605450990062432256,
    "created_at" : "2015-06-01 19:08:59 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 605493594485424128,
  "created_at" : "2015-06-01 21:58:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 31, 36 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Simon Bates",
      "screen_name" : "simonpbates",
      "indices" : [ 62, 74 ],
      "id_str" : "138373277",
      "id" : 138373277
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 81, 96 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "proflearn",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605474159485804544",
  "text" : "RT @BCcampus: Starts Thursday, @ETUG Spring15 High5! Keynotes @simonpbates &amp; @hibbittsdesign ttp:\/\/ow.ly\/NJCK6 #proflearn h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 17, 22 ],
        "id_str" : "17102936",
        "id" : 17102936
      }, {
        "name" : "Simon Bates",
        "screen_name" : "simonpbates",
        "indices" : [ 48, 60 ],
        "id_str" : "138373277",
        "id" : 138373277
      }, {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 67, 82 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "proflearn",
        "indices" : [ 101, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605467749163364352",
    "text" : "Starts Thursday, @ETUG Spring15 High5! Keynotes @simonpbates &amp; @hibbittsdesign ttp:\/\/ow.ly\/NJCK6 #proflearn h",
    "id" : 605467749163364352,
    "created_at" : "2015-06-01 20:15:35 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 605474159485804544,
  "created_at" : "2015-06-01 20:41:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605473663731654656",
  "text" : "What is learner experience design? Not a subset of UX design but the intersection of UX design, learning design and technology development.",
  "id" : 605473663731654656,
  "created_at" : "2015-06-01 20:39:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]