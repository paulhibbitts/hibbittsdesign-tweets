Grailbird.data.tweets_2011_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinheed1",
      "screen_name" : "ugleah",
      "indices" : [ 125, 132 ],
      "id_str" : "2562345146",
      "id" : 2562345146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31127674122412032",
  "text" : "Finding a lot of new possibilities by redefining my role on a current project from \"designer\" to \"design facilitator\". Kudos @ugleah",
  "id" : 31127674122412032,
  "created_at" : "2011-01-28 23:13:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Analytic Design Grp",
      "screen_name" : "Analytic_Design",
      "indices" : [ 3, 19 ],
      "id_str" : "150458565",
      "id" : 150458565
    }, {
      "name" : "thomas clifford",
      "screen_name" : "tommytrc",
      "indices" : [ 78, 87 ],
      "id_str" : "5683952",
      "id" : 5683952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 73 ],
      "url" : "http:\/\/t.co\/7B3mAOb",
      "expanded_url" : "http:\/\/tommytrc.posterous.com\/happy-27th-birthday-macintosh",
      "display_url" : "tommytrc.posterous.com\/happy-27th-bir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "29689009298997248",
  "text" : "RT @Analytic_Design: Happy 27th Birthday, Macintosh!! http:\/\/t.co\/7B3mAOb via @tommytrc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "thomas clifford",
        "screen_name" : "tommytrc",
        "indices" : [ 57, 66 ],
        "id_str" : "5683952",
        "id" : 5683952
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 52 ],
        "url" : "http:\/\/t.co\/7B3mAOb",
        "expanded_url" : "http:\/\/tommytrc.posterous.com\/happy-27th-birthday-macintosh",
        "display_url" : "tommytrc.posterous.com\/happy-27th-bir\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "29661262195466240",
    "text" : "Happy 27th Birthday, Macintosh!! http:\/\/t.co\/7B3mAOb via @tommytrc",
    "id" : 29661262195466240,
    "created_at" : "2011-01-24 22:06:10 +0000",
    "user" : {
      "name" : "Analytic Design Grp",
      "screen_name" : "Analytic_Design",
      "protected" : true,
      "id_str" : "150458565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000507460003\/e6bf05958a2cd9603569f7f560d7e4c9_normal.jpeg",
      "id" : 150458565,
      "verified" : false
    }
  },
  "id" : 29689009298997248,
  "created_at" : "2011-01-24 23:56:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott W. Ambler",
      "screen_name" : "scottwambler",
      "indices" : [ 3, 16 ],
      "id_str" : "61747648",
      "id" : 61747648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28288264028819457",
  "text" : "RT @scottwambler: Want to improve team morale?  Provide learning opportunities for them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28262492106915841",
    "text" : "Want to improve team morale?  Provide learning opportunities for them.",
    "id" : 28262492106915841,
    "created_at" : "2011-01-21 01:27:57 +0000",
    "user" : {
      "name" : "Scott W. Ambler",
      "screen_name" : "scottwambler",
      "protected" : false,
      "id_str" : "61747648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446067243734933506\/7WBAnFQz_normal.jpeg",
      "id" : 61747648,
      "verified" : false
    }
  },
  "id" : 28288264028819457,
  "created_at" : "2011-01-21 03:10:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27857968481439744",
  "text" : "Very impressed with 2nd Ed. of Jenifer Tidwell's book Designing Interfaces: Patterns for Effective IxD -&gt; mobile + updates + new patterns!",
  "id" : 27857968481439744,
  "created_at" : "2011-01-19 22:40:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23429922160648192",
  "text" : "Uniformity vs. Individuality in Mac UI Design http:\/\/bit.ly\/gOmlpw  Great look at the decline of the Apple HIG, which is both good and bad.",
  "id" : 23429922160648192,
  "created_at" : "2011-01-07 17:25:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 0, 8 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22786509950156801",
  "geo" : { },
  "id_str" : "23034065665925121",
  "in_reply_to_user_id" : 1550251,
  "text" : "@dmitryn Paper only for Persona example, disagree with described scenario format. My pref. design scenario formats http:\/\/slidesha.re\/fzKlsS",
  "id" : 23034065665925121,
  "in_reply_to_status_id" : 22786509950156801,
  "created_at" : "2011-01-06 15:12:03 +0000",
  "in_reply_to_screen_name" : "dmitryn",
  "in_reply_to_user_id_str" : "1550251",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 0, 8 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22279691972902912",
  "geo" : { },
  "id_str" : "22334030779260928",
  "in_reply_to_user_id" : 1550251,
  "text" : "@dmitryn For example, here are two Persona formats that I used as references:  http:\/\/bit.ly\/i8kLhP and http:\/\/bit.ly\/8OzVXo Your thoughts?",
  "id" : 22334030779260928,
  "in_reply_to_status_id" : 22279691972902912,
  "created_at" : "2011-01-04 16:50:22 +0000",
  "in_reply_to_screen_name" : "dmitryn",
  "in_reply_to_user_id_str" : "1550251",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 0, 8 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "22279691972902912",
  "geo" : { },
  "id_str" : "22333715724111873",
  "in_reply_to_user_id" : 1550251,
  "text" : "@dmitryn I was thinking about light-weight methods that better support on-going collaboration when I wrote \"agile inspired\".",
  "id" : 22333715724111873,
  "in_reply_to_status_id" : 22279691972902912,
  "created_at" : "2011-01-04 16:49:07 +0000",
  "in_reply_to_screen_name" : "dmitryn",
  "in_reply_to_user_id_str" : "1550251",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22067498765524992",
  "text" : "Solid results with using agile inspired personas and scenarios in recent usability review. Adds more context with very little scope creep.",
  "id" : 22067498765524992,
  "created_at" : "2011-01-03 23:11:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]