Grailbird.data.tweets_2011_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 39 ],
      "url" : "http:\/\/t.co\/HaRE9Ys",
      "expanded_url" : "http:\/\/www.alistapart.com\/articles\/the-ux-of-learning\/",
      "display_url" : "alistapart.com\/articles\/the-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "96351710498402304",
  "text" : "The UX of Learning: http:\/\/t.co\/HaRE9Ys &lt;-As with many UX-related pursuits, empathy is a critical aspect",
  "id" : 96351710498402304,
  "created_at" : "2011-07-27 22:50:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Fox",
      "screen_name" : "kfury",
      "indices" : [ 3, 9 ],
      "id_str" : "785",
      "id" : 785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95538672094543872",
  "text" : "RT @kfury: Great read: Larry Tesler explains the origins of the Mac\u2019s original scrolling behavior http:\/\/bit.ly\/otMUbt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95307971436883968",
    "text" : "Great read: Larry Tesler explains the origins of the Mac\u2019s original scrolling behavior http:\/\/bit.ly\/otMUbt",
    "id" : 95307971436883968,
    "created_at" : "2011-07-25 01:42:45 +0000",
    "user" : {
      "name" : "Kevin Fox",
      "screen_name" : "kfury",
      "protected" : false,
      "id_str" : "785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593841586573692930\/XY2_NLrT_normal.jpg",
      "id" : 785,
      "verified" : true
    }
  },
  "id" : 95538672094543872,
  "created_at" : "2011-07-25 16:59:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "selma zafar",
      "screen_name" : "selmaz",
      "indices" : [ 3, 10 ],
      "id_str" : "36598690",
      "id" : 36598690
    }, {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 46, 58 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94520802849984512",
  "text" : "RT @selmaz: Are u a PM looking for a change?  @openroadies team is hiring! fun, challenging projects & people are pretty nice too. http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenRoad",
        "screen_name" : "openroadies",
        "indices" : [ 34, 46 ],
        "id_str" : "66913866",
        "id" : 66913866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94518035439812608",
    "text" : "Are u a PM looking for a change?  @openroadies team is hiring! fun, challenging projects & people are pretty nice too. http:\/\/bit.ly\/qy6iVk",
    "id" : 94518035439812608,
    "created_at" : "2011-07-22 21:23:50 +0000",
    "user" : {
      "name" : "selma zafar",
      "screen_name" : "selmaz",
      "protected" : false,
      "id_str" : "36598690",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/191536681\/selma_photo2_normal.jpg",
      "id" : 36598690,
      "verified" : false
    }
  },
  "id" : 94520802849984512,
  "created_at" : "2011-07-22 21:34:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94101316783185920",
  "text" : "Thinking of teaching vs. coaching. Teaching is sharing information (to many), but coaching can be framed as asking questions (one-on-one).",
  "id" : 94101316783185920,
  "created_at" : "2011-07-21 17:47:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 98 ],
      "url" : "http:\/\/t.co\/JF8zj66",
      "expanded_url" : "http:\/\/www.modernanalyst.com\/Resources\/Articles\/tabid\/115\/articleType\/ArticleView\/articleId\/1892\/Business-Analysis-and-User-Experience.aspx",
      "display_url" : "modernanalyst.com\/Resources\/Arti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "91902379028529152",
  "text" : "Key differences and similarities between Business Analysis and User Experience http:\/\/t.co\/JF8zj66",
  "id" : 91902379028529152,
  "created_at" : "2011-07-15 16:10:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Idea Sandbox",
      "screen_name" : "IdeaSandbox",
      "indices" : [ 76, 88 ],
      "id_str" : "10258",
      "id" : 10258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http:\/\/t.co\/n1GOvdE",
      "expanded_url" : "http:\/\/www.idea-sandbox.com\/blog\/2011\/07\/11-ways-to-restate-problems-to-get-better-solutions\/",
      "display_url" : "idea-sandbox.com\/blog\/2011\/07\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "90570218035884032",
  "text" : "11 Ways To Restate Problems to Get Better Solutions http:\/\/t.co\/n1GOvdE via @IdeaSandbox &lt;- Some practical methods for reframing a problem",
  "id" : 90570218035884032,
  "created_at" : "2011-07-11 23:56:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 0, 8 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89159872779792384",
  "geo" : { },
  "id_str" : "89375220586135552",
  "in_reply_to_user_id" : 1550251,
  "text" : "@dmitryn The highlight of the article for me is the categorized UX skills inventory - a very useful reference",
  "id" : 89375220586135552,
  "in_reply_to_status_id" : 89159872779792384,
  "created_at" : "2011-07-08 16:48:07 +0000",
  "in_reply_to_screen_name" : "dmitryn",
  "in_reply_to_user_id_str" : "1550251",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 100 ],
      "url" : "http:\/\/t.co\/u5aDUV5",
      "expanded_url" : "http:\/\/www.uie.com\/brainsparks\/2011\/07\/07\/do-ux-teams-require-new-skills-for-content-strategy-service-design-or-lean-ux\/",
      "display_url" : "uie.com\/brainsparks\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "89131599660187648",
  "text" : "Do UX teams require new skills for Content Strategy, Service Design, or Lean UX? http:\/\/t.co\/u5aDUV5 &lt;- Includes UX skills overview diagram",
  "id" : 89131599660187648,
  "created_at" : "2011-07-08 00:40:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Baz",
      "screen_name" : "joebaz",
      "indices" : [ 3, 10 ],
      "id_str" : "1736961",
      "id" : 1736961
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "usability",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88987928516243456",
  "text" : "RT @joebaz: 6 Maxims on discount #usability testing by Steve Krug http:\/\/bit.ly\/6mxKruG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "usability",
        "indices" : [ 21, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88986209237483520",
    "text" : "6 Maxims on discount #usability testing by Steve Krug http:\/\/bit.ly\/6mxKruG",
    "id" : 88986209237483520,
    "created_at" : "2011-07-07 15:02:20 +0000",
    "user" : {
      "name" : "Joe Baz",
      "screen_name" : "joebaz",
      "protected" : false,
      "id_str" : "1736961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485106877022208000\/UtzbY7xl_normal.jpeg",
      "id" : 1736961,
      "verified" : false
    }
  },
  "id" : 88987928516243456,
  "created_at" : "2011-07-07 15:09:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88687833174380544",
  "text" : "Job opportunity: Software Interaction Designer at Global Relay - Vancouver, Canada Area #jobs http:\/\/lnkd.in\/JkZQ9k",
  "id" : 88687833174380544,
  "created_at" : "2011-07-06 19:16:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 3, 11 ],
      "id_str" : "1550251",
      "id" : 1550251
    }, {
      "name" : "Craig Villamor",
      "screen_name" : "cvilly",
      "indices" : [ 139, 140 ],
      "id_str" : "4763791",
      "id" : 4763791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "li",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/pdJIh5F",
      "expanded_url" : "http:\/\/cvil.ly\/2011\/07\/06\/design-for-touch\/",
      "display_url" : "cvil.ly\/2011\/07\/06\/des\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "88670738726387712",
  "text" : "RT @dmitryn: \"Your next UI should be designed for touch, even if you\u2019re not targeting smartphones or tablets.\" http:\/\/t.co\/pdJIh5F via @ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Craig Villamor",
        "screen_name" : "cvilly",
        "indices" : [ 122, 129 ],
        "id_str" : "4763791",
        "id" : 4763791
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ux",
        "indices" : [ 130, 133 ]
      }, {
        "text" : "li",
        "indices" : [ 134, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 117 ],
        "url" : "http:\/\/t.co\/pdJIh5F",
        "expanded_url" : "http:\/\/cvil.ly\/2011\/07\/06\/design-for-touch\/",
        "display_url" : "cvil.ly\/2011\/07\/06\/des\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "88654590454673408",
    "text" : "\"Your next UI should be designed for touch, even if you\u2019re not targeting smartphones or tablets.\" http:\/\/t.co\/pdJIh5F via @cvilly #ux #li",
    "id" : 88654590454673408,
    "created_at" : "2011-07-06 17:04:36 +0000",
    "user" : {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "protected" : false,
      "id_str" : "1550251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623216199791329280\/hoNAcmrW_normal.jpg",
      "id" : 1550251,
      "verified" : false
    }
  },
  "id" : 88670738726387712,
  "created_at" : "2011-07-06 18:08:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 98 ],
      "url" : "http:\/\/t.co\/zdEsb4F",
      "expanded_url" : "http:\/\/www.paulhibbitts.com\/courses\/uxfundamentals-demo\/",
      "display_url" : "paulhibbitts.com\/courses\/uxfund\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "88669186477395968",
  "text" : "Updates to my example UX course companion website (incl. mobile) beta now live http:\/\/t.co\/zdEsb4F",
  "id" : 88669186477395968,
  "created_at" : "2011-07-06 18:02:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88659136199405569",
  "text" : "Having pixel-level control of a user interface design is an awesome thing!",
  "id" : 88659136199405569,
  "created_at" : "2011-07-06 17:22:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather McGaw",
      "screen_name" : "HeatherMcGaw",
      "indices" : [ 0, 13 ],
      "id_str" : "15690851",
      "id" : 15690851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87984076782452736",
  "geo" : { },
  "id_str" : "87988813510615041",
  "in_reply_to_user_id" : 15690851,
  "text" : "@HeatherMcGaw I've used GoToMeeting for quite a few utests and have been very happy. Easy participant installs and fast screen refresh rate.",
  "id" : 87988813510615041,
  "in_reply_to_status_id" : 87984076782452736,
  "created_at" : "2011-07-04 20:59:02 +0000",
  "in_reply_to_screen_name" : "HeatherMcGaw",
  "in_reply_to_user_id_str" : "15690851",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]