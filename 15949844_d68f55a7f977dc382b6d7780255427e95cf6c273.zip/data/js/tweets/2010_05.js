Grailbird.data.tweets_2010_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14801264259",
  "text" : "One can always become a better designer - it is just a question about how much better.",
  "id" : 14801264259,
  "created_at" : "2010-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Snyder",
      "screen_name" : "csnyder",
      "indices" : [ 0, 8 ],
      "id_str" : "14943457",
      "id" : 14943457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14861387391",
  "in_reply_to_user_id" : 14943457,
  "text" : "@csnyder I prefer a general-purpose tool rather than something specialized. GoToMeeting is my favorite -best screen refresh and easy install",
  "id" : 14861387391,
  "created_at" : "2010-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "csnyder",
  "in_reply_to_user_id_str" : "14943457",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14770878045",
  "text" : "Usability Ain\u2019t Everything \u2013 A Response to Nielsen\u2019s iPad Usability Study  http:\/\/bit.ly\/9Rwj1J (via Johnny Holland)",
  "id" : 14770878045,
  "created_at" : "2010-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd",
      "screen_name" : "toddsieling",
      "indices" : [ 0, 12 ],
      "id_str" : "7415622",
      "id" : 7415622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14774324840",
  "geo" : { },
  "id_str" : "14784076891",
  "in_reply_to_user_id" : 7415622,
  "text" : "@toddsieling As shown by useit.com indeed. Usability testing by its nature can limit the lens of viewing a product's user experience.",
  "id" : 14784076891,
  "in_reply_to_status_id" : 14774324840,
  "created_at" : "2010-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "toddsieling",
  "in_reply_to_user_id_str" : "7415622",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd",
      "screen_name" : "toddsieling",
      "indices" : [ 0, 12 ],
      "id_str" : "7415622",
      "id" : 7415622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14774324840",
  "geo" : { },
  "id_str" : "14784268058",
  "in_reply_to_user_id" : 7415622,
  "text" : "@toddsieling While I have always favoured Nielsen's usability criteria (learnability, efficiency, memorability, errors, and satisfaction)",
  "id" : 14784268058,
  "in_reply_to_status_id" : 14774324840,
  "created_at" : "2010-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "toddsieling",
  "in_reply_to_user_id_str" : "7415622",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd",
      "screen_name" : "toddsieling",
      "indices" : [ 0, 12 ],
      "id_str" : "7415622",
      "id" : 7415622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14784448141",
  "in_reply_to_user_id" : 7415622,
  "text" : "@toddsieling for measuring usability, I prefer Quesenbery's 5Es (engaging, effective, efficient, error tolerant, easy to learn) for UX eval",
  "id" : 14784448141,
  "created_at" : "2010-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "toddsieling",
  "in_reply_to_user_id_str" : "7415622",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtain Revenue",
      "screen_name" : "corvustweets",
      "indices" : [ 0, 13 ],
      "id_str" : "2503692858",
      "id" : 2503692858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14394748675",
  "text" : "@corvustweets Congratulations on joining the SFU workshop Todd, that's great news!",
  "id" : 14394748675,
  "created_at" : "2010-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14376572354",
  "text" : "Checking out the new WebEx Beta, looks very promising from a user experience point of view http:\/\/www.webex.com\/meetbeta\/lp\/",
  "id" : 14376572354,
  "created_at" : "2010-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14316810107",
  "text" : "Nice little collection of Android UI patterns, including related recommendations http:\/\/bit.ly\/akpQza",
  "id" : 14316810107,
  "created_at" : "2010-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Martell",
      "screen_name" : "danmartell",
      "indices" : [ 69, 80 ],
      "id_str" : "10638782",
      "id" : 10638782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14197810939",
  "text" : "Looking forward to learning more about lean product development with @danmartell on June 17th in Vancouver http:\/\/bit.ly\/aIEYH7",
  "id" : 14197810939,
  "created_at" : "2010-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "indices" : [ 111, 119 ],
      "id_str" : "15022225",
      "id" : 15022225
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ipad",
      "indices" : [ 89, 94 ]
    }, {
      "text" : "usability",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13747038092",
  "text" : "Alertbox: iPad Usability - First Findings From User Testing http:\/\/bit.ly\/iPadUsability  #ipad #usability (via @NNgroup)",
  "id" : 13747038092,
  "created_at" : "2010-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]