Grailbird.data.tweets_2015_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WIRED\/status\/582955415014625280\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/warQYEivBc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBcS3HFXIAAKjPG.jpg",
      "id_str" : "582955414771408896",
      "id" : 582955414771408896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBcS3HFXIAAKjPG.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 932
      } ],
      "display_url" : "pic.twitter.com\/warQYEivBc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/8v6OsXwlH7",
      "expanded_url" : "http:\/\/wrd.cm\/1Hhx7n6",
      "display_url" : "wrd.cm\/1Hhx7n6"
    } ]
  },
  "geo" : { },
  "id_str" : "582988372353777665",
  "text" : "RT @WIRED: Google unveils a Chrome stick that turns any display into a PC http:\/\/t.co\/8v6OsXwlH7 http:\/\/t.co\/warQYEivBc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WIRED\/status\/582955415014625280\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/warQYEivBc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBcS3HFXIAAKjPG.jpg",
        "id_str" : "582955414771408896",
        "id" : 582955414771408896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBcS3HFXIAAKjPG.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 932
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 932
        } ],
        "display_url" : "pic.twitter.com\/warQYEivBc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/8v6OsXwlH7",
        "expanded_url" : "http:\/\/wrd.cm\/1Hhx7n6",
        "display_url" : "wrd.cm\/1Hhx7n6"
      } ]
    },
    "geo" : { },
    "id_str" : "582955415014625280",
    "text" : "Google unveils a Chrome stick that turns any display into a PC http:\/\/t.co\/8v6OsXwlH7 http:\/\/t.co\/warQYEivBc",
    "id" : 582955415014625280,
    "created_at" : "2015-03-31 17:19:36 +0000",
    "user" : {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615598832726970372\/jsK-gBSt_normal.png",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 582988372353777665,
  "created_at" : "2015-03-31 19:30:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 3, 15 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/openroadies\/status\/582656552806588416\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/qxvWNMuumG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBYDDChW4AAUJeu.jpg",
      "id_str" : "582656552542330880",
      "id" : 582656552542330880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBYDDChW4AAUJeu.jpg",
      "sizes" : [ {
        "h" : 380,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 211,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 120,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qxvWNMuumG"
    } ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 120, 125 ]
    }, {
      "text" : "yvr",
      "indices" : [ 126, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/9plMrdk97o",
      "expanded_url" : "http:\/\/ow.ly\/L06e2",
      "display_url" : "ow.ly\/L06e2"
    } ]
  },
  "geo" : { },
  "id_str" : "582662425226276864",
  "text" : "RT @openroadies: Know any amazing project managers looking for new opportunities? We're hiring: http:\/\/t.co\/9plMrdk97o  #jobs #yvr http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/openroadies\/status\/582656552806588416\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/qxvWNMuumG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBYDDChW4AAUJeu.jpg",
        "id_str" : "582656552542330880",
        "id" : 582656552542330880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBYDDChW4AAUJeu.jpg",
        "sizes" : [ {
          "h" : 380,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 211,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 120,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/qxvWNMuumG"
      } ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 103, 108 ]
      }, {
        "text" : "yvr",
        "indices" : [ 109, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/9plMrdk97o",
        "expanded_url" : "http:\/\/ow.ly\/L06e2",
        "display_url" : "ow.ly\/L06e2"
      } ]
    },
    "geo" : { },
    "id_str" : "582656552806588416",
    "text" : "Know any amazing project managers looking for new opportunities? We're hiring: http:\/\/t.co\/9plMrdk97o  #jobs #yvr http:\/\/t.co\/qxvWNMuumG",
    "id" : 582656552806588416,
    "created_at" : "2015-03-30 21:32:02 +0000",
    "user" : {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "protected" : false,
      "id_str" : "66913866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554783440747237376\/HA2Svg4h_normal.png",
      "id" : 66913866,
      "verified" : false
    }
  },
  "id" : 582662425226276864,
  "created_at" : "2015-03-30 21:55:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 80, 85 ]
    }, {
      "text" : "proflearn",
      "indices" : [ 86, 96 ]
    }, {
      "text" : "bcoer",
      "indices" : [ 97, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/TN2ASqwUBE",
      "expanded_url" : "http:\/\/bit.ly\/1NjJLUo",
      "display_url" : "bit.ly\/1NjJLUo"
    } ]
  },
  "geo" : { },
  "id_str" : "581163594831818752",
  "text" : "RT @etug: ETUG Spring Workshop Registration is now Open! http:\/\/t.co\/TN2ASqwUBE\n#etug #proflearn #bcoer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 70, 75 ]
      }, {
        "text" : "proflearn",
        "indices" : [ 76, 86 ]
      }, {
        "text" : "bcoer",
        "indices" : [ 87, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/TN2ASqwUBE",
        "expanded_url" : "http:\/\/bit.ly\/1NjJLUo",
        "display_url" : "bit.ly\/1NjJLUo"
      } ]
    },
    "geo" : { },
    "id_str" : "581160872980152321",
    "text" : "ETUG Spring Workshop Registration is now Open! http:\/\/t.co\/TN2ASqwUBE\n#etug #proflearn #bcoer",
    "id" : 581160872980152321,
    "created_at" : "2015-03-26 18:28:44 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 581163594831818752,
  "created_at" : "2015-03-26 18:39:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 13, 22 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/581158545913212930\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mOIe5VlMkP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBCwniCVIAAgD9-.png",
      "id_str" : "581158545128759296",
      "id" : 581158545128759296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBCwniCVIAAgD9-.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mOIe5VlMkP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581158545913212930",
  "text" : "My colleague @m_travin and I have been refining our Learning Ecology framework. Check it out and share your thoughts. http:\/\/t.co\/mOIe5VlMkP",
  "id" : 581158545913212930,
  "created_at" : "2015-03-26 18:19:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Learning Plan",
      "screen_name" : "learningplan",
      "indices" : [ 3, 16 ],
      "id_str" : "248512387",
      "id" : 248512387
    }, {
      "name" : "Ed Batista",
      "screen_name" : "edbatista",
      "indices" : [ 80, 90 ],
      "id_str" : "2092061",
      "id" : 2092061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/hW5TM1JeCg",
      "expanded_url" : "http:\/\/ow.ly\/KOjcr",
      "display_url" : "ow.ly\/KOjcr"
    } ]
  },
  "geo" : { },
  "id_str" : "580945114496786432",
  "text" : "RT @learningplan: Tips for Coaching Someone Remotely http:\/\/t.co\/hW5TM1JeCg via @edbatista",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ed Batista",
        "screen_name" : "edbatista",
        "indices" : [ 62, 72 ],
        "id_str" : "2092061",
        "id" : 2092061
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/hW5TM1JeCg",
        "expanded_url" : "http:\/\/ow.ly\/KOjcr",
        "display_url" : "ow.ly\/KOjcr"
      } ]
    },
    "geo" : { },
    "id_str" : "580943576735080448",
    "text" : "Tips for Coaching Someone Remotely http:\/\/t.co\/hW5TM1JeCg via @edbatista",
    "id" : 580943576735080448,
    "created_at" : "2015-03-26 04:05:16 +0000",
    "user" : {
      "name" : "Learning Plan",
      "screen_name" : "learningplan",
      "protected" : false,
      "id_str" : "248512387",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1327746022\/screen-capture_normal.png",
      "id" : 248512387,
      "verified" : false
    }
  },
  "id" : 580945114496786432,
  "created_at" : "2015-03-26 04:11:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Reich",
      "screen_name" : "bjfr",
      "indices" : [ 3, 8 ],
      "id_str" : "14883339",
      "id" : 14883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/71g3rpdVB2",
      "expanded_url" : "http:\/\/arstechnica.com\/tech-policy\/2015\/03\/despite-privacy-policy-radioshack-customer-data-up-for-sale-in-auction\/",
      "display_url" : "arstechnica.com\/tech-policy\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580786725917622272",
  "text" : "RT @bjfr: Despite privacy policy, Radio Shack data for sale. #edtech should be watching this: http:\/\/t.co\/71g3rpdVB2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 51, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/71g3rpdVB2",
        "expanded_url" : "http:\/\/arstechnica.com\/tech-policy\/2015\/03\/despite-privacy-policy-radioshack-customer-data-up-for-sale-in-auction\/",
        "display_url" : "arstechnica.com\/tech-policy\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580785623830773760",
    "text" : "Despite privacy policy, Radio Shack data for sale. #edtech should be watching this: http:\/\/t.co\/71g3rpdVB2",
    "id" : 580785623830773760,
    "created_at" : "2015-03-25 17:37:37 +0000",
    "user" : {
      "name" : "Justin Reich",
      "screen_name" : "bjfr",
      "protected" : false,
      "id_str" : "14883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3709606866\/fd5b8cc5536d4b3762267b9e588bc08e_normal.png",
      "id" : 14883339,
      "verified" : false
    }
  },
  "id" : 580786725917622272,
  "created_at" : "2015-03-25 17:42:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580487223277195265",
  "text" : "I think my unofficial slogan is shaping up to be \"Putting learners back into the driving seat\".",
  "id" : 580487223277195265,
  "created_at" : "2015-03-24 21:51:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    }, {
      "name" : "Amanda Coolidge",
      "screen_name" : "acoolidge",
      "indices" : [ 14, 24 ],
      "id_str" : "17416175",
      "id" : 17416175
    }, {
      "name" : "Mary Burgess",
      "screen_name" : "maryeburgess",
      "indices" : [ 25, 38 ],
      "id_str" : "24827526",
      "id" : 24827526
    }, {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 39, 48 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580398388321132546",
  "geo" : { },
  "id_str" : "580423124715454464",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde @acoolidge @maryeburgess @BCcampus That is really awesome news, congratulations to everyone on the team!",
  "id" : 580423124715454464,
  "in_reply_to_status_id" : 580398388321132546,
  "created_at" : "2015-03-24 17:37:11 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/fXH51yIvzO",
      "expanded_url" : "http:\/\/www.cooper.com\/journal\/2013\/01\/self-study-interaction-design",
      "display_url" : "cooper.com\/journal\/2013\/0\u2026"
    }, {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/b6lLqpueuy",
      "expanded_url" : "http:\/\/thehipperelement.com\/post\/75476711614\/ux-crash-course-31-fundamentals",
      "display_url" : "thehipperelement.com\/post\/754767116\u2026"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/HQrrWHEJLT",
      "expanded_url" : "http:\/\/uxmastery.com\/how-to-get-started-in-ux-design\/",
      "display_url" : "uxmastery.com\/how-to-get-sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580067923672240128",
  "text" : "Are you an instructional designer wanting to know more about UX design? http:\/\/t.co\/fXH51yIvzO http:\/\/t.co\/b6lLqpueuy http:\/\/t.co\/HQrrWHEJLT",
  "id" : 580067923672240128,
  "created_at" : "2015-03-23 18:05:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580052591859474433",
  "text" : "(Multi-device) learning experience goals:\n\u2713 To be engaging\n\u2713 To be convenient\n\u2713 To be organized\n\u2713 To be relevant\n\u2713 To be enjoyable",
  "id" : 580052591859474433,
  "created_at" : "2015-03-23 17:04:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580042197547896832",
  "text" : "Professional happiness tip: track when work makes you feel energized and use this list to help guide your pursuit of future work.",
  "id" : 580042197547896832,
  "created_at" : "2015-03-23 16:23:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmet Connolly",
      "screen_name" : "thoughtwax",
      "indices" : [ 3, 14 ],
      "id_str" : "11323",
      "id" : 11323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579864116854026240",
  "text" : "RT @thoughtwax: 1984: A bicycle for the mind.\n2015: A trampoline for the ego.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "579779740237742080",
    "text" : "1984: A bicycle for the mind.\n2015: A trampoline for the ego.",
    "id" : 579779740237742080,
    "created_at" : "2015-03-22 23:00:36 +0000",
    "user" : {
      "name" : "Emmet Connolly",
      "screen_name" : "thoughtwax",
      "protected" : false,
      "id_str" : "11323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/14507772\/me_normal.jpg",
      "id" : 11323,
      "verified" : false
    }
  },
  "id" : 579864116854026240,
  "created_at" : "2015-03-23 04:35:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578358390017028097",
  "text" : "RT @lukew: Companies want design to act as a source of product leadership but can't make the organizational changes\/sacrifices required to \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567741417259151362",
    "text" : "Companies want design to act as a source of product leadership but can't make the organizational changes\/sacrifices required to enable it.",
    "id" : 567741417259151362,
    "created_at" : "2015-02-17 17:44:36 +0000",
    "user" : {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "protected" : false,
      "id_str" : "13889622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477610446917103616\/_cjU3_ga_normal.png",
      "id" : 13889622,
      "verified" : false
    }
  },
  "id" : 578358390017028097,
  "created_at" : "2015-03-19 00:52:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 3, 11 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/dmitryn\/status\/577527579315421185\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/MLnDnOeJXb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAPKRecWcAASnY1.png",
      "id_str" : "577527578812116992",
      "id" : 577527578812116992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAPKRecWcAASnY1.png",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 901,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1126,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1126,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/MLnDnOeJXb"
    } ],
    "hashtags" : [ {
      "text" : "Empathy",
      "indices" : [ 14, 22 ]
    }, {
      "text" : "UX",
      "indices" : [ 121, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/PlBr7yXRcS",
      "expanded_url" : "https:\/\/medium.com\/@odannyboy\/in-design-empathy-is-not-enough-c315b1c1ecee?source=tw-fec65f0a4c75-1426528236405#7a6e--share-414-506",
      "display_url" : "medium.com\/@odannyboy\/in-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577537640913735680",
  "text" : "RT @dmitryn: \u201C#Empathy will get you to see problems from users\u2019 perspective, but not solutions.\u201D https:\/\/t.co\/PlBr7yXRcS #UX http:\/\/t.co\/ML\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/medium.com\" rel=\"nofollow\"\u003EMedium\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/dmitryn\/status\/577527579315421185\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/MLnDnOeJXb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAPKRecWcAASnY1.png",
        "id_str" : "577527578812116992",
        "id" : 577527578812116992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAPKRecWcAASnY1.png",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1126,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1126,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/MLnDnOeJXb"
      } ],
      "hashtags" : [ {
        "text" : "Empathy",
        "indices" : [ 1, 9 ]
      }, {
        "text" : "UX",
        "indices" : [ 108, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/PlBr7yXRcS",
        "expanded_url" : "https:\/\/medium.com\/@odannyboy\/in-design-empathy-is-not-enough-c315b1c1ecee?source=tw-fec65f0a4c75-1426528236405#7a6e--share-414-506",
        "display_url" : "medium.com\/@odannyboy\/in-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "577527579315421185",
    "text" : "\u201C#Empathy will get you to see problems from users\u2019 perspective, but not solutions.\u201D https:\/\/t.co\/PlBr7yXRcS #UX http:\/\/t.co\/MLnDnOeJXb",
    "id" : 577527579315421185,
    "created_at" : "2015-03-16 17:51:19 +0000",
    "user" : {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "protected" : false,
      "id_str" : "1550251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623216199791329280\/hoNAcmrW_normal.jpg",
      "id" : 1550251,
      "verified" : false
    }
  },
  "id" : 577537640913735680,
  "created_at" : "2015-03-16 18:31:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 43, 48 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "levalee",
      "screen_name" : "levalee",
      "indices" : [ 143, 144 ],
      "id_str" : "17505659",
      "id" : 17505659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 144 ],
      "url" : "http:\/\/t.co\/04WZCxzTC8",
      "expanded_url" : "http:\/\/ht.ly\/KgFom",
      "display_url" : "ht.ly\/KgFom"
    } ]
  },
  "geo" : { },
  "id_str" : "576505987021963264",
  "text" : "RT @BCcampus: Call for Proposals now open! @etug welcomes faculty, staff &amp; student proposals for the ETUG Spring Workshop. http:\/\/t.co\/04WZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 29, 34 ],
        "id_str" : "17102936",
        "id" : 17102936
      }, {
        "name" : "levalee",
        "screen_name" : "levalee",
        "indices" : [ 136, 144 ],
        "id_str" : "17505659",
        "id" : 17505659
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/04WZCxzTC8",
        "expanded_url" : "http:\/\/ht.ly\/KgFom",
        "display_url" : "ht.ly\/KgFom"
      } ]
    },
    "geo" : { },
    "id_str" : "576505570611585024",
    "text" : "Call for Proposals now open! @etug welcomes faculty, staff &amp; student proposals for the ETUG Spring Workshop. http:\/\/t.co\/04WZCxzTC8 @levalee",
    "id" : 576505570611585024,
    "created_at" : "2015-03-13 22:10:13 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 576505987021963264,
  "created_at" : "2015-03-13 22:11:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    }, {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 88, 95 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 102, 109 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openeducationwk",
      "indices" : [ 48, 64 ]
    }, {
      "text" : "tielab",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/HE39omagLx",
      "expanded_url" : "http:\/\/bit.ly\/1MyBfSR",
      "display_url" : "bit.ly\/1MyBfSR"
    } ]
  },
  "geo" : { },
  "id_str" : "576499521040965632",
  "text" : "RT @clintlalonde: In 15 min (3PM PST) our final #openeducationwk event. The Open Web w\/ @brlamb &amp; @cogdog. Join live webcast at http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian Lamb",
        "screen_name" : "brlamb",
        "indices" : [ 70, 77 ],
        "id_str" : "745903",
        "id" : 745903
      }, {
        "name" : "Alan Levine",
        "screen_name" : "cogdog",
        "indices" : [ 84, 91 ],
        "id_str" : "740343",
        "id" : 740343
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openeducationwk",
        "indices" : [ 30, 46 ]
      }, {
        "text" : "tielab",
        "indices" : [ 137, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/HE39omagLx",
        "expanded_url" : "http:\/\/bit.ly\/1MyBfSR",
        "display_url" : "bit.ly\/1MyBfSR"
      } ]
    },
    "geo" : { },
    "id_str" : "576499243935866880",
    "text" : "In 15 min (3PM PST) our final #openeducationwk event. The Open Web w\/ @brlamb &amp; @cogdog. Join live webcast at http:\/\/t.co\/HE39omagLx #tielab",
    "id" : 576499243935866880,
    "created_at" : "2015-03-13 21:45:05 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 576499521040965632,
  "created_at" : "2015-03-13 21:46:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 105, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/H7cqOYnTkR",
      "expanded_url" : "https:\/\/mm.tt\/517648533?t=AoFLb0i8Po",
      "display_url" : "mm.tt\/517648533?t=Ao\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "576480647197290496",
  "text" : "Exploring what a visual map for a learning ecology might look like. First-up, a look back at my CMPT 363 #SFU course https:\/\/t.co\/H7cqOYnTkR",
  "id" : 576480647197290496,
  "created_at" : "2015-03-13 20:31:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "ThirdPersonManifesto",
      "screen_name" : "3PM",
      "indices" : [ 20, 24 ],
      "id_str" : "429342492",
      "id" : 429342492
    }, {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 70, 77 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 84, 91 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openeducationwk",
      "indices" : [ 35, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/lW50f34y85",
      "expanded_url" : "http:\/\/ht.ly\/KgahI",
      "display_url" : "ht.ly\/KgahI"
    } ]
  },
  "geo" : { },
  "id_str" : "576400432605474816",
  "text" : "RT @BCcampus: Today @3pm (Pacific) #openeducationwk presentation from @brlamb &amp; @cogdog will be live streamed. Details: http:\/\/t.co\/lW50f34\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ThirdPersonManifesto",
        "screen_name" : "3PM",
        "indices" : [ 6, 10 ],
        "id_str" : "429342492",
        "id" : 429342492
      }, {
        "name" : "Brian Lamb",
        "screen_name" : "brlamb",
        "indices" : [ 56, 63 ],
        "id_str" : "745903",
        "id" : 745903
      }, {
        "name" : "Alan Levine",
        "screen_name" : "cogdog",
        "indices" : [ 70, 77 ],
        "id_str" : "740343",
        "id" : 740343
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openeducationwk",
        "indices" : [ 21, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/lW50f34y85",
        "expanded_url" : "http:\/\/ht.ly\/KgahI",
        "display_url" : "ht.ly\/KgahI"
      } ]
    },
    "geo" : { },
    "id_str" : "576400075083112448",
    "text" : "Today @3pm (Pacific) #openeducationwk presentation from @brlamb &amp; @cogdog will be live streamed. Details: http:\/\/t.co\/lW50f34y85",
    "id" : 576400075083112448,
    "created_at" : "2015-03-13 15:11:01 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 576400432605474816,
  "created_at" : "2015-03-13 15:12:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sameroom HQ",
      "screen_name" : "sameroomhq",
      "indices" : [ 19, 30 ],
      "id_str" : "3016611945",
      "id" : 3016611945
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edu",
      "indices" : [ 34, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575755796060860416",
  "text" : "Sleeper feature of @sameroomhq in #edu is that discussions are possible with EXISTING student accounts AND chat history remains for students",
  "id" : 575755796060860416,
  "created_at" : "2015-03-11 20:30:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 31, 36 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575433992972861440",
  "text" : "Mulling over a session for the @ETUG Spring Workshop. Working title is Exploring Learning Ecologies: Experiences (and Experiments) So Far.",
  "id" : 575433992972861440,
  "created_at" : "2015-03-10 23:12:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Known",
      "screen_name" : "withknown",
      "indices" : [ 0, 10 ],
      "id_str" : "227050193",
      "id" : 227050193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "575353474507927552",
  "geo" : { },
  "id_str" : "575361832031911936",
  "in_reply_to_user_id" : 227050193,
  "text" : "@withknown Thanks for reply. Simple bookmarking w. search on a private install looks promising. Public install for blogging looks good too!",
  "id" : 575361832031911936,
  "in_reply_to_status_id" : 575353474507927552,
  "created_at" : "2015-03-10 18:25:25 +0000",
  "in_reply_to_screen_name" : "withknown",
  "in_reply_to_user_id_str" : "227050193",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Known",
      "screen_name" : "withknown",
      "indices" : [ 13, 23 ],
      "id_str" : "227050193",
      "id" : 227050193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575350922076778496",
  "text" : "Wondering if @withknown could be the open source, locally hosted version of Evernote I've been searching for",
  "id" : 575350922076778496,
  "created_at" : "2015-03-10 17:42:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 97, 102 ]
    }, {
      "text" : "proflearn",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/RBDYQErpEv",
      "expanded_url" : "http:\/\/etug.ca\/2015\/02\/27\/etug-spring-2015-call-for-proposals\/",
      "display_url" : "etug.ca\/2015\/02\/27\/etu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575128791120392193",
  "text" : "RT @etug: Say what?! ETUG Call for Proposals now open: http:\/\/t.co\/RBDYQErpEv 2 weeks to submit! #etug #proflearn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 87, 92 ]
      }, {
        "text" : "proflearn",
        "indices" : [ 93, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/RBDYQErpEv",
        "expanded_url" : "http:\/\/etug.ca\/2015\/02\/27\/etug-spring-2015-call-for-proposals\/",
        "display_url" : "etug.ca\/2015\/02\/27\/etu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "575113225177432064",
    "text" : "Say what?! ETUG Call for Proposals now open: http:\/\/t.co\/RBDYQErpEv 2 weeks to submit! #etug #proflearn",
    "id" : 575113225177432064,
    "created_at" : "2015-03-10 01:57:32 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 575128791120392193,
  "created_at" : "2015-03-10 02:59:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hoefler&Co.",
      "screen_name" : "HoeflerCo",
      "indices" : [ 3, 13 ],
      "id_str" : "1765921",
      "id" : 1765921
    }, {
      "name" : "Susan Kare",
      "screen_name" : "SusanKare",
      "indices" : [ 28, 38 ],
      "id_str" : "215456428",
      "id" : 215456428
    }, {
      "name" : "Museum of Modern Art",
      "screen_name" : "MuseumModernArt",
      "indices" : [ 74, 90 ],
      "id_str" : "15057943",
      "id" : 15057943
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HoeflerCo\/status\/574386668968525825\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/L5Y6F78R7H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_ihoXcWQAAap5W.jpg",
      "id_str" : "574386667349491712",
      "id" : 574386667349491712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_ihoXcWQAAap5W.jpg",
      "sizes" : [ {
        "h" : 237,
        "resize" : "fit",
        "w" : 381
      }, {
        "h" : 211,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 381
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 381
      } ],
      "display_url" : "pic.twitter.com\/L5Y6F78R7H"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/CeifjYzjVp",
      "expanded_url" : "http:\/\/www.moma.org\/explore\/inside_out\/2015\/03\/04\/is-this-for-everyone-new-design-acquisitions-at-moma",
      "display_url" : "moma.org\/explore\/inside\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "574452257850200065",
  "text" : "RT @HoeflerCo: Great to see @SusanKare, of Mac bitmap fame, recognized by @MuseumModernArt! http:\/\/t.co\/CeifjYzjVp http:\/\/t.co\/L5Y6F78R7H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan Kare",
        "screen_name" : "SusanKare",
        "indices" : [ 13, 23 ],
        "id_str" : "215456428",
        "id" : 215456428
      }, {
        "name" : "Museum of Modern Art",
        "screen_name" : "MuseumModernArt",
        "indices" : [ 59, 75 ],
        "id_str" : "15057943",
        "id" : 15057943
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HoeflerCo\/status\/574386668968525825\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/L5Y6F78R7H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_ihoXcWQAAap5W.jpg",
        "id_str" : "574386667349491712",
        "id" : 574386667349491712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_ihoXcWQAAap5W.jpg",
        "sizes" : [ {
          "h" : 237,
          "resize" : "fit",
          "w" : 381
        }, {
          "h" : 211,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 237,
          "resize" : "fit",
          "w" : 381
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 237,
          "resize" : "fit",
          "w" : 381
        } ],
        "display_url" : "pic.twitter.com\/L5Y6F78R7H"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/CeifjYzjVp",
        "expanded_url" : "http:\/\/www.moma.org\/explore\/inside_out\/2015\/03\/04\/is-this-for-everyone-new-design-acquisitions-at-moma",
        "display_url" : "moma.org\/explore\/inside\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "574386668968525825",
    "text" : "Great to see @SusanKare, of Mac bitmap fame, recognized by @MuseumModernArt! http:\/\/t.co\/CeifjYzjVp http:\/\/t.co\/L5Y6F78R7H",
    "id" : 574386668968525825,
    "created_at" : "2015-03-08 01:50:28 +0000",
    "user" : {
      "name" : "Hoefler&Co.",
      "screen_name" : "HoeflerCo",
      "protected" : false,
      "id_str" : "1765921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000073050881\/6baed800b68d9eeb73c41b3d17b53e08_normal.png",
      "id" : 1765921,
      "verified" : true
    }
  },
  "id" : 574452257850200065,
  "created_at" : "2015-03-08 06:11:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "indices" : [ 3, 15 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    }, {
      "name" : "Charles Hudson",
      "screen_name" : "chudson",
      "indices" : [ 101, 109 ],
      "id_str" : "763893",
      "id" : 763893
    }, {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "indices" : [ 113, 125 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ProductHunt\/status\/573191371638616064\/photo\/1",
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/4wQwXhygpW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Rig9_WoAA7zIe.png",
      "id_str" : "573191371118518272",
      "id" : 573191371118518272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Rig9_WoAA7zIe.png",
      "sizes" : [ {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1037,
        "resize" : "fit",
        "w" : 1480
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4wQwXhygpW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/j7Ozvr6Wc2",
      "expanded_url" : "http:\/\/www.producthunt.com\/posts\/sameroom",
      "display_url" : "producthunt.com\/posts\/sameroom"
    } ]
  },
  "geo" : { },
  "id_str" : "574236861410885632",
  "text" : "RT @ProductHunt: Sameroom: A bridge to connect users across chat services http:\/\/t.co\/j7Ozvr6Wc2 via @chudson on @producthunt http:\/\/t.co\/4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charles Hudson",
        "screen_name" : "chudson",
        "indices" : [ 84, 92 ],
        "id_str" : "763893",
        "id" : 763893
      }, {
        "name" : "Product Hunt",
        "screen_name" : "ProductHunt",
        "indices" : [ 96, 108 ],
        "id_str" : "2208027565",
        "id" : 2208027565
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ProductHunt\/status\/573191371638616064\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/4wQwXhygpW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Rig9_WoAA7zIe.png",
        "id_str" : "573191371118518272",
        "id" : 573191371118518272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Rig9_WoAA7zIe.png",
        "sizes" : [ {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1037,
          "resize" : "fit",
          "w" : 1480
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/4wQwXhygpW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/j7Ozvr6Wc2",
        "expanded_url" : "http:\/\/www.producthunt.com\/posts\/sameroom",
        "display_url" : "producthunt.com\/posts\/sameroom"
      } ]
    },
    "geo" : { },
    "id_str" : "573191371638616064",
    "text" : "Sameroom: A bridge to connect users across chat services http:\/\/t.co\/j7Ozvr6Wc2 via @chudson on @producthunt http:\/\/t.co\/4wQwXhygpW",
    "id" : 573191371638616064,
    "created_at" : "2015-03-04 18:40:47 +0000",
    "user" : {
      "name" : "\uD83D\uDC31 Product Hunt",
      "screen_name" : "ProductHunt",
      "protected" : false,
      "id_str" : "2208027565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752302755134316548\/vwdNnovQ_normal.jpg",
      "id" : 2208027565,
      "verified" : true
    }
  },
  "id" : 574236861410885632,
  "created_at" : "2015-03-07 15:55:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Pantel",
      "screen_name" : "cpantel",
      "indices" : [ 3, 11 ],
      "id_str" : "24698409",
      "id" : 24698409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/lYj99fEM3X",
      "expanded_url" : "http:\/\/www.d2l.com\/careers\/job\/?ID=product-designer-vancouver-d2lpdvan",
      "display_url" : "d2l.com\/careers\/job\/?I\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573612691761160192",
  "text" : "RT @cpantel: We are looking for a great Product Designer at D2L in Vancouver, BC. Join us to help improve how the world learns.http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/lYj99fEM3X",
        "expanded_url" : "http:\/\/www.d2l.com\/careers\/job\/?ID=product-designer-vancouver-d2lpdvan",
        "display_url" : "d2l.com\/careers\/job\/?I\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "573612404992512001",
    "text" : "We are looking for a great Product Designer at D2L in Vancouver, BC. Join us to help improve how the world learns.http:\/\/t.co\/lYj99fEM3X",
    "id" : 573612404992512001,
    "created_at" : "2015-03-05 22:33:49 +0000",
    "user" : {
      "name" : "Christian Pantel",
      "screen_name" : "cpantel",
      "protected" : false,
      "id_str" : "24698409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1157862096\/IMG_8191_Twitter_normal.jpg",
      "id" : 24698409,
      "verified" : false
    }
  },
  "id" : 573612691761160192,
  "created_at" : "2015-03-05 22:34:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Known",
      "screen_name" : "withknown",
      "indices" : [ 13, 23 ],
      "id_str" : "227050193",
      "id" : 227050193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573611224132288512",
  "text" : "Checking out @withknown today, really like the emphasis of maintaining ownership of data and ability to self-host as well. Pro plan too.",
  "id" : 573611224132288512,
  "created_at" : "2015-03-05 22:29:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573580430240145408",
  "text" : "One of the many reasons learning ecologies are of such interest to me is that they have value both as an instructor and a life-long learner.",
  "id" : 573580430240145408,
  "created_at" : "2015-03-05 20:26:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573232893784301568",
  "text" : "Responsive web design is not the future of e-learning, it's a requirement. Creating and supporting learning ecologies is the future to me.",
  "id" : 573232893784301568,
  "created_at" : "2015-03-04 21:25:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learnerexperience",
      "indices" : [ 51, 69 ]
    }, {
      "text" : "multidevicelearning",
      "indices" : [ 71, 91 ]
    }, {
      "text" : "learningecologies",
      "indices" : [ 93, 111 ]
    }, {
      "text" : "flatfileCMS",
      "indices" : [ 112, 124 ]
    }, {
      "text" : "opensource",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572900169840128000",
  "text" : "Any interest in a Slack team space to chat Web LX? #learnerexperience, #multidevicelearning, #learningecologies #flatfileCMS #opensource",
  "id" : 572900169840128000,
  "created_at" : "2015-03-03 23:23:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openeducationwk",
      "indices" : [ 66, 82 ]
    }, {
      "text" : "bcpse",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/CVnNu374h0",
      "expanded_url" : "http:\/\/ht.ly\/JQF1p",
      "display_url" : "ht.ly\/JQF1p"
    } ]
  },
  "geo" : { },
  "id_str" : "572804710903627777",
  "text" : "RT @BCcampus: Have you seen the schedule of our Open Webinars for #openeducationwk? They start Monday! 5 sessions: http:\/\/t.co\/CVnNu374h0. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openeducationwk",
        "indices" : [ 52, 68 ]
      }, {
        "text" : "bcpse",
        "indices" : [ 125, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/CVnNu374h0",
        "expanded_url" : "http:\/\/ht.ly\/JQF1p",
        "display_url" : "ht.ly\/JQF1p"
      } ]
    },
    "geo" : { },
    "id_str" : "572591007319130112",
    "text" : "Have you seen the schedule of our Open Webinars for #openeducationwk? They start Monday! 5 sessions: http:\/\/t.co\/CVnNu374h0. #bcpse",
    "id" : 572591007319130112,
    "created_at" : "2015-03-03 02:55:09 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 572804710903627777,
  "created_at" : "2015-03-03 17:04:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572466570804375553",
  "text" : "Why should instructors care about open source flat-file CMS's? To me: portability, security, speed, modularity, reusability and flexibility.",
  "id" : 572466570804375553,
  "created_at" : "2015-03-02 18:40:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572458798587068417",
  "text" : "As teachers in a connected world, we need to provide value to students even when they have access to better learning resources than we do.",
  "id" : 572458798587068417,
  "created_at" : "2015-03-02 18:09:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kimmy K.",
      "screen_name" : "kimzzzy88",
      "indices" : [ 0, 10 ],
      "id_str" : "1946054928",
      "id" : 1946054928
    }, {
      "name" : "HeyAvailable",
      "screen_name" : "HeyAvailable",
      "indices" : [ 11, 24 ],
      "id_str" : "599987583",
      "id" : 599987583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/EJELK4f4Q3",
      "expanded_url" : "http:\/\/paulhibbitts.com",
      "display_url" : "paulhibbitts.com"
    } ]
  },
  "in_reply_to_status_id_str" : "572177739538554880",
  "geo" : { },
  "id_str" : "572207584297549824",
  "in_reply_to_user_id" : 1946054928,
  "text" : "@kimzzzy88 @HeyAvailable Always happy to chat. Please email paul at http:\/\/t.co\/EJELK4f4Q3 and we can make arrangements.",
  "id" : 572207584297549824,
  "in_reply_to_status_id" : 572177739538554880,
  "created_at" : "2015-03-02 01:31:33 +0000",
  "in_reply_to_screen_name" : "kimzzzy88",
  "in_reply_to_user_id_str" : "1946054928",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]