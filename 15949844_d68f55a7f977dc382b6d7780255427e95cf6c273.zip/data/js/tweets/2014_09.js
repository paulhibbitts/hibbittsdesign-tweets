Grailbird.data.tweets_2014_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KS Huntley",
      "screen_name" : "MillerTAFEScott",
      "indices" : [ 0, 16 ],
      "id_str" : "17593065",
      "id" : 17593065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517144765817565186",
  "geo" : { },
  "id_str" : "517145325887553536",
  "in_reply_to_user_id" : 295523228,
  "text" : "@MillerTAFEScott Love the situational approach. Thanks very much for sharing!",
  "id" : 517145325887553536,
  "in_reply_to_status_id" : 517144765817565186,
  "created_at" : "2014-10-01 02:53:48 +0000",
  "in_reply_to_screen_name" : "kshuntley",
  "in_reply_to_user_id_str" : "295523228",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KS Huntley",
      "screen_name" : "MillerTAFEScott",
      "indices" : [ 0, 16 ],
      "id_str" : "17593065",
      "id" : 17593065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517126054591201280",
  "geo" : { },
  "id_str" : "517141262722273280",
  "in_reply_to_user_id" : 295523228,
  "text" : "@MillerTAFEScott Awesome to hear! Any highlights that you could share?",
  "id" : 517141262722273280,
  "in_reply_to_status_id" : 517126054591201280,
  "created_at" : "2014-10-01 02:37:39 +0000",
  "in_reply_to_screen_name" : "kshuntley",
  "in_reply_to_user_id_str" : "295523228",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootnz14",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/tdBXUWnYzQ",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/moodle-moot-nz14-designing-a-multi-device-moodle-course-site-a-case-study\/",
      "display_url" : "slides.com\/paulhibbitts\/m\u2026"
    }, {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/nCgLp8FCcj",
      "expanded_url" : "http:\/\/1drv.ms\/1qYSWke",
      "display_url" : "1drv.ms\/1qYSWke"
    } ]
  },
  "geo" : { },
  "id_str" : "517073848890822657",
  "text" : "My pleasure to be part of #mootnz14 Moodle Mobile Workshop this AM! Slides http:\/\/t.co\/tdBXUWnYzQ OneNote notebook http:\/\/t.co\/nCgLp8FCcj",
  "id" : 517073848890822657,
  "created_at" : "2014-09-30 22:09:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rochelle Savage",
      "screen_name" : "rsavagenz",
      "indices" : [ 0, 10 ],
      "id_str" : "187700165",
      "id" : 187700165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517068577061339136",
  "geo" : { },
  "id_str" : "517071252239171584",
  "in_reply_to_user_id" : 187700165,
  "text" : "@rsavagenz You are most welcome! I've found it a very helpful alternative feedback channel for my own students.",
  "id" : 517071252239171584,
  "in_reply_to_status_id" : 517068577061339136,
  "created_at" : "2014-09-30 21:59:27 +0000",
  "in_reply_to_screen_name" : "rsavagenz",
  "in_reply_to_user_id_str" : "187700165",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootnz14",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517055218715201536",
  "text" : "I will be starting my \"Designing a Multi-device Moodle Course Site: A Case Study\" presentation for #mootnz14 in about 5 minutes.",
  "id" : 517055218715201536,
  "created_at" : "2014-09-30 20:55:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 51, 66 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 70, 79 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootnz14",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/P1YfuDsRg1",
      "expanded_url" : "http:\/\/www.linkedin.com\/pulse\/article\/20140923193943-572658-course-companion-learner-experience-principles",
      "display_url" : "linkedin.com\/pulse\/article\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517031205183553537",
  "text" : "\"(Multi-device) Learning Experience Principles\" by @hibbittsdesign on @LinkedIn http:\/\/t.co\/P1YfuDsRg1 #mootnz14",
  "id" : 517031205183553537,
  "created_at" : "2014-09-30 19:20:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft SharePoint",
      "screen_name" : "SharePoint",
      "indices" : [ 3, 14 ],
      "id_str" : "26541422",
      "id" : 26541422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/9tA9SEQGSE",
      "expanded_url" : "http:\/\/ow.ly\/C7qlz",
      "display_url" : "ow.ly\/C7qlz"
    } ]
  },
  "geo" : { },
  "id_str" : "516989863204495360",
  "text" : "RT @SharePoint: Introducing the Enterprise Social Resource Center! http:\/\/t.co\/9tA9SEQGSE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/9tA9SEQGSE",
        "expanded_url" : "http:\/\/ow.ly\/C7qlz",
        "display_url" : "ow.ly\/C7qlz"
      } ]
    },
    "geo" : { },
    "id_str" : "516986870589558784",
    "text" : "Introducing the Enterprise Social Resource Center! http:\/\/t.co\/9tA9SEQGSE",
    "id" : 516986870589558784,
    "created_at" : "2014-09-30 16:24:09 +0000",
    "user" : {
      "name" : "Microsoft SharePoint",
      "screen_name" : "SharePoint",
      "protected" : false,
      "id_str" : "26541422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458756244300247040\/Kbi4ibpG_normal.png",
      "id" : 26541422,
      "verified" : false
    }
  },
  "id" : 516989863204495360,
  "created_at" : "2014-09-30 16:36:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516985071245721600",
  "text" : "Realizing more and more how designing multi-device learning experiences has forever changed how I view and facilitate learning in general.",
  "id" : 516985071245721600,
  "created_at" : "2014-09-30 16:17:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clark Quinn",
      "screen_name" : "Quinnovator",
      "indices" : [ 3, 15 ],
      "id_str" : "15312626",
      "id" : 15312626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mLearning",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/Z0seh0U8XC",
      "expanded_url" : "http:\/\/floatlearning.com\/mml-book\/",
      "display_url" : "floatlearning.com\/mml-book\/"
    } ]
  },
  "geo" : { },
  "id_str" : "516763873752260608",
  "text" : "RT @Quinnovator: A new and likely valuable #mLearning book coming: http:\/\/t.co\/Z0seh0U8XC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mLearning",
        "indices" : [ 26, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/Z0seh0U8XC",
        "expanded_url" : "http:\/\/floatlearning.com\/mml-book\/",
        "display_url" : "floatlearning.com\/mml-book\/"
      } ]
    },
    "geo" : { },
    "id_str" : "516735062910308352",
    "text" : "A new and likely valuable #mLearning book coming: http:\/\/t.co\/Z0seh0U8XC",
    "id" : 516735062910308352,
    "created_at" : "2014-09-29 23:43:34 +0000",
    "user" : {
      "name" : "Clark Quinn",
      "screen_name" : "Quinnovator",
      "protected" : false,
      "id_str" : "15312626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639121092083224576\/9rAOP3Tq_normal.jpg",
      "id" : 15312626,
      "verified" : false
    }
  },
  "id" : 516763873752260608,
  "created_at" : "2014-09-30 01:38:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootnz14",
      "indices" : [ 23, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/P3rLeU3Re0",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/moodle-moot-nz14-designing-a-multi-device-moodle-course-site-a-case-study#\/",
      "display_url" : "slides.com\/paulhibbitts\/m\u2026"
    }, {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/nCgLp8FCcj",
      "expanded_url" : "http:\/\/1drv.ms\/1qYSWke",
      "display_url" : "1drv.ms\/1qYSWke"
    } ]
  },
  "geo" : { },
  "id_str" : "516695557528899585",
  "text" : "&lt; 24 hours until my #mootnz14 Multi-device Moodle remote presentation. Slides http:\/\/t.co\/P3rLeU3Re0 OneNote notebook http:\/\/t.co\/nCgLp8FCcj",
  "id" : 516695557528899585,
  "created_at" : "2014-09-29 21:06:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516666055268507650",
  "text" : "Mulling over a new professional endeavour, simply named \"The Learner Experience Project\". Overwhelming, but very exciting possibilities.",
  "id" : 516666055268507650,
  "created_at" : "2014-09-29 19:09:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515197803350720512",
  "text" : "Learning is a process, not an event.",
  "id" : 515197803350720512,
  "created_at" : "2014-09-25 17:55:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/514916147037483008\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Mf2cMRKdKm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByVZgUrIAAAAyab.png",
      "id_str" : "514916144244064256",
      "id" : 514916144244064256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByVZgUrIAAAAyab.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 856,
        "resize" : "fit",
        "w" : 1188
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Mf2cMRKdKm"
    } ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 69, 79 ]
    }, {
      "text" : "SFU",
      "indices" : [ 101, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514916147037483008",
  "text" : "Based on student feedback, more updates to the multi-device friendly #CanvasLMS course companion for #SFU CMPT 363 http:\/\/t.co\/Mf2cMRKdKm",
  "id" : 514916147037483008,
  "created_at" : "2014-09-24 23:15:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/7JTe0T8Dq2",
      "expanded_url" : "https:\/\/www.linkedin.com\/today\/post\/article\/20140923193943-572658-course-companion-learner-experience-principles",
      "display_url" : "linkedin.com\/today\/post\/art\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514499433031929856",
  "text" : "Course Companion Learner Experience Principles https:\/\/t.co\/7JTe0T8Dq2",
  "id" : 514499433031929856,
  "created_at" : "2014-09-23 19:39:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Straumsheim",
      "screen_name" : "carlstraumsheim",
      "indices" : [ 3, 19 ],
      "id_str" : "30349233",
      "id" : 30349233
    }, {
      "name" : "George",
      "screen_name" : "georgekroner",
      "indices" : [ 52, 65 ],
      "id_str" : "9128102",
      "id" : 9128102
    }, {
      "name" : "Phil Hill",
      "screen_name" : "PhilOnEdTech",
      "indices" : [ 66, 79 ],
      "id_str" : "17997570",
      "id" : 17997570
    }, {
      "name" : "Casey Green",
      "screen_name" : "DigitalTweed",
      "indices" : [ 80, 93 ],
      "id_str" : "23250802",
      "id" : 23250802
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/carlstraumsheim\/status\/514402710922493952\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/1rWQfSYxh7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByOGigBIgAActQM.png",
      "id_str" : "514402709718728704",
      "id" : 514402709718728704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByOGigBIgAActQM.png",
      "sizes" : [ {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 901
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 901
      } ],
      "display_url" : "pic.twitter.com\/1rWQfSYxh7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514486902523969537",
  "text" : "RT @carlstraumsheim: I could stare at this all day. @georgekroner @PhilOnEdTech @DigitalTweed http:\/\/t.co\/1rWQfSYxh7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George",
        "screen_name" : "georgekroner",
        "indices" : [ 31, 44 ],
        "id_str" : "9128102",
        "id" : 9128102
      }, {
        "name" : "Phil Hill",
        "screen_name" : "PhilOnEdTech",
        "indices" : [ 45, 58 ],
        "id_str" : "17997570",
        "id" : 17997570
      }, {
        "name" : "Casey Green",
        "screen_name" : "DigitalTweed",
        "indices" : [ 59, 72 ],
        "id_str" : "23250802",
        "id" : 23250802
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/carlstraumsheim\/status\/514402710922493952\/photo\/1",
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/1rWQfSYxh7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByOGigBIgAActQM.png",
        "id_str" : "514402709718728704",
        "id" : 514402709718728704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByOGigBIgAActQM.png",
        "sizes" : [ {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 609,
          "resize" : "fit",
          "w" : 901
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 609,
          "resize" : "fit",
          "w" : 901
        } ],
        "display_url" : "pic.twitter.com\/1rWQfSYxh7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514402710922493952",
    "text" : "I could stare at this all day. @georgekroner @PhilOnEdTech @DigitalTweed http:\/\/t.co\/1rWQfSYxh7",
    "id" : 514402710922493952,
    "created_at" : "2014-09-23 13:15:38 +0000",
    "user" : {
      "name" : "Carl Straumsheim",
      "screen_name" : "carlstraumsheim",
      "protected" : false,
      "id_str" : "30349233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/423503311069650944\/33K85Igb_normal.jpeg",
      "id" : 30349233,
      "verified" : false
    }
  },
  "id" : 514486902523969537,
  "created_at" : "2014-09-23 18:50:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Rispin",
      "screen_name" : "moodleyou",
      "indices" : [ 3, 13 ],
      "id_str" : "196743392",
      "id" : 196743392
    }, {
      "name" : "ADAPTLAND",
      "screen_name" : "adaptland",
      "indices" : [ 84, 94 ],
      "id_str" : "791111994",
      "id" : 791111994
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 95, 110 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "~|Iky Br\u00F8w\u03B7|~",
      "screen_name" : "IkybrownUS",
      "indices" : [ 111, 122 ],
      "id_str" : "550592981",
      "id" : 550592981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/N0QaPWF79G",
      "expanded_url" : "http:\/\/paper.li\/moodleyou",
      "display_url" : "paper.li\/moodleyou"
    } ]
  },
  "geo" : { },
  "id_str" : "514219217860984832",
  "text" : "RT @moodleyou: The Moodle Educator Daily is out! http:\/\/t.co\/N0QaPWF79G Stories via @adaptland @hibbittsdesign @IkybrownUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/paper.li\" rel=\"nofollow\"\u003EPaper.li\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ADAPTLAND",
        "screen_name" : "adaptland",
        "indices" : [ 69, 79 ],
        "id_str" : "791111994",
        "id" : 791111994
      }, {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 80, 95 ],
        "id_str" : "15949844",
        "id" : 15949844
      }, {
        "name" : "~|Iky Br\u00F8w\u03B7|~",
        "screen_name" : "IkybrownUS",
        "indices" : [ 96, 107 ],
        "id_str" : "550592981",
        "id" : 550592981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/N0QaPWF79G",
        "expanded_url" : "http:\/\/paper.li\/moodleyou",
        "display_url" : "paper.li\/moodleyou"
      } ]
    },
    "geo" : { },
    "id_str" : "514210747157860352",
    "text" : "The Moodle Educator Daily is out! http:\/\/t.co\/N0QaPWF79G Stories via @adaptland @hibbittsdesign @IkybrownUS",
    "id" : 514210747157860352,
    "created_at" : "2014-09-23 00:32:50 +0000",
    "user" : {
      "name" : "Keith Rispin",
      "screen_name" : "moodleyou",
      "protected" : false,
      "id_str" : "196743392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1173359678\/moodle_powered_normal.png",
      "id" : 196743392,
      "verified" : false
    }
  },
  "id" : 514219217860984832,
  "created_at" : "2014-09-23 01:06:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TRU, Open Learning",
      "screen_name" : "TRUOpenLearning",
      "indices" : [ 41, 57 ],
      "id_str" : "23662900",
      "id" : 23662900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514161542150225920",
  "text" : "Thanks to everyone who participated from @TRUOpenLearning, enjoyed the company and discussions.",
  "id" : 514161542150225920,
  "created_at" : "2014-09-22 21:17:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/pRCSOu1LY1",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/tru-designing-a-multi-device-moodle-course-site-a-case-study",
      "display_url" : "slides.com\/paulhibbitts\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514160445037764608",
  "text" : "Slides for my second talk at Thompson Rivers University this AM, \"Designing a Multi-device Moodle Course Site\" http:\/\/t.co\/pRCSOu1LY1",
  "id" : 514160445037764608,
  "created_at" : "2014-09-22 21:12:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Irwin DeVries",
      "screen_name" : "IrwinDev",
      "indices" : [ 0, 9 ],
      "id_str" : "120194872",
      "id" : 120194872
    }, {
      "name" : "Trudi Scrumptious",
      "screen_name" : "tru",
      "indices" : [ 122, 126 ],
      "id_str" : "4588771",
      "id" : 4588771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514122303634808832",
  "geo" : { },
  "id_str" : "514159055288676352",
  "in_reply_to_user_id" : 120194872,
  "text" : "@IrwinDev Nice to see you again, and thanks very much for tweeting about today's sessions. It was my pleasure to speak at @TRU!",
  "id" : 514159055288676352,
  "in_reply_to_status_id" : 514122303634808832,
  "created_at" : "2014-09-22 21:07:26 +0000",
  "in_reply_to_screen_name" : "IrwinDev",
  "in_reply_to_user_id_str" : "120194872",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Irwin DeVries",
      "screen_name" : "IrwinDev",
      "indices" : [ 3, 12 ],
      "id_str" : "120194872",
      "id" : 120194872
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 89, 104 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "Giltzow Wingford",
      "screen_name" : "mytru",
      "indices" : [ 106, 112 ],
      "id_str" : "4254488865",
      "id" : 4254488865
    }, {
      "name" : "TRU, Open Learning",
      "screen_name" : "TRUOpenLearning",
      "indices" : [ 113, 129 ],
      "id_str" : "23662900",
      "id" : 23662900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514158253761396736",
  "text" : "RT @IrwinDev: Learners will choose the best technology at hand for what they want to do. @hibbittsdesign  @myTRU @TRUOpenLearning",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 75, 90 ],
        "id_str" : "15949844",
        "id" : 15949844
      }, {
        "name" : "Giltzow Wingford",
        "screen_name" : "mytru",
        "indices" : [ 92, 98 ],
        "id_str" : "4254488865",
        "id" : 4254488865
      }, {
        "name" : "TRU, Open Learning",
        "screen_name" : "TRUOpenLearning",
        "indices" : [ 99, 115 ],
        "id_str" : "23662900",
        "id" : 23662900
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514119525193621505",
    "text" : "Learners will choose the best technology at hand for what they want to do. @hibbittsdesign  @myTRU @TRUOpenLearning",
    "id" : 514119525193621505,
    "created_at" : "2014-09-22 18:30:21 +0000",
    "user" : {
      "name" : "Irwin DeVries",
      "screen_name" : "IrwinDev",
      "protected" : false,
      "id_str" : "120194872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718662718132064258\/jmAsqZvL_normal.jpg",
      "id" : 120194872,
      "verified" : false
    }
  },
  "id" : 514158253761396736,
  "created_at" : "2014-09-22 21:04:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/UPun1Ln5Ri",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/tru-developing-a-course-in-the-open-a-case-study#\/",
      "display_url" : "slides.com\/paulhibbitts\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514073683422609408",
  "text" : "Slides for my first talk at Thompson Rivers University this AM, \"Developing a Course in the Open\" http:\/\/t.co\/UPun1Ln5Ri The Future is Open.",
  "id" : 514073683422609408,
  "created_at" : "2014-09-22 15:28:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Hurff",
      "screen_name" : "scotthurff",
      "indices" : [ 3, 14 ],
      "id_str" : "3283",
      "id" : 3283
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/scotthurff\/status\/512650045301456896\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/YBUrdqn2uF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx1Mf-jIcAAcx3x.png",
      "id_str" : "512650044840112128",
      "id" : 512650044840112128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx1Mf-jIcAAcx3x.png",
      "sizes" : [ {
        "h" : 305,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1378
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YBUrdqn2uF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/KghJf1pKZ4",
      "expanded_url" : "http:\/\/buff.ly\/1mdZay4",
      "display_url" : "buff.ly\/1mdZay4"
    } ]
  },
  "geo" : { },
  "id_str" : "512668045496844289",
  "text" : "RT @scotthurff: How are the new iPhones going to mess with your designs? I tried to find out for you: http:\/\/t.co\/KghJf1pKZ4 http:\/\/t.co\/YB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/scotthurff\/status\/512650045301456896\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/YBUrdqn2uF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx1Mf-jIcAAcx3x.png",
        "id_str" : "512650044840112128",
        "id" : 512650044840112128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx1Mf-jIcAAcx3x.png",
        "sizes" : [ {
          "h" : 305,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1378
        }, {
          "h" : 173,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/YBUrdqn2uF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/KghJf1pKZ4",
        "expanded_url" : "http:\/\/buff.ly\/1mdZay4",
        "display_url" : "buff.ly\/1mdZay4"
      } ]
    },
    "geo" : { },
    "id_str" : "512650045301456896",
    "text" : "How are the new iPhones going to mess with your designs? I tried to find out for you: http:\/\/t.co\/KghJf1pKZ4 http:\/\/t.co\/YBUrdqn2uF",
    "id" : 512650045301456896,
    "created_at" : "2014-09-18 17:11:10 +0000",
    "user" : {
      "name" : "Scott Hurff",
      "screen_name" : "scotthurff",
      "protected" : false,
      "id_str" : "3283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3628476340\/a07dee4e8f5ba17bafb2bfefee311d83_normal.jpeg",
      "id" : 3283,
      "verified" : false
    }
  },
  "id" : 512668045496844289,
  "created_at" : "2014-09-18 18:22:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512667486412881920",
  "text" : "Student comment on assigned reading warms my heart - \u201CI found the entire piece interesting. Very different from the dry texts I am used to.\u201D",
  "id" : 512667486412881920,
  "created_at" : "2014-09-18 18:20:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UX Mastery",
      "screen_name" : "uxmastery",
      "indices" : [ 3, 13 ],
      "id_str" : "631741925",
      "id" : 631741925
    }, {
      "name" : "Everett McKay",
      "screen_name" : "UXDesignEdge",
      "indices" : [ 95, 108 ],
      "id_str" : "205411420",
      "id" : 205411420
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/uBwqOYdmqz",
      "expanded_url" : "http:\/\/uxmastery.com\/ask-uxperts-everett-mckay\/",
      "display_url" : "uxmastery.com\/ask-uxperts-ev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512456260726554624",
  "text" : "RT @uxmastery: Our next Ask the UXperts will be about UI for non-designers with Everett McKay (@UXDesignEdge) http:\/\/t.co\/uBwqOYdmqz #ux",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Everett McKay",
        "screen_name" : "UXDesignEdge",
        "indices" : [ 80, 93 ],
        "id_str" : "205411420",
        "id" : 205411420
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ux",
        "indices" : [ 118, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/uBwqOYdmqz",
        "expanded_url" : "http:\/\/uxmastery.com\/ask-uxperts-everett-mckay\/",
        "display_url" : "uxmastery.com\/ask-uxperts-ev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "512434604222201856",
    "text" : "Our next Ask the UXperts will be about UI for non-designers with Everett McKay (@UXDesignEdge) http:\/\/t.co\/uBwqOYdmqz #ux",
    "id" : 512434604222201856,
    "created_at" : "2014-09-18 02:55:04 +0000",
    "user" : {
      "name" : "UX Mastery",
      "screen_name" : "uxmastery",
      "protected" : false,
      "id_str" : "631741925",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724856215910625285\/yKvLknw6_normal.jpg",
      "id" : 631741925,
      "verified" : false
    }
  },
  "id" : 512456260726554624,
  "created_at" : "2014-09-18 04:21:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Embedly",
      "screen_name" : "embedly",
      "indices" : [ 12, 20 ],
      "id_str" : "82485597",
      "id" : 82485597
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/7psv1b0Ih3",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/17482\/pages\/week-3-materials-sep-18-24",
      "display_url" : "canvas.sfu.ca\/courses\/17482\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512358727354052608",
  "text" : "Want to use @embedly with #CanvasLMS? Add Embedly code to HTML doc in Files and then display in iFrame within Page https:\/\/t.co\/7psv1b0Ih3",
  "id" : 512358727354052608,
  "created_at" : "2014-09-17 21:53:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austen Sinclair",
      "screen_name" : "Austen_Sinclair",
      "indices" : [ 0, 16 ],
      "id_str" : "60157437",
      "id" : 60157437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512093610141941760",
  "geo" : { },
  "id_str" : "512271473449660416",
  "in_reply_to_user_id" : 60157437,
  "text" : "@Austen_Sinclair Thanks very much, I am really looking forward to being a part of the Moodle Mobile Workshop!",
  "id" : 512271473449660416,
  "in_reply_to_status_id" : 512093610141941760,
  "created_at" : "2014-09-17 16:06:51 +0000",
  "in_reply_to_screen_name" : "Austen_Sinclair",
  "in_reply_to_user_id_str" : "60157437",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Floro",
      "screen_name" : "nickfloro",
      "indices" : [ 3, 13 ],
      "id_str" : "15578710",
      "id" : 15578710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/2AazBTQk0z",
      "expanded_url" : "http:\/\/zite.to\/1o1HQYl",
      "display_url" : "zite.to\/1o1HQYl"
    } ]
  },
  "geo" : { },
  "id_str" : "512093287663288320",
  "text" : "RT @nickfloro: Microsoft just created the only tablet keyboard you'll ever need http:\/\/t.co\/2AazBTQk0z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/2AazBTQk0z",
        "expanded_url" : "http:\/\/zite.to\/1o1HQYl",
        "display_url" : "zite.to\/1o1HQYl"
      } ]
    },
    "geo" : { },
    "id_str" : "512083111262564352",
    "text" : "Microsoft just created the only tablet keyboard you'll ever need http:\/\/t.co\/2AazBTQk0z",
    "id" : 512083111262564352,
    "created_at" : "2014-09-17 03:38:22 +0000",
    "user" : {
      "name" : "Nick Floro",
      "screen_name" : "nickfloro",
      "protected" : false,
      "id_str" : "15578710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/130051719\/Nick-Photo-Side_0508c_normal.jpg",
      "id" : 15578710,
      "verified" : false
    }
  },
  "id" : 512093287663288320,
  "created_at" : "2014-09-17 04:18:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy L. Bissette",
      "screen_name" : "TLBissette",
      "indices" : [ 3, 14 ],
      "id_str" : "204032180",
      "id" : 204032180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/fRL0kARDqR",
      "expanded_url" : "http:\/\/ow.ly\/2NBJZL",
      "display_url" : "ow.ly\/2NBJZL"
    } ]
  },
  "geo" : { },
  "id_str" : "512036423370031104",
  "text" : "RT @TLBissette: Smartphone Use Rising Fast Among College Students http:\/\/t.co\/fRL0kARDqR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/fRL0kARDqR",
        "expanded_url" : "http:\/\/ow.ly\/2NBJZL",
        "display_url" : "ow.ly\/2NBJZL"
      } ]
    },
    "geo" : { },
    "id_str" : "512034341250420736",
    "text" : "Smartphone Use Rising Fast Among College Students http:\/\/t.co\/fRL0kARDqR",
    "id" : 512034341250420736,
    "created_at" : "2014-09-17 00:24:34 +0000",
    "user" : {
      "name" : "Tracy L. Bissette",
      "screen_name" : "TLBissette",
      "protected" : false,
      "id_str" : "204032180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410924455\/d736a7d934b7b10b3199fe9dc6e2dfdf_normal.png",
      "id" : 204032180,
      "verified" : false
    }
  },
  "id" : 512036423370031104,
  "created_at" : "2014-09-17 00:32:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 0, 8 ],
      "id_str" : "10675",
      "id" : 10675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511941953832108033",
  "geo" : { },
  "id_str" : "511944855296421889",
  "in_reply_to_user_id" : 10675,
  "text" : "@gordonr Please have their chocolate donut with mint icing for me!",
  "id" : 511944855296421889,
  "in_reply_to_status_id" : 511941953832108033,
  "created_at" : "2014-09-16 18:28:59 +0000",
  "in_reply_to_screen_name" : "gordonr",
  "in_reply_to_user_id_str" : "10675",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fredrik Matheson",
      "screen_name" : "movito",
      "indices" : [ 3, 10 ],
      "id_str" : "700593",
      "id" : 700593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511944554912956418",
  "text" : "RT @movito: I think I'll just filter out every bit of Apple Watch news, buy one, and make up my own mind about it when I've used it for a w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511940705498177537",
    "text" : "I think I'll just filter out every bit of Apple Watch news, buy one, and make up my own mind about it when I've used it for a while.",
    "id" : 511940705498177537,
    "created_at" : "2014-09-16 18:12:30 +0000",
    "user" : {
      "name" : "Fredrik Matheson",
      "screen_name" : "movito",
      "protected" : false,
      "id_str" : "700593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460457076204916736\/jey8mT4q_normal.png",
      "id" : 700593,
      "verified" : false
    }
  },
  "id" : 511944554912956418,
  "created_at" : "2014-09-16 18:27:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhan Patel",
      "screen_name" : "Farhanpatel",
      "indices" : [ 3, 15 ],
      "id_str" : "18129659",
      "id" : 18129659
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 18, 33 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "Scott Kerr",
      "screen_name" : "scott_kerr",
      "indices" : [ 35, 46 ],
      "id_str" : "11837102",
      "id" : 11837102
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/scott_kerr\/status\/506232489720176640\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/zptSOMEyBC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwZ_xEsIMAA51al.jpg",
      "id_str" : "506232489174904832",
      "id" : 506232489174904832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwZ_xEsIMAA51al.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 285,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zptSOMEyBC"
    } ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 71, 74 ]
    }, {
      "text" : "UI",
      "indices" : [ 79, 82 ]
    }, {
      "text" : "design",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511943581188493313",
  "text" : "RT @Farhanpatel: .@hibbittsdesign \u201C@scott_kerr: The difference between #UX and #UI: explained in cereal\n\n#design http:\/\/t.co\/zptSOMEyBC\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 1, 16 ],
        "id_str" : "15949844",
        "id" : 15949844
      }, {
        "name" : "Scott Kerr",
        "screen_name" : "scott_kerr",
        "indices" : [ 18, 29 ],
        "id_str" : "11837102",
        "id" : 11837102
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/scott_kerr\/status\/506232489720176640\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/zptSOMEyBC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwZ_xEsIMAA51al.jpg",
        "id_str" : "506232489174904832",
        "id" : 506232489174904832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwZ_xEsIMAA51al.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 162,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 285,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zptSOMEyBC"
      } ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 54, 57 ]
      }, {
        "text" : "UI",
        "indices" : [ 62, 65 ]
      }, {
        "text" : "design",
        "indices" : [ 88, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511938325532667904",
    "text" : ".@hibbittsdesign \u201C@scott_kerr: The difference between #UX and #UI: explained in cereal\n\n#design http:\/\/t.co\/zptSOMEyBC\u201D",
    "id" : 511938325532667904,
    "created_at" : "2014-09-16 18:03:02 +0000",
    "user" : {
      "name" : "Farhan Patel",
      "screen_name" : "Farhanpatel",
      "protected" : false,
      "id_str" : "18129659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1660058153\/332381_641654518255_121402639_34566660_1817936857_o_normal.jpg",
      "id" : 18129659,
      "verified" : false
    }
  },
  "id" : 511943581188493313,
  "created_at" : "2014-09-16 18:23:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhan Patel",
      "screen_name" : "Farhanpatel",
      "indices" : [ 0, 12 ],
      "id_str" : "18129659",
      "id" : 18129659
    }, {
      "name" : "Scott Kerr",
      "screen_name" : "scott_kerr",
      "indices" : [ 13, 24 ],
      "id_str" : "11837102",
      "id" : 11837102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511938325532667904",
  "geo" : { },
  "id_str" : "511943547189477376",
  "in_reply_to_user_id" : 18129659,
  "text" : "@Farhanpatel @scott_kerr Awesome visual example!",
  "id" : 511943547189477376,
  "in_reply_to_status_id" : 511938325532667904,
  "created_at" : "2014-09-16 18:23:47 +0000",
  "in_reply_to_screen_name" : "Farhanpatel",
  "in_reply_to_user_id_str" : "18129659",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Bersin",
      "screen_name" : "Josh_Bersin",
      "indices" : [ 3, 15 ],
      "id_str" : "14211474",
      "id" : 14211474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "skills",
      "indices" : [ 53, 60 ]
    }, {
      "text" : "hr",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "career",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/n6i5hON9ld",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/article\/20140913163925-131079-are-you-ready-to-become-obsolete-what-i-ve-learned-about-continuous-reinvention",
      "display_url" : "linkedin.com\/pulse\/article\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "511939779894968320",
  "text" : "RT @Josh_Bersin: There is a 3 year half-life on your #skills. Are you ready to become obsolete? Let's hope not..  https:\/\/t.co\/n6i5hON9ld #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "skills",
        "indices" : [ 36, 43 ]
      }, {
        "text" : "hr",
        "indices" : [ 121, 124 ]
      }, {
        "text" : "career",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/n6i5hON9ld",
        "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/article\/20140913163925-131079-are-you-ready-to-become-obsolete-what-i-ve-learned-about-continuous-reinvention",
        "display_url" : "linkedin.com\/pulse\/article\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "511318461587288064",
    "text" : "There is a 3 year half-life on your #skills. Are you ready to become obsolete? Let's hope not..  https:\/\/t.co\/n6i5hON9ld #hr #career",
    "id" : 511318461587288064,
    "created_at" : "2014-09-15 00:59:55 +0000",
    "user" : {
      "name" : "Josh Bersin",
      "screen_name" : "Josh_Bersin",
      "protected" : false,
      "id_str" : "14211474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2869484348\/9ffaeb3cd186c9dc6ff174fa81b4bb9c_normal.jpeg",
      "id" : 14211474,
      "verified" : false
    }
  },
  "id" : 511939779894968320,
  "created_at" : "2014-09-16 18:08:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MootNZ14",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/P3rLeU3Re0",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/moodle-moot-nz14-designing-a-multi-device-moodle-course-site-a-case-study#\/",
      "display_url" : "slides.com\/paulhibbitts\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "511904596047171584",
  "text" : "Draft slides for my case study of designing a multi-device Moodle course site @ the New Zealand Moodle Moot http:\/\/t.co\/P3rLeU3Re0 #MootNZ14",
  "id" : 511904596047171584,
  "created_at" : "2014-09-16 15:49:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511572921182355457",
  "text" : "Excited to be speaking about developing courses in the open and multi-device learning experiences at Thompson Rivers University in one week!",
  "id" : 511572921182355457,
  "created_at" : "2014-09-15 17:51:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kelly",
      "screen_name" : "LnDDave",
      "indices" : [ 3, 11 ],
      "id_str" : "69493393",
      "id" : 69493393
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AppleWatch",
      "indices" : [ 71, 82 ]
    }, {
      "text" : "edchat",
      "indices" : [ 106, 113 ]
    }, {
      "text" : "lrnchat",
      "indices" : [ 114, 122 ]
    }, {
      "text" : "education",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/nJdzbODNvq",
      "expanded_url" : "http:\/\/davidkelly.me\/2014\/09\/apple-watch-inevitable-emergence-wlearning\/",
      "display_url" : "davidkelly.me\/2014\/09\/apple-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510846031588626432",
  "text" : "RT @LnDDave: Apple Watch and the Inevitable Emergence of \"wLearning\" - #AppleWatch http:\/\/t.co\/nJdzbODNvq #edchat #lrnchat #education",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AppleWatch",
        "indices" : [ 58, 69 ]
      }, {
        "text" : "edchat",
        "indices" : [ 93, 100 ]
      }, {
        "text" : "lrnchat",
        "indices" : [ 101, 109 ]
      }, {
        "text" : "education",
        "indices" : [ 110, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/nJdzbODNvq",
        "expanded_url" : "http:\/\/davidkelly.me\/2014\/09\/apple-watch-inevitable-emergence-wlearning\/",
        "display_url" : "davidkelly.me\/2014\/09\/apple-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "510841821606322176",
    "text" : "Apple Watch and the Inevitable Emergence of \"wLearning\" - #AppleWatch http:\/\/t.co\/nJdzbODNvq #edchat #lrnchat #education",
    "id" : 510841821606322176,
    "created_at" : "2014-09-13 17:25:55 +0000",
    "user" : {
      "name" : "David Kelly",
      "screen_name" : "LnDDave",
      "protected" : false,
      "id_str" : "69493393",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1908027699\/OnlineScrape4_normal.png",
      "id" : 69493393,
      "verified" : false
    }
  },
  "id" : 510846031588626432,
  "created_at" : "2014-09-13 17:42:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 3, 15 ],
      "id_str" : "66913866",
      "id" : 66913866
    }, {
      "name" : "Vancouver Design Wk",
      "screen_name" : "vandesignwk",
      "indices" : [ 50, 62 ],
      "id_str" : "2717780959",
      "id" : 2717780959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/DkZmdRnazO",
      "expanded_url" : "http:\/\/ow.ly\/Bl6sT",
      "display_url" : "ow.ly\/Bl6sT"
    } ]
  },
  "geo" : { },
  "id_str" : "509846704016064513",
  "text" : "RT @openroadies: OpenRoadies are participating in @vandesignwk 's Open Studios Event. Learn more and register here: http:\/\/t.co\/DkZmdRnazO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vancouver Design Wk",
        "screen_name" : "vandesignwk",
        "indices" : [ 33, 45 ],
        "id_str" : "2717780959",
        "id" : 2717780959
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/DkZmdRnazO",
        "expanded_url" : "http:\/\/ow.ly\/Bl6sT",
        "display_url" : "ow.ly\/Bl6sT"
      } ]
    },
    "geo" : { },
    "id_str" : "509744504849838080",
    "text" : "OpenRoadies are participating in @vandesignwk 's Open Studios Event. Learn more and register here: http:\/\/t.co\/DkZmdRnazO",
    "id" : 509744504849838080,
    "created_at" : "2014-09-10 16:45:35 +0000",
    "user" : {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "protected" : false,
      "id_str" : "66913866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554783440747237376\/HA2Svg4h_normal.png",
      "id" : 66913866,
      "verified" : false
    }
  },
  "id" : 509846704016064513,
  "created_at" : "2014-09-10 23:31:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott W. Ambler",
      "screen_name" : "scottwambler",
      "indices" : [ 3, 16 ],
      "id_str" : "61747648",
      "id" : 61747648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509435075448954881",
  "text" : "RT @scottwambler: Change is uncomfortable, but you should always be improving.  Embrace discomfort.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509434966024159232",
    "text" : "Change is uncomfortable, but you should always be improving.  Embrace discomfort.",
    "id" : 509434966024159232,
    "created_at" : "2014-09-09 20:15:35 +0000",
    "user" : {
      "name" : "Scott W. Ambler",
      "screen_name" : "scottwambler",
      "protected" : false,
      "id_str" : "61747648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446067243734933506\/7WBAnFQz_normal.jpeg",
      "id" : 61747648,
      "verified" : false
    }
  },
  "id" : 509435075448954881,
  "created_at" : "2014-09-09 20:16:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/QSrBUWzJ7u",
      "expanded_url" : "http:\/\/Apple.com",
      "display_url" : "Apple.com"
    } ]
  },
  "geo" : { },
  "id_str" : "509430260333424640",
  "text" : "In other ground-breaking news, http:\/\/t.co\/QSrBUWzJ7u is finally mobile friendly. Time check: September 9, 2014.",
  "id" : 509430260333424640,
  "created_at" : "2014-09-09 19:56:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Peters",
      "screen_name" : "bit101",
      "indices" : [ 3, 10 ],
      "id_str" : "756040",
      "id" : 756040
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/bit101\/status\/509391770161913856\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/sPpfFxEfvI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxG5HZSIMAAiSW5.jpg",
      "id_str" : "509391769566720000",
      "id" : 509391769566720000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxG5HZSIMAAiSW5.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1020
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1020
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/sPpfFxEfvI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509395625763282944",
  "text" : "RT @bit101: I think this dude was in the middle of changing his sweater when he got rushed onto stage. http:\/\/t.co\/sPpfFxEfvI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/bit101\/status\/509391770161913856\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/sPpfFxEfvI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxG5HZSIMAAiSW5.jpg",
        "id_str" : "509391769566720000",
        "id" : 509391769566720000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxG5HZSIMAAiSW5.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/sPpfFxEfvI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509391770161913856",
    "text" : "I think this dude was in the middle of changing his sweater when he got rushed onto stage. http:\/\/t.co\/sPpfFxEfvI",
    "id" : 509391770161913856,
    "created_at" : "2014-09-09 17:23:56 +0000",
    "user" : {
      "name" : "Keith Peters",
      "screen_name" : "bit101",
      "protected" : false,
      "id_str" : "756040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000192278171\/74d9d7c06f944d1970497c8e700cb214_normal.png",
      "id" : 756040,
      "verified" : false
    }
  },
  "id" : 509395625763282944,
  "created_at" : "2014-09-09 17:39:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cooper",
      "screen_name" : "cooper",
      "indices" : [ 3, 10 ],
      "id_str" : "17223242",
      "id" : 17223242
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/cooper\/status\/509375977131347968\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ZizuFasmDI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxGqwJQIMAArrQ3.jpg",
      "id_str" : "509375976963584000",
      "id" : 509375976963584000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxGqwJQIMAArrQ3.jpg",
      "sizes" : [ {
        "h" : 126,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 851
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 851
      } ],
      "display_url" : "pic.twitter.com\/ZizuFasmDI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/h8QBNS9gaB",
      "expanded_url" : "http:\/\/buff.ly\/1utcHlB",
      "display_url" : "buff.ly\/1utcHlB"
    } ]
  },
  "geo" : { },
  "id_str" : "509376493319761920",
  "text" : "RT @cooper: The first print copies of ABOUT FACE 4 have landed! Want your own? Order it here: http:\/\/t.co\/h8QBNS9gaB http:\/\/t.co\/ZizuFasmDI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/cooper\/status\/509375977131347968\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/ZizuFasmDI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxGqwJQIMAArrQ3.jpg",
        "id_str" : "509375976963584000",
        "id" : 509375976963584000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxGqwJQIMAArrQ3.jpg",
        "sizes" : [ {
          "h" : 126,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 851
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 222,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 851
        } ],
        "display_url" : "pic.twitter.com\/ZizuFasmDI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/h8QBNS9gaB",
        "expanded_url" : "http:\/\/buff.ly\/1utcHlB",
        "display_url" : "buff.ly\/1utcHlB"
      } ]
    },
    "geo" : { },
    "id_str" : "509375977131347968",
    "text" : "The first print copies of ABOUT FACE 4 have landed! Want your own? Order it here: http:\/\/t.co\/h8QBNS9gaB http:\/\/t.co\/ZizuFasmDI",
    "id" : 509375977131347968,
    "created_at" : "2014-09-09 16:21:11 +0000",
    "user" : {
      "name" : "Cooper",
      "screen_name" : "cooper",
      "protected" : false,
      "id_str" : "17223242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659130203671625728\/qicVhWwi_normal.jpg",
      "id" : 17223242,
      "verified" : false
    }
  },
  "id" : 509376493319761920,
  "created_at" : "2014-09-09 16:23:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SFUFlexibleEducation",
      "screen_name" : "SFUFlexed",
      "indices" : [ 34, 44 ],
      "id_str" : "2565668911",
      "id" : 2565668911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509361296387874816",
  "text" : "Really looking forward to today's @SFUFlexed focus group session! Oh, and that little Apple event scheduled this morning as well...",
  "id" : 509361296387874816,
  "created_at" : "2014-09-09 15:22:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Lombardi",
      "screen_name" : "LombardiMike",
      "indices" : [ 3, 16 ],
      "id_str" : "20495800",
      "id" : 20495800
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BCED",
      "indices" : [ 117, 122 ]
    }, {
      "text" : "bcpoli",
      "indices" : [ 123, 130 ]
    }, {
      "text" : "Vsb39",
      "indices" : [ 131, 137 ]
    }, {
      "text" : "cknw",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "cbcbc",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508384878585716737",
  "text" : "RT @LombardiMike: RT if you support using binding arbitration to re-open  the doors of our schools for our students. #BCED #bcpoli #Vsb39 #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BCED",
        "indices" : [ 99, 104 ]
      }, {
        "text" : "bcpoli",
        "indices" : [ 105, 112 ]
      }, {
        "text" : "Vsb39",
        "indices" : [ 113, 119 ]
      }, {
        "text" : "cknw",
        "indices" : [ 120, 125 ]
      }, {
        "text" : "cbcbc",
        "indices" : [ 127, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "508066367787237376",
    "text" : "RT if you support using binding arbitration to re-open  the doors of our schools for our students. #BCED #bcpoli #Vsb39 #cknw @#cbcbc",
    "id" : 508066367787237376,
    "created_at" : "2014-09-06 01:37:16 +0000",
    "user" : {
      "name" : "Mike Lombardi",
      "screen_name" : "LombardiMike",
      "protected" : false,
      "id_str" : "20495800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533848171118465026\/8GQPg3p0_normal.jpeg",
      "id" : 20495800,
      "verified" : false
    }
  },
  "id" : 508384878585716737,
  "created_at" : "2014-09-06 22:42:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barish Golland",
      "screen_name" : "BarishGolland",
      "indices" : [ 0, 14 ],
      "id_str" : "32352319",
      "id" : 32352319
    }, {
      "name" : "Ana Golland",
      "screen_name" : "AnaGolland",
      "indices" : [ 15, 26 ],
      "id_str" : "586678405",
      "id" : 586678405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508349606392893440",
  "geo" : { },
  "id_str" : "508350210213302272",
  "in_reply_to_user_id" : 32352319,
  "text" : "@BarishGolland @AnaGolland I am sure it will be a great camp then! I'll tell Marika about it and see if it works schedule - wise.",
  "id" : 508350210213302272,
  "in_reply_to_status_id" : 508349606392893440,
  "created_at" : "2014-09-06 20:25:09 +0000",
  "in_reply_to_screen_name" : "BarishGolland",
  "in_reply_to_user_id_str" : "32352319",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barish Golland",
      "screen_name" : "BarishGolland",
      "indices" : [ 0, 14 ],
      "id_str" : "32352319",
      "id" : 32352319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508334370101268480",
  "in_reply_to_user_id" : 32352319,
  "text" : "@BarishGolland Lego camp looks very interesting! Are you personally involved too?",
  "id" : 508334370101268480,
  "created_at" : "2014-09-06 19:22:12 +0000",
  "in_reply_to_screen_name" : "BarishGolland",
  "in_reply_to_user_id_str" : "32352319",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Downes",
      "screen_name" : "Downes",
      "indices" : [ 3, 10 ],
      "id_str" : "7470932",
      "id" : 7470932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/hanAFnaPM2",
      "expanded_url" : "http:\/\/www.downes.ca\/presentation\/346",
      "display_url" : "downes.ca\/presentation\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507971396874416128",
  "text" : "RT @Downes: Audio and slides - The Challenges (and Future) of Networked Learning - now available - http:\/\/t.co\/hanAFnaPM2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/hanAFnaPM2",
        "expanded_url" : "http:\/\/www.downes.ca\/presentation\/346",
        "display_url" : "downes.ca\/presentation\/3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "507971022168264704",
    "text" : "Audio and slides - The Challenges (and Future) of Networked Learning - now available - http:\/\/t.co\/hanAFnaPM2",
    "id" : 507971022168264704,
    "created_at" : "2014-09-05 19:18:24 +0000",
    "user" : {
      "name" : "Downes",
      "screen_name" : "Downes",
      "protected" : false,
      "id_str" : "7470932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000109454958\/ad0542ba988807b629dce6589baf210e_normal.jpeg",
      "id" : 7470932,
      "verified" : false
    }
  },
  "id" : 507971396874416128,
  "created_at" : "2014-09-05 19:19:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treehouse",
      "screen_name" : "treehouse",
      "indices" : [ 3, 13 ],
      "id_str" : "14843763",
      "id" : 14843763
    }, {
      "name" : "Ars Technica",
      "screen_name" : "arstechnica",
      "indices" : [ 91, 103 ],
      "id_str" : "717313",
      "id" : 717313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/rJcJD605lQ",
      "expanded_url" : "http:\/\/trhou.se\/1qgkGC9",
      "display_url" : "trhou.se\/1qgkGC9"
    } ]
  },
  "geo" : { },
  "id_str" : "507651432971923456",
  "text" : "RT @treehouse: How a new HTML element will make the Web faster: http:\/\/t.co\/rJcJD605lQ via @arstechnica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ars Technica",
        "screen_name" : "arstechnica",
        "indices" : [ 76, 88 ],
        "id_str" : "717313",
        "id" : 717313
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/rJcJD605lQ",
        "expanded_url" : "http:\/\/trhou.se\/1qgkGC9",
        "display_url" : "trhou.se\/1qgkGC9"
      } ]
    },
    "geo" : { },
    "id_str" : "507649563562606592",
    "text" : "How a new HTML element will make the Web faster: http:\/\/t.co\/rJcJD605lQ via @arstechnica",
    "id" : 507649563562606592,
    "created_at" : "2014-09-04 22:01:02 +0000",
    "user" : {
      "name" : "Treehouse",
      "screen_name" : "treehouse",
      "protected" : false,
      "id_str" : "14843763",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428279627933417472\/thV1pch1_normal.png",
      "id" : 14843763,
      "verified" : true
    }
  },
  "id" : 507651432971923456,
  "created_at" : "2014-09-04 22:08:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mootnz14",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/S0pLCK5Y2x",
      "expanded_url" : "http:\/\/www.moodlemoot.co.nz\/mod\/wiki\/view.php?id=1826",
      "display_url" : "moodlemoot.co.nz\/mod\/wiki\/view.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507589348637016064",
  "text" : "Excited to be part of the Moodle Mobile Workshop at the New Zealand Moodle Moot (via video conference)! http:\/\/t.co\/S0pLCK5Y2x #mootnz14",
  "id" : 507589348637016064,
  "created_at" : "2014-09-04 18:01:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/BANtIDOph0",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/17482\/pages\/all-course-tools",
      "display_url" : "canvas.sfu.ca\/courses\/17482\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507298208931147776",
  "text" : "CMPT 363 launches tomorrow night with a full class of 80 students + waitlist. Just updated the course tools page at https:\/\/t.co\/BANtIDOph0",
  "id" : 507298208931147776,
  "created_at" : "2014-09-03 22:44:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507201102291292160",
  "text" : "Updating my \"Reasons Why You Might Want To Avoid This Course\" slide for tomorrow - great opportunity to be fully transparent and honest.",
  "id" : 507201102291292160,
  "created_at" : "2014-09-03 16:19:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visual Idiot",
      "screen_name" : "idiot",
      "indices" : [ 3, 9 ],
      "id_str" : "202571491",
      "id" : 202571491
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/idiot\/status\/506796376320380928\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/Leu3GcfD9X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwiAnkyIQAAvNVA.jpg",
      "id_str" : "506796375456366592",
      "id" : 506796375456366592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwiAnkyIQAAvNVA.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Leu3GcfD9X"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506812411668877313",
  "text" : "RT @idiot: http:\/\/t.co\/Leu3GcfD9X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/idiot\/status\/506796376320380928\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/Leu3GcfD9X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwiAnkyIQAAvNVA.jpg",
        "id_str" : "506796375456366592",
        "id" : 506796375456366592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwiAnkyIQAAvNVA.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Leu3GcfD9X"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "506796376320380928",
    "text" : "http:\/\/t.co\/Leu3GcfD9X",
    "id" : 506796376320380928,
    "created_at" : "2014-09-02 13:30:46 +0000",
    "user" : {
      "name" : "Visual Idiot",
      "screen_name" : "idiot",
      "protected" : false,
      "id_str" : "202571491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575994177843904512\/Su6OblHX_normal.jpeg",
      "id" : 202571491,
      "verified" : false
    }
  },
  "id" : 506812411668877313,
  "created_at" : "2014-09-02 14:34:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]