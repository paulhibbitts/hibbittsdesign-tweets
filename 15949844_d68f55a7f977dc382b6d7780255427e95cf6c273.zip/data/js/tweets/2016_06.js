Grailbird.data.tweets_2016_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana Chisnell",
      "screen_name" : "danachis",
      "indices" : [ 3, 12 ],
      "id_str" : "3215861",
      "id" : 3215861
    }, {
      "name" : "Whitney Quesenbery",
      "screen_name" : "whitneyq",
      "indices" : [ 138, 139 ],
      "id_str" : "16949684",
      "id" : 16949684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/nLbeVxv9TU",
      "expanded_url" : "https:\/\/vimeo.com\/172958362",
      "display_url" : "vimeo.com\/172958362"
    } ]
  },
  "geo" : { },
  "id_str" : "748671509418303488",
  "text" : "RT @danachis: Democracy by Design. Documentary about LA creating a new voting system from the ground, up. https:\/\/t.co\/nLbeVxv9TU (10 min)\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Whitney Quesenbery",
        "screen_name" : "whitneyq",
        "indices" : [ 131, 140 ],
        "id_str" : "16949684",
        "id" : 16949684
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/nLbeVxv9TU",
        "expanded_url" : "https:\/\/vimeo.com\/172958362",
        "display_url" : "vimeo.com\/172958362"
      } ]
    },
    "geo" : { },
    "id_str" : "748667434173878272",
    "text" : "Democracy by Design. Documentary about LA creating a new voting system from the ground, up. https:\/\/t.co\/nLbeVxv9TU (10 min) Cameo:@whitneyq",
    "id" : 748667434173878272,
    "created_at" : "2016-07-01 00:00:00 +0000",
    "user" : {
      "name" : "Dana Chisnell",
      "screen_name" : "danachis",
      "protected" : false,
      "id_str" : "3215861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683048450896834560\/M6K-bf8E_normal.jpg",
      "id" : 3215861,
      "verified" : false
    }
  },
  "id" : 748671509418303488,
  "created_at" : "2016-07-01 00:16:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 3, 15 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indieweb",
      "indices" : [ 17, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/r0iTmfSQaF",
      "expanded_url" : "http:\/\/known.networkeffects.ca\/2016\/indieweb-weve-come-to-love-the-convenience-of-the-centralized",
      "display_url" : "known.networkeffects.ca\/2016\/indieweb-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748581488845742080",
  "text" : "RT @grantpotter: #indieweb \"We\u2019ve come to love the convenience of the centralized web, but we\u2019ve failed to recognize how much .. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/known.networkeffects.ca\" rel=\"nofollow\"\u003Eknown-twitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "indieweb",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/r0iTmfSQaF",
        "expanded_url" : "http:\/\/known.networkeffects.ca\/2016\/indieweb-weve-come-to-love-the-convenience-of-the-centralized",
        "display_url" : "known.networkeffects.ca\/2016\/indieweb-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748581146888445952",
    "text" : "#indieweb \"We\u2019ve come to love the convenience of the centralized web, but we\u2019ve failed to recognize how much .. https:\/\/t.co\/r0iTmfSQaF",
    "id" : 748581146888445952,
    "created_at" : "2016-06-30 18:17:08 +0000",
    "user" : {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "protected" : false,
      "id_str" : "6271482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639833921228640256\/S63CDenk_normal.jpg",
      "id" : 6271482,
      "verified" : false
    }
  },
  "id" : 748581488845742080,
  "created_at" : "2016-06-30 18:18:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veronika Druce",
      "screen_name" : "vnktw",
      "indices" : [ 3, 9 ],
      "id_str" : "2815351590",
      "id" : 2815351590
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DESIGNDISRUPTORS",
      "indices" : [ 59, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748347725536604161",
  "text" : "RT @vnktw: Design isn't finished until someone is using it #DESIGNDISRUPTORS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DESIGNDISRUPTORS",
        "indices" : [ 48, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748339185581363200",
    "text" : "Design isn't finished until someone is using it #DESIGNDISRUPTORS",
    "id" : 748339185581363200,
    "created_at" : "2016-06-30 02:15:39 +0000",
    "user" : {
      "name" : "Veronika Druce",
      "screen_name" : "vnktw",
      "protected" : false,
      "id_str" : "2815351590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714672678876160000\/maj_NLn8_normal.jpg",
      "id" : 2815351590,
      "verified" : false
    }
  },
  "id" : 748347725536604161,
  "created_at" : "2016-06-30 02:49:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "indices" : [ 3, 10 ],
      "id_str" : "944913038",
      "id" : 944913038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yvr",
      "indices" : [ 95, 99 ]
    }, {
      "text" : "ux",
      "indices" : [ 100, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748271978910363648",
  "text" : "RT @Van_UE: Sorry everyone! Tonight's VanUE event is cancelled. See you all at the next event! #yvr #ux",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "yvr",
        "indices" : [ 83, 87 ]
      }, {
        "text" : "ux",
        "indices" : [ 88, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748271298443362308",
    "text" : "Sorry everyone! Tonight's VanUE event is cancelled. See you all at the next event! #yvr #ux",
    "id" : 748271298443362308,
    "created_at" : "2016-06-29 21:45:54 +0000",
    "user" : {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "protected" : false,
      "id_str" : "944913038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2842592785\/c138e36411049b83817c208ab9149c60_normal.png",
      "id" : 944913038,
      "verified" : false
    }
  },
  "id" : 748271978910363648,
  "created_at" : "2016-06-29 21:48:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/2NQImwW5lf",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-06-29-eating-my-own-dogfood",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748227598770016258",
  "text" : "Sneak peek at my blog post about eating my own dog food as I prepare for next term's CMPT 363 course: https:\/\/t.co\/2NQImwW5lf #GravEdu",
  "id" : 748227598770016258,
  "created_at" : "2016-06-29 18:52:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 30, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/yJwV2clFWb",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-163\/",
      "display_url" : "paulhibbitts.net\/cmpt-363-163\/"
    } ]
  },
  "geo" : { },
  "id_str" : "748197214770499584",
  "text" : "Working on the Course Hub for #SFU CMPT 363 so that students can better self-assess course fit (reg. starts July 4). https:\/\/t.co\/yJwV2clFWb",
  "id" : 748197214770499584,
  "created_at" : "2016-06-29 16:51:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Madland",
      "screen_name" : "colinmadland",
      "indices" : [ 0, 13 ],
      "id_str" : "81038069",
      "id" : 81038069
    }, {
      "name" : "TRU, Open Learning",
      "screen_name" : "TRUOpenLearning",
      "indices" : [ 14, 30 ],
      "id_str" : "23662900",
      "id" : 23662900
    }, {
      "name" : "Trinity Western",
      "screen_name" : "TrinityWestern",
      "indices" : [ 31, 46 ],
      "id_str" : "20702795",
      "id" : 20702795
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747988535802662913",
  "geo" : { },
  "id_str" : "747989855246835712",
  "in_reply_to_user_id" : 81038069,
  "text" : "@colinmadland @TRUOpenLearning @TrinityWestern It was great to meet you in person at #FoL16, all the best with your new role!",
  "id" : 747989855246835712,
  "in_reply_to_status_id" : 747988535802662913,
  "created_at" : "2016-06-29 03:07:33 +0000",
  "in_reply_to_screen_name" : "colinmadland",
  "in_reply_to_user_id_str" : "81038069",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Fraser Univ.",
      "screen_name" : "SFU",
      "indices" : [ 3, 7 ],
      "id_str" : "8071702",
      "id" : 8071702
    }, {
      "name" : "Louise Holt",
      "screen_name" : "agoldbug",
      "indices" : [ 106, 115 ],
      "id_str" : "742954188",
      "id" : 742954188
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SFU\/status\/747935209681752069\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/SRezNGinJa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmEzG0FXEAAQ7PE.jpg",
      "id_str" : "747935205273571328",
      "id" : 747935205273571328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmEzG0FXEAAQ7PE.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2446,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 1535,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 899,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/SRezNGinJa"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 58, 62 ]
    }, {
      "text" : "Burnaby",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747941585627688960",
  "text" : "RT @SFU: What an unbearably amazing sight to see! Bear at #SFU entrance sign on #Burnaby mountain!\nThanks @agoldbug. https:\/\/t.co\/SRezNGinJa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Louise Holt",
        "screen_name" : "agoldbug",
        "indices" : [ 97, 106 ],
        "id_str" : "742954188",
        "id" : 742954188
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SFU\/status\/747935209681752069\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/SRezNGinJa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmEzG0FXEAAQ7PE.jpg",
        "id_str" : "747935205273571328",
        "id" : 747935205273571328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmEzG0FXEAAQ7PE.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2446,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 1535,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 899,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/SRezNGinJa"
      } ],
      "hashtags" : [ {
        "text" : "SFU",
        "indices" : [ 49, 53 ]
      }, {
        "text" : "Burnaby",
        "indices" : [ 71, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747935209681752069",
    "text" : "What an unbearably amazing sight to see! Bear at #SFU entrance sign on #Burnaby mountain!\nThanks @agoldbug. https:\/\/t.co\/SRezNGinJa",
    "id" : 747935209681752069,
    "created_at" : "2016-06-28 23:30:24 +0000",
    "user" : {
      "name" : "Simon Fraser Univ.",
      "screen_name" : "SFU",
      "protected" : false,
      "id_str" : "8071702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752576681982906370\/KFTfecTT_normal.jpg",
      "id" : 8071702,
      "verified" : false
    }
  },
  "id" : 747941585627688960,
  "created_at" : "2016-06-28 23:55:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jono Penn",
      "screen_name" : "jonopenn",
      "indices" : [ 3, 12 ],
      "id_str" : "1371027559",
      "id" : 1371027559
    }, {
      "name" : "LivingComputers",
      "screen_name" : "LivingComputers",
      "indices" : [ 72, 88 ],
      "id_str" : "488844086",
      "id" : 488844086
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "XeroxAlto",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/fw9UOUYhDx",
      "expanded_url" : "http:\/\/arstechnica.com\/gadgets\/2016\/06\/y-combinators-xerox-alto-restoring-the-legendary-1970s-gui-computer\/",
      "display_url" : "arstechnica.com\/gadgets\/2016\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747930083688493056",
  "text" : "RT @jonopenn: Glad I've gotten to see (&amp; use!) #XeroxAlto by way of @LivingComputers \nhttps:\/\/t.co\/fw9UOUYhDx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LivingComputers",
        "screen_name" : "LivingComputers",
        "indices" : [ 58, 74 ],
        "id_str" : "488844086",
        "id" : 488844086
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "XeroxAlto",
        "indices" : [ 37, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/fw9UOUYhDx",
        "expanded_url" : "http:\/\/arstechnica.com\/gadgets\/2016\/06\/y-combinators-xerox-alto-restoring-the-legendary-1970s-gui-computer\/",
        "display_url" : "arstechnica.com\/gadgets\/2016\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747505378460499968",
    "text" : "Glad I've gotten to see (&amp; use!) #XeroxAlto by way of @LivingComputers \nhttps:\/\/t.co\/fw9UOUYhDx",
    "id" : 747505378460499968,
    "created_at" : "2016-06-27 19:02:24 +0000",
    "user" : {
      "name" : "Jono Penn",
      "screen_name" : "jonopenn",
      "protected" : false,
      "id_str" : "1371027559",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623907575759646720\/J2Dfigvm_normal.jpg",
      "id" : 1371027559,
      "verified" : false
    }
  },
  "id" : 747930083688493056,
  "created_at" : "2016-06-28 23:10:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/747834310560911361\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/bTdykdJHOk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmDQhzzUgAAWDcP.jpg",
      "id_str" : "747826817403224064",
      "id" : 747826817403224064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmDQhzzUgAAWDcP.jpg",
      "sizes" : [ {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/bTdykdJHOk"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/747834310560911361\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/bTdykdJHOk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmDQlEvUsAAeYHq.jpg",
      "id_str" : "747826873489469440",
      "id" : 747826873489469440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmDQlEvUsAAeYHq.jpg",
      "sizes" : [ {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/bTdykdJHOk"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/747834310560911361\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/bTdykdJHOk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmDSs95UkAAvB_b.jpg",
      "id_str" : "747829208114565120",
      "id" : 747829208114565120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmDSs95UkAAvB_b.jpg",
      "sizes" : [ {
        "h" : 461,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/bTdykdJHOk"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/747834310560911361\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/bTdykdJHOk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmDSuRtUkAAbxOM.jpg",
      "id_str" : "747829230612811776",
      "id" : 747829230612811776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmDSuRtUkAAbxOM.jpg",
      "sizes" : [ {
        "h" : 461,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/bTdykdJHOk"
    } ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747834310560911361",
  "text" : "With the Grav Course Hub you can use a URL parameter to embed content only pages into your LMS. #CanvasLMS example: https:\/\/t.co\/bTdykdJHOk",
  "id" : 747834310560911361,
  "created_at" : "2016-06-28 16:49:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Veletsianos",
      "screen_name" : "veletsianos",
      "indices" : [ 3, 15 ],
      "id_str" : "17883918",
      "id" : 17883918
    }, {
      "name" : "Dirk Ifenthaler",
      "screen_name" : "ifenthaler",
      "indices" : [ 86, 97 ],
      "id_str" : "45137054",
      "id" : 45137054
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/veletsianos\/status\/747826893248856065\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/0doBPhS1y6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmDQl1HUsAAKr71.jpg",
      "id_str" : "747826886475034624",
      "id" : 747826886475034624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmDQl1HUsAAKr71.jpg",
      "sizes" : [ {
        "h" : 394,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1186,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 695,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1186,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/0doBPhS1y6"
    } ],
    "hashtags" : [ {
      "text" : "edmedia",
      "indices" : [ 98, 106 ]
    }, {
      "text" : "edmediaconf",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747831659794309120",
  "text" : "RT @veletsianos: What students say they would like from learning analytics systems by @ifenthaler #edmedia #edmediaconf https:\/\/t.co\/0doBPh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dirk Ifenthaler",
        "screen_name" : "ifenthaler",
        "indices" : [ 69, 80 ],
        "id_str" : "45137054",
        "id" : 45137054
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/veletsianos\/status\/747826893248856065\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/0doBPhS1y6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmDQl1HUsAAKr71.jpg",
        "id_str" : "747826886475034624",
        "id" : 747826886475034624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmDQl1HUsAAKr71.jpg",
        "sizes" : [ {
          "h" : 394,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1186,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 695,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1186,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/0doBPhS1y6"
      } ],
      "hashtags" : [ {
        "text" : "edmedia",
        "indices" : [ 81, 89 ]
      }, {
        "text" : "edmediaconf",
        "indices" : [ 90, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747826893248856065",
    "text" : "What students say they would like from learning analytics systems by @ifenthaler #edmedia #edmediaconf https:\/\/t.co\/0doBPhS1y6",
    "id" : 747826893248856065,
    "created_at" : "2016-06-28 16:19:59 +0000",
    "user" : {
      "name" : "George Veletsianos",
      "screen_name" : "veletsianos",
      "protected" : false,
      "id_str" : "17883918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2252880258\/veletsianos_george_bio_photo_normal.jpg",
      "id" : 17883918,
      "verified" : false
    }
  },
  "id" : 747831659794309120,
  "created_at" : "2016-06-28 16:38:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Source Way",
      "screen_name" : "opensourceway",
      "indices" : [ 3, 17 ],
      "id_str" : "80589255",
      "id" : 80589255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/jaTrF8GMgY",
      "expanded_url" : "http:\/\/red.ht\/1WddzuT",
      "display_url" : "red.ht\/1WddzuT"
    } ]
  },
  "geo" : { },
  "id_str" : "747646918541578240",
  "text" : "RT @opensourceway: 19 years later, The Cathedral and the Bazaar still moves us https:\/\/t.co\/jaTrF8GMgY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/jaTrF8GMgY",
        "expanded_url" : "http:\/\/red.ht\/1WddzuT",
        "display_url" : "red.ht\/1WddzuT"
      } ]
    },
    "geo" : { },
    "id_str" : "747633371803582464",
    "text" : "19 years later, The Cathedral and the Bazaar still moves us https:\/\/t.co\/jaTrF8GMgY",
    "id" : 747633371803582464,
    "created_at" : "2016-06-28 03:31:00 +0000",
    "user" : {
      "name" : "Open Source Way",
      "screen_name" : "opensourceway",
      "protected" : false,
      "id_str" : "80589255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469124275572453376\/8fd3035c_normal.png",
      "id" : 80589255,
      "verified" : false
    }
  },
  "id" : 747646918541578240,
  "created_at" : "2016-06-28 04:24:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747584934403989504",
  "text" : "SILO BUSTER: Break out of your LMS w. Grav Course Hub and store your site where people can help each other. https:\/\/t.co\/VgQsw7bHP4 #GravEdu",
  "id" : 747584934403989504,
  "created_at" : "2016-06-28 00:18:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Thurrott",
      "screen_name" : "thurrott",
      "indices" : [ 3, 12 ],
      "id_str" : "14964767",
      "id" : 14964767
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/thurrott\/status\/747534594073829378\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Uciim3OKdV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl_Gv_oWgAMDl-Q.jpg",
      "id_str" : "747534591003623427",
      "id" : 747534591003623427,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl_Gv_oWgAMDl-Q.jpg",
      "sizes" : [ {
        "h" : 1102,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 1102,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1102,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/Uciim3OKdV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747536579204259840",
  "text" : "RT @thurrott: A fire destroyed the first NexDock shipments, the company told customers today. https:\/\/t.co\/Uciim3OKdV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/thurrott\/status\/747534594073829378\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/Uciim3OKdV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl_Gv_oWgAMDl-Q.jpg",
        "id_str" : "747534591003623427",
        "id" : 747534591003623427,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl_Gv_oWgAMDl-Q.jpg",
        "sizes" : [ {
          "h" : 1102,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 1102,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1102,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/Uciim3OKdV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747534594073829378",
    "text" : "A fire destroyed the first NexDock shipments, the company told customers today. https:\/\/t.co\/Uciim3OKdV",
    "id" : 747534594073829378,
    "created_at" : "2016-06-27 20:58:30 +0000",
    "user" : {
      "name" : "Paul Thurrott",
      "screen_name" : "thurrott",
      "protected" : false,
      "id_str" : "14964767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718435052779151360\/s1niU-q7_normal.jpg",
      "id" : 14964767,
      "verified" : false
    }
  },
  "id" : 747536579204259840,
  "created_at" : "2016-06-27 21:06:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Office Sway",
      "screen_name" : "sway",
      "indices" : [ 0, 5 ],
      "id_str" : "129937699",
      "id" : 129937699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/abG6zmYU9l",
      "expanded_url" : "http:\/\/slides.com",
      "display_url" : "slides.com"
    } ]
  },
  "in_reply_to_status_id_str" : "747527809174757377",
  "geo" : { },
  "id_str" : "747529284609183745",
  "in_reply_to_user_id" : 129937699,
  "text" : "@sway I use embedded decks for my university UX course. I first chose https:\/\/t.co\/abG6zmYU9l over Sway, and am now moving over to swipe.to.",
  "id" : 747529284609183745,
  "in_reply_to_status_id" : 747527809174757377,
  "created_at" : "2016-06-27 20:37:24 +0000",
  "in_reply_to_screen_name" : "sway",
  "in_reply_to_user_id_str" : "129937699",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747525299265376256",
  "text" : "SILO BUSTER: Break out of your LMS and enable students to actively collaborate with the Grav Course Hub. https:\/\/t.co\/VgQsw7bHP4 #GravEdu",
  "id" : 747525299265376256,
  "created_at" : "2016-06-27 20:21:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Office Sway",
      "screen_name" : "sway",
      "indices" : [ 0, 5 ],
      "id_str" : "129937699",
      "id" : 129937699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747520879484145664",
  "geo" : { },
  "id_str" : "747522784545234944",
  "in_reply_to_user_id" : 129937699,
  "text" : "@sway Appreciate you reaching out\uD83D\uDE42 The general workflow of Sway was not a good fit for me, and as well I prefer multi-device Web app.",
  "id" : 747522784545234944,
  "in_reply_to_status_id" : 747520879484145664,
  "created_at" : "2016-06-27 20:11:34 +0000",
  "in_reply_to_screen_name" : "sway",
  "in_reply_to_user_id_str" : "129937699",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/747519591459348480\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/U8SWiPF8EE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl-4cP0UkAA7L8C.jpg",
      "id_str" : "747518858588622848",
      "id" : 747518858588622848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl-4cP0UkAA7L8C.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 679
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/U8SWiPF8EE"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 86, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/S03QOw3vR6",
      "expanded_url" : "https:\/\/www.swipe.to\/5279w#page=lgcD2nn7d",
      "display_url" : "swipe.to\/5279w#page=lgc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747519591459348480",
  "text" : "Mapping techniques to the design process\/toolkit diagram for my UX course CMPT 363 at #SFU: https:\/\/t.co\/S03QOw3vR6 https:\/\/t.co\/U8SWiPF8EE",
  "id" : 747519591459348480,
  "created_at" : "2016-06-27 19:58:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747498779482284033",
  "text" : "SILO BUSTER: Break out of your LMS and enable open access to cross-platform content w. the Grav Course Hub. https:\/\/t.co\/VgQsw7bHP4 #GravEdu",
  "id" : 747498779482284033,
  "created_at" : "2016-06-27 18:36:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft Design",
      "screen_name" : "MicrosoftDesign",
      "indices" : [ 3, 19 ],
      "id_str" : "209202416",
      "id" : 209202416
    }, {
      "name" : "Bill Buxton",
      "screen_name" : "wasbuxton",
      "indices" : [ 70, 80 ],
      "id_str" : "57046779",
      "id" : 57046779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/raEySTvofj",
      "expanded_url" : "http:\/\/bit.ly\/28TmZXn",
      "display_url" : "bit.ly\/28TmZXn"
    } ]
  },
  "geo" : { },
  "id_str" : "747496876144877568",
  "text" : "RT @MicrosoftDesign: True discovery is to see through different eyes: @wasbuxton explores Microsoft's journey toward design that matters. h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.crowdbooster.com\" rel=\"nofollow\"\u003ECrowdbooster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Buxton",
        "screen_name" : "wasbuxton",
        "indices" : [ 49, 59 ],
        "id_str" : "57046779",
        "id" : 57046779
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/raEySTvofj",
        "expanded_url" : "http:\/\/bit.ly\/28TmZXn",
        "display_url" : "bit.ly\/28TmZXn"
      } ]
    },
    "geo" : { },
    "id_str" : "747484890195726336",
    "text" : "True discovery is to see through different eyes: @wasbuxton explores Microsoft's journey toward design that matters. https:\/\/t.co\/raEySTvofj",
    "id" : 747484890195726336,
    "created_at" : "2016-06-27 17:41:00 +0000",
    "user" : {
      "name" : "Microsoft Design",
      "screen_name" : "MicrosoftDesign",
      "protected" : false,
      "id_str" : "209202416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641678298137915392\/pkgzJDbc_normal.jpg",
      "id" : 209202416,
      "verified" : true
    }
  },
  "id" : 747496876144877568,
  "created_at" : "2016-06-27 18:28:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747483878303006721",
  "text" : "SILO BUSTER: Break out of your LMS and share materials between related courses with the Grav Course Hub. https:\/\/t.co\/VgQsw7bHP4 #GravEdu",
  "id" : 747483878303006721,
  "created_at" : "2016-06-27 17:36:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Gibbs",
      "screen_name" : "OnlineCrsLady",
      "indices" : [ 3, 17 ],
      "id_str" : "7044082",
      "id" : 7044082
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 20, 27 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 28, 43 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/OnlineCrsLady\/status\/747227667225780224\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/UeKBJ8KY9c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl6vj3fWEAATItl.jpg",
      "id_str" : "747227618915782656",
      "id" : 747227618915782656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl6vj3fWEAATItl.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 850
      } ],
      "display_url" : "pic.twitter.com\/UeKBJ8KY9c"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747239221488812032",
  "text" : "RT @OnlineCrsLady: .@btopro @hibbittsdesign ha ha, learners of the world unite; you have nothing to lose but your LMSes! :-) https:\/\/t.co\/U\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bryan Ollendyke",
        "screen_name" : "btopro",
        "indices" : [ 1, 8 ],
        "id_str" : "16847370",
        "id" : 16847370
      }, {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 9, 24 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/OnlineCrsLady\/status\/747227667225780224\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/UeKBJ8KY9c",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl6vj3fWEAATItl.jpg",
        "id_str" : "747227618915782656",
        "id" : 747227618915782656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl6vj3fWEAATItl.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 850
        } ],
        "display_url" : "pic.twitter.com\/UeKBJ8KY9c"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "747225924534472704",
    "geo" : { },
    "id_str" : "747227667225780224",
    "in_reply_to_user_id" : 16847370,
    "text" : ".@btopro @hibbittsdesign ha ha, learners of the world unite; you have nothing to lose but your LMSes! :-) https:\/\/t.co\/UeKBJ8KY9c",
    "id" : 747227667225780224,
    "in_reply_to_status_id" : 747225924534472704,
    "created_at" : "2016-06-27 00:38:53 +0000",
    "in_reply_to_screen_name" : "btopro",
    "in_reply_to_user_id_str" : "16847370",
    "user" : {
      "name" : "Laura Gibbs",
      "screen_name" : "OnlineCrsLady",
      "protected" : false,
      "id_str" : "7044082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2190857671\/photo_normal.jpg",
      "id" : 7044082,
      "verified" : false
    }
  },
  "id" : 747239221488812032,
  "created_at" : "2016-06-27 01:24:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747204059195572225",
  "text" : "RT @btopro: send them back to the dungeon only when necessary.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "714823129739173889",
    "text" : "send them back to the dungeon only when necessary.",
    "id" : 714823129739173889,
    "created_at" : "2016-03-29 14:34:49 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 747204059195572225,
  "created_at" : "2016-06-26 23:05:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 8, 23 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747202579864641538",
  "geo" : { },
  "id_str" : "747203317126729729",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @hibbittsdesign it is great advice though, isn't it \u263A",
  "id" : 747203317126729729,
  "in_reply_to_status_id" : 747202579864641538,
  "created_at" : "2016-06-26 23:02:07 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Ual9JAgUpB",
      "expanded_url" : "https:\/\/twitter.com\/actualham\/status\/747195806558601216",
      "display_url" : "twitter.com\/actualham\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747199606518251522",
  "text" : "The limitations of Canvas in this post are exactly the reasons I 'flipped' my LMS (Canvas). https:\/\/t.co\/VgQsw7bHP4 https:\/\/t.co\/Ual9JAgUpB",
  "id" : 747199606518251522,
  "created_at" : "2016-06-26 22:47:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Justin Tarte",
      "screen_name" : "justintarte",
      "indices" : [ 3, 15 ],
      "id_str" : "169083205",
      "id" : 169083205
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISTE2016",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747098643748917249",
  "text" : "RT @justintarte: Technology can no longer be viewed as a learning enhancer; it must be viewed as a foundational piece of living in the 21st\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ISTE2016",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747087912211079168",
    "text" : "Technology can no longer be viewed as a learning enhancer; it must be viewed as a foundational piece of living in the 21st century #ISTE2016",
    "id" : 747087912211079168,
    "created_at" : "2016-06-26 15:23:33 +0000",
    "user" : {
      "name" : "Dr. Justin Tarte",
      "screen_name" : "justintarte",
      "protected" : false,
      "id_str" : "169083205",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740319780394041345\/_57aXH6q_normal.jpg",
      "id" : 169083205,
      "verified" : false
    }
  },
  "id" : 747098643748917249,
  "created_at" : "2016-06-26 16:06:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InVision",
      "screen_name" : "InVisionApp",
      "indices" : [ 3, 15 ],
      "id_str" : "256093789",
      "id" : 256093789
    }, {
      "name" : "For Creative Girls",
      "screen_name" : "forcreativegirl",
      "indices" : [ 111, 127 ],
      "id_str" : "748264146324553733",
      "id" : 748264146324553733
    }, {
      "name" : "Jennifer Aldrich",
      "screen_name" : "jma245",
      "indices" : [ 128, 135 ],
      "id_str" : "32696488",
      "id" : 32696488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/K04LcfDDtv",
      "expanded_url" : "http:\/\/forcreativegirls.com\/category\/women-in-ux-design-jennifer-aldrich-of-invision-app\/",
      "display_url" : "forcreativegirls.com\/category\/women\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746498528160014336",
  "text" : "RT @InVisionApp: Women in UX Design: An interview with Jennifer Aldrich of InVision https:\/\/t.co\/K04LcfDDtv by @ForCreativeGirl @jma245",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "For Creative Girls",
        "screen_name" : "forcreativegirl",
        "indices" : [ 94, 110 ],
        "id_str" : "748264146324553733",
        "id" : 748264146324553733
      }, {
        "name" : "Jennifer Aldrich",
        "screen_name" : "jma245",
        "indices" : [ 111, 118 ],
        "id_str" : "32696488",
        "id" : 32696488
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/K04LcfDDtv",
        "expanded_url" : "http:\/\/forcreativegirls.com\/category\/women-in-ux-design-jennifer-aldrich-of-invision-app\/",
        "display_url" : "forcreativegirls.com\/category\/women\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745687277565730818",
    "text" : "Women in UX Design: An interview with Jennifer Aldrich of InVision https:\/\/t.co\/K04LcfDDtv by @ForCreativeGirl @jma245",
    "id" : 745687277565730818,
    "created_at" : "2016-06-22 18:37:55 +0000",
    "user" : {
      "name" : "InVision",
      "screen_name" : "InVisionApp",
      "protected" : false,
      "id_str" : "256093789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593893225045200896\/r9uL4jWU_normal.png",
      "id" : 256093789,
      "verified" : false
    }
  },
  "id" : 746498528160014336,
  "created_at" : "2016-06-25 00:21:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 97, 105 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/yJwV2clFWb",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-163\/",
      "display_url" : "paulhibbitts.net\/cmpt-363-163\/"
    } ]
  },
  "geo" : { },
  "id_str" : "746462377298657280",
  "text" : "What took me a few months (part-time) to build\/design last year only took me about a day with my @getgrav Course Hub https:\/\/t.co\/yJwV2clFWb",
  "id" : 746462377298657280,
  "created_at" : "2016-06-24 21:57:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "June M. Breivik",
      "screen_name" : "junebre",
      "indices" : [ 3, 11 ],
      "id_str" : "14290896",
      "id" : 14290896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/NiLCaLUYQV",
      "expanded_url" : "https:\/\/www.tes.com\/us\/news\/breaking-views\/teachers-must-embrace-new-technology-or-risk-becoming-obsolete",
      "display_url" : "tes.com\/us\/news\/breaki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746460543360241664",
  "text" : "RT @junebre: 'Teachers must embrace new technology or risk becoming obsolete' https:\/\/t.co\/NiLCaLUYQV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/NiLCaLUYQV",
        "expanded_url" : "https:\/\/www.tes.com\/us\/news\/breaking-views\/teachers-must-embrace-new-technology-or-risk-becoming-obsolete",
        "display_url" : "tes.com\/us\/news\/breaki\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "746230060219150336",
    "text" : "'Teachers must embrace new technology or risk becoming obsolete' https:\/\/t.co\/NiLCaLUYQV",
    "id" : 746230060219150336,
    "created_at" : "2016-06-24 06:34:45 +0000",
    "user" : {
      "name" : "June M. Breivik",
      "screen_name" : "junebre",
      "protected" : false,
      "id_str" : "14290896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699931014445998080\/y_fQ1ZWY_normal.jpg",
      "id" : 14290896,
      "verified" : false
    }
  },
  "id" : 746460543360241664,
  "created_at" : "2016-06-24 21:50:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746454803312574465",
  "text" : "Honestly, what I had hoped that Microsoft's Sway could have been swipe.to is: Markdown-based, fast, multi-device friendly and flexible.",
  "id" : 746454803312574465,
  "created_at" : "2016-06-24 21:27:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746433063668723712",
  "geo" : { },
  "id_str" : "746434682183507970",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Congratulations Christina, that's wonderful news!",
  "id" : 746434682183507970,
  "in_reply_to_status_id" : 746433063668723712,
  "created_at" : "2016-06-24 20:07:50 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 3, 12 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Arfon Smith",
      "screen_name" : "arfon",
      "indices" : [ 62, 68 ],
      "id_str" : "617243",
      "id" : 617243
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 70, 77 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/abbycabs\/status\/746065737362472960\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/9CP200zoRD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClqOaGTUsAAabia.jpg",
      "id_str" : "746065267302641664",
      "id" : 746065267302641664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClqOaGTUsAAabia.jpg",
      "sizes" : [ {
        "h" : 482,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 850,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1490,
        "resize" : "fit",
        "w" : 2104
      }, {
        "h" : 1450,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/9CP200zoRD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/lrteZxigym",
      "expanded_url" : "https:\/\/github.com\/blog\/2195-the-shape-of-open-source",
      "display_url" : "github.com\/blog\/2195-the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746144931165548544",
  "text" : "RT @abbycabs: \"Clearly, open source is more than just code\" - @arfon, @github https:\/\/t.co\/lrteZxigym https:\/\/t.co\/9CP200zoRD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arfon Smith",
        "screen_name" : "arfon",
        "indices" : [ 48, 54 ],
        "id_str" : "617243",
        "id" : 617243
      }, {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 56, 63 ],
        "id_str" : "13334762",
        "id" : 13334762
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/abbycabs\/status\/746065737362472960\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/9CP200zoRD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClqOaGTUsAAabia.jpg",
        "id_str" : "746065267302641664",
        "id" : 746065267302641664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClqOaGTUsAAabia.jpg",
        "sizes" : [ {
          "h" : 482,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 850,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1490,
          "resize" : "fit",
          "w" : 2104
        }, {
          "h" : 1450,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/9CP200zoRD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/lrteZxigym",
        "expanded_url" : "https:\/\/github.com\/blog\/2195-the-shape-of-open-source",
        "display_url" : "github.com\/blog\/2195-the-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "746065737362472960",
    "text" : "\"Clearly, open source is more than just code\" - @arfon, @github https:\/\/t.co\/lrteZxigym https:\/\/t.co\/9CP200zoRD",
    "id" : 746065737362472960,
    "created_at" : "2016-06-23 19:41:47 +0000",
    "user" : {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "protected" : false,
      "id_str" : "395367768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549828293654876160\/tHuO1vnZ_normal.jpeg",
      "id" : 395367768,
      "verified" : false
    }
  },
  "id" : 746144931165548544,
  "created_at" : "2016-06-24 00:56:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/S6dfARq05Z",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-163\/ux-techniques-guide",
      "display_url" : "paulhibbitts.net\/cmpt-363-163\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746049902988386305",
  "text" : "Example of a performance support tool for intro UX design course, with menu link to collaboratively edit via GitLab:\nhttps:\/\/t.co\/S6dfARq05Z",
  "id" : 746049902988386305,
  "created_at" : "2016-06-23 18:38:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/kXuwF1V5B7",
      "expanded_url" : "https:\/\/twitter.com\/EdwardTufte\/status\/745754660405972992",
      "display_url" : "twitter.com\/EdwardTufte\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746028984937259008",
  "text" : "Sharing this article with my fellow educators again... cross-platform content (eg Markdown) is more pliable content. https:\/\/t.co\/kXuwF1V5B7",
  "id" : 746028984937259008,
  "created_at" : "2016-06-23 17:15:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/kXuwF1V5B7",
      "expanded_url" : "https:\/\/twitter.com\/EdwardTufte\/status\/745754660405972992",
      "display_url" : "twitter.com\/EdwardTufte\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745775927104143360",
  "text" : "This aligns with my current experiences that Markdown is the (current) best option for cross-platform content reuse. https:\/\/t.co\/kXuwF1V5B7",
  "id" : 745775927104143360,
  "created_at" : "2016-06-23 00:30:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Whitaker",
      "screen_name" : "ThatSteveGuy",
      "indices" : [ 3, 16 ],
      "id_str" : "14351562",
      "id" : 14351562
    }, {
      "name" : "Jennifer Pahlka",
      "screen_name" : "pahlkadot",
      "indices" : [ 92, 102 ],
      "id_str" : "74543",
      "id" : 74543
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ThatSteveGuy\/status\/745660759359787008\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/bAHE1oGSlN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClkegadWgAEqZK1.jpg",
      "id_str" : "745660755513606145",
      "id" : 745660755513606145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClkegadWgAEqZK1.jpg",
      "sizes" : [ {
        "h" : 565,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/bAHE1oGSlN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/7y16snlWis",
      "expanded_url" : "https:\/\/medium.com\/code-for-america\/the-cio-problem-part-2-innovation-af24ebc038e5#---111-263.zext42gkv",
      "display_url" : "medium.com\/code-for-ameri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745763896527454208",
  "text" : "RT @ThatSteveGuy: Great quote: \u201CThat\u2019s not innovation. That\u2019s just how tech works today.\u201D\u200A\u2014\u200A@pahlkadot https:\/\/t.co\/7y16snlWis https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/medium.com\" rel=\"nofollow\"\u003EMedium\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jennifer Pahlka",
        "screen_name" : "pahlkadot",
        "indices" : [ 74, 84 ],
        "id_str" : "74543",
        "id" : 74543
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ThatSteveGuy\/status\/745660759359787008\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/bAHE1oGSlN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClkegadWgAEqZK1.jpg",
        "id_str" : "745660755513606145",
        "id" : 745660755513606145,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClkegadWgAEqZK1.jpg",
        "sizes" : [ {
          "h" : 565,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 565,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 565,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/bAHE1oGSlN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/7y16snlWis",
        "expanded_url" : "https:\/\/medium.com\/code-for-america\/the-cio-problem-part-2-innovation-af24ebc038e5#---111-263.zext42gkv",
        "display_url" : "medium.com\/code-for-ameri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745660759359787008",
    "text" : "Great quote: \u201CThat\u2019s not innovation. That\u2019s just how tech works today.\u201D\u200A\u2014\u200A@pahlkadot https:\/\/t.co\/7y16snlWis https:\/\/t.co\/bAHE1oGSlN",
    "id" : 745660759359787008,
    "created_at" : "2016-06-22 16:52:33 +0000",
    "user" : {
      "name" : "Steven Whitaker",
      "screen_name" : "ThatSteveGuy",
      "protected" : false,
      "id_str" : "14351562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672111531551678464\/S9JVB3T9_normal.png",
      "id" : 14351562,
      "verified" : false
    }
  },
  "id" : 745763896527454208,
  "created_at" : "2016-06-22 23:42:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 3, 15 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "careers",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "yvr",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "tech",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/rUVe3vulR5",
      "expanded_url" : "http:\/\/ow.ly\/3P5t301swFG",
      "display_url" : "ow.ly\/3P5t301swFG"
    } ]
  },
  "geo" : { },
  "id_str" : "745761085014237184",
  "text" : "RT @openroadies: We're looking for an Art Director to join our awesome team! Check out the posting and apply now: https:\/\/t.co\/rUVe3vulR5 #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "careers",
        "indices" : [ 121, 129 ]
      }, {
        "text" : "yvr",
        "indices" : [ 130, 134 ]
      }, {
        "text" : "tech",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/rUVe3vulR5",
        "expanded_url" : "http:\/\/ow.ly\/3P5t301swFG",
        "display_url" : "ow.ly\/3P5t301swFG"
      } ]
    },
    "geo" : { },
    "id_str" : "745760966483283973",
    "text" : "We're looking for an Art Director to join our awesome team! Check out the posting and apply now: https:\/\/t.co\/rUVe3vulR5 #careers #yvr #tech",
    "id" : 745760966483283973,
    "created_at" : "2016-06-22 23:30:44 +0000",
    "user" : {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "protected" : false,
      "id_str" : "66913866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554783440747237376\/HA2Svg4h_normal.png",
      "id" : 66913866,
      "verified" : false
    }
  },
  "id" : 745761085014237184,
  "created_at" : "2016-06-22 23:31:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 14, 22 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "GitLab",
      "screen_name" : "gitlab",
      "indices" : [ 36, 43 ],
      "id_str" : "390167291",
      "id" : 390167291
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/745761009600606208\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/gdJlCL7iYE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cll5meEUkAEleLf.jpg",
      "id_str" : "745760915119706113",
      "id" : 745760915119706113,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cll5meEUkAEleLf.jpg",
      "sizes" : [ {
        "h" : 461,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/gdJlCL7iYE"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 47, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745761009600606208",
  "text" : "Combining the @getgrav Course Hub + @gitlab at #SFU my CMPT 363 students can now publicly propose syllabus changes.\uD83D\uDE4C https:\/\/t.co\/gdJlCL7iYE",
  "id" : 745761009600606208,
  "created_at" : "2016-06-22 23:30:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gravstrap",
      "screen_name" : "gravstrap",
      "indices" : [ 3, 13 ],
      "id_str" : "701343168558669824",
      "id" : 701343168558669824
    }, {
      "name" : "Gravstrap",
      "screen_name" : "gravstrap",
      "indices" : [ 15, 25 ],
      "id_str" : "701343168558669824",
      "id" : 701343168558669824
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 56, 64 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/iegLsdi5XS",
      "expanded_url" : "https:\/\/github.com\/giansi\/gravstrap\/releases\/tag\/v1.1.1",
      "display_url" : "github.com\/giansi\/gravstr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745479593704841216",
  "text" : "RT @gravstrap: @gravstrap 1.1 is out and now works with @getgrav 1.1 RC. https:\/\/t.co\/iegLsdi5XS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gravstrap",
        "screen_name" : "gravstrap",
        "indices" : [ 0, 10 ],
        "id_str" : "701343168558669824",
        "id" : 701343168558669824
      }, {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 41, 49 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/iegLsdi5XS",
        "expanded_url" : "https:\/\/github.com\/giansi\/gravstrap\/releases\/tag\/v1.1.1",
        "display_url" : "github.com\/giansi\/gravstr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745116741588508673",
    "in_reply_to_user_id" : 701343168558669824,
    "text" : "@gravstrap 1.1 is out and now works with @getgrav 1.1 RC. https:\/\/t.co\/iegLsdi5XS",
    "id" : 745116741588508673,
    "created_at" : "2016-06-21 04:50:49 +0000",
    "in_reply_to_screen_name" : "gravstrap",
    "in_reply_to_user_id_str" : "701343168558669824",
    "user" : {
      "name" : "Gravstrap",
      "screen_name" : "gravstrap",
      "protected" : false,
      "id_str" : "701343168558669824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704008901663047681\/wXrpVz9s_normal.jpg",
      "id" : 701343168558669824,
      "verified" : false
    }
  },
  "id" : 745479593704841216,
  "created_at" : "2016-06-22 04:52:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 6, 10 ]
    }, {
      "text" : "OpenEd",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/yJwV2clFWb",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-163\/",
      "display_url" : "paulhibbitts.net\/cmpt-363-163\/"
    }, {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/3xLCjEz8y3",
      "expanded_url" : "https:\/\/csil-git1.cs.surrey.sfu.ca\/paulh\/cmpt-363-163\/tree\/master\/pages",
      "display_url" : "csil-git1.cs.surrey.sfu.ca\/paulh\/cmpt-363\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745391889596112898",
  "text" : "Draft #SFU CMPT 363 course schedule and syllabus are now available at https:\/\/t.co\/yJwV2clFWb (via GitLab https:\/\/t.co\/3xLCjEz8y3). #OpenEd",
  "id" : 745391889596112898,
  "created_at" : "2016-06-21 23:04:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitLab",
      "screen_name" : "gitlab",
      "indices" : [ 101, 108 ],
      "id_str" : "390167291",
      "id" : 390167291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745366879795970049",
  "text" : "Not only now do I have the means for students to contribute their own learning environment via SFU's @gitlab, but I can track all changes \uD83D\uDC4D",
  "id" : 745366879795970049,
  "created_at" : "2016-06-21 21:24:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 45, 60 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/yJwV2clFWb",
      "expanded_url" : "http:\/\/paulhibbitts.net\/cmpt-363-163\/",
      "display_url" : "paulhibbitts.net\/cmpt-363-163\/"
    } ]
  },
  "geo" : { },
  "id_str" : "745363085263704064",
  "text" : "Setup done! CMPT 363 hosted with the awesome @ReclaimHosting folks while all student identifiable info FIPPA safe\uD83D\uDE4C  https:\/\/t.co\/yJwV2clFWb",
  "id" : 745363085263704064,
  "created_at" : "2016-06-21 21:09:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitLab",
      "screen_name" : "gitlab",
      "indices" : [ 107, 114 ],
      "id_str" : "390167291",
      "id" : 390167291
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 119, 127 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745359134162202624",
  "text" : "Almost giddy as I set up my FIPPA-blessed open and collaborative workflow for CMPT 363 with the SFU hosted @gitlab and @getgrav Course Hub.",
  "id" : 745359134162202624,
  "created_at" : "2016-06-21 20:54:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 0, 14 ],
      "id_str" : "41268670",
      "id" : 41268670
    }, {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 15, 24 ],
      "id_str" : "890887814",
      "id" : 890887814
    }, {
      "name" : "Slides",
      "screen_name" : "slides",
      "indices" : [ 93, 100 ],
      "id_str" : "813740730",
      "id" : 813740730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745344277723611138",
  "geo" : { },
  "id_str" : "745345728508104704",
  "in_reply_to_user_id" : 41268670,
  "text" : "@_mike_collins @swipe_to OH! I did not know you could do that \uD83D\uDE42  You might want to check out @slides for a really nice UI, but no Markdown.",
  "id" : 745345728508104704,
  "in_reply_to_status_id" : 745344277723611138,
  "created_at" : "2016-06-21 20:00:44 +0000",
  "in_reply_to_screen_name" : "_mike_collins",
  "in_reply_to_user_id_str" : "41268670",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 0, 14 ],
      "id_str" : "41268670",
      "id" : 41268670
    }, {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 15, 24 ],
      "id_str" : "890887814",
      "id" : 890887814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745343250806996993",
  "geo" : { },
  "id_str" : "745343822880636928",
  "in_reply_to_user_id" : 41268670,
  "text" : "@_mike_collins @swipe_to Less visual control however at this time, so there are tradeoffs. For me, the upside is much greater than downside.",
  "id" : 745343822880636928,
  "in_reply_to_status_id" : 745343250806996993,
  "created_at" : "2016-06-21 19:53:09 +0000",
  "in_reply_to_screen_name" : "_mike_collins",
  "in_reply_to_user_id_str" : "41268670",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 0, 14 ],
      "id_str" : "41268670",
      "id" : 41268670
    }, {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 15, 24 ],
      "id_str" : "890887814",
      "id" : 890887814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/abG6zmYU9l",
      "expanded_url" : "http:\/\/slides.com",
      "display_url" : "slides.com"
    } ]
  },
  "in_reply_to_status_id_str" : "745343250806996993",
  "geo" : { },
  "id_str" : "745343664533049344",
  "in_reply_to_user_id" : 41268670,
  "text" : "@_mike_collins @swipe_to So I've used https:\/\/t.co\/abG6zmYU9l for years (revealjs) but the move to Markdown (esp. with Grav) is huge for me\uD83D\uDC4D",
  "id" : 745343664533049344,
  "in_reply_to_status_id" : 745343250806996993,
  "created_at" : "2016-06-21 19:52:32 +0000",
  "in_reply_to_screen_name" : "_mike_collins",
  "in_reply_to_user_id_str" : "41268670",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745343001463918593",
  "text" : "This is the 3rd year I am developing my CMPT 363 course in the open, and plans include a GitHub repo for course hub &amp; slides (via Markdown).",
  "id" : 745343001463918593,
  "created_at" : "2016-06-21 19:49:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 0, 14 ],
      "id_str" : "41268670",
      "id" : 41268670
    }, {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 15, 24 ],
      "id_str" : "890887814",
      "id" : 890887814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745332261185261569",
  "geo" : { },
  "id_str" : "745341269853908992",
  "in_reply_to_user_id" : 41268670,
  "text" : "@_mike_collins @swipe_to BTW, I've been experimenting a bit and you can include links to images stored on GitHub within swipe.io too \uD83D\uDE42",
  "id" : 745341269853908992,
  "in_reply_to_status_id" : 745332261185261569,
  "created_at" : "2016-06-21 19:43:01 +0000",
  "in_reply_to_screen_name" : "_mike_collins",
  "in_reply_to_user_id_str" : "41268670",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 0, 14 ],
      "id_str" : "41268670",
      "id" : 41268670
    }, {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 15, 24 ],
      "id_str" : "890887814",
      "id" : 890887814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/N1ByiZ96gr",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-05-26-creating-slides-in-markdown",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "745332261185261569",
  "geo" : { },
  "id_str" : "745335169666646017",
  "in_reply_to_user_id" : 41268670,
  "text" : "@_mike_collins @swipe_to You bet! https:\/\/t.co\/N1ByiZ96gr I also often increase Browser zoom % to make default text larger when presenting.",
  "id" : 745335169666646017,
  "in_reply_to_status_id" : 745332261185261569,
  "created_at" : "2016-06-21 19:18:46 +0000",
  "in_reply_to_screen_name" : "_mike_collins",
  "in_reply_to_user_id_str" : "41268670",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 55, 64 ],
      "id_str" : "890887814",
      "id" : 890887814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745322186290798592",
  "text" : "Curious if any other educators in my network are using @swipe_to (Markdown-based slides app)? Considering using it this Fall for CMPT 363.",
  "id" : 745322186290798592,
  "created_at" : "2016-06-21 18:27:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aarron Walter",
      "screen_name" : "aarron",
      "indices" : [ 3, 10 ],
      "id_str" : "9463382",
      "id" : 9463382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/REZCNgd0W9",
      "expanded_url" : "https:\/\/medium.com\/@aarron\/7-problems-growing-design-teams-face-5fd94292d405#.vr0z31msx",
      "display_url" : "medium.com\/@aarron\/7-prob\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745321475914141696",
  "text" : "RT @aarron: After studying many companies and running design teams for years, I've discovered 7 common problems all face. https:\/\/t.co\/REZC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/REZCNgd0W9",
        "expanded_url" : "https:\/\/medium.com\/@aarron\/7-problems-growing-design-teams-face-5fd94292d405#.vr0z31msx",
        "display_url" : "medium.com\/@aarron\/7-prob\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745316232983871488",
    "text" : "After studying many companies and running design teams for years, I've discovered 7 common problems all face. https:\/\/t.co\/REZCNgd0W9",
    "id" : 745316232983871488,
    "created_at" : "2016-06-21 18:03:31 +0000",
    "user" : {
      "name" : "Aarron Walter",
      "screen_name" : "aarron",
      "protected" : false,
      "id_str" : "9463382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727883346035023874\/pvWNeypQ_normal.jpg",
      "id" : 9463382,
      "verified" : false
    }
  },
  "id" : 745321475914141696,
  "created_at" : "2016-06-21 18:24:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Vk0zUjeLnJ",
      "expanded_url" : "https:\/\/getgrav.org\/downloads",
      "display_url" : "getgrav.org\/downloads"
    } ]
  },
  "geo" : { },
  "id_str" : "745308041596133376",
  "text" : "RT @getgrav: Updated Grav 1.1.0-rc.3 with Admin Plugin 1.1.0-rc.4 released! https:\/\/t.co\/Vk0zUjeLnJ Get 'em while they're hot!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/Vk0zUjeLnJ",
        "expanded_url" : "https:\/\/getgrav.org\/downloads",
        "display_url" : "getgrav.org\/downloads"
      } ]
    },
    "geo" : { },
    "id_str" : "745307948453363713",
    "text" : "Updated Grav 1.1.0-rc.3 with Admin Plugin 1.1.0-rc.4 released! https:\/\/t.co\/Vk0zUjeLnJ Get 'em while they're hot!",
    "id" : 745307948453363713,
    "created_at" : "2016-06-21 17:30:36 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 745308041596133376,
  "created_at" : "2016-06-21 17:30:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis",
      "screen_name" : "maestroluis",
      "indices" : [ 0, 12 ],
      "id_str" : "24625697",
      "id" : 24625697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745289943451205643",
  "geo" : { },
  "id_str" : "745300655556833284",
  "in_reply_to_user_id" : 24625697,
  "text" : "@maestroluis Nice to connect Luis! Please let me know if you have any questions or comments about my Grav Course Hub project.",
  "id" : 745300655556833284,
  "in_reply_to_status_id" : 745289943451205643,
  "created_at" : "2016-06-21 17:01:37 +0000",
  "in_reply_to_screen_name" : "maestroluis",
  "in_reply_to_user_id_str" : "24625697",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catherine Cronin",
      "screen_name" : "catherinecronin",
      "indices" : [ 3, 19 ],
      "id_str" : "59833587",
      "id" : 59833587
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oer",
      "indices" : [ 57, 61 ]
    }, {
      "text" : "oep",
      "indices" : [ 62, 66 ]
    }, {
      "text" : "oer16",
      "indices" : [ 67, 73 ]
    }, {
      "text" : "opened16",
      "indices" : [ 74, 83 ]
    }, {
      "text" : "go_gn",
      "indices" : [ 84, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/O6tgevFdDn",
      "expanded_url" : "https:\/\/twitter.com\/veletsianos\/status\/744911761267056640",
      "display_url" : "twitter.com\/veletsianos\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745054527292772353",
  "text" : "RT @catherinecronin: calling all open education folks... #oer #oep #oer16 #opened16 #go_gn https:\/\/t.co\/O6tgevFdDn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oer",
        "indices" : [ 36, 40 ]
      }, {
        "text" : "oep",
        "indices" : [ 41, 45 ]
      }, {
        "text" : "oer16",
        "indices" : [ 46, 52 ]
      }, {
        "text" : "opened16",
        "indices" : [ 53, 62 ]
      }, {
        "text" : "go_gn",
        "indices" : [ 63, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/O6tgevFdDn",
        "expanded_url" : "https:\/\/twitter.com\/veletsianos\/status\/744911761267056640",
        "display_url" : "twitter.com\/veletsianos\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744917095561961472",
    "text" : "calling all open education folks... #oer #oep #oer16 #opened16 #go_gn https:\/\/t.co\/O6tgevFdDn",
    "id" : 744917095561961472,
    "created_at" : "2016-06-20 15:37:30 +0000",
    "user" : {
      "name" : "Catherine Cronin",
      "screen_name" : "catherinecronin",
      "protected" : false,
      "id_str" : "59833587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577570280844886016\/FADcwktb_normal.png",
      "id" : 59833587,
      "verified" : false
    }
  },
  "id" : 745054527292772353,
  "created_at" : "2016-06-21 00:43:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Pantel",
      "screen_name" : "cpantel",
      "indices" : [ 3, 11 ],
      "id_str" : "24698409",
      "id" : 24698409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/2AauHKX36p",
      "expanded_url" : "https:\/\/lnkd.in\/eiE-zCb",
      "display_url" : "lnkd.in\/eiE-zCb"
    } ]
  },
  "geo" : { },
  "id_str" : "745008051497775104",
  "text" : "RT @cpantel: Product Designer - D2L https:\/\/t.co\/2AauHKX36p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/2AauHKX36p",
        "expanded_url" : "https:\/\/lnkd.in\/eiE-zCb",
        "display_url" : "lnkd.in\/eiE-zCb"
      } ]
    },
    "geo" : { },
    "id_str" : "745006126039629825",
    "text" : "Product Designer - D2L https:\/\/t.co\/2AauHKX36p",
    "id" : 745006126039629825,
    "created_at" : "2016-06-20 21:31:16 +0000",
    "user" : {
      "name" : "Christian Pantel",
      "screen_name" : "cpantel",
      "protected" : false,
      "id_str" : "24698409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1157862096\/IMG_8191_Twitter_normal.jpg",
      "id" : 24698409,
      "verified" : false
    }
  },
  "id" : 745008051497775104,
  "created_at" : "2016-06-20 21:38:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 32, 40 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/C3tZ8ovQa7",
      "expanded_url" : "http:\/\/demo.hibbittsdesign.org\/grav-multi-course-pages-hub\/",
      "display_url" : "demo.hibbittsdesign.org\/grav-multi-cou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744978351475953664",
  "text" : "Support for multiple courses in @getgrav Course Hub lets you share elements within one course AND between courses.\uD83D\uDE80\nhttps:\/\/t.co\/C3tZ8ovQa7",
  "id" : 744978351475953664,
  "created_at" : "2016-06-20 19:40:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baldwin",
      "screen_name" : "benry",
      "indices" : [ 3, 9 ],
      "id_str" : "1969441",
      "id" : 1969441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prodmgmt",
      "indices" : [ 93, 102 ]
    }, {
      "text" : "UX",
      "indices" : [ 103, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/N50PbhS9Ws",
      "expanded_url" : "http:\/\/benry.net",
      "display_url" : "benry.net"
    } ]
  },
  "geo" : { },
  "id_str" : "744596296917389312",
  "text" : "RT @benry: Hey interweb, I\u2019m no longer at YP, and looking for new opportunities in Vancouver #prodmgmt #UX. Find me here: https:\/\/t.co\/N50P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "prodmgmt",
        "indices" : [ 82, 91 ]
      }, {
        "text" : "UX",
        "indices" : [ 92, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/N50PbhS9Ws",
        "expanded_url" : "http:\/\/benry.net",
        "display_url" : "benry.net"
      } ]
    },
    "geo" : { },
    "id_str" : "743922078722625536",
    "text" : "Hey interweb, I\u2019m no longer at YP, and looking for new opportunities in Vancouver #prodmgmt #UX. Find me here: https:\/\/t.co\/N50PbhS9Ws",
    "id" : 743922078722625536,
    "created_at" : "2016-06-17 21:43:39 +0000",
    "user" : {
      "name" : "Scott Baldwin",
      "screen_name" : "benry",
      "protected" : false,
      "id_str" : "1969441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573733440186511360\/TYW5qsNh_normal.png",
      "id" : 1969441,
      "verified" : false
    }
  },
  "id" : 744596296917389312,
  "created_at" : "2016-06-19 18:22:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 6, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743904807199506432",
  "text" : "Draft #SFU CMPT 363 Open Source UX project criteria?\n\u2713Active\n\u27133+ contributors\n\u2713Online user community\n\u2713Large UX aspect\n\u2713Multi-device Web app",
  "id" : 743904807199506432,
  "created_at" : "2016-06-17 20:35:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/mDJ9E4VNAs",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/",
      "display_url" : "hibbittsdesign.org"
    } ]
  },
  "geo" : { },
  "id_str" : "743866008352366592",
  "text" : "See something you want to reuse on https:\/\/t.co\/mDJ9E4VNAs? At the bottom of each post there are now links to download or view as Markdown \uD83D\uDE4C",
  "id" : 743866008352366592,
  "created_at" : "2016-06-17 18:00:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin DeRosa",
      "screen_name" : "actualham",
      "indices" : [ 0, 10 ],
      "id_str" : "2182862052",
      "id" : 2182862052
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 11, 18 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 19, 32 ],
      "id_str" : "12991032",
      "id" : 12991032
    }, {
      "name" : "BCcampus Open",
      "screen_name" : "BCOpenText",
      "indices" : [ 33, 44 ],
      "id_str" : "3148543346",
      "id" : 3148543346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743862994157838336",
  "geo" : { },
  "id_str" : "743863769919455232",
  "in_reply_to_user_id" : 2182862052,
  "text" : "@actualham @btopro @clintlalonde @BCOpenText Please let me know if you have any questions, etc. about my Grav Course Hub project.",
  "id" : 743863769919455232,
  "in_reply_to_status_id" : 743862994157838336,
  "created_at" : "2016-06-17 17:51:57 +0000",
  "in_reply_to_screen_name" : "actualham",
  "in_reply_to_user_id_str" : "2182862052",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Robin DeRosa",
      "screen_name" : "actualham",
      "indices" : [ 8, 18 ],
      "id_str" : "2182862052",
      "id" : 2182862052
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 19, 32 ],
      "id_str" : "12991032",
      "id" : 12991032
    }, {
      "name" : "BCcampus Open",
      "screen_name" : "BCOpenText",
      "indices" : [ 33, 44 ],
      "id_str" : "3148543346",
      "id" : 3148543346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/XobSDZK7gz",
      "expanded_url" : "https:\/\/www.swipe.to\/4340n#page=nv8hRbrJC",
      "display_url" : "swipe.to\/4340n#page=nv8\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "743862379063152641",
  "geo" : { },
  "id_str" : "743863324438233088",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @actualham @clintlalonde @BCOpenText I've loved moving from HTML&gt;Markdown... here is my Markdown in 1 slide: https:\/\/t.co\/XobSDZK7gz",
  "id" : 743863324438233088,
  "in_reply_to_status_id" : 743862379063152641,
  "created_at" : "2016-06-17 17:50:11 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/WPekFQ3fyM",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/demo\/grav-course-hub-bootstrap\/",
      "display_url" : "hibbittsdesign.org\/demo\/grav-cour\u2026"
    }, {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/93oxU1Hpo3",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/demo\/grav-multi-course-hub\/",
      "display_url" : "hibbittsdesign.org\/demo\/grav-mult\u2026"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/sZCYRZccqP",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/demo\/grav-multi-course-hub-v2\/",
      "display_url" : "hibbittsdesign.org\/demo\/grav-mult\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743862249492623364",
  "text" : "Here are 3 Grav Course Hub demos:\nSingle course:\nhttps:\/\/t.co\/WPekFQ3fyM\nMultiple courses:\nhttps:\/\/t.co\/93oxU1Hpo3\nhttps:\/\/t.co\/sZCYRZccqP",
  "id" : 743862249492623364,
  "created_at" : "2016-06-17 17:45:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "indices" : [ 3, 16 ],
      "id_str" : "35943",
      "id" : 35943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/hQB4ML02bF",
      "expanded_url" : "https:\/\/www.youcaring.com\/help-carolyn",
      "display_url" : "youcaring.com\/help-carolyn"
    } ]
  },
  "geo" : { },
  "id_str" : "743847518186807296",
  "text" : "RT @karenmcgrane: I\u2019d love it if everyone could donate to help Carolyn. I\u2019d also love it if you could retweet this to your networks. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/hQB4ML02bF",
        "expanded_url" : "https:\/\/www.youcaring.com\/help-carolyn",
        "display_url" : "youcaring.com\/help-carolyn"
      } ]
    },
    "in_reply_to_status_id_str" : "743792368801955840",
    "geo" : { },
    "id_str" : "743794829226827776",
    "in_reply_to_user_id" : 35943,
    "text" : "I\u2019d love it if everyone could donate to help Carolyn. I\u2019d also love it if you could retweet this to your networks. https:\/\/t.co\/hQB4ML02bF",
    "id" : 743794829226827776,
    "in_reply_to_status_id" : 743792368801955840,
    "created_at" : "2016-06-17 13:18:00 +0000",
    "in_reply_to_screen_name" : "karenmcgrane",
    "in_reply_to_user_id_str" : "35943",
    "user" : {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "protected" : false,
      "id_str" : "35943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720948130867449857\/DR8tPuqM_normal.jpg",
      "id" : 35943,
      "verified" : false
    }
  },
  "id" : 743847518186807296,
  "created_at" : "2016-06-17 16:47:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/mQ0s1btU4K",
      "expanded_url" : "https:\/\/twitter.com\/btopro\/status\/743616722201092096",
      "display_url" : "twitter.com\/btopro\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743618906871390208",
  "text" : "And really, when was the LMS ever someone's first destination of choice? https:\/\/t.co\/mQ0s1btU4K",
  "id" : 743618906871390208,
  "created_at" : "2016-06-17 01:38:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/Nc2zrlnoyz",
      "expanded_url" : "https:\/\/twitter.com\/clintlalonde\/status\/743586784123068421",
      "display_url" : "twitter.com\/clintlalonde\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743597114903564288",
  "text" : "Awesome, thanks for sharing this Clint! https:\/\/t.co\/Nc2zrlnoyz",
  "id" : 743597114903564288,
  "created_at" : "2016-06-17 00:12:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 10, 24 ],
      "id_str" : "260919324",
      "id" : 260919324
    }, {
      "name" : "Shan Satoglu",
      "screen_name" : "shansatoglu",
      "indices" : [ 31, 43 ],
      "id_str" : "527937919",
      "id" : 527937919
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 76, 84 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/q2Ts3GTcAi",
      "expanded_url" : "http:\/\/demo.hibbittsdesign.org\/grav-multi-course-hub-v2\/",
      "display_url" : "demo.hibbittsdesign.org\/grav-multi-cou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743546310557470721",
  "text" : "Thanks to @clhendricksbc &amp; @ShanSatoglu multiple course support for the @getgrav Course Hub is coming! Sneak peek: https:\/\/t.co\/q2Ts3GTcAi \uD83D\uDE80",
  "id" : 743546310557470721,
  "created_at" : "2016-06-16 20:50:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "silo",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743523868678094848",
  "text" : "RT @btopro: hearing people talk about HTML they are *allowed* to use in Canvas. Why are you not *allowed* to use the full richness of the w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "silo",
        "indices" : [ 130, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743523481833222144",
    "text" : "hearing people talk about HTML they are *allowed* to use in Canvas. Why are you not *allowed* to use the full richness of the web #silo",
    "id" : 743523481833222144,
    "created_at" : "2016-06-16 19:19:46 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 743523868678094848,
  "created_at" : "2016-06-16 19:21:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743523808951205888",
  "text" : "RT @btopro: are we not beyond HTML for creating documents on the web? mark, down. mark, down.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743523709395181572",
    "text" : "are we not beyond HTML for creating documents on the web? mark, down. mark, down.",
    "id" : 743523709395181572,
    "created_at" : "2016-06-16 19:20:40 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 743523808951205888,
  "created_at" : "2016-06-16 19:21:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 74, 82 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/743122272009871360\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/O67BTe9O6O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClAZw9rUgAE9GHl.jpg",
      "id_str" : "743122267496808449",
      "id" : 743122267496808449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClAZw9rUgAE9GHl.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 462,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/O67BTe9O6O"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/743122272009871360\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/O67BTe9O6O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClAZwyXUUAQga1P.jpg",
      "id_str" : "743122264460120068",
      "id" : 743122264460120068,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClAZwyXUUAQga1P.jpg",
      "sizes" : [ {
        "h" : 523,
        "resize" : "fit",
        "w" : 712
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 712
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 712
      } ],
      "display_url" : "pic.twitter.com\/O67BTe9O6O"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/743122272009871360\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/O67BTe9O6O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClAZxABUkAEra6b.jpg",
      "id_str" : "743122268125958145",
      "id" : 743122268125958145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClAZxABUkAEra6b.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 462,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/O67BTe9O6O"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/743122272009871360\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/O67BTe9O6O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClAZwyWUYAASqgb.jpg",
      "id_str" : "743122264455929856",
      "id" : 743122264455929856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClAZwyWUYAASqgb.jpg",
      "sizes" : [ {
        "h" : 523,
        "resize" : "fit",
        "w" : 712
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 712
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 712
      } ],
      "display_url" : "pic.twitter.com\/O67BTe9O6O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743122272009871360",
  "text" : "Achievement unlocked (just before demo tomorrow): Multiple courses within @getgrav Course Hub with course sub-pages. https:\/\/t.co\/O67BTe9O6O",
  "id" : 743122272009871360,
  "created_at" : "2016-06-15 16:45:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jameslabocki",
      "screen_name" : "jameslabocki",
      "indices" : [ 120, 133 ],
      "id_str" : "15275187",
      "id" : 15275187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/rHQQA0q04b",
      "expanded_url" : "https:\/\/allthingsopen.com\/2016\/01\/29\/can-strategic-design-improve-the-design-and-user-experience-across-open-source-communities\/",
      "display_url" : "allthingsopen.com\/2016\/01\/29\/can\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742874070199328768",
  "text" : "Can Strategic Design Improve the Design and User Experience Across Open Source Communities? https:\/\/t.co\/rHQQA0q04b via @jameslabocki",
  "id" : 742874070199328768,
  "created_at" : "2016-06-15 00:19:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742860538233774080",
  "text" : "In addition to CMPT 363 class exercises + weekly readings, a key educational element is a peer-reviewed heuristic eval before user research.",
  "id" : 742860538233774080,
  "created_at" : "2016-06-14 23:25:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 10, 14 ]
    }, {
      "text" : "UX",
      "indices" : [ 44, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742853489986916352",
  "text" : "Steps for #SFU CMPT-363 student open source #UX project:\n\u2705 Project choice\n\u2705 User research (incl. usability tests)\n\u2705 Design &amp; usability tests",
  "id" : 742853489986916352,
  "created_at" : "2016-06-14 22:57:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/742828655869452288\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/XHM6gIgbYQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck8OuUGVAAAbFgJ.jpg",
      "id_str" : "742828652371443712",
      "id" : 742828652371443712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck8OuUGVAAAbFgJ.jpg",
      "sizes" : [ {
        "h" : 802,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 660
      } ],
      "display_url" : "pic.twitter.com\/XHM6gIgbYQ"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 14, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Gy7HkHzFVM",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1wMOEchgUUkN13t2i5sZFKaw7Mhavn2DslRXZKLqfXPE\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1wM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742828655869452288",
  "text" : "Working on my #SFU CMPT 363 UX design course: visual UX process\/toolkit &amp; course questions. https:\/\/t.co\/Gy7HkHzFVM https:\/\/t.co\/XHM6gIgbYQ",
  "id" : 742828655869452288,
  "created_at" : "2016-06-14 21:18:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/Vk0zUjeLnJ",
      "expanded_url" : "https:\/\/getgrav.org\/downloads",
      "display_url" : "getgrav.org\/downloads"
    } ]
  },
  "geo" : { },
  "id_str" : "742813945002524672",
  "text" : "RT @getgrav: Grav 1.1 RC-2 and Admin Plugin 1.1 RC-3 now available to download and test! https:\/\/t.co\/Vk0zUjeLnJ Enjoy!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/Vk0zUjeLnJ",
        "expanded_url" : "https:\/\/getgrav.org\/downloads",
        "display_url" : "getgrav.org\/downloads"
      } ]
    },
    "geo" : { },
    "id_str" : "742776548445540353",
    "text" : "Grav 1.1 RC-2 and Admin Plugin 1.1 RC-3 now available to download and test! https:\/\/t.co\/Vk0zUjeLnJ Enjoy!",
    "id" : 742776548445540353,
    "created_at" : "2016-06-14 17:51:43 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 742813945002524672,
  "created_at" : "2016-06-14 20:20:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 86, 94 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/hnkrmJhirL",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-06-15-including-multiple-courses-within-a-hub",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742795041672822785",
  "text" : "Sneak peek at my blog post about the new support for multiple courses within a single @getgrav Course Hub. https:\/\/t.co\/hnkrmJhirL #GravEdu",
  "id" : 742795041672822785,
  "created_at" : "2016-06-14 19:05:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 28, 36 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/9PFedwpqcF",
      "expanded_url" : "https:\/\/getgrav.org\/downloads\/skeletons",
      "display_url" : "getgrav.org\/downloads\/skel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742770167818551296",
  "text" : "With the 1.2 release of the @getgrav course hub, experimental support for multiple courses (blogs) is now included. https:\/\/t.co\/9PFedwpqcF",
  "id" : 742770167818551296,
  "created_at" : "2016-06-14 17:26:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 24, 32 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 74, 87 ],
      "id_str" : "91939908",
      "id" : 91939908
    }, {
      "name" : "Shan Satoglu",
      "screen_name" : "shansatoglu",
      "indices" : [ 116, 128 ],
      "id_str" : "527937919",
      "id" : 527937919
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/fZu563LR6a",
      "expanded_url" : "http:\/\/watchtheedge.ca\/2016\/06\/09\/working-with-grav\/",
      "display_url" : "watchtheedge.ca\/2016\/06\/09\/wor\u2026"
    }, {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/pr1WgtkqyD",
      "expanded_url" : "https:\/\/post.bcit.ca\/flipping-the-lms\/",
      "display_url" : "post.bcit.ca\/flipping-the-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742763584669655040",
  "text" : "Some recent posts about @getgrav in education:\nhttps:\/\/t.co\/fZu563LR6a by @davidnwright \nhttps:\/\/t.co\/pr1WgtkqyD by @ShanSatoglu\n#GravEdu \uD83D\uDE80",
  "id" : 742763584669655040,
  "created_at" : "2016-06-14 17:00:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 50, 58 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741418949682724864",
  "text" : "A nice bookend to a great week. My little blog of @getgrav and open source learning environments reached a milestone +1000 visits\/mo. \uD83C\uDF86",
  "id" : 741418949682724864,
  "created_at" : "2016-06-10 23:57:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 56, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/rcBEwCg5W1",
      "expanded_url" : "http:\/\/ow.ly\/JdJE3019dwA",
      "display_url" : "ow.ly\/JdJE3019dwA"
    } ]
  },
  "geo" : { },
  "id_str" : "741413123920252932",
  "text" : "RT @BCcampus: Sign up for our newsletter to receive the #FoL16 follow-up, filled with digital assets (slides, images, etc. ) https:\/\/t.co\/r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 42, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/rcBEwCg5W1",
        "expanded_url" : "http:\/\/ow.ly\/JdJE3019dwA",
        "display_url" : "ow.ly\/JdJE3019dwA"
      } ]
    },
    "geo" : { },
    "id_str" : "741412752967733249",
    "text" : "Sign up for our newsletter to receive the #FoL16 follow-up, filled with digital assets (slides, images, etc. ) https:\/\/t.co\/rcBEwCg5W1",
    "id" : 741412752967733249,
    "created_at" : "2016-06-10 23:32:29 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 741413123920252932,
  "created_at" : "2016-06-10 23:33:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 0, 9 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741383515552415745",
  "geo" : { },
  "id_str" : "741410013298597889",
  "in_reply_to_user_id" : 15949844,
  "text" : "@BCcampus Thanks so much for the RTs, always appreciated! Have a great weekend.",
  "id" : 741410013298597889,
  "in_reply_to_status_id" : 741383515552415745,
  "created_at" : "2016-06-10 23:21:36 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741397292666654720",
  "geo" : { },
  "id_str" : "741397832423243776",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Great, I will DM you for a meetup to review details, etc. Cheers!",
  "id" : 741397832423243776,
  "in_reply_to_status_id" : 741397292666654720,
  "created_at" : "2016-06-10 22:33:12 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 2, 10 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/741383515552415745\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/lciRxmUMEx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CknsX6qVAAAU-Hw.jpg",
      "id_str" : "741383509307097088",
      "id" : 741383509307097088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CknsX6qVAAAU-Hw.jpg",
      "sizes" : [ {
        "h" : 836,
        "resize" : "fit",
        "w" : 1260
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 836,
        "resize" : "fit",
        "w" : 1260
      } ],
      "display_url" : "pic.twitter.com\/lciRxmUMEx"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/741383515552415745\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/lciRxmUMEx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CknsYDGUUAAp8_w.jpg",
      "id_str" : "741383511571976192",
      "id" : 741383511571976192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CknsYDGUUAAp8_w.jpg",
      "sizes" : [ {
        "h" : 836,
        "resize" : "fit",
        "w" : 1260
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 836,
        "resize" : "fit",
        "w" : 1260
      } ],
      "display_url" : "pic.twitter.com\/lciRxmUMEx"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/741383515552415745\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/lciRxmUMEx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CknsYAdVEAAYxsS.jpg",
      "id_str" : "741383510863187968",
      "id" : 741383510863187968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CknsYAdVEAAYxsS.jpg",
      "sizes" : [ {
        "h" : 836,
        "resize" : "fit",
        "w" : 1260
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 836,
        "resize" : "fit",
        "w" : 1260
      } ],
      "display_url" : "pic.twitter.com\/lciRxmUMEx"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/741383515552415745\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/lciRxmUMEx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CknsWhxVEAEDpo_.jpg",
      "id_str" : "741383485445705729",
      "id" : 741383485445705729,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CknsWhxVEAEDpo_.jpg",
      "sizes" : [ {
        "h" : 774,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 1260
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 1260
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/lciRxmUMEx"
    } ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 101, 107 ]
    }, {
      "text" : "GravEdu",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741383515552415745",
  "text" : "A @getgrav Multi-course Hub can have a blog for each course and shared content, all in a single hub. #FoL16 #GravEdu https:\/\/t.co\/lciRxmUMEx",
  "id" : 741383515552415745,
  "created_at" : "2016-06-10 21:36:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barish Golland",
      "screen_name" : "BarishGolland",
      "indices" : [ 3, 17 ],
      "id_str" : "32352319",
      "id" : 32352319
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WordPress",
      "indices" : [ 38, 48 ]
    }, {
      "text" : "HigherEd",
      "indices" : [ 52, 61 ]
    }, {
      "text" : "FoL16",
      "indices" : [ 71, 77 ]
    }, {
      "text" : "WPCampus",
      "indices" : [ 79, 88 ]
    }, {
      "text" : "xAPI",
      "indices" : [ 89, 94 ]
    }, {
      "text" : "UBC",
      "indices" : [ 95, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/ehuYu0uLVY",
      "expanded_url" : "http:\/\/www.slideshare.net\/BarishGolland\/wordpress-in-higher-ed-courses-programs-and-future-plans-at-ubc",
      "display_url" : "slideshare.net\/BarishGolland\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741380604202078208",
  "text" : "RT @BarishGolland: My slides from the #WordPress in #HigherEd panel at #FoL16, #WPCampus #xAPI #UBC https:\/\/t.co\/ehuYu0uLVY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WordPress",
        "indices" : [ 19, 29 ]
      }, {
        "text" : "HigherEd",
        "indices" : [ 33, 42 ]
      }, {
        "text" : "FoL16",
        "indices" : [ 52, 58 ]
      }, {
        "text" : "WPCampus",
        "indices" : [ 60, 69 ]
      }, {
        "text" : "xAPI",
        "indices" : [ 70, 75 ]
      }, {
        "text" : "UBC",
        "indices" : [ 76, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/ehuYu0uLVY",
        "expanded_url" : "http:\/\/www.slideshare.net\/BarishGolland\/wordpress-in-higher-ed-courses-programs-and-future-plans-at-ubc",
        "display_url" : "slideshare.net\/BarishGolland\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740967352133525506",
    "text" : "My slides from the #WordPress in #HigherEd panel at #FoL16, #WPCampus #xAPI #UBC https:\/\/t.co\/ehuYu0uLVY",
    "id" : 740967352133525506,
    "created_at" : "2016-06-09 18:02:37 +0000",
    "user" : {
      "name" : "Barish Golland",
      "screen_name" : "BarishGolland",
      "protected" : false,
      "id_str" : "32352319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2781080334\/edb2a707e205406bc022eedd7926198a_normal.jpeg",
      "id" : 32352319,
      "verified" : false
    }
  },
  "id" : 741380604202078208,
  "created_at" : "2016-06-10 21:24:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 58, 66 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 33, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/gEFdVW0Ygt",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/tests\/grav-multi-course-hub\/",
      "display_url" : "hibbittsdesign.org\/tests\/grav-mul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741369155203407872",
  "text" : "It's (barely) alive! Inspired by #FoL16 here's an example @getgrav multi-course hub. Share elements BETWEEN courses\uD83D\uDC4D https:\/\/t.co\/gEFdVW0Ygt",
  "id" : 741369155203407872,
  "created_at" : "2016-06-10 20:39:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard",
      "screen_name" : "rwpickard",
      "indices" : [ 0, 10 ],
      "id_str" : "17435582",
      "id" : 17435582
    }, {
      "name" : "Catherine Caws",
      "screen_name" : "katrinrulokoz",
      "indices" : [ 11, 25 ],
      "id_str" : "126046946",
      "id" : 126046946
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 26, 39 ],
      "id_str" : "12991032",
      "id" : 12991032
    }, {
      "name" : "Fernwood Publishing",
      "screen_name" : "fernpub",
      "indices" : [ 40, 48 ],
      "id_str" : "47670565",
      "id" : 47670565
    }, {
      "name" : "Matthew Hooton",
      "screen_name" : "deloumeroad",
      "indices" : [ 49, 61 ],
      "id_str" : "96889297",
      "id" : 96889297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741353703702024192",
  "geo" : { },
  "id_str" : "741364802056916992",
  "in_reply_to_user_id" : 17435582,
  "text" : "@rwpickard @katrinrulokoz @clintlalonde @fernpub @deloumeroad Any due income should be paid for sure! I've donated to 'shareware' texts.",
  "id" : 741364802056916992,
  "in_reply_to_status_id" : 741353703702024192,
  "created_at" : "2016-06-10 20:21:57 +0000",
  "in_reply_to_screen_name" : "rwpickard",
  "in_reply_to_user_id_str" : "17435582",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 18, 26 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 11, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/NHl8XDCJOT",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-06-03-moving-beyond-the-lms-with-grav-workshop-resources",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741321497944297477",
  "text" : "Attend the #FoL16 @getgrav studio yesterday? Want to dig deeper into the goodness of Grav? Here's a resources page! https:\/\/t.co\/NHl8XDCJOT",
  "id" : 741321497944297477,
  "created_at" : "2016-06-10 17:29:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/741320123860975617\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/1ddNoPznsJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkmyuHUVAAEkcD1.jpg",
      "id_str" : "741320118987194369",
      "id" : 741320118987194369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkmyuHUVAAEkcD1.jpg",
      "sizes" : [ {
        "h" : 774,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 1260
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 1260
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/1ddNoPznsJ"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/741320123860975617\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/1ddNoPznsJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkmyuHmUoAAd47B.jpg",
      "id_str" : "741320119062667264",
      "id" : 741320119062667264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkmyuHmUoAAd47B.jpg",
      "sizes" : [ {
        "h" : 774,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 1260
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 1260
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/1ddNoPznsJ"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/741320123860975617\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/1ddNoPznsJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkmyuNAUoAAq6fP.jpg",
      "id_str" : "741320120513896448",
      "id" : 741320120513896448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkmyuNAUoAAq6fP.jpg",
      "sizes" : [ {
        "h" : 774,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 1260
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 1260
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/1ddNoPznsJ"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/741320123860975617\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/1ddNoPznsJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkmyuJbUkAAuoe8.jpg",
      "id_str" : "741320119553396736",
      "id" : 741320119553396736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkmyuJbUkAAuoe8.jpg",
      "sizes" : [ {
        "h" : 774,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 1260
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 1260
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/1ddNoPznsJ"
    } ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 63, 69 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741298959319064576",
  "geo" : { },
  "id_str" : "741320123860975617",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc That sounds great, thanks! I was so inspired by #FoL16 I couldn't help myself... right direction? https:\/\/t.co\/1ddNoPznsJ",
  "id" : 741320123860975617,
  "in_reply_to_status_id" : 741298959319064576,
  "created_at" : "2016-06-10 17:24:25 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 26, 34 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 40, 47 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Bw3oVBpojk",
      "expanded_url" : "https:\/\/twitter.com\/davidnwright\/status\/741121510765658112",
      "display_url" : "twitter.com\/davidnwright\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741317743861858304",
  "text" : "A great overview of using @getgrav with @github, this time using simple FTP transfers to update site pages. #FoL16 https:\/\/t.co\/Bw3oVBpojk",
  "id" : 741317743861858304,
  "created_at" : "2016-06-10 17:14:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 0, 9 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741291997210644480",
  "geo" : { },
  "id_str" : "741294430846517252",
  "in_reply_to_user_id" : 93710949,
  "text" : "@BCcampus Thank you! \uD83D\uDE0A",
  "id" : 741294430846517252,
  "in_reply_to_status_id" : 741291997210644480,
  "created_at" : "2016-06-10 15:42:19 +0000",
  "in_reply_to_screen_name" : "BCcampus",
  "in_reply_to_user_id_str" : "93710949",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 0, 13 ],
      "id_str" : "91939908",
      "id" : 91939908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/tv9q3nqqW1",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/",
      "display_url" : "hibbittsdesign.org\/blog\/"
    } ]
  },
  "in_reply_to_status_id_str" : "741121510765658112",
  "geo" : { },
  "id_str" : "741124479292739589",
  "in_reply_to_user_id" : 91939908,
  "text" : "@davidnwright I'd also love to make it a linked entry in my blog if you are a-ok with it, like the 'Fork U' entry at https:\/\/t.co\/tv9q3nqqW1",
  "id" : 741124479292739589,
  "in_reply_to_status_id" : 741121510765658112,
  "created_at" : "2016-06-10 04:26:59 +0000",
  "in_reply_to_screen_name" : "davidnwright",
  "in_reply_to_user_id_str" : "91939908",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 0, 13 ],
      "id_str" : "91939908",
      "id" : 91939908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741121510765658112",
  "geo" : { },
  "id_str" : "741123919533473796",
  "in_reply_to_user_id" : 91939908,
  "text" : "@davidnwright This is an absolutely awesome post! I will further share it tomorrow to help spread it around \uD83D\uDE42  Your FTP + GitHub is great \uD83D\uDC4D",
  "id" : 741123919533473796,
  "in_reply_to_status_id" : 741121510765658112,
  "created_at" : "2016-06-10 04:24:46 +0000",
  "in_reply_to_screen_name" : "davidnwright",
  "in_reply_to_user_id_str" : "91939908",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741109841037561857",
  "geo" : { },
  "id_str" : "741118678620639232",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Thanks Christina, I am so glad that you enjoyed it! Perhaps next week we can connect re: multiple course hub site.",
  "id" : 741118678620639232,
  "in_reply_to_status_id" : 741109841037561857,
  "created_at" : "2016-06-10 04:03:56 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741112105315774465",
  "geo" : { },
  "id_str" : "741117803290316800",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Thanks so much Clint, glad you were able to be a part of it!",
  "id" : 741117803290316800,
  "in_reply_to_status_id" : 741112105315774465,
  "created_at" : "2016-06-10 04:00:28 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 76, 84 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 42, 48 ]
    }, {
      "text" : "GravEdu",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/01QG69wdR4",
      "expanded_url" : "https:\/\/swipe.to\/4340n",
      "display_url" : "swipe.to\/4340n"
    } ]
  },
  "geo" : { },
  "id_str" : "741064848188919808",
  "text" : "Thanks to everyone who participated in my #FoL16 Moving Beyond the LMS with @getgrav Workshop! Slides at: https:\/\/t.co\/01QG69wdR4 #GravEdu",
  "id" : 741064848188919808,
  "created_at" : "2016-06-10 00:30:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Robarts",
      "screen_name" : "srobarts",
      "indices" : [ 0, 9 ],
      "id_str" : "4540561",
      "id" : 4540561
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 10, 18 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "741003793865662466",
  "geo" : { },
  "id_str" : "741044670604529665",
  "in_reply_to_user_id" : 4540561,
  "text" : "@srobarts @getgrav Thanks so much for being part of the session!",
  "id" : 741044670604529665,
  "in_reply_to_status_id" : 741003793865662466,
  "created_at" : "2016-06-09 23:09:52 +0000",
  "in_reply_to_screen_name" : "srobarts",
  "in_reply_to_user_id_str" : "4540561",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Yip",
      "screen_name" : "denniskdyip",
      "indices" : [ 3, 15 ],
      "id_str" : "174739964",
      "id" : 174739964
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/denniskdyip\/status\/741035759881228288\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/T8T34kiY3w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiwF1RUoAA7oRp.jpg",
      "id_str" : "741035752948015104",
      "id" : 741035752948015104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiwF1RUoAA7oRp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/T8T34kiY3w"
    } ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 53, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741042201375838208",
  "text" : "RT @denniskdyip: THANK YOU for an amazing conference #FoL16 https:\/\/t.co\/T8T34kiY3w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/denniskdyip\/status\/741035759881228288\/photo\/1",
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/T8T34kiY3w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiwF1RUoAA7oRp.jpg",
        "id_str" : "741035752948015104",
        "id" : 741035752948015104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiwF1RUoAA7oRp.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/T8T34kiY3w"
      } ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 36, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741035759881228288",
    "text" : "THANK YOU for an amazing conference #FoL16 https:\/\/t.co\/T8T34kiY3w",
    "id" : 741035759881228288,
    "created_at" : "2016-06-09 22:34:27 +0000",
    "user" : {
      "name" : "Dennis Yip",
      "screen_name" : "denniskdyip",
      "protected" : false,
      "id_str" : "174739964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703760154945171456\/ERFlFxby_normal.jpg",
      "id" : 174739964,
      "verified" : false
    }
  },
  "id" : 741042201375838208,
  "created_at" : "2016-06-09 23:00:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/TuZYh072fq",
      "expanded_url" : "https:\/\/twitter.com\/GreenGeographer\/status\/741040376375480320",
      "display_url" : "twitter.com\/GreenGeographe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741041996513480705",
  "text" : "It was my pleasure, thanks for joining us! https:\/\/t.co\/TuZYh072fq",
  "id" : 741041996513480705,
  "created_at" : "2016-06-09 22:59:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 23, 31 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 113, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/pr1WgtkqyD",
      "expanded_url" : "https:\/\/post.bcit.ca\/flipping-the-lms\/",
      "display_url" : "post.bcit.ca\/flipping-the-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740973695410151426",
  "text" : "Flipping the LMS (with @getgrav) to Support Agile Course Design and High-Impact Learning https:\/\/t.co\/pr1WgtkqyD #FoL16 \uD83D\uDE4C",
  "id" : 740973695410151426,
  "created_at" : "2016-06-09 18:27:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 24, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/JKCp6WyYQh",
      "expanded_url" : "https:\/\/twitter.com\/davidnwright\/status\/740968027076714496",
      "display_url" : "twitter.com\/davidnwright\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740969023236493312",
  "text" : "Awesome to see David! \uD83D\uDE80 #FoL16 https:\/\/t.co\/JKCp6WyYQh",
  "id" : 740969023236493312,
  "created_at" : "2016-06-09 18:09:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 3, 14 ],
      "id_str" : "1983141",
      "id" : 1983141
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/okalrelsrv\/status\/740961536424873984\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/4wVwYquNOl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkhslkmVEAApfRZ.jpg",
      "id_str" : "740961531437846528",
      "id" : 740961531437846528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkhslkmVEAApfRZ.jpg",
      "sizes" : [ {
        "h" : 967,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1218,
        "resize" : "fit",
        "w" : 1512
      }, {
        "h" : 548,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1218,
        "resize" : "fit",
        "w" : 1512
      } ],
      "display_url" : "pic.twitter.com\/4wVwYquNOl"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/okalrelsrv\/status\/740961536424873984\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/4wVwYquNOl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ckhslk6UkAAJTgN.jpg",
      "id_str" : "740961531521699840",
      "id" : 740961531521699840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ckhslk6UkAAJTgN.jpg",
      "sizes" : [ {
        "h" : 774,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 978,
        "resize" : "fit",
        "w" : 1516
      }, {
        "h" : 978,
        "resize" : "fit",
        "w" : 1516
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/4wVwYquNOl"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/okalrelsrv\/status\/740961536424873984\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/4wVwYquNOl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkhslmgUoAA0CuS.jpg",
      "id_str" : "740961531949522944",
      "id" : 740961531949522944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkhslmgUoAA0CuS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/4wVwYquNOl"
    } ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 16, 22 ]
    }, {
      "text" : "edtech",
      "indices" : [ 23, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/S2ioWl92Om",
      "expanded_url" : "http:\/\/tinyurl.com\/z9d28xh",
      "display_url" : "tinyurl.com\/z9d28xh"
    } ]
  },
  "geo" : { },
  "id_str" : "740961699595845632",
  "text" : "RT @okalrelsrv: #FoL16 #edtech pros in BC invited to sign up to stay informed - platform and practice co-op https:\/\/t.co\/S2ioWl92Om https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/okalrelsrv\/status\/740961536424873984\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/4wVwYquNOl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkhslkmVEAApfRZ.jpg",
        "id_str" : "740961531437846528",
        "id" : 740961531437846528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkhslkmVEAApfRZ.jpg",
        "sizes" : [ {
          "h" : 967,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1218,
          "resize" : "fit",
          "w" : 1512
        }, {
          "h" : 548,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1218,
          "resize" : "fit",
          "w" : 1512
        } ],
        "display_url" : "pic.twitter.com\/4wVwYquNOl"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/okalrelsrv\/status\/740961536424873984\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/4wVwYquNOl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ckhslk6UkAAJTgN.jpg",
        "id_str" : "740961531521699840",
        "id" : 740961531521699840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ckhslk6UkAAJTgN.jpg",
        "sizes" : [ {
          "h" : 774,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 978,
          "resize" : "fit",
          "w" : 1516
        }, {
          "h" : 978,
          "resize" : "fit",
          "w" : 1516
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/4wVwYquNOl"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/okalrelsrv\/status\/740961536424873984\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/4wVwYquNOl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkhslmgUoAA0CuS.jpg",
        "id_str" : "740961531949522944",
        "id" : 740961531949522944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkhslmgUoAA0CuS.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/4wVwYquNOl"
      } ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "edtech",
        "indices" : [ 7, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/S2ioWl92Om",
        "expanded_url" : "http:\/\/tinyurl.com\/z9d28xh",
        "display_url" : "tinyurl.com\/z9d28xh"
      } ]
    },
    "geo" : { },
    "id_str" : "740961536424873984",
    "text" : "#FoL16 #edtech pros in BC invited to sign up to stay informed - platform and practice co-op https:\/\/t.co\/S2ioWl92Om https:\/\/t.co\/4wVwYquNOl",
    "id" : 740961536424873984,
    "created_at" : "2016-06-09 17:39:31 +0000",
    "user" : {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "protected" : false,
      "id_str" : "1983141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739951680591040512\/HosITGfQ_normal.jpg",
      "id" : 1983141,
      "verified" : false
    }
  },
  "id" : 740961699595845632,
  "created_at" : "2016-06-09 17:40:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 11, 18 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 107, 115 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/NgJLlK4uk6",
      "expanded_url" : "https:\/\/www.swipe.to\/4340n#page=4kvvQLrfJ",
      "display_url" : "swipe.to\/4340n#page=4kv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740955205382995968",
  "text" : "Look, it's @btopro yet again making a guest appearance in one of my workshops about flipping your LMS with @getgrav! https:\/\/t.co\/NgJLlK4uk6",
  "id" : 740955205382995968,
  "created_at" : "2016-06-09 17:14:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 3, 17 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/jqIvpusAJO",
      "expanded_url" : "https:\/\/oet.sandcats.io\/",
      "display_url" : "oet.sandcats.io"
    } ]
  },
  "geo" : { },
  "id_str" : "740941071593537536",
  "text" : "RT @clhendricksbc: #FoL16 What is Sandstorm at BCcampus? It\u2019s a web app that makes web apps easy to install with one click. https:\/\/t.co\/jq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/jqIvpusAJO",
        "expanded_url" : "https:\/\/oet.sandcats.io\/",
        "display_url" : "oet.sandcats.io"
      } ]
    },
    "geo" : { },
    "id_str" : "740939389967032320",
    "text" : "#FoL16 What is Sandstorm at BCcampus? It\u2019s a web app that makes web apps easy to install with one click. https:\/\/t.co\/jqIvpusAJO",
    "id" : 740939389967032320,
    "created_at" : "2016-06-09 16:11:31 +0000",
    "user" : {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "protected" : false,
      "id_str" : "260919324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726838525086208000\/46wx7Jih_normal.jpg",
      "id" : 260919324,
      "verified" : false
    }
  },
  "id" : 740941071593537536,
  "created_at" : "2016-06-09 16:18:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Rumsey",
      "screen_name" : "ryanrumsey",
      "indices" : [ 3, 14 ],
      "id_str" : "1639811",
      "id" : 1639811
    }, {
      "name" : "Dawn Ressel (Nidy)",
      "screen_name" : "uxdawn",
      "indices" : [ 112, 119 ],
      "id_str" : "32317236",
      "id" : 32317236
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EUX16",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740940666054705152",
  "text" : "RT @ryanrumsey: \"Until your design is out in he hands of users, via code, it's a figment of your imagination\" - @uxdawn #EUX16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dawn Ressel (Nidy)",
        "screen_name" : "uxdawn",
        "indices" : [ 96, 103 ],
        "id_str" : "32317236",
        "id" : 32317236
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EUX16",
        "indices" : [ 104, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740927574197473281",
    "text" : "\"Until your design is out in he hands of users, via code, it's a figment of your imagination\" - @uxdawn #EUX16",
    "id" : 740927574197473281,
    "created_at" : "2016-06-09 15:24:34 +0000",
    "user" : {
      "name" : "Ryan Rumsey",
      "screen_name" : "ryanrumsey",
      "protected" : false,
      "id_str" : "1639811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750031189088493568\/S__WPhAS_normal.jpg",
      "id" : 1639811,
      "verified" : false
    }
  },
  "id" : 740940666054705152,
  "created_at" : "2016-06-09 16:16:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 73, 81 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/740939508892372992\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/EzgmU5YLoE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkhYjiBUgAA3ElZ.jpg",
      "id_str" : "740939506153455616",
      "id" : 740939506153455616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkhYjiBUgAA3ElZ.jpg",
      "sizes" : [ {
        "h" : 818,
        "resize" : "fit",
        "w" : 1189
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 818,
        "resize" : "fit",
        "w" : 1189
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 818,
        "resize" : "fit",
        "w" : 1189
      } ],
      "display_url" : "pic.twitter.com\/EzgmU5YLoE"
    } ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 66, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740939508892372992",
  "text" : "Experience the power of an open and collaborative platform at the #FoL16 @getgrav Course Hub studio today at 1:00pm. https:\/\/t.co\/EzgmU5YLoE",
  "id" : 740939508892372992,
  "created_at" : "2016-06-09 16:11:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 25, 33 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 18, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/fXOsasF8vt",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1T_275jM2Q892ZSbUOu0l0nGsccisNNwlMcA4_gytOGo\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1T_\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/735EDWHiDO",
      "expanded_url" : "http:\/\/demo.hibbittsdesign.org",
      "display_url" : "demo.hibbittsdesign.org"
    } ]
  },
  "geo" : { },
  "id_str" : "740702945130516483",
  "text" : "What to expect at #FoL16 @getgrav Course Hub studio Thursday?\nGrav + GitHub:\nhttps:\/\/t.co\/fXOsasF8vt\nLive demo site:\nhttps:\/\/t.co\/735EDWHiDO",
  "id" : 740702945130516483,
  "created_at" : "2016-06-09 00:31:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liesel Knaack",
      "screen_name" : "LieselKnaack",
      "indices" : [ 0, 13 ],
      "id_str" : "1541499920",
      "id" : 1541499920
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 14, 22 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740690058244558848",
  "geo" : { },
  "id_str" : "740690636328800257",
  "in_reply_to_user_id" : 1541499920,
  "text" : "@LieselKnaack @getgrav It was my pleasure Liesel, thanks for the invite! The Maker Faire format was awesome \uD83D\uDC4D",
  "id" : 740690636328800257,
  "in_reply_to_status_id" : 740690058244558848,
  "created_at" : "2016-06-08 23:43:03 +0000",
  "in_reply_to_screen_name" : "LieselKnaack",
  "in_reply_to_user_id_str" : "1541499920",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 26, 35 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 66, 79 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/Gh8mH371so",
      "expanded_url" : "https:\/\/twitter.com\/clintlalonde\/status\/740666754142076928",
      "display_url" : "twitter.com\/clintlalonde\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740674009822531587",
  "text" : "The open textbook work of @bccampus in general, and in particular @clintlalonde (right back at ya). https:\/\/t.co\/Gh8mH371so",
  "id" : 740674009822531587,
  "created_at" : "2016-06-08 22:36:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/QHub47tOlT",
      "expanded_url" : "https:\/\/twitter.com\/SFUteachlearn\/status\/740661491112628224",
      "display_url" : "twitter.com\/SFUteachlearn\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740662367604727808",
  "text" : "What a great session! https:\/\/t.co\/QHub47tOlT",
  "id" : 740662367604727808,
  "created_at" : "2016-06-08 21:50:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 103, 111 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740660929755381760",
  "text" : "Great to be a part of #FoL16 today! Heading back to the mothership to put the finishing touches on the @getgrav Course Hub studio tomorrow.",
  "id" : 740660929755381760,
  "created_at" : "2016-06-08 21:45:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Gill",
      "screen_name" : "trent_g",
      "indices" : [ 0, 8 ],
      "id_str" : "19269876",
      "id" : 19269876
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 66, 74 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740608383510683648",
  "geo" : { },
  "id_str" : "740629065426604032",
  "in_reply_to_user_id" : 19269876,
  "text" : "@trent_g Let me know if you'd like to connect and chat more about @getgrav",
  "id" : 740629065426604032,
  "in_reply_to_status_id" : 740608383510683648,
  "created_at" : "2016-06-08 19:38:24 +0000",
  "in_reply_to_screen_name" : "trent_g",
  "in_reply_to_user_id_str" : "19269876",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 59, 67 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 79, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/DG04W50tZ3",
      "expanded_url" : "http:\/\/sched.co\/6roD",
      "display_url" : "sched.co\/6roD"
    } ]
  },
  "geo" : { },
  "id_str" : "740561854670327813",
  "text" : "Learn about and explore the modern flat-file (no database) @getgrav CMS at the #FoL16 Maker Faire this morning. https:\/\/t.co\/DG04W50tZ3 \uD83D\uDE80",
  "id" : 740561854670327813,
  "created_at" : "2016-06-08 15:11:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Mott",
      "screen_name" : "jonmott",
      "indices" : [ 3, 11 ],
      "id_str" : "14921170",
      "id" : 14921170
    }, {
      "name" : "IMS Global Learning",
      "screen_name" : "LearningImpact",
      "indices" : [ 78, 93 ],
      "id_str" : "146316919",
      "id" : 146316919
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "standardsmatter",
      "indices" : [ 61, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/PJ86aoDKDI",
      "expanded_url" : "https:\/\/twitter.com\/sashatberr\/status\/740283935578423298",
      "display_url" : "twitter.com\/sashatberr\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740545076871467008",
  "text" : "RT @jonmott: Time for a friction-less learning ecosystem ... #standardsmatter @LearningImpact https:\/\/t.co\/PJ86aoDKDI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IMS Global Learning",
        "screen_name" : "LearningImpact",
        "indices" : [ 65, 80 ],
        "id_str" : "146316919",
        "id" : 146316919
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "standardsmatter",
        "indices" : [ 48, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/PJ86aoDKDI",
        "expanded_url" : "https:\/\/twitter.com\/sashatberr\/status\/740283935578423298",
        "display_url" : "twitter.com\/sashatberr\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740419368421588996",
    "text" : "Time for a friction-less learning ecosystem ... #standardsmatter @LearningImpact https:\/\/t.co\/PJ86aoDKDI",
    "id" : 740419368421588996,
    "created_at" : "2016-06-08 05:45:08 +0000",
    "user" : {
      "name" : "Jon Mott",
      "screen_name" : "jonmott",
      "protected" : false,
      "id_str" : "14921170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723942320391868416\/peNbfSS6_normal.jpg",
      "id" : 14921170,
      "verified" : false
    }
  },
  "id" : 740545076871467008,
  "created_at" : "2016-06-08 14:04:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 70, 78 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/740381946543382528\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/V0UpTtluM4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkZddEEVEAA49lc.jpg",
      "id_str" : "740381942638514176",
      "id" : 740381942638514176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkZddEEVEAA49lc.jpg",
      "sizes" : [ {
        "h" : 368,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 716
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 716
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 716
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/V0UpTtluM4"
    } ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 29, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740381946543382528",
  "text" : "The downside is I am missing #FoL16 Pub Night, but upside is a bit of @getgrav signage for tomorrow's Maker Faire... https:\/\/t.co\/V0UpTtluM4",
  "id" : 740381946543382528,
  "created_at" : "2016-06-08 03:16:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Blickensderfer",
      "screen_name" : "Dan_Blick",
      "indices" : [ 3, 13 ],
      "id_str" : "188554158",
      "id" : 188554158
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 16, 23 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Data Carpentry",
      "screen_name" : "datacarpentry",
      "indices" : [ 117, 131 ],
      "id_str" : "2493407430",
      "id" : 2493407430
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 27, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/IYWv7aUf8M",
      "expanded_url" : "https:\/\/github.com\/datacarpentry\/semester-biology",
      "display_url" : "github.com\/datacarpentry\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740348000652787712",
  "text" : "RT @Dan_Blick: .@github is #OER TROVE! Ex: \"forkable set of materials for teaching biologists how to work with data\" @datacarpentry https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 1, 8 ],
        "id_str" : "13334762",
        "id" : 13334762
      }, {
        "name" : "Data Carpentry",
        "screen_name" : "datacarpentry",
        "indices" : [ 102, 116 ],
        "id_str" : "2493407430",
        "id" : 2493407430
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OER",
        "indices" : [ 12, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/IYWv7aUf8M",
        "expanded_url" : "https:\/\/github.com\/datacarpentry\/semester-biology",
        "display_url" : "github.com\/datacarpentry\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740341731225415682",
    "text" : ".@github is #OER TROVE! Ex: \"forkable set of materials for teaching biologists how to work with data\" @datacarpentry https:\/\/t.co\/IYWv7aUf8M",
    "id" : 740341731225415682,
    "created_at" : "2016-06-08 00:36:38 +0000",
    "user" : {
      "name" : "Dan Blickensderfer",
      "screen_name" : "Dan_Blick",
      "protected" : false,
      "id_str" : "188554158",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000638002183\/e6388b44edcc11c2dc7d525139192b23_normal.jpeg",
      "id" : 188554158,
      "verified" : false
    }
  },
  "id" : 740348000652787712,
  "created_at" : "2016-06-08 01:01:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 37, 45 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 18, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/itVjf6ywF4",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1FIA1jXwjGkiEjvHte8CExrGGh8IuiuDoaNcEPeOuRog\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1FI\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ipxyS1LKnY",
      "expanded_url" : "http:\/\/paulhibbitts.net\/grav\/demo-site\/",
      "display_url" : "paulhibbitts.net\/grav\/demo-site\/"
    } ]
  },
  "geo" : { },
  "id_str" : "740321127017242628",
  "text" : "What to expect at #FoL16 Maker Faire @getgrav table tomorrow?\nStep-by-step guide: https:\/\/t.co\/itVjf6ywF4\nDemo site: https:\/\/t.co\/ipxyS1LKnY",
  "id" : 740321127017242628,
  "created_at" : "2016-06-07 23:14:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/kUCdSKCGvN",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-10-20-my-dream-workflow",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "740319534985269249",
  "geo" : { },
  "id_str" : "740320910033309696",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Happy to do so anytime! This post would give you an idea of what the general workflow looks like: https:\/\/t.co\/kUCdSKCGvN",
  "id" : 740320910033309696,
  "in_reply_to_status_id" : 740319534985269249,
  "created_at" : "2016-06-07 23:13:54 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740285801519448065",
  "geo" : { },
  "id_str" : "740291719233572868",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco And that is with full version control \uD83D\uDE09",
  "id" : 740291719233572868,
  "in_reply_to_status_id" : 740285801519448065,
  "created_at" : "2016-06-07 21:17:54 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740285801519448065",
  "geo" : { },
  "id_str" : "740291614870929409",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Sometime I could demo to you the workflow possible with a flat-file CMS... for example content updates to a Webserver ~ 30 secs.",
  "id" : 740291614870929409,
  "in_reply_to_status_id" : 740285801519448065,
  "created_at" : "2016-06-07 21:17:29 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 99, 107 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740263972289400833",
  "text" : "Only have a tablet or Chromebook? No problem! There will be a cloud-only option for you to explore @getgrav at the Maker Faire too. #FoL16",
  "id" : 740263972289400833,
  "created_at" : "2016-06-07 19:27:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 83, 91 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/740263902106116096\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jbZQuJaJZQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkXyF8HUgAE4QE2.jpg",
      "id_str" : "740263897622413313",
      "id" : 740263897622413313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkXyF8HUgAE4QE2.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2304,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/jbZQuJaJZQ"
    } ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740263902106116096",
  "text" : "Attending Maker Faire tomorrow? These little gems will be there for you to try out @getgrav on your notebook! #FoL16 https:\/\/t.co\/jbZQuJaJZQ",
  "id" : 740263902106116096,
  "created_at" : "2016-06-07 19:27:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "indices" : [ 3, 17 ],
      "id_str" : "153597392",
      "id" : 153597392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740251989422964736",
  "text" : "RT @SFUteachlearn: #FoL16 Don't always explain everything to students. Experiencing frustration and pushing through it is part of the learn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740234750170796039",
    "text" : "#FoL16 Don't always explain everything to students. Experiencing frustration and pushing through it is part of the learning experience.",
    "id" : 740234750170796039,
    "created_at" : "2016-06-07 17:31:31 +0000",
    "user" : {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "protected" : false,
      "id_str" : "153597392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1011990133\/twitter_badge_teach_learn2_normal.jpg",
      "id" : 153597392,
      "verified" : false
    }
  },
  "id" : 740251989422964736,
  "created_at" : "2016-06-07 18:40:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 87, 95 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/YmfT7hUNOQ",
      "expanded_url" : "https:\/\/twitter.com\/pedagome\/status\/740242988190838789",
      "display_url" : "twitter.com\/pedagome\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740244652507299840",
  "text" : "A great article for anyone interested in the built-in GitHub\/GitLab integration of the @getgrav Course Hub. #GravEdu https:\/\/t.co\/YmfT7hUNOQ",
  "id" : 740244652507299840,
  "created_at" : "2016-06-07 18:10:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Lane",
      "screen_name" : "lightweight",
      "indices" : [ 0, 12 ],
      "id_str" : "10454472",
      "id" : 10454472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739953429649334272",
  "geo" : { },
  "id_str" : "739953705437396992",
  "in_reply_to_user_id" : 10454472,
  "text" : "@lightweight As an individual instructor with moderate tech skills, I've been able to do more in terms of openness and collaboration non-DB.",
  "id" : 739953705437396992,
  "in_reply_to_status_id" : 739953429649334272,
  "created_at" : "2016-06-06 22:54:45 +0000",
  "in_reply_to_screen_name" : "lightweight",
  "in_reply_to_user_id_str" : "10454472",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Lane",
      "screen_name" : "lightweight",
      "indices" : [ 0, 12 ],
      "id_str" : "10454472",
      "id" : 10454472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739952743234699265",
  "geo" : { },
  "id_str" : "739953207103750146",
  "in_reply_to_user_id" : 10454472,
  "text" : "@lightweight You are right, but I find a non-DB approach can give more options for collaboration. Nothing is a silver bullet though \uD83D\uDE42",
  "id" : 739953207103750146,
  "in_reply_to_status_id" : 739952743234699265,
  "created_at" : "2016-06-06 22:52:46 +0000",
  "in_reply_to_screen_name" : "lightweight",
  "in_reply_to_user_id_str" : "10454472",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Lane",
      "screen_name" : "lightweight",
      "indices" : [ 0, 12 ],
      "id_str" : "10454472",
      "id" : 10454472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "739947464266915840",
  "geo" : { },
  "id_str" : "739952334659194880",
  "in_reply_to_user_id" : 10454472,
  "text" : "@lightweight Quite a bit for me. Once content is stored as indiv. files (vs. database) a whole ecosystem for collab is possible (eg GitHub).",
  "id" : 739952334659194880,
  "in_reply_to_status_id" : 739947464266915840,
  "created_at" : "2016-06-06 22:49:18 +0000",
  "in_reply_to_screen_name" : "lightweight",
  "in_reply_to_user_id_str" : "10454472",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Becker",
      "screen_name" : "genebecker",
      "indices" : [ 3, 14 ],
      "id_str" : "8293402",
      "id" : 8293402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/A96tW3dA7l",
      "expanded_url" : "http:\/\/j.mp\/1UuUTAN",
      "display_url" : "j.mp\/1UuUTAN"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/G4AshAEhgv",
      "expanded_url" : "http:\/\/j.mp\/1UuUyhn",
      "display_url" : "j.mp\/1UuUyhn"
    } ]
  },
  "geo" : { },
  "id_str" : "739940102214942721",
  "text" : "RT @genebecker: Decentralized Web Summit https:\/\/t.co\/A96tW3dA7l Background: Locking the Web Open: A Call for a Distributed Web https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/A96tW3dA7l",
        "expanded_url" : "http:\/\/j.mp\/1UuUTAN",
        "display_url" : "j.mp\/1UuUTAN"
      }, {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/G4AshAEhgv",
        "expanded_url" : "http:\/\/j.mp\/1UuUyhn",
        "display_url" : "j.mp\/1UuUyhn"
      } ]
    },
    "geo" : { },
    "id_str" : "739936177763930113",
    "text" : "Decentralized Web Summit https:\/\/t.co\/A96tW3dA7l Background: Locking the Web Open: A Call for a Distributed Web https:\/\/t.co\/G4AshAEhgv",
    "id" : 739936177763930113,
    "created_at" : "2016-06-06 21:45:06 +0000",
    "user" : {
      "name" : "Gene Becker",
      "screen_name" : "genebecker",
      "protected" : false,
      "id_str" : "8293402",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2821465967\/5ca1432df922c457e14c01de4239e3f5_normal.jpeg",
      "id" : 8293402,
      "verified" : false
    }
  },
  "id" : 739940102214942721,
  "created_at" : "2016-06-06 22:00:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 17, 25 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 38, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739928960780247041",
  "text" : "Preparing for my @getgrav sessions at #FoL16 I just experienced how easy it is to create TWO blogs in one Grav site... &lt;10 seconds. Mic drop",
  "id" : 739928960780247041,
  "created_at" : "2016-06-06 21:16:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739916227657662465",
  "text" : "WordPress still has its charms, esp. institution-wide, but the new generation of no database CMSs can be more open and collaborative. #FoL16",
  "id" : 739916227657662465,
  "created_at" : "2016-06-06 20:25:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 94, 102 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 128, 137 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 20, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/DG04W50tZ3",
      "expanded_url" : "http:\/\/sched.co\/6roD",
      "display_url" : "sched.co\/6roD"
    } ]
  },
  "geo" : { },
  "id_str" : "739913049432150020",
  "text" : "I'll be part of the #FoL16 \"Educational Technology Maker Faire\". Let's nerd out together with @getgrav! https:\/\/t.co\/DG04W50tZ3 @bccampus \uD83D\uDE80",
  "id" : 739913049432150020,
  "created_at" : "2016-06-06 20:13:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 3, 16 ],
      "id_str" : "91939908",
      "id" : 91939908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FofL16",
      "indices" : [ 37, 44 ]
    }, {
      "text" : "opened",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/23Wa2plKN7",
      "expanded_url" : "http:\/\/sched.co\/69dV",
      "display_url" : "sched.co\/69dV"
    }, {
      "indices" : [ 123, 140 ],
      "url" : "https:\/\/t.co\/7W5TkzyMRT",
      "expanded_url" : "http:\/\/watchtheedge.ca\/2016\/06\/06\/oermakerspace\/",
      "display_url" : "watchtheedge.ca\/2016\/06\/06\/oer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739909609842843648",
  "text" : "RT @davidnwright: ICYMI: Tomorrow at #FofL16, Join me for The Classroom as OER Makerspace https:\/\/t.co\/23Wa2plKN7 Preview: https:\/\/t.co\/7W5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FofL16",
        "indices" : [ 19, 26 ]
      }, {
        "text" : "opened",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/23Wa2plKN7",
        "expanded_url" : "http:\/\/sched.co\/69dV",
        "display_url" : "sched.co\/69dV"
      }, {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/7W5TkzyMRT",
        "expanded_url" : "http:\/\/watchtheedge.ca\/2016\/06\/06\/oermakerspace\/",
        "display_url" : "watchtheedge.ca\/2016\/06\/06\/oer\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "739909398202441729",
    "text" : "ICYMI: Tomorrow at #FofL16, Join me for The Classroom as OER Makerspace https:\/\/t.co\/23Wa2plKN7 Preview: https:\/\/t.co\/7W5TkzyMRT #opened",
    "id" : 739909398202441729,
    "created_at" : "2016-06-06 19:58:42 +0000",
    "user" : {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "protected" : false,
      "id_str" : "91939908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000388128638\/0a05619f6295cf44230a317aea475ef1_normal.jpeg",
      "id" : 91939908,
      "verified" : false
    }
  },
  "id" : 739909609842843648,
  "created_at" : "2016-06-06 19:59:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 3, 17 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 94, 100 ]
    }, {
      "text" : "OpenEdu",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/URUZUMsTyN",
      "expanded_url" : "http:\/\/flexible.learning.ubc.ca\/news-events\/renewable-assignments-student-work-adding-value-to-the-world\/?login",
      "display_url" : "flexible.learning.ubc.ca\/news-events\/re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739906339703427072",
  "text" : "RT @clhendricksbc: Here\u2019s another post on non-disposable assignments: https:\/\/t.co\/URUZUMsTyN #FoL16 #OpenEdu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 75, 81 ]
      }, {
        "text" : "OpenEdu",
        "indices" : [ 82, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/URUZUMsTyN",
        "expanded_url" : "http:\/\/flexible.learning.ubc.ca\/news-events\/renewable-assignments-student-work-adding-value-to-the-world\/?login",
        "display_url" : "flexible.learning.ubc.ca\/news-events\/re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "739857916287553536",
    "text" : "Here\u2019s another post on non-disposable assignments: https:\/\/t.co\/URUZUMsTyN #FoL16 #OpenEdu",
    "id" : 739857916287553536,
    "created_at" : "2016-06-06 16:34:07 +0000",
    "user" : {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "protected" : false,
      "id_str" : "260919324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726838525086208000\/46wx7Jih_normal.jpg",
      "id" : 260919324,
      "verified" : false
    }
  },
  "id" : 739906339703427072,
  "created_at" : "2016-06-06 19:46:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 8, 16 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 47, 59 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    }, {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "indices" : [ 82, 96 ],
      "id_str" : "3296136369",
      "id" : 3296136369
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/735EDWYTvm",
      "expanded_url" : "http:\/\/demo.hibbittsdesign.org",
      "display_url" : "demo.hibbittsdesign.org"
    } ]
  },
  "geo" : { },
  "id_str" : "739901304252727296",
  "text" : "A fresh @getgrav Course Hub demo site update:\n\u2713@SandstormIO for anonymous survey\n\u2713@RocketChatApp Livechat\nhttps:\/\/t.co\/735EDWYTvm #GravEdu",
  "id" : 739901304252727296,
  "created_at" : "2016-06-06 19:26:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitLab",
      "screen_name" : "gitlab",
      "indices" : [ 3, 10 ],
      "id_str" : "390167291",
      "id" : 390167291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/fd7ACtLNUL",
      "expanded_url" : "https:\/\/about.gitlab.com\/2016\/06\/06\/navigation-redesign\/",
      "display_url" : "about.gitlab.com\/2016\/06\/06\/nav\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739882009929994241",
  "text" : "RT @gitlab: Get excited for our new and improved UI. It's been 4 months in the making and we can't wait to see what you think https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/fd7ACtLNUL",
        "expanded_url" : "https:\/\/about.gitlab.com\/2016\/06\/06\/navigation-redesign\/",
        "display_url" : "about.gitlab.com\/2016\/06\/06\/nav\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "739880217020243968",
    "text" : "Get excited for our new and improved UI. It's been 4 months in the making and we can't wait to see what you think https:\/\/t.co\/fd7ACtLNUL",
    "id" : 739880217020243968,
    "created_at" : "2016-06-06 18:02:44 +0000",
    "user" : {
      "name" : "GitLab",
      "screen_name" : "gitlab",
      "protected" : false,
      "id_str" : "390167291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757993008461742080\/9pAwHBR0_normal.jpg",
      "id" : 390167291,
      "verified" : false
    }
  },
  "id" : 739882009929994241,
  "created_at" : "2016-06-06 18:09:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 126, 132 ]
    }, {
      "text" : "bcpse",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/s3RxrRRdl7",
      "expanded_url" : "http:\/\/bit.ly\/25HQ3bp",
      "display_url" : "bit.ly\/25HQ3bp"
    } ]
  },
  "geo" : { },
  "id_str" : "739878600497725441",
  "text" : "RT @clintlalonde: Privacy Guidelines for BC post-secondary faculty using 3rd party web services (PDF) https:\/\/t.co\/s3RxrRRdl7 #FoL16 #bcpse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 108, 114 ]
      }, {
        "text" : "bcpse",
        "indices" : [ 115, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/s3RxrRRdl7",
        "expanded_url" : "http:\/\/bit.ly\/25HQ3bp",
        "display_url" : "bit.ly\/25HQ3bp"
      } ]
    },
    "geo" : { },
    "id_str" : "739868609225183232",
    "text" : "Privacy Guidelines for BC post-secondary faculty using 3rd party web services (PDF) https:\/\/t.co\/s3RxrRRdl7 #FoL16 #bcpse",
    "id" : 739868609225183232,
    "created_at" : "2016-06-06 17:16:37 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 739878600497725441,
  "created_at" : "2016-06-06 17:56:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "indices" : [ 3, 14 ],
      "id_str" : "1983141",
      "id" : 1983141
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 23, 36 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739853369506828289",
  "text" : "RT @okalrelsrv: #FoL16 @clintlalonde \"Open web means open to everyone to use and contribute to\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Clint Lalonde",
        "screen_name" : "clintlalonde",
        "indices" : [ 7, 20 ],
        "id_str" : "12991032",
        "id" : 12991032
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739851026736414724",
    "text" : "#FoL16 @clintlalonde \"Open web means open to everyone to use and contribute to\"",
    "id" : 739851026736414724,
    "created_at" : "2016-06-06 16:06:45 +0000",
    "user" : {
      "name" : "Lynda Williams",
      "screen_name" : "okalrelsrv",
      "protected" : false,
      "id_str" : "1983141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739951680591040512\/HosITGfQ_normal.jpg",
      "id" : 1983141,
      "verified" : false
    }
  },
  "id" : 739853369506828289,
  "created_at" : "2016-06-06 16:16:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Squillace",
      "screen_name" : "bobsquill",
      "indices" : [ 3, 13 ],
      "id_str" : "246613933",
      "id" : 246613933
    }, {
      "name" : "Apereo Foundation",
      "screen_name" : "ApereoOrg",
      "indices" : [ 133, 140 ],
      "id_str" : "1117619618",
      "id" : 1117619618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/ikJztlvW0D",
      "expanded_url" : "http:\/\/ow.ly\/n5Kw300WorP",
      "display_url" : "ow.ly\/n5Kw300WorP"
    } ]
  },
  "geo" : { },
  "id_str" : "739589557927043072",
  "text" : "RT @bobsquill: My new post on Disaggravating the LMS: practical advice on teaching from a disaggregated LMS: https:\/\/t.co\/ikJztlvW0D @Apere\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Apereo Foundation",
        "screen_name" : "ApereoOrg",
        "indices" : [ 118, 128 ],
        "id_str" : "1117619618",
        "id" : 1117619618
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/ikJztlvW0D",
        "expanded_url" : "http:\/\/ow.ly\/n5Kw300WorP",
        "display_url" : "ow.ly\/n5Kw300WorP"
      } ]
    },
    "geo" : { },
    "id_str" : "739588880375160832",
    "text" : "My new post on Disaggravating the LMS: practical advice on teaching from a disaggregated LMS: https:\/\/t.co\/ikJztlvW0D @ApereoOrg",
    "id" : 739588880375160832,
    "created_at" : "2016-06-05 22:45:04 +0000",
    "user" : {
      "name" : "Robert Squillace",
      "screen_name" : "bobsquill",
      "protected" : false,
      "id_str" : "246613933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605379772764422146\/1c8YMKcF_normal.jpg",
      "id" : 246613933,
      "verified" : false
    }
  },
  "id" : 739589557927043072,
  "created_at" : "2016-06-05 22:47:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rajiv Jhangiani",
      "screen_name" : "thatpsychprof",
      "indices" : [ 3, 17 ],
      "id_str" : "39835900",
      "id" : 39835900
    }, {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 96, 110 ],
      "id_str" : "260919324",
      "id" : 260919324
    }, {
      "name" : "Colin Madland",
      "screen_name" : "colinmadland",
      "indices" : [ 111, 124 ],
      "id_str" : "81038069",
      "id" : 81038069
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 33, 37 ]
    }, {
      "text" : "FoL16",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/nnYuI57bIf",
      "expanded_url" : "http:\/\/sched.co\/6AIC",
      "display_url" : "sched.co\/6AIC"
    } ]
  },
  "geo" : { },
  "id_str" : "739567507602710528",
  "text" : "RT @thatpsychprof: Interested in #OER research in BC? Attend my session tomorrow afternoon with @clhendricksbc @colinmadland: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christina Hendricks",
        "screen_name" : "clhendricksbc",
        "indices" : [ 77, 91 ],
        "id_str" : "260919324",
        "id" : 260919324
      }, {
        "name" : "Colin Madland",
        "screen_name" : "colinmadland",
        "indices" : [ 92, 105 ],
        "id_str" : "81038069",
        "id" : 81038069
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OER",
        "indices" : [ 14, 18 ]
      }, {
        "text" : "FoL16",
        "indices" : [ 131, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/nnYuI57bIf",
        "expanded_url" : "http:\/\/sched.co\/6AIC",
        "display_url" : "sched.co\/6AIC"
      } ]
    },
    "geo" : { },
    "id_str" : "739507247353495552",
    "text" : "Interested in #OER research in BC? Attend my session tomorrow afternoon with @clhendricksbc @colinmadland: https:\/\/t.co\/nnYuI57bIf #FoL16",
    "id" : 739507247353495552,
    "created_at" : "2016-06-05 17:20:41 +0000",
    "user" : {
      "name" : "Rajiv Jhangiani",
      "screen_name" : "thatpsychprof",
      "protected" : false,
      "id_str" : "39835900",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677017328740122624\/zdAKRH0L_normal.jpg",
      "id" : 39835900,
      "verified" : false
    }
  },
  "id" : 739567507602710528,
  "created_at" : "2016-06-05 21:20:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/G3zKcNcC0m",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-06-03-moving-beyond-the-lms-with-grav-workshop-resources#twig-language-for-theme-development",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Z5GtQPP3O3",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/hibbitts-design-org-blog\/tree\/master\/posts",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739564840314798080",
  "text" : "(3\/3) View a blog post with this capability at https:\/\/t.co\/G3zKcNcC0m. You can even view\/download all blog posts at https:\/\/t.co\/Z5GtQPP3O3",
  "id" : 739564840314798080,
  "created_at" : "2016-06-05 21:09:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 12, 20 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/739564721368485890\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/uS6KtZGTpZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkN2MXjUoAEqgdU.jpg",
      "id_str" : "739564718671568897",
      "id" : 739564718671568897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkN2MXjUoAEqgdU.jpg",
      "sizes" : [ {
        "h" : 461,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/uS6KtZGTpZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739564721368485890",
  "text" : "(2\/3) Using @getgrav + GitHub (or an institutional GitLab server) to provide content file downloads or raw Markdown. https:\/\/t.co\/uS6KtZGTpZ",
  "id" : 739564721368485890,
  "created_at" : "2016-06-05 21:09:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 114, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739564648689602561",
  "text" : "(1\/3) To make Web content truly 'open' it should be available in a cross-platform data format. In preparation for #FoL16 I am exploring...",
  "id" : 739564648689602561,
  "created_at" : "2016-06-05 21:08:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caroline Jarrett",
      "screen_name" : "cjforms",
      "indices" : [ 3, 11 ],
      "id_str" : "144605504",
      "id" : 144605504
    }, {
      "name" : "Roo Reynolds",
      "screen_name" : "rooreynolds",
      "indices" : [ 114, 126 ],
      "id_str" : "787166",
      "id" : 787166
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "govdesign",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/XMGdQ8ZRDV",
      "expanded_url" : "http:\/\/bit.ly\/1WAU7s5",
      "display_url" : "bit.ly\/1WAU7s5"
    } ]
  },
  "geo" : { },
  "id_str" : "739483848442970112",
  "text" : "RT @cjforms: Nice overview of how UK govt is doing user-centred #govdesign with agile: https:\/\/t.co\/XMGdQ8ZRDV by @rooreynolds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Roo Reynolds",
        "screen_name" : "rooreynolds",
        "indices" : [ 101, 113 ],
        "id_str" : "787166",
        "id" : 787166
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "govdesign",
        "indices" : [ 51, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/XMGdQ8ZRDV",
        "expanded_url" : "http:\/\/bit.ly\/1WAU7s5",
        "display_url" : "bit.ly\/1WAU7s5"
      } ]
    },
    "geo" : { },
    "id_str" : "739479861971017728",
    "text" : "Nice overview of how UK govt is doing user-centred #govdesign with agile: https:\/\/t.co\/XMGdQ8ZRDV by @rooreynolds",
    "id" : 739479861971017728,
    "created_at" : "2016-06-05 15:31:52 +0000",
    "user" : {
      "name" : "Caroline Jarrett",
      "screen_name" : "cjforms",
      "protected" : false,
      "id_str" : "144605504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528613343381032960\/aFnqmqcK_normal.jpeg",
      "id" : 144605504,
      "verified" : false
    }
  },
  "id" : 739483848442970112,
  "created_at" : "2016-06-05 15:47:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Santee",
      "screen_name" : "amysantee",
      "indices" : [ 3, 13 ],
      "id_str" : "308151349",
      "id" : 308151349
    }, {
      "name" : "John Whalen",
      "screen_name" : "johnwhalen",
      "indices" : [ 22, 33 ],
      "id_str" : "14231482",
      "id" : 14231482
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/amysantee\/status\/738869169697886209\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/dbqtOCCreH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkD9lsLVAAAk-7u.jpg",
      "id_str" : "738869162844422144",
      "id" : 738869162844422144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkD9lsLVAAAk-7u.jpg",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 873
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 873
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 873
      }, {
        "h" : 379,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/dbqtOCCreH"
    } ],
    "hashtags" : [ {
      "text" : "uxpa2016",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738889329271934976",
  "text" : "RT @amysantee: Here's @johnwhalen's excellent four-step roadmap to getting organizational buy-in for UX #uxpa2016 https:\/\/t.co\/dbqtOCCreH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Whalen",
        "screen_name" : "johnwhalen",
        "indices" : [ 7, 18 ],
        "id_str" : "14231482",
        "id" : 14231482
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/amysantee\/status\/738869169697886209\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/dbqtOCCreH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkD9lsLVAAAk-7u.jpg",
        "id_str" : "738869162844422144",
        "id" : 738869162844422144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkD9lsLVAAAk-7u.jpg",
        "sizes" : [ {
          "h" : 487,
          "resize" : "fit",
          "w" : 873
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 873
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 873
        }, {
          "h" : 379,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/dbqtOCCreH"
      } ],
      "hashtags" : [ {
        "text" : "uxpa2016",
        "indices" : [ 89, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738869169697886209",
    "text" : "Here's @johnwhalen's excellent four-step roadmap to getting organizational buy-in for UX #uxpa2016 https:\/\/t.co\/dbqtOCCreH",
    "id" : 738869169697886209,
    "created_at" : "2016-06-03 23:05:12 +0000",
    "user" : {
      "name" : "Amy Santee",
      "screen_name" : "amysantee",
      "protected" : false,
      "id_str" : "308151349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743647290494091264\/HETMHSTK_normal.jpg",
      "id" : 308151349,
      "verified" : false
    }
  },
  "id" : 738889329271934976,
  "created_at" : "2016-06-04 00:25:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738796652400500740",
  "text" : "Supporting an open and collaborative platform is no silver bullet, but wow does it open up some amazing pedagogical opportunities.",
  "id" : 738796652400500740,
  "created_at" : "2016-06-03 18:17:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Irwin",
      "screen_name" : "sunnydeveloper",
      "indices" : [ 0, 15 ],
      "id_str" : "109086082",
      "id" : 109086082
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 16, 29 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738794436969123840",
  "geo" : { },
  "id_str" : "738795272575143936",
  "in_reply_to_user_id" : 109086082,
  "text" : "@sunnydeveloper @clintlalonde Grav makes it quite easy for both student and instructor (built-in option in my Course Hub package)",
  "id" : 738795272575143936,
  "in_reply_to_status_id" : 738794436969123840,
  "created_at" : "2016-06-03 18:11:33 +0000",
  "in_reply_to_screen_name" : "sunnydeveloper",
  "in_reply_to_user_id_str" : "109086082",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Irwin",
      "screen_name" : "sunnydeveloper",
      "indices" : [ 0, 15 ],
      "id_str" : "109086082",
      "id" : 109086082
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 16, 29 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738793642869952512",
  "geo" : { },
  "id_str" : "738794238201069568",
  "in_reply_to_user_id" : 109086082,
  "text" : "@sunnydeveloper @clintlalonde Oh I meant actually changing the online environment itself.",
  "id" : 738794238201069568,
  "in_reply_to_status_id" : 738793642869952512,
  "created_at" : "2016-06-03 18:07:27 +0000",
  "in_reply_to_screen_name" : "sunnydeveloper",
  "in_reply_to_user_id_str" : "109086082",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Irwin",
      "screen_name" : "sunnydeveloper",
      "indices" : [ 0, 15 ],
      "id_str" : "109086082",
      "id" : 109086082
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 16, 29 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738791160068476928",
  "geo" : { },
  "id_str" : "738793262815662080",
  "in_reply_to_user_id" : 109086082,
  "text" : "@sunnydeveloper @clintlalonde It also lets educators get help from other educators in overall site devel., unlike silo of WP, Moodle etc.",
  "id" : 738793262815662080,
  "in_reply_to_status_id" : 738791160068476928,
  "created_at" : "2016-06-03 18:03:34 +0000",
  "in_reply_to_screen_name" : "sunnydeveloper",
  "in_reply_to_user_id_str" : "109086082",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Irwin",
      "screen_name" : "sunnydeveloper",
      "indices" : [ 0, 15 ],
      "id_str" : "109086082",
      "id" : 109086082
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 16, 29 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738791160068476928",
  "geo" : { },
  "id_str" : "738792600245665792",
  "in_reply_to_user_id" : 109086082,
  "text" : "@sunnydeveloper @clintlalonde Yes, you've got it exactly \uD83D\uDC4D Not only just students, but also other educators can contribute too.",
  "id" : 738792600245665792,
  "in_reply_to_status_id" : 738791160068476928,
  "created_at" : "2016-06-03 18:00:56 +0000",
  "in_reply_to_screen_name" : "sunnydeveloper",
  "in_reply_to_user_id_str" : "109086082",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 3, 16 ],
      "id_str" : "91939908",
      "id" : 91939908
    }, {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 49, 58 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "Brenna Clarke Gray",
      "screen_name" : "brennacgray",
      "indices" : [ 110, 122 ],
      "id_str" : "14109848",
      "id" : 14109848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 59, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/QJm177Sam6",
      "expanded_url" : "http:\/\/sched.co\/6kfZ",
      "display_url" : "sched.co\/6kfZ"
    }, {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/vgtzw6IEsI",
      "expanded_url" : "https:\/\/github.com\/davidnwright\/borderlands\/wiki\/Plastic-Pedagogies-Session",
      "display_url" : "github.com\/davidnwright\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738784191991537667",
  "text" : "RT @davidnwright: Quick peek at what\u2019s in store  @BCcampus #FoL16 session https:\/\/t.co\/QJm177Sam6 w\/ me &amp; @brennacgray \/ rough work: https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BCcampus",
        "screen_name" : "BCcampus",
        "indices" : [ 31, 40 ],
        "id_str" : "93710949",
        "id" : 93710949
      }, {
        "name" : "Brenna Clarke Gray",
        "screen_name" : "brennacgray",
        "indices" : [ 92, 104 ],
        "id_str" : "14109848",
        "id" : 14109848
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 41, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/QJm177Sam6",
        "expanded_url" : "http:\/\/sched.co\/6kfZ",
        "display_url" : "sched.co\/6kfZ"
      }, {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/vgtzw6IEsI",
        "expanded_url" : "https:\/\/github.com\/davidnwright\/borderlands\/wiki\/Plastic-Pedagogies-Session",
        "display_url" : "github.com\/davidnwright\/b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738783740227248128",
    "text" : "Quick peek at what\u2019s in store  @BCcampus #FoL16 session https:\/\/t.co\/QJm177Sam6 w\/ me &amp; @brennacgray \/ rough work: https:\/\/t.co\/vgtzw6IEsI",
    "id" : 738783740227248128,
    "created_at" : "2016-06-03 17:25:44 +0000",
    "user" : {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "protected" : false,
      "id_str" : "91939908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000388128638\/0a05619f6295cf44230a317aea475ef1_normal.jpeg",
      "id" : 91939908,
      "verified" : false
    }
  },
  "id" : 738784191991537667,
  "created_at" : "2016-06-03 17:27:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 29, 37 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/xky1rbWLdt",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-07-using-grav-as-a-simple-open-publishing-tool",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738781353861222400",
  "text" : "An oldie but a goodie: Using @getgrav as a GitHub-powered Open Publishing Tool https:\/\/t.co\/xky1rbWLdt Similar to Grav Course Hub. #GravEdu",
  "id" : 738781353861222400,
  "created_at" : "2016-06-03 17:16:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738777227479785472",
  "text" : "Hmm... is the Grav Course Hub really an Open Course Hub?\n\u2713 Open source\n\u2713 Open content files (option)\n\u2713 Support for collab eg GitHub (option)",
  "id" : 738777227479785472,
  "created_at" : "2016-06-03 16:59:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/NHl8XDCJOT",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-06-03-moving-beyond-the-lms-with-grav-workshop-resources",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738772213864620034",
  "text" : "Sneak peek at my blog post: Moving Beyond the LMS with Grav Workshop Resources. Markdown, no database, oh my! https:\/\/t.co\/NHl8XDCJOT #FoL16",
  "id" : 738772213864620034,
  "created_at" : "2016-06-03 16:39:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/jT8ZfNRQlK",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=XUJIbxDuPpQ",
      "display_url" : "youtube.com\/watch?v=XUJIbx\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "738558239663525888",
  "geo" : { },
  "id_str" : "738559111806095360",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke Excellent, thanks so much! Here is my first attempt of a 10 minute over of my work with Grav so far... https:\/\/t.co\/jT8ZfNRQlK",
  "id" : 738559111806095360,
  "in_reply_to_status_id" : 738558239663525888,
  "created_at" : "2016-06-03 02:33:08 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 3, 15 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 17, 32 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738537986078314497",
  "text" : "RT @billymeinke: @hibbittsdesign \"Flip\" is already owned by the Flipped Edu peoples, and suggests that the learning paradigm is the same. I\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 0, 15 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "738455834603094016",
    "geo" : { },
    "id_str" : "738527318973419521",
    "in_reply_to_user_id" : 15949844,
    "text" : "@hibbittsdesign \"Flip\" is already owned by the Flipped Edu peoples, and suggests that the learning paradigm is the same. Ideas?",
    "id" : 738527318973419521,
    "in_reply_to_status_id" : 738455834603094016,
    "created_at" : "2016-06-03 00:26:48 +0000",
    "in_reply_to_screen_name" : "hibbittsdesign",
    "in_reply_to_user_id_str" : "15949844",
    "user" : {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "protected" : false,
      "id_str" : "296003222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723968088568270848\/2af0G-Xg_normal.jpg",
      "id" : 296003222,
      "verified" : false
    }
  },
  "id" : 738537986078314497,
  "created_at" : "2016-06-03 01:09:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 3, 15 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 17, 32 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738537971041730560",
  "text" : "RT @billymeinke: @hibbittsdesign I love the work you're doing with Grav, but TBH I think we can find a better word than \"Flip\". (1\/2)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 0, 15 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "738455834603094016",
    "geo" : { },
    "id_str" : "738527145765408769",
    "in_reply_to_user_id" : 15949844,
    "text" : "@hibbittsdesign I love the work you're doing with Grav, but TBH I think we can find a better word than \"Flip\". (1\/2)",
    "id" : 738527145765408769,
    "in_reply_to_status_id" : 738455834603094016,
    "created_at" : "2016-06-03 00:26:07 +0000",
    "in_reply_to_screen_name" : "hibbittsdesign",
    "in_reply_to_user_id_str" : "15949844",
    "user" : {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "protected" : false,
      "id_str" : "296003222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723968088568270848\/2af0G-Xg_normal.jpg",
      "id" : 296003222,
      "verified" : false
    }
  },
  "id" : 738537971041730560,
  "created_at" : "2016-06-03 01:09:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/jqQHqddup9",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-18-flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "738527318973419521",
  "geo" : { },
  "id_str" : "738537912908709888",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke Thanks for the feedback! Very open to ideas. The usage grew organically from my own experience: https:\/\/t.co\/jqQHqddup9",
  "id" : 738537912908709888,
  "in_reply_to_status_id" : 738527318973419521,
  "created_at" : "2016-06-03 01:08:54 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738505062230708224",
  "geo" : { },
  "id_str" : "738507461804490752",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro '...playing with the idea to use grav as an API consumer, created a small (and ugly) proof of concept...' check out Grav Gitter room",
  "id" : 738507461804490752,
  "in_reply_to_status_id" : 738505062230708224,
  "created_at" : "2016-06-02 23:07:54 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 3, 10 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tanbob\/status\/738440068369514496\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/QMzzn9LfQN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj93U3NUoAAEXHN.jpg",
      "id_str" : "738440064212967424",
      "id" : 738440064212967424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj93U3NUoAAEXHN.jpg",
      "sizes" : [ {
        "h" : 277,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 608
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 608
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 157,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QMzzn9LfQN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/LBMNBnfUuL",
      "expanded_url" : "https:\/\/homonym.wordpress.com\/2016\/06\/02\/considerations-for-ed-tech-and-innovation",
      "display_url" : "homonym.wordpress.com\/2016\/06\/02\/con\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738503957706772480",
  "text" : "RT @tanbob: Considerations for ed tech and\u00A0innovation https:\/\/t.co\/LBMNBnfUuL https:\/\/t.co\/QMzzn9LfQN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tanbob\/status\/738440068369514496\/photo\/1",
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/QMzzn9LfQN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj93U3NUoAAEXHN.jpg",
        "id_str" : "738440064212967424",
        "id" : 738440064212967424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj93U3NUoAAEXHN.jpg",
        "sizes" : [ {
          "h" : 277,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 608
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 608
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 157,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/QMzzn9LfQN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/LBMNBnfUuL",
        "expanded_url" : "https:\/\/homonym.wordpress.com\/2016\/06\/02\/considerations-for-ed-tech-and-innovation",
        "display_url" : "homonym.wordpress.com\/2016\/06\/02\/con\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738440068369514496",
    "text" : "Considerations for ed tech and\u00A0innovation https:\/\/t.co\/LBMNBnfUuL https:\/\/t.co\/QMzzn9LfQN",
    "id" : 738440068369514496,
    "created_at" : "2016-06-02 18:40:06 +0000",
    "user" : {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "protected" : false,
      "id_str" : "10817782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530559772\/twitterProfilePhoto_normal.jpg",
      "id" : 10817782,
      "verified" : false
    }
  },
  "id" : 738503957706772480,
  "created_at" : "2016-06-02 22:53:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/oYORYFUPCH",
      "expanded_url" : "https:\/\/github.com\/attiks\/poc-getgrav-rest-consumer",
      "display_url" : "github.com\/attiks\/poc-get\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738498663853363200",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Would this just release proof-of-concept be of help in your plans? https:\/\/t.co\/oYORYFUPCH",
  "id" : 738498663853363200,
  "created_at" : "2016-06-02 22:32:56 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Wright",
      "screen_name" : "larrywright",
      "indices" : [ 3, 15 ],
      "id_str" : "10286",
      "id" : 10286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738470443678502917",
  "text" : "RT @larrywright: \u201CYou need Flash to watch this video.\u201D\n\nNo, no I don\u2019t. Your website sucks, don\u2019t blame me for that.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735960611234951172",
    "text" : "\u201CYou need Flash to watch this video.\u201D\n\nNo, no I don\u2019t. Your website sucks, don\u2019t blame me for that.",
    "id" : 735960611234951172,
    "created_at" : "2016-05-26 22:27:37 +0000",
    "user" : {
      "name" : "Larry Wright",
      "screen_name" : "larrywright",
      "protected" : false,
      "id_str" : "10286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663570206913097728\/jQBM7Maw_normal.jpg",
      "id" : 10286,
      "verified" : false
    }
  },
  "id" : 738470443678502917,
  "created_at" : "2016-06-02 20:40:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738455834603094016",
  "text" : "Why Flip an LMS?\nTo support unmet pedagogical goals\nTo deliver a better student\/facilitator UX\nTo increase access, sharing and collaboration",
  "id" : 738455834603094016,
  "created_at" : "2016-06-02 19:42:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Rogers",
      "screen_name" : "cameron_rogers",
      "indices" : [ 3, 18 ],
      "id_str" : "50444125",
      "id" : 50444125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738197104770711554",
  "text" : "RT @cameron_rogers: Despite popular opinion, design is not about Sketch, style guides, or pushing pixels, it is the act of intentionally so\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738138813143257088",
    "text" : "Despite popular opinion, design is not about Sketch, style guides, or pushing pixels, it is the act of intentionally solving  problems.",
    "id" : 738138813143257088,
    "created_at" : "2016-06-01 22:43:01 +0000",
    "user" : {
      "name" : "Cameron Rogers",
      "screen_name" : "cameron_rogers",
      "protected" : false,
      "id_str" : "50444125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682332043317874689\/LEdc1Okp_normal.jpg",
      "id" : 50444125,
      "verified" : false
    }
  },
  "id" : 738197104770711554,
  "created_at" : "2016-06-02 02:34:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 13, 26 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "738186282589782016",
  "geo" : { },
  "id_str" : "738194334755868672",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @clintlalonde Another reason to flip your LMS with an open and collaborative platform \uD83D\uDE09",
  "id" : 738194334755868672,
  "in_reply_to_status_id" : 738186282589782016,
  "created_at" : "2016-06-02 02:23:39 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/lBk2zl2rSn",
      "expanded_url" : "https:\/\/getgrav.org\/blog\/grav-rc-1.1-available",
      "display_url" : "getgrav.org\/blog\/grav-rc-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738166403681812482",
  "text" : "RT @getgrav: Grav + Admin Plugin  1.1 Release Candidate 1 released! https:\/\/t.co\/lBk2zl2rSn - Please help us test it, so spread the word!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/lBk2zl2rSn",
        "expanded_url" : "https:\/\/getgrav.org\/blog\/grav-rc-1.1-available",
        "display_url" : "getgrav.org\/blog\/grav-rc-1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738165707251159041",
    "text" : "Grav + Admin Plugin  1.1 Release Candidate 1 released! https:\/\/t.co\/lBk2zl2rSn - Please help us test it, so spread the word!",
    "id" : 738165707251159041,
    "created_at" : "2016-06-02 00:29:53 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 738166403681812482,
  "created_at" : "2016-06-02 00:32:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/GZaywk2Yru",
      "expanded_url" : "https:\/\/moodleassociation.org\/members\/",
      "display_url" : "moodleassociation.org\/members\/"
    } ]
  },
  "geo" : { },
  "id_str" : "738151479064698881",
  "text" : "If you (or org) use open source you should contribute to it whenever you can. This brevity of this list is shameful: https:\/\/t.co\/GZaywk2Yru",
  "id" : 738151479064698881,
  "created_at" : "2016-06-01 23:33:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stacey",
      "screen_name" : "pgstacey",
      "indices" : [ 56, 65 ],
      "id_str" : "48018738",
      "id" : 48018738
    }, {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "indices" : [ 136, 144 ],
      "id_str" : "783092",
      "id" : 783092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738150484448411648",
  "text" : "I gained new insight of open source sustainability from @pgstacey's CC work &amp; Doc Searls '...make money because of open-source'. HT @benwerd",
  "id" : 738150484448411648,
  "created_at" : "2016-06-01 23:29:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 125, 131 ]
    }, {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/XkvASPOevV",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-05-31-grav-cms-materials-for-festival-of-learning-2016",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738135070783897604",
  "text" : "New Post: Grav CMS Materials for the 2016 Festival of Learning (which can help you 'flip' your LMS!) https:\/\/t.co\/XkvASPOevV #FoL16 #GravEdu",
  "id" : 738135070783897604,
  "created_at" : "2016-06-01 22:28:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738120064021336064",
  "text" : "In my case I considered sustainability before I actually started to develop my open source project - it was PART of my open source project.",
  "id" : 738120064021336064,
  "created_at" : "2016-06-01 21:28:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738119624290492416",
  "text" : "I think the issue of sustainability needs more love and attention with any talk of open source software, and also open education resources.",
  "id" : 738119624290492416,
  "created_at" : "2016-06-01 21:26:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738117965573324800",
  "text" : "While I've generated income from my open source Grav Course Hub project &lt;3 mo. post-launch I can see this will be an iterative process too.",
  "id" : 738117965573324800,
  "created_at" : "2016-06-01 21:20:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Smith",
      "screen_name" : "carologic",
      "indices" : [ 3, 13 ],
      "id_str" : "15616564",
      "id" : 15616564
    }, {
      "name" : "50\/50 Pledge",
      "screen_name" : "5050pledge",
      "indices" : [ 36, 47 ],
      "id_str" : "3241884668",
      "id" : 3241884668
    }, {
      "name" : "UXPA International",
      "screen_name" : "UXPA_Int",
      "indices" : [ 101, 110 ],
      "id_str" : "47451021",
      "id" : 47451021
    }, {
      "name" : "CallbackWomen",
      "screen_name" : "CallbackWomen",
      "indices" : [ 119, 133 ],
      "id_str" : "1138103090",
      "id" : 1138103090
    }, {
      "name" : "Women in UX",
      "screen_name" : "womenux",
      "indices" : [ 134, 140 ],
      "id_str" : "2511698239",
      "id" : 2511698239
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uxpa2016",
      "indices" : [ 15, 24 ]
    }, {
      "text" : "ux",
      "indices" : [ 111, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738066843974279168",
  "text" : "RT @carologic: #uxpa2016 busted the @5050pledge with 94 women\/65 men speaking. Congrats on 25 years! @UXPA_Int #ux cc\/ @CallbackWomen @wome\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "50\/50 Pledge",
        "screen_name" : "5050pledge",
        "indices" : [ 21, 32 ],
        "id_str" : "3241884668",
        "id" : 3241884668
      }, {
        "name" : "UXPA International",
        "screen_name" : "UXPA_Int",
        "indices" : [ 86, 95 ],
        "id_str" : "47451021",
        "id" : 47451021
      }, {
        "name" : "CallbackWomen",
        "screen_name" : "CallbackWomen",
        "indices" : [ 104, 118 ],
        "id_str" : "1138103090",
        "id" : 1138103090
      }, {
        "name" : "Women in UX",
        "screen_name" : "womenux",
        "indices" : [ 119, 127 ],
        "id_str" : "2511698239",
        "id" : 2511698239
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "uxpa2016",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "ux",
        "indices" : [ 96, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738059078337859584",
    "text" : "#uxpa2016 busted the @5050pledge with 94 women\/65 men speaking. Congrats on 25 years! @UXPA_Int #ux cc\/ @CallbackWomen @womenux",
    "id" : 738059078337859584,
    "created_at" : "2016-06-01 17:26:11 +0000",
    "user" : {
      "name" : "Carol Smith",
      "screen_name" : "carologic",
      "protected" : false,
      "id_str" : "15616564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659035329899290624\/ze1s6_0q_normal.jpg",
      "id" : 15616564,
      "verified" : false
    }
  },
  "id" : 738066843974279168,
  "created_at" : "2016-06-01 17:57:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]