Grailbird.data.tweets_2010_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitney Hess",
      "screen_name" : "whitneyhess",
      "indices" : [ 0, 12 ],
      "id_str" : "11963132",
      "id" : 11963132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8013291233",
  "in_reply_to_user_id" : 11963132,
  "text" : "@whitneyhess Here is a summary vs. details example from Fluid that might be of interest, with reference examples too http:\/\/bit.ly\/8JQj2e",
  "id" : 8013291233,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "whitneyhess",
  "in_reply_to_user_id_str" : "11963132",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Citrix GoToMeeting",
      "screen_name" : "GoToMeeting",
      "indices" : [ 21, 33 ],
      "id_str" : "50706891",
      "id" : 50706891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7925679022",
  "text" : "After 4 years of use @gotomeeting remains my recommended tool for live remote usability testing-easy install and fast screen refresh are key",
  "id" : 7925679022,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Travis",
      "screen_name" : "userfocus",
      "indices" : [ 92, 102 ],
      "id_str" : "16509110",
      "id" : 16509110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7949953248",
  "text" : "Myth-busting paper on usability studies and the Hawthorne Effect. http:\/\/bit.ly\/8K4LBz (via @userfocus)",
  "id" : 7949953248,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7685117015",
  "text" : "Bill Buxton interview on Natural User Interfaces http:\/\/bit.ly\/8RQq50, includes the quote \"Now that we can do anything, what should we do?\"",
  "id" : 7685117015,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7497733279",
  "text" : "Two of my favourite (and inspirational!) UX researchers, Bill Buxton and Jared Spool, interviewed by CBC Radio http:\/\/bit.ly\/7eyifo",
  "id" : 7497733279,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]