Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384806339735605248",
  "text" : "My recipe for keeping a course taught +10 times fresh? Re-design the course in the open, keep the course public &amp; let students rate classes.",
  "id" : 384806339735605248,
  "created_at" : "2013-09-30 22:25:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Coronado",
      "screen_name" : "jcoronado1",
      "indices" : [ 3, 14 ],
      "id_str" : "167479795",
      "id" : 167479795
    }, {
      "name" : "Cooper",
      "screen_name" : "cooper",
      "indices" : [ 130, 137 ],
      "id_str" : "17223242",
      "id" : 17223242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Visualize2013",
      "indices" : [ 87, 101 ]
    }, {
      "text" : "UX",
      "indices" : [ 102, 105 ]
    }, {
      "text" : "innovation",
      "indices" : [ 106, 117 ]
    }, {
      "text" : "leadership",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384781860460437504",
  "text" : "RT @jcoronado1: Competing in today's market means differentiating the user experience.\n#Visualize2013 #UX #innovation #leadership @cooper",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cooper",
        "screen_name" : "cooper",
        "indices" : [ 114, 121 ],
        "id_str" : "17223242",
        "id" : 17223242
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Visualize2013",
        "indices" : [ 71, 85 ]
      }, {
        "text" : "UX",
        "indices" : [ 86, 89 ]
      }, {
        "text" : "innovation",
        "indices" : [ 90, 101 ]
      }, {
        "text" : "leadership",
        "indices" : [ 102, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384771991561334784",
    "text" : "Competing in today's market means differentiating the user experience.\n#Visualize2013 #UX #innovation #leadership @cooper",
    "id" : 384771991561334784,
    "created_at" : "2013-09-30 20:09:26 +0000",
    "user" : {
      "name" : "Jose Coronado",
      "screen_name" : "jcoronado1",
      "protected" : false,
      "id_str" : "167479795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000417437431\/26f26bba117d7a5336d65137533b53de_normal.jpeg",
      "id" : 167479795,
      "verified" : false
    }
  },
  "id" : 384781860460437504,
  "created_at" : "2013-09-30 20:48:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382602791161569280",
  "text" : "Is there really still a case for using such terms as mlearning and elearning these days? Most distinctions seem like context guessing to me.",
  "id" : 382602791161569280,
  "created_at" : "2013-09-24 20:29:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "indices" : [ 3, 12 ],
      "id_str" : "18613",
      "id" : 18613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/dLoIGqxbaK",
      "expanded_url" : "http:\/\/www.theatlantic.com\/education\/archive\/2013\/09\/when-media-companies-try-to-become-education-companies\/279708",
      "display_url" : "theatlantic.com\/education\/arch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381902254820696064",
  "text" : "RT @gsiemens: \"When Media Companies Try to Become Education Companies\" http:\/\/t.co\/dLoIGqxbaK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/dLoIGqxbaK",
        "expanded_url" : "http:\/\/www.theatlantic.com\/education\/archive\/2013\/09\/when-media-companies-try-to-become-education-companies\/279708",
        "display_url" : "theatlantic.com\/education\/arch\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381896760924200960",
    "text" : "\"When Media Companies Try to Become Education Companies\" http:\/\/t.co\/dLoIGqxbaK",
    "id" : 381896760924200960,
    "created_at" : "2013-09-22 21:44:17 +0000",
    "user" : {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "protected" : false,
      "id_str" : "18613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451036825637761025\/7_0RawE8_normal.jpeg",
      "id" : 18613,
      "verified" : false
    }
  },
  "id" : 381902254820696064,
  "created_at" : "2013-09-22 22:06:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381193922178859008",
  "geo" : { },
  "id_str" : "381194185686007808",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Have you tried to clear your Browser cache, etc?",
  "id" : 381194185686007808,
  "in_reply_to_status_id" : 381193922178859008,
  "created_at" : "2013-09-20 23:12:30 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381192516587905025",
  "geo" : { },
  "id_str" : "381193371089268736",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde FF on Mac OS works fine for me",
  "id" : 381193371089268736,
  "in_reply_to_status_id" : 381192516587905025,
  "created_at" : "2013-09-20 23:09:16 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381190696230588416",
  "geo" : { },
  "id_str" : "381191524727279616",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Nope, all seems well from here",
  "id" : 381191524727279616,
  "in_reply_to_status_id" : 381190696230588416,
  "created_at" : "2013-09-20 23:01:56 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 99, 109 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cmpt363",
      "indices" : [ 49, 57 ]
    }, {
      "text" : "SFU",
      "indices" : [ 68, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/cFTWthKXYc",
      "expanded_url" : "https:\/\/slid.es\/explore",
      "display_url" : "slid.es\/explore"
    } ]
  },
  "geo" : { },
  "id_str" : "381182753619734528",
  "text" : "Humbled that \"The Process of IxD\" slides from my #cmpt363 course at #SFU are currently featured on @SlidesApp https:\/\/t.co\/cFTWthKXYc",
  "id" : 381182753619734528,
  "created_at" : "2013-09-20 22:27:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chelsea Huang",
      "screen_name" : "chelishness",
      "indices" : [ 0, 12 ],
      "id_str" : "611339062",
      "id" : 611339062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cmpt363",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379807891177222144",
  "geo" : { },
  "id_str" : "380007501984325633",
  "in_reply_to_user_id" : 611339062,
  "text" : "@chelishness Personas are intended to avoid the \"elastic\" user by incl. specifics of demographics, goals, and behaviours. #cmpt363",
  "id" : 380007501984325633,
  "in_reply_to_status_id" : 379807891177222144,
  "created_at" : "2013-09-17 16:37:03 +0000",
  "in_reply_to_screen_name" : "chelishness",
  "in_reply_to_user_id_str" : "611339062",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Yau",
      "screen_name" : "gkyaspera",
      "indices" : [ 0, 10 ],
      "id_str" : "113997842",
      "id" : 113997842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cmpt363",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379805622343970816",
  "geo" : { },
  "id_str" : "380005648294891520",
  "in_reply_to_user_id" : 113997842,
  "text" : "@gkyaspera A primary persona should represent the primary target audience of a product. Perhaps a combination of the two personas? #cmpt363",
  "id" : 380005648294891520,
  "in_reply_to_status_id" : 379805622343970816,
  "created_at" : "2013-09-17 16:29:41 +0000",
  "in_reply_to_screen_name" : "gkyaspera",
  "in_reply_to_user_id_str" : "113997842",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 3, 11 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "design",
      "indices" : [ 17, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/lnKj3HeYV7",
      "expanded_url" : "https:\/\/medium.com\/design-ux\/db0d974f0882",
      "display_url" : "medium.com\/design-ux\/db0d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379727192881913856",
  "text" : "RT @dmitryn: The #design community is the new Fox News https:\/\/t.co\/lnKj3HeYV7 - truth hurts.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "design",
        "indices" : [ 4, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/lnKj3HeYV7",
        "expanded_url" : "https:\/\/medium.com\/design-ux\/db0d974f0882",
        "display_url" : "medium.com\/design-ux\/db0d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379719225042300928",
    "text" : "The #design community is the new Fox News https:\/\/t.co\/lnKj3HeYV7 - truth hurts.",
    "id" : 379719225042300928,
    "created_at" : "2013-09-16 21:31:32 +0000",
    "user" : {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "protected" : false,
      "id_str" : "1550251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623216199791329280\/hoNAcmrW_normal.jpg",
      "id" : 1550251,
      "verified" : false
    }
  },
  "id" : 379727192881913856,
  "created_at" : "2013-09-16 22:03:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis Rosenfeld",
      "screen_name" : "louisrosenfeld",
      "indices" : [ 0, 15 ],
      "id_str" : "1760431",
      "id" : 1760431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379666339490983937",
  "geo" : { },
  "id_str" : "379685730815320064",
  "in_reply_to_user_id" : 1760431,
  "text" : "@louisrosenfeld Early 1990's I did a lot of HC dev, including Stack Enhancers. Right now I find WordPress + RWD Framework the closest thing!",
  "id" : 379685730815320064,
  "in_reply_to_status_id" : 379666339490983937,
  "created_at" : "2013-09-16 19:18:27 +0000",
  "in_reply_to_screen_name" : "louisrosenfeld",
  "in_reply_to_user_id_str" : "1760431",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 0, 12 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379656206979457024",
  "geo" : { },
  "id_str" : "379658621833187328",
  "in_reply_to_user_id" : 66913866,
  "text" : "@openroadies Please congratulate Dominik and that I say hello!",
  "id" : 379658621833187328,
  "in_reply_to_status_id" : 379656206979457024,
  "created_at" : "2013-09-16 17:30:43 +0000",
  "in_reply_to_screen_name" : "openroadies",
  "in_reply_to_user_id_str" : "66913866",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/CZLHk0Ezj3",
      "expanded_url" : "http:\/\/Wired.com",
      "display_url" : "Wired.com"
    }, {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/REslMgZkFm",
      "expanded_url" : "http:\/\/www.wired.com\/opinion\/2013\/09\/why-do-research-when-you-can-fail-fast-pivot-and-act-out-other-popular-startup-cliches\/",
      "display_url" : "wired.com\/opinion\/2013\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379649370020270080",
  "text" : "How the 'Failure' Culture of Startups Is Killing Innovation | Wired Opinion | http:\/\/t.co\/CZLHk0Ezj3 http:\/\/t.co\/REslMgZkFm",
  "id" : 379649370020270080,
  "created_at" : "2013-09-16 16:53:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Intercom",
      "screen_name" : "intercom",
      "indices" : [ 63, 72 ],
      "id_str" : "274788446",
      "id" : 274788446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/SDL7MafJ8Q",
      "expanded_url" : "http:\/\/shar.es\/iih2v",
      "display_url" : "shar.es\/iih2v"
    } ]
  },
  "geo" : { },
  "id_str" : "379327378356330496",
  "text" : "Why cards are the future of the web http:\/\/t.co\/SDL7MafJ8Q via @intercom",
  "id" : 379327378356330496,
  "created_at" : "2013-09-15 19:34:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Frost",
      "screen_name" : "brad_frost",
      "indices" : [ 0, 11 ],
      "id_str" : "11855482",
      "id" : 11855482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/DiYVqZijN0",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "378517964292513795",
  "geo" : { },
  "id_str" : "378539418010648576",
  "in_reply_to_user_id" : 11855482,
  "text" : "@brad_frost Not commercial, but I publicly re-envisioned the multi-device companion for my course http:\/\/t.co\/DiYVqZijN0 Loved the process!",
  "id" : 378539418010648576,
  "in_reply_to_status_id" : 378517964292513795,
  "created_at" : "2013-09-13 15:23:24 +0000",
  "in_reply_to_screen_name" : "brad_frost",
  "in_reply_to_user_id_str" : "11855482",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 48, 64 ],
      "id_str" : "17349291",
      "id" : 17349291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378304357596295169",
  "text" : "Really enjoyed talking about multi-device UX at @HabaneroConsult today. Great discussion, especially regarding design process challenges.",
  "id" : 378304357596295169,
  "created_at" : "2013-09-12 23:49:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    }, {
      "name" : "Horace Dediu",
      "screen_name" : "asymco",
      "indices" : [ 135, 142 ],
      "id_str" : "110520327",
      "id" : 110520327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/gjo6XxHCMO",
      "expanded_url" : "http:\/\/lnkd.in\/b8sG6nE",
      "display_url" : "lnkd.in\/b8sG6nE"
    } ]
  },
  "geo" : { },
  "id_str" : "378213818825854976",
  "text" : "RT @lukew: Multi-device design anyone? \n87% Of Connected Devices By 2017 Will Be Tablets &amp; Smartphones http:\/\/t.co\/gjo6XxHCMO\n\nht\/ @asymco",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Horace Dediu",
        "screen_name" : "asymco",
        "indices" : [ 124, 131 ],
        "id_str" : "110520327",
        "id" : 110520327
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/gjo6XxHCMO",
        "expanded_url" : "http:\/\/lnkd.in\/b8sG6nE",
        "display_url" : "lnkd.in\/b8sG6nE"
      } ]
    },
    "geo" : { },
    "id_str" : "378191949674840064",
    "text" : "Multi-device design anyone? \n87% Of Connected Devices By 2017 Will Be Tablets &amp; Smartphones http:\/\/t.co\/gjo6XxHCMO\n\nht\/ @asymco",
    "id" : 378191949674840064,
    "created_at" : "2013-09-12 16:22:41 +0000",
    "user" : {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "protected" : false,
      "id_str" : "13889622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477610446917103616\/_cjU3_ga_normal.png",
      "id" : 13889622,
      "verified" : false
    }
  },
  "id" : 378213818825854976,
  "created_at" : "2013-09-12 17:49:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Yau",
      "screen_name" : "gkyaspera",
      "indices" : [ 0, 10 ],
      "id_str" : "113997842",
      "id" : 113997842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cmpt363",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/L7IuLB6pvH",
      "expanded_url" : "http:\/\/cmpt-363-133.hibbittsdesign.com\/week-2-preparations\/",
      "display_url" : "cmpt-363-133.hibbittsdesign.com\/week-2-prepara\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "377964868130713600",
  "geo" : { },
  "id_str" : "377966792569663488",
  "in_reply_to_user_id" : 113997842,
  "text" : "@gkyaspera The first reading summary due for #cmpt363 is the article \"Personas: Dead yet?\" and can be accessed at http:\/\/t.co\/L7IuLB6pvH",
  "id" : 377966792569663488,
  "in_reply_to_status_id" : 377964868130713600,
  "created_at" : "2013-09-12 01:28:00 +0000",
  "in_reply_to_screen_name" : "gkyaspera",
  "in_reply_to_user_id_str" : "113997842",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 71, 87 ],
      "id_str" : "17349291",
      "id" : 17349291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/rEcLbho4qm",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/ca578766-e77b-3616-0d97-90026b671147\/",
      "display_url" : "workflowy.com\/shared\/ca57876\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377840115990933504",
  "text" : "Looking forward to discussing multi-device design experiences with the @HabaneroConsult UX team tomorrow! Topics: https:\/\/t.co\/rEcLbho4qm",
  "id" : 377840115990933504,
  "created_at" : "2013-09-11 17:04:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zoe Shakespeare ",
      "screen_name" : "ZShakespeare",
      "indices" : [ 0, 13 ],
      "id_str" : "2618423705",
      "id" : 2618423705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/p3oqQQ6n6X",
      "expanded_url" : "http:\/\/cmpt-363-133.hibbittsdesign.com\/project-description\/",
      "display_url" : "cmpt-363-133.hibbittsdesign.com\/project-descri\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "377827398550831104",
  "geo" : { },
  "id_str" : "377837548678447105",
  "in_reply_to_user_id" : 167111234,
  "text" : "@ZShakespeare That didn't take long! Fall project is a multi-device version of GoSFU http:\/\/t.co\/p3oqQQ6n6X Let's see when this arrives\u2026",
  "id" : 377837548678447105,
  "in_reply_to_status_id" : 377827398550831104,
  "created_at" : "2013-09-11 16:54:26 +0000",
  "in_reply_to_screen_name" : "BJOlaney",
  "in_reply_to_user_id_str" : "167111234",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/qabiUgtt8z",
      "expanded_url" : "http:\/\/www.apple.com\/",
      "display_url" : "apple.com"
    } ]
  },
  "geo" : { },
  "id_str" : "377530003514064897",
  "text" : "Trying out the new http:\/\/t.co\/qabiUgtt8z on a range of devices - not impressed w. speed and amount of physical effort required. Thoughts?",
  "id" : 377530003514064897,
  "created_at" : "2013-09-10 20:32:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Johanson",
      "screen_name" : "ParkaPal",
      "indices" : [ 0, 9 ],
      "id_str" : "20391380",
      "id" : 20391380
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cmpt363",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377270156524679168",
  "geo" : { },
  "id_str" : "377457012399144960",
  "in_reply_to_user_id" : 20391380,
  "text" : "@ParkaPal Later in the term we will also be looking at Nielsen's heuristics in addition to his five aspects of usability. #cmpt363",
  "id" : 377457012399144960,
  "in_reply_to_status_id" : 377270156524679168,
  "created_at" : "2013-09-10 15:42:19 +0000",
  "in_reply_to_screen_name" : "ParkaPal",
  "in_reply_to_user_id_str" : "20391380",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr.Revolver",
      "screen_name" : "misterrevolver",
      "indices" : [ 0, 15 ],
      "id_str" : "228668308",
      "id" : 228668308
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cmpt363",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377298243391995904",
  "geo" : { },
  "id_str" : "377456418137600002",
  "in_reply_to_user_id" : 228668308,
  "text" : "@misterrevolver Well put! #cmpt363",
  "id" : 377456418137600002,
  "in_reply_to_status_id" : 377298243391995904,
  "created_at" : "2013-09-10 15:39:57 +0000",
  "in_reply_to_screen_name" : "misterrevolver",
  "in_reply_to_user_id_str" : "228668308",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaughn Leung",
      "screen_name" : "ShaughnL24",
      "indices" : [ 0, 11 ],
      "id_str" : "1732803536",
      "id" : 1732803536
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cmpt363",
      "indices" : [ 133, 141 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377270067257307136",
  "geo" : { },
  "id_str" : "377455724710088705",
  "in_reply_to_user_id" : 1732803536,
  "text" : "@ShaughnL24 Good question - and the answer is both yes &amp; no. We'll be looking at the process of IxD, including Agile, next week. #cmpt363",
  "id" : 377455724710088705,
  "in_reply_to_status_id" : 377270067257307136,
  "created_at" : "2013-09-10 15:37:12 +0000",
  "in_reply_to_screen_name" : "ShaughnL24",
  "in_reply_to_user_id_str" : "1732803536",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobert McBob",
      "screen_name" : "BobertMcBob",
      "indices" : [ 0, 12 ],
      "id_str" : "47815024",
      "id" : 47815024
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cmpt363",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/Uafw1Jk7UA",
      "expanded_url" : "http:\/\/karelvredenburg.com\/home\/2013\/3\/23\/great-design-requires-skeuomorphic-and-flat-approaches.html",
      "display_url" : "karelvredenburg.com\/home\/2013\/3\/23\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "377254002280628224",
  "geo" : { },
  "id_str" : "377454507438776320",
  "in_reply_to_user_id" : 47815024,
  "text" : "@BobertMcBob In addition to my comments in class, here is a good article on skeuomorphism vs flat design http:\/\/t.co\/Uafw1Jk7UA #cmpt363",
  "id" : 377454507438776320,
  "in_reply_to_status_id" : 377254002280628224,
  "created_at" : "2013-09-10 15:32:21 +0000",
  "in_reply_to_screen_name" : "BobertMcBob",
  "in_reply_to_user_id_str" : "47815024",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377091296759787520",
  "text" : "We need to be our own Chief Learning Officers.",
  "id" : 377091296759787520,
  "created_at" : "2013-09-09 15:29:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 3, 19 ],
      "id_str" : "17349291",
      "id" : 17349291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Calgary",
      "indices" : [ 30, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Lz27N26ADx",
      "expanded_url" : "http:\/\/hbn.ro\/165ygNX",
      "display_url" : "hbn.ro\/165ygNX"
    } ]
  },
  "geo" : { },
  "id_str" : "376097975539216384",
  "text" : "MT @HabaneroConsult Iris, the #Calgary Board of Education member portal http:\/\/t.co\/Lz27N26ADx &lt;- Awesome example of learner-centered design",
  "id" : 376097975539216384,
  "created_at" : "2013-09-06 21:41:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SFU Vancouver",
      "screen_name" : "SFUVan",
      "indices" : [ 53, 60 ],
      "id_str" : "243778649",
      "id" : 243778649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "cmpt363",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376013001368694784",
  "text" : "#SFU students, the hashtag for my CMPT 363 course at @SFUVan is #cmpt363",
  "id" : 376013001368694784,
  "created_at" : "2013-09-06 16:04:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375753006056095744",
  "geo" : { },
  "id_str" : "375756648540684290",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Really appreciate the updates you have been providing. Hope that additional server\/data redundancy is available in the future.",
  "id" : 375756648540684290,
  "in_reply_to_status_id" : 375753006056095744,
  "created_at" : "2013-09-05 23:05:40 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/TCDV5QRPry",
      "expanded_url" : "http:\/\/www.logodesignlove.com\/next-logo",
      "display_url" : "logodesignlove.com\/next-logo"
    } ]
  },
  "geo" : { },
  "id_str" : "375686126029119488",
  "text" : "All this talk about logo design today makes me think of Paul Rand and his design of the NeXT logo http:\/\/t.co\/TCDV5QRPry Note SJ quote!",
  "id" : 375686126029119488,
  "created_at" : "2013-09-05 18:25:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gigaom",
      "screen_name" : "gigaom",
      "indices" : [ 3, 10 ],
      "id_str" : "2893971",
      "id" : 2893971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/RUrPY3OenF",
      "expanded_url" : "http:\/\/wp.me\/p10LZV-2SLR",
      "display_url" : "wp.me\/p10LZV-2SLR"
    } ]
  },
  "geo" : { },
  "id_str" : "375670955390951424",
  "text" : "MT @gigaom Google's strategy to take over computing continues: Chrome apps For your desktop http:\/\/t.co\/RUrPY3OenF  &lt;- Incl my fav Workflowy",
  "id" : 375670955390951424,
  "created_at" : "2013-09-05 17:25:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/375404711249080320\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/y0ez8WxCls",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTW0mI1CcAAj12Y.png",
      "id_str" : "375404711253274624",
      "id" : 375404711253274624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTW0mI1CcAAj12Y.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 203,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1226
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/y0ez8WxCls"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375404711249080320",
  "text" : "Instructor tip: Using Web materials in your classes? A start page add-on like Super Start or Speed Dial works great! http:\/\/t.co\/y0ez8WxCls",
  "id" : 375404711249080320,
  "created_at" : "2013-09-04 23:47:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375400980184961024",
  "text" : "The idea of a required textbook for a university course seems like a quaint and outdated approach to me these days.",
  "id" : 375400980184961024,
  "created_at" : "2013-09-04 23:32:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 3, 19 ],
      "id_str" : "17349291",
      "id" : 17349291
    }, {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 31, 46 ],
      "id_str" : "1122631",
      "id" : 1122631
    }, {
      "name" : "CBCEarlyEdition",
      "screen_name" : "CBCEarlyEdition",
      "indices" : [ 58, 74 ],
      "id_str" : "143058193",
      "id" : 143058193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "surrey",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/b0Hch8fR1r",
      "expanded_url" : "http:\/\/hbn.ro\/17A33TB",
      "display_url" : "hbn.ro\/17A33TB"
    } ]
  },
  "geo" : { },
  "id_str" : "375352627581554688",
  "text" : "RT @HabaneroConsult: Tomorrow, @MalloryOConnor will be on @CBCEarlyEdition talking about our SchoolLink app. Read the case study: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mallory O'Connor",
        "screen_name" : "MalloryOConnor",
        "indices" : [ 10, 25 ],
        "id_str" : "1122631",
        "id" : 1122631
      }, {
        "name" : "CBCEarlyEdition",
        "screen_name" : "CBCEarlyEdition",
        "indices" : [ 37, 53 ],
        "id_str" : "143058193",
        "id" : 143058193
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "surrey",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/b0Hch8fR1r",
        "expanded_url" : "http:\/\/hbn.ro\/17A33TB",
        "display_url" : "hbn.ro\/17A33TB"
      } ]
    },
    "geo" : { },
    "id_str" : "375351103048523776",
    "text" : "Tomorrow, @MalloryOConnor will be on @CBCEarlyEdition talking about our SchoolLink app. Read the case study: http:\/\/t.co\/b0Hch8fR1r #surrey",
    "id" : 375351103048523776,
    "created_at" : "2013-09-04 20:14:11 +0000",
    "user" : {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "protected" : false,
      "id_str" : "17349291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768212660244537344\/z_mWqOrE_normal.jpg",
      "id" : 17349291,
      "verified" : false
    }
  },
  "id" : 375352627581554688,
  "created_at" : "2013-09-04 20:20:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 3, 11 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ROI",
      "indices" : [ 20, 24 ]
    }, {
      "text" : "UX",
      "indices" : [ 28, 31 ]
    }, {
      "text" : "truth",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374931402690543617",
  "text" : "RT @dmitryn: OH re. #ROI of #UX: \"In 2013, there are plenty of competitors who [will use] UX to take away your business while you ponder RO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ROI",
        "indices" : [ 7, 11 ]
      }, {
        "text" : "UX",
        "indices" : [ 15, 18 ]
      }, {
        "text" : "truth",
        "indices" : [ 130, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374918743861624833",
    "text" : "OH re. #ROI of #UX: \"In 2013, there are plenty of competitors who [will use] UX to take away your business while you ponder ROI.\" #truth",
    "id" : 374918743861624833,
    "created_at" : "2013-09-03 15:36:08 +0000",
    "user" : {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "protected" : false,
      "id_str" : "1550251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623216199791329280\/hoNAcmrW_normal.jpg",
      "id" : 1550251,
      "verified" : false
    }
  },
  "id" : 374931402690543617,
  "created_at" : "2013-09-03 16:26:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 29, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374915306008756224",
  "text" : "Welcome to the Fall semester #SFU students! Looking forward to meeting my CMPT 363 class.",
  "id" : 374915306008756224,
  "created_at" : "2013-09-03 15:22:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]