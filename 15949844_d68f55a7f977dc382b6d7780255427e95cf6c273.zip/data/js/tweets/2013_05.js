Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 0, 5 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339109289669058560",
  "geo" : { },
  "id_str" : "340560451266027521",
  "in_reply_to_user_id" : 15949844,
  "text" : "@etug Thanks very much for the RT. Looking forward to next week!",
  "id" : 340560451266027521,
  "in_reply_to_status_id" : 339109289669058560,
  "created_at" : "2013-05-31 20:08:33 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PageLines",
      "screen_name" : "PageLines",
      "indices" : [ 0, 10 ],
      "id_str" : "50707841",
      "id" : 50707841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/DiYVqZijN0",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340281388530024448",
  "in_reply_to_user_id" : 50707841,
  "text" : "@PageLines Thanks PageLines! I've been able to prototype my new course companion in only two days. http:\/\/t.co\/DiYVqZijN0 Great support too!",
  "id" : 340281388530024448,
  "created_at" : "2013-05-31 01:39:39 +0000",
  "in_reply_to_screen_name" : "PageLines",
  "in_reply_to_user_id_str" : "50707841",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carter Gilchrist",
      "screen_name" : "cgilchrist",
      "indices" : [ 3, 14 ],
      "id_str" : "26156564",
      "id" : 26156564
    }, {
      "name" : "Unbounce",
      "screen_name" : "unbounce",
      "indices" : [ 79, 88 ],
      "id_str" : "65304372",
      "id" : 65304372
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "product",
      "indices" : [ 44, 52 ]
    }, {
      "text" : "ui",
      "indices" : [ 53, 56 ]
    }, {
      "text" : "designer",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "Vancouver",
      "indices" : [ 97, 107 ]
    }, {
      "text" : "ux",
      "indices" : [ 131, 134 ]
    }, {
      "text" : "jobs",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/5agwFizEcn",
      "expanded_url" : "http:\/\/buff.ly\/16tTSGa",
      "display_url" : "buff.ly\/16tTSGa"
    } ]
  },
  "geo" : { },
  "id_str" : "340250569954439169",
  "text" : "RT @cgilchrist: We're hiring an experienced #product #ui #designer to join the @Unbounce team in #Vancouver http:\/\/t.co\/5agwFizEcn #ux #job\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Unbounce",
        "screen_name" : "unbounce",
        "indices" : [ 63, 72 ],
        "id_str" : "65304372",
        "id" : 65304372
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "product",
        "indices" : [ 28, 36 ]
      }, {
        "text" : "ui",
        "indices" : [ 37, 40 ]
      }, {
        "text" : "designer",
        "indices" : [ 41, 50 ]
      }, {
        "text" : "Vancouver",
        "indices" : [ 81, 91 ]
      }, {
        "text" : "ux",
        "indices" : [ 115, 118 ]
      }, {
        "text" : "jobs",
        "indices" : [ 119, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/5agwFizEcn",
        "expanded_url" : "http:\/\/buff.ly\/16tTSGa",
        "display_url" : "buff.ly\/16tTSGa"
      } ]
    },
    "geo" : { },
    "id_str" : "340249789033766913",
    "text" : "We're hiring an experienced #product #ui #designer to join the @Unbounce team in #Vancouver http:\/\/t.co\/5agwFizEcn #ux #jobs Would love a RT",
    "id" : 340249789033766913,
    "created_at" : "2013-05-30 23:34:05 +0000",
    "user" : {
      "name" : "Carter Gilchrist",
      "screen_name" : "cgilchrist",
      "protected" : false,
      "id_str" : "26156564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707090564152303617\/zQE_-CzV_normal.jpg",
      "id" : 26156564,
      "verified" : false
    }
  },
  "id" : 340250569954439169,
  "created_at" : "2013-05-30 23:37:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 90, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/DiYVqZijN0",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340205882761678849",
  "text" : "First prototype for a multi-device + thumb friendly course companion my Fall UI course at #SFU Computing Science http:\/\/t.co\/DiYVqZijN0",
  "id" : 340205882761678849,
  "created_at" : "2013-05-30 20:39:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tero Parviainen",
      "screen_name" : "teropa",
      "indices" : [ 3, 10 ],
      "id_str" : "14157530",
      "id" : 14157530
    }, {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 121, 127 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/MIAQ67BPBU",
      "expanded_url" : "http:\/\/buff.ly\/13Y8euW",
      "display_url" : "buff.ly\/13Y8euW"
    } ]
  },
  "geo" : { },
  "id_str" : "339804062902005761",
  "text" : "RT @teropa: Designing for Thumb Flow - that's 75% of people's interactions with a smartphone. http:\/\/t.co\/MIAQ67BPBU via @lukew",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Luke Wroblewski",
        "screen_name" : "lukew",
        "indices" : [ 109, 115 ],
        "id_str" : "13889622",
        "id" : 13889622
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/MIAQ67BPBU",
        "expanded_url" : "http:\/\/buff.ly\/13Y8euW",
        "display_url" : "buff.ly\/13Y8euW"
      } ]
    },
    "geo" : { },
    "id_str" : "339794549771751424",
    "text" : "Designing for Thumb Flow - that's 75% of people's interactions with a smartphone. http:\/\/t.co\/MIAQ67BPBU via @lukew",
    "id" : 339794549771751424,
    "created_at" : "2013-05-29 17:25:08 +0000",
    "user" : {
      "name" : "Tero Parviainen",
      "screen_name" : "teropa",
      "protected" : false,
      "id_str" : "14157530",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2732329711\/3445d3d345ba841d248a9cdf0a18e687_normal.jpeg",
      "id" : 14157530,
      "verified" : false
    }
  },
  "id" : 339804062902005761,
  "created_at" : "2013-05-29 18:02:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karan Mavai",
      "screen_name" : "karanm",
      "indices" : [ 3, 10 ],
      "id_str" : "15401172",
      "id" : 15401172
    }, {
      "name" : "Vision Critical",
      "screen_name" : "visioncritical",
      "indices" : [ 63, 78 ],
      "id_str" : "36746097",
      "id" : 36746097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/WlUtiMHKh7",
      "expanded_url" : "http:\/\/bit.ly\/116dng2",
      "display_url" : "bit.ly\/116dng2"
    } ]
  },
  "geo" : { },
  "id_str" : "339479198630547456",
  "text" : "RT @karanm: We're looking for a top notch Interaction Designer @visioncritical. http:\/\/t.co\/WlUtiMHKh7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vision Critical",
        "screen_name" : "visioncritical",
        "indices" : [ 51, 66 ],
        "id_str" : "36746097",
        "id" : 36746097
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/WlUtiMHKh7",
        "expanded_url" : "http:\/\/bit.ly\/116dng2",
        "display_url" : "bit.ly\/116dng2"
      } ]
    },
    "geo" : { },
    "id_str" : "339478019146149890",
    "text" : "We're looking for a top notch Interaction Designer @visioncritical. http:\/\/t.co\/WlUtiMHKh7",
    "id" : 339478019146149890,
    "created_at" : "2013-05-28 20:27:21 +0000",
    "user" : {
      "name" : "Karan Mavai",
      "screen_name" : "karanm",
      "protected" : false,
      "id_str" : "15401172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752927756397142016\/EHL6muhj_normal.jpg",
      "id" : 15401172,
      "verified" : false
    }
  },
  "id" : 339479198630547456,
  "created_at" : "2013-05-28 20:32:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/cu4ydei44b",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ts_4vOUDImE",
      "display_url" : "youtube.com\/watch?v=ts_4vO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339423551079718913",
  "text" : "Many people who call themselves user experience designers aren't, but the team that designed this deserves the title: http:\/\/t.co\/cu4ydei44b",
  "id" : 339423551079718913,
  "created_at" : "2013-05-28 16:50:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BraveNewCode",
      "screen_name" : "BraveNewCode",
      "indices" : [ 0, 13 ],
      "id_str" : "89039840",
      "id" : 89039840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/VFqiM3e6ZM",
      "expanded_url" : "http:\/\/cms.wptouch.com",
      "display_url" : "cms.wptouch.com"
    } ]
  },
  "in_reply_to_status_id_str" : "339160049702285312",
  "geo" : { },
  "id_str" : "339161226712064000",
  "in_reply_to_user_id" : 15478959,
  "text" : "@bravenewcode Thanks very much! I did not know about the http:\/\/t.co\/VFqiM3e6ZM site - great to see. I'll keep my eye open for more demos.",
  "id" : 339161226712064000,
  "in_reply_to_status_id" : 339160049702285312,
  "created_at" : "2013-05-27 23:28:32 +0000",
  "in_reply_to_screen_name" : "wptouch",
  "in_reply_to_user_id_str" : "15478959",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BraveNewCode",
      "screen_name" : "BraveNewCode",
      "indices" : [ 0, 13 ],
      "id_str" : "89039840",
      "id" : 89039840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339142867660468224",
  "geo" : { },
  "id_str" : "339158644883091456",
  "in_reply_to_user_id" : 15478959,
  "text" : "@bravenewcode Any example sites using WPtouch Pro 3.x that you could share?",
  "id" : 339158644883091456,
  "in_reply_to_status_id" : 339142867660468224,
  "created_at" : "2013-05-27 23:18:16 +0000",
  "in_reply_to_screen_name" : "wptouch",
  "in_reply_to_user_id_str" : "15478959",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Y7arogvDYS",
      "expanded_url" : "http:\/\/www.mindmeister.com\/273528276\/etug-spring-2013-designing-for-touch-not-just-for-mobile-anymore-by-paul-hibbitts",
      "display_url" : "mindmeister.com\/273528276\/etug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339109289669058560",
  "text" : "Revised outline for my #etug Spring workshop to reflect the multi-device nature of designing for touch friendliness http:\/\/t.co\/Y7arogvDYS",
  "id" : 339109289669058560,
  "created_at" : "2013-05-27 20:02:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2013",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/agoucykQIK",
      "expanded_url" : "http:\/\/www.paulhibbitts.com\/multi-device-experience-design\/imoot2013\/index.html",
      "display_url" : "paulhibbitts.com\/multi-device-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337961828778901504",
  "text" : "Thanks again to everyone who attended my #iMoot2013 session on mobile learning! The accompanying resource page is at http:\/\/t.co\/agoucykQIK",
  "id" : 337961828778901504,
  "created_at" : "2013-05-24 16:02:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Elliott",
      "screen_name" : "ikawhero",
      "indices" : [ 0, 9 ],
      "id_str" : "15014149",
      "id" : 15014149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337958319031472129",
  "geo" : { },
  "id_str" : "337960380800311298",
  "in_reply_to_user_id" : 15014149,
  "text" : "@ikawhero Thanks very much Shane, it was my pleasure!",
  "id" : 337960380800311298,
  "in_reply_to_status_id" : 337958319031472129,
  "created_at" : "2013-05-24 15:56:48 +0000",
  "in_reply_to_screen_name" : "ikawhero",
  "in_reply_to_user_id_str" : "15014149",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2013",
      "indices" : [ 4, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/av7RYY8iLx",
      "expanded_url" : "http:\/\/uxfundamentals.com\/moodle\/",
      "display_url" : "uxfundamentals.com\/moodle\/"
    } ]
  },
  "geo" : { },
  "id_str" : "337637171152441344",
  "text" : "For #iMoot2013 attendees, a sneak peek of the mobile course companion demo I'll be discussing in my session tomorrow http:\/\/t.co\/av7RYY8iLx",
  "id" : 337637171152441344,
  "created_at" : "2013-05-23 18:32:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2013",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/9OGCXPWnBE",
      "expanded_url" : "http:\/\/2013.imoot.org\/local\/schedule\/schedulehtml.php",
      "display_url" : "2013.imoot.org\/local\/schedule\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337262739481313281",
  "text" : "Making final preparations for my #iMoot2013 talk about mobile\/multi-device learning using Moodle + Twitter Bootstrap. http:\/\/t.co\/9OGCXPWnBE",
  "id" : 337262739481313281,
  "created_at" : "2013-05-22 17:44:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karan Mavai",
      "screen_name" : "karanm",
      "indices" : [ 0, 7 ],
      "id_str" : "15401172",
      "id" : 15401172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336998515362373633",
  "geo" : { },
  "id_str" : "337000283194400769",
  "in_reply_to_user_id" : 15401172,
  "text" : "@karanm Great to see you again today Karan! Thanks for joining in the discussions.",
  "id" : 337000283194400769,
  "in_reply_to_status_id" : 336998515362373633,
  "created_at" : "2013-05-22 00:21:43 +0000",
  "in_reply_to_screen_name" : "karanm",
  "in_reply_to_user_id_str" : "15401172",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 67, 72 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336913944465772545",
  "geo" : { },
  "id_str" : "336919336461676546",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Thanks very much Tannis! Hope to see you next month at the @etug Spring Workshop.",
  "id" : 336919336461676546,
  "in_reply_to_status_id" : 336913944465772545,
  "created_at" : "2013-05-21 19:00:04 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vision Critical",
      "screen_name" : "visioncritical",
      "indices" : [ 63, 78 ],
      "id_str" : "36746097",
      "id" : 36746097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336908609982197760",
  "text" : "On my way to talk about mobile and multi-device experiences at @visioncritical - I've really been looking forward to this!",
  "id" : 336908609982197760,
  "created_at" : "2013-05-21 18:17:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SkyDrive",
      "screen_name" : "skydrive",
      "indices" : [ 0, 9 ],
      "id_str" : "2161733725",
      "id" : 2161733725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335148851105251328",
  "in_reply_to_user_id" : 297174372,
  "text" : "@SkyDrive What's up with Mac SkyDrive? For days I keep getting a message that an update is required, but when I try to do so I get an error.",
  "id" : 335148851105251328,
  "created_at" : "2013-05-16 21:44:47 +0000",
  "in_reply_to_screen_name" : "onedrive",
  "in_reply_to_user_id_str" : "297174372",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clark",
      "screen_name" : "globalmoxie",
      "indices" : [ 3, 15 ],
      "id_str" : "2733270440",
      "id" : 2733270440
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mobilism",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/N8wIboo0Od",
      "expanded_url" : "http:\/\/bit.ly\/beyond-mobile",
      "display_url" : "bit.ly\/beyond-mobile"
    } ]
  },
  "geo" : { },
  "id_str" : "335119992544690178",
  "text" : "RT @globalmoxie: Here are my slides from my \"beyond mobile\" talk at #mobilism. Design for sensors, not just the screen. http:\/\/t.co\/N8wIboo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mobilism",
        "indices" : [ 51, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/N8wIboo0Od",
        "expanded_url" : "http:\/\/bit.ly\/beyond-mobile",
        "display_url" : "bit.ly\/beyond-mobile"
      } ]
    },
    "geo" : { },
    "id_str" : "335088377403670528",
    "text" : "Here are my slides from my \"beyond mobile\" talk at #mobilism. Design for sensors, not just the screen. http:\/\/t.co\/N8wIboo0Od",
    "id" : 335088377403670528,
    "created_at" : "2013-05-16 17:44:29 +0000",
    "user" : {
      "name" : "Josh Clark",
      "screen_name" : "bigmediumjosh",
      "protected" : false,
      "id_str" : "7552082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/581098479298084864\/4LiXBCy4_normal.jpg",
      "id" : 7552082,
      "verified" : false
    }
  },
  "id" : 335119992544690178,
  "created_at" : "2013-05-16 19:50:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2013",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/9OGCXPWnBE",
      "expanded_url" : "http:\/\/2013.imoot.org\/local\/schedule\/schedulehtml.php",
      "display_url" : "2013.imoot.org\/local\/schedule\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "335071070933618688",
  "text" : "Interested in mobile learning + Twitter Bootstrap with Moodle? I will be presenting online at #iMoot2013 next Friday http:\/\/t.co\/9OGCXPWnBE",
  "id" : 335071070933618688,
  "created_at" : "2013-05-16 16:35:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331879352776146945",
  "text" : "What do multi-device experiences mean to you?",
  "id" : 331879352776146945,
  "created_at" : "2013-05-07 21:12:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331879102321672194",
  "text" : "#5 We need to think about APIs and content structure as well as multiple screens",
  "id" : 331879102321672194,
  "created_at" : "2013-05-07 21:11:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331879046566785024",
  "text" : "#4 Devices will not just vary in terms of displays, but also interactions, posture, and privacy",
  "id" : 331879046566785024,
  "created_at" : "2013-05-07 21:11:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331878972788973569",
  "text" : "#3 People will expect the same functionality and content regardless of device",
  "id" : 331878972788973569,
  "created_at" : "2013-05-07 21:11:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331878909383696384",
  "text" : "#2 Device transitions mid-task are bound to be attempted",
  "id" : 331878909383696384,
  "created_at" : "2013-05-07 21:11:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331878861312774145",
  "text" : "Multi-device experiences mean that\u2026 #1 People can choose the specific device best suited to the task at hand",
  "id" : 331878861312774145,
  "created_at" : "2013-05-07 21:11:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331816847404060673",
  "text" : "But being multi-device REALLY means being more available!",
  "id" : 331816847404060673,
  "created_at" : "2013-05-07 17:04:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331814850579791872",
  "text" : "Being mobile really means being available.",
  "id" : 331814850579791872,
  "created_at" : "2013-05-07 16:56:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/AW7Qz8Pi1i",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/b0ddae89-8156-6687-ba26-46e5bf624a52\/",
      "display_url" : "workflowy.com\/shared\/b0ddae8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331505356704468992",
  "text" : "Revised draft of multi-device experience design principles https:\/\/t.co\/AW7Qz8Pi1i Items to add\/change\/remove?",
  "id" : 331505356704468992,
  "created_at" : "2013-05-06 20:26:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexis MacMillan",
      "screen_name" : "alexismac",
      "indices" : [ 3, 13 ],
      "id_str" : "23222825",
      "id" : 23222825
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 122, 136 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edinnovation13",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330441709689376768",
  "text" : "RT @alexismac: Teaching and Learning is about building human capacity, not about making the factory model more efficient. @audreywatters #e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 107, 121 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edinnovation13",
        "indices" : [ 122, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "330404451791810561",
    "text" : "Teaching and Learning is about building human capacity, not about making the factory model more efficient. @audreywatters #edinnovation13",
    "id" : 330404451791810561,
    "created_at" : "2013-05-03 19:32:14 +0000",
    "user" : {
      "name" : "Alexis MacMillan",
      "screen_name" : "alexismac",
      "protected" : false,
      "id_str" : "23222825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731954177836875777\/v2kYMONv_normal.jpg",
      "id" : 23222825,
      "verified" : false
    }
  },
  "id" : 330441709689376768,
  "created_at" : "2013-05-03 22:00:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Rettig",
      "screen_name" : "mrettig",
      "indices" : [ 3, 11 ],
      "id_str" : "1687031",
      "id" : 1687031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/FTXNX6f9Uv",
      "expanded_url" : "http:\/\/cacm.acm.org\/blogs\/blog-cacm\/163939-the-role-of-hypercard-in-todays-world\/fulltext",
      "display_url" : "cacm.acm.org\/blogs\/blog-cac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "330436113393131520",
  "text" : "RT @mrettig: Hypercard lives! http:\/\/t.co\/FTXNX6f9Uv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/FTXNX6f9Uv",
        "expanded_url" : "http:\/\/cacm.acm.org\/blogs\/blog-cacm\/163939-the-role-of-hypercard-in-todays-world\/fulltext",
        "display_url" : "cacm.acm.org\/blogs\/blog-cac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "330434181312176128",
    "text" : "Hypercard lives! http:\/\/t.co\/FTXNX6f9Uv",
    "id" : 330434181312176128,
    "created_at" : "2013-05-03 21:30:22 +0000",
    "user" : {
      "name" : "Marc Rettig",
      "screen_name" : "mrettig",
      "protected" : false,
      "id_str" : "1687031",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/406979889\/rettig.headShot.twitter_sept09_normal.jpg",
      "id" : 1687031,
      "verified" : false
    }
  },
  "id" : 330436113393131520,
  "created_at" : "2013-05-03 21:38:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denim & Steel",
      "screen_name" : "DenimAndSteel",
      "indices" : [ 3, 17 ],
      "id_str" : "386399234",
      "id" : 386399234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330370146138992643",
  "text" : "RT @DenimAndSteel: Do you have non-technical friends who are wine lovers? We\u2019d like to invite them to a 1-hr testing session in Mt. Pleasan\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "330369012347334658",
    "text" : "Do you have non-technical friends who are wine lovers? We\u2019d like to invite them to a 1-hr testing session in Mt. Pleasant.",
    "id" : 330369012347334658,
    "created_at" : "2013-05-03 17:11:25 +0000",
    "user" : {
      "name" : "Denim & Steel",
      "screen_name" : "DenimAndSteel",
      "protected" : false,
      "id_str" : "386399234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487730797659451392\/vphHBnLu_normal.png",
      "id" : 386399234,
      "verified" : false
    }
  },
  "id" : 330370146138992643,
  "created_at" : "2013-05-03 17:15:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rahel Anne Bailie",
      "screen_name" : "rahelab",
      "indices" : [ 3, 11 ],
      "id_str" : "14140382",
      "id" : 14140382
    }, {
      "name" : "selma zafar",
      "screen_name" : "selmaz",
      "indices" : [ 27, 34 ],
      "id_str" : "36598690",
      "id" : 36598690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "contentstrategy",
      "indices" : [ 48, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/NaShk06rFH",
      "expanded_url" : "http:\/\/contentstrategyworkshops.com\/presentation\/leveraging-social-content-for-business-value\/",
      "display_url" : "contentstrategyworkshops.com\/presentation\/l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "330120470940758017",
  "text" : "RT @rahelab: The brilliant @selmaz is leading a #contentstrategy workshop on leveraging social content at our summer event: http:\/\/t.co\/NaS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "selma zafar",
        "screen_name" : "selmaz",
        "indices" : [ 14, 21 ],
        "id_str" : "36598690",
        "id" : 36598690
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "contentstrategy",
        "indices" : [ 35, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/NaShk06rFH",
        "expanded_url" : "http:\/\/contentstrategyworkshops.com\/presentation\/leveraging-social-content-for-business-value\/",
        "display_url" : "contentstrategyworkshops.com\/presentation\/l\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "329273497526358016",
    "text" : "The brilliant @selmaz is leading a #contentstrategy workshop on leveraging social content at our summer event: http:\/\/t.co\/NaShk06rFH",
    "id" : 329273497526358016,
    "created_at" : "2013-04-30 16:38:14 +0000",
    "user" : {
      "name" : "Rahel Anne Bailie",
      "screen_name" : "rahelab",
      "protected" : false,
      "id_str" : "14140382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537251916095295489\/bvBg8DHc_normal.jpeg",
      "id" : 14140382,
      "verified" : false
    }
  },
  "id" : 330120470940758017,
  "created_at" : "2013-05-03 00:43:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 3, 11 ],
      "id_str" : "10675",
      "id" : 10675
    }, {
      "name" : "Change.org",
      "screen_name" : "Change",
      "indices" : [ 93, 100 ],
      "id_str" : "15947602",
      "id" : 15947602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/Lu6yutlTwv",
      "expanded_url" : "https:\/\/www.change.org\/petitions\/capilano-university-save-the-interactive-design-program?share_id=JOrAvHykVc&utm_campaign=twitter_link_action_box&utm_medium=twitter&utm_source=share_petition",
      "display_url" : "change.org\/petitions\/capi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "330073468244729857",
  "text" : "RT @gordonr: Cap University: Save the Interactive Design program https:\/\/t.co\/Lu6yutlTwv via @change - a shame to see it go.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Change.org",
        "screen_name" : "Change",
        "indices" : [ 80, 87 ],
        "id_str" : "15947602",
        "id" : 15947602
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/Lu6yutlTwv",
        "expanded_url" : "https:\/\/www.change.org\/petitions\/capilano-university-save-the-interactive-design-program?share_id=JOrAvHykVc&utm_campaign=twitter_link_action_box&utm_medium=twitter&utm_source=share_petition",
        "display_url" : "change.org\/petitions\/capi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "330065673994772480",
    "text" : "Cap University: Save the Interactive Design program https:\/\/t.co\/Lu6yutlTwv via @change - a shame to see it go.",
    "id" : 330065673994772480,
    "created_at" : "2013-05-02 21:06:03 +0000",
    "user" : {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "protected" : false,
      "id_str" : "10675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723725303218991104\/GhSmJXhv_normal.jpg",
      "id" : 10675,
      "verified" : false
    }
  },
  "id" : 330073468244729857,
  "created_at" : "2013-05-02 21:37:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aarron Walter",
      "screen_name" : "aarron",
      "indices" : [ 3, 10 ],
      "id_str" : "9463382",
      "id" : 9463382
    }, {
      "name" : "Sonar",
      "screen_name" : "sonar",
      "indices" : [ 58, 64 ],
      "id_str" : "205755946",
      "id" : 205755946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/ALSeE9yVgd",
      "expanded_url" : "https:\/\/medium.com\/design-startups\/b79d490e9b9a",
      "display_url" : "medium.com\/design-startup\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "330018648049721346",
  "text" : "RT @aarron: +1 \"UX: easy to criticize, hard to do well.\" -@sonar https:\/\/t.co\/ALSeE9yVgd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sonar",
        "screen_name" : "sonar",
        "indices" : [ 46, 52 ],
        "id_str" : "205755946",
        "id" : 205755946
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/ALSeE9yVgd",
        "expanded_url" : "https:\/\/medium.com\/design-startups\/b79d490e9b9a",
        "display_url" : "medium.com\/design-startup\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "329985616873930752",
    "text" : "+1 \"UX: easy to criticize, hard to do well.\" -@sonar https:\/\/t.co\/ALSeE9yVgd",
    "id" : 329985616873930752,
    "created_at" : "2013-05-02 15:47:56 +0000",
    "user" : {
      "name" : "Aarron Walter",
      "screen_name" : "aarron",
      "protected" : false,
      "id_str" : "9463382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727883346035023874\/pvWNeypQ_normal.jpg",
      "id" : 9463382,
      "verified" : false
    }
  },
  "id" : 330018648049721346,
  "created_at" : "2013-05-02 17:59:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 58, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/ml6Zi6NZGp",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/49d37085-8c02-2c84-188d-034e29ef4812\/",
      "display_url" : "workflowy.com\/shared\/49d3708\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329719425047609346",
  "text" : "Revised draft of topics\/readings for my Fall UI course at #SFU Computing Science: https:\/\/t.co\/ml6Zi6NZGp Multi-device goodness developing!",
  "id" : 329719425047609346,
  "created_at" : "2013-05-01 22:10:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]