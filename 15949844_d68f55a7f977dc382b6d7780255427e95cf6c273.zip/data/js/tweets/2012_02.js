Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174276447626739712",
  "text" : "Looking forward to discussion with LMS Replacement Team at SFU tomorrow about my mobile course companion built using WordPress + WPtouch Pro",
  "id" : 174276447626739712,
  "created_at" : "2012-02-27 23:35:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justinmind",
      "screen_name" : "just_in_mind",
      "indices" : [ 3, 16 ],
      "id_str" : "46068081",
      "id" : 46068081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webdevelopment",
      "indices" : [ 74, 89 ]
    }, {
      "text" : "prototyping",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/UqcYLcEW",
      "expanded_url" : "http:\/\/ow.ly\/9dXs0",
      "display_url" : "ow.ly\/9dXs0"
    } ]
  },
  "geo" : { },
  "id_str" : "172393117817905154",
  "text" : "RT @just_in_mind: Now Justinmind Prototyper is FREE! http:\/\/t.co\/UqcYLcEW #webdevelopment #prototyping",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "webdevelopment",
        "indices" : [ 56, 71 ]
      }, {
        "text" : "prototyping",
        "indices" : [ 72, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/UqcYLcEW",
        "expanded_url" : "http:\/\/ow.ly\/9dXs0",
        "display_url" : "ow.ly\/9dXs0"
      } ]
    },
    "geo" : { },
    "id_str" : "172386478180147200",
    "text" : "Now Justinmind Prototyper is FREE! http:\/\/t.co\/UqcYLcEW #webdevelopment #prototyping",
    "id" : 172386478180147200,
    "created_at" : "2012-02-22 18:25:13 +0000",
    "user" : {
      "name" : "Justinmind",
      "screen_name" : "just_in_mind",
      "protected" : false,
      "id_str" : "46068081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488662466398666753\/pklq83Cl_normal.png",
      "id" : 46068081,
      "verified" : false
    }
  },
  "id" : 172393117817905154,
  "created_at" : "2012-02-22 18:51:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 0, 8 ],
      "id_str" : "1550251",
      "id" : 1550251
    }, {
      "name" : "Kenneth",
      "screen_name" : "KennethWong_",
      "indices" : [ 9, 22 ],
      "id_str" : "76891284",
      "id" : 76891284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172064601184276481",
  "geo" : { },
  "id_str" : "172120013984104449",
  "in_reply_to_user_id" : 1550251,
  "text" : "@dmitryn @KennethWong_ Thanks very much for the RTs\/mentions!",
  "id" : 172120013984104449,
  "in_reply_to_status_id" : 172064601184276481,
  "created_at" : "2012-02-22 00:46:23 +0000",
  "in_reply_to_screen_name" : "dmitryn",
  "in_reply_to_user_id_str" : "1550251",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Schroeter",
      "screen_name" : "matthanns",
      "indices" : [ 0, 10 ],
      "id_str" : "22445401",
      "id" : 22445401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171799556424609792",
  "geo" : { },
  "id_str" : "172119380673564672",
  "in_reply_to_user_id" : 22445401,
  "text" : "@matthanns Thanks very much for sharing the photo!",
  "id" : 172119380673564672,
  "in_reply_to_status_id" : 171799556424609792,
  "created_at" : "2012-02-22 00:43:52 +0000",
  "in_reply_to_screen_name" : "matthanns",
  "in_reply_to_user_id_str" : "22445401",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Grange",
      "screen_name" : "GrangeSteve",
      "indices" : [ 0, 12 ],
      "id_str" : "291889357",
      "id" : 291889357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172016539355189248",
  "geo" : { },
  "id_str" : "172045945763151872",
  "in_reply_to_user_id" : 291889357,
  "text" : "@GrangeSteve Thanks very much, it's great to hear that the talk was useful to you!",
  "id" : 172045945763151872,
  "in_reply_to_status_id" : 172016539355189248,
  "created_at" : "2012-02-21 19:52:04 +0000",
  "in_reply_to_screen_name" : "GrangeSteve",
  "in_reply_to_user_id_str" : "291889357",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Masterton",
      "screen_name" : "chris_masterton",
      "indices" : [ 0, 16 ],
      "id_str" : "80641764",
      "id" : 80641764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171817708151767043",
  "geo" : { },
  "id_str" : "172009006280347648",
  "in_reply_to_user_id" : 80641764,
  "text" : "@chris_masterton Thanks so much for the very kind words! It was awesome to see you and Selma there!",
  "id" : 172009006280347648,
  "in_reply_to_status_id" : 171817708151767043,
  "created_at" : "2012-02-21 17:25:17 +0000",
  "in_reply_to_screen_name" : "chris_masterton",
  "in_reply_to_user_id_str" : "80641764",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OREFRONT",
      "screen_name" : "OREFRONT",
      "indices" : [ 0, 9 ],
      "id_str" : "465222801",
      "id" : 465222801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171799900592418816",
  "geo" : { },
  "id_str" : "172008336391274498",
  "in_reply_to_user_id" : 465222801,
  "text" : "@OREFRONT It was my pleasure, thanks for joining us!",
  "id" : 172008336391274498,
  "in_reply_to_status_id" : 171799900592418816,
  "created_at" : "2012-02-21 17:22:37 +0000",
  "in_reply_to_screen_name" : "OREFRONT",
  "in_reply_to_user_id_str" : "465222801",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Agile Vancouver",
      "screen_name" : "agilevancouver",
      "indices" : [ 95, 110 ],
      "id_str" : "133390035",
      "id" : 133390035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/ZudXJhGs",
      "expanded_url" : "http:\/\/speakerdeck.com\/u\/hibbittsdesign\/p\/involving-stakeholders-in-user-experience-ux-design",
      "display_url" : "speakerdeck.com\/u\/hibbittsdesi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "172007391196487680",
  "text" : "My slides from last night's Agile Vancouver presentation are at http:\/\/t.co\/ZudXJhGs Thanks to @agilevancouver and everyone who attended!",
  "id" : 172007391196487680,
  "created_at" : "2012-02-21 17:18:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/E83PUD8u",
      "expanded_url" : "http:\/\/speakerdeck.com\/u\/hibbittsdesign\/p\/user-experience-ux-design-for-mobile-learning-enhancing-formal-learning-and-performance",
      "display_url" : "speakerdeck.com\/u\/hibbittsdesi\u2026"
    }, {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/g5tRgIKz",
      "expanded_url" : "http:\/\/www.mindmeister.com\/132638751\/mobile-learning-ux-presentation-outline",
      "display_url" : "mindmeister.com\/132638751\/mobi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "171670213664849921",
  "geo" : { },
  "id_str" : "171734045024198658",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Love to hear your thoughts about my draft mobile learning talk outline\/slides! http:\/\/t.co\/E83PUD8u http:\/\/t.co\/g5tRgIKz",
  "id" : 171734045024198658,
  "in_reply_to_status_id" : 171670213664849921,
  "created_at" : "2012-02-20 23:12:41 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171670213664849921",
  "geo" : { },
  "id_str" : "171672468757557248",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard That's my talk outline for tonight :-)",
  "id" : 171672468757557248,
  "in_reply_to_status_id" : 171670213664849921,
  "created_at" : "2012-02-20 19:08:00 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/0mE2QPOE",
      "expanded_url" : "http:\/\/agilevancouver.ca\/",
      "display_url" : "agilevancouver.ca"
    } ]
  },
  "geo" : { },
  "id_str" : "171638987872669696",
  "text" : "Looking forward to speaking tonight at Agile Vancouver about stakeholder involvement in UX design http:\/\/t.co\/0mE2QPOE",
  "id" : 171638987872669696,
  "created_at" : "2012-02-20 16:54:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete",
      "screen_name" : "NoDissasemble",
      "indices" : [ 3, 17 ],
      "id_str" : "19435679",
      "id" : 19435679
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infoq",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/pL77jfND",
      "expanded_url" : "http:\/\/bit.ly\/y2RDYX",
      "display_url" : "bit.ly\/y2RDYX"
    } ]
  },
  "geo" : { },
  "id_str" : "168094830705119233",
  "text" : "RT @NoDissasemble: Strategic User Experience: Leisa Reichelt proposes a detailed process for delivering a great UX s... http:\/\/t.co\/pL77 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/en.wikipedia.org\/wiki\/Short_Circuit\" rel=\"nofollow\"\u003Enodissasemble\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "infoq",
        "indices" : [ 122, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/pL77jfND",
        "expanded_url" : "http:\/\/bit.ly\/y2RDYX",
        "display_url" : "bit.ly\/y2RDYX"
      } ]
    },
    "geo" : { },
    "id_str" : "168076542692438016",
    "text" : "Strategic User Experience: Leisa Reichelt proposes a detailed process for delivering a great UX s... http:\/\/t.co\/pL77jfND #infoq",
    "id" : 168076542692438016,
    "created_at" : "2012-02-10 20:59:05 +0000",
    "user" : {
      "name" : "Pete",
      "screen_name" : "NoDissasemble",
      "protected" : false,
      "id_str" : "19435679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591485406794776576\/jOl27vgi_normal.png",
      "id" : 19435679,
      "verified" : false
    }
  },
  "id" : 168094830705119233,
  "created_at" : "2012-02-10 22:11:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/g5tRgIKz",
      "expanded_url" : "http:\/\/www.mindmeister.com\/132638751\/mobile-learning-ux-presentation-outline",
      "display_url" : "mindmeister.com\/132638751\/mobi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "167676222460002304",
  "text" : "Looking for Vancouver groups\/companies interested in a presentation about ux design for mobile learning - suggestions? http:\/\/t.co\/g5tRgIKz",
  "id" : 167676222460002304,
  "created_at" : "2012-02-09 18:28:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jocelyn Smith",
      "screen_name" : "UXcrickets",
      "indices" : [ 0, 11 ],
      "id_str" : "40075726",
      "id" : 40075726
    }, {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 12, 20 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167337142031368192",
  "geo" : { },
  "id_str" : "167400249026031616",
  "in_reply_to_user_id" : 40075726,
  "text" : "@UXcrickets @dmitryn Your most welcome, and please feel free to contact me directly if I can be of more help re: remote collaboration, etc.",
  "id" : 167400249026031616,
  "in_reply_to_status_id" : 167337142031368192,
  "created_at" : "2012-02-09 00:11:44 +0000",
  "in_reply_to_screen_name" : "UXcrickets",
  "in_reply_to_user_id_str" : "40075726",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jocelyn Smith",
      "screen_name" : "UXcrickets",
      "indices" : [ 0, 11 ],
      "id_str" : "40075726",
      "id" : 40075726
    }, {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 12, 20 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167329254172930049",
  "geo" : { },
  "id_str" : "167333630878810112",
  "in_reply_to_user_id" : 40075726,
  "text" : "@UXcrickets @dmitryn My preferred collab mockup tool is myBalsamiq and HotGloo for more interactive prototypes. Let me know how it goes!",
  "id" : 167333630878810112,
  "in_reply_to_status_id" : 167329254172930049,
  "created_at" : "2012-02-08 19:47:01 +0000",
  "in_reply_to_screen_name" : "UXcrickets",
  "in_reply_to_user_id_str" : "40075726",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167048172810682368",
  "in_reply_to_user_id" : 105643919,
  "text" : "@martinaatmaa Thanks for the RT!",
  "id" : 167048172810682368,
  "created_at" : "2012-02-08 00:52:42 +0000",
  "in_reply_to_screen_name" : "mrtn_su",
  "in_reply_to_user_id_str" : "105643919",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "selma zafar",
      "screen_name" : "selmaz",
      "indices" : [ 0, 7 ],
      "id_str" : "36598690",
      "id" : 36598690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166699921930596352",
  "geo" : { },
  "id_str" : "166935847034302464",
  "in_reply_to_user_id" : 36598690,
  "text" : "@selmaz Thanks for the RT Selma!",
  "id" : 166935847034302464,
  "in_reply_to_status_id" : 166699921930596352,
  "created_at" : "2012-02-07 17:26:22 +0000",
  "in_reply_to_screen_name" : "selmaz",
  "in_reply_to_user_id_str" : "36598690",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baldwin",
      "screen_name" : "benry",
      "indices" : [ 0, 6 ],
      "id_str" : "1969441",
      "id" : 1969441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166681296922357760",
  "in_reply_to_user_id" : 1969441,
  "text" : "@benry Thanks for the RT Scott. I hope the renovations are going well!",
  "id" : 166681296922357760,
  "created_at" : "2012-02-07 00:34:52 +0000",
  "in_reply_to_screen_name" : "benry",
  "in_reply_to_user_id_str" : "1969441",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habanero UX Team",
      "screen_name" : "HabaneroUE",
      "indices" : [ 0, 11 ],
      "id_str" : "178784851",
      "id" : 178784851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166617033004417026",
  "in_reply_to_user_id" : 178784851,
  "text" : "@HabaneroUE Thanks very much for the RT!",
  "id" : 166617033004417026,
  "created_at" : "2012-02-06 20:19:30 +0000",
  "in_reply_to_screen_name" : "HabaneroUE",
  "in_reply_to_user_id_str" : "178784851",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BraveNewCode",
      "screen_name" : "BraveNewCode",
      "indices" : [ 0, 13 ],
      "id_str" : "89039840",
      "id" : 89039840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166614570612424706",
  "geo" : { },
  "id_str" : "166616521114779650",
  "in_reply_to_user_id" : 15478959,
  "text" : "@bravenewcode Thanks for the RT. Special thanks also for the awesome developer support you guys provide!",
  "id" : 166616521114779650,
  "in_reply_to_status_id" : 166614570612424706,
  "created_at" : "2012-02-06 20:17:28 +0000",
  "in_reply_to_screen_name" : "wptouch",
  "in_reply_to_user_id_str" : "15478959",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BraveNewCode",
      "screen_name" : "BraveNewCode",
      "indices" : [ 0, 13 ],
      "id_str" : "89039840",
      "id" : 89039840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/S7CBo5pB",
      "expanded_url" : "http:\/\/speakerdeck.com\/u\/hibbittsdesign\/p\/user-experience-ux-design-for-mobile-learning-a-case-study-of-augmenting-formal-instruction",
      "display_url" : "speakerdeck.com\/u\/hibbittsdesi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "166577980947181568",
  "geo" : { },
  "id_str" : "166612216869687296",
  "in_reply_to_user_id" : 15478959,
  "text" : "@bravenewcode Mobile course companion to augment formal instruction includes a case study featuring WPtouch Pro http:\/\/t.co\/S7CBo5pB",
  "id" : 166612216869687296,
  "in_reply_to_status_id" : 166577980947181568,
  "created_at" : "2012-02-06 20:00:22 +0000",
  "in_reply_to_screen_name" : "wptouch",
  "in_reply_to_user_id_str" : "15478959",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/0mE2QPOE",
      "expanded_url" : "http:\/\/agilevancouver.ca\/",
      "display_url" : "agilevancouver.ca"
    } ]
  },
  "geo" : { },
  "id_str" : "166591528641376256",
  "text" : "I will be presenting \"Involving Stakeholders in User Experience (UX) Design\" at Agile Vancouver on Monday, Feb 20th http:\/\/t.co\/0mE2QPOE",
  "id" : 166591528641376256,
  "created_at" : "2012-02-06 18:38:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzanne",
      "screen_name" : "suzanneginsburg",
      "indices" : [ 0, 16 ],
      "id_str" : "21534965",
      "id" : 21534965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/OMx5AAqT",
      "expanded_url" : "http:\/\/www.paulhibbitts.com\/usability-ucd-ux-recommended-links-and-tools.html#MobileGuidelines",
      "display_url" : "paulhibbitts.com\/usability-ucd-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "165239398248611840",
  "geo" : { },
  "id_str" : "165248460658982913",
  "in_reply_to_user_id" : 21534965,
  "text" : "@suzanneginsburg You might find something of interest in my mobile guidelines and standards collection http:\/\/t.co\/OMx5AAqT",
  "id" : 165248460658982913,
  "in_reply_to_status_id" : 165239398248611840,
  "created_at" : "2012-02-03 01:41:17 +0000",
  "in_reply_to_screen_name" : "suzanneginsburg",
  "in_reply_to_user_id_str" : "21534965",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]