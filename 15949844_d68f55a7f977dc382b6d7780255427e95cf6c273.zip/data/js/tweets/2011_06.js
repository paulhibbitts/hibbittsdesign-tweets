Grailbird.data.tweets_2011_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Headway Themes",
      "screen_name" : "headwaythemes",
      "indices" : [ 0, 14 ],
      "id_str" : "42527523",
      "id" : 42527523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86523291979878400",
  "geo" : { },
  "id_str" : "86524497468981248",
  "in_reply_to_user_id" : 42527523,
  "text" : "@headwaythemes Thanks very much for the info esp. 3.2RC3!",
  "id" : 86524497468981248,
  "in_reply_to_status_id" : 86523291979878400,
  "created_at" : "2011-06-30 20:00:22 +0000",
  "in_reply_to_screen_name" : "headwaythemes",
  "in_reply_to_user_id_str" : "42527523",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Agentic Inc.",
      "screen_name" : "agentic",
      "indices" : [ 93, 101 ],
      "id_str" : "92621411",
      "id" : 92621411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86521416488464384",
  "text" : "It was my pleasure to share some of my recent experiences about Web navigation methods today @Agentic. Great Q&A and follow-up discussions!",
  "id" : 86521416488464384,
  "created_at" : "2011-06-30 19:48:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Griffiths",
      "screen_name" : "GrantGriffiths",
      "indices" : [ 0, 15 ],
      "id_str" : "8320702",
      "id" : 8320702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86192553317249025",
  "geo" : { },
  "id_str" : "86216408802930688",
  "in_reply_to_user_id" : 8320702,
  "text" : "@GrantGriffiths Great to know, thanks very much!",
  "id" : 86216408802930688,
  "in_reply_to_status_id" : 86192553317249025,
  "created_at" : "2011-06-29 23:36:08 +0000",
  "in_reply_to_screen_name" : "GrantGriffiths",
  "in_reply_to_user_id_str" : "8320702",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Headway Themes",
      "screen_name" : "headwaythemes",
      "indices" : [ 0, 14 ],
      "id_str" : "42527523",
      "id" : 42527523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86182742722756608",
  "in_reply_to_user_id" : 42527523,
  "text" : "@headwaythemes Any known issues with upgrading to WordPress 3.1.4?",
  "id" : 86182742722756608,
  "created_at" : "2011-06-29 21:22:21 +0000",
  "in_reply_to_screen_name" : "headwaythemes",
  "in_reply_to_user_id_str" : "42527523",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 94 ],
      "url" : "http:\/\/t.co\/0mrgre4",
      "expanded_url" : "https:\/\/www.iwork.com\/r\/en\/?a=p28426520&d=Web_Navigation_Update_Summer_2011.key&u=paul%40hibbittsdesign.com&p=15182F176DA119CB5715",
      "display_url" : "iwork.com\/r\/en\/?a=p28426\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "86139003690172416",
  "text" : "Draft slides of my Web Navigation Methods Update: Summer 2011 presentation http:\/\/t.co\/0mrgre4",
  "id" : 86139003690172416,
  "created_at" : "2011-06-29 18:28:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtain Revenue",
      "screen_name" : "corvustweets",
      "indices" : [ 0, 13 ],
      "id_str" : "2503692858",
      "id" : 2503692858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85918442439454720",
  "text" : "@corvustweets One of its killer features is that you can customize tabs (page types) for each client workspace",
  "id" : 85918442439454720,
  "created_at" : "2011-06-29 03:52:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtain Revenue",
      "screen_name" : "corvustweets",
      "indices" : [ 0, 13 ],
      "id_str" : "2503692858",
      "id" : 2503692858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85914002881908736",
  "text" : "@corvustweets You might want to check out TeamworkPM. I migrated to it (from Basecamp) a while ago and have been very happy overall.",
  "id" : 85914002881908736,
  "created_at" : "2011-06-29 03:34:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 88 ],
      "url" : "http:\/\/t.co\/Zy8PJNF",
      "expanded_url" : "http:\/\/www.paulhibbitts.com\/usability-ucd-ux-recommended-links-and-tools.html#MobileGuidelines",
      "display_url" : "paulhibbitts.com\/usability-ucd-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "83673229193003009",
  "text" : "Added the Nokia N9 UX Guidelines to my mobile guidelines collection: http:\/\/t.co\/Zy8PJNF &lt;-Includes a nice little section on writing UI text",
  "id" : 83673229193003009,
  "created_at" : "2011-06-22 23:10:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 65 ],
      "url" : "http:\/\/t.co\/b1iZWin",
      "expanded_url" : "http:\/\/www.webdesignerdepot.com\/2011\/06\/how-to-avoid-a-redesign-failure\/",
      "display_url" : "webdesignerdepot.com\/2011\/06\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "83594597032407040",
  "text" : "How to avoid a redesign failure | Webdesigner http:\/\/t.co\/b1iZWin &lt;-Solid suggestions in my experience when a complete redesign is required",
  "id" : 83594597032407040,
  "created_at" : "2011-06-22 17:57:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jin Yang",
      "screen_name" : "jzy",
      "indices" : [ 3, 7 ],
      "id_str" : "14971237",
      "id" : 14971237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 61 ],
      "url" : "http:\/\/t.co\/Za4RJMP",
      "expanded_url" : "http:\/\/aneventapart.com\/alasurvey2010\/",
      "display_url" : "aneventapart.com\/alasurvey2010\/"
    } ]
  },
  "geo" : { },
  "id_str" : "83299007639724032",
  "text" : "RT @jzy: Web Design Survey, 2010 results: http:\/\/t.co\/Za4RJMP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 52 ],
        "url" : "http:\/\/t.co\/Za4RJMP",
        "expanded_url" : "http:\/\/aneventapart.com\/alasurvey2010\/",
        "display_url" : "aneventapart.com\/alasurvey2010\/"
      } ]
    },
    "geo" : { },
    "id_str" : "83195937182330880",
    "text" : "Web Design Survey, 2010 results: http:\/\/t.co\/Za4RJMP",
    "id" : 83195937182330880,
    "created_at" : "2011-06-21 15:33:51 +0000",
    "user" : {
      "name" : "Jin Yang",
      "screen_name" : "jzy",
      "protected" : false,
      "id_str" : "14971237",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1180150530\/jin-madmen_normal.png",
      "id" : 14971237,
      "verified" : false
    }
  },
  "id" : 83299007639724032,
  "created_at" : "2011-06-21 22:23:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Cooper",
      "screen_name" : "MrAlanCooper",
      "indices" : [ 3, 16 ],
      "id_str" : "103920270",
      "id" : 103920270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81853559666253824",
  "text" : "RT @MrAlanCooper: OH: It's not about going to your desk and drawing rectangles. It's about co-creating.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81852989257687040",
    "text" : "OH: It's not about going to your desk and drawing rectangles. It's about co-creating.\"",
    "id" : 81852989257687040,
    "created_at" : "2011-06-17 22:37:28 +0000",
    "user" : {
      "name" : "Alan Cooper",
      "screen_name" : "MrAlanCooper",
      "protected" : false,
      "id_str" : "103920270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1470274107\/Alan_Avatar_normal.jpg",
      "id" : 103920270,
      "verified" : false
    }
  },
  "id" : 81853559666253824,
  "created_at" : "2011-06-17 22:39:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81419332067930113",
  "text" : "Learning Styles: The Cognitive Side of Content http:\/\/bit.ly\/iyQD3K &lt;- Includes a nice concise list of learning style implications",
  "id" : 81419332067930113,
  "created_at" : "2011-06-16 17:54:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 0, 4 ],
      "id_str" : "1063291",
      "id" : 1063291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81078538479996928",
  "geo" : { },
  "id_str" : "81095745998036992",
  "in_reply_to_user_id" : 1063291,
  "text" : "@UIE I've joined LinkedIn Groups for identifying people with similar interests, learning, keeping up-to-date, and occasional discussions.",
  "id" : 81095745998036992,
  "in_reply_to_status_id" : 81078538479996928,
  "created_at" : "2011-06-15 20:28:27 +0000",
  "in_reply_to_screen_name" : "UIE",
  "in_reply_to_user_id_str" : "1063291",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtain Revenue",
      "screen_name" : "corvustweets",
      "indices" : [ 0, 13 ],
      "id_str" : "2503692858",
      "id" : 2503692858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81060868930019330",
  "text" : "@corvustweets While I love a lot of things about c5, the mobile support I wanted led me to WP with WPtouch Pro. Still a ways to go though...",
  "id" : 81060868930019330,
  "created_at" : "2011-06-15 18:09:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtain Revenue",
      "screen_name" : "corvustweets",
      "indices" : [ 0, 13 ],
      "id_str" : "2503692858",
      "id" : 2503692858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81058945443180544",
  "text" : "@corvustweets Thanks for the RT of the new course companion site demo!",
  "id" : 81058945443180544,
  "created_at" : "2011-06-15 18:02:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rosenfeld Media",
      "screen_name" : "RosenfeldMedia",
      "indices" : [ 0, 15 ],
      "id_str" : "22375745",
      "id" : 22375745
    }, {
      "name" : "Obtain Revenue",
      "screen_name" : "corvustweets",
      "indices" : [ 16, 29 ],
      "id_str" : "2503692858",
      "id" : 2503692858
    }, {
      "name" : "UX Zeitgeist",
      "screen_name" : "uxzeitgeist",
      "indices" : [ 80, 92 ],
      "id_str" : "59224227",
      "id" : 59224227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80989277034516480",
  "geo" : { },
  "id_str" : "81043381240856576",
  "in_reply_to_user_id" : 22375745,
  "text" : "@RosenfeldMedia @corvustweets Thanks! I'll look into mirroring the book list on @uxzeitgeist",
  "id" : 81043381240856576,
  "in_reply_to_status_id" : 80989277034516480,
  "created_at" : "2011-06-15 17:00:22 +0000",
  "in_reply_to_screen_name" : "RosenfeldMedia",
  "in_reply_to_user_id_str" : "22375745",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http:\/\/t.co\/pUngqgf",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/uxfundamentals-demo\/",
      "display_url" : "hibbittsdesign.com\/courses\/uxfund\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80759552299106304",
  "text" : "New course companion site (incl. mobile) beta at http:\/\/t.co\/pUngqgf w. \"Intro to UX\" module. Feedback & suggestions greatly appreciated!",
  "id" : 80759552299106304,
  "created_at" : "2011-06-14 22:12:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "selma zafar",
      "screen_name" : "selmaz",
      "indices" : [ 3, 10 ],
      "id_str" : "36598690",
      "id" : 36598690
    }, {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 85, 97 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IA",
      "indices" : [ 17, 20 ]
    }, {
      "text" : "wireframes",
      "indices" : [ 25, 36 ]
    }, {
      "text" : "UX",
      "indices" : [ 72, 75 ]
    }, {
      "text" : "UXjobs",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80380143457153024",
  "text" : "RT @selmaz: Love #IA and #wireframes? More Interviews this week for the #UX position @openroadies.  Still time to apply!   http:\/\/bit.ly ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenRoad",
        "screen_name" : "openroadies",
        "indices" : [ 73, 85 ],
        "id_str" : "66913866",
        "id" : 66913866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IA",
        "indices" : [ 5, 8 ]
      }, {
        "text" : "wireframes",
        "indices" : [ 13, 24 ]
      }, {
        "text" : "UX",
        "indices" : [ 60, 63 ]
      }, {
        "text" : "UXjobs",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80376828040200192",
    "text" : "Love #IA and #wireframes? More Interviews this week for the #UX position @openroadies.  Still time to apply!   http:\/\/bit.ly\/m19o5d #UXjobs",
    "id" : 80376828040200192,
    "created_at" : "2011-06-13 20:51:43 +0000",
    "user" : {
      "name" : "selma zafar",
      "screen_name" : "selmaz",
      "protected" : false,
      "id_str" : "36598690",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/191536681\/selma_photo2_normal.jpg",
      "id" : 36598690,
      "verified" : false
    }
  },
  "id" : 80380143457153024,
  "created_at" : "2011-06-13 21:04:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "52 Weeks of UX",
      "screen_name" : "52WeeksOfUX",
      "indices" : [ 3, 15 ],
      "id_str" : "100552037",
      "id" : 100552037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80306177581387776",
  "text" : "RT @52WeeksOfUX: \"Let's be real and acknowledge that the job title of \"UX Designer\" is vaporware\"  http:\/\/awe.sm\/5MbJA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/timely.is\" rel=\"nofollow\"\u003ETimely by Demandforce\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80294149881987072",
    "text" : "\"Let's be real and acknowledge that the job title of \"UX Designer\" is vaporware\"  http:\/\/awe.sm\/5MbJA",
    "id" : 80294149881987072,
    "created_at" : "2011-06-13 15:23:11 +0000",
    "user" : {
      "name" : "52 Weeks of UX",
      "screen_name" : "52WeeksOfUX",
      "protected" : false,
      "id_str" : "100552037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/617053922\/52weeks_normal.png",
      "id" : 100552037,
      "verified" : false
    }
  },
  "id" : 80306177581387776,
  "created_at" : "2011-06-13 16:10:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 59 ],
      "url" : "http:\/\/t.co\/5CftS8U",
      "expanded_url" : "http:\/\/dux.typepad.com\/dux\/2011\/06\/powerpoint-for-prototyping-part-1-of-2.html",
      "display_url" : "dux.typepad.com\/dux\/2011\/06\/po\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80299948553408512",
  "text" : "Powerpoint for Prototyping: Part 1 of 2 http:\/\/t.co\/5CftS8U &lt;- PowerPoint is still one of my top tools to create scenario-based storyboards",
  "id" : 80299948553408512,
  "created_at" : "2011-06-13 15:46:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]