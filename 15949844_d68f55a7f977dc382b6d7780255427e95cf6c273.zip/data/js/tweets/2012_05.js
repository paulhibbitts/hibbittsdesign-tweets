Grailbird.data.tweets_2012_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/gwYTMlTx",
      "expanded_url" : "http:\/\/arstechnica.com\/apple\/2012\/05\/25-years-of-hypercard-the-missing-link-to-the-web\/",
      "display_url" : "arstechnica.com\/apple\/2012\/05\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "208282287471738881",
  "text" : "25 years of HyperCard\u2014the missing link to the Web | Ars Technica http:\/\/t.co\/gwYTMlTx HyperCard was where it all started for me in 1989.",
  "id" : 208282287471738881,
  "created_at" : "2012-05-31 19:42:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill Christ",
      "screen_name" : "jillchrist",
      "indices" : [ 3, 14 ],
      "id_str" : "14436418",
      "id" : 14436418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207537781176680448",
  "text" : "RT @jillchrist: Sometimes it's nice to stop worrying about getting recognized, and focus on recognizing others.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "207531798094282752",
    "text" : "Sometimes it's nice to stop worrying about getting recognized, and focus on recognizing others.",
    "id" : 207531798094282752,
    "created_at" : "2012-05-29 18:00:11 +0000",
    "user" : {
      "name" : "Jill Christ",
      "screen_name" : "jillchrist",
      "protected" : false,
      "id_str" : "14436418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513366069449216001\/B4BVQdun_normal.jpeg",
      "id" : 14436418,
      "verified" : false
    }
  },
  "id" : 207537781176680448,
  "created_at" : "2012-05-29 18:23:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenneth",
      "screen_name" : "KennethWong_",
      "indices" : [ 0, 13 ],
      "id_str" : "76891284",
      "id" : 76891284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207216180765790208",
  "geo" : { },
  "id_str" : "207246769099247616",
  "in_reply_to_user_id" : 76891284,
  "text" : "@KennethWong_ Thanks for letting me know!",
  "id" : 207246769099247616,
  "in_reply_to_status_id" : 207216180765790208,
  "created_at" : "2012-05-28 23:07:34 +0000",
  "in_reply_to_screen_name" : "KennethWong_",
  "in_reply_to_user_id_str" : "76891284",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206154323112116225",
  "text" : "Since starting to use more open source tools (e.g. Zurb Foundation &amp; WordPress) every LMS I use out seems constrained and backward looking.",
  "id" : 206154323112116225,
  "created_at" : "2012-05-25 22:46:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205780710093619200",
  "geo" : { },
  "id_str" : "205791894796640257",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 Thanks very much. I am still a WordPress newbie but I absolutely love being able to use Foundation for both WP and my HTML sites!",
  "id" : 205791894796640257,
  "in_reply_to_status_id" : 205780710093619200,
  "created_at" : "2012-05-24 22:46:25 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/Yjt8FcMR",
      "expanded_url" : "http:\/\/paulhibbitts.com\/mobilelearningux\/",
      "display_url" : "paulhibbitts.com\/mobilelearning\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "205762949447557120",
  "geo" : { },
  "id_str" : "205766089823633409",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 Super simple example mini-site with Reverie http:\/\/t.co\/Yjt8FcMR Being able to utilize Foundation within WP pages has been amazing!",
  "id" : 205766089823633409,
  "in_reply_to_status_id" : 205762949447557120,
  "created_at" : "2012-05-24 21:03:53 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205762949447557120",
  "geo" : { },
  "id_str" : "205764185399885824",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 With mobile-specific work never found anything better than WPtouch Pro for device specific. Doing mobile-first work with Reverie now.",
  "id" : 205764185399885824,
  "in_reply_to_status_id" : 205762949447557120,
  "created_at" : "2012-05-24 20:56:19 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205760253877432320",
  "geo" : { },
  "id_str" : "205761973818900480",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 Wptouch Pro for device specific designs, and Reverie WP theme which is based on Zurb Foundation for responsive web design approach.",
  "id" : 205761973818900480,
  "in_reply_to_status_id" : 205760253877432320,
  "created_at" : "2012-05-24 20:47:32 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger Nowell",
      "screen_name" : "Roger_Nowell",
      "indices" : [ 0, 13 ],
      "id_str" : "123773951",
      "id" : 123773951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205551139482107904",
  "geo" : { },
  "id_str" : "205694155660328960",
  "in_reply_to_user_id" : 123773951,
  "text" : "@Roger_Nowell Thanks for sharing my Mobile Learning UX mini-site!",
  "id" : 205694155660328960,
  "in_reply_to_status_id" : 205551139482107904,
  "created_at" : "2012-05-24 16:18:02 +0000",
  "in_reply_to_screen_name" : "Roger_Nowell",
  "in_reply_to_user_id_str" : "123773951",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David J Kelley",
      "screen_name" : "DavidJKelley",
      "indices" : [ 3, 16 ],
      "id_str" : "25037910",
      "id" : 25037910
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Design",
      "indices" : [ 37, 44 ]
    }, {
      "text" : "ux",
      "indices" : [ 99, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/hLWfyCs1",
      "expanded_url" : "http:\/\/bit.ly\/KkAYDH",
      "display_url" : "bit.ly\/KkAYDH"
    } ]
  },
  "geo" : { },
  "id_str" : "205693515596963840",
  "text" : "RT @DavidJKelley: Why Responsive Web #Design is not the Holy Grail for Mobile http:\/\/t.co\/hLWfyCs1 #ux",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Design",
        "indices" : [ 19, 26 ]
      }, {
        "text" : "ux",
        "indices" : [ 81, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/hLWfyCs1",
        "expanded_url" : "http:\/\/bit.ly\/KkAYDH",
        "display_url" : "bit.ly\/KkAYDH"
      } ]
    },
    "geo" : { },
    "id_str" : "205693056245170177",
    "text" : "Why Responsive Web #Design is not the Holy Grail for Mobile http:\/\/t.co\/hLWfyCs1 #ux",
    "id" : 205693056245170177,
    "created_at" : "2012-05-24 16:13:40 +0000",
    "user" : {
      "name" : "David J Kelley",
      "screen_name" : "DavidJKelley",
      "protected" : false,
      "id_str" : "25037910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471844134387331072\/IQc1rW9v_normal.jpeg",
      "id" : 25037910,
      "verified" : false
    }
  },
  "id" : 205693515596963840,
  "created_at" : "2012-05-24 16:15:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlearning",
      "indices" : [ 124, 134 ]
    }, {
      "text" : "ux",
      "indices" : [ 135, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/RqljBiPe",
      "expanded_url" : "http:\/\/mobilelearningux.com\/",
      "display_url" : "mobilelearningux.com"
    } ]
  },
  "geo" : { },
  "id_str" : "205351063283441664",
  "text" : "Interested in learning more about mobile learning UX design? New mobile friendly mini-site (beta only) http:\/\/t.co\/RqljBiPe #mlearning #ux",
  "id" : 205351063283441664,
  "created_at" : "2012-05-23 17:34:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 118, 128 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/QRBWDysY",
      "expanded_url" : "http:\/\/shar.es\/qfTrg",
      "display_url" : "shar.es\/qfTrg"
    } ]
  },
  "geo" : { },
  "id_str" : "205033754010464257",
  "text" : "From UI to UX: Can Software Really Help People Be More Passionate About Their Jobs? - Forbes http:\/\/t.co\/QRBWDysY via @sharethis",
  "id" : 205033754010464257,
  "created_at" : "2012-05-22 20:33:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug2012",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 76 ],
      "url" : "https:\/\/t.co\/7apAaeM0",
      "expanded_url" : "https:\/\/speakerdeck.com\/u\/hibbittsdesign\/p\/etug-leveraging-wordpress-for-mobile-learning-a-case-study",
      "display_url" : "speakerdeck.com\/u\/hibbittsdesi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "204975921864781825",
  "text" : "Leveraging WordPress for Mobile Learning: A Case Study https:\/\/t.co\/7apAaeM0 Draft slides for my June 8th presentation at #etug2012",
  "id" : 204975921864781825,
  "created_at" : "2012-05-22 16:44:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/tqGp7YHb",
      "expanded_url" : "http:\/\/lnkd.in\/vbNaD2",
      "display_url" : "lnkd.in\/vbNaD2"
    } ]
  },
  "geo" : { },
  "id_str" : "203542790590832640",
  "text" : "UBC Careers - Staff Postings http:\/\/t.co\/tqGp7YHb",
  "id" : 203542790590832640,
  "created_at" : "2012-05-18 17:49:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202524972000870400",
  "text" : "RT @etug: Registration is going strong for Just ID and ETUG Spring workshop. Don't leave it to the last minute! Go to http;\/\/etug.ca for ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "202481503488311297",
    "text" : "Registration is going strong for Just ID and ETUG Spring workshop. Don't leave it to the last minute! Go to http;\/\/etug.ca for more info.",
    "id" : 202481503488311297,
    "created_at" : "2012-05-15 19:32:07 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 202524972000870400,
  "created_at" : "2012-05-15 22:24:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202195433945174016",
  "text" : "Classifying formal vs informal learning - looks like it  is quite useful to view as a continuum. Any examples or reference suggestions?",
  "id" : 202195433945174016,
  "created_at" : "2012-05-15 00:35:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200607634947178497",
  "text" : "As much as social media is over-hyped, mobile learning is under-appreciated.",
  "id" : 200607634947178497,
  "created_at" : "2012-05-10 15:26:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/5IlXxiul",
      "expanded_url" : "http:\/\/beedie.sfu.ca\/blog\/2012\/04\/jan-kietzmann-on-designing-sfu-mobile\/",
      "display_url" : "beedie.sfu.ca\/blog\/2012\/04\/j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199634027496472576",
  "text" : "Looking forward to presenting and hearing the thoughts of students about mobile learning at Designing SFU Mobile http:\/\/t.co\/5IlXxiul",
  "id" : 199634027496472576,
  "created_at" : "2012-05-07 22:57:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]