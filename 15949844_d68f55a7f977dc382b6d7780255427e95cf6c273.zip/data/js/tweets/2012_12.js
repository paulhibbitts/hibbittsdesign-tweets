Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 3, 7 ],
      "id_str" : "1063291",
      "id" : 1063291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/kSWt3xeU",
      "expanded_url" : "http:\/\/ar.gy\/2rbb",
      "display_url" : "ar.gy\/2rbb"
    } ]
  },
  "geo" : { },
  "id_str" : "284338037327003648",
  "text" : "RT @UIE: Make your navigation on mobile screens more effective \u2022 Luke Wroblewski \u2022 January 10 Virtual Seminar \u2022 http:\/\/t.co\/kSWt3xeU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/reach.me\" rel=\"nofollow\"\u003EReach.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/kSWt3xeU",
        "expanded_url" : "http:\/\/ar.gy\/2rbb",
        "display_url" : "ar.gy\/2rbb"
      } ]
    },
    "geo" : { },
    "id_str" : "284320245651492866",
    "text" : "Make your navigation on mobile screens more effective \u2022 Luke Wroblewski \u2022 January 10 Virtual Seminar \u2022 http:\/\/t.co\/kSWt3xeU",
    "id" : 284320245651492866,
    "created_at" : "2012-12-27 15:30:03 +0000",
    "user" : {
      "name" : "UIE",
      "screen_name" : "UIE",
      "protected" : false,
      "id_str" : "1063291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3759116326\/19308cfcdb0b831111d4ee3fc3e6232c_normal.jpeg",
      "id" : 1063291,
      "verified" : false
    }
  },
  "id" : 284338037327003648,
  "created_at" : "2012-12-27 16:40:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "farhan putrananda",
      "screen_name" : "FarhanP",
      "indices" : [ 0, 8 ],
      "id_str" : "2705034932",
      "id" : 2705034932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281475891601735682",
  "geo" : { },
  "id_str" : "281542842684432384",
  "in_reply_to_user_id" : 18129659,
  "text" : "@Farhanp Thanks for your interest in my SFU course! No plans so far, but Summer or Fall 2013 is a possibility depending on dept. needs, etc.",
  "id" : 281542842684432384,
  "in_reply_to_status_id" : 281475891601735682,
  "created_at" : "2012-12-19 23:33:39 +0000",
  "in_reply_to_screen_name" : "Farhanpatel",
  "in_reply_to_user_id_str" : "18129659",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 3, 9 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280799753015525376",
  "text" : "RT @mor10: Responsive Design isn't about fitting a set of predefined screen sizes. It's about providing a great experience on all screens.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "280798692078923776",
    "text" : "Responsive Design isn't about fitting a set of predefined screen sizes. It's about providing a great experience on all screens.",
    "id" : 280798692078923776,
    "created_at" : "2012-12-17 22:16:39 +0000",
    "user" : {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "protected" : false,
      "id_str" : "14611891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764557277084782592\/wf8yMQfN_normal.jpg",
      "id" : 14611891,
      "verified" : true
    }
  },
  "id" : 280799753015525376,
  "created_at" : "2012-12-17 22:20:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Julien",
      "screen_name" : "thejordanrules",
      "indices" : [ 0, 15 ],
      "id_str" : "41398382",
      "id" : 41398382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278872502397202432",
  "geo" : { },
  "id_str" : "278922214370336768",
  "in_reply_to_user_id" : 41398382,
  "text" : "@thejordanrules Love to hear examples re: poor teaching of UX",
  "id" : 278922214370336768,
  "in_reply_to_status_id" : 278872502397202432,
  "created_at" : "2012-12-12 18:00:12 +0000",
  "in_reply_to_screen_name" : "thejordanrules",
  "in_reply_to_user_id_str" : "41398382",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UX Booth",
      "screen_name" : "UXBooth",
      "indices" : [ 89, 97 ],
      "id_str" : "16740348",
      "id" : 16740348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/11ct7EX6",
      "expanded_url" : "http:\/\/www.uxbooth.com\/articles\/stuck-in-the-details-mind-map-user-tasks\/",
      "display_url" : "uxbooth.com\/articles\/stuck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277203697677787136",
  "text" : "Stuck in the Details? Mind Map User Tasks - UX Booth | UX Booth http:\/\/t.co\/11ct7EX6 via @uxbooth &lt;- A key stakeholder collab tool for me",
  "id" : 277203697677787136,
  "created_at" : "2012-12-08 00:11:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MindMeister",
      "screen_name" : "mindmeister",
      "indices" : [ 0, 12 ],
      "id_str" : "5570982",
      "id" : 5570982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277096174819893248",
  "in_reply_to_user_id" : 5570982,
  "text" : "@mindmeister Thanks for the RT! MindMeister is my favorite way to create and share my presentation outlines.",
  "id" : 277096174819893248,
  "created_at" : "2012-12-07 17:04:10 +0000",
  "in_reply_to_screen_name" : "mindmeister",
  "in_reply_to_user_id_str" : "5570982",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/CzIMj2IM",
      "expanded_url" : "http:\/\/www.mindmeister.com\/233818108\/moodlemoot-2013-canada-mobile-learning-ux",
      "display_url" : "mindmeister.com\/233818108\/mood\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276757289682235392",
  "text" : "Outline for my Canada MoodleMoot 2013 presentation on mobile learning user experience design http:\/\/t.co\/CzIMj2IM Comments most appreciated.",
  "id" : 276757289682235392,
  "created_at" : "2012-12-06 18:37:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Spool",
      "screen_name" : "jmspool",
      "indices" : [ 3, 11 ],
      "id_str" : "849101",
      "id" : 849101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/m9DpHd74",
      "expanded_url" : "http:\/\/ar.gy\/2iAD",
      "display_url" : "ar.gy\/2iAD"
    } ]
  },
  "geo" : { },
  "id_str" : "276479118604914688",
  "text" : "RT @jmspool: Announcing the 2013 Virtual Seminar Program! http:\/\/t.co\/m9DpHd74",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/reach.me\" rel=\"nofollow\"\u003EReach.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/m9DpHd74",
        "expanded_url" : "http:\/\/ar.gy\/2iAD",
        "display_url" : "ar.gy\/2iAD"
      } ]
    },
    "geo" : { },
    "id_str" : "276355350918213632",
    "text" : "Announcing the 2013 Virtual Seminar Program! http:\/\/t.co\/m9DpHd74",
    "id" : 276355350918213632,
    "created_at" : "2012-12-05 16:00:24 +0000",
    "user" : {
      "name" : "Jared Spool",
      "screen_name" : "jmspool",
      "protected" : false,
      "id_str" : "849101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744600845199745025\/azqaoUzM_normal.jpg",
      "id" : 849101,
      "verified" : false
    }
  },
  "id" : 276479118604914688,
  "created_at" : "2012-12-06 00:12:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    }, {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 12, 20 ],
      "id_str" : "10675",
      "id" : 10675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276358296108154880",
  "geo" : { },
  "id_str" : "276370977393356800",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco @gordonr Nicely said Holly, and I certainly agree.",
  "id" : 276370977393356800,
  "in_reply_to_status_id" : 276358296108154880,
  "created_at" : "2012-12-05 17:02:30 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 3, 11 ],
      "id_str" : "10675",
      "id" : 10675
    }, {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 90, 102 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "python",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "django",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/VCXiqbGL",
      "expanded_url" : "http:\/\/www.openroad.ca\/about\/careers\/python-django-developer\/",
      "display_url" : "openroad.ca\/about\/careers\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276118630964535297",
  "text" : "RT @gordonr: Are you a Python\/Django developer? Know any talented ones? Want to work with @openroadies? Apply here: http:\/\/t.co\/VCXiqbGL ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenRoad",
        "screen_name" : "openroadies",
        "indices" : [ 77, 89 ],
        "id_str" : "66913866",
        "id" : 66913866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "python",
        "indices" : [ 124, 131 ]
      }, {
        "text" : "django",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/VCXiqbGL",
        "expanded_url" : "http:\/\/www.openroad.ca\/about\/careers\/python-django-developer\/",
        "display_url" : "openroad.ca\/about\/careers\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "276105837804654592",
    "text" : "Are you a Python\/Django developer? Know any talented ones? Want to work with @openroadies? Apply here: http:\/\/t.co\/VCXiqbGL #python #django",
    "id" : 276105837804654592,
    "created_at" : "2012-12-04 23:28:56 +0000",
    "user" : {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "protected" : false,
      "id_str" : "10675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723725303218991104\/GhSmJXhv_normal.jpg",
      "id" : 10675,
      "verified" : false
    }
  },
  "id" : 276118630964535297,
  "created_at" : "2012-12-05 00:19:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276073520436502528",
  "geo" : { },
  "id_str" : "276117808071471105",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Thanks very much Holly, it was my pleasure to get a chance to meet and chat with you! Keep in touch.",
  "id" : 276117808071471105,
  "in_reply_to_status_id" : 276073520436502528,
  "created_at" : "2012-12-05 00:16:30 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]