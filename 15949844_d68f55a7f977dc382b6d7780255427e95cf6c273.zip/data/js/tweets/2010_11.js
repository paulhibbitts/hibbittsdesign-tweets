Grailbird.data.tweets_2010_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everett McKay",
      "screen_name" : "UXDesignEdge",
      "indices" : [ 55, 68 ],
      "id_str" : "205411420",
      "id" : 205411420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8315253020430336",
  "text" : "The cost of unnecessary features http:\/\/bit.ly\/hYiyVs (@UXDesignEdge). 2 of my fav techniques: scenario-based design+progressive disclosure!",
  "id" : 8315253020430336,
  "created_at" : "2010-11-27 00:24:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7825568724688896",
  "text" : "Everyday is a good day to be thankful. Happy Thanksgiving to my American friends and followers!",
  "id" : 7825568724688896,
  "created_at" : "2010-11-25 15:58:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SharePoint2010",
      "indices" : [ 10, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6871934121811969",
  "text" : "Exploring #SharePoint2010 as a virtual learning environment for my UCD\/usability training courses. Any experiences\/feedback to share?",
  "id" : 6871934121811969,
  "created_at" : "2010-11-23 00:49:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hagan Rivers",
      "screen_name" : "haganrivers",
      "indices" : [ 126, 138 ],
      "id_str" : "11996722",
      "id" : 11996722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5771819910959104",
  "text" : "\u201CAs teachers we learn constantly. You explain something to a student, and suddenly it opens your mind, too.\u201D\u2013R.Totenberg (via @haganrivers)",
  "id" : 5771819910959104,
  "created_at" : "2010-11-19 23:58:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Goodwin",
      "screen_name" : "kimgoodwin",
      "indices" : [ 66, 77 ],
      "id_str" : "16295946",
      "id" : 16295946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4951623461773312",
  "text" : "Updated my Collaborative Scenario-based Design slides w. quote by @kimgoodwin, new web collab proto rec. + more http:\/\/slidesha.re\/9fBiYb",
  "id" : 4951623461773312,
  "created_at" : "2010-11-17 17:38:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 0, 8 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4630399682617344",
  "geo" : { },
  "id_str" : "4693923192635392",
  "in_reply_to_user_id" : 1550251,
  "text" : "@dmitryn Have not tried the iPad version yet (only Mac\/PC so far), have you? Also want to test-drive it on an Android tablet.",
  "id" : 4693923192635392,
  "in_reply_to_status_id" : 4630399682617344,
  "created_at" : "2010-11-17 00:34:53 +0000",
  "in_reply_to_screen_name" : "dmitryn",
  "in_reply_to_user_id_str" : "1550251",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4603703738761216",
  "text" : "Trying out FUZE Meeting for on-line training webinars and very impressed so far! Ability to present videos also a very useful feature.",
  "id" : 4603703738761216,
  "created_at" : "2010-11-16 18:36:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4327538356649985",
  "text" : "Having my \"box of letters\" being hosted on Facebook is so unappealing I literally do not know where to start.",
  "id" : 4327538356649985,
  "created_at" : "2010-11-16 00:19:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baldwin",
      "screen_name" : "benry",
      "indices" : [ 0, 6 ],
      "id_str" : "1969441",
      "id" : 1969441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576296677548032",
  "in_reply_to_user_id" : 1969441,
  "text" : "@benry I've been with DreamHost for the past two years and have been very happy with them. In the past they sometimes had New Years specials",
  "id" : 576296677548032,
  "created_at" : "2010-11-05 15:52:54 +0000",
  "in_reply_to_screen_name" : "benry",
  "in_reply_to_user_id_str" : "1969441",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292359115902976",
  "text" : "I &hearts; the book \"Conquering the Content: A Step-by-Step Guide to Online Course Design\". Insights for in-person teaching & learning too!",
  "id" : 292359115902976,
  "created_at" : "2010-11-04 21:04:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 0, 16 ],
      "id_str" : "17349291",
      "id" : 17349291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29620062895",
  "geo" : { },
  "id_str" : "29631672342",
  "in_reply_to_user_id" : 17349291,
  "text" : "@HabaneroConsult Fabulous news about the Intranet Innovation Award! Congratulations to everyone involved!",
  "id" : 29631672342,
  "in_reply_to_status_id" : 29620062895,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "HabaneroConsult",
  "in_reply_to_user_id_str" : "17349291",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29616979707",
  "text" : "Very impressed so far with Cacoo for real-time collaborative prototyping!",
  "id" : 29616979707,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]