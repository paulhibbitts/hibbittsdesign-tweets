Grailbird.data.tweets_2015_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649351501391990784",
  "geo" : { },
  "id_str" : "649363700915138561",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Thanks for the reminder Clint, I'm in \uD83D\uDE00 Really looking forward to it!",
  "id" : 649363700915138561,
  "in_reply_to_status_id" : 649351501391990784,
  "created_at" : "2015-09-30 23:22:25 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenEd15",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/VeB8Qo30WN",
      "expanded_url" : "http:\/\/bit.ly\/1LiavZY",
      "display_url" : "bit.ly\/1LiavZY"
    } ]
  },
  "geo" : { },
  "id_str" : "649358145177817088",
  "text" : "RT @clintlalonde: Less than 8 hours to get registered for #OpenEd15 at the early bird rate http:\/\/t.co\/VeB8Qo30WN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenEd15",
        "indices" : [ 40, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/VeB8Qo30WN",
        "expanded_url" : "http:\/\/bit.ly\/1LiavZY",
        "display_url" : "bit.ly\/1LiavZY"
      } ]
    },
    "geo" : { },
    "id_str" : "649351501391990784",
    "text" : "Less than 8 hours to get registered for #OpenEd15 at the early bird rate http:\/\/t.co\/VeB8Qo30WN",
    "id" : 649351501391990784,
    "created_at" : "2015-09-30 22:33:56 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 649358145177817088,
  "created_at" : "2015-09-30 23:00:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649336394276429825",
  "text" : "Being able to create dynamic + collaborative learning environments in the open on GitHub is an underappreciated aspect of flat-file CMS's.",
  "id" : 649336394276429825,
  "created_at" : "2015-09-30 21:33:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/I1EuU7LXBT",
      "expanded_url" : "https:\/\/education.github.com\/guide",
      "display_url" : "education.github.com\/guide"
    } ]
  },
  "geo" : { },
  "id_str" : "649334045449416705",
  "text" : "If you're an instructor you can learn more about GitHub in the classroom at https:\/\/t.co\/I1EuU7LXBT Using Orgs. as classes is brilliant! \uD83D\uDC4D",
  "id" : 649334045449416705,
  "created_at" : "2015-09-30 21:24:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649332078052413440",
  "text" : "The more I use GitHub as an open and collaborative environment with co-learners and peers the more I see it as a continuum of possibilities.",
  "id" : 649332078052413440,
  "created_at" : "2015-09-30 21:16:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/wZcPjOgKnk",
      "expanded_url" : "https:\/\/github.com\/paulhibbitts\/cmpt-363-153-website\/blob\/master\/user\/materials\/rubrics\/assignment-2\/README.md",
      "display_url" : "github.com\/paulhibbitts\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649329607783546880",
  "text" : "Leveraging GitHub README files for easier reading &amp; collaborative editing of course updates with CMPT 363 students. https:\/\/t.co\/wZcPjOgKnk",
  "id" : 649329607783546880,
  "created_at" : "2015-09-30 21:06:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/lukew\/status\/647086956061454336\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/9J4M3zebG8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPrqKEkVEAAbhEG.png",
      "id_str" : "647086955226796032",
      "id" : 647086955226796032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPrqKEkVEAAbhEG.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 148,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 2760
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9J4M3zebG8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/dU60KtHXY9",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/book\/mobile-multi-device-design\/id916423134?ls1&mt",
      "display_url" : "itunes.apple.com\/us\/book\/mobile\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648993379561308161",
  "text" : "RT @lukew: my mobile &amp; multi-device design book is free on iTunes, for you: https:\/\/t.co\/dU60KtHXY9 http:\/\/t.co\/9J4M3zebG8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lukew\/status\/647086956061454336\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/9J4M3zebG8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPrqKEkVEAAbhEG.png",
        "id_str" : "647086955226796032",
        "id" : 647086955226796032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPrqKEkVEAAbhEG.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 148,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 2760
        }, {
          "h" : 445,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9J4M3zebG8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/dU60KtHXY9",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/book\/mobile-multi-device-design\/id916423134?ls1&mt",
        "display_url" : "itunes.apple.com\/us\/book\/mobile\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "647086956061454336",
    "text" : "my mobile &amp; multi-device design book is free on iTunes, for you: https:\/\/t.co\/dU60KtHXY9 http:\/\/t.co\/9J4M3zebG8",
    "id" : 647086956061454336,
    "created_at" : "2015-09-24 16:35:27 +0000",
    "user" : {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "protected" : false,
      "id_str" : "13889622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477610446917103616\/_cjU3_ga_normal.png",
      "id" : 13889622,
      "verified" : false
    }
  },
  "id" : 648993379561308161,
  "created_at" : "2015-09-29 22:50:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/2Bi8gA0eZF",
      "expanded_url" : "https:\/\/twitter.com\/effectiveui\/status\/648942123031613441",
      "display_url" : "twitter.com\/effectiveui\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648945054027935744",
  "text" : "I've been using the SUS for over 15 years and have found it hard to beat, including other commercial options. https:\/\/t.co\/2Bi8gA0eZF",
  "id" : 648945054027935744,
  "created_at" : "2015-09-29 19:38:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "648917743085858816",
  "text" : "#SFU CMPT 363 week 3 materials, and Oct 5th class preparations, are now available on the course companion site at http:\/\/t.co\/I7fZ1cnbn3",
  "id" : 648917743085858816,
  "created_at" : "2015-09-29 17:50:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meena Kadri",
      "screen_name" : "meanestindian",
      "indices" : [ 3, 17 ],
      "id_str" : "22707348",
      "id" : 22707348
    }, {
      "name" : "IDEO",
      "screen_name" : "ideo",
      "indices" : [ 98, 103 ],
      "id_str" : "23462787",
      "id" : 23462787
    }, {
      "name" : "Matt Cooper-Wright",
      "screen_name" : "matt_speaks",
      "indices" : [ 106, 118 ],
      "id_str" : "218433827",
      "id" : 218433827
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/meanestindian\/status\/648391713849933824\/photo\/1",
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/ic0gpmReU9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP-MxsXU8AAQHvQ.png",
      "id_str" : "648391656715120640",
      "id" : 648391656715120640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP-MxsXU8AAQHvQ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 417,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 138,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 566,
        "resize" : "fit",
        "w" : 1390
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ic0gpmReU9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/Fu3D4g75sl",
      "expanded_url" : "https:\/\/medium.com\/design-research-methods\/design-research-from-interview-to-insight-part-one-summarising-the-interview-dceee9ba0969",
      "display_url" : "medium.com\/design-researc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648649558801575936",
  "text" : "RT @meanestindian: Design Research: From Interview to Insight https:\/\/t.co\/Fu3D4g75sl Fab post by @IDEO\u2019s @matt_speaks http:\/\/t.co\/ic0gpmRe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IDEO",
        "screen_name" : "ideo",
        "indices" : [ 79, 84 ],
        "id_str" : "23462787",
        "id" : 23462787
      }, {
        "name" : "Matt Cooper-Wright",
        "screen_name" : "matt_speaks",
        "indices" : [ 87, 99 ],
        "id_str" : "218433827",
        "id" : 218433827
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/meanestindian\/status\/648391713849933824\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/ic0gpmReU9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CP-MxsXU8AAQHvQ.png",
        "id_str" : "648391656715120640",
        "id" : 648391656715120640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP-MxsXU8AAQHvQ.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 417,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 138,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 566,
          "resize" : "fit",
          "w" : 1390
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ic0gpmReU9"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/Fu3D4g75sl",
        "expanded_url" : "https:\/\/medium.com\/design-research-methods\/design-research-from-interview-to-insight-part-one-summarising-the-interview-dceee9ba0969",
        "display_url" : "medium.com\/design-researc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "648391713849933824",
    "text" : "Design Research: From Interview to Insight https:\/\/t.co\/Fu3D4g75sl Fab post by @IDEO\u2019s @matt_speaks http:\/\/t.co\/ic0gpmReU9",
    "id" : 648391713849933824,
    "created_at" : "2015-09-28 07:00:05 +0000",
    "user" : {
      "name" : "Meena Kadri",
      "screen_name" : "meanestindian",
      "protected" : false,
      "id_str" : "22707348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1594230828\/bollybabe_normal.png",
      "id" : 22707348,
      "verified" : false
    }
  },
  "id" : 648649558801575936,
  "created_at" : "2015-09-29 00:04:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "indices" : [ 0, 8 ],
      "id_str" : "783092",
      "id" : 783092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648588007570698240",
  "geo" : { },
  "id_str" : "648619021198336001",
  "in_reply_to_user_id" : 783092,
  "text" : "@benwerd Lots of things to really think about in these tweets Ben. Struggling myself to share\/learn openly but yet monetize certain aspects.",
  "id" : 648619021198336001,
  "in_reply_to_status_id" : 648588007570698240,
  "created_at" : "2015-09-28 22:03:20 +0000",
  "in_reply_to_screen_name" : "benwerd",
  "in_reply_to_user_id_str" : "783092",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 10, 15 ]
    }, {
      "text" : "prolearn",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Ee5fDic31V",
      "expanded_url" : "http:\/\/bit.ly\/1OCJqRL",
      "display_url" : "bit.ly\/1OCJqRL"
    } ]
  },
  "geo" : { },
  "id_str" : "648596869162012673",
  "text" : "RT @etug: #etug Fall Call for Unconference Sessions! Join your peeps for another fun-filled day of networking http:\/\/t.co\/Ee5fDic31V #prole\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "prolearn",
        "indices" : [ 123, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/Ee5fDic31V",
        "expanded_url" : "http:\/\/bit.ly\/1OCJqRL",
        "display_url" : "bit.ly\/1OCJqRL"
      } ]
    },
    "geo" : { },
    "id_str" : "648595126831345664",
    "text" : "#etug Fall Call for Unconference Sessions! Join your peeps for another fun-filled day of networking http:\/\/t.co\/Ee5fDic31V #prolearn",
    "id" : 648595126831345664,
    "created_at" : "2015-09-28 20:28:23 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 648596869162012673,
  "created_at" : "2015-09-28 20:35:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/648554007141548032\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/4jWh0YVsXP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQAgbsaUAAAviUJ.png",
      "id_str" : "648554006491430912",
      "id" : 648554006491430912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQAgbsaUAAAviUJ.png",
      "sizes" : [ {
        "h" : 406,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 920,
        "resize" : "fit",
        "w" : 770
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 920,
        "resize" : "fit",
        "w" : 770
      } ],
      "display_url" : "pic.twitter.com\/4jWh0YVsXP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648554007141548032",
  "text" : "2nd-pass at flowchart to determine the suitability of a \"flipped-LMS\" approach. Not sure about the term... thoughts? http:\/\/t.co\/4jWh0YVsXP",
  "id" : 648554007141548032,
  "created_at" : "2015-09-28 17:44:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Frost",
      "screen_name" : "brad_frost",
      "indices" : [ 3, 14 ],
      "id_str" : "11855482",
      "id" : 11855482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/k8TfviLNWI",
      "expanded_url" : "https:\/\/playbook.cio.gov\/designstandards\/",
      "display_url" : "playbook.cio.gov\/designstandard\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/c9b1uDaMDj",
      "expanded_url" : "https:\/\/18f.gsa.gov\/2015\/09\/28\/web-design-standards\/",
      "display_url" : "18f.gsa.gov\/2015\/09\/28\/web\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648552797181313026",
  "text" : "RT @brad_frost: MY COUNTRY NOW HAS A DESIGN LANGUAGE AND PATTERN LIBRARY! Woooo! https:\/\/t.co\/k8TfviLNWI\n\nMore info: https:\/\/t.co\/c9b1uDaMDj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/k8TfviLNWI",
        "expanded_url" : "https:\/\/playbook.cio.gov\/designstandards\/",
        "display_url" : "playbook.cio.gov\/designstandard\u2026"
      }, {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/c9b1uDaMDj",
        "expanded_url" : "https:\/\/18f.gsa.gov\/2015\/09\/28\/web-design-standards\/",
        "display_url" : "18f.gsa.gov\/2015\/09\/28\/web\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "648531096959758338",
    "text" : "MY COUNTRY NOW HAS A DESIGN LANGUAGE AND PATTERN LIBRARY! Woooo! https:\/\/t.co\/k8TfviLNWI\n\nMore info: https:\/\/t.co\/c9b1uDaMDj",
    "id" : 648531096959758338,
    "created_at" : "2015-09-28 16:13:57 +0000",
    "user" : {
      "name" : "Brad Frost",
      "screen_name" : "brad_frost",
      "protected" : false,
      "id_str" : "11855482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499941427820769281\/8tYwgR5r_normal.png",
      "id" : 11855482,
      "verified" : false
    }
  },
  "id" : 648552797181313026,
  "created_at" : "2015-09-28 17:40:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648303327441121280",
  "text" : "(3\/3) ..., where deep (i.e. direct) links are provided to any required LMS elements such as discussions, assignments, grades, etc.",
  "id" : 648303327441121280,
  "created_at" : "2015-09-28 01:08:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648303289923076096",
  "text" : "(2\/3) A flipped-LMS is an approach where an open platform chosen by instructors provides an alternative front-end to their institutional LMS",
  "id" : 648303289923076096,
  "created_at" : "2015-09-28 01:08:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 113, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648303263431856132",
  "text" : "(1\/3) Working on a definition of a flipped-LMS, based on my own experiences of implementing such an approach for #SFU CMPT 363 this term:",
  "id" : 648303263431856132,
  "created_at" : "2015-09-28 01:08:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 28, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/V4gRb8kA5t",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "648260161333686272",
  "text" : "Virtual office hours for my #SFU CMPT 363 students are in full swing at http:\/\/t.co\/V4gRb8kA5t until 4:30pm today.",
  "id" : 648260161333686272,
  "created_at" : "2015-09-27 22:17:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Bovis",
      "screen_name" : "PaulBovis",
      "indices" : [ 0, 10 ],
      "id_str" : "1004346642",
      "id" : 1004346642
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 11, 19 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647570424935645184",
  "geo" : { },
  "id_str" : "647571951855099904",
  "in_reply_to_user_id" : 1004346642,
  "text" : "@PaulBovis @getgrav Thanks for the feedback Paul! Keep me posted re: LMS authentication in Grav.",
  "id" : 647571951855099904,
  "in_reply_to_status_id" : 647570424935645184,
  "created_at" : "2015-09-26 00:42:39 +0000",
  "in_reply_to_screen_name" : "PaulBovis",
  "in_reply_to_user_id_str" : "1004346642",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/647555301382598656\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/7NNWnosYt7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPyUHXgUsAA0frF.png",
      "id_str" : "647555300724092928",
      "id" : 647555300724092928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPyUHXgUsAA0frF.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 865,
        "resize" : "fit",
        "w" : 735
      }, {
        "h" : 865,
        "resize" : "fit",
        "w" : 735
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7NNWnosYt7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647555301382598656",
  "text" : "First-pass at a simple flowchart to determine the suitability of a flipped-LMS approach for instructors. Comments? http:\/\/t.co\/7NNWnosYt7",
  "id" : 647555301382598656,
  "created_at" : "2015-09-25 23:36:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 65, 73 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/1YPIEXJ2n5",
      "expanded_url" : "https:\/\/twitter.com\/alexeyzagalsky\/status\/646007340357976064",
      "display_url" : "twitter.com\/alexeyzagalsky\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647468893171113984",
  "text" : "The combination of GitHub with an open source flat-file CMS like @getgrav is an excellent example of this workflow. https:\/\/t.co\/1YPIEXJ2n5",
  "id" : 647468893171113984,
  "created_at" : "2015-09-25 17:53:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InfoWorld",
      "screen_name" : "infoworld",
      "indices" : [ 53, 63 ],
      "id_str" : "15426758",
      "id" : 15426758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/q71uXlZ2oP",
      "expanded_url" : "http:\/\/www.infoworld.com\/article\/2886828\/collaboration-software\/github-for-the-rest-of-us.html",
      "display_url" : "infoworld.com\/article\/288682\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647466355000643584",
  "text" : "GitHub for the rest of us http:\/\/t.co\/q71uXlZ2oP via @infoworld",
  "id" : 647466355000643584,
  "created_at" : "2015-09-25 17:43:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 110, 118 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 39, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647192103957565440",
  "text" : "These are a few of my favorite things\n\u25FE#SFU CMPT 363\n\u25FEMulti-device UX\/LX design\n\u25FEFlipped-LMS\n\u25FEOpen source CMS @getgrav\n\u25FETwig\n\u25FEGitHub Desktop",
  "id" : 647192103957565440,
  "created_at" : "2015-09-24 23:33:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 105, 114 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/zuPIF9YCcJ",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/online-course-companions-my-new-workflow-instructor-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/online-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647172885409173504",
  "text" : "In case you missed it earlier... \"Online Course Companions: My New (Dream) Workflow as an Instructor\" on @LinkedIn https:\/\/t.co\/zuPIF9YCcJ",
  "id" : 647172885409173504,
  "created_at" : "2015-09-24 22:16:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 29, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/3o0CHiYn5Z",
      "expanded_url" : "http:\/\/blog.usabilla.com\/user-interviews-never-ask-users-what-they-want\/",
      "display_url" : "blog.usabilla.com\/user-interview\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647158864941453312",
  "text" : "A very timely article for my #SFU CMPT 363 course as we start to explore and apply user research techniques. http:\/\/t.co\/3o0CHiYn5Z",
  "id" : 647158864941453312,
  "created_at" : "2015-09-24 21:21:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 3, 7 ],
      "id_str" : "1063291",
      "id" : 1063291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/zkgWIqbzTS",
      "expanded_url" : "http:\/\/ow.ly\/SCFji",
      "display_url" : "ow.ly\/SCFji"
    } ]
  },
  "geo" : { },
  "id_str" : "647108561990914048",
  "text" : "RT @UIE: \"All the user experience best practices in the world won't save a project...designed to solve the wrong problem.\" http:\/\/t.co\/zkgW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/zkgWIqbzTS",
        "expanded_url" : "http:\/\/ow.ly\/SCFji",
        "display_url" : "ow.ly\/SCFji"
      } ]
    },
    "geo" : { },
    "id_str" : "647096988585041920",
    "text" : "\"All the user experience best practices in the world won't save a project...designed to solve the wrong problem.\" http:\/\/t.co\/zkgWIqbzTS",
    "id" : 647096988585041920,
    "created_at" : "2015-09-24 17:15:19 +0000",
    "user" : {
      "name" : "UIE",
      "screen_name" : "UIE",
      "protected" : false,
      "id_str" : "1063291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3759116326\/19308cfcdb0b831111d4ee3fc3e6232c_normal.jpeg",
      "id" : 1063291,
      "verified" : false
    }
  },
  "id" : 647108561990914048,
  "created_at" : "2015-09-24 18:01:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "indices" : [ 3, 13 ],
      "id_str" : "18983561",
      "id" : 18983561
    }, {
      "name" : "Howard Miller",
      "screen_name" : "thepurpleblob",
      "indices" : [ 120, 134 ],
      "id_str" : "29485773",
      "id" : 29485773
    }, {
      "name" : "Gareth J Barnard",
      "screen_name" : "gjbarnard",
      "indices" : [ 141, 144 ],
      "id_str" : "290161978",
      "id" : 290161978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/f2j0o1p3V2",
      "expanded_url" : "http:\/\/Moodle.org",
      "display_url" : "Moodle.org"
    } ]
  },
  "geo" : { },
  "id_str" : "647051097656262656",
  "text" : "RT @basbrands: Finally feel confident enough to update the Moodle 2.9 bootstrap theme on http:\/\/t.co\/f2j0o1p3V2. Thanks @thepurpleblob &amp; @g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Howard Miller",
        "screen_name" : "thepurpleblob",
        "indices" : [ 105, 119 ],
        "id_str" : "29485773",
        "id" : 29485773
      }, {
        "name" : "Gareth J Barnard",
        "screen_name" : "gjbarnard",
        "indices" : [ 126, 136 ],
        "id_str" : "290161978",
        "id" : 290161978
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/f2j0o1p3V2",
        "expanded_url" : "http:\/\/Moodle.org",
        "display_url" : "Moodle.org"
      } ]
    },
    "geo" : { },
    "id_str" : "646953220582064128",
    "text" : "Finally feel confident enough to update the Moodle 2.9 bootstrap theme on http:\/\/t.co\/f2j0o1p3V2. Thanks @thepurpleblob &amp; @gjbarnard !",
    "id" : 646953220582064128,
    "created_at" : "2015-09-24 07:44:02 +0000",
    "user" : {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "protected" : false,
      "id_str" : "18983561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570499815742521344\/KPZ0dxP5_normal.png",
      "id" : 18983561,
      "verified" : false
    }
  },
  "id" : 647051097656262656,
  "created_at" : "2015-09-24 14:12:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Voorhies",
      "screen_name" : "jimvoorhies",
      "indices" : [ 0, 12 ],
      "id_str" : "14269684",
      "id" : 14269684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646780444709515264",
  "geo" : { },
  "id_str" : "646780726470246401",
  "in_reply_to_user_id" : 14269684,
  "text" : "@jimvoorhies That's awesome \uD83D\uDE00",
  "id" : 646780726470246401,
  "in_reply_to_status_id" : 646780444709515264,
  "created_at" : "2015-09-23 20:18:36 +0000",
  "in_reply_to_screen_name" : "jimvoorhies",
  "in_reply_to_user_id_str" : "14269684",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/646776960819945472\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/WPJjUs1jaA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPnQN_dUEAAg1RI.jpg",
      "id_str" : "646776960295636992",
      "id" : 646776960295636992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPnQN_dUEAAg1RI.jpg",
      "sizes" : [ {
        "h" : 345,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/WPJjUs1jaA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646776960819945472",
  "text" : "Everytime I see a iOS9 graphic in my Twitter feed I think back to the earlier Mac OS9... and yes, that is a CD-ROM. http:\/\/t.co\/WPJjUs1jaA",
  "id" : 646776960819945472,
  "created_at" : "2015-09-23 20:03:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Waterhouse",
      "screen_name" : "_natw",
      "indices" : [ 3, 9 ],
      "id_str" : "28141192",
      "id" : 28141192
    }, {
      "name" : "Ben Terrett",
      "screen_name" : "benterrett",
      "indices" : [ 49, 60 ],
      "id_str" : "58213",
      "id" : 58213
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/_natw\/status\/646736215501328385\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/cUbf5Ogihf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPmrJ2BWEAA22ua.jpg",
      "id_str" : "646736207112704000",
      "id" : 646736207112704000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPmrJ2BWEAA22ua.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/cUbf5Ogihf"
    } ],
    "hashtags" : [ {
      "text" : "Ux",
      "indices" : [ 11, 14 ]
    }, {
      "text" : "rsadesign",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646765250247815168",
  "text" : "RT @_natw: #Ux is the responsibility of everyone @benterrett #rsadesign http:\/\/t.co\/cUbf5Ogihf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Terrett",
        "screen_name" : "benterrett",
        "indices" : [ 38, 49 ],
        "id_str" : "58213",
        "id" : 58213
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/_natw\/status\/646736215501328385\/photo\/1",
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/cUbf5Ogihf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPmrJ2BWEAA22ua.jpg",
        "id_str" : "646736207112704000",
        "id" : 646736207112704000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPmrJ2BWEAA22ua.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/cUbf5Ogihf"
      } ],
      "hashtags" : [ {
        "text" : "Ux",
        "indices" : [ 0, 3 ]
      }, {
        "text" : "rsadesign",
        "indices" : [ 50, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "646736215501328385",
    "text" : "#Ux is the responsibility of everyone @benterrett #rsadesign http:\/\/t.co\/cUbf5Ogihf",
    "id" : 646736215501328385,
    "created_at" : "2015-09-23 17:21:44 +0000",
    "user" : {
      "name" : "Nathan Waterhouse",
      "screen_name" : "_natw",
      "protected" : false,
      "id_str" : "28141192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2940154899\/33472b9b18b21cfb5ca8d4dc9a6236e4_normal.jpeg",
      "id" : 28141192,
      "verified" : false
    }
  },
  "id" : 646765250247815168,
  "created_at" : "2015-09-23 19:17:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 40, 48 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/V4gRb8Cbu3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "646753253246504960",
  "text" : "Mulling options to help instructors use @getgrav CMS: intro materials\/workshops &amp; template of http:\/\/t.co\/V4gRb8Cbu3. Thoughts instructors?",
  "id" : 646753253246504960,
  "created_at" : "2015-09-23 18:29:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bajarin",
      "screen_name" : "BenBajarin",
      "indices" : [ 3, 14 ],
      "id_str" : "14546264",
      "id" : 14546264
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BenBajarin\/status\/646741787898462208\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/h1HJMFgz4v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPmwOlnWEAANNtL.png",
      "id_str" : "646741786166169600",
      "id" : 646741786166169600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPmwOlnWEAANNtL.png",
      "sizes" : [ {
        "h" : 766,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1027
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/h1HJMFgz4v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646742508119162881",
  "text" : "RT @BenBajarin: In case it wasn\u2019t clear mobile operating systems were the future. http:\/\/t.co\/h1HJMFgz4v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BenBajarin\/status\/646741787898462208\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/h1HJMFgz4v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPmwOlnWEAANNtL.png",
        "id_str" : "646741786166169600",
        "id" : 646741786166169600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPmwOlnWEAANNtL.png",
        "sizes" : [ {
          "h" : 766,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1027
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/h1HJMFgz4v"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "646741787898462208",
    "text" : "In case it wasn\u2019t clear mobile operating systems were the future. http:\/\/t.co\/h1HJMFgz4v",
    "id" : 646741787898462208,
    "created_at" : "2015-09-23 17:43:52 +0000",
    "user" : {
      "name" : "Ben Bajarin",
      "screen_name" : "BenBajarin",
      "protected" : false,
      "id_str" : "14546264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679174610315677696\/Fx4qZ9iE_normal.png",
      "id" : 14546264,
      "verified" : false
    }
  },
  "id" : 646742508119162881,
  "created_at" : "2015-09-23 17:46:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 3, 15 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/openroadies\/status\/646729482007613440\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/J3vemmmSZs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPmlCXVUsAEHHZ6.png",
      "id_str" : "646729481546149889",
      "id" : 646729481546149889,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPmlCXVUsAEHHZ6.png",
      "sizes" : [ {
        "h" : 313,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 691
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 691
      } ],
      "display_url" : "pic.twitter.com\/J3vemmmSZs"
    } ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 80, 85 ]
    }, {
      "text" : "yvr",
      "indices" : [ 86, 90 ]
    }, {
      "text" : "UX",
      "indices" : [ 91, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/KtI4mteFIw",
      "expanded_url" : "http:\/\/ow.ly\/SzSHj",
      "display_url" : "ow.ly\/SzSHj"
    } ]
  },
  "geo" : { },
  "id_str" : "646729610051190784",
  "text" : "RT @openroadies: Yup, we're hiring again! Know any amazing Senior UX Designers? #jobs #yvr #UX http:\/\/t.co\/KtI4mteFIw http:\/\/t.co\/J3vemmmSZs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/openroadies\/status\/646729482007613440\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/J3vemmmSZs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPmlCXVUsAEHHZ6.png",
        "id_str" : "646729481546149889",
        "id" : 646729481546149889,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPmlCXVUsAEHHZ6.png",
        "sizes" : [ {
          "h" : 313,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 691
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 691
        } ],
        "display_url" : "pic.twitter.com\/J3vemmmSZs"
      } ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 63, 68 ]
      }, {
        "text" : "yvr",
        "indices" : [ 69, 73 ]
      }, {
        "text" : "UX",
        "indices" : [ 74, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/KtI4mteFIw",
        "expanded_url" : "http:\/\/ow.ly\/SzSHj",
        "display_url" : "ow.ly\/SzSHj"
      } ]
    },
    "geo" : { },
    "id_str" : "646729482007613440",
    "text" : "Yup, we're hiring again! Know any amazing Senior UX Designers? #jobs #yvr #UX http:\/\/t.co\/KtI4mteFIw http:\/\/t.co\/J3vemmmSZs",
    "id" : 646729482007613440,
    "created_at" : "2015-09-23 16:54:58 +0000",
    "user" : {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "protected" : false,
      "id_str" : "66913866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554783440747237376\/HA2Svg4h_normal.png",
      "id" : 66913866,
      "verified" : false
    }
  },
  "id" : 646729610051190784,
  "created_at" : "2015-09-23 16:55:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Z5jJwFgNtL",
      "expanded_url" : "http:\/\/www.creativebloq.com\/netmag\/introduction-lean-3126388",
      "display_url" : "creativebloq.com\/netmag\/introdu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646466405064273920",
  "text" : "Several CMPT 363 students asked for info about Waterfall vs. Agile vs Lean - I like the quadrant comparison at http:\/\/t.co\/Z5jJwFgNtL",
  "id" : 646466405064273920,
  "created_at" : "2015-09-22 23:29:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 46, 58 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/jDPGx3xedn",
      "expanded_url" : "http:\/\/kck.st\/1JfEBdJ",
      "display_url" : "kck.st\/1JfEBdJ"
    } ]
  },
  "geo" : { },
  "id_str" : "646069590477307904",
  "text" : "I just backed Growing The 8 Bit Generation on @Kickstarter http:\/\/t.co\/jDPGx3xedn",
  "id" : 646069590477307904,
  "created_at" : "2015-09-21 21:12:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/646006321746055168\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Y3u35dezIw",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CPcTU4zUkAAKFoC.png",
      "id_str" : "646006321116909568",
      "id" : 646006321116909568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CPcTU4zUkAAKFoC.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/Y3u35dezIw"
    } ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 25, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/8lSr57aunk",
      "expanded_url" : "http:\/\/1drv.ms\/1KmfHpT",
      "display_url" : "1drv.ms\/1KmfHpT"
    } ]
  },
  "geo" : { },
  "id_str" : "646006321746055168",
  "text" : "I'll be introducing this #UX design process to my CMPT 363 class today. Want your own copy? http:\/\/t.co\/8lSr57aunk http:\/\/t.co\/Y3u35dezIw",
  "id" : 646006321746055168,
  "created_at" : "2015-09-21 17:01:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645757920114700288",
  "text" : "A tip to my fellow univ. instructors: assume all of your students will be accessing course materials on mobile devices &amp; design accordingly.",
  "id" : 645757920114700288,
  "created_at" : "2015-09-21 00:34:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter",
      "screen_name" : "attiks",
      "indices" : [ 3, 10 ],
      "id_str" : "26830351",
      "id" : 26830351
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 86, 94 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/aFTmxwLSZL",
      "expanded_url" : "https:\/\/attiks.com\/blog\/grav-an-alternative-for-small-drupal-sites?pk_campaign=social-links&pk_kwd=twitter",
      "display_url" : "attiks.com\/blog\/grav-an-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645682053254479872",
  "text" : "RT @attiks: Grav - An alternative for small Drupal sites? https:\/\/t.co\/aFTmxwLSZL \/cc @getgrav",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 74, 82 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/aFTmxwLSZL",
        "expanded_url" : "https:\/\/attiks.com\/blog\/grav-an-alternative-for-small-drupal-sites?pk_campaign=social-links&pk_kwd=twitter",
        "display_url" : "attiks.com\/blog\/grav-an-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644596947978993672",
    "text" : "Grav - An alternative for small Drupal sites? https:\/\/t.co\/aFTmxwLSZL \/cc @getgrav",
    "id" : 644596947978993672,
    "created_at" : "2015-09-17 19:41:03 +0000",
    "user" : {
      "name" : "Peter",
      "screen_name" : "attiks",
      "protected" : false,
      "id_str" : "26830351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1232723175\/attiks_square_normal.png",
      "id" : 26830351,
      "verified" : false
    }
  },
  "id" : 645682053254479872,
  "created_at" : "2015-09-20 19:32:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus Open",
      "screen_name" : "BCOpenText",
      "indices" : [ 3, 14 ],
      "id_str" : "3148543346",
      "id" : 3148543346
    }, {
      "name" : "Amanda Coolidge",
      "screen_name" : "acoolidge",
      "indices" : [ 42, 52 ],
      "id_str" : "17416175",
      "id" : 17416175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/qqoHw0JFBQ",
      "expanded_url" : "http:\/\/ow.ly\/SoXNY",
      "display_url" : "ow.ly\/SoXNY"
    } ]
  },
  "geo" : { },
  "id_str" : "644953969052139520",
  "text" : "RT @BCOpenText: Free hands-on workshop w\/ @acoolidge: Designing Accessible Open Educational Resources, Oct. 19th. http:\/\/t.co\/qqoHw0JFBQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Coolidge",
        "screen_name" : "acoolidge",
        "indices" : [ 26, 36 ],
        "id_str" : "17416175",
        "id" : 17416175
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/qqoHw0JFBQ",
        "expanded_url" : "http:\/\/ow.ly\/SoXNY",
        "display_url" : "ow.ly\/SoXNY"
      } ]
    },
    "geo" : { },
    "id_str" : "644949166238625792",
    "text" : "Free hands-on workshop w\/ @acoolidge: Designing Accessible Open Educational Resources, Oct. 19th. http:\/\/t.co\/qqoHw0JFBQ",
    "id" : 644949166238625792,
    "created_at" : "2015-09-18 19:00:38 +0000",
    "user" : {
      "name" : "BCcampus Open",
      "screen_name" : "BCOpenText",
      "protected" : false,
      "id_str" : "3148543346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587706251347243009\/BA0taxiM_normal.jpg",
      "id" : 3148543346,
      "verified" : false
    }
  },
  "id" : 644953969052139520,
  "created_at" : "2015-09-18 19:19:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amir Khella",
      "screen_name" : "amirkhella",
      "indices" : [ 3, 14 ],
      "id_str" : "7985762",
      "id" : 7985762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644941163703566336",
  "text" : "RT @amirkhella: \"Debugging isn't about finding and fixing a bug. It's about understanding why the bug was there in the first place\"\n-Mr Rob\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644940559677718529",
    "text" : "\"Debugging isn't about finding and fixing a bug. It's about understanding why the bug was there in the first place\"\n-Mr Robot",
    "id" : 644940559677718529,
    "created_at" : "2015-09-18 18:26:26 +0000",
    "user" : {
      "name" : "Amir Khella",
      "screen_name" : "amirkhella",
      "protected" : false,
      "id_str" : "7985762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000064136776\/0459de9b955462b2a983d29d6dcd3a90_normal.png",
      "id" : 7985762,
      "verified" : false
    }
  },
  "id" : 644941163703566336,
  "created_at" : "2015-09-18 18:28:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InteractionDesignOrg",
      "screen_name" : "interacting",
      "indices" : [ 3, 15 ],
      "id_str" : "24160604",
      "id" : 24160604
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/interacting\/status\/644787842498056192\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/B0LT80Crf6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPK_IFkW8AAff8F.jpg",
      "id_str" : "644787842321936384",
      "id" : 644787842321936384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPK_IFkW8AAff8F.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 679
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 679
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 848,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/B0LT80Crf6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/8UhH3i9ZqA",
      "expanded_url" : "https:\/\/www.interaction-design.org\/",
      "display_url" : "interaction-design.org"
    }, {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/E8KYzpBQM6",
      "expanded_url" : "https:\/\/goo.gl\/XI3XYu",
      "display_url" : "goo.gl\/XI3XYu"
    } ]
  },
  "geo" : { },
  "id_str" : "644938379444944896",
  "text" : "RT @interacting: The Interaction Design Foundation relaunched the new website!\nhttps:\/\/t.co\/8UhH3i9ZqA\n\nImg: https:\/\/t.co\/E8KYzpBQM6 http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/interacting\/status\/644787842498056192\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/B0LT80Crf6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPK_IFkW8AAff8F.jpg",
        "id_str" : "644787842321936384",
        "id" : 644787842321936384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPK_IFkW8AAff8F.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 679
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 679
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 848,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/B0LT80Crf6"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/8UhH3i9ZqA",
        "expanded_url" : "https:\/\/www.interaction-design.org\/",
        "display_url" : "interaction-design.org"
      }, {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/E8KYzpBQM6",
        "expanded_url" : "https:\/\/goo.gl\/XI3XYu",
        "display_url" : "goo.gl\/XI3XYu"
      } ]
    },
    "geo" : { },
    "id_str" : "644787842498056192",
    "text" : "The Interaction Design Foundation relaunched the new website!\nhttps:\/\/t.co\/8UhH3i9ZqA\n\nImg: https:\/\/t.co\/E8KYzpBQM6 http:\/\/t.co\/B0LT80Crf6",
    "id" : 644787842498056192,
    "created_at" : "2015-09-18 08:19:35 +0000",
    "user" : {
      "name" : "InteractionDesignOrg",
      "screen_name" : "interacting",
      "protected" : false,
      "id_str" : "24160604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/602854461166460928\/1f8QiNbN_normal.jpg",
      "id" : 24160604,
      "verified" : false
    }
  },
  "id" : 644938379444944896,
  "created_at" : "2015-09-18 18:17:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moodle News",
      "screen_name" : "moodlenews",
      "indices" : [ 10, 21 ],
      "id_str" : "96450920",
      "id" : 96450920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/JUEfdIEsfm",
      "expanded_url" : "http:\/\/www.moodlenews.com\/2015\/developing-a-course-in-the-open-with-paul-hibbitts\/",
      "display_url" : "moodlenews.com\/2015\/developin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644931386894192640",
  "text" : "Thanks to @moodlenews for recently highlighting my 2014 iMoot talk on developing a course in the open! http:\/\/t.co\/JUEfdIEsfm",
  "id" : 644931386894192640,
  "created_at" : "2015-09-18 17:49:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/644921402257072128\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/dVfnVeqdsb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPM4mQ5U8AAc-9Z.png",
      "id_str" : "644921401665712128",
      "id" : 644921401665712128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPM4mQ5U8AAc-9Z.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/dVfnVeqdsb"
    } ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 35, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/8lSr57aunk",
      "expanded_url" : "http:\/\/1drv.ms\/1KmfHpT",
      "display_url" : "1drv.ms\/1KmfHpT"
    } ]
  },
  "geo" : { },
  "id_str" : "644921402257072128",
  "text" : "Interested in using my CC-licensed #UX process\/toolkit diagram? You can now grab everything @ http:\/\/t.co\/8lSr57aunk http:\/\/t.co\/dVfnVeqdsb",
  "id" : 644921402257072128,
  "created_at" : "2015-09-18 17:10:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 3, 15 ],
      "id_str" : "66913866",
      "id" : 66913866
    }, {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 102, 118 ],
      "id_str" : "17349291",
      "id" : 17349291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/yxzHauPCGc",
      "expanded_url" : "https:\/\/twitter.com\/Van_UE\/status\/644626111826165760",
      "display_url" : "twitter.com\/Van_UE\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644674924443889664",
  "text" : "RT @openroadies: We're co-hosting the second annual Vancouver User Experience awards with our friends @HabaneroConsult. Learn more! https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Habanero",
        "screen_name" : "HabaneroConsult",
        "indices" : [ 85, 101 ],
        "id_str" : "17349291",
        "id" : 17349291
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/yxzHauPCGc",
        "expanded_url" : "https:\/\/twitter.com\/Van_UE\/status\/644626111826165760",
        "display_url" : "twitter.com\/Van_UE\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644655849101639680",
    "text" : "We're co-hosting the second annual Vancouver User Experience awards with our friends @HabaneroConsult. Learn more! https:\/\/t.co\/yxzHauPCGc",
    "id" : 644655849101639680,
    "created_at" : "2015-09-17 23:35:06 +0000",
    "user" : {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "protected" : false,
      "id_str" : "66913866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554783440747237376\/HA2Svg4h_normal.png",
      "id" : 66913866,
      "verified" : false
    }
  },
  "id" : 644674924443889664,
  "created_at" : "2015-09-18 00:50:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inspectlet",
      "screen_name" : "Inspectlet",
      "indices" : [ 19, 30 ],
      "id_str" : "282198792",
      "id" : 282198792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644667787269378048",
  "text" : "Impressed with how @Inspectlet gives quick insight of user behaviours - after watching a few recordings issue identified and now addressed.",
  "id" : 644667787269378048,
  "created_at" : "2015-09-18 00:22:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fredrik Matheson",
      "screen_name" : "movito",
      "indices" : [ 0, 7 ],
      "id_str" : "700593",
      "id" : 700593
    }, {
      "name" : "WorkFlowy",
      "screen_name" : "WorkFlowy",
      "indices" : [ 8, 18 ],
      "id_str" : "82836356",
      "id" : 82836356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/tXArLFpNeC",
      "expanded_url" : "https:\/\/workflowy.com\/s\/x5IjZIaAAP",
      "display_url" : "workflowy.com\/s\/x5IjZIaAAP"
    } ]
  },
  "in_reply_to_status_id_str" : "644630636091842560",
  "geo" : { },
  "id_str" : "644640953643347968",
  "in_reply_to_user_id" : 700593,
  "text" : "@movito @WorkFlowy Indeed. It is an web-based outliner that supports sharing and collaborative editing. An example: https:\/\/t.co\/tXArLFpNeC",
  "id" : 644640953643347968,
  "in_reply_to_status_id" : 644630636091842560,
  "created_at" : "2015-09-17 22:35:54 +0000",
  "in_reply_to_screen_name" : "movito",
  "in_reply_to_user_id_str" : "700593",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fredrik Matheson",
      "screen_name" : "movito",
      "indices" : [ 0, 7 ],
      "id_str" : "700593",
      "id" : 700593
    }, {
      "name" : "WorkFlowy",
      "screen_name" : "WorkFlowy",
      "indices" : [ 53, 63 ],
      "id_str" : "82836356",
      "id" : 82836356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644629216777117697",
  "geo" : { },
  "id_str" : "644629901430030336",
  "in_reply_to_user_id" : 700593,
  "text" : "@movito Music for sure, but these days I like to use @WorkFlowy to lay out the structure of my talks.",
  "id" : 644629901430030336,
  "in_reply_to_status_id" : 644629216777117697,
  "created_at" : "2015-09-17 21:51:59 +0000",
  "in_reply_to_screen_name" : "movito",
  "in_reply_to_user_id_str" : "700593",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 3, 19 ],
      "id_str" : "17349291",
      "id" : 17349291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 111, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/N8y3M0RGNm",
      "expanded_url" : "https:\/\/twitter.com\/Van_UE\/status\/644626111826165760",
      "display_url" : "twitter.com\/Van_UE\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644627393517219840",
  "text" : "RT @HabaneroConsult: We're proud to present the Vancouver User Experience Awards for the second straight year! #UX https:\/\/t.co\/N8y3M0RGNm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 90, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/N8y3M0RGNm",
        "expanded_url" : "https:\/\/twitter.com\/Van_UE\/status\/644626111826165760",
        "display_url" : "twitter.com\/Van_UE\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644626375576567809",
    "text" : "We're proud to present the Vancouver User Experience Awards for the second straight year! #UX https:\/\/t.co\/N8y3M0RGNm",
    "id" : 644626375576567809,
    "created_at" : "2015-09-17 21:37:59 +0000",
    "user" : {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "protected" : false,
      "id_str" : "17349291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768212660244537344\/z_mWqOrE_normal.jpg",
      "id" : 17349291,
      "verified" : false
    }
  },
  "id" : 644627393517219840,
  "created_at" : "2015-09-17 21:42:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Froelich",
      "screen_name" : "danfroelich",
      "indices" : [ 3, 15 ],
      "id_str" : "12328452",
      "id" : 12328452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/XjSk7hTkoh",
      "expanded_url" : "https:\/\/lnkd.in\/eGXdRxp",
      "display_url" : "lnkd.in\/eGXdRxp"
    } ]
  },
  "geo" : { },
  "id_str" : "644615046031626242",
  "text" : "RT @danfroelich: Want to learn more about Moodle and course design with the new responsive Snap theme?  Moodle Moot prezo here: https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/XjSk7hTkoh",
        "expanded_url" : "https:\/\/lnkd.in\/eGXdRxp",
        "display_url" : "lnkd.in\/eGXdRxp"
      } ]
    },
    "geo" : { },
    "id_str" : "639796513904857090",
    "text" : "Want to learn more about Moodle and course design with the new responsive Snap theme?  Moodle Moot prezo here: https:\/\/t.co\/XjSk7hTkoh",
    "id" : 639796513904857090,
    "created_at" : "2015-09-04 13:45:50 +0000",
    "user" : {
      "name" : "Dan Froelich",
      "screen_name" : "danfroelich",
      "protected" : false,
      "id_str" : "12328452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1143531974\/Dan300px_normal.JPG",
      "id" : 12328452,
      "verified" : false
    }
  },
  "id" : 644615046031626242,
  "created_at" : "2015-09-17 20:52:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/C56qHhA3JG",
      "expanded_url" : "http:\/\/blog.blackboard.com\/opening-the-moodle-experience\/?lang=uki",
      "display_url" : "blog.blackboard.com\/opening-the-mo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644614590991613953",
  "text" : "Opening the Moodle Experience http:\/\/t.co\/C56qHhA3JG",
  "id" : 644614590991613953,
  "created_at" : "2015-09-17 20:51:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/644612196106809344\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/N1aQBQujMR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPIfYGBUsAA57nf.png",
      "id_str" : "644612195460886528",
      "id" : 644612195460886528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPIfYGBUsAA57nf.png",
      "sizes" : [ {
        "h" : 689,
        "resize" : "fit",
        "w" : 375
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 689,
        "resize" : "fit",
        "w" : 375
      }, {
        "h" : 689,
        "resize" : "fit",
        "w" : 375
      } ],
      "display_url" : "pic.twitter.com\/N1aQBQujMR"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/644612196106809344\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/N1aQBQujMR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPIfYFmUAAA4Ula.png",
      "id_str" : "644612195347595264",
      "id" : 644612195347595264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPIfYFmUAAA4Ula.png",
      "sizes" : [ {
        "h" : 689,
        "resize" : "fit",
        "w" : 375
      }, {
        "h" : 689,
        "resize" : "fit",
        "w" : 375
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 689,
        "resize" : "fit",
        "w" : 375
      } ],
      "display_url" : "pic.twitter.com\/N1aQBQujMR"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/644612196106809344\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/N1aQBQujMR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPIfYGQUYAAc8Az.png",
      "id_str" : "644612195523780608",
      "id" : 644612195523780608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPIfYGQUYAAc8Az.png",
      "sizes" : [ {
        "h" : 625,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 689,
        "resize" : "fit",
        "w" : 375
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 689,
        "resize" : "fit",
        "w" : 375
      }, {
        "h" : 689,
        "resize" : "fit",
        "w" : 375
      } ],
      "display_url" : "pic.twitter.com\/N1aQBQujMR"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/644612196106809344\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/N1aQBQujMR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPIfX_SVEAE2HbU.png",
      "id_str" : "644612193653166081",
      "id" : 644612193653166081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPIfX_SVEAE2HbU.png",
      "sizes" : [ {
        "h" : 689,
        "resize" : "fit",
        "w" : 375
      }, {
        "h" : 689,
        "resize" : "fit",
        "w" : 375
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 689,
        "resize" : "fit",
        "w" : 375
      } ],
      "display_url" : "pic.twitter.com\/N1aQBQujMR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644612196106809344",
  "text" : "For my CMPT 363 course companion I am trying out a more conversational approach for GitHub edit links + navbar icon. http:\/\/t.co\/N1aQBQujMR",
  "id" : 644612196106809344,
  "created_at" : "2015-09-17 20:41:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Yc506d5E7U",
      "expanded_url" : "https:\/\/project-open-data.cio.gov\/policy-memo\/",
      "display_url" : "project-open-data.cio.gov\/policy-memo\/"
    } ]
  },
  "geo" : { },
  "id_str" : "644606860150988800",
  "text" : "\u2764\uFE0F use of GitHub for version-controlled collaboration of U.S. government policy - \u201CEdit this Page\" link in menubar https:\/\/t.co\/Yc506d5E7U",
  "id" : 644606860150988800,
  "created_at" : "2015-09-17 20:20:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mack Flavelle",
      "screen_name" : "MackFlavelle",
      "indices" : [ 3, 16 ],
      "id_str" : "25091677",
      "id" : 25091677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/n2TEH5T8qE",
      "expanded_url" : "http:\/\/www.meetup.com\/Vancouver-GitMasters\/",
      "display_url" : "meetup.com\/Vancouver-GitM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644603434042322946",
  "text" : "RT @MackFlavelle: I'm organizing a meetup for GitHub users who want to get more out of it. I'll bring beer and food. You come? http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/n2TEH5T8qE",
        "expanded_url" : "http:\/\/www.meetup.com\/Vancouver-GitMasters\/",
        "display_url" : "meetup.com\/Vancouver-GitM\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644559473747472384",
    "text" : "I'm organizing a meetup for GitHub users who want to get more out of it. I'll bring beer and food. You come? http:\/\/t.co\/n2TEH5T8qE",
    "id" : 644559473747472384,
    "created_at" : "2015-09-17 17:12:08 +0000",
    "user" : {
      "name" : "Mack Flavelle",
      "screen_name" : "MackFlavelle",
      "protected" : false,
      "id_str" : "25091677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636282723653414913\/5-zp8YaN_normal.jpg",
      "id" : 25091677,
      "verified" : false
    }
  },
  "id" : 644603434042322946,
  "created_at" : "2015-09-17 20:06:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 42, 50 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 66, 75 ],
      "id_str" : "180743261",
      "id" : 180743261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/zuPIF9YCcJ",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/online-course-companions-my-new-workflow-instructor-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/online-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644555849122222080",
  "text" : "1st week into my CMPT 363 course and this @getgrav CMS \u27A8 GitHub \u27A8 @deployHQ workflow is starting to really pay off: https:\/\/t.co\/zuPIF9YCcJ",
  "id" : 644555849122222080,
  "created_at" : "2015-09-17 16:57:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Jeff Eaton)))",
      "screen_name" : "eaton",
      "indices" : [ 3, 9 ],
      "id_str" : "2582861",
      "id" : 2582861
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/eaton\/status\/644551164567142401\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/KZzbjblPu2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPHn3lNVEAAGE89.png",
      "id_str" : "644551163757531136",
      "id" : 644551163757531136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPHn3lNVEAAGE89.png",
      "sizes" : [ {
        "h" : 214,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 285,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 285,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 121,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KZzbjblPu2"
    } ],
    "hashtags" : [ {
      "text" : "responsivedesign",
      "indices" : [ 84, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/810i0oJsqT",
      "expanded_url" : "http:\/\/www.imore.com\/ios-9-review#ipad",
      "display_url" : "imore.com\/ios-9-review#i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644551413482172417",
  "text" : "RT @eaton: iOS 9's multitasking features are built on the same layout principles as #responsivedesign \u2014 http:\/\/t.co\/810i0oJsqT http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/eaton\/status\/644551164567142401\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/KZzbjblPu2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPHn3lNVEAAGE89.png",
        "id_str" : "644551163757531136",
        "id" : 644551163757531136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPHn3lNVEAAGE89.png",
        "sizes" : [ {
          "h" : 214,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 285,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 285,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 121,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KZzbjblPu2"
      } ],
      "hashtags" : [ {
        "text" : "responsivedesign",
        "indices" : [ 73, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/810i0oJsqT",
        "expanded_url" : "http:\/\/www.imore.com\/ios-9-review#ipad",
        "display_url" : "imore.com\/ios-9-review#i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644551164567142401",
    "text" : "iOS 9's multitasking features are built on the same layout principles as #responsivedesign \u2014 http:\/\/t.co\/810i0oJsqT http:\/\/t.co\/KZzbjblPu2",
    "id" : 644551164567142401,
    "created_at" : "2015-09-17 16:39:07 +0000",
    "user" : {
      "name" : "(((Jeff Eaton)))",
      "screen_name" : "eaton",
      "protected" : false,
      "id_str" : "2582861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755858721373233153\/R1jV5uS6_normal.jpg",
      "id" : 2582861,
      "verified" : false
    }
  },
  "id" : 644551413482172417,
  "created_at" : "2015-09-17 16:40:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 3, 17 ],
      "id_str" : "10451462",
      "id" : 10451462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "highered",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/5rTkUd1Ugi",
      "expanded_url" : "http:\/\/theatln.tc\/1FMVXtz",
      "display_url" : "theatln.tc\/1FMVXtz"
    } ]
  },
  "geo" : { },
  "id_str" : "644284451590041600",
  "text" : "RT @catspyjamasnz: There Is No Excuse for How Universities Treat Adjuncts http:\/\/t.co\/5rTkUd1Ugi #highered",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "highered",
        "indices" : [ 78, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/5rTkUd1Ugi",
        "expanded_url" : "http:\/\/theatln.tc\/1FMVXtz",
        "display_url" : "theatln.tc\/1FMVXtz"
      } ]
    },
    "geo" : { },
    "id_str" : "644283439655600133",
    "text" : "There Is No Excuse for How Universities Treat Adjuncts http:\/\/t.co\/5rTkUd1Ugi #highered",
    "id" : 644283439655600133,
    "created_at" : "2015-09-16 22:55:16 +0000",
    "user" : {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "protected" : false,
      "id_str" : "10451462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690397421499736064\/j-HGgre5_normal.jpg",
      "id" : 10451462,
      "verified" : false
    }
  },
  "id" : 644284451590041600,
  "created_at" : "2015-09-16 22:59:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644274398136954882",
  "text" : "Welcome to 2015, iOS9! When the Shift key is engaged, the iOS 9 keyboard shows capital letters and when it's not it shows lowercase letters.",
  "id" : 644274398136954882,
  "created_at" : "2015-09-16 22:19:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644264590063173632",
  "text" : "The Graded Discussion feature of #CanvasLMS along with first requiring a post before seeing others is ideal for one-minute class summaries.",
  "id" : 644264590063173632,
  "created_at" : "2015-09-16 21:40:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 35, 43 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644256018092814336",
  "text" : "Due to my own fault I corrupted my @getgrav CMPT 363 course companion, but with the non-database design I was able to restore site &lt;5 mins \uD83D\uDC4D",
  "id" : 644256018092814336,
  "created_at" : "2015-09-16 21:06:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/VktALKkYOk",
      "expanded_url" : "http:\/\/getgrav.org\/blog\/grav-0.9.43-and-admin-0.6.0",
      "display_url" : "getgrav.org\/blog\/grav-0.9.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644228120879325185",
  "text" : "RT @getgrav: Grav 0.9.43 and Admin Plugin 0.6.0 released. As usual, some new goodies, improvements and fixes. check it out! http:\/\/t.co\/Vkt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/VktALKkYOk",
        "expanded_url" : "http:\/\/getgrav.org\/blog\/grav-0.9.43-and-admin-0.6.0",
        "display_url" : "getgrav.org\/blog\/grav-0.9.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644223328522141696",
    "text" : "Grav 0.9.43 and Admin Plugin 0.6.0 released. As usual, some new goodies, improvements and fixes. check it out! http:\/\/t.co\/VktALKkYOk",
    "id" : 644223328522141696,
    "created_at" : "2015-09-16 18:56:25 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 644228120879325185,
  "created_at" : "2015-09-16 19:15:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644182635011514368",
  "text" : "See you at 10:00AM local time today, iOS9.",
  "id" : 644182635011514368,
  "created_at" : "2015-09-16 16:14:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "indices" : [ 0, 8 ],
      "id_str" : "783092",
      "id" : 783092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643929755637559296",
  "geo" : { },
  "id_str" : "643930146831896577",
  "in_reply_to_user_id" : 783092,
  "text" : "@benwerd As an end-user Leap for me was a huge letdown, while Known was more than expected \uD83D\uDE00 Keep up the great work!",
  "id" : 643930146831896577,
  "in_reply_to_status_id" : 643929755637559296,
  "created_at" : "2015-09-15 23:31:25 +0000",
  "in_reply_to_screen_name" : "benwerd",
  "in_reply_to_user_id_str" : "783092",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 31, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643906819102871552",
  "text" : "A few spots have opened up for #SFU CMPT 363. Waitlisted students are now being contacted. Contact Cathy in the CS department for status.",
  "id" : 643906819102871552,
  "created_at" : "2015-09-15 21:58:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 4, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/I7fZ1c5Avv",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "643847841937522690",
  "text" : "All #SFU CMPT 363 week 1 materials, and week 2 preparations, are now available on the course companion site at http:\/\/t.co\/I7fZ1c5Avv",
  "id" : 643847841937522690,
  "created_at" : "2015-09-15 18:04:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 34, 38 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643846804426084353",
  "text" : "Really enjoyed the 1st session of #SFU CMPT 363. Great to see so many students share their one-minute class summaries online in #CanvasLMS.",
  "id" : 643846804426084353,
  "created_at" : "2015-09-15 18:00:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SFU OLC",
      "screen_name" : "SFU_OLC",
      "indices" : [ 3, 11 ],
      "id_str" : "17165999",
      "id" : 17165999
    }, {
      "name" : "SIAT",
      "screen_name" : "SIAT_SFU",
      "indices" : [ 61, 70 ],
      "id_str" : "45701038",
      "id" : 45701038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/hePUcclVqp",
      "expanded_url" : "http:\/\/ow.ly\/S9nkh",
      "display_url" : "ow.ly\/S9nkh"
    } ]
  },
  "geo" : { },
  "id_str" : "643570273082413056",
  "text" : "RT @SFU_OLC: What is User Experience or \"UX\"?  Find out from @SIAT_SFU student James! http:\/\/t.co\/hePUcclVqp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SIAT",
        "screen_name" : "SIAT_SFU",
        "indices" : [ 48, 57 ],
        "id_str" : "45701038",
        "id" : 45701038
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/hePUcclVqp",
        "expanded_url" : "http:\/\/ow.ly\/S9nkh",
        "display_url" : "ow.ly\/S9nkh"
      } ]
    },
    "geo" : { },
    "id_str" : "643512244014313473",
    "text" : "What is User Experience or \"UX\"?  Find out from @SIAT_SFU student James! http:\/\/t.co\/hePUcclVqp",
    "id" : 643512244014313473,
    "created_at" : "2015-09-14 19:50:49 +0000",
    "user" : {
      "name" : "SFU OLC",
      "screen_name" : "SFU_OLC",
      "protected" : false,
      "id_str" : "17165999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699344493246488576\/UirLMTs__normal.jpg",
      "id" : 17165999,
      "verified" : false
    }
  },
  "id" : 643570273082413056,
  "created_at" : "2015-09-14 23:41:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/w0TXeBz5Bf",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/cmpt-363-153-introduction-to-ux#\/",
      "display_url" : "slides.com\/paulhibbitts\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643505430665293825",
  "text" : "There are countless ways UI\/UX could be introduced to 3rd year comp science students - here is a sneak peek at mine http:\/\/t.co\/w0TXeBz5Bf",
  "id" : 643505430665293825,
  "created_at" : "2015-09-14 19:23:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Core77",
      "screen_name" : "core77",
      "indices" : [ 61, 68 ],
      "id_str" : "20236725",
      "id" : 20236725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/NaAFWXMsDe",
      "expanded_url" : "http:\/\/www.core77.com\/posts\/39867\/",
      "display_url" : "core77.com\/posts\/39867\/"
    } ]
  },
  "geo" : { },
  "id_str" : "643482962663616513",
  "text" : "The Design Firm Is (Walking) Dead http:\/\/t.co\/NaAFWXMsDe via @Core77",
  "id" : 643482962663616513,
  "created_at" : "2015-09-14 17:54:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/I7fZ1c5Avv",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "643470504796491776",
  "text" : "If you are interested in UI\/UX design you can follow the (face-to-face) course along at http:\/\/t.co\/I7fZ1c5Avv. Critical feedback welcome.",
  "id" : 643470504796491776,
  "created_at" : "2015-09-14 17:04:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 35, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643469160211709952",
  "text" : "Really looking forward to my first #SFU CMPT 363 class today with 76 students (15 are unfortunately on a waitlist).",
  "id" : 643469160211709952,
  "created_at" : "2015-09-14 16:59:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peak Usability",
      "screen_name" : "PeakUsability",
      "indices" : [ 3, 17 ],
      "id_str" : "64285327",
      "id" : 64285327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/VjuyFwWRsb",
      "expanded_url" : "https:\/\/www.punchkick.com\/blog\/2015\/08\/07\/how-apple-has-shaped-the-user-interface",
      "display_url" : "punchkick.com\/blog\/2015\/08\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643251371156738053",
  "text" : "RT @PeakUsability: How Apple has shaped the user interface - a historical timeline.\nhttps:\/\/t.co\/VjuyFwWRsb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/VjuyFwWRsb",
        "expanded_url" : "https:\/\/www.punchkick.com\/blog\/2015\/08\/07\/how-apple-has-shaped-the-user-interface",
        "display_url" : "punchkick.com\/blog\/2015\/08\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643250915558821889",
    "text" : "How Apple has shaped the user interface - a historical timeline.\nhttps:\/\/t.co\/VjuyFwWRsb",
    "id" : 643250915558821889,
    "created_at" : "2015-09-14 02:32:23 +0000",
    "user" : {
      "name" : "Peak Usability",
      "screen_name" : "PeakUsability",
      "protected" : false,
      "id_str" : "64285327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268436088\/Avatar_normal.jpg",
      "id" : 64285327,
      "verified" : false
    }
  },
  "id" : 643251371156738053,
  "created_at" : "2015-09-14 02:34:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 0, 11 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643186699036688384",
  "geo" : { },
  "id_str" : "643200875544993793",
  "in_reply_to_user_id" : 217880712,
  "text" : "@jimbobtyer One more coffee chat for the road?",
  "id" : 643200875544993793,
  "in_reply_to_status_id" : 643186699036688384,
  "created_at" : "2015-09-13 23:13:33 +0000",
  "in_reply_to_screen_name" : "jimbobtyer",
  "in_reply_to_user_id_str" : "217880712",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 49, 57 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643181236563783680",
  "text" : "The open platform, multidevice &amp; modular CMS @getgrav supports the front-end for dynamic interactions, performance support &amp; social learning",
  "id" : 643181236563783680,
  "created_at" : "2015-09-13 21:55:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643179589770973184",
  "text" : "Many key strengths of #CanvasLMS stand out with a flipped-LMS approach: peer reviews, discussions, student calendar, assignments and grades.",
  "id" : 643179589770973184,
  "created_at" : "2015-09-13 21:48:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "643177729102184448",
  "text" : "Example flipped-LMS approach w. #CanvasLMS http:\/\/t.co\/I7fZ1cnbn3 In the words of Thomas Edison, vision without execution is hallucination.",
  "id" : 643177729102184448,
  "created_at" : "2015-09-13 21:41:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643175882144612352",
  "text" : "When thinking about \"flipping\" a LMS, consider all 3 elements of Learner Experience Design:\n\u2705UX Design\n\u2705Educational Design\n\u2705Tech Development",
  "id" : 643175882144612352,
  "created_at" : "2015-09-13 21:34:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643173376492572673",
  "text" : "If your LMS supports deep-linking (i.e. links will flow through to targets with user authentication) then any instructor can \"flip\" the LMS.",
  "id" : 643173376492572673,
  "created_at" : "2015-09-13 21:24:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643172330718429184",
  "text" : "When does a flipped-LMS make sense? When BENEFIT &gt; EFFORT for students and instructors. Both are contextual and audience specific.",
  "id" : 643172330718429184,
  "created_at" : "2015-09-13 21:20:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643161075978862592",
  "text" : "When taking a flipped-LMS approach it is critical that a single URL can be provided to students as the entry point to all tools\/resources.",
  "id" : 643161075978862592,
  "created_at" : "2015-09-13 20:35:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/V4gRb8kA5t",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    }, {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/zuPIF9YCcJ",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/online-course-companions-my-new-workflow-instructor-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/online-c\u2026"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/WNJH6248Z3",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/what-problems-can-flat-file-cmss-solve-instructors-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/what-pro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642849942134886400",
  "text" : "Example course companion w. flipped-LMS approach: http:\/\/t.co\/V4gRb8kA5t Related posts: https:\/\/t.co\/zuPIF9YCcJ and https:\/\/t.co\/WNJH6248Z3",
  "id" : 642849942134886400,
  "created_at" : "2015-09-12 23:59:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Twardoch",
      "screen_name" : "adamtwar",
      "indices" : [ 3, 12 ],
      "id_str" : "2547235570",
      "id" : 2547235570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/5KxptUCNC6",
      "expanded_url" : "http:\/\/bit.ly\/adrian-frutiger-1928-2015",
      "display_url" : "bit.ly\/adrian-frutige\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642734131525259264",
  "text" : "RT @adamtwar: Farewell Adrian Frutiger (1928\u20132015) http:\/\/t.co\/5KxptUCNC6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/5KxptUCNC6",
        "expanded_url" : "http:\/\/bit.ly\/adrian-frutiger-1928-2015",
        "display_url" : "bit.ly\/adrian-frutige\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "642681356435255296",
    "text" : "Farewell Adrian Frutiger (1928\u20132015) http:\/\/t.co\/5KxptUCNC6",
    "id" : 642681356435255296,
    "created_at" : "2015-09-12 12:49:10 +0000",
    "user" : {
      "name" : "Adam Twardoch",
      "screen_name" : "adamtwar",
      "protected" : false,
      "id_str" : "2547235570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/589542857071063040\/MX-Klm8M_normal.jpg",
      "id" : 2547235570,
      "verified" : false
    }
  },
  "id" : 642734131525259264,
  "created_at" : "2015-09-12 16:18:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642469441914077184",
  "text" : "RT @getgrav: Grav 0.9.42 hotfix released to address issues with people updating Grav via admin and getting locked out.  Doesn't effect anyt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "642469306022805504",
    "text" : "Grav 0.9.42 hotfix released to address issues with people updating Grav via admin and getting locked out.  Doesn't effect anything else.",
    "id" : 642469306022805504,
    "created_at" : "2015-09-11 22:46:33 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 642469441914077184,
  "created_at" : "2015-09-11 22:47:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MURAL",
      "screen_name" : "mural",
      "indices" : [ 3, 9 ],
      "id_str" : "389544877",
      "id" : 389544877
    }, {
      "name" : "Jeff Gothelf",
      "screen_name" : "jboogie",
      "indices" : [ 43, 51 ],
      "id_str" : "9384812",
      "id" : 9384812
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mural\/status\/642434010812182528\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/CwZRllbwu1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COpiVDnW8AAIluH.jpg",
      "id_str" : "642434010740879360",
      "id" : 642434010740879360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COpiVDnW8AAIluH.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/CwZRllbwu1"
    } ],
    "hashtags" : [ {
      "text" : "LeanUX",
      "indices" : [ 60, 67 ]
    }, {
      "text" : "ux",
      "indices" : [ 125, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/byJDKfElBu",
      "expanded_url" : "http:\/\/buff.ly\/1QtABYA",
      "display_url" : "buff.ly\/1QtABYA"
    } ]
  },
  "geo" : { },
  "id_str" : "642448566842093568",
  "text" : "RT @mural: Want to observe Jeff Gothelf's (@jboogie) online #LeanUX workshop on 9\/22? Buy a seat here http:\/\/t.co\/byJDKfElBu #ux http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff Gothelf",
        "screen_name" : "jboogie",
        "indices" : [ 32, 40 ],
        "id_str" : "9384812",
        "id" : 9384812
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mural\/status\/642434010812182528\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/CwZRllbwu1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COpiVDnW8AAIluH.jpg",
        "id_str" : "642434010740879360",
        "id" : 642434010740879360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COpiVDnW8AAIluH.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/CwZRllbwu1"
      } ],
      "hashtags" : [ {
        "text" : "LeanUX",
        "indices" : [ 49, 56 ]
      }, {
        "text" : "ux",
        "indices" : [ 114, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/byJDKfElBu",
        "expanded_url" : "http:\/\/buff.ly\/1QtABYA",
        "display_url" : "buff.ly\/1QtABYA"
      } ]
    },
    "geo" : { },
    "id_str" : "642434010812182528",
    "text" : "Want to observe Jeff Gothelf's (@jboogie) online #LeanUX workshop on 9\/22? Buy a seat here http:\/\/t.co\/byJDKfElBu #ux http:\/\/t.co\/CwZRllbwu1",
    "id" : 642434010812182528,
    "created_at" : "2015-09-11 20:26:18 +0000",
    "user" : {
      "name" : "MURAL",
      "screen_name" : "mural",
      "protected" : false,
      "id_str" : "389544877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/633765435377225728\/oyKfXnrM_normal.png",
      "id" : 389544877,
      "verified" : false
    }
  },
  "id" : 642448566842093568,
  "created_at" : "2015-09-11 21:24:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/8XS8X8yyw1",
      "expanded_url" : "http:\/\/getgrav.org\/blog\/grav-0.9.41-and-admin-0.5.0",
      "display_url" : "getgrav.org\/blog\/grav-0.9.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642433909150519296",
  "text" : "RT @getgrav: Big updates today!  Grav 0.9.41 and the Admin plugin 0.5.0 released.\n\nNew features + many improvements and bug fixes http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/8XS8X8yyw1",
        "expanded_url" : "http:\/\/getgrav.org\/blog\/grav-0.9.41-and-admin-0.5.0",
        "display_url" : "getgrav.org\/blog\/grav-0.9.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "642429144194617344",
    "text" : "Big updates today!  Grav 0.9.41 and the Admin plugin 0.5.0 released.\n\nNew features + many improvements and bug fixes http:\/\/t.co\/8XS8X8yyw1",
    "id" : 642429144194617344,
    "created_at" : "2015-09-11 20:06:58 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 642433909150519296,
  "created_at" : "2015-09-11 20:25:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642421059333951488",
  "text" : "These three words to describe the outcome of my CMPT 363 UX\/UI design course are standing up to scrutiny so far: Empathetic Problem Solving",
  "id" : 642421059333951488,
  "created_at" : "2015-09-11 19:34:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/xVOW9ssSes",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=com.ebay.mobile&hl=en",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642373690043166721",
  "text" : "Looks like eBay just gave me a new case study for this term's CMPT 363 with the release of their new mobile app https:\/\/t.co\/xVOW9ssSes",
  "id" : 642373690043166721,
  "created_at" : "2015-09-11 16:26:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/WNJH6248Z3",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/what-problems-can-flat-file-cmss-solve-instructors-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/what-pro\u2026"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/zuPIF9YCcJ",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/online-course-companions-my-new-workflow-instructor-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/online-c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "642179850749415424",
  "geo" : { },
  "id_str" : "642186222102704128",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Yes, and I think it's a real game-changer. More of my thoughts here https:\/\/t.co\/WNJH6248Z3 and here https:\/\/t.co\/zuPIF9YCcJ",
  "id" : 642186222102704128,
  "in_reply_to_status_id" : 642179850749415424,
  "created_at" : "2015-09-11 04:01:41 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 46, 54 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/5Ezf5aFzpr",
      "expanded_url" : "https:\/\/github.com\/paulhibbitts\/cmpt-363-153-website",
      "display_url" : "github.com\/paulhibbitts\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642158445467058176",
  "text" : "Version .9x of my course companion built with @getgrav is also open source and available for anyone to use\/improve. https:\/\/t.co\/5Ezf5aFzpr",
  "id" : 642158445467058176,
  "created_at" : "2015-09-11 02:11:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/642157668891668480\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/w8SNHXqBoV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COlm_zmUcAAyimd.png",
      "id_str" : "642157668245729280",
      "id" : 642157668245729280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COlm_zmUcAAyimd.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/w8SNHXqBoV"
    } ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 19, 22 ]
    }, {
      "text" : "SFU",
      "indices" : [ 61, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642157668891668480",
  "text" : "Version 1.0 of the #UX design process\/toolkit diagram for my #SFU CMPT 363 course, CC-licensed for anyone to use. http:\/\/t.co\/w8SNHXqBoV",
  "id" : 642157668891668480,
  "created_at" : "2015-09-11 02:08:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HeyDesigner",
      "screen_name" : "HeyDesigner",
      "indices" : [ 3, 15 ],
      "id_str" : "564493814",
      "id" : 564493814
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HeyDesigner\/status\/641598401797353472\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/o66zgvBJ2h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COdqWKLWsAE9fBA.png",
      "id_str" : "641598400845230081",
      "id" : 641598400845230081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COdqWKLWsAE9fBA.png",
      "sizes" : [ {
        "h" : 498,
        "resize" : "fit",
        "w" : 902
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 498,
        "resize" : "fit",
        "w" : 902
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/o66zgvBJ2h"
    } ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 59, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/Bv93Uqf9t0",
      "expanded_url" : "http:\/\/thehipperelement.com\/post\/128705195169\/15-ux-commandments",
      "display_url" : "thehipperelement.com\/post\/128705195\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642153607001870336",
  "text" : "RT @HeyDesigner: 15 UX Commandments http:\/\/t.co\/Bv93Uqf9t0 #ux http:\/\/t.co\/o66zgvBJ2h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HeyDesigner\/status\/641598401797353472\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/o66zgvBJ2h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COdqWKLWsAE9fBA.png",
        "id_str" : "641598400845230081",
        "id" : 641598400845230081,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COdqWKLWsAE9fBA.png",
        "sizes" : [ {
          "h" : 498,
          "resize" : "fit",
          "w" : 902
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 498,
          "resize" : "fit",
          "w" : 902
        }, {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/o66zgvBJ2h"
      } ],
      "hashtags" : [ {
        "text" : "ux",
        "indices" : [ 42, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/Bv93Uqf9t0",
        "expanded_url" : "http:\/\/thehipperelement.com\/post\/128705195169\/15-ux-commandments",
        "display_url" : "thehipperelement.com\/post\/128705195\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641598401797353472",
    "text" : "15 UX Commandments http:\/\/t.co\/Bv93Uqf9t0 #ux http:\/\/t.co\/o66zgvBJ2h",
    "id" : 641598401797353472,
    "created_at" : "2015-09-09 13:05:53 +0000",
    "user" : {
      "name" : "HeyDesigner",
      "screen_name" : "HeyDesigner",
      "protected" : false,
      "id_str" : "564493814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631087242136682497\/djgX-nnc_normal.png",
      "id" : 564493814,
      "verified" : false
    }
  },
  "id" : 642153607001870336,
  "created_at" : "2015-09-11 01:52:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Gothelf",
      "screen_name" : "jboogie",
      "indices" : [ 3, 11 ],
      "id_str" : "9384812",
      "id" : 9384812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642134171708583936",
  "text" : "RT @jboogie: Drowning in Trello boards and Slack channels is the new drowning in email.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "642083649228308480",
    "text" : "Drowning in Trello boards and Slack channels is the new drowning in email.",
    "id" : 642083649228308480,
    "created_at" : "2015-09-10 21:14:05 +0000",
    "user" : {
      "name" : "Jeff Gothelf",
      "screen_name" : "jboogie",
      "protected" : false,
      "id_str" : "9384812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725599999644602368\/W95reVDZ_normal.jpg",
      "id" : 9384812,
      "verified" : true
    }
  },
  "id" : 642134171708583936,
  "created_at" : "2015-09-11 00:34:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642092821583892482",
  "text" : "Working on one-line summary of my CMPT 363 UI\/UX design course. So far the leading candidate is \"empathetic problem solving\" - Twitterverse?",
  "id" : 642092821583892482,
  "created_at" : "2015-09-10 21:50:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 29, 37 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 55, 64 ],
      "id_str" : "180743261",
      "id" : 180743261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/zuPIFagdBj",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/online-course-companions-my-new-workflow-instructor-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/online-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642090786209820676",
  "text" : "My new (dream) workflow with @getgrav CMS, GitHub, and @deployHQ for my online SFU course companion this year. https:\/\/t.co\/zuPIFagdBj",
  "id" : 642090786209820676,
  "created_at" : "2015-09-10 21:42:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Econ_Concepts",
      "screen_name" : "NishaEcon",
      "indices" : [ 0, 10 ],
      "id_str" : "1882362204",
      "id" : 1882362204
    }, {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 11, 17 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641846650424586240",
  "geo" : { },
  "id_str" : "642011936209530880",
  "in_reply_to_user_id" : 1882362204,
  "text" : "@NishaEcon @mor10 Thanks for sharing your experiences!",
  "id" : 642011936209530880,
  "in_reply_to_status_id" : 641846650424586240,
  "created_at" : "2015-09-10 16:29:08 +0000",
  "in_reply_to_screen_name" : "NishaEcon",
  "in_reply_to_user_id_str" : "1882362204",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 3, 7 ],
      "id_str" : "1063291",
      "id" : 1063291
    }, {
      "name" : "John Walker",
      "screen_name" : "JohnWalkerUX",
      "indices" : [ 74, 87 ],
      "id_str" : "2213045672",
      "id" : 2213045672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/cd0v553nhr",
      "expanded_url" : "http:\/\/ow.ly\/RZNUQ",
      "display_url" : "ow.ly\/RZNUQ"
    } ]
  },
  "geo" : { },
  "id_str" : "641708731579822080",
  "text" : "RT @UIE: Notes on How to combine Design Thinking and Agile in practice by @johnwalkerux http:\/\/t.co\/cd0v553nhr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Walker",
        "screen_name" : "JohnWalkerUX",
        "indices" : [ 65, 78 ],
        "id_str" : "2213045672",
        "id" : 2213045672
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/cd0v553nhr",
        "expanded_url" : "http:\/\/ow.ly\/RZNUQ",
        "display_url" : "ow.ly\/RZNUQ"
      } ]
    },
    "geo" : { },
    "id_str" : "641706484083085312",
    "text" : "Notes on How to combine Design Thinking and Agile in practice by @johnwalkerux http:\/\/t.co\/cd0v553nhr",
    "id" : 641706484083085312,
    "created_at" : "2015-09-09 20:15:22 +0000",
    "user" : {
      "name" : "UIE",
      "screen_name" : "UIE",
      "protected" : false,
      "id_str" : "1063291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3759116326\/19308cfcdb0b831111d4ee3fc3e6232c_normal.jpeg",
      "id" : 1063291,
      "verified" : false
    }
  },
  "id" : 641708731579822080,
  "created_at" : "2015-09-09 20:24:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641706248388276224",
  "text" : "Still my favorite acid test for a multi-device course companion website - is it still of value for students AFTER the course has ended?",
  "id" : 641706248388276224,
  "created_at" : "2015-09-09 20:14:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Wendkos",
      "screen_name" : "MaxWendkos",
      "indices" : [ 3, 14 ],
      "id_str" : "47243142",
      "id" : 47243142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641690058848768001",
  "text" : "RT @MaxWendkos: It\u2019s been real, Safari. See you at the next Apple product announcement.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641689539333988352",
    "text" : "It\u2019s been real, Safari. See you at the next Apple product announcement.",
    "id" : 641689539333988352,
    "created_at" : "2015-09-09 19:08:02 +0000",
    "user" : {
      "name" : "Max Wendkos",
      "screen_name" : "MaxWendkos",
      "protected" : false,
      "id_str" : "47243142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478257067455549440\/GFY0MPi8_normal.jpeg",
      "id" : 47243142,
      "verified" : false
    }
  },
  "id" : 641690058848768001,
  "created_at" : "2015-09-09 19:10:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Rubino \u2718",
      "screen_name" : "Daniel_Rubino",
      "indices" : [ 3, 17 ],
      "id_str" : "37025150",
      "id" : 37025150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641689805571493888",
  "text" : "RT @Daniel_Rubino: Cool. Apple invented Nokia's Living Images.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641686191105011712",
    "text" : "Cool. Apple invented Nokia's Living Images.",
    "id" : 641686191105011712,
    "created_at" : "2015-09-09 18:54:44 +0000",
    "user" : {
      "name" : "Daniel Rubino \u2718",
      "screen_name" : "Daniel_Rubino",
      "protected" : false,
      "id_str" : "37025150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000325363185\/8f6a9ba3e51928a8d1478a35aed8163f_normal.gif",
      "id" : 37025150,
      "verified" : false
    }
  },
  "id" : 641689805571493888,
  "created_at" : "2015-09-09 19:09:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Thurrott",
      "screen_name" : "thurrott",
      "indices" : [ 3, 12 ],
      "id_str" : "14964767",
      "id" : 14964767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641673721703346176",
  "text" : "RT @thurrott: The number of times we can say Steve jobs is rolling in his grave because of this one keynote is astonishing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641672176005959680",
    "text" : "The number of times we can say Steve jobs is rolling in his grave because of this one keynote is astonishing.",
    "id" : 641672176005959680,
    "created_at" : "2015-09-09 17:59:03 +0000",
    "user" : {
      "name" : "Paul Thurrott",
      "screen_name" : "thurrott",
      "protected" : false,
      "id_str" : "14964767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718435052779151360\/s1niU-q7_normal.jpg",
      "id" : 14964767,
      "verified" : false
    }
  },
  "id" : 641673721703346176,
  "created_at" : "2015-09-09 18:05:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Smith",
      "screen_name" : "toddsmithdesign",
      "indices" : [ 0, 16 ],
      "id_str" : "18220686",
      "id" : 18220686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641670061191618560",
  "geo" : { },
  "id_str" : "641670696477691904",
  "in_reply_to_user_id" : 18220686,
  "text" : "@toddsmithdesign That was an unbelievably brutal and ignorant demo. Very disappointed in Apple and Adobe today. But yay iPad Surface Pro!",
  "id" : 641670696477691904,
  "in_reply_to_status_id" : 641670061191618560,
  "created_at" : "2015-09-09 17:53:10 +0000",
  "in_reply_to_screen_name" : "toddsmithdesign",
  "in_reply_to_user_id_str" : "18220686",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641670115365269504",
  "text" : "I am calling it. Apple has turned into a parody of its former self.",
  "id" : 641670115365269504,
  "created_at" : "2015-09-09 17:50:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Surface",
      "screen_name" : "surface",
      "indices" : [ 3, 11 ],
      "id_str" : "612076511",
      "id" : 612076511
    }, {
      "name" : "Microsoft Office",
      "screen_name" : "Office",
      "indices" : [ 23, 30 ],
      "id_str" : "22209176",
      "id" : 22209176
    }, {
      "name" : "Adobe",
      "screen_name" : "Adobe",
      "indices" : [ 32, 38 ],
      "id_str" : "63786611",
      "id" : 63786611
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/surface\/status\/641669013349597184\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/3dvMCBtZnY",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/COeqkPxUsAA1OOv.png",
      "id_str" : "641669011609006080",
      "id" : 641669011609006080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/COeqkPxUsAA1OOv.png",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3dvMCBtZnY"
    } ],
    "hashtags" : [ {
      "text" : "Surface",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641669313636646912",
  "text" : "RT @surface: With full @Office, @Adobe, plus the ability to use apps, #Surface is all you need to get things done. http:\/\/t.co\/3dvMCBtZnY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Microsoft Office",
        "screen_name" : "Office",
        "indices" : [ 10, 17 ],
        "id_str" : "22209176",
        "id" : 22209176
      }, {
        "name" : "Adobe",
        "screen_name" : "Adobe",
        "indices" : [ 19, 25 ],
        "id_str" : "63786611",
        "id" : 63786611
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/surface\/status\/641669013349597184\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/3dvMCBtZnY",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/COeqkPxUsAA1OOv.png",
        "id_str" : "641669011609006080",
        "id" : 641669011609006080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/COeqkPxUsAA1OOv.png",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3dvMCBtZnY"
      } ],
      "hashtags" : [ {
        "text" : "Surface",
        "indices" : [ 57, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641669013349597184",
    "text" : "With full @Office, @Adobe, plus the ability to use apps, #Surface is all you need to get things done. http:\/\/t.co\/3dvMCBtZnY",
    "id" : 641669013349597184,
    "created_at" : "2015-09-09 17:46:29 +0000",
    "user" : {
      "name" : "Surface",
      "screen_name" : "surface",
      "protected" : false,
      "id_str" : "612076511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648882630612553728\/D6YeA6Nt_normal.png",
      "id" : 612076511,
      "verified" : true
    }
  },
  "id" : 641669313636646912,
  "created_at" : "2015-09-09 17:47:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adobe",
      "screen_name" : "Adobe",
      "indices" : [ 108, 114 ],
      "id_str" : "63786611",
      "id" : 63786611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/uVlr5sZ6aQ",
      "expanded_url" : "https:\/\/twitter.com\/guardiantech\/status\/641667993416675328",
      "display_url" : "twitter.com\/guardiantech\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641669125647937537",
  "text" : "Greatly disappointed in your choice of a demo this morning - was this the only thing you could come up with @Adobe? https:\/\/t.co\/uVlr5sZ6aQ",
  "id" : 641669125647937537,
  "created_at" : "2015-09-09 17:46:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pogue",
      "screen_name" : "Pogue",
      "indices" : [ 3, 9 ],
      "id_str" : "9534522",
      "id" : 9534522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "appleevent",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641665762730508288",
  "text" : "RT @Pogue: The iPad Pro can be fitted with a new, magnetic iPad screen cover with physical keys. (*cough* Microsoft Surface idea *cough*) #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "appleevent",
        "indices" : [ 127, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641664649725919232",
    "text" : "The iPad Pro can be fitted with a new, magnetic iPad screen cover with physical keys. (*cough* Microsoft Surface idea *cough*) #appleevent",
    "id" : 641664649725919232,
    "created_at" : "2015-09-09 17:29:08 +0000",
    "user" : {
      "name" : "David Pogue",
      "screen_name" : "Pogue",
      "protected" : false,
      "id_str" : "9534522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/69259417\/dp_photo__small__normal.jpg",
      "id" : 9534522,
      "verified" : true
    }
  },
  "id" : 641665762730508288,
  "created_at" : "2015-09-09 17:33:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641665569419194368",
  "text" : "This Microsoft, I mean Apple, event is really killing me. PENCIL, not PEN.",
  "id" : 641665569419194368,
  "created_at" : "2015-09-09 17:32:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Smith",
      "screen_name" : "toddsmithdesign",
      "indices" : [ 0, 16 ],
      "id_str" : "18220686",
      "id" : 18220686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641661391040962560",
  "geo" : { },
  "id_str" : "641662158103707648",
  "in_reply_to_user_id" : 18220686,
  "text" : "@toddsmithdesign BTW, I really appreciate all the information and thoughts you share about the upcoming election.",
  "id" : 641662158103707648,
  "in_reply_to_status_id" : 641661391040962560,
  "created_at" : "2015-09-09 17:19:14 +0000",
  "in_reply_to_screen_name" : "toddsmithdesign",
  "in_reply_to_user_id_str" : "18220686",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Smith",
      "screen_name" : "toddsmithdesign",
      "indices" : [ 0, 16 ],
      "id_str" : "18220686",
      "id" : 18220686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641661391040962560",
  "geo" : { },
  "id_str" : "641661938590584832",
  "in_reply_to_user_id" : 18220686,
  "text" : "@toddsmithdesign They always could have I am sure. In this multi-device world I want to watch the event on my PC while I work on my Mac \uD83D\uDE00",
  "id" : 641661938590584832,
  "in_reply_to_status_id" : 641661391040962560,
  "created_at" : "2015-09-09 17:18:22 +0000",
  "in_reply_to_screen_name" : "toddsmithdesign",
  "in_reply_to_user_id_str" : "18220686",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/641660217092997120\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/MtjBSA7RJF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COeikTkUwAAz4df.png",
      "id_str" : "641660216535203840",
      "id" : 641660216535203840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COeikTkUwAAz4df.png",
      "sizes" : [ {
        "h" : 196,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1236,
        "resize" : "fit",
        "w" : 2143
      } ],
      "display_url" : "pic.twitter.com\/MtjBSA7RJF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641660217092997120",
  "text" : "It's 2015 - at this point this is simply ridiculous. Apple, you can do better. http:\/\/t.co\/MtjBSA7RJF",
  "id" : 641660217092997120,
  "created_at" : "2015-09-09 17:11:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/641647898103406592\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/G596oSggEZ",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/COeXXQAU8AAbO1l.png",
      "id_str" : "641647897612709888",
      "id" : 641647897612709888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/COeXXQAU8AAbO1l.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/G596oSggEZ"
    } ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 31, 34 ]
    }, {
      "text" : "SFU",
      "indices" : [ 65, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641647898103406592",
  "text" : "Another round of tweaks to the #UX design process\/toolkit for my #SFU CMPT 363 course, this time as an animated GIF. http:\/\/t.co\/G596oSggEZ",
  "id" : 641647898103406592,
  "created_at" : "2015-09-09 16:22:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/D7RyEu7Ifi",
      "expanded_url" : "http:\/\/ish.re\/N5A8",
      "display_url" : "ish.re\/N5A8"
    } ]
  },
  "geo" : { },
  "id_str" : "641646951830679552",
  "text" : "How Mature is Your Organization when it Comes to UX? | UX Magazine http:\/\/t.co\/D7RyEu7Ifi &lt;- 5 level model quite a useful reference",
  "id" : 641646951830679552,
  "created_at" : "2015-09-09 16:18:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rovy Branon",
      "screen_name" : "rovybranon",
      "indices" : [ 3, 14 ],
      "id_str" : "11093162",
      "id" : 11093162
    }, {
      "name" : "Phil Hill",
      "screen_name" : "PhilOnEdTech",
      "indices" : [ 51, 64 ],
      "id_str" : "17997570",
      "id" : 17997570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/7TEtU5bdh4",
      "expanded_url" : "http:\/\/ht.ly\/3ybq24",
      "display_url" : "ht.ly\/3ybq24"
    } ]
  },
  "geo" : { },
  "id_str" : "641645557518200832",
  "text" : "RT @rovybranon: Why Moodle Matters | e-Literate by @philonedtech http:\/\/t.co\/7TEtU5bdh4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Phil Hill",
        "screen_name" : "PhilOnEdTech",
        "indices" : [ 35, 48 ],
        "id_str" : "17997570",
        "id" : 17997570
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/7TEtU5bdh4",
        "expanded_url" : "http:\/\/ht.ly\/3ybq24",
        "display_url" : "ht.ly\/3ybq24"
      } ]
    },
    "geo" : { },
    "id_str" : "641645259492036608",
    "text" : "Why Moodle Matters | e-Literate by @philonedtech http:\/\/t.co\/7TEtU5bdh4",
    "id" : 641645259492036608,
    "created_at" : "2015-09-09 16:12:05 +0000",
    "user" : {
      "name" : "Rovy Branon",
      "screen_name" : "rovybranon",
      "protected" : false,
      "id_str" : "11093162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1723902958\/Rovy_NEW_Cropped_normal.jpg",
      "id" : 11093162,
      "verified" : false
    }
  },
  "id" : 641645557518200832,
  "created_at" : "2015-09-09 16:13:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/641392862370729984\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/VrZpKOKMMi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COavaNaVEAEzSmb.png",
      "id_str" : "641392861758427137",
      "id" : 641392861758427137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COavaNaVEAEzSmb.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VrZpKOKMMi"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 10, 14 ]
    }, {
      "text" : "UX",
      "indices" : [ 62, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641392862370729984",
  "text" : "Greetings #SFU CMPT 363 students! Here is a sneak peek at the #UX design process we will be using during our course. http:\/\/t.co\/VrZpKOKMMi",
  "id" : 641392862370729984,
  "created_at" : "2015-09-08 23:29:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sameroom HQ",
      "screen_name" : "sameroomhq",
      "indices" : [ 0, 11 ],
      "id_str" : "3016611945",
      "id" : 3016611945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641389526812745728",
  "geo" : { },
  "id_str" : "641390226724618241",
  "in_reply_to_user_id" : 3016611945,
  "text" : "@sameroomhq Oh that is really good to know too, will share that info with students as well. Thanks again!",
  "id" : 641390226724618241,
  "in_reply_to_status_id" : 641389526812745728,
  "created_at" : "2015-09-08 23:18:41 +0000",
  "in_reply_to_screen_name" : "sameroomhq",
  "in_reply_to_user_id_str" : "3016611945",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sameroom HQ",
      "screen_name" : "sameroomhq",
      "indices" : [ 0, 11 ],
      "id_str" : "3016611945",
      "id" : 3016611945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641388474533220352",
  "geo" : { },
  "id_str" : "641389047370223616",
  "in_reply_to_user_id" : 3016611945,
  "text" : "@sameroomhq Thanks! So in my case for student 1-on-1 portals I will supply the needed university form for a-ok of email address storage.",
  "id" : 641389047370223616,
  "in_reply_to_status_id" : 641388474533220352,
  "created_at" : "2015-09-08 23:13:59 +0000",
  "in_reply_to_screen_name" : "sameroomhq",
  "in_reply_to_user_id_str" : "3016611945",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sameroom HQ",
      "screen_name" : "sameroomhq",
      "indices" : [ 0, 11 ],
      "id_str" : "3016611945",
      "id" : 3016611945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641387635240341504",
  "in_reply_to_user_id" : 3016611945,
  "text" : "@sameroomhq When linking an account (i.e. Slack) to a Sameroom Portal what personal info is stored? Would it just be the Slack account name?",
  "id" : 641387635240341504,
  "created_at" : "2015-09-08 23:08:23 +0000",
  "in_reply_to_screen_name" : "sameroomhq",
  "in_reply_to_user_id_str" : "3016611945",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/x9FpnCUSWY",
      "expanded_url" : "https:\/\/twitter.com\/mor10\/status\/641329313762177024",
      "display_url" : "twitter.com\/mor10\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641373414645628928",
  "text" : "I will be trying out a laptop (&amp; mobile device) ban this term in my SFU course with 75 students. Will share results. https:\/\/t.co\/x9FpnCUSWY",
  "id" : 641373414645628928,
  "created_at" : "2015-09-08 22:11:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ijGWdw0Oqz",
      "expanded_url" : "https:\/\/github.com\/wiki-hub\/wiki-hub",
      "display_url" : "github.com\/wiki-hub\/wiki-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641370350282915840",
  "text" : "Wow, what a gem of a project! Supports a wiki-style interface for sites (i.e. course companions) hosted on GitHub. https:\/\/t.co\/ijGWdw0Oqz",
  "id" : 641370350282915840,
  "created_at" : "2015-09-08 21:59:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641334234876125186",
  "geo" : { },
  "id_str" : "641339879108968448",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Thanks Glen! And I appreciated the suggestion. \u263A",
  "id" : 641339879108968448,
  "in_reply_to_status_id" : 641334234876125186,
  "created_at" : "2015-09-08 19:58:37 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 3, 9 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edu",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/0BBL3APYmw",
      "expanded_url" : "http:\/\/www.irishtimes.com\/news\/education\/is-the-pen-mightier-than-the-keyboard-for-students-1.2154226#.Ve8xwGrsrds.twitter",
      "display_url" : "irishtimes.com\/news\/education\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641328610582884356",
  "text" : "RT @mor10: Food for thought for students: Turns out taking notes on a laptop makes you less likely to learn: http:\/\/t.co\/0BBL3APYmw #edu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edu",
        "indices" : [ 121, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/0BBL3APYmw",
        "expanded_url" : "http:\/\/www.irishtimes.com\/news\/education\/is-the-pen-mightier-than-the-keyboard-for-students-1.2154226#.Ve8xwGrsrds.twitter",
        "display_url" : "irishtimes.com\/news\/education\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641328436502511617",
    "text" : "Food for thought for students: Turns out taking notes on a laptop makes you less likely to learn: http:\/\/t.co\/0BBL3APYmw #edu",
    "id" : 641328436502511617,
    "created_at" : "2015-09-08 19:13:09 +0000",
    "user" : {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "protected" : false,
      "id_str" : "14611891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764557277084782592\/wf8yMQfN_normal.jpg",
      "id" : 14611891,
      "verified" : true
    }
  },
  "id" : 641328610582884356,
  "created_at" : "2015-09-08 19:13:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 29, 37 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 55, 64 ],
      "id_str" : "180743261",
      "id" : 180743261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/zuPIF9YCcJ",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/online-course-companions-my-new-workflow-instructor-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/online-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641285085690376192",
  "text" : "My new (dream) workflow with @getgrav CMS, GitHub, and @deployHQ for online course companions this year. https:\/\/t.co\/zuPIF9YCcJ",
  "id" : 641285085690376192,
  "created_at" : "2015-09-08 16:20:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 0, 8 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640996001214427136",
  "geo" : { },
  "id_str" : "641273326619353088",
  "in_reply_to_user_id" : 2737573033,
  "text" : "@getgrav Thanks so much, couldn't have done it without you! \uD83D\uDE00",
  "id" : 641273326619353088,
  "in_reply_to_status_id" : 640996001214427136,
  "created_at" : "2015-09-08 15:34:10 +0000",
  "in_reply_to_screen_name" : "getgrav",
  "in_reply_to_user_id_str" : "2737573033",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641060686680866816",
  "text" : "Pro tip: The first day of your class sets student expectations all term long - present less and interact more.",
  "id" : 641060686680866816,
  "created_at" : "2015-09-08 01:29:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 101, 109 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/p2auPXReSD",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1jM4fIHqKdihbAW1SqMAAcegM43pEusZuuu8sWge_ePw\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1jM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641020305008295936",
  "text" : "Sneak peek at a new upcoming article about my workflow for a flipped-LMS approach with the flat-file @getgrav CMS https:\/\/t.co\/p2auPXReSD",
  "id" : 641020305008295936,
  "created_at" : "2015-09-07 22:48:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 107, 115 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640995725539540992",
  "text" : "Completely energized about the new school term starting tomorrow, and almost finished a blog post about my @getgrav workflow to boot.",
  "id" : 640995725539540992,
  "created_at" : "2015-09-07 21:11:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/p2auPXReSD",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1jM4fIHqKdihbAW1SqMAAcegM43pEusZuuu8sWge_ePw\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1jM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640995052005691392",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard It's almost done \uD83D\uDE00 https:\/\/t.co\/p2auPXReSD",
  "id" : 640995052005691392,
  "created_at" : "2015-09-07 21:08:24 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MeasuringU",
      "screen_name" : "MeasuringU",
      "indices" : [ 3, 14 ],
      "id_str" : "103951768",
      "id" : 103951768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/KnS66tzUOp",
      "expanded_url" : "http:\/\/ow.ly\/RKPas",
      "display_url" : "ow.ly\/RKPas"
    } ]
  },
  "geo" : { },
  "id_str" : "640225191436484608",
  "text" : "RT @MeasuringU: Are Users The New Designers? (UX Booth) http:\/\/t.co\/KnS66tzUOp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/KnS66tzUOp",
        "expanded_url" : "http:\/\/ow.ly\/RKPas",
        "display_url" : "ow.ly\/RKPas"
      } ]
    },
    "geo" : { },
    "id_str" : "640223481305677824",
    "text" : "Are Users The New Designers? (UX Booth) http:\/\/t.co\/KnS66tzUOp",
    "id" : 640223481305677824,
    "created_at" : "2015-09-05 18:02:27 +0000",
    "user" : {
      "name" : "MeasuringU",
      "screen_name" : "MeasuringU",
      "protected" : false,
      "id_str" : "103951768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768568168553910272\/Qigu06V6_normal.jpg",
      "id" : 103951768,
      "verified" : false
    }
  },
  "id" : 640225191436484608,
  "created_at" : "2015-09-05 18:09:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rovy Branon",
      "screen_name" : "rovybranon",
      "indices" : [ 3, 14 ],
      "id_str" : "11093162",
      "id" : 11093162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/8nkroj5iwR",
      "expanded_url" : "http:\/\/ht.ly\/3yanaF",
      "display_url" : "ht.ly\/3yanaF"
    } ]
  },
  "geo" : { },
  "id_str" : "640200933331173376",
  "text" : "RT @rovybranon: UMUC to Go Textbook-Free | InsideHigherEd http:\/\/t.co\/8nkroj5iwR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/8nkroj5iwR",
        "expanded_url" : "http:\/\/ht.ly\/3yanaF",
        "display_url" : "ht.ly\/3yanaF"
      } ]
    },
    "geo" : { },
    "id_str" : "640195500516507648",
    "text" : "UMUC to Go Textbook-Free | InsideHigherEd http:\/\/t.co\/8nkroj5iwR",
    "id" : 640195500516507648,
    "created_at" : "2015-09-05 16:11:16 +0000",
    "user" : {
      "name" : "Rovy Branon",
      "screen_name" : "rovybranon",
      "protected" : false,
      "id_str" : "11093162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1723902958\/Rovy_NEW_Cropped_normal.jpg",
      "id" : 11093162,
      "verified" : false
    }
  },
  "id" : 640200933331173376,
  "created_at" : "2015-09-05 16:32:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moodle News",
      "screen_name" : "moodlenews",
      "indices" : [ 3, 14 ],
      "id_str" : "96450920",
      "id" : 96450920
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moodle",
      "indices" : [ 82, 89 ]
    }, {
      "text" : "moodlenews",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/sAEzTuensY",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=NjtqPTblu0w",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    }, {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/X4OsQZj8w4",
      "expanded_url" : "http:\/\/www.moodlenews.com\/2015\/developing-a-course-in-the-open-with-paul-hibbitts\/",
      "display_url" : "moodlenews.com\/2015\/developin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639958888079474688",
  "text" : "RT @moodlenews: Reflections on Developing a Course in the Open with Paul Hibbitts #moodle #moodlenews http:\/\/t.co\/sAEzTuensY http:\/\/t.co\/X4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "moodle",
        "indices" : [ 66, 73 ]
      }, {
        "text" : "moodlenews",
        "indices" : [ 74, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/sAEzTuensY",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=NjtqPTblu0w",
        "display_url" : "youtube.com\/watch?feature=\u2026"
      }, {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/X4OsQZj8w4",
        "expanded_url" : "http:\/\/www.moodlenews.com\/2015\/developing-a-course-in-the-open-with-paul-hibbitts\/",
        "display_url" : "moodlenews.com\/2015\/developin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639800167340732420",
    "text" : "Reflections on Developing a Course in the Open with Paul Hibbitts #moodle #moodlenews http:\/\/t.co\/sAEzTuensY http:\/\/t.co\/X4OsQZj8w4",
    "id" : 639800167340732420,
    "created_at" : "2015-09-04 14:00:21 +0000",
    "user" : {
      "name" : "Moodle News",
      "screen_name" : "moodlenews",
      "protected" : false,
      "id_str" : "96450920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/889559056\/moodlenewsicon_normal.png",
      "id" : 96450920,
      "verified" : false
    }
  },
  "id" : 639958888079474688,
  "created_at" : "2015-09-05 00:31:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 18, 23 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "proflearn",
      "indices" : [ 127, 137 ]
    }, {
      "text" : "etug",
      "indices" : [ 138, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/DTfhu2OI8y",
      "expanded_url" : "http:\/\/bit.ly\/1PQsxjB",
      "display_url" : "bit.ly\/1PQsxjB"
    } ]
  },
  "geo" : { },
  "id_str" : "639949962889920512",
  "text" : "RT @BCcampus: The @ETUG Fall Workshop date has been announced! Hold the date &gt; Nov. 6! For more info http:\/\/t.co\/DTfhu2OI8y #proflearn #etug",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 4, 9 ],
        "id_str" : "17102936",
        "id" : 17102936
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "proflearn",
        "indices" : [ 113, 123 ]
      }, {
        "text" : "etug",
        "indices" : [ 124, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/DTfhu2OI8y",
        "expanded_url" : "http:\/\/bit.ly\/1PQsxjB",
        "display_url" : "bit.ly\/1PQsxjB"
      } ]
    },
    "geo" : { },
    "id_str" : "639948604665409537",
    "text" : "The @ETUG Fall Workshop date has been announced! Hold the date &gt; Nov. 6! For more info http:\/\/t.co\/DTfhu2OI8y #proflearn #etug",
    "id" : 639948604665409537,
    "created_at" : "2015-09-04 23:50:11 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 639949962889920512,
  "created_at" : "2015-09-04 23:55:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neela Bell",
      "screen_name" : "neela_bell",
      "indices" : [ 3, 14 ],
      "id_str" : "2282119621",
      "id" : 2282119621
    }, {
      "name" : "Connie Malamed",
      "screen_name" : "elearningcoach",
      "indices" : [ 93, 108 ],
      "id_str" : "38082026",
      "id" : 38082026
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/neela_bell\/status\/639450279440711680\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/9OE2tGw3Dt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN_IpB_WwAAKASW.png",
      "id_str" : "639450279344259072",
      "id" : 639450279344259072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN_IpB_WwAAKASW.png",
      "sizes" : [ {
        "h" : 177,
        "resize" : "fit",
        "w" : 310
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 310
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 310
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 310
      } ],
      "display_url" : "pic.twitter.com\/9OE2tGw3Dt"
    } ],
    "hashtags" : [ {
      "text" : "elearning",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/dQlK3KVLFg",
      "expanded_url" : "http:\/\/buff.ly\/1NV6Xfn",
      "display_url" : "buff.ly\/1NV6Xfn"
    } ]
  },
  "geo" : { },
  "id_str" : "639669266401226752",
  "text" : "RT @neela_bell: Why Aesthetics Matter to Learning - Back by Research  http:\/\/t.co\/dQlK3KVLFg @elearningcoach #elearning http:\/\/t.co\/9OE2tGw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Connie Malamed",
        "screen_name" : "elearningcoach",
        "indices" : [ 77, 92 ],
        "id_str" : "38082026",
        "id" : 38082026
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/neela_bell\/status\/639450279440711680\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/9OE2tGw3Dt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN_IpB_WwAAKASW.png",
        "id_str" : "639450279344259072",
        "id" : 639450279344259072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN_IpB_WwAAKASW.png",
        "sizes" : [ {
          "h" : 177,
          "resize" : "fit",
          "w" : 310
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 310
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 310
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 310
        } ],
        "display_url" : "pic.twitter.com\/9OE2tGw3Dt"
      } ],
      "hashtags" : [ {
        "text" : "elearning",
        "indices" : [ 93, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/dQlK3KVLFg",
        "expanded_url" : "http:\/\/buff.ly\/1NV6Xfn",
        "display_url" : "buff.ly\/1NV6Xfn"
      } ]
    },
    "geo" : { },
    "id_str" : "639450279440711680",
    "text" : "Why Aesthetics Matter to Learning - Back by Research  http:\/\/t.co\/dQlK3KVLFg @elearningcoach #elearning http:\/\/t.co\/9OE2tGw3Dt",
    "id" : 639450279440711680,
    "created_at" : "2015-09-03 14:50:01 +0000",
    "user" : {
      "name" : "Neela Bell",
      "screen_name" : "neela_bell",
      "protected" : false,
      "id_str" : "2282119621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500358118056816641\/gqUCh-xl_normal.jpeg",
      "id" : 2282119621,
      "verified" : false
    }
  },
  "id" : 639669266401226752,
  "created_at" : "2015-09-04 05:20:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639262412005249024",
  "geo" : { },
  "id_str" : "639503590994808833",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Just posted a series of user stories which serve as the requirements for my workflow - are these relatable to you too? Thanks!",
  "id" : 639503590994808833,
  "in_reply_to_status_id" : 639262412005249024,
  "created_at" : "2015-09-03 18:21:52 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639501908785238016",
  "text" : "(6\/6) As a teacher, I want to quickly update the live course companion site so that I spend a minimum of time with non-productive tasks.",
  "id" : 639501908785238016,
  "created_at" : "2015-09-03 18:15:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639501692615065600",
  "text" : "(5\/6) As a teacher, I want to control updates to the course companion site so that the risk of not being available to students is minimized.",
  "id" : 639501692615065600,
  "created_at" : "2015-09-03 18:14:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639501652328734720",
  "text" : "(4\/6) As a teacher, I want to share course companion content and code so that others can reuse and adapt the materials to their own needs.",
  "id" : 639501652328734720,
  "created_at" : "2015-09-03 18:14:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639501615884402688",
  "text" : "(3\/6) As a teacher, I want to enable my students to be contributors to the course companion so we can all benefit from their knowledge.",
  "id" : 639501615884402688,
  "created_at" : "2015-09-03 18:14:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639501583558905856",
  "text" : "(2\/6) As a teacher, I want to be able to edit the course companion on any of my devices so I can make changes when most convenient for me.",
  "id" : 639501583558905856,
  "created_at" : "2015-09-03 18:13:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 77, 85 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 103, 112 ],
      "id_str" : "180743261",
      "id" : 180743261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639501535911677953",
  "text" : "(1\/6) Some user stories as a preamble to describing my current workflow with @getgrav CMS, GitHub, and @deployHQ for my course companion:",
  "id" : 639501535911677953,
  "created_at" : "2015-09-03 18:13:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 0, 9 ],
      "id_str" : "180743261",
      "id" : 180743261
    }, {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 10, 21 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639346107957514240",
  "geo" : { },
  "id_str" : "639463198349914112",
  "in_reply_to_user_id" : 180743261,
  "text" : "@deployhq @gcoulthard Thanks for the encouragement :-) I will see what I can come up with...",
  "id" : 639463198349914112,
  "in_reply_to_status_id" : 639346107957514240,
  "created_at" : "2015-09-03 15:41:21 +0000",
  "in_reply_to_screen_name" : "deployhq",
  "in_reply_to_user_id_str" : "180743261",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 3, 14 ],
      "id_str" : "10876852",
      "id" : 10876852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheNextWeb\/status\/638829566329421824\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/29hdtK0Bdr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN2TjveUsAAZO0W.jpg",
      "id_str" : "638828964404834304",
      "id" : 638828964404834304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN2TjveUsAAZO0W.jpg",
      "sizes" : [ {
        "h" : 1025,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1081,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/29hdtK0Bdr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639298014855585792",
  "text" : "RT @TheNextWeb: Happy 15th Birthday Nokia\u200B 3310 \uD83C\uDF82\n- 84x84 monochrome screen\n- Bulletproof build quality\n- Week-long battery\n- Snake \uD83D\uDC4D http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheNextWeb\/status\/638829566329421824\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/29hdtK0Bdr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN2TjveUsAAZO0W.jpg",
        "id_str" : "638828964404834304",
        "id" : 638828964404834304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN2TjveUsAAZO0W.jpg",
        "sizes" : [ {
          "h" : 1025,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1081,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/29hdtK0Bdr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638829566329421824",
    "text" : "Happy 15th Birthday Nokia\u200B 3310 \uD83C\uDF82\n- 84x84 monochrome screen\n- Bulletproof build quality\n- Week-long battery\n- Snake \uD83D\uDC4D http:\/\/t.co\/29hdtK0Bdr",
    "id" : 638829566329421824,
    "created_at" : "2015-09-01 21:43:32 +0000",
    "user" : {
      "name" : "The Next Web \uD83C\uDF0D\uD83D\uDCBB\uD83D\uDCF1",
      "screen_name" : "TheNextWeb",
      "protected" : false,
      "id_str" : "10876852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712955373557325824\/CZ2ne8yK_normal.jpg",
      "id" : 10876852,
      "verified" : true
    }
  },
  "id" : 639298014855585792,
  "created_at" : "2015-09-03 04:44:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krista Lambert",
      "screen_name" : "contentkrista",
      "indices" : [ 0, 14 ],
      "id_str" : "166647816",
      "id" : 166647816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639205876507607041",
  "geo" : { },
  "id_str" : "639209934844878848",
  "in_reply_to_user_id" : 166647816,
  "text" : "@contentkrista Thanks Krista! I've got my work cut out\u00A0for me \uD83D\uDE04",
  "id" : 639209934844878848,
  "in_reply_to_status_id" : 639205876507607041,
  "created_at" : "2015-09-02 22:54:59 +0000",
  "in_reply_to_screen_name" : "contentkrista",
  "in_reply_to_user_id_str" : "166647816",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 57, 65 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 80, 89 ],
      "id_str" : "180743261",
      "id" : 180743261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639208815842447360",
  "text" : "I've created a learning environment that I love using w. @getgrav, GitHub &amp; @deployhq. In 1.5 weeks I can see how my students feel about it!",
  "id" : 639208815842447360,
  "created_at" : "2015-09-02 22:50:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639207960611319808",
  "text" : "Likewise, can an instructor love their digital learning environment like they do a favorite song or book? That greatly affects students too.",
  "id" : 639207960611319808,
  "created_at" : "2015-09-02 22:47:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639200841984028673",
  "text" : "Can a student love their digital learning environment like they do a favorite song or book? That's where I want to get to.",
  "id" : 639200841984028673,
  "created_at" : "2015-09-02 22:18:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Hill",
      "screen_name" : "PhilOnEdTech",
      "indices" : [ 3, 16 ],
      "id_str" : "17997570",
      "id" : 17997570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/74EJRPJOvs",
      "expanded_url" : "http:\/\/mfeldstein.com\/interview-with-martin-dougiamas-on-changes-to-moodle-community-this-year\/",
      "display_url" : "mfeldstein.com\/interview-with\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/LfZmgUeeip",
      "expanded_url" : "http:\/\/mfeldstein.com\/breaking-totara-lms-forks-from-moodle-and-changes-relationship\/",
      "display_url" : "mfeldstein.com\/breaking-totar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639199488918319105",
  "text" : "RT @PhilOnEdTech: Moodle changes: interview with Martin Dougiamas http:\/\/t.co\/74EJRPJOvs and Totara LMS forking from Moodle core http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/74EJRPJOvs",
        "expanded_url" : "http:\/\/mfeldstein.com\/interview-with-martin-dougiamas-on-changes-to-moodle-community-this-year\/",
        "display_url" : "mfeldstein.com\/interview-with\u2026"
      }, {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/LfZmgUeeip",
        "expanded_url" : "http:\/\/mfeldstein.com\/breaking-totara-lms-forks-from-moodle-and-changes-relationship\/",
        "display_url" : "mfeldstein.com\/breaking-totar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639192740601839616",
    "text" : "Moodle changes: interview with Martin Dougiamas http:\/\/t.co\/74EJRPJOvs and Totara LMS forking from Moodle core http:\/\/t.co\/LfZmgUeeip",
    "id" : 639192740601839616,
    "created_at" : "2015-09-02 21:46:39 +0000",
    "user" : {
      "name" : "Phil Hill",
      "screen_name" : "PhilOnEdTech",
      "protected" : false,
      "id_str" : "17997570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700491582714179584\/nxqFbWXh_normal.jpg",
      "id" : 17997570,
      "verified" : false
    }
  },
  "id" : 639199488918319105,
  "created_at" : "2015-09-02 22:13:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/639142569918640128\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/PGskqTpZtx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN6wx8XUEAEnDBY.png",
      "id_str" : "639142569197178881",
      "id" : 639142569197178881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN6wx8XUEAEnDBY.png",
      "sizes" : [ {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 912,
        "resize" : "fit",
        "w" : 1392
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PGskqTpZtx"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/639142569918640128\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/PGskqTpZtx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN6wx80VAAAQmYj.png",
      "id_str" : "639142569318875136",
      "id" : 639142569318875136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN6wx80VAAAQmYj.png",
      "sizes" : [ {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 912,
        "resize" : "fit",
        "w" : 1392
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PGskqTpZtx"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/639142569918640128\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/PGskqTpZtx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN6wx4GU8AAboQ0.png",
      "id_str" : "639142568052191232",
      "id" : 639142568052191232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN6wx4GU8AAboQ0.png",
      "sizes" : [ {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 912,
        "resize" : "fit",
        "w" : 1392
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PGskqTpZtx"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/639142569918640128\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/PGskqTpZtx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN6wx4iUYAAUhEf.png",
      "id_str" : "639142568169594880",
      "id" : 639142568169594880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN6wx4iUYAAUhEf.png",
      "sizes" : [ {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 912,
        "resize" : "fit",
        "w" : 1392
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PGskqTpZtx"
    } ],
    "hashtags" : [ {
      "text" : "opened",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639142569918640128",
  "text" : "A flat-file CMS + GitHub = collaborative editing of content &amp; behavior (code) for dynamic learning platforms #opened http:\/\/t.co\/PGskqTpZtx",
  "id" : 639142569918640128,
  "created_at" : "2015-09-02 18:27:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638896506460745730",
  "geo" : { },
  "id_str" : "638897109576486912",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc It's been a great learning experience for me, now let's see how it all works with my students!",
  "id" : 638897109576486912,
  "in_reply_to_status_id" : 638896506460745730,
  "created_at" : "2015-09-02 02:11:55 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638894203678818304",
  "geo" : { },
  "id_str" : "638896694252335104",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc I wish I could have more control over the visual appearance of Canvas side of things though, but c'est la vie \uD83D\uDE09",
  "id" : 638896694252335104,
  "in_reply_to_status_id" : 638894203678818304,
  "created_at" : "2015-09-02 02:10:16 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Ru08uba2HJ",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/home\/week-01",
      "display_url" : "cmpt-363-153.hibbittsdesign.com\/home\/week-01"
    } ]
  },
  "in_reply_to_status_id_str" : "638894203678818304",
  "geo" : { },
  "id_str" : "638896456800186368",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc It's a shame BB doesn't. Here is an example page with direct links to a forum (thread) and assignment http:\/\/t.co\/Ru08uba2HJ",
  "id" : 638896456800186368,
  "in_reply_to_status_id" : 638894203678818304,
  "created_at" : "2015-09-02 02:09:20 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638893942319087616",
  "geo" : { },
  "id_str" : "638895294831181824",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Indeed \uD83D\uDE1F With support of direct links (as Canvas has) you can make the transition between the systems almost seamless.",
  "id" : 638895294831181824,
  "in_reply_to_status_id" : 638893942319087616,
  "created_at" : "2015-09-02 02:04:43 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638891214968741888",
  "geo" : { },
  "id_str" : "638892085530066944",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Instead of the LMS being the front-end, and likely holding almost (if not all) content and functions. How does that sound?",
  "id" : 638892085530066944,
  "in_reply_to_status_id" : 638891214968741888,
  "created_at" : "2015-09-02 01:51:57 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638891214968741888",
  "geo" : { },
  "id_str" : "638891863840157696",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc To me it means that anything can be used by the instructor for on-line course front-end, with direct links to LMS as needed.",
  "id" : 638891863840157696,
  "in_reply_to_status_id" : 638891214968741888,
  "created_at" : "2015-09-02 01:51:05 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Whitby",
      "screen_name" : "tomwhitby",
      "indices" : [ 3, 13 ],
      "id_str" : "17762060",
      "id" : 17762060
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Edchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638856513340051456",
  "text" : "RT @tomwhitby: If innovation is truly a desired outcome, how is it specifically supported and encouraged in the system other than empty pla\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Edchat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638855070122135552",
    "text" : "If innovation is truly a desired outcome, how is it specifically supported and encouraged in the system other than empty platitudes? #Edchat",
    "id" : 638855070122135552,
    "created_at" : "2015-09-01 23:24:52 +0000",
    "user" : {
      "name" : "Tom Whitby",
      "screen_name" : "tomwhitby",
      "protected" : false,
      "id_str" : "17762060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601591035\/twitter_pic_1__normal.jpg",
      "id" : 17762060,
      "verified" : false
    }
  },
  "id" : 638856513340051456,
  "created_at" : "2015-09-01 23:30:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638836696352579588",
  "text" : "The purpose of a flipped-LMS approach should be to not only (significantly) improve the learner experience but ALSO that of the instructor.",
  "id" : 638836696352579588,
  "created_at" : "2015-09-01 22:11:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 60, 68 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/V4gRb8kA5t",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "638834493067890688",
  "text" : "Interested in exploring a flipped-LMS approach? Explore the @getgrav CMS front-end http:\/\/t.co\/V4gRb8kA5t w. links to all needed LMS items.",
  "id" : 638834493067890688,
  "created_at" : "2015-09-01 22:03:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 115, 123 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638831849972723712",
  "text" : "My flipped-LMS approach for this term will be using the open source, flat-file (no DB), multi-device &amp; modular @getgrav CMS + #CanvasLMS.",
  "id" : 638831849972723712,
  "created_at" : "2015-09-01 21:52:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/638829288435806208\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/DoQEanmmmd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN2T2hNVEAUksgI.png",
      "id_str" : "638829286992973829",
      "id" : 638829286992973829,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN2T2hNVEAUksgI.png",
      "sizes" : [ {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DoQEanmmmd"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/638829288435806208\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/DoQEanmmmd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN2T2WRUEAEUa79.png",
      "id_str" : "638829284056895489",
      "id" : 638829284056895489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN2T2WRUEAEUa79.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/DoQEanmmmd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638829288435806208",
  "text" : "With the flipped-LMS approach for CMPT 363, it's critical for taskflows to be as seamless as possible. CMS \u21C4 LMS http:\/\/t.co\/DoQEanmmmd",
  "id" : 638829288435806208,
  "created_at" : "2015-09-01 21:42:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "CMS Critic",
      "screen_name" : "cmscritic",
      "indices" : [ 112, 122 ],
      "id_str" : "16147963",
      "id" : 16147963
    }, {
      "name" : "Tech Connection",
      "screen_name" : "CMSConnection",
      "indices" : [ 123, 137 ],
      "id_str" : "242408499",
      "id" : 242408499
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cms",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/2AmKvhPM30",
      "expanded_url" : "http:\/\/awards.cmscritic.com\/nominate\/",
      "display_url" : "awards.cmscritic.com\/nominate\/"
    } ]
  },
  "geo" : { },
  "id_str" : "638725650409361408",
  "text" : "RT @getgrav: There's still time, please nominate Grav for a \"Critics' Choice CMS Award!\" http:\/\/t.co\/2AmKvhPM30 @cmscritic @CMSConnection #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CMS Critic",
        "screen_name" : "cmscritic",
        "indices" : [ 99, 109 ],
        "id_str" : "16147963",
        "id" : 16147963
      }, {
        "name" : "Tech Connection",
        "screen_name" : "CMSConnection",
        "indices" : [ 110, 124 ],
        "id_str" : "242408499",
        "id" : 242408499
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cms",
        "indices" : [ 125, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/2AmKvhPM30",
        "expanded_url" : "http:\/\/awards.cmscritic.com\/nominate\/",
        "display_url" : "awards.cmscritic.com\/nominate\/"
      } ]
    },
    "geo" : { },
    "id_str" : "638722759309197312",
    "text" : "There's still time, please nominate Grav for a \"Critics' Choice CMS Award!\" http:\/\/t.co\/2AmKvhPM30 @cmscritic @CMSConnection #cms",
    "id" : 638722759309197312,
    "created_at" : "2015-09-01 14:39:07 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 638725650409361408,
  "created_at" : "2015-09-01 14:50:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]