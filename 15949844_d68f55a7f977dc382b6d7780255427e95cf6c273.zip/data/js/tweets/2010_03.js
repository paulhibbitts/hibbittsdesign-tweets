Grailbird.data.tweets_2010_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "o",
      "screen_name" : "iheartusers",
      "indices" : [ 0, 12 ],
      "id_str" : "2460674923",
      "id" : 2460674923
    }, {
      "name" : "Citrix GoToMeeting",
      "screen_name" : "GoToMeeting",
      "indices" : [ 39, 51 ],
      "id_str" : "50706891",
      "id" : 50706891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11442906482",
  "in_reply_to_user_id" : 7436572,
  "text" : "@iheartusers I've been very happy with @gotomeeting for remote user studies - easy install for participants and fast screen refreshes",
  "id" : 11442906482,
  "created_at" : "2010-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "carrietrieglaff",
  "in_reply_to_user_id_str" : "7436572",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11375165572",
  "text" : "Finding that a one sentence goal + motivation statement makes a great starting point for collaboration on more detailed scenarios.",
  "id" : 11375165572,
  "created_at" : "2010-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11276810088",
  "text" : "Interesting look at collaborative concept mapping during an agile project utilizing extreme scenario based design - http:\/\/bit.ly\/bymWw9",
  "id" : 11276810088,
  "created_at" : "2010-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Soucy",
      "screen_name" : "usableinterface",
      "indices" : [ 0, 16 ],
      "id_str" : "276717629",
      "id" : 276717629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11056827710",
  "in_reply_to_user_id" : 7404682,
  "text" : "@usableinterface I\u2019ve been very pleased with my Presentation Pro Remote by Keyspan (now Tripp Lite) - good RF range and Mac\/PC USB",
  "id" : 11056827710,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "kylesoucy",
  "in_reply_to_user_id_str" : "7404682",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Sherman",
      "screen_name" : "pjsherman",
      "indices" : [ 0, 10 ],
      "id_str" : "18213770",
      "id" : 18213770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10682082852",
  "geo" : { },
  "id_str" : "10683383444",
  "in_reply_to_user_id" : 18213770,
  "text" : "@pjsherman On the Mac Tweetie is my favourite, and I am just trying out sobees Beta (native desktop) on my PC - seems promising so far.",
  "id" : 10683383444,
  "in_reply_to_status_id" : 10682082852,
  "created_at" : "2010-03-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "pjsherman",
  "in_reply_to_user_id_str" : "18213770",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caris Hurd",
      "screen_name" : "carismarie",
      "indices" : [ 0, 11 ],
      "id_str" : "1036751",
      "id" : 1036751
    }, {
      "name" : "RunRev",
      "screen_name" : "RunRev",
      "indices" : [ 74, 81 ],
      "id_str" : "2882852739",
      "id" : 2882852739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10574189874",
  "geo" : { },
  "id_str" : "10576950864",
  "in_reply_to_user_id" : 1036751,
  "text" : "@carismarie A modern variant of HyperCard (with much more power) would be @RunRev. I have no connection with the company, just a happy user!",
  "id" : 10576950864,
  "in_reply_to_status_id" : 10574189874,
  "created_at" : "2010-03-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "carismarie",
  "in_reply_to_user_id_str" : "1036751",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teamwork PM",
      "screen_name" : "TeamworkPM",
      "indices" : [ 9, 20 ],
      "id_str" : "2745195586",
      "id" : 2745195586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10380457865",
  "text" : "Kudos to @teamworkpm for great customer support \u2013 accidentally deleted data was restored in under an hour.  Thanks very much Dan!",
  "id" : 10380457865,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    }, {
      "name" : "SurveyGizmo",
      "screen_name" : "SurveyGizmo",
      "indices" : [ 56, 68 ],
      "id_str" : "13133002",
      "id" : 13133002
    }, {
      "name" : "ProofHQ",
      "screen_name" : "ProofHQ",
      "indices" : [ 106, 114 ],
      "id_str" : "18721942",
      "id" : 18721942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10387536552",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Hi Glen! A couple of options come to mind - @SurveyGizmo supports ratings\/rank questions, and @ProofHQ to support more feedback",
  "id" : 10387536552,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]