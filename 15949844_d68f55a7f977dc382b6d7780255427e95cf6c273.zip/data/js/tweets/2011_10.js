Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtain Revenue",
      "screen_name" : "corvustweets",
      "indices" : [ 0, 13 ],
      "id_str" : "2503692858",
      "id" : 2503692858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128625015439626240",
  "text" : "@corvustweets Belated congratulations on the launch of Denim & Steel!",
  "id" : 128625015439626240,
  "created_at" : "2011-10-25 00:12:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    }, {
      "name" : "Teamwork PM",
      "screen_name" : "TeamworkPM",
      "indices" : [ 67, 78 ],
      "id_str" : "2745195586",
      "id" : 2745195586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127516091881766912",
  "geo" : { },
  "id_str" : "127523891332653057",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 I've been a happy customer of Basecamp, but I've also found @teamworkpm to provide a more extensive feature set with good ease-of-use",
  "id" : 127523891332653057,
  "in_reply_to_status_id" : 127516091881766912,
  "created_at" : "2011-10-21 23:17:19 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hong",
      "screen_name" : "hqu",
      "indices" : [ 0, 4 ],
      "id_str" : "16657356",
      "id" : 16657356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125427672758231041",
  "geo" : { },
  "id_str" : "125937815149219840",
  "in_reply_to_user_id" : 16657356,
  "text" : "@hqu Thanks very much for the mention, hope the UX design resources are useful to you!",
  "id" : 125937815149219840,
  "in_reply_to_status_id" : 125427672758231041,
  "created_at" : "2011-10-17 14:14:49 +0000",
  "in_reply_to_screen_name" : "hqu",
  "in_reply_to_user_id_str" : "16657356",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moin Zaman",
      "screen_name" : "moinzaman",
      "indices" : [ 0, 10 ],
      "id_str" : "66008807",
      "id" : 66008807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125244570761039872",
  "geo" : { },
  "id_str" : "125937233470554112",
  "in_reply_to_user_id" : 66008807,
  "text" : "@moinzaman Thanks very much for the mention, hope the UX resources are helpful to you!",
  "id" : 125937233470554112,
  "in_reply_to_status_id" : 125244570761039872,
  "created_at" : "2011-10-17 14:12:30 +0000",
  "in_reply_to_screen_name" : "moinzaman",
  "in_reply_to_user_id_str" : "66008807",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "selma zafar",
      "screen_name" : "selmaz",
      "indices" : [ 3, 10 ],
      "id_str" : "36598690",
      "id" : 36598690
    }, {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 37, 49 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 33, 36 ]
    }, {
      "text" : "UX",
      "indices" : [ 72, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122450886021754880",
  "text" : "RT @selmaz: It's a busy fall for #UX @openroadies!  We are looking for  #UX consultants.  Do you love IA, wireframes & usability? Contac ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenRoad",
        "screen_name" : "openroadies",
        "indices" : [ 25, 37 ],
        "id_str" : "66913866",
        "id" : 66913866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 21, 24 ]
      }, {
        "text" : "UX",
        "indices" : [ 60, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122351748613550080",
    "text" : "It's a busy fall for #UX @openroadies!  We are looking for  #UX consultants.  Do you love IA, wireframes & usability? Contact me.",
    "id" : 122351748613550080,
    "created_at" : "2011-10-07 16:45:04 +0000",
    "user" : {
      "name" : "selma zafar",
      "screen_name" : "selmaz",
      "protected" : false,
      "id_str" : "36598690",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/191536681\/selma_photo2_normal.jpg",
      "id" : 36598690,
      "verified" : false
    }
  },
  "id" : 122450886021754880,
  "created_at" : "2011-10-07 23:19:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/oniPWyoL",
      "expanded_url" : "http:\/\/bit.ly\/pYkehz",
      "display_url" : "bit.ly\/pYkehz"
    } ]
  },
  "geo" : { },
  "id_str" : "122016633299550208",
  "text" : "The Flipped Classroom | Education Sector http:\/\/t.co\/oniPWyoL",
  "id" : 122016633299550208,
  "created_at" : "2011-10-06 18:33:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Sherman",
      "screen_name" : "jasherman",
      "indices" : [ 3, 13 ],
      "id_str" : "23328751",
      "id" : 23328751
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SteveJobs",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121951107995013120",
  "text" : "RT @jasherman: Amazing that one person could have such a positive impact, and add so much value, for so many. We are privileged to have  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SteveJobs",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121784349279522816",
    "text" : "Amazing that one person could have such a positive impact, and add so much value, for so many. We are privileged to have seen it. #SteveJobs",
    "id" : 121784349279522816,
    "created_at" : "2011-10-06 03:10:26 +0000",
    "user" : {
      "name" : "Jerry Sherman",
      "screen_name" : "jasherman",
      "protected" : false,
      "id_str" : "23328751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434826754306240512\/NDGTZSD6_normal.png",
      "id" : 23328751,
      "verified" : false
    }
  },
  "id" : 121951107995013120,
  "created_at" : "2011-10-06 14:13:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121744631330377728",
  "text" : "My thoughts and prayers are with the family and friends of Steve Jobs tonight. Jobs was a source of inspiration that improved many lives.",
  "id" : 121744631330377728,
  "created_at" : "2011-10-06 00:32:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/YkaVYnTw",
      "expanded_url" : "http:\/\/tinyurl.com\/3nk8rqc",
      "display_url" : "tinyurl.com\/3nk8rqc"
    } ]
  },
  "geo" : { },
  "id_str" : "121721480651354112",
  "text" : "Why AirPlay Mirroring is the Biggest Thing to Happen to User Research in 2011 http:\/\/t.co\/YkaVYnTw &lt;-This is the killer iOS 5 feature to me!",
  "id" : 121721480651354112,
  "created_at" : "2011-10-05 23:00:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Breker",
      "screen_name" : "melissabreker",
      "indices" : [ 0, 14 ],
      "id_str" : "23722577",
      "id" : 23722577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120976056026013696",
  "geo" : { },
  "id_str" : "120979184943243264",
  "in_reply_to_user_id" : 23722577,
  "text" : "@melissabreker Thanks for your feedback! Love to hear more - are you thinking more about user-research, stakeholder questions, or both?",
  "id" : 120979184943243264,
  "in_reply_to_status_id" : 120976056026013696,
  "created_at" : "2011-10-03 21:51:00 +0000",
  "in_reply_to_screen_name" : "melissabreker",
  "in_reply_to_user_id_str" : "23722577",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120975224165507072",
  "text" : "Thinking of possible topics for future UX fundamentals seminars - asking the right questions and problem reframing are current frontrunners.",
  "id" : 120975224165507072,
  "created_at" : "2011-10-03 21:35:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]