Grailbird.data.tweets_2010_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25846601217",
  "text" : "4 Best User Interface Design Pattern Libraries http:\/\/bit.ly\/9y2lhR Also check out Quince w problem descriptions http:\/\/bit.ly\/94ByG4",
  "id" : 25846601217,
  "created_at" : "2010-09-29 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catriona Shedd",
      "screen_name" : "inspireUX",
      "indices" : [ 3, 13 ],
      "id_str" : "15325945",
      "id" : 15325945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25903844807",
  "text" : "RT @inspireUX 15 Tips to Help Designers Gain Stakeholder Buy-In http:\/\/bit.ly\/diPOD5 Lots of solid advice that rings true for me!",
  "id" : 25903844807,
  "created_at" : "2010-09-29 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Bray",
      "screen_name" : "timbray",
      "indices" : [ 3, 11 ],
      "id_str" : "1235521",
      "id" : 1235521
    }, {
      "name" : "Ron Jeffries",
      "screen_name" : "RonJeffries",
      "indices" : [ 126, 138 ],
      "id_str" : "14979481",
      "id" : 14979481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25602707869",
  "text" : "RT @timbray: Do you hate software patents? If so, you have until Monday to tell the USPTO: http:\/\/goo.gl\/V7lg Please RT! (via @RonJeffries)",
  "id" : 25602707869,
  "created_at" : "2010-09-26 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Fadeyev",
      "screen_name" : "usabilitypost",
      "indices" : [ 42, 56 ],
      "id_str" : "14254504",
      "id" : 14254504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 36 ],
      "url" : "http:\/\/t.co\/jmBZoyX",
      "expanded_url" : "http:\/\/www.usabilitypost.com\/2010\/09\/24\/false-simplicity\/",
      "display_url" : "usabilitypost.com\/2010\/09\/24\/fal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "25448342947",
  "text" : "False Simplicity http:\/\/t.co\/jmBZoyX (via @usabilitypost) Good article, and reminds me of Tog's advice... icon + label is often best!",
  "id" : 25448342947,
  "created_at" : "2010-09-24 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25238267780",
  "text" : "First-hand observation of people trying to use your product not only brings insight but also helps you become a more thoughtful designer.",
  "id" : 25238267780,
  "created_at" : "2010-09-22 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kicker Studio",
      "screen_name" : "kickerstudio",
      "indices" : [ 107, 120 ],
      "id_str" : "15419573",
      "id" : 15419573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25052549222",
  "text" : "\"You cannot build a great product simply by obeying what customers say they want.\" http:\/\/is.gd\/fjXs8 (via @kickerstudio)",
  "id" : 25052549222,
  "created_at" : "2010-09-20 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25059674631",
  "text" : "A preview of my Collaborative Scenario-based Design presentation is now at http:\/\/slidesha.re\/bJtlqC Comments and questions most welcome!",
  "id" : 25059674631,
  "created_at" : "2010-09-20 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakersCabin",
      "screen_name" : "drawar",
      "indices" : [ 3, 10 ],
      "id_str" : "2799257485",
      "id" : 2799257485
    }, {
      "name" : "iA Inc.",
      "screen_name" : "iA",
      "indices" : [ 81, 84 ],
      "id_str" : "2087371",
      "id" : 2087371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24678838190",
  "text" : "RT @drawar: This is the post I should've written. Can experience be designed? by @iA http:\/\/bit.ly\/b60xdg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "iA Inc.",
        "screen_name" : "iA",
        "indices" : [ 69, 72 ],
        "id_str" : "2087371",
        "id" : 2087371
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "24676612710",
    "geo" : { },
    "id_str" : "24677315106",
    "in_reply_to_user_id" : 2087371,
    "text" : "This is the post I should've written. Can experience be designed? by @iA http:\/\/bit.ly\/b60xdg",
    "id" : 24677315106,
    "in_reply_to_status_id" : 24676612710,
    "created_at" : "2010-09-16 16:14:11 +0000",
    "in_reply_to_screen_name" : "iA",
    "in_reply_to_user_id_str" : "2087371",
    "user" : {
      "name" : "Makers Cabin",
      "screen_name" : "MakersCabin",
      "protected" : false,
      "id_str" : "50321599",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525368456598650880\/7GvddumH_normal.png",
      "id" : 50321599,
      "verified" : false
    }
  },
  "id" : 24678838190,
  "created_at" : "2010-09-16 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nambu.com\/\" rel=\"nofollow\"\u003ENambu\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23248708763",
  "text" : "Android & iPhone App Design: Is it twice the work? http:\/\/bit.ly\/ctOIOm Always interesting to examine cross-platform mobile design issues!",
  "id" : 23248708763,
  "created_at" : "2010-09-07 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]