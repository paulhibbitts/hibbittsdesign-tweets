Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Wulf",
      "screen_name" : "wulfsoft",
      "indices" : [ 102, 111 ],
      "id_str" : "101085470",
      "id" : 101085470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109059066906677249",
  "text" : "Very impressed with the UI stencil \"SmartResizing\" feature of PowerMockups for PowerPoint! Great work @wulfsoft",
  "id" : 109059066906677249,
  "created_at" : "2011-09-01 00:24:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Wise",
      "screen_name" : "ewise",
      "indices" : [ 0, 6 ],
      "id_str" : "14142221",
      "id" : 14142221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108646738025394176",
  "geo" : { },
  "id_str" : "108660570458308609",
  "in_reply_to_user_id" : 14142221,
  "text" : "@ewise Hey Evan! Please email me directly and we can discuss options\u2026",
  "id" : 108660570458308609,
  "in_reply_to_status_id" : 108646738025394176,
  "created_at" : "2011-08-30 22:01:13 +0000",
  "in_reply_to_screen_name" : "ewise",
  "in_reply_to_user_id_str" : "14142221",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108623520384286720",
  "text" : "@thebobstercom Thanks for the mention!",
  "id" : 108623520384286720,
  "created_at" : "2011-08-30 19:34:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/108618293706899456\/photo\/1",
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/iinOfvb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AYHjwzzCQAAd5j1.png",
      "id_str" : "108618293711093760",
      "id" : 108618293711093760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AYHjwzzCQAAd5j1.png",
      "sizes" : [ {
        "h" : 744,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 396
      } ],
      "display_url" : "pic.twitter.com\/iinOfvb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108618293706899456",
  "text" : "Putting final touches on the mobile website for my CMPT 363 (ui\/ux design) Fall course at SFU - student feedback awaits http:\/\/t.co\/iinOfvb",
  "id" : 108618293706899456,
  "created_at" : "2011-08-30 19:13:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habanero UX Team",
      "screen_name" : "HabaneroUE",
      "indices" : [ 3, 14 ],
      "id_str" : "178784851",
      "id" : 178784851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/OurMYMj",
      "expanded_url" : "http:\/\/cot.ag\/nNmPk7",
      "display_url" : "cot.ag\/nNmPk7"
    } ]
  },
  "geo" : { },
  "id_str" : "107259914702954496",
  "text" : "RT @HabaneroUE: September VanUE Event: \"We're going two-way baby\" How Vancity transformed its intranet from static to social\u2026 http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 129 ],
        "url" : "http:\/\/t.co\/OurMYMj",
        "expanded_url" : "http:\/\/cot.ag\/nNmPk7",
        "display_url" : "cot.ag\/nNmPk7"
      } ]
    },
    "geo" : { },
    "id_str" : "107198843640217600",
    "text" : "September VanUE Event: \"We're going two-way baby\" How Vancity transformed its intranet from static to social\u2026 http:\/\/t.co\/OurMYMj",
    "id" : 107198843640217600,
    "created_at" : "2011-08-26 21:12:50 +0000",
    "user" : {
      "name" : "Habanero UX Team",
      "screen_name" : "HabaneroUE",
      "protected" : false,
      "id_str" : "178784851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1863327616\/BACON_normal.jpg",
      "id" : 178784851,
      "verified" : false
    }
  },
  "id" : 107259914702954496,
  "created_at" : "2011-08-27 01:15:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106086369012629505",
  "text" : "Finding the use of concept maps an insightful early step in the collaborative creation of more detailed scenarios.",
  "id" : 106086369012629505,
  "created_at" : "2011-08-23 19:32:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 3, 11 ],
      "id_str" : "10675",
      "id" : 10675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SISV",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/YBE1HVc",
      "expanded_url" : "http:\/\/www.socialintranetsummit.com\/summit\/",
      "display_url" : "socialintranetsummit.com\/summit\/"
    } ]
  },
  "geo" : { },
  "id_str" : "105774403345842176",
  "text" : "RT @gordonr: Social Intranet Summit: updated agenda now up, plus a few great speakers  to be announced this week: http:\/\/t.co\/YBE1HVc #SISV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SISV",
        "indices" : [ 121, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 120 ],
        "url" : "http:\/\/t.co\/YBE1HVc",
        "expanded_url" : "http:\/\/www.socialintranetsummit.com\/summit\/",
        "display_url" : "socialintranetsummit.com\/summit\/"
      } ]
    },
    "geo" : { },
    "id_str" : "105511111931072513",
    "text" : "Social Intranet Summit: updated agenda now up, plus a few great speakers  to be announced this week: http:\/\/t.co\/YBE1HVc #SISV",
    "id" : 105511111931072513,
    "created_at" : "2011-08-22 05:26:24 +0000",
    "user" : {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "protected" : false,
      "id_str" : "10675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723725303218991104\/GhSmJXhv_normal.jpg",
      "id" : 10675,
      "verified" : false
    }
  },
  "id" : 105774403345842176,
  "created_at" : "2011-08-22 22:52:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 81, 96 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http:\/\/t.co\/koUarPn",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/national\/on-innovations\/tech-community-are-we-mtv-or-ted\/2011\/08\/18\/gIQASfGsNJ_story.html",
      "display_url" : "washingtonpost.com\/national\/on-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "104742478590115841",
  "text" : "Tech community, are we MTV or TED? - The Washington Post http:\/\/t.co\/koUarPn via @washingtonpost",
  "id" : 104742478590115841,
  "created_at" : "2011-08-20 02:32:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http:\/\/t.co\/y11T74q",
      "expanded_url" : "http:\/\/bit.ly\/pwSuRB",
      "display_url" : "bit.ly\/pwSuRB"
    } ]
  },
  "geo" : { },
  "id_str" : "103952600956796928",
  "text" : "The four corners of usability measurement: Measuring Usability Blog http:\/\/t.co\/y11T74q",
  "id" : 103952600956796928,
  "created_at" : "2011-08-17 22:13:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UX Magazine",
      "screen_name" : "uxmag",
      "indices" : [ 77, 83 ],
      "id_str" : "15056788",
      "id" : 15056788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/usZZs0s",
      "expanded_url" : "http:\/\/bit.ly\/p8hVf8",
      "display_url" : "bit.ly\/p8hVf8"
    } ]
  },
  "geo" : { },
  "id_str" : "99536468959170561",
  "text" : "I am reading: Five Lessons from a Year of Tablet UX Research on UX Magazine (@uxmag) http:\/\/t.co\/usZZs0s",
  "id" : 99536468959170561,
  "created_at" : "2011-08-05 17:45:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]