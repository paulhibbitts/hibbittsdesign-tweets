Grailbird.data.tweets_2011_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41292185177559040",
  "text" : "Using page description diagrams http:\/\/bit.ly\/hvSEeJ for quicker group consensus of needed content\/functionality - any experiences to share?",
  "id" : 41292185177559040,
  "created_at" : "2011-02-26 00:23:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aza Raskin",
      "screen_name" : "azaaza",
      "indices" : [ 3, 10 ],
      "id_str" : "534677003",
      "id" : 534677003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34771511739035648",
  "text" : "RT @azaaza: Design is as much about iterating understanding of the problem as it is the solution. Your first attempt at both will be wrong.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34765036928901120",
    "text" : "Design is as much about iterating understanding of the problem as it is the solution. Your first attempt at both will be wrong.",
    "id" : 34765036928901120,
    "created_at" : "2011-02-08 00:06:45 +0000",
    "user" : {
      "name" : "Aza Raskin",
      "screen_name" : "aza",
      "protected" : false,
      "id_str" : "13370272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801298949\/Aza_Evil_normal.png",
      "id" : 13370272,
      "verified" : false
    }
  },
  "id" : 34771511739035648,
  "created_at" : "2011-02-08 00:32:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]