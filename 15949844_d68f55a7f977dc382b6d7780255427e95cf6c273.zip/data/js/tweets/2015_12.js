Grailbird.data.tweets_2015_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682716153358057472",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde One of my highlights of 2015 was definitely OpenEd2015! Happy New Year to you and your family.",
  "id" : 682716153358057472,
  "created_at" : "2016-01-01 00:13:09 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682311322411864066",
  "geo" : { },
  "id_str" : "682705458730160129",
  "in_reply_to_user_id" : 15949844,
  "text" : "@btopro It was great to connect with you in 2015. Happy New Year Bryan!",
  "id" : 682705458730160129,
  "in_reply_to_status_id" : 682311322411864066,
  "created_at" : "2015-12-31 23:30:40 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "indices" : [ 0, 11 ],
      "id_str" : "27633854",
      "id" : 27633854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682704460116824064",
  "geo" : { },
  "id_str" : "682705178164727809",
  "in_reply_to_user_id" : 27633854,
  "text" : "@JustStormy Happy New Year Melissa!",
  "id" : 682705178164727809,
  "in_reply_to_status_id" : 682704460116824064,
  "created_at" : "2015-12-31 23:29:33 +0000",
  "in_reply_to_screen_name" : "JustStormy",
  "in_reply_to_user_id_str" : "27633854",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682703758573219840",
  "geo" : { },
  "id_str" : "682704411471171584",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Let me know if any look useful to you \uD83D\uDE00 I've got big plans for GravCMS in 2016. Happy New Year Christina!",
  "id" : 682704411471171584,
  "in_reply_to_status_id" : 682703758573219840,
  "created_at" : "2015-12-31 23:26:30 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682701851037270016",
  "text" : "My key apps of 2015:\n\u2705 GravCMS\n\u2705 GitHub Desktop\n\u2705 Atom.io\n\u2705 Gitter.im\n\u2705 CanvasLMS\n\u2705 Slid.es\n\u2705 Grammarly\n\u2705 Olark\n\u2705 Google Music, for the soul",
  "id" : 682701851037270016,
  "created_at" : "2015-12-31 23:16:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD Dillon",
      "screen_name" : "JD_Dillon",
      "indices" : [ 3, 13 ],
      "id_str" : "131767918",
      "id" : 131767918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682693663697207296",
  "text" : "RT @JD_Dillon: Blended learning isn't a strategy. It's reality. 70\/20\/10 isn't a model. It's reality. Social learning isn't new. It's reali\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682691839837761536",
    "text" : "Blended learning isn't a strategy. It's reality. 70\/20\/10 isn't a model. It's reality. Social learning isn't new. It's reality ...",
    "id" : 682691839837761536,
    "created_at" : "2015-12-31 22:36:33 +0000",
    "user" : {
      "name" : "JD Dillon",
      "screen_name" : "JD_Dillon",
      "protected" : false,
      "id_str" : "131767918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742566632724238336\/LXyssY2J_normal.jpg",
      "id" : 131767918,
      "verified" : false
    }
  },
  "id" : 682693663697207296,
  "created_at" : "2015-12-31 22:43:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "CMS Critic",
      "screen_name" : "cmscritic",
      "indices" : [ 66, 76 ],
      "id_str" : "16147963",
      "id" : 16147963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/Mh7j8kpzp4",
      "expanded_url" : "http:\/\/awards.cmscritic.com\/vote\/",
      "display_url" : "awards.cmscritic.com\/vote\/"
    } ]
  },
  "geo" : { },
  "id_str" : "682629922112827396",
  "text" : "RT @getgrav: ** ONLY 1 DAY LEFT** to vote Grav \u201CBest Free CMS\u201D in @cmscritic People\u2019s Choice Awards  https:\/\/t.co\/Mh7j8kpzp4 - Don\u2019t procra\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CMS Critic",
        "screen_name" : "cmscritic",
        "indices" : [ 53, 63 ],
        "id_str" : "16147963",
        "id" : 16147963
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/Mh7j8kpzp4",
        "expanded_url" : "http:\/\/awards.cmscritic.com\/vote\/",
        "display_url" : "awards.cmscritic.com\/vote\/"
      } ]
    },
    "geo" : { },
    "id_str" : "682627681825865728",
    "text" : "** ONLY 1 DAY LEFT** to vote Grav \u201CBest Free CMS\u201D in @cmscritic People\u2019s Choice Awards  https:\/\/t.co\/Mh7j8kpzp4 - Don\u2019t procrastinate!",
    "id" : 682627681825865728,
    "created_at" : "2015-12-31 18:21:36 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 682629922112827396,
  "created_at" : "2015-12-31 18:30:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senongo",
      "screen_name" : "senongo",
      "indices" : [ 3, 11 ],
      "id_str" : "174108566",
      "id" : 174108566
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/senongo\/status\/682372467415855104\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/0N67nTe658",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXhGG_tUEAAN9li.jpg",
      "id_str" : "682372429541281792",
      "id" : 682372429541281792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXhGG_tUEAAN9li.jpg",
      "sizes" : [ {
        "h" : 298,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 845,
        "resize" : "fit",
        "w" : 963
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 845,
        "resize" : "fit",
        "w" : 963
      } ],
      "display_url" : "pic.twitter.com\/0N67nTe658"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682374785125367808",
  "text" : "RT @senongo: What a time to be alive https:\/\/t.co\/0N67nTe658",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/senongo\/status\/682372467415855104\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/0N67nTe658",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXhGG_tUEAAN9li.jpg",
        "id_str" : "682372429541281792",
        "id" : 682372429541281792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXhGG_tUEAAN9li.jpg",
        "sizes" : [ {
          "h" : 298,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 845,
          "resize" : "fit",
          "w" : 963
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 526,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 845,
          "resize" : "fit",
          "w" : 963
        } ],
        "display_url" : "pic.twitter.com\/0N67nTe658"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682372467415855104",
    "text" : "What a time to be alive https:\/\/t.co\/0N67nTe658",
    "id" : 682372467415855104,
    "created_at" : "2015-12-31 01:27:28 +0000",
    "user" : {
      "name" : "Senongo",
      "screen_name" : "senongo",
      "protected" : false,
      "id_str" : "174108566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475681970228559872\/J3LvqZgv_normal.jpeg",
      "id" : 174108566,
      "verified" : false
    }
  },
  "id" : 682374785125367808,
  "created_at" : "2015-12-31 01:36:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus Open",
      "screen_name" : "BCOpenText",
      "indices" : [ 3, 14 ],
      "id_str" : "3148543346",
      "id" : 3148543346
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenEd",
      "indices" : [ 122, 129 ]
    }, {
      "text" : "OER",
      "indices" : [ 130, 134 ]
    }, {
      "text" : "BCPSE",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/Z8oeoav8YG",
      "expanded_url" : "http:\/\/ow.ly\/Wbltz",
      "display_url" : "ow.ly\/Wbltz"
    } ]
  },
  "geo" : { },
  "id_str" : "682373718979428356",
  "text" : "RT @BCOpenText: We are pleased to announce the 2016 Faculty Fellows Program call for applications https:\/\/t.co\/Z8oeoav8YG #OpenEd #OER #BCP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenEd",
        "indices" : [ 106, 113 ]
      }, {
        "text" : "OER",
        "indices" : [ 114, 118 ]
      }, {
        "text" : "BCPSE",
        "indices" : [ 119, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/Z8oeoav8YG",
        "expanded_url" : "http:\/\/ow.ly\/Wbltz",
        "display_url" : "ow.ly\/Wbltz"
      } ]
    },
    "geo" : { },
    "id_str" : "682373349771730945",
    "text" : "We are pleased to announce the 2016 Faculty Fellows Program call for applications https:\/\/t.co\/Z8oeoav8YG #OpenEd #OER #BCPSE",
    "id" : 682373349771730945,
    "created_at" : "2015-12-31 01:30:59 +0000",
    "user" : {
      "name" : "BCcampus Open",
      "screen_name" : "BCOpenText",
      "protected" : false,
      "id_str" : "3148543346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587706251347243009\/BA0taxiM_normal.jpg",
      "id" : 3148543346,
      "verified" : false
    }
  },
  "id" : 682373718979428356,
  "created_at" : "2015-12-31 01:32:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/tj1FuaSotg",
      "expanded_url" : "http:\/\/lsh.re\/W76U",
      "display_url" : "lsh.re\/W76U"
    } ]
  },
  "geo" : { },
  "id_str" : "682322749054959621",
  "text" : "The Top UX Predictions for 2016 | UX Magazine https:\/\/t.co\/tj1FuaSotg",
  "id" : 682322749054959621,
  "created_at" : "2015-12-30 22:09:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/IB26SQh3Ld",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/enhancing-the-online-experience-for-students-and-instructors-with-a-modern-flat-file-cms#\/",
      "display_url" : "slides.com\/paulhibbitts\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682319994168963073",
  "text" : "My most popular slide deck of 2015 - Enhancing the experience for students &amp; instructors with a modern flat-file CMS https:\/\/t.co\/IB26SQh3Ld",
  "id" : 682319994168963073,
  "created_at" : "2015-12-30 21:58:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/dgZwX4LB4m",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/why-a-modern-flat-file-cms",
      "display_url" : "hibbittsdesign.org\/blog\/why-a-mod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682311322411864066",
  "text" : "My most popular post of 2015 - Why a modern flat-file (no database) CMS is my choice as an individual open educator https:\/\/t.co\/dgZwX4LB4m",
  "id" : 682311322411864066,
  "created_at" : "2015-12-30 21:24:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/w5AvBBh745",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/flipped-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681981694375628800",
  "text" : "Flipped-LMS Approach Using an Open and Collaborative Web Platform https:\/\/t.co\/w5AvBBh745 Is the terminology used clear and understandable?",
  "id" : 681981694375628800,
  "created_at" : "2015-12-29 23:34:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UX Booth",
      "screen_name" : "UXBooth",
      "indices" : [ 41, 49 ],
      "id_str" : "16740348",
      "id" : 16740348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/3RuKXd0TlH",
      "expanded_url" : "http:\/\/www.uxbooth.com\/articles\/best-of-2015\/",
      "display_url" : "uxbooth.com\/articles\/best-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681969766102204417",
  "text" : "Best of 2015 https:\/\/t.co\/3RuKXd0TlH via @UXBooth",
  "id" : 681969766102204417,
  "created_at" : "2015-12-29 22:47:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/NKj1DUsZqa",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/a-few-thoughts-about-lms-vs-cms-usage",
      "display_url" : "hibbittsdesign.org\/blog\/a-few-tho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681964652956237824",
  "text" : "A Few Thoughts About... LMS vs CMS Usage https:\/\/t.co\/NKj1DUsZqa",
  "id" : 681964652956237824,
  "created_at" : "2015-12-29 22:26:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681606885116481537",
  "text" : "(2\/2) Main reasons for modern flat-file CMS vs. DB CMS:\n\u2713Open &amp; collaborative ecosystem (i.e. GitHub)\n\u2713Pliability\n\u2713Portability\n\u2713Simplicity",
  "id" : 681606885116481537,
  "created_at" : "2015-12-28 22:45:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 55, 63 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681606854695190528",
  "text" : "(1\/2) My viewpoint: in 2016 a modern flat-file CMS (eg @getgrav) is better suited to individual educators than a database CMS (eg WordPress)",
  "id" : 681606854695190528,
  "created_at" : "2015-12-28 22:45:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/mDJ9E4VNAs",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/",
      "display_url" : "hibbittsdesign.org"
    } ]
  },
  "geo" : { },
  "id_str" : "681601033827532800",
  "text" : "In 2015 I used an open &amp; collab flipped-LMS approach and wrote about it @ https:\/\/t.co\/mDJ9E4VNAs In 2016... a Starter Kit for instructors!",
  "id" : 681601033827532800,
  "created_at" : "2015-12-28 22:22:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Onur Oral",
      "screen_name" : "oralonur",
      "indices" : [ 17, 26 ],
      "id_str" : "103866955",
      "id" : 103866955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/85HvWRNc3v",
      "expanded_url" : "https:\/\/medium.com\/interactive-mind\/mobile-2015-263ab694e60e#.1xbpp3ltr",
      "display_url" : "medium.com\/interactive-mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681567895571202048",
  "text" : "\u201CMobile:2015\u201D by @oralonur https:\/\/t.co\/85HvWRNc3v",
  "id" : 681567895571202048,
  "created_at" : "2015-12-28 20:10:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681552409135415297",
  "text" : "Likelihood instructors use LMS tools outside of courses? ~ 0%\nLikelihood instructors use open source CMS tools outside of courses? \u226B 0%",
  "id" : 681552409135415297,
  "created_at" : "2015-12-28 19:08:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681552364365467648",
  "text" : "Likelihood students use LMS tools outside of courses? ~ 0%\nLikelihood students use open source CMS tools outside of courses? \u226B 0%",
  "id" : 681552364365467648,
  "created_at" : "2015-12-28 19:08:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681552335391203329",
  "text" : "Likelihood instructors use LMS skills outside of courses? ~ 0%\nLikelihood instructors use open source CMS skills outside of courses? \u226B 0%",
  "id" : 681552335391203329,
  "created_at" : "2015-12-28 19:08:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681552298573574144",
  "text" : "Likelihood students use LMS skills outside of courses? ~ 0%\nLikelihood students use open source CMS skills outside of courses? \u226B 0%",
  "id" : 681552298573574144,
  "created_at" : "2015-12-28 19:08:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681552257729441792",
  "text" : "Likelihood instructors use LMS outside of courses? ~ 0%\nLikelihood instructors use an open source CMS outside of courses? \u226B 0%",
  "id" : 681552257729441792,
  "created_at" : "2015-12-28 19:08:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681552227111026688",
  "text" : "Likelihood students use an LMS outside of courses? ~ 0%\nLikelihood students use an open source CMS outside of courses? \u226B 0%",
  "id" : 681552227111026688,
  "created_at" : "2015-12-28 19:08:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/clintlalonde\/status\/679727443163267072\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/sZqYW2sSOV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW7ggdKUQAAUMd2.png",
      "id_str" : "679727441967857664",
      "id" : 679727441967857664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW7ggdKUQAAUMd2.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/sZqYW2sSOV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/GSezYSV3jK",
      "expanded_url" : "http:\/\/clintlalonde.net\/2015\/12\/23\/selling-your-cc-content-isnt-pointless-its-a-sustainability-model\/",
      "display_url" : "clintlalonde.net\/2015\/12\/23\/sel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679775721326133248",
  "text" : "RT @clintlalonde: Selling your CC content isn\u2019t pointless. It\u2019s a sustainability\u00A0model. https:\/\/t.co\/GSezYSV3jK https:\/\/t.co\/sZqYW2sSOV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/clintlalonde\/status\/679727443163267072\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/sZqYW2sSOV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW7ggdKUQAAUMd2.png",
        "id_str" : "679727441967857664",
        "id" : 679727441967857664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW7ggdKUQAAUMd2.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/sZqYW2sSOV"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/GSezYSV3jK",
        "expanded_url" : "http:\/\/clintlalonde.net\/2015\/12\/23\/selling-your-cc-content-isnt-pointless-its-a-sustainability-model\/",
        "display_url" : "clintlalonde.net\/2015\/12\/23\/sel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "679727443163267072",
    "text" : "Selling your CC content isn\u2019t pointless. It\u2019s a sustainability\u00A0model. https:\/\/t.co\/GSezYSV3jK https:\/\/t.co\/sZqYW2sSOV",
    "id" : 679727443163267072,
    "created_at" : "2015-12-23 18:17:05 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 679775721326133248,
  "created_at" : "2015-12-23 21:28:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stacey",
      "screen_name" : "pgstacey",
      "indices" : [ 24, 33 ],
      "id_str" : "48018738",
      "id" : 48018738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/Zl3QkznyAh",
      "expanded_url" : "https:\/\/medium.com\/made-with-creative-commons\/maximize-abundance-f3f70c0c0491#.bj71oc7vp",
      "display_url" : "medium.com\/made-with-crea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679084965250793478",
  "text" : "\u201CMaximize Abundance\u201D by @pgstacey https:\/\/t.co\/Zl3QkznyAh",
  "id" : 679084965250793478,
  "created_at" : "2015-12-21 23:44:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/w5AvBBh745",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/flipped-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679013863585538048",
  "text" : "Last 2015 blog post sets my New Year's focus: Flipped-LMS Approach Using an Open and Collaborative Course Platform https:\/\/t.co\/w5AvBBh745",
  "id" : 679013863585538048,
  "created_at" : "2015-12-21 19:01:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gail Morong",
      "screen_name" : "gailmorong",
      "indices" : [ 0, 11 ],
      "id_str" : "2930467458",
      "id" : 2930467458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679008546843811840",
  "geo" : { },
  "id_str" : "679010537263398912",
  "in_reply_to_user_id" : 2930467458,
  "text" : "@gailmorong Thanks for sharing your thoughts. I also see it as an approach to increase both student &amp; instructor control (still LMS backend)",
  "id" : 679010537263398912,
  "in_reply_to_status_id" : 679008546843811840,
  "created_at" : "2015-12-21 18:48:22 +0000",
  "in_reply_to_screen_name" : "gailmorong",
  "in_reply_to_user_id_str" : "2930467458",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gail Morong",
      "screen_name" : "gailmorong",
      "indices" : [ 0, 11 ],
      "id_str" : "2930467458",
      "id" : 2930467458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678742690838667269",
  "geo" : { },
  "id_str" : "679007208474992640",
  "in_reply_to_user_id" : 15949844,
  "text" : "@gailmorong Thanks for the RT! It was nice to re-connect at OpenEd too.",
  "id" : 679007208474992640,
  "in_reply_to_status_id" : 678742690838667269,
  "created_at" : "2015-12-21 18:35:08 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/w5AvBBh745",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/flipped-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "678742690838667269",
  "text" : "Sunday night sneak peek at my third iteration\uD83D\uDD03Flipped-LMS Approach Using an Open and Collaborative Course Platform https:\/\/t.co\/w5AvBBh745",
  "id" : 678742690838667269,
  "created_at" : "2015-12-21 01:04:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenny Chen",
      "screen_name" : "kennycheny",
      "indices" : [ 51, 62 ],
      "id_str" : "711659959",
      "id" : 711659959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/2jEGVEvahk",
      "expanded_url" : "https:\/\/medium.com\/@kennycheny\/the-best-user-experience-design-links-of-2015-5f4b50b2a6bc#.pbk91161q",
      "display_url" : "medium.com\/@kennycheny\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "678284929038352384",
  "text" : "\u201CThe Best User Experience Design Links of 2015\u201D by @kennycheny https:\/\/t.co\/2jEGVEvahk",
  "id" : 678284929038352384,
  "created_at" : "2015-12-19 18:45:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 4, 12 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 14, 21 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 26, 35 ],
      "id_str" : "180743261",
      "id" : 180743261
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/677978018430640129\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/tDDioatOen",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWipak0UkAEMKLW.png",
      "id_str" : "677978017944080385",
      "id" : 677978017944080385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWipak0UkAEMKLW.png",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tDDioatOen"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677978018430640129",
  "text" : "How @getgrav, @github and @deployhq all work together to support an open and collaborative flipped-LMS approach. https:\/\/t.co\/tDDioatOen",
  "id" : 677978018430640129,
  "created_at" : "2015-12-18 22:25:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "DrupalCamp Atlanta",
      "screen_name" : "DrupalCamp_ATL",
      "indices" : [ 28, 43 ],
      "id_str" : "48747368",
      "id" : 48747368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677950910576902145",
  "geo" : { },
  "id_str" : "677960320325779456",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Really enjoyed your @DrupalCamp_ATL presentation too, and have already started to share it \uD83D\uDE00",
  "id" : 677960320325779456,
  "in_reply_to_status_id" : 677950910576902145,
  "created_at" : "2015-12-18 21:15:10 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677950910576902145",
  "geo" : { },
  "id_str" : "677959845669036032",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro We share similar goals: you and your team working at an institutional level while my audience is primarily individual instructors \uD83D\uDC4D",
  "id" : 677959845669036032,
  "in_reply_to_status_id" : 677950910576902145,
  "created_at" : "2015-12-18 21:13:17 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/677916527908143104\/photo\/1",
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/BM7EW0l8lx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhxfWCU8AAGV08.png",
      "id_str" : "677916527224483840",
      "id" : 677916527224483840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhxfWCU8AAGV08.png",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BM7EW0l8lx"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/677916527908143104\/photo\/1",
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/BM7EW0l8lx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhxfUkVEAEloug.png",
      "id_str" : "677916526830227457",
      "id" : 677916526830227457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhxfUkVEAEloug.png",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BM7EW0l8lx"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/677916527908143104\/photo\/1",
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/BM7EW0l8lx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhxfVuU8AA_-Z4.png",
      "id_str" : "677916527140597760",
      "id" : 677916527140597760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhxfVuU8AA_-Z4.png",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BM7EW0l8lx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677916527908143104",
  "text" : "Updated visualizations:\n\u30FBFlipped-LMS\n\u30FBOpen &amp; collaborative platform\n\u30FBFlipped-LMS using open &amp; collaborative platform https:\/\/t.co\/BM7EW0l8lx",
  "id" : 677916527908143104,
  "created_at" : "2015-12-18 18:21:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcpse",
      "indices" : [ 142, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/Ea76X096rg",
      "expanded_url" : "http:\/\/bit.ly\/1lX1WsL",
      "display_url" : "bit.ly\/1lX1WsL"
    } ]
  },
  "geo" : { },
  "id_str" : "677909903415971842",
  "text" : "RT @clintlalonde: Appreciate if you could RT &gt; We're looking for Faculty Fellows for the BC Open Textbook project  https:\/\/t.co\/Ea76X096rg \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bcpse",
        "indices" : [ 124, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/Ea76X096rg",
        "expanded_url" : "http:\/\/bit.ly\/1lX1WsL",
        "display_url" : "bit.ly\/1lX1WsL"
      } ]
    },
    "geo" : { },
    "id_str" : "677909644786843648",
    "text" : "Appreciate if you could RT &gt; We're looking for Faculty Fellows for the BC Open Textbook project  https:\/\/t.co\/Ea76X096rg #bcpse",
    "id" : 677909644786843648,
    "created_at" : "2015-12-18 17:53:48 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 677909903415971842,
  "created_at" : "2015-12-18 17:54:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677906898411126784",
  "text" : "Next iteration of a visualized flipped-LMS approach + open collaborative platform coming up soon...",
  "id" : 677906898411126784,
  "created_at" : "2015-12-18 17:42:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 3, 10 ],
      "id_str" : "236846178",
      "id" : 236846178
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 42, 49 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "DrupalCamp Atlanta",
      "screen_name" : "DrupalCamp_ATL",
      "indices" : [ 83, 98 ],
      "id_str" : "48747368",
      "id" : 48747368
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 114, 129 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677902988090826752",
  "text" : "RT @elmsln: We've updated our homepage w\/ @btopro's Rethinking Systems Design from @DrupalCamp_ATL and apparently @hibbittsdesign is on our\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bryan Ollendyke",
        "screen_name" : "btopro",
        "indices" : [ 30, 37 ],
        "id_str" : "16847370",
        "id" : 16847370
      }, {
        "name" : "DrupalCamp Atlanta",
        "screen_name" : "DrupalCamp_ATL",
        "indices" : [ 71, 86 ],
        "id_str" : "48747368",
        "id" : 48747368
      }, {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 102, 117 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677880886986149888",
    "text" : "We've updated our homepage w\/ @btopro's Rethinking Systems Design from @DrupalCamp_ATL and apparently @hibbittsdesign is on our homepage!",
    "id" : 677880886986149888,
    "created_at" : "2015-12-18 15:59:32 +0000",
    "user" : {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "protected" : false,
      "id_str" : "236846178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601925668025278465\/4j0l2bWZ_normal.png",
      "id" : 236846178,
      "verified" : false
    }
  },
  "id" : 677902988090826752,
  "created_at" : "2015-12-18 17:27:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 0, 7 ],
      "id_str" : "236846178",
      "id" : 236846178
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 8, 15 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "DrupalCamp Atlanta",
      "screen_name" : "DrupalCamp_ATL",
      "indices" : [ 16, 31 ],
      "id_str" : "48747368",
      "id" : 48747368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677880886986149888",
  "geo" : { },
  "id_str" : "677902909082697728",
  "in_reply_to_user_id" : 236846178,
  "text" : "@elmsln @btopro @DrupalCamp_ATL Thanks so much for the shout-out, keep up the awesome work!",
  "id" : 677902909082697728,
  "in_reply_to_status_id" : 677880886986149888,
  "created_at" : "2015-12-18 17:27:03 +0000",
  "in_reply_to_screen_name" : "elmsln",
  "in_reply_to_user_id_str" : "236846178",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harold Jarche",
      "screen_name" : "hjarche",
      "indices" : [ 3, 11 ],
      "id_str" : "11698322",
      "id" : 11698322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677688129881526273",
  "text" : "RT @hjarche: I really dislike the term \"learner\". It's like calling a human being a \"breather\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677679088686006272",
    "text" : "I really dislike the term \"learner\". It's like calling a human being a \"breather\"",
    "id" : 677679088686006272,
    "created_at" : "2015-12-18 02:37:40 +0000",
    "user" : {
      "name" : "Harold Jarche",
      "screen_name" : "hjarche",
      "protected" : false,
      "id_str" : "11698322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608362206468710401\/aLkYjv31_normal.png",
      "id" : 11698322,
      "verified" : false
    }
  },
  "id" : 677688129881526273,
  "created_at" : "2015-12-18 03:13:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Source Way",
      "screen_name" : "opensourceway",
      "indices" : [ 3, 17 ],
      "id_str" : "80589255",
      "id" : 80589255
    }, {
      "name" : "Al Sweigart",
      "screen_name" : "AlSweigart",
      "indices" : [ 35, 46 ],
      "id_str" : "14738418",
      "id" : 14738418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/yZmoOx2DTy",
      "expanded_url" : "http:\/\/red.ht\/1L5WDfq",
      "display_url" : "red.ht\/1L5WDfq"
    } ]
  },
  "geo" : { },
  "id_str" : "677625111470579714",
  "text" : "RT @opensourceway: APIs, not apps: @AlSweigart tells us what the future will be like when everyone can code https:\/\/t.co\/yZmoOx2DTy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Al Sweigart",
        "screen_name" : "AlSweigart",
        "indices" : [ 16, 27 ],
        "id_str" : "14738418",
        "id" : 14738418
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/yZmoOx2DTy",
        "expanded_url" : "http:\/\/red.ht\/1L5WDfq",
        "display_url" : "red.ht\/1L5WDfq"
      } ]
    },
    "geo" : { },
    "id_str" : "677623561142542337",
    "text" : "APIs, not apps: @AlSweigart tells us what the future will be like when everyone can code https:\/\/t.co\/yZmoOx2DTy",
    "id" : 677623561142542337,
    "created_at" : "2015-12-17 22:57:01 +0000",
    "user" : {
      "name" : "Open Source Way",
      "screen_name" : "opensourceway",
      "protected" : false,
      "id_str" : "80589255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469124275572453376\/8fd3035c_normal.png",
      "id" : 80589255,
      "verified" : false
    }
  },
  "id" : 677625111470579714,
  "created_at" : "2015-12-17 23:03:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 37, 45 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 47, 54 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 59, 68 ],
      "id_str" : "180743261",
      "id" : 180743261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/bAPsLmhEfg",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/using-grav-with-github-and-deploy",
      "display_url" : "hibbittsdesign.org\/blog\/using-gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677582045292290048",
  "text" : "Web-savvy instructor? See how to use @getgrav, @GitHub and @deployhq for an open, collab &amp; very efficient workflow. https:\/\/t.co\/bAPsLmhEfg",
  "id" : 677582045292290048,
  "created_at" : "2015-12-17 20:12:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giansimon Diblas",
      "screen_name" : "giansi72",
      "indices" : [ 0, 9 ],
      "id_str" : "3230477368",
      "id" : 3230477368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677575749143011328",
  "geo" : { },
  "id_str" : "677576324462960641",
  "in_reply_to_user_id" : 3230477368,
  "text" : "@giansi72 Thanks very much, I will give the skeleton a try next.",
  "id" : 677576324462960641,
  "in_reply_to_status_id" : 677575749143011328,
  "created_at" : "2015-12-17 19:49:19 +0000",
  "in_reply_to_screen_name" : "giansi72",
  "in_reply_to_user_id_str" : "3230477368",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/pvYWEY1V8R",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/etug-spring-2014-developing-a-course-in-the-open-a-case-study#\/",
      "display_url" : "slides.com\/paulhibbitts\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677299155123867648",
  "text" : "Cool bananas. My slides for \"Developing a Course in the Open: A Case Study\" crossed over the 2000 views mark today. https:\/\/t.co\/pvYWEY1V8R",
  "id" : 677299155123867648,
  "created_at" : "2015-12-17 01:27:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/jfi4kWaKVm",
      "expanded_url" : "http:\/\/getgrav.org\/blog\/traditional-cms-platforms-and-grav",
      "display_url" : "getgrav.org\/blog\/tradition\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677287755748007936",
  "text" : "RT @getgrav: Questions have come up lately about how Grav themes are different from Joomla\/WordPress etc.  This post should help: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/jfi4kWaKVm",
        "expanded_url" : "http:\/\/getgrav.org\/blog\/traditional-cms-platforms-and-grav",
        "display_url" : "getgrav.org\/blog\/tradition\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677281443437932544",
    "text" : "Questions have come up lately about how Grav themes are different from Joomla\/WordPress etc.  This post should help: https:\/\/t.co\/jfi4kWaKVm",
    "id" : 677281443437932544,
    "created_at" : "2015-12-17 00:17:34 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 677287755748007936,
  "created_at" : "2015-12-17 00:42:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giansimon Diblas",
      "screen_name" : "giansi72",
      "indices" : [ 0, 9 ],
      "id_str" : "3230477368",
      "id" : 3230477368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675583156423102464",
  "geo" : { },
  "id_str" : "677277619558027264",
  "in_reply_to_user_id" : 3230477368,
  "text" : "@giansi72 Thanks! I've been trying to install the Gravstrap Theme (v0.9.7) via Admin Panel but no luck so far. Does an install work for you?",
  "id" : 677277619558027264,
  "in_reply_to_status_id" : 675583156423102464,
  "created_at" : "2015-12-17 00:02:22 +0000",
  "in_reply_to_screen_name" : "giansi72",
  "in_reply_to_user_id_str" : "3230477368",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677268435601068032",
  "geo" : { },
  "id_str" : "677269328425717764",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco Merry Christmas! \uD83C\uDF84",
  "id" : 677269328425717764,
  "in_reply_to_status_id" : 677268435601068032,
  "created_at" : "2015-12-16 23:29:25 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677269005510377472",
  "text" : "My acid-test for online course companions continues to be student requests for access even after course has ended. Indicates real edu value.",
  "id" : 677269005510377472,
  "created_at" : "2015-12-16 23:28:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Shapiro",
      "screen_name" : "philshapiro",
      "indices" : [ 3, 15 ],
      "id_str" : "40720843",
      "id" : 40720843
    }, {
      "name" : "Marius Moscovici",
      "screen_name" : "MMoscovici",
      "indices" : [ 86, 97 ],
      "id_str" : "725031481",
      "id" : 725031481
    }, {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 102, 113 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Open Source Way",
      "screen_name" : "opensourceway",
      "indices" : [ 119, 133 ],
      "id_str" : "80589255",
      "id" : 80589255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/sLc4uTg9VZ",
      "expanded_url" : "http:\/\/on.tcrn.ch\/l\/P7L0",
      "display_url" : "on.tcrn.ch\/l\/P7L0"
    } ]
  },
  "geo" : { },
  "id_str" : "677229761383424001",
  "text" : "RT @philshapiro: The Golden Age Of Open Source Has\u00A0Arrived https:\/\/t.co\/sLc4uTg9VZ by @mmoscovici via @techcrunch  (cc @opensourceway)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marius Moscovici",
        "screen_name" : "MMoscovici",
        "indices" : [ 69, 80 ],
        "id_str" : "725031481",
        "id" : 725031481
      }, {
        "name" : "TechCrunch",
        "screen_name" : "TechCrunch",
        "indices" : [ 85, 96 ],
        "id_str" : "816653",
        "id" : 816653
      }, {
        "name" : "Open Source Way",
        "screen_name" : "opensourceway",
        "indices" : [ 102, 116 ],
        "id_str" : "80589255",
        "id" : 80589255
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/sLc4uTg9VZ",
        "expanded_url" : "http:\/\/on.tcrn.ch\/l\/P7L0",
        "display_url" : "on.tcrn.ch\/l\/P7L0"
      } ]
    },
    "geo" : { },
    "id_str" : "677211320941477889",
    "text" : "The Golden Age Of Open Source Has\u00A0Arrived https:\/\/t.co\/sLc4uTg9VZ by @mmoscovici via @techcrunch  (cc @opensourceway)",
    "id" : 677211320941477889,
    "created_at" : "2015-12-16 19:38:55 +0000",
    "user" : {
      "name" : "Phil Shapiro",
      "screen_name" : "philshapiro",
      "protected" : false,
      "id_str" : "40720843",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718722605570768896\/LjKZjF17_normal.jpg",
      "id" : 40720843,
      "verified" : false
    }
  },
  "id" : 677229761383424001,
  "created_at" : "2015-12-16 20:52:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 131, 139 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "677224252345487360",
  "text" : "What is an example of a flipped-LMS approach using an open and collaborative learning platform? https:\/\/t.co\/I7fZ1cnbn3 Built with @getgrav.",
  "id" : 677224252345487360,
  "created_at" : "2015-12-16 20:30:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Warunika Ranaweera",
      "screen_name" : "WarunikaR",
      "indices" : [ 0, 10 ],
      "id_str" : "773940438",
      "id" : 773940438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677053037320364032",
  "geo" : { },
  "id_str" : "677180349583982592",
  "in_reply_to_user_id" : 773940438,
  "text" : "@WarunikaR I see it (mostly) as a communication failure on my part - something for me to still reflect upon.",
  "id" : 677180349583982592,
  "in_reply_to_status_id" : 677053037320364032,
  "created_at" : "2015-12-16 17:35:51 +0000",
  "in_reply_to_screen_name" : "WarunikaR",
  "in_reply_to_user_id_str" : "773940438",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/LzYLMeYplT",
      "expanded_url" : "http:\/\/www.ratemyprofessors.com\/ShowRatings.jsp?tid=96450",
      "display_url" : "ratemyprofessors.com\/ShowRatings.js\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676930542298865666",
  "text" : "Speechless about my most recent RMP ratings. No textbook was used for the course, but still an unfortunate outcome. https:\/\/t.co\/LzYLMeYplT",
  "id" : 676930542298865666,
  "created_at" : "2015-12-16 01:03:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gantry Framework",
      "screen_name" : "gantry_fw",
      "indices" : [ 3, 13 ],
      "id_str" : "3485276114",
      "id" : 3485276114
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 62, 70 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/6BWGpMcoaE",
      "expanded_url" : "http:\/\/gantry.org\/blog\/gantry5-meets-grav",
      "display_url" : "gantry.org\/blog\/gantry5-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676918086944104452",
  "text" : "RT @gantry_fw: We have CI Builds of first beta of Gantry5 for @getgrav CMS.  It runs, but we'll be bug fixing and improving it https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 47, 55 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/6BWGpMcoaE",
        "expanded_url" : "http:\/\/gantry.org\/blog\/gantry5-meets-grav",
        "display_url" : "gantry.org\/blog\/gantry5-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "676564383602892800",
    "text" : "We have CI Builds of first beta of Gantry5 for @getgrav CMS.  It runs, but we'll be bug fixing and improving it https:\/\/t.co\/6BWGpMcoaE",
    "id" : 676564383602892800,
    "created_at" : "2015-12-15 00:48:13 +0000",
    "user" : {
      "name" : "Gantry Framework",
      "screen_name" : "gantry_fw",
      "protected" : false,
      "id_str" : "3485276114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656192636479340544\/aBJrIUNP_normal.png",
      "id" : 3485276114,
      "verified" : false
    }
  },
  "id" : 676918086944104452,
  "created_at" : "2015-12-16 00:13:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "ServerPilot",
      "screen_name" : "ServerPilot",
      "indices" : [ 87, 99 ],
      "id_str" : "1137770767",
      "id" : 1137770767
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AWS",
      "indices" : [ 71, 75 ]
    }, {
      "text" : "EC2",
      "indices" : [ 76, 80 ]
    }, {
      "text" : "PHP7",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/aiVkpWZebe",
      "expanded_url" : "http:\/\/getgrav.org\/blog\/fast-free-grav-development",
      "display_url" : "getgrav.org\/blog\/fast-free\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676917738888175616",
  "text" : "RT @getgrav: Run Grav like a Boss! A guide to setup a blog for free on #AWS #EC2 using @ServerPilot to manage and provide #PHP7. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ServerPilot",
        "screen_name" : "ServerPilot",
        "indices" : [ 74, 86 ],
        "id_str" : "1137770767",
        "id" : 1137770767
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AWS",
        "indices" : [ 58, 62 ]
      }, {
        "text" : "EC2",
        "indices" : [ 63, 67 ]
      }, {
        "text" : "PHP7",
        "indices" : [ 109, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/aiVkpWZebe",
        "expanded_url" : "http:\/\/getgrav.org\/blog\/fast-free-grav-development",
        "display_url" : "getgrav.org\/blog\/fast-free\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "676902387920084992",
    "text" : "Run Grav like a Boss! A guide to setup a blog for free on #AWS #EC2 using @ServerPilot to manage and provide #PHP7. https:\/\/t.co\/aiVkpWZebe",
    "id" : 676902387920084992,
    "created_at" : "2015-12-15 23:11:20 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 676917738888175616,
  "created_at" : "2015-12-16 00:12:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676865298125819904",
  "text" : "An open and collaborative learning platform enables both students and instructors to contribute directly to their shared online environment.",
  "id" : 676865298125819904,
  "created_at" : "2015-12-15 20:43:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676862593827385344",
  "text" : "A flipped-LMS approach is where an open platform,\nin the full control of course participants,\nserves as an alternative front-end to the LMS.",
  "id" : 676862593827385344,
  "created_at" : "2015-12-15 20:33:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 0, 9 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676839006022328321",
  "geo" : { },
  "id_str" : "676839246913605632",
  "in_reply_to_user_id" : 837060721,
  "text" : "@m_travin It would plug into the workflow like a charm \uD83D\uDE00",
  "id" : 676839246913605632,
  "in_reply_to_status_id" : 676839006022328321,
  "created_at" : "2015-12-15 19:00:26 +0000",
  "in_reply_to_screen_name" : "m_travin",
  "in_reply_to_user_id_str" : "837060721",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676838406123458560",
  "text" : "Looks like I've got two concepts I need to visualize:\n\u2705Flipped-LMS approach\n\u2705Open and collaborative learning platform (using GitHub &amp; Grav)",
  "id" : 676838406123458560,
  "created_at" : "2015-12-15 18:57:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/RJrDyK8xWm",
      "expanded_url" : "https:\/\/youtu.be\/duZrKhfRYns",
      "display_url" : "youtu.be\/duZrKhfRYns"
    } ]
  },
  "geo" : { },
  "id_str" : "676568140013109252",
  "text" : "Gantry5 A New Dawn for Theming https:\/\/t.co\/RJrDyK8xWm via @YouTube",
  "id" : 676568140013109252,
  "created_at" : "2015-12-15 01:03:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 6, 14 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 22, 29 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 44, 53 ],
      "id_str" : "180743261",
      "id" : 180743261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/bAPsLmhEfg",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/using-grav-with-github-and-deploy",
      "display_url" : "hibbittsdesign.org\/blog\/using-gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676476543959367680",
  "text" : "Using @getgrav CMS w. @GitHub Desktop &amp; @deployhq https:\/\/t.co\/bAPsLmhEfg. An open, collaborative &amp; very efficient workflow for instructors.",
  "id" : 676476543959367680,
  "created_at" : "2015-12-14 18:59:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/bAPsLmhEfg",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/using-grav-with-github-and-deploy",
      "display_url" : "hibbittsdesign.org\/blog\/using-gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676216490404655104",
  "text" : "It's slowly getting there - a sneak peek at my biggest post yet: Grav CMS + GitHub + Deploy for course companions https:\/\/t.co\/bAPsLmhEfg",
  "id" : 676216490404655104,
  "created_at" : "2015-12-14 01:45:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 90, 97 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 104, 113 ],
      "id_str" : "180743261",
      "id" : 180743261
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 117, 125 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676173778909458432",
  "geo" : { },
  "id_str" : "676177110638067712",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Hang in there \uD83D\uDE00! Already using the time to write post about the wonders of @github &amp; @deployhq w. @getgrav for instructors\uD83C\uDF84.",
  "id" : 676177110638067712,
  "in_reply_to_status_id" : 676173778909458432,
  "created_at" : "2015-12-13 23:09:20 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676152269805514752",
  "text" : "Grading. Done.",
  "id" : 676152269805514752,
  "created_at" : "2015-12-13 21:30:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/675462189117890560\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/pxRsZNUuxY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV-5SCRUkAAI0A9.jpg",
      "id_str" : "675462188627169280",
      "id" : 675462188627169280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV-5SCRUkAAI0A9.jpg",
      "sizes" : [ {
        "h" : 289,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 145,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 82,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pxRsZNUuxY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/RlzJyHg7mJ",
      "expanded_url" : "http:\/\/getgrav.org\/blog\/grav-1.0-released",
      "display_url" : "getgrav.org\/blog\/grav-1.0-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675498779928231937",
  "text" : "RT @getgrav: Huge News!!! Grav 1.0 has been released!!!!\n\nhttps:\/\/t.co\/RlzJyHg7mJ https:\/\/t.co\/pxRsZNUuxY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/675462189117890560\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/pxRsZNUuxY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CV-5SCRUkAAI0A9.jpg",
        "id_str" : "675462188627169280",
        "id" : 675462188627169280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV-5SCRUkAAI0A9.jpg",
        "sizes" : [ {
          "h" : 289,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 145,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 82,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/pxRsZNUuxY"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/RlzJyHg7mJ",
        "expanded_url" : "http:\/\/getgrav.org\/blog\/grav-1.0-released",
        "display_url" : "getgrav.org\/blog\/grav-1.0-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "675462189117890560",
    "text" : "Huge News!!! Grav 1.0 has been released!!!!\n\nhttps:\/\/t.co\/RlzJyHg7mJ https:\/\/t.co\/pxRsZNUuxY",
    "id" : 675462189117890560,
    "created_at" : "2015-12-11 23:48:30 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 675498779928231937,
  "created_at" : "2015-12-12 02:13:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giansimon Diblas",
      "screen_name" : "giansi72",
      "indices" : [ 0, 9 ],
      "id_str" : "3230477368",
      "id" : 3230477368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675181075312812032",
  "geo" : { },
  "id_str" : "675380177082257408",
  "in_reply_to_user_id" : 3230477368,
  "text" : "@giansi72 Congratulations on the new theme! I look forward to checking it out.",
  "id" : 675380177082257408,
  "in_reply_to_status_id" : 675181075312812032,
  "created_at" : "2015-12-11 18:22:36 +0000",
  "in_reply_to_screen_name" : "giansi72",
  "in_reply_to_user_id_str" : "3230477368",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Official ACM",
      "screen_name" : "TheOfficialACM",
      "indices" : [ 3, 18 ],
      "id_str" : "115763683",
      "id" : 115763683
    }, {
      "name" : "Your Life",
      "screen_name" : "YourLifeTeam",
      "indices" : [ 63, 76 ],
      "id_str" : "2841885419",
      "id" : 2841885419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/3CRiNqDoG5",
      "expanded_url" : "http:\/\/ow.ly\/VInyt",
      "display_url" : "ow.ly\/VInyt"
    } ]
  },
  "geo" : { },
  "id_str" : "675109686165794816",
  "text" : "RT @TheOfficialACM: Happy 200th birthday, Ada Lovelace! Thanks @YourLifeTeam for this extremely creative biographical video on Ada: https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Your Life",
        "screen_name" : "YourLifeTeam",
        "indices" : [ 43, 56 ],
        "id_str" : "2841885419",
        "id" : 2841885419
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/3CRiNqDoG5",
        "expanded_url" : "http:\/\/ow.ly\/VInyt",
        "display_url" : "ow.ly\/VInyt"
      } ]
    },
    "geo" : { },
    "id_str" : "674965644287328256",
    "text" : "Happy 200th birthday, Ada Lovelace! Thanks @YourLifeTeam for this extremely creative biographical video on Ada: https:\/\/t.co\/3CRiNqDoG5",
    "id" : 674965644287328256,
    "created_at" : "2015-12-10 14:55:24 +0000",
    "user" : {
      "name" : "Official ACM",
      "screen_name" : "TheOfficialACM",
      "protected" : false,
      "id_str" : "115763683",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656872290492284928\/6Vk-M4KK_normal.jpg",
      "id" : 115763683,
      "verified" : false
    }
  },
  "id" : 675109686165794816,
  "created_at" : "2015-12-11 00:27:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trent Gill",
      "screen_name" : "trent_g",
      "indices" : [ 0, 8 ],
      "id_str" : "19269876",
      "id" : 19269876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674643150804135936",
  "geo" : { },
  "id_str" : "674702380236079104",
  "in_reply_to_user_id" : 19269876,
  "text" : "@trent_g Thanks very much, glad to know you are finding the blog of interest! The Grav CMS is a game changer to me.",
  "id" : 674702380236079104,
  "in_reply_to_status_id" : 674643150804135936,
  "created_at" : "2015-12-09 21:29:17 +0000",
  "in_reply_to_screen_name" : "trent_g",
  "in_reply_to_user_id_str" : "19269876",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 3, 18 ],
      "id_str" : "1122631",
      "id" : 1122631
    }, {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 74, 90 ],
      "id_str" : "17349291",
      "id" : 17349291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/9iuQYxJHVR",
      "expanded_url" : "https:\/\/twitter.com\/HabaneroConsult\/status\/674688790728859648",
      "display_url" : "twitter.com\/HabaneroConsul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674692630530265089",
  "text" : "RT @MalloryOConnor: The perfect Xmas gift for your team: UX training with @HabaneroConsult's UX Masterclass! 10% discount before Dec 31! ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Habanero",
        "screen_name" : "HabaneroConsult",
        "indices" : [ 54, 70 ],
        "id_str" : "17349291",
        "id" : 17349291
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/9iuQYxJHVR",
        "expanded_url" : "https:\/\/twitter.com\/HabaneroConsult\/status\/674688790728859648",
        "display_url" : "twitter.com\/HabaneroConsul\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "674692413202366464",
    "text" : "The perfect Xmas gift for your team: UX training with @HabaneroConsult's UX Masterclass! 10% discount before Dec 31! https:\/\/t.co\/9iuQYxJHVR",
    "id" : 674692413202366464,
    "created_at" : "2015-12-09 20:49:41 +0000",
    "user" : {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "protected" : false,
      "id_str" : "1122631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2261747531\/mallory_thumbnail_normal.png",
      "id" : 1122631,
      "verified" : false
    }
  },
  "id" : 674692630530265089,
  "created_at" : "2015-12-09 20:50:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DML Research Hub",
      "screen_name" : "DMLResearchHub",
      "indices" : [ 3, 18 ],
      "id_str" : "829574822",
      "id" : 829574822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HigherEd",
      "indices" : [ 63, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/deniiwdaIT",
      "expanded_url" : "http:\/\/bit.ly\/1inzIVm",
      "display_url" : "bit.ly\/1inzIVm"
    } ]
  },
  "geo" : { },
  "id_str" : "674639485867438080",
  "text" : "RT @DMLResearchHub: \"It's unacceptable for anyone who works in #HigherEd to be anti-tech or digitally underdeveloped\" https:\/\/t.co\/deniiwda\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HigherEd",
        "indices" : [ 43, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/deniiwdaIT",
        "expanded_url" : "http:\/\/bit.ly\/1inzIVm",
        "display_url" : "bit.ly\/1inzIVm"
      } ]
    },
    "geo" : { },
    "id_str" : "674638523274821632",
    "text" : "\"It's unacceptable for anyone who works in #HigherEd to be anti-tech or digitally underdeveloped\" https:\/\/t.co\/deniiwdaIT",
    "id" : 674638523274821632,
    "created_at" : "2015-12-09 17:15:32 +0000",
    "user" : {
      "name" : "DML Research Hub",
      "screen_name" : "DMLResearchHub",
      "protected" : false,
      "id_str" : "829574822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455874777979162624\/IGCLaTfR_normal.png",
      "id" : 829574822,
      "verified" : false
    }
  },
  "id" : 674639485867438080,
  "created_at" : "2015-12-09 17:19:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giansimon Diblas",
      "screen_name" : "giansi72",
      "indices" : [ 0, 9 ],
      "id_str" : "3230477368",
      "id" : 3230477368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674559519574355969",
  "geo" : { },
  "id_str" : "674613891943391232",
  "in_reply_to_user_id" : 3230477368,
  "text" : "@giansi72 Thanks for the update!",
  "id" : 674613891943391232,
  "in_reply_to_status_id" : 674559519574355969,
  "created_at" : "2015-12-09 15:37:40 +0000",
  "in_reply_to_screen_name" : "giansi72",
  "in_reply_to_user_id_str" : "3230477368",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "proflearn",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/kWBTpi4F1Y",
      "expanded_url" : "http:\/\/bit.ly\/21NaJh5",
      "display_url" : "bit.ly\/21NaJh5"
    } ]
  },
  "geo" : { },
  "id_str" : "674362461030486018",
  "text" : "RT @etug: Start the new year right this Tell: \"Busting through the Maze: Building and Supporting our 1st Mooc https:\/\/t.co\/kWBTpi4F1Y #prof\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "proflearn",
        "indices" : [ 124, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/kWBTpi4F1Y",
        "expanded_url" : "http:\/\/bit.ly\/21NaJh5",
        "display_url" : "bit.ly\/21NaJh5"
      } ]
    },
    "geo" : { },
    "id_str" : "674351244123635712",
    "text" : "Start the new year right this Tell: \"Busting through the Maze: Building and Supporting our 1st Mooc https:\/\/t.co\/kWBTpi4F1Y #proflearn",
    "id" : 674351244123635712,
    "created_at" : "2015-12-08 22:14:00 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 674362461030486018,
  "created_at" : "2015-12-08 22:58:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 12, 20 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/zHYKN1rRk8",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/grav-as-a-simple-open-publishing-tool",
      "display_url" : "hibbittsdesign.org\/blog\/grav-as-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674312901193129984",
  "text" : "Using Grav (@getgrav) as a GitHub-powered Open Publishing Tool https:\/\/t.co\/zHYKN1rRk8",
  "id" : 674312901193129984,
  "created_at" : "2015-12-08 19:41:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674302150810271744",
  "text" : "Last night I had not one, but two, students tell me they plan to encourage other instructors to try my flipped-LMS approach with Grav CMS.",
  "id" : 674302150810271744,
  "created_at" : "2015-12-08 18:58:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674016396175544325",
  "text" : "60 final CMPT 363 assignments submitted, 19 remaining with 90 minutes left.",
  "id" : 674016396175544325,
  "created_at" : "2015-12-08 00:03:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 6, 14 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/zHYKN1rRk8",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/grav-as-a-simple-open-publishing-tool",
      "display_url" : "hibbittsdesign.org\/blog\/grav-as-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673933084153110529",
  "text" : "Using @getgrav as a simple (but yet powerful) open publishing tool https:\/\/t.co\/zHYKN1rRk8",
  "id" : 673933084153110529,
  "created_at" : "2015-12-07 18:32:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/zHYKN1rRk8",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/grav-as-a-simple-open-publishing-tool",
      "display_url" : "hibbittsdesign.org\/blog\/grav-as-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673666870650601472",
  "text" : "Sunday night peek at an upcoming post on using Grav CMS as a simple open publishing tool https:\/\/t.co\/zHYKN1rRk8",
  "id" : 673666870650601472,
  "created_at" : "2015-12-07 00:54:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 42, 50 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 55, 62 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672944808306995202",
  "text" : "Almost finished an interesting setup with @getgrav and @github for an open publishing project I am about to start. More to share next week!",
  "id" : 672944808306995202,
  "created_at" : "2015-12-05 01:05:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 92, 99 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 130, 138 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672842987139825664",
  "text" : "(2\/2) Course companion starter kit will provide a strategy (flipped-LMS), an open workflow (@github) and a ready-to-use template (@getgrav).",
  "id" : 672842987139825664,
  "created_at" : "2015-12-04 18:20:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/TTgzGFnp4H",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/course-companion-starter-kit",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672842946832547840",
  "text" : "(1\/2) Everything digital starts with a placeholder, here is mine for today: https:\/\/t.co\/TTgzGFnp4H.",
  "id" : 672842946832547840,
  "created_at" : "2015-12-04 18:20:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Jo Richey",
      "screen_name" : "erinjo",
      "indices" : [ 3, 10 ],
      "id_str" : "14961286",
      "id" : 14961286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672611577078530048",
  "text" : "RT @erinjo: Two tropes I wish we, as technologists, would stop using: \"digital natives\" and \"so easy that your mom can use it\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/erinjo.idno.co\/\" rel=\"nofollow\"\u003EErin's Idno\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "672484579580645376",
    "text" : "Two tropes I wish we, as technologists, would stop using: \"digital natives\" and \"so easy that your mom can use it\".",
    "id" : 672484579580645376,
    "created_at" : "2015-12-03 18:36:32 +0000",
    "user" : {
      "name" : "Erin Jo Richey",
      "screen_name" : "erinjo",
      "protected" : false,
      "id_str" : "14961286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461635779010101248\/ngayZj4G_normal.jpeg",
      "id" : 14961286,
      "verified" : false
    }
  },
  "id" : 672611577078530048,
  "created_at" : "2015-12-04 03:01:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News",
      "screen_name" : "newsycombinator",
      "indices" : [ 3, 19 ],
      "id_str" : "14335498",
      "id" : 14335498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/bCA2x5e2AT",
      "expanded_url" : "https:\/\/github.com\/php\/php-src\/releases\/tag\/php-7.0.0",
      "display_url" : "github.com\/php\/php-src\/re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672581787109883905",
  "text" : "RT @newsycombinator: PHP 7 Released https:\/\/t.co\/bCA2x5e2AT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.steer.me\" rel=\"nofollow\"\u003Enewsycombinator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/bCA2x5e2AT",
        "expanded_url" : "https:\/\/github.com\/php\/php-src\/releases\/tag\/php-7.0.0",
        "display_url" : "github.com\/php\/php-src\/re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672023064494915584",
    "text" : "PHP 7 Released https:\/\/t.co\/bCA2x5e2AT",
    "id" : 672023064494915584,
    "created_at" : "2015-12-02 12:02:38 +0000",
    "user" : {
      "name" : "Hacker News",
      "screen_name" : "newsycombinator",
      "protected" : false,
      "id_str" : "14335498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469397708986269696\/iUrYEOpJ_normal.png",
      "id" : 14335498,
      "verified" : false
    }
  },
  "id" : 672581787109883905,
  "created_at" : "2015-12-04 01:02:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 30, 38 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672551233815580673",
  "text" : "Oh, and regarding my previous @getgrav tweets, I am planning to create a course companion starter kit for educators requiring 0% Twig too \uD83D\uDE00",
  "id" : 672551233815580673,
  "created_at" : "2015-12-03 23:01:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672549562532294656",
  "text" : "(4\/4) I think a lot of my fellow web-savvy educators could do some amazing things by learning, and applying, the basics of Twig with Grav.",
  "id" : 672549562532294656,
  "created_at" : "2015-12-03 22:54:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672549537207087104",
  "text" : "(3\/4) With a reasonable investment in time, learning Twig basics has gotten me closer to realizing my design than umpteen WordPress plugins.",
  "id" : 672549537207087104,
  "created_at" : "2015-12-03 22:54:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672549510237650944",
  "text" : "(2\/4) ease of use &amp; flexibility. While WordPress has various advantages, I am finding Twig much more friendly for customizations than PHP.",
  "id" : 672549510237650944,
  "created_at" : "2015-12-03 22:54:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 9, 17 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672549480739176448",
  "text" : "(1\/4) As @getgrav continues its march towards 1.0, I see so much promise in the platform (yes, platform, not just a CMS) in terms of both",
  "id" : 672549480739176448,
  "created_at" : "2015-12-03 22:54:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 44, 51 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672541999187144704",
  "text" : "I really can't say enough good things about @GitHub Desktop! It delivers version control, even across multiple machines, with a simple tap.",
  "id" : 672541999187144704,
  "created_at" : "2015-12-03 22:24:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/ogAd0uwAML",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/a-few-thoughts-about-sustainable-open-design-practice",
      "display_url" : "hibbittsdesign.org\/blog\/a-few-tho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672494006735998976",
  "text" : "A Few Thoughts About... Sustainable Open Design Practice https:\/\/t.co\/ogAd0uwAML",
  "id" : 672494006735998976,
  "created_at" : "2015-12-03 19:14:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Coolidge",
      "screen_name" : "acoolidge",
      "indices" : [ 0, 10 ],
      "id_str" : "17416175",
      "id" : 17416175
    }, {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 11, 27 ],
      "id_str" : "17462723",
      "id" : 17462723
    }, {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 28, 37 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672457688463249409",
  "geo" : { },
  "id_str" : "672490312506327040",
  "in_reply_to_user_id" : 17416175,
  "text" : "@acoolidge @creativecommons @BCcampus Wonderful news, congratulations Amanda!",
  "id" : 672490312506327040,
  "in_reply_to_status_id" : 672457688463249409,
  "created_at" : "2015-12-03 18:59:19 +0000",
  "in_reply_to_screen_name" : "acoolidge",
  "in_reply_to_user_id_str" : "17416175",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wikipedia",
      "screen_name" : "Wikipedia",
      "indices" : [ 18, 28 ],
      "id_str" : "86390214",
      "id" : 86390214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keepitfree",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/ZcJTUnXLR0",
      "expanded_url" : "https:\/\/donate.wikimedia.org\/?utm_medium=SocialMedia&utm_campaign=ThankYouPage&utm_source=Twitter",
      "display_url" : "donate.wikimedia.org\/?utm_medium=So\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672457015101288448",
  "text" : "I just donated to @Wikipedia. Help keep it free! #keepitfree https:\/\/t.co\/ZcJTUnXLR0",
  "id" : 672457015101288448,
  "created_at" : "2015-12-03 16:47:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/672302761677996033\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/xrmpSWBTbX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVR_zJsUsAA7P8p.png",
      "id_str" : "672302761136926720",
      "id" : 672302761136926720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVR_zJsUsAA7P8p.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 748,
        "resize" : "fit",
        "w" : 1496
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xrmpSWBTbX"
    } ],
    "hashtags" : [ {
      "text" : "Gantry5",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672436140570357760",
  "text" : "RT @getgrav: #Gantry5 running in Grav Admin plugin teaser!  It's pretty stunning! https:\/\/t.co\/xrmpSWBTbX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/672302761677996033\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/xrmpSWBTbX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVR_zJsUsAA7P8p.png",
        "id_str" : "672302761136926720",
        "id" : 672302761136926720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVR_zJsUsAA7P8p.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 748,
          "resize" : "fit",
          "w" : 1496
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/xrmpSWBTbX"
      } ],
      "hashtags" : [ {
        "text" : "Gantry5",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "672302761677996033",
    "text" : "#Gantry5 running in Grav Admin plugin teaser!  It's pretty stunning! https:\/\/t.co\/xrmpSWBTbX",
    "id" : 672302761677996033,
    "created_at" : "2015-12-03 06:34:03 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 672436140570357760,
  "created_at" : "2015-12-03 15:24:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/Ep268FONF0",
      "expanded_url" : "http:\/\/www.wired.com\/2014\/07\/out-in-the-open-sandstorm-makes-it-easy-to-control-your-apps-in-the-cloud\/",
      "display_url" : "wired.com\/2014\/07\/out-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672285565492989952",
  "text" : "RT @clintlalonde: Out in the Open: Sandstorm Makes It Easy to Control Your Apps in the Cloud https:\/\/t.co\/Ep268FONF0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/Ep268FONF0",
        "expanded_url" : "http:\/\/www.wired.com\/2014\/07\/out-in-the-open-sandstorm-makes-it-easy-to-control-your-apps-in-the-cloud\/",
        "display_url" : "wired.com\/2014\/07\/out-in\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672278470777442304",
    "text" : "Out in the Open: Sandstorm Makes It Easy to Control Your Apps in the Cloud https:\/\/t.co\/Ep268FONF0",
    "id" : 672278470777442304,
    "created_at" : "2015-12-03 04:57:32 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 672285565492989952,
  "created_at" : "2015-12-03 05:25:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672226944331571200",
  "text" : "(2\/2) where ongoing relationships + user research are key, and monetization via workshops\/consulting\/support for institutions and companies.",
  "id" : 672226944331571200,
  "created_at" : "2015-12-03 01:32:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672226903848148992",
  "text" : "(1\/2) Slowly navigating my way through a sustainable open design practice. Leaning towards open source materials for individual educators,",
  "id" : 672226903848148992,
  "created_at" : "2015-12-03 01:32:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 3, 10 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JIdfest",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672158157322366976",
  "text" : "RT @tanbob: JIBC's 3rd annual Demofest is this Thursday at 12.  If you are in the vicinity we'd love to have you drop by #JIdfest",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JIdfest",
        "indices" : [ 109, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671726036074160128",
    "text" : "JIBC's 3rd annual Demofest is this Thursday at 12.  If you are in the vicinity we'd love to have you drop by #JIdfest",
    "id" : 671726036074160128,
    "created_at" : "2015-12-01 16:22:21 +0000",
    "user" : {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "protected" : false,
      "id_str" : "10817782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530559772\/twitterProfilePhoto_normal.jpg",
      "id" : 10817782,
      "verified" : false
    }
  },
  "id" : 672158157322366976,
  "created_at" : "2015-12-02 20:59:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672130529597259777",
  "geo" : { },
  "id_str" : "672132121129967616",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Great to reconnect post-OpenEd!",
  "id" : 672132121129967616,
  "in_reply_to_status_id" : 672130529597259777,
  "created_at" : "2015-12-02 19:15:59 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "CMS Critic",
      "screen_name" : "cmscritic",
      "indices" : [ 69, 79 ],
      "id_str" : "16147963",
      "id" : 16147963
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/671881398551052288\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Ifr4lw09Xu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVMAkmPU8AAhLy5.png",
      "id_str" : "671881398148460544",
      "id" : 671881398148460544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVMAkmPU8AAhLy5.png",
      "sizes" : [ {
        "h" : 236,
        "resize" : "fit",
        "w" : 472
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 472
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 472
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ifr4lw09Xu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/Mh7j8kpzp4",
      "expanded_url" : "http:\/\/awards.cmscritic.com\/vote\/",
      "display_url" : "awards.cmscritic.com\/vote\/"
    } ]
  },
  "geo" : { },
  "id_str" : "671900262865309696",
  "text" : "RT @getgrav: Please vote for Grav in \"Best Free CMS\" category in the @cmscritic People's Choice awards https:\/\/t.co\/Mh7j8kpzp4 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CMS Critic",
        "screen_name" : "cmscritic",
        "indices" : [ 56, 66 ],
        "id_str" : "16147963",
        "id" : 16147963
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/671881398551052288\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/Ifr4lw09Xu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVMAkmPU8AAhLy5.png",
        "id_str" : "671881398148460544",
        "id" : 671881398148460544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVMAkmPU8AAhLy5.png",
        "sizes" : [ {
          "h" : 236,
          "resize" : "fit",
          "w" : 472
        }, {
          "h" : 236,
          "resize" : "fit",
          "w" : 472
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 236,
          "resize" : "fit",
          "w" : 472
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Ifr4lw09Xu"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/Mh7j8kpzp4",
        "expanded_url" : "http:\/\/awards.cmscritic.com\/vote\/",
        "display_url" : "awards.cmscritic.com\/vote\/"
      } ]
    },
    "geo" : { },
    "id_str" : "671881398551052288",
    "text" : "Please vote for Grav in \"Best Free CMS\" category in the @cmscritic People's Choice awards https:\/\/t.co\/Mh7j8kpzp4 https:\/\/t.co\/Ifr4lw09Xu",
    "id" : 671881398551052288,
    "created_at" : "2015-12-02 02:39:43 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 671900262865309696,
  "created_at" : "2015-12-02 03:54:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/dgZwX53bVU",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/why-a-modern-flat-file-cms",
      "display_url" : "hibbittsdesign.org\/blog\/why-a-mod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671802353398374400",
  "text" : "A sneak-peek at a new post: Why a modern flat-file (no database) CMS is my choice as an individual open educator. https:\/\/t.co\/dgZwX53bVU",
  "id" : 671802353398374400,
  "created_at" : "2015-12-01 21:25:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/zBjwzObqj6",
      "expanded_url" : "http:\/\/twig.sensiolabs.org\/doc\/templates.html",
      "display_url" : "twig.sensiolabs.org\/doc\/templates.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671748503920443392",
  "text" : "RT @getgrav: Grav top-tip #1, Read the Twig docs for designers: https:\/\/t.co\/zBjwzObqj6 -  Will help you get a solid handle on Twig's power\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/zBjwzObqj6",
        "expanded_url" : "http:\/\/twig.sensiolabs.org\/doc\/templates.html",
        "display_url" : "twig.sensiolabs.org\/doc\/templates.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "671746083312173056",
    "text" : "Grav top-tip #1, Read the Twig docs for designers: https:\/\/t.co\/zBjwzObqj6 -  Will help you get a solid handle on Twig's powerful features",
    "id" : 671746083312173056,
    "created_at" : "2015-12-01 17:42:01 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 671748503920443392,
  "created_at" : "2015-12-01 17:51:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BCcampus",
      "indices" : [ 119, 128 ]
    }, {
      "text" : "OER",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/2yXbwYEK5z",
      "expanded_url" : "http:\/\/ow.ly\/VkQvp",
      "display_url" : "ow.ly\/VkQvp"
    } ]
  },
  "geo" : { },
  "id_str" : "671746993862021120",
  "text" : "RT @BCcampus: The William and Flora Hewlett Foundation supports the B.C. Open Textbook Project https:\/\/t.co\/2yXbwYEK5z #BCcampus #OER",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BCcampus",
        "indices" : [ 105, 114 ]
      }, {
        "text" : "OER",
        "indices" : [ 115, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/2yXbwYEK5z",
        "expanded_url" : "http:\/\/ow.ly\/VkQvp",
        "display_url" : "ow.ly\/VkQvp"
      } ]
    },
    "geo" : { },
    "id_str" : "671739430760247296",
    "text" : "The William and Flora Hewlett Foundation supports the B.C. Open Textbook Project https:\/\/t.co\/2yXbwYEK5z #BCcampus #OER",
    "id" : 671739430760247296,
    "created_at" : "2015-12-01 17:15:35 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 671746993862021120,
  "created_at" : "2015-12-01 17:45:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]