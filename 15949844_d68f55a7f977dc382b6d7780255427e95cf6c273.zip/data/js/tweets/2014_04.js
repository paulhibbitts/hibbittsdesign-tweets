Grailbird.data.tweets_2014_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vivian Forssman",
      "screen_name" : "vivforssman",
      "indices" : [ 0, 12 ],
      "id_str" : "257351755",
      "id" : 257351755
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/oMfMbr244c",
      "expanded_url" : "http:\/\/iy103-w14.hibbittsdesign.com\/",
      "display_url" : "iy103-w14.hibbittsdesign.com"
    } ]
  },
  "in_reply_to_status_id_str" : "461658077343649792",
  "geo" : { },
  "id_str" : "461665369459924992",
  "in_reply_to_user_id" : 257351755,
  "text" : "@vivforssman True enough, but better learner experiences are still possible w Moodle. Here is a basic example of mine http:\/\/t.co\/oMfMbr244c",
  "id" : 461665369459924992,
  "in_reply_to_status_id" : 461658077343649792,
  "created_at" : "2014-05-01 00:36:16 +0000",
  "in_reply_to_screen_name" : "vivforssman",
  "in_reply_to_user_id_str" : "257351755",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Coolidge",
      "screen_name" : "acoolidge",
      "indices" : [ 0, 10 ],
      "id_str" : "17416175",
      "id" : 17416175
    }, {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 11, 18 ],
      "id_str" : "745903",
      "id" : 745903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461633664250433536",
  "geo" : { },
  "id_str" : "461645625851789312",
  "in_reply_to_user_id" : 17416175,
  "text" : "@acoolidge @brlamb Awesome to see this issue highlighted! Key acid-test I find is when students ask for access even after course is over.",
  "id" : 461645625851789312,
  "in_reply_to_status_id" : 461633664250433536,
  "created_at" : "2014-04-30 23:17:48 +0000",
  "in_reply_to_screen_name" : "acoolidge",
  "in_reply_to_user_id_str" : "17416175",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instructure",
      "screen_name" : "Instructure",
      "indices" : [ 0, 12 ],
      "id_str" : "2387820763",
      "id" : 2387820763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460886199167500288",
  "in_reply_to_user_id" : 41847236,
  "text" : "@instructure Any plans for adding the Chat feature to the open source version of Canvas?",
  "id" : 460886199167500288,
  "created_at" : "2014-04-28 21:00:07 +0000",
  "in_reply_to_screen_name" : "CanvasLMS",
  "in_reply_to_user_id_str" : "41847236",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Ives",
      "screen_name" : "hunch_box",
      "indices" : [ 3, 13 ],
      "id_str" : "551358460",
      "id" : 551358460
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oer",
      "indices" : [ 99, 103 ]
    }, {
      "text" : "oss",
      "indices" : [ 104, 108 ]
    }, {
      "text" : "inf530",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/2DHheGxPFH",
      "expanded_url" : "http:\/\/oss-watch.ac.uk\/resources\/ossoptionseducation",
      "display_url" : "oss-watch.ac.uk\/resources\/osso\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459841144474460160",
  "text" : "RT @hunch_box: A great software resource: Open Source Options for Education http:\/\/t.co\/2DHheGxPFH #oer #oss #inf530",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oer",
        "indices" : [ 84, 88 ]
      }, {
        "text" : "oss",
        "indices" : [ 89, 93 ]
      }, {
        "text" : "inf530",
        "indices" : [ 94, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/2DHheGxPFH",
        "expanded_url" : "http:\/\/oss-watch.ac.uk\/resources\/ossoptionseducation",
        "display_url" : "oss-watch.ac.uk\/resources\/osso\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "459818605321134081",
    "text" : "A great software resource: Open Source Options for Education http:\/\/t.co\/2DHheGxPFH #oer #oss #inf530",
    "id" : 459818605321134081,
    "created_at" : "2014-04-25 22:17:53 +0000",
    "user" : {
      "name" : "Matt Ives",
      "screen_name" : "hunch_box",
      "protected" : false,
      "id_str" : "551358460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681289297056509953\/vJMAYht8_normal.jpg",
      "id" : 551358460,
      "verified" : false
    }
  },
  "id" : 459841144474460160,
  "created_at" : "2014-04-25 23:47:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sync.com",
      "screen_name" : "Sync",
      "indices" : [ 0, 5 ],
      "id_str" : "551224728",
      "id" : 551224728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459794567202476032",
  "in_reply_to_user_id" : 551224728,
  "text" : "@Sync Loving the new Vault feature. Also just read on your site that you are planning to open source your client software - awesome move!",
  "id" : 459794567202476032,
  "created_at" : "2014-04-25 20:42:22 +0000",
  "in_reply_to_screen_name" : "Sync",
  "in_reply_to_user_id_str" : "551224728",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UXGuys",
      "screen_name" : "UXGUYS",
      "indices" : [ 3, 10 ],
      "id_str" : "23092914",
      "id" : 23092914
    }, {
      "name" : "Tara Franz",
      "screen_name" : "tarafranz",
      "indices" : [ 24, 34 ],
      "id_str" : "16337075",
      "id" : 16337075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/fP7CaN8X82",
      "expanded_url" : "http:\/\/www.meetup.com\/VancouverUE\/events\/177130612\/?a=me1_grp&rv=me1",
      "display_url" : "meetup.com\/VancouverUE\/ev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459785403625504768",
  "text" : "RT @UXGUYS: Hey tweeps! @tarafranz &amp; Anthony Hempell will be presenting to VanUE on \"Exploring the research toolbox\" Tue Apr 29! http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tara Franz",
        "screen_name" : "tarafranz",
        "indices" : [ 12, 22 ],
        "id_str" : "16337075",
        "id" : 16337075
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/fP7CaN8X82",
        "expanded_url" : "http:\/\/www.meetup.com\/VancouverUE\/events\/177130612\/?a=me1_grp&rv=me1",
        "display_url" : "meetup.com\/VancouverUE\/ev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "459785066957508608",
    "text" : "Hey tweeps! @tarafranz &amp; Anthony Hempell will be presenting to VanUE on \"Exploring the research toolbox\" Tue Apr 29! http:\/\/t.co\/fP7CaN8X82",
    "id" : 459785066957508608,
    "created_at" : "2014-04-25 20:04:37 +0000",
    "user" : {
      "name" : "UXGuys",
      "screen_name" : "UXGUYS",
      "protected" : false,
      "id_str" : "23092914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/89260231\/Picture_2_normal.png",
      "id" : 23092914,
      "verified" : false
    }
  },
  "id" : 459785403625504768,
  "created_at" : "2014-04-25 20:05:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 102, 109 ],
      "id_str" : "745903",
      "id" : 745903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459774271712006144",
  "text" : "Enjoyed being a part of today\u2019s Open Open Chat about innovative open learning environments! Thanks to @brlamb and everyone who participated.",
  "id" : 459774271712006144,
  "created_at" : "2014-04-25 19:21:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 3, 10 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 32, 47 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "novak rogic",
      "screen_name" : "supernova_k",
      "indices" : [ 52, 64 ],
      "id_str" : "3446221",
      "id" : 3446221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/F6Kt2zmqQo",
      "expanded_url" : "http:\/\/bcopened.org\/bc-open-open-ed-chats\/",
      "display_url" : "bcopened.org\/bc-open-open-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459754546147766273",
  "text" : "RT @brlamb: Open Open Chat with @hibbittsdesign and @supernova_k underway in a few minutes: http:\/\/t.co\/F6Kt2zmqQo (Note new login informat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 20, 35 ],
        "id_str" : "15949844",
        "id" : 15949844
      }, {
        "name" : "novak rogic",
        "screen_name" : "supernova_k",
        "indices" : [ 40, 52 ],
        "id_str" : "3446221",
        "id" : 3446221
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/F6Kt2zmqQo",
        "expanded_url" : "http:\/\/bcopened.org\/bc-open-open-ed-chats\/",
        "display_url" : "bcopened.org\/bc-open-open-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "459753885469401088",
    "text" : "Open Open Chat with @hibbittsdesign and @supernova_k underway in a few minutes: http:\/\/t.co\/F6Kt2zmqQo (Note new login information).",
    "id" : 459753885469401088,
    "created_at" : "2014-04-25 18:00:42 +0000",
    "user" : {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "protected" : false,
      "id_str" : "745903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671910130498203649\/btEUG3ES_normal.jpg",
      "id" : 745903,
      "verified" : false
    }
  },
  "id" : 459754546147766273,
  "created_at" : "2014-04-25 18:03:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 3, 10 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 42, 57 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "novak rogic",
      "screen_name" : "supernova_k",
      "indices" : [ 62, 74 ],
      "id_str" : "3446221",
      "id" : 3446221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/MTlGn2Pk6A",
      "expanded_url" : "http:\/\/bcopened.org\/bc-open-open-ed-chats\/",
      "display_url" : "bcopened.org\/bc-open-open-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459075564381282304",
  "text" : "RT @brlamb: Friday, 11 AM PDT, we'll have @hibbittsdesign and @supernova_k join us for an Open Open Chat on open course spaces: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 30, 45 ],
        "id_str" : "15949844",
        "id" : 15949844
      }, {
        "name" : "novak rogic",
        "screen_name" : "supernova_k",
        "indices" : [ 50, 62 ],
        "id_str" : "3446221",
        "id" : 3446221
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/MTlGn2Pk6A",
        "expanded_url" : "http:\/\/bcopened.org\/bc-open-open-ed-chats\/",
        "display_url" : "bcopened.org\/bc-open-open-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "459073845404925952",
    "text" : "Friday, 11 AM PDT, we'll have @hibbittsdesign and @supernova_k join us for an Open Open Chat on open course spaces: http:\/\/t.co\/MTlGn2Pk6A",
    "id" : 459073845404925952,
    "created_at" : "2014-04-23 20:58:28 +0000",
    "user" : {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "protected" : false,
      "id_str" : "745903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671910130498203649\/btEUG3ES_normal.jpg",
      "id" : 745903,
      "verified" : false
    }
  },
  "id" : 459075564381282304,
  "created_at" : "2014-04-23 21:05:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft OneNote",
      "screen_name" : "msonenote",
      "indices" : [ 0, 10 ],
      "id_str" : "23735316",
      "id" : 23735316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459016385985650688",
  "in_reply_to_user_id" : 23735316,
  "text" : "@msonenote Is there a technique for links between Notebook pages to work on all clients? My page-to-page links break on iOS and Android...",
  "id" : 459016385985650688,
  "created_at" : "2014-04-23 17:10:09 +0000",
  "in_reply_to_screen_name" : "msonenote",
  "in_reply_to_user_id_str" : "23735316",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/QAZDgXiHWw",
      "expanded_url" : "http:\/\/www.cstudies.ubc.ca\/a\/Course\/Designing-Multi-device-Learning-Experiences\/IY103\/",
      "display_url" : "cstudies.ubc.ca\/a\/Course\/Desig\u2026"
    }, {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/UbWsdPACcq",
      "expanded_url" : "http:\/\/1drv.ms\/1f0v0L7",
      "display_url" : "1drv.ms\/1f0v0L7"
    } ]
  },
  "geo" : { },
  "id_str" : "459004931924451328",
  "text" : "Multi-device Learning Experiences is now a one-day workshop! Info at http:\/\/t.co\/QAZDgXiHWw OneNote companion at http:\/\/t.co\/UbWsdPACcq",
  "id" : 459004931924451328,
  "created_at" : "2014-04-23 16:24:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2014",
      "indices" : [ 29, 39 ]
    }, {
      "text" : "OER",
      "indices" : [ 122, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/o9QeLyDQYA",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/imoot-2014-developing-a-course-in-the-open-a-case-study",
      "display_url" : "slides.com\/paulhibbitts\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "458649760849592321",
  "text" : "Draft slides for my upcoming #iMoot2014 presentation Developing a Course in the Open: A Case Study http:\/\/t.co\/o9QeLyDQYA #OER",
  "id" : 458649760849592321,
  "created_at" : "2014-04-22 16:53:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aza Raskin",
      "screen_name" : "aza",
      "indices" : [ 3, 7 ],
      "id_str" : "13370272",
      "id" : 13370272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/rC13xXOKz6",
      "expanded_url" : "http:\/\/jsmess.textfiles.com\/",
      "display_url" : "jsmess.textfiles.com"
    } ]
  },
  "geo" : { },
  "id_str" : "456976476332503040",
  "text" : "RT @aza: \"Every computer that every existed. In your browser.\" Bold slogan. http:\/\/t.co\/rC13xXOKz6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/rC13xXOKz6",
        "expanded_url" : "http:\/\/jsmess.textfiles.com\/",
        "display_url" : "jsmess.textfiles.com"
      } ]
    },
    "geo" : { },
    "id_str" : "456970467392229377",
    "text" : "\"Every computer that every existed. In your browser.\" Bold slogan. http:\/\/t.co\/rC13xXOKz6",
    "id" : 456970467392229377,
    "created_at" : "2014-04-18 01:40:24 +0000",
    "user" : {
      "name" : "Aza Raskin",
      "screen_name" : "aza",
      "protected" : false,
      "id_str" : "13370272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801298949\/Aza_Evil_normal.png",
      "id" : 13370272,
      "verified" : false
    }
  },
  "id" : 456976476332503040,
  "created_at" : "2014-04-18 02:04:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barish Golland",
      "screen_name" : "BarishGolland",
      "indices" : [ 0, 14 ],
      "id_str" : "32352319",
      "id" : 32352319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456841144840638464",
  "geo" : { },
  "id_str" : "456853026561458176",
  "in_reply_to_user_id" : 32352319,
  "text" : "@BarishGolland Thanks Barish, I am really looking forward to the one-day workshop!",
  "id" : 456853026561458176,
  "in_reply_to_status_id" : 456841144840638464,
  "created_at" : "2014-04-17 17:53:44 +0000",
  "in_reply_to_screen_name" : "BarishGolland",
  "in_reply_to_user_id_str" : "32352319",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 0, 7 ],
      "id_str" : "745903",
      "id" : 745903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456564769961418752",
  "geo" : { },
  "id_str" : "456566480834813952",
  "in_reply_to_user_id" : 745903,
  "text" : "@brlamb Thanks for the info! Please feel free to let me know if I can be of assistance with regards to my own UX design work in that area.",
  "id" : 456566480834813952,
  "in_reply_to_status_id" : 456564769961418752,
  "created_at" : "2014-04-16 22:55:06 +0000",
  "in_reply_to_screen_name" : "brlamb",
  "in_reply_to_user_id_str" : "745903",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 0, 7 ],
      "id_str" : "745903",
      "id" : 745903
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OTSummit",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456563136753987584",
  "geo" : { },
  "id_str" : "456564250186510337",
  "in_reply_to_user_id" : 745903,
  "text" : "@brlamb Watching the livestream of the #OTSummit - where was that student-led learning space design project you mentioned? Sounded awesome!",
  "id" : 456564250186510337,
  "in_reply_to_status_id" : 456563136753987584,
  "created_at" : "2014-04-16 22:46:14 +0000",
  "in_reply_to_screen_name" : "brlamb",
  "in_reply_to_user_id_str" : "745903",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456553798870122498",
  "geo" : { },
  "id_str" : "456561204580720640",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters Congratulations on the launch of Educating Modern Learners! Really like the summary-style questions at the end of articles.",
  "id" : 456561204580720640,
  "in_reply_to_status_id" : 456553798870122498,
  "created_at" : "2014-04-16 22:34:08 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/dfp7XZiWNg",
      "expanded_url" : "http:\/\/modernlearners.com",
      "display_url" : "modernlearners.com"
    } ]
  },
  "geo" : { },
  "id_str" : "456557010914271234",
  "text" : "RT @audreywatters: Educating Modern Learners is live! http:\/\/t.co\/dfp7XZiWNg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/dfp7XZiWNg",
        "expanded_url" : "http:\/\/modernlearners.com",
        "display_url" : "modernlearners.com"
      } ]
    },
    "geo" : { },
    "id_str" : "456553798870122498",
    "text" : "Educating Modern Learners is live! http:\/\/t.co\/dfp7XZiWNg",
    "id" : 456553798870122498,
    "created_at" : "2014-04-16 22:04:42 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 456557010914271234,
  "created_at" : "2014-04-16 22:17:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OTSummit",
      "indices" : [ 40, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/MibIKTK6fM",
      "expanded_url" : "http:\/\/bit.ly\/1l7LJdw",
      "display_url" : "bit.ly\/1l7LJdw"
    } ]
  },
  "geo" : { },
  "id_str" : "456522130318827520",
  "text" : "Lots of learning + inspiration from the #OTSummit today! Check out the livestream at http:\/\/t.co\/MibIKTK6fM",
  "id" : 456522130318827520,
  "created_at" : "2014-04-16 19:58:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Senack",
      "screen_name" : "HigherEdPIRG",
      "indices" : [ 3, 16 ],
      "id_str" : "237449973",
      "id" : 237449973
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HigherEdPIRG\/status\/456503052711628800\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/jUn9gO8Fbf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlXTG2XCEAE9fRW.jpg",
      "id_str" : "456503051872768001",
      "id" : 456503051872768001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlXTG2XCEAE9fRW.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jUn9gO8Fbf"
    } ],
    "hashtags" : [ {
      "text" : "otsummit",
      "indices" : [ 102, 111 ]
    }, {
      "text" : "opentextbooksparallel",
      "indices" : [ 112, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456505463765352448",
  "text" : "RT @HigherEdPIRG: Open-source software started as cheap &amp; good enough. Now, it drives innovation. #otsummit #opentextbooksparallel http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HigherEdPIRG\/status\/456503052711628800\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/jUn9gO8Fbf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BlXTG2XCEAE9fRW.jpg",
        "id_str" : "456503051872768001",
        "id" : 456503051872768001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlXTG2XCEAE9fRW.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/jUn9gO8Fbf"
      } ],
      "hashtags" : [ {
        "text" : "otsummit",
        "indices" : [ 84, 93 ]
      }, {
        "text" : "opentextbooksparallel",
        "indices" : [ 94, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "456503052711628800",
    "text" : "Open-source software started as cheap &amp; good enough. Now, it drives innovation. #otsummit #opentextbooksparallel http:\/\/t.co\/jUn9gO8Fbf",
    "id" : 456503052711628800,
    "created_at" : "2014-04-16 18:43:03 +0000",
    "user" : {
      "name" : "Ethan Senack",
      "screen_name" : "HigherEdPIRG",
      "protected" : false,
      "id_str" : "237449973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/420980207944597504\/_8UrwLbo_normal.jpeg",
      "id" : 237449973,
      "verified" : false
    }
  },
  "id" : 456505463765352448,
  "created_at" : "2014-04-16 18:52:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Belshaw",
      "screen_name" : "JohnBelshaw",
      "indices" : [ 3, 15 ],
      "id_str" : "43976999",
      "id" : 43976999
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "otsummit",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456491236585521152",
  "text" : "RT @JohnBelshaw: Getting faculty to adopt OERs\/OpenTexts -- if building valuable assignments works for students, it will work for faculty t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "otsummit",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "456490012746346496",
    "text" : "Getting faculty to adopt OERs\/OpenTexts -- if building valuable assignments works for students, it will work for faculty too. #otsummit",
    "id" : 456490012746346496,
    "created_at" : "2014-04-16 17:51:14 +0000",
    "user" : {
      "name" : "John Belshaw",
      "screen_name" : "JohnBelshaw",
      "protected" : false,
      "id_str" : "43976999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571001950779359232\/-77S8uxx_normal.jpeg",
      "id" : 43976999,
      "verified" : false
    }
  },
  "id" : 456491236585521152,
  "created_at" : "2014-04-16 17:56:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OTSummit",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/sxJUDUNnPq",
      "expanded_url" : "http:\/\/bit.ly\/1palWaI",
      "display_url" : "bit.ly\/1palWaI"
    } ]
  },
  "geo" : { },
  "id_str" : "456473496655122432",
  "text" : "RT @BCcampus: \"Ask not what your wiki can do for you, but what you can do for your wiki.\u201D\" http:\/\/t.co\/sxJUDUNnPq #OTSummit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OTSummit",
        "indices" : [ 100, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/sxJUDUNnPq",
        "expanded_url" : "http:\/\/bit.ly\/1palWaI",
        "display_url" : "bit.ly\/1palWaI"
      } ]
    },
    "geo" : { },
    "id_str" : "456473060246167552",
    "text" : "\"Ask not what your wiki can do for you, but what you can do for your wiki.\u201D\" http:\/\/t.co\/sxJUDUNnPq #OTSummit",
    "id" : 456473060246167552,
    "created_at" : "2014-04-16 16:43:53 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 456473496655122432,
  "created_at" : "2014-04-16 16:45:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "otsummit",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/T1t10gL3hz",
      "expanded_url" : "http:\/\/bit.ly\/1l7LJdw",
      "display_url" : "bit.ly\/1l7LJdw"
    } ]
  },
  "geo" : { },
  "id_str" : "456461127585497088",
  "text" : "RT @clintlalonde: Minister Virk welcoming attendees to the #otsummit. Livestreaming at http:\/\/t.co\/T1t10gL3hz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "otsummit",
        "indices" : [ 41, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/T1t10gL3hz",
        "expanded_url" : "http:\/\/bit.ly\/1l7LJdw",
        "display_url" : "bit.ly\/1l7LJdw"
      } ]
    },
    "geo" : { },
    "id_str" : "456456036623216642",
    "text" : "Minister Virk welcoming attendees to the #otsummit. Livestreaming at http:\/\/t.co\/T1t10gL3hz",
    "id" : 456456036623216642,
    "created_at" : "2014-04-16 15:36:14 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 456461127585497088,
  "created_at" : "2014-04-16 15:56:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edutopia",
      "screen_name" : "edutopia",
      "indices" : [ 3, 12 ],
      "id_str" : "35415477",
      "id" : 35415477
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/edutopia\/status\/456233233416351744\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/BvhpKxuTxD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlTdtVVCAAEt748.jpg",
      "id_str" : "456233233160470529",
      "id" : 456233233160470529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlTdtVVCAAEt748.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BvhpKxuTxD"
    } ],
    "hashtags" : [ {
      "text" : "teachers",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/n0WgPj4eo4",
      "expanded_url" : "http:\/\/edut.to\/1na4O2W",
      "display_url" : "edut.to\/1na4O2W"
    } ]
  },
  "geo" : { },
  "id_str" : "456238268741201921",
  "text" : "RT @edutopia: \"I teach because I love to learn.\u201D #teachers http:\/\/t.co\/n0WgPj4eo4. http:\/\/t.co\/BvhpKxuTxD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/edutopia\/status\/456233233416351744\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/BvhpKxuTxD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BlTdtVVCAAEt748.jpg",
        "id_str" : "456233233160470529",
        "id" : 456233233160470529,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlTdtVVCAAEt748.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BvhpKxuTxD"
      } ],
      "hashtags" : [ {
        "text" : "teachers",
        "indices" : [ 35, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/n0WgPj4eo4",
        "expanded_url" : "http:\/\/edut.to\/1na4O2W",
        "display_url" : "edut.to\/1na4O2W"
      } ]
    },
    "geo" : { },
    "id_str" : "456233233416351744",
    "text" : "\"I teach because I love to learn.\u201D #teachers http:\/\/t.co\/n0WgPj4eo4. http:\/\/t.co\/BvhpKxuTxD",
    "id" : 456233233416351744,
    "created_at" : "2014-04-16 00:50:53 +0000",
    "user" : {
      "name" : "edutopia",
      "screen_name" : "edutopia",
      "protected" : false,
      "id_str" : "35415477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582733084514086912\/QbYyrd-O_normal.png",
      "id" : 35415477,
      "verified" : true
    }
  },
  "id" : 456238268741201921,
  "created_at" : "2014-04-16 01:10:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/aaBlHLqmMM",
      "expanded_url" : "http:\/\/ift.tt\/1eCShNA",
      "display_url" : "ift.tt\/1eCShNA"
    } ]
  },
  "geo" : { },
  "id_str" : "456123637267849216",
  "text" : "RT @etug: New post! [T.e.l.l. March Summary] Designing a Multi-device Moodle Course site: A Case Study http:\/\/t.co\/aaBlHLqmMM #ETUG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ETUG",
        "indices" : [ 116, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/aaBlHLqmMM",
        "expanded_url" : "http:\/\/ift.tt\/1eCShNA",
        "display_url" : "ift.tt\/1eCShNA"
      } ]
    },
    "geo" : { },
    "id_str" : "455581566350401536",
    "text" : "New post! [T.e.l.l. March Summary] Designing a Multi-device Moodle Course site: A Case Study http:\/\/t.co\/aaBlHLqmMM #ETUG",
    "id" : 455581566350401536,
    "created_at" : "2014-04-14 05:41:24 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 456123637267849216,
  "created_at" : "2014-04-15 17:35:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blackboard",
      "screen_name" : "Blackboard",
      "indices" : [ 0, 11 ],
      "id_str" : "70406994",
      "id" : 70406994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/bC6lQmStaq",
      "expanded_url" : "http:\/\/etug.ca\/2014\/03\/24\/designing-a-multi-device-moodle-course-site\/",
      "display_url" : "etug.ca\/2014\/03\/24\/des\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "455873597429792768",
  "geo" : { },
  "id_str" : "455874372524199936",
  "in_reply_to_user_id" : 70406994,
  "text" : "@Blackboard Appreciate the reply! Please let me know what you find out. Here is a link to the recording in question: http:\/\/t.co\/bC6lQmStaq",
  "id" : 455874372524199936,
  "in_reply_to_status_id" : 455873597429792768,
  "created_at" : "2014-04-15 01:04:54 +0000",
  "in_reply_to_screen_name" : "Blackboard",
  "in_reply_to_user_id_str" : "70406994",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blackboard",
      "screen_name" : "Blackboard",
      "indices" : [ 0, 11 ],
      "id_str" : "70406994",
      "id" : 70406994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455871802711879680",
  "in_reply_to_user_id" : 70406994,
  "text" : "@Blackboard Any plans to support the recording of Web Tours in Blackboard Collaborate? Big let down to see it missing from a recording :-(",
  "id" : 455871802711879680,
  "created_at" : "2014-04-15 00:54:42 +0000",
  "in_reply_to_screen_name" : "Blackboard",
  "in_reply_to_user_id_str" : "70406994",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/QKBw98n4Po",
      "expanded_url" : "http:\/\/www.mindmeister.com\/387130789\/designing-a-course-in-the-open-a-case-study",
      "display_url" : "mindmeister.com\/387130789\/desi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "455828319741562880",
  "text" : "Follow-up to my tweet about developing courses in the open, here is a visual topic map of the presentation so far: http:\/\/t.co\/QKBw98n4Po",
  "id" : 455828319741562880,
  "created_at" : "2014-04-14 22:01:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tylor Sherman",
      "screen_name" : "tylorsherman",
      "indices" : [ 0, 13 ],
      "id_str" : "6274112",
      "id" : 6274112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455824574194528256",
  "geo" : { },
  "id_str" : "455825872616845312",
  "in_reply_to_user_id" : 6274112,
  "text" : "@tylorsherman Awesome, thanks Tylor! Updated list:  honesty, accountability, collaboration, criticism, and enrolment.",
  "id" : 455825872616845312,
  "in_reply_to_status_id" : 455824574194528256,
  "created_at" : "2014-04-14 21:52:11 +0000",
  "in_reply_to_screen_name" : "tylorsherman",
  "in_reply_to_user_id_str" : "6274112",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455823129407807488",
  "text" : "Working on a presentation about developing courses in the open. Benefits\/risks: honesty, accountability, criticism, and enrolment. Others?",
  "id" : 455823129407807488,
  "created_at" : "2014-04-14 21:41:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455797608783425536",
  "text" : "OneNote might be a viable course companion platform: multi-device support, collaborative, sharable, searchable, and offline access. Others?",
  "id" : 455797608783425536,
  "created_at" : "2014-04-14 19:59:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft OneNote",
      "screen_name" : "msonenote",
      "indices" : [ 11, 21 ],
      "id_str" : "23735316",
      "id" : 23735316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/mCLndoJch6",
      "expanded_url" : "http:\/\/1drv.ms\/1qKCL7L",
      "display_url" : "1drv.ms\/1qKCL7L"
    } ]
  },
  "geo" : { },
  "id_str" : "455791679388127232",
  "text" : "Trying out @msonenote as a multi-device course companion for one-day workshop. http:\/\/t.co\/mCLndoJch6 Contact me for mobile app invite.",
  "id" : 455791679388127232,
  "created_at" : "2014-04-14 19:36:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft OneNote",
      "screen_name" : "msonenote",
      "indices" : [ 0, 10 ],
      "id_str" : "23735316",
      "id" : 23735316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454721434208985088",
  "geo" : { },
  "id_str" : "454724201622937600",
  "in_reply_to_user_id" : 23735316,
  "text" : "@msonenote For sure, and I've just submitted more detailed feedback under the category \"Other\". I did not see a OneNote category. Thanks!",
  "id" : 454724201622937600,
  "in_reply_to_status_id" : 454721434208985088,
  "created_at" : "2014-04-11 20:54:32 +0000",
  "in_reply_to_screen_name" : "msonenote",
  "in_reply_to_user_id_str" : "23735316",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft OneNote",
      "screen_name" : "msonenote",
      "indices" : [ 0, 10 ],
      "id_str" : "23735316",
      "id" : 23735316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454679099428978688",
  "in_reply_to_user_id" : 23735316,
  "text" : "@msonenote Thanks for the Mac version and recent updates! Would love to see some responsive elements for multi-devices i.e. tables &amp; images.",
  "id" : 454679099428978688,
  "created_at" : "2014-04-11 17:55:19 +0000",
  "in_reply_to_screen_name" : "msonenote",
  "in_reply_to_user_id_str" : "23735316",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/kkoxkkZwtZ",
      "expanded_url" : "http:\/\/www.elearningguild.com\/research\/archives\/index.cfm?id=174&action=viewonly&utm_campaign=elg&utm_medium=some&utm_source=wdg-tw#.U0WCNPtQbvM.twitter",
      "display_url" : "elearningguild.com\/research\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453946478973562880",
  "text" : "The eLearning Guild : Making mLearning Usable: How We Use Mobile Devices : Research Library http:\/\/t.co\/kkoxkkZwtZ",
  "id" : 453946478973562880,
  "created_at" : "2014-04-09 17:24:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 3, 11 ],
      "id_str" : "5690792",
      "id" : 5690792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openedmedia",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/fvNMxjjI13",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/enroll\/CBT3DR",
      "display_url" : "canvas.sfu.ca\/enroll\/CBT3DR"
    } ]
  },
  "geo" : { },
  "id_str" : "453614012169605121",
  "text" : "RT @draggin: OER workshop fully open to those with an SFU computing ID. Feel free to sign up here! https:\/\/t.co\/fvNMxjjI13 #openedmedia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openedmedia",
        "indices" : [ 110, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/fvNMxjjI13",
        "expanded_url" : "https:\/\/canvas.sfu.ca\/enroll\/CBT3DR",
        "display_url" : "canvas.sfu.ca\/enroll\/CBT3DR"
      } ]
    },
    "geo" : { },
    "id_str" : "453606721634566144",
    "text" : "OER workshop fully open to those with an SFU computing ID. Feel free to sign up here! https:\/\/t.co\/fvNMxjjI13 #openedmedia",
    "id" : 453606721634566144,
    "created_at" : "2014-04-08 18:54:04 +0000",
    "user" : {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "protected" : false,
      "id_str" : "5690792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749667549248270336\/7VoQZUTn_normal.jpg",
      "id" : 5690792,
      "verified" : false
    }
  },
  "id" : 453614012169605121,
  "created_at" : "2014-04-08 19:23:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453245142225272832",
  "geo" : { },
  "id_str" : "453246989191221248",
  "in_reply_to_user_id" : 15949844,
  "text" : "@sparkandco Thanks very much the RT, greatly appreciated!",
  "id" : 453246989191221248,
  "in_reply_to_status_id" : 453245142225272832,
  "created_at" : "2014-04-07 19:04:37 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/QAZDgXiHWw",
      "expanded_url" : "http:\/\/www.cstudies.ubc.ca\/a\/Course\/Designing-Multi-device-Learning-Experiences\/IY103\/",
      "display_url" : "cstudies.ubc.ca\/a\/Course\/Desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453245142225272832",
  "text" : "Looks like I need at least 3 more people to sign-up for Designing Multi-device Learning Experiences before tomorrow. http:\/\/t.co\/QAZDgXiHWw",
  "id" : 453245142225272832,
  "created_at" : "2014-04-07 18:57:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moodle News",
      "screen_name" : "moodlenews",
      "indices" : [ 3, 14 ],
      "id_str" : "96450920",
      "id" : 96450920
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2014",
      "indices" : [ 16, 26 ]
    }, {
      "text" : "Moodle",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/UbWqCbAsOy",
      "expanded_url" : "http:\/\/wp.me\/pPsqH-3xC",
      "display_url" : "wp.me\/pPsqH-3xC"
    } ]
  },
  "geo" : { },
  "id_str" : "452123083642376192",
  "text" : "RT @moodlenews: #iMoot2014 releases the first list of accepted presentations, shoots for 60 total #Moodle http:\/\/t.co\/UbWqCbAsOy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iMoot2014",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "Moodle",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/UbWqCbAsOy",
        "expanded_url" : "http:\/\/wp.me\/pPsqH-3xC",
        "display_url" : "wp.me\/pPsqH-3xC"
      } ]
    },
    "geo" : { },
    "id_str" : "452083366892806144",
    "text" : "#iMoot2014 releases the first list of accepted presentations, shoots for 60 total #Moodle http:\/\/t.co\/UbWqCbAsOy",
    "id" : 452083366892806144,
    "created_at" : "2014-04-04 14:00:48 +0000",
    "user" : {
      "name" : "Moodle News",
      "screen_name" : "moodlenews",
      "protected" : false,
      "id_str" : "96450920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/889559056\/moodlenewsicon_normal.png",
      "id" : 96450920,
      "verified" : false
    }
  },
  "id" : 452123083642376192,
  "created_at" : "2014-04-04 16:38:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/ZmG6YOGpMb",
      "expanded_url" : "http:\/\/iy103-w14.hibbittsdesign.com",
      "display_url" : "iy103-w14.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "451847725256941569",
  "text" : "6 days until designing multi-device learning experiences course. http:\/\/t.co\/ZmG6YOGpMb How can I further improve the course companion?",
  "id" : 451847725256941569,
  "created_at" : "2014-04-03 22:24:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451513188425539585",
  "text" : "RT @lukew: Telling a software designer to \"design for people not for screens\/devices.\" is confusing the ends with the means.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.3627032925, -121.92000869 ]
    },
    "id_str" : "451400136262811648",
    "text" : "Telling a software designer to \"design for people not for screens\/devices.\" is confusing the ends with the means.",
    "id" : 451400136262811648,
    "created_at" : "2014-04-02 16:45:53 +0000",
    "user" : {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "protected" : false,
      "id_str" : "13889622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477610446917103616\/_cjU3_ga_normal.png",
      "id" : 13889622,
      "verified" : false
    }
  },
  "id" : 451513188425539585,
  "created_at" : "2014-04-03 00:15:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everett McKay",
      "screen_name" : "UXDesignEdge",
      "indices" : [ 0, 13 ],
      "id_str" : "205411420",
      "id" : 205411420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451447072865415169",
  "geo" : { },
  "id_str" : "451511950820667392",
  "in_reply_to_user_id" : 205411420,
  "text" : "@UXDesignEdge Happy to share my experiences on this matter anytime",
  "id" : 451511950820667392,
  "in_reply_to_status_id" : 451447072865415169,
  "created_at" : "2014-04-03 00:10:12 +0000",
  "in_reply_to_screen_name" : "UXDesignEdge",
  "in_reply_to_user_id_str" : "205411420",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cooper",
      "screen_name" : "cooper",
      "indices" : [ 3, 10 ],
      "id_str" : "17223242",
      "id" : 17223242
    }, {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 54, 61 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/QmBH7QW4Bf",
      "expanded_url" : "http:\/\/awe.sm\/bJALF",
      "display_url" : "awe.sm\/bJALF"
    } ]
  },
  "geo" : { },
  "id_str" : "451395732713394177",
  "text" : "RT @cooper: About Face 4 is available for preorder on @amazon. Sign up for your copy now: http:\/\/t.co\/QmBH7QW4Bf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/totally.awe.sm\" rel=\"nofollow\"\u003Eawe.sm\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amazon",
        "screen_name" : "amazon",
        "indices" : [ 42, 49 ],
        "id_str" : "20793816",
        "id" : 20793816
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/QmBH7QW4Bf",
        "expanded_url" : "http:\/\/awe.sm\/bJALF",
        "display_url" : "awe.sm\/bJALF"
      } ]
    },
    "geo" : { },
    "id_str" : "451394892707938304",
    "text" : "About Face 4 is available for preorder on @amazon. Sign up for your copy now: http:\/\/t.co\/QmBH7QW4Bf",
    "id" : 451394892707938304,
    "created_at" : "2014-04-02 16:25:03 +0000",
    "user" : {
      "name" : "Cooper",
      "screen_name" : "cooper",
      "protected" : false,
      "id_str" : "17223242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659130203671625728\/qicVhWwi_normal.jpg",
      "id" : 17223242,
      "verified" : false
    }
  },
  "id" : 451395732713394177,
  "created_at" : "2014-04-02 16:28:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/bZ1Pqw8bhy",
      "expanded_url" : "http:\/\/www.coerll.utexas.edu\/coerll\/sites\/coerll.utexas.edu.coerll\/files\/OER-handout.pdf?utm_source=Coerll%20e-newsletter_April%202014",
      "display_url" : "coerll.utexas.edu\/coerll\/sites\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451100909427126272",
  "text" : "RT @clintlalonde: Good handout on the basics of OER (pdf) from Centre for OER &amp; Language Learning at U of Texas http:\/\/t.co\/bZ1Pqw8bhy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/bZ1Pqw8bhy",
        "expanded_url" : "http:\/\/www.coerll.utexas.edu\/coerll\/sites\/coerll.utexas.edu.coerll\/files\/OER-handout.pdf?utm_source=Coerll%20e-newsletter_April%202014",
        "display_url" : "coerll.utexas.edu\/coerll\/sites\/c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "451092541199233027",
    "text" : "Good handout on the basics of OER (pdf) from Centre for OER &amp; Language Learning at U of Texas http:\/\/t.co\/bZ1Pqw8bhy",
    "id" : 451092541199233027,
    "created_at" : "2014-04-01 20:23:37 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 451100909427126272,
  "created_at" : "2014-04-01 20:56:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A List Apart",
      "screen_name" : "alistapart",
      "indices" : [ 3, 14 ],
      "id_str" : "18776131",
      "id" : 18776131
    }, {
      "name" : "Mat Marquis",
      "screen_name" : "wilto",
      "indices" : [ 86, 92 ],
      "id_str" : "12602932",
      "id" : 12602932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/iuK6uewsZt",
      "expanded_url" : "http:\/\/bit.ly\/1hWLRcP",
      "display_url" : "bit.ly\/1hWLRcP"
    } ]
  },
  "geo" : { },
  "id_str" : "451097673827758080",
  "text" : "RT @alistapart: Thanks to you, the `picture` element is coming to browsers this year. @wilto explains how: http:\/\/t.co\/iuK6uewsZt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mat Marquis",
        "screen_name" : "wilto",
        "indices" : [ 70, 76 ],
        "id_str" : "12602932",
        "id" : 12602932
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/iuK6uewsZt",
        "expanded_url" : "http:\/\/bit.ly\/1hWLRcP",
        "display_url" : "bit.ly\/1hWLRcP"
      } ]
    },
    "geo" : { },
    "id_str" : "450973393207046144",
    "text" : "Thanks to you, the `picture` element is coming to browsers this year. @wilto explains how: http:\/\/t.co\/iuK6uewsZt",
    "id" : 450973393207046144,
    "created_at" : "2014-04-01 12:30:10 +0000",
    "user" : {
      "name" : "A List Apart",
      "screen_name" : "alistapart",
      "protected" : false,
      "id_str" : "18776131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478913945475235840\/Jv1mMBOA_normal.jpeg",
      "id" : 18776131,
      "verified" : false
    }
  },
  "id" : 451097673827758080,
  "created_at" : "2014-04-01 20:44:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UBC Robson Square",
      "screen_name" : "UBCRobsonSquare",
      "indices" : [ 93, 109 ],
      "id_str" : "210914069",
      "id" : 210914069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/9rOPb2aPvs",
      "expanded_url" : "http:\/\/slid.es\/paulhibbitts\/iy103-w14-assess-slides",
      "display_url" : "slid.es\/paulhibbitts\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451046209516363779",
  "text" : "Draft slides for Assess topic in upcoming Designing Multi-device Learning Experiences course @UBCRobsonSquare http:\/\/t.co\/9rOPb2aPvs",
  "id" : 451046209516363779,
  "created_at" : "2014-04-01 17:19:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]