Grailbird.data.tweets_2013_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "levalee",
      "screen_name" : "levalee",
      "indices" : [ 0, 8 ],
      "id_str" : "17505659",
      "id" : 17505659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351105601323008002",
  "geo" : { },
  "id_str" : "351515490599964673",
  "in_reply_to_user_id" : 17505659,
  "text" : "@levalee Awesome! True \"time capsule\" candidates :-)",
  "id" : 351515490599964673,
  "in_reply_to_status_id" : 351105601323008002,
  "created_at" : "2013-07-01 01:39:58 +0000",
  "in_reply_to_screen_name" : "levalee",
  "in_reply_to_user_id_str" : "17505659",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Lewis",
      "screen_name" : "TommyLee",
      "indices" : [ 3, 12 ],
      "id_str" : "5541152",
      "id" : 5541152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bldwin",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/T66gT9tTfW",
      "expanded_url" : "http:\/\/bit.ly\/1aOu9Yk",
      "display_url" : "bit.ly\/1aOu9Yk"
    } ]
  },
  "geo" : { },
  "id_str" : "350719822704807936",
  "text" : "RT @TommyLee: New UX\/UI design guidance for Windows 8.1 now available -- http:\/\/t.co\/T66gT9tTfW #bldwin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bldwin",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/T66gT9tTfW",
        "expanded_url" : "http:\/\/bit.ly\/1aOu9Yk",
        "display_url" : "bit.ly\/1aOu9Yk"
      } ]
    },
    "geo" : { },
    "id_str" : "349991796715175936",
    "text" : "New UX\/UI design guidance for Windows 8.1 now available -- http:\/\/t.co\/T66gT9tTfW #bldwin",
    "id" : 349991796715175936,
    "created_at" : "2013-06-26 20:45:21 +0000",
    "user" : {
      "name" : "Tommy Lewis",
      "screen_name" : "TommyLee",
      "protected" : false,
      "id_str" : "5541152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/597878490101223425\/LKXgIVTB_normal.png",
      "id" : 5541152,
      "verified" : false
    }
  },
  "id" : 350719822704807936,
  "created_at" : "2013-06-28 20:58:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kevinmpowell",
      "screen_name" : "kevinmpowell",
      "indices" : [ 120, 133 ],
      "id_str" : "15357198",
      "id" : 15357198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350687306530820097",
  "text" : "It's pass\u00E9 for us to say mobile first, tablet first, etc. In our multi-device world it needs to be experience first. HT @kevinmpowell",
  "id" : 350687306530820097,
  "created_at" : "2013-06-28 18:49:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/yb8tsv8f6F",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/b97043aa-63e5-fa1b-3206-fc0699ea4b7d\/",
      "display_url" : "workflowy.com\/shared\/b97043a\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/25QCsKbmwd",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/d96485b6-2e24-9142-4446-906e0a6eeb82\/",
      "display_url" : "workflowy.com\/shared\/d96485b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350663758869307394",
  "text" : "Week 3 of my open course development\u2026 revised learning objectives https:\/\/t.co\/yb8tsv8f6F and linking to assessments https:\/\/t.co\/25QCsKbmwd",
  "id" : 350663758869307394,
  "created_at" : "2013-06-28 17:15:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forrester",
      "screen_name" : "forrester",
      "indices" : [ 3, 13 ],
      "id_str" : "7712452",
      "id" : 7712452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CX",
      "indices" : [ 15, 18 ]
    }, {
      "text" : "ForrForum",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350394803130871808",
  "text" : "RT @forrester: #CX pros face a sobering reality in the post-PC era; we now live in a multi-device world with demanding customer expectation\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CX",
        "indices" : [ 0, 3 ]
      }, {
        "text" : "ForrForum",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349584257435451394",
    "text" : "#CX pros face a sobering reality in the post-PC era; we now live in a multi-device world with demanding customer expectations #ForrForum",
    "id" : 349584257435451394,
    "created_at" : "2013-06-25 17:45:56 +0000",
    "user" : {
      "name" : "Forrester",
      "screen_name" : "forrester",
      "protected" : false,
      "id_str" : "7712452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557536783252996097\/2mkZ4an0_normal.png",
      "id" : 7712452,
      "verified" : true
    }
  },
  "id" : 350394803130871808,
  "created_at" : "2013-06-27 23:26:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techvibes",
      "screen_name" : "techvibes",
      "indices" : [ 3, 13 ],
      "id_str" : "15549032",
      "id" : 15549032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/GYkwnNm7TT",
      "expanded_url" : "http:\/\/ow.ly\/mq4s5",
      "display_url" : "ow.ly\/mq4s5"
    } ]
  },
  "geo" : { },
  "id_str" : "350380979757649921",
  "text" : "MT @techvibes UBC Student Communications is hiring a UX\/Usability Coordinator in Vancouver http:\/\/t.co\/GYkwnNm7TT &lt; This warms my heart",
  "id" : 350380979757649921,
  "created_at" : "2013-06-27 22:31:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/EmDMPGPCFd",
      "expanded_url" : "http:\/\/blogs.msdn.com\/b\/ie\/archive\/2013\/06\/26\/introducing-ie11-the-best-way-to-experience-the-web-on-modern-touch-devices.aspx",
      "display_url" : "blogs.msdn.com\/b\/ie\/archive\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350306265689374720",
  "text" : "RT @lukew: and what's new in Internet Explorer 11 too:\nhttp:\/\/t.co\/EmDMPGPCFd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/EmDMPGPCFd",
        "expanded_url" : "http:\/\/blogs.msdn.com\/b\/ie\/archive\/2013\/06\/26\/introducing-ie11-the-best-way-to-experience-the-web-on-modern-touch-devices.aspx",
        "display_url" : "blogs.msdn.com\/b\/ie\/archive\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "350304326998179840",
    "text" : "and what's new in Internet Explorer 11 too:\nhttp:\/\/t.co\/EmDMPGPCFd",
    "id" : 350304326998179840,
    "created_at" : "2013-06-27 17:27:14 +0000",
    "user" : {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "protected" : false,
      "id_str" : "13889622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477610446917103616\/_cjU3_ga_normal.png",
      "id" : 13889622,
      "verified" : false
    }
  },
  "id" : 350306265689374720,
  "created_at" : "2013-06-27 17:34:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Briscoe",
      "screen_name" : "seanbriscoe",
      "indices" : [ 3, 15 ],
      "id_str" : "163448770",
      "id" : 163448770
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bldwin",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/UbsiMcUuSy",
      "expanded_url" : "http:\/\/ASP.NET",
      "display_url" : "ASP.NET"
    } ]
  },
  "geo" : { },
  "id_str" : "350287528252809217",
  "text" : "RT @seanbriscoe: Twitter Bootstrap shipping with http:\/\/t.co\/UbsiMcUuSy fully supported just like jQuery. #bldwin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bldwin",
        "indices" : [ 89, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/UbsiMcUuSy",
        "expanded_url" : "http:\/\/ASP.NET",
        "display_url" : "ASP.NET"
      } ]
    },
    "geo" : { },
    "id_str" : "350287053193363457",
    "text" : "Twitter Bootstrap shipping with http:\/\/t.co\/UbsiMcUuSy fully supported just like jQuery. #bldwin",
    "id" : 350287053193363457,
    "created_at" : "2013-06-27 16:18:36 +0000",
    "user" : {
      "name" : "Sean Briscoe",
      "screen_name" : "seanbriscoe",
      "protected" : false,
      "id_str" : "163448770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1142993846\/3e1d6bac-c107-484e-bf3b-bd2ad591daaf_normal.png",
      "id" : 163448770,
      "verified" : false
    }
  },
  "id" : 350287528252809217,
  "created_at" : "2013-06-27 16:20:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bldwin",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350276030172372992",
  "text" : "The biggest surprise in Windows 8.1 Preview on my Surface? Online\/local smart search integrated with Bing - very nicely done! #bldwin",
  "id" : 350276030172372992,
  "created_at" : "2013-06-27 15:34:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Berg",
      "screen_name" : "mediakube",
      "indices" : [ 3, 13 ],
      "id_str" : "21651963",
      "id" : 21651963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/GDwheS1pxD",
      "expanded_url" : "http:\/\/bgr.com\/2013\/06\/17\/samsung-galaxy-devices-chart\/",
      "display_url" : "bgr.com\/2013\/06\/17\/sam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350041117854666752",
  "text" : "RT @mediakube: Samsung mobile devices UX: pick a size any size from this device chart http:\/\/t.co\/GDwheS1pxD  (26 different devices!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/GDwheS1pxD",
        "expanded_url" : "http:\/\/bgr.com\/2013\/06\/17\/samsung-galaxy-devices-chart\/",
        "display_url" : "bgr.com\/2013\/06\/17\/sam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "350040217580879872",
    "text" : "Samsung mobile devices UX: pick a size any size from this device chart http:\/\/t.co\/GDwheS1pxD  (26 different devices!)",
    "id" : 350040217580879872,
    "created_at" : "2013-06-26 23:57:45 +0000",
    "user" : {
      "name" : "Brian Berg",
      "screen_name" : "mediakube",
      "protected" : false,
      "id_str" : "21651963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1301038276\/MK_twitter_logo2_normal.jpg",
      "id" : 21651963,
      "verified" : false
    }
  },
  "id" : 350041117854666752,
  "created_at" : "2013-06-27 00:01:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Jursa",
      "screen_name" : "IATV",
      "indices" : [ 3, 8 ],
      "id_str" : "17151314",
      "id" : 17151314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/2UkIM3iysA",
      "expanded_url" : "http:\/\/bit.ly\/184lr91",
      "display_url" : "bit.ly\/184lr91"
    } ]
  },
  "geo" : { },
  "id_str" : "350029366027223041",
  "text" : "MT @IATV \"Why the Web Is Ready for Responsive Web Design\" http:\/\/t.co\/2UkIM3iysA &lt;- Yes, and RWD is the floor and not the ceiling.",
  "id" : 350029366027223041,
  "created_at" : "2013-06-26 23:14:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Build",
      "screen_name" : "bldwin",
      "indices" : [ 3, 10 ],
      "id_str" : "294210173",
      "id" : 294210173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bldwin",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/z0ZfUvIs4l",
      "expanded_url" : "http:\/\/channel9.msdn.com",
      "display_url" : "channel9.msdn.com"
    } ]
  },
  "geo" : { },
  "id_str" : "349910882031116289",
  "text" : "RT @bldwin: Good morning, the Build keynote will be streaming live at 9am PDT at http:\/\/t.co\/z0ZfUvIs4l #bldwin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bldwin",
        "indices" : [ 92, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/z0ZfUvIs4l",
        "expanded_url" : "http:\/\/channel9.msdn.com",
        "display_url" : "channel9.msdn.com"
      } ]
    },
    "geo" : { },
    "id_str" : "349908051995787267",
    "text" : "Good morning, the Build keynote will be streaming live at 9am PDT at http:\/\/t.co\/z0ZfUvIs4l #bldwin",
    "id" : 349908051995787267,
    "created_at" : "2013-06-26 15:12:35 +0000",
    "user" : {
      "name" : "Build",
      "screen_name" : "bldwin",
      "protected" : false,
      "id_str" : "294210173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672854315258634240\/pUT9gml6_normal.jpg",
      "id" : 294210173,
      "verified" : false
    }
  },
  "id" : 349910882031116289,
  "created_at" : "2013-06-26 15:23:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "indices" : [ 0, 10 ],
      "id_str" : "18983561",
      "id" : 18983561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349785238148362241",
  "geo" : { },
  "id_str" : "349898482196299776",
  "in_reply_to_user_id" : 18983561,
  "text" : "@basbrands Congrats Bas, all the best with your new endeavours!",
  "id" : 349898482196299776,
  "in_reply_to_status_id" : 349785238148362241,
  "created_at" : "2013-06-26 14:34:33 +0000",
  "in_reply_to_screen_name" : "basbrands",
  "in_reply_to_user_id_str" : "18983561",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/59VzMB45jf",
      "expanded_url" : "http:\/\/prn.to\/16uujRs",
      "display_url" : "prn.to\/16uujRs"
    } ]
  },
  "geo" : { },
  "id_str" : "349301598016651264",
  "text" : "MT @Mosaic_App The wait is over. http:\/\/t.co\/59VzMB45jf A new approach to school mobility is here. &lt;- Apps create barriers of use to me\u2026",
  "id" : 349301598016651264,
  "created_at" : "2013-06-24 23:02:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Nicola",
      "screen_name" : "lucisferre",
      "indices" : [ 3, 14 ],
      "id_str" : "1575733226",
      "id" : 1575733226
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HTML5",
      "indices" : [ 82, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349280306211192832",
  "text" : "RT @lucisferre: UBC is looking for someone to teach a for-credit course on modern #HTML5 frameworks. If you think you\u2019d be a good fit get i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HTML5",
        "indices" : [ 66, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349274978312654849",
    "text" : "UBC is looking for someone to teach a for-credit course on modern #HTML5 frameworks. If you think you\u2019d be a good fit get in touch with me.",
    "id" : 349274978312654849,
    "created_at" : "2013-06-24 21:16:58 +0000",
    "user" : {
      "name" : "Chris Nicola",
      "screen_name" : "chrismnicola",
      "protected" : false,
      "id_str" : "47128593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603995310772207616\/bpbS9lQu_normal.jpg",
      "id" : 47128593,
      "verified" : false
    }
  },
  "id" : 349280306211192832,
  "created_at" : "2013-06-24 21:38:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kimberly Voll",
      "screen_name" : "zanytomato",
      "indices" : [ 0, 11 ],
      "id_str" : "199980153",
      "id" : 199980153
    }, {
      "name" : "CDM",
      "screen_name" : "CentreDigiMedia",
      "indices" : [ 12, 28 ],
      "id_str" : "12231022",
      "id" : 12231022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349271387564814338",
  "geo" : { },
  "id_str" : "349273339979767808",
  "in_reply_to_user_id" : 199980153,
  "text" : "@zanytomato @CentreDigiMedia I'd love to, thanks! It would be a great opportunity to discuss multi-device design, esp. role w. education :-)",
  "id" : 349273339979767808,
  "in_reply_to_status_id" : 349271387564814338,
  "created_at" : "2013-06-24 21:10:28 +0000",
  "in_reply_to_screen_name" : "zanytomato",
  "in_reply_to_user_id_str" : "199980153",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kimberly Voll",
      "screen_name" : "zanytomato",
      "indices" : [ 0, 11 ],
      "id_str" : "199980153",
      "id" : 199980153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/DiYVqZijN0",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "349268029374341123",
  "geo" : { },
  "id_str" : "349268949910827009",
  "in_reply_to_user_id" : 199980153,
  "text" : "@zanytomato Awesome :-) If you are curious, I am publicly creating next term's course companion at http:\/\/t.co\/DiYVqZijN0 Feedback welcome!",
  "id" : 349268949910827009,
  "in_reply_to_status_id" : 349268029374341123,
  "created_at" : "2013-06-24 20:53:01 +0000",
  "in_reply_to_screen_name" : "zanytomato",
  "in_reply_to_user_id_str" : "199980153",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 51, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/yb8tsv8f6F",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/b97043aa-63e5-fa1b-3206-fc0699ea4b7d\/",
      "display_url" : "workflowy.com\/shared\/b97043a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349267645259984897",
  "text" : "Second draft high-level learning objectives for my #SFU Fall UI design course https:\/\/t.co\/yb8tsv8f6F Suggestions for improvements?",
  "id" : 349267645259984897,
  "created_at" : "2013-06-24 20:47:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edcampwest",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348917835050934272",
  "text" : "Wow, lots of great ideas and interesting discussions! Thanks to participants and organizers for a wonderful #edcampwest at SFU.",
  "id" : 348917835050934272,
  "created_at" : "2013-06-23 21:37:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Irvine",
      "screen_name" : "_valeriei",
      "indices" : [ 0, 10 ],
      "id_str" : "40426722",
      "id" : 40426722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348683233782808576",
  "geo" : { },
  "id_str" : "348813006999793664",
  "in_reply_to_user_id" : 40426722,
  "text" : "@_valeriei Thanks Valerie, I look forward to that!",
  "id" : 348813006999793664,
  "in_reply_to_status_id" : 348683233782808576,
  "created_at" : "2013-06-23 14:41:16 +0000",
  "in_reply_to_screen_name" : "_valeriei",
  "in_reply_to_user_id_str" : "40426722",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "edcampwest",
      "indices" : [ 5, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348626163771514880",
  "text" : "#SFU #edcampwest is tomorrow! Hoping to discuss &amp; share multi-device\/mobile learning UX, flipped classrooms, and in-the-open course design.",
  "id" : 348626163771514880,
  "created_at" : "2013-06-23 02:18:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brock & Bierk",
      "screen_name" : "BrockBierk",
      "indices" : [ 3, 14 ],
      "id_str" : "240074326",
      "id" : 240074326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348485724720472064",
  "text" : "RT @BrockBierk: Its a great day to be websites in this multi device world.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "348139506962137088",
    "text" : "Its a great day to be websites in this multi device world.",
    "id" : 348139506962137088,
    "created_at" : "2013-06-21 18:05:01 +0000",
    "user" : {
      "name" : "Brock & Bierk",
      "screen_name" : "BrockBierk",
      "protected" : false,
      "id_str" : "240074326",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000006610208\/57f0b2cf7de29f6da1987755220a471b_normal.png",
      "id" : 240074326,
      "verified" : false
    }
  },
  "id" : 348485724720472064,
  "created_at" : "2013-06-22 17:00:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "foundationzurb",
      "screen_name" : "foundationzurb",
      "indices" : [ 3, 18 ],
      "id_str" : "2394933703",
      "id" : 2394933703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/GVTHy6tofG",
      "expanded_url" : "http:\/\/zurb.us\/11lLeWh",
      "display_url" : "zurb.us\/11lLeWh"
    } ]
  },
  "geo" : { },
  "id_str" : "348209915879374848",
  "text" : "RT @foundationzurb: Toying with a possible new grid for Foundation 5 that builds off of existing patterns. What do you think? http:\/\/t.co\/G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/GVTHy6tofG",
        "expanded_url" : "http:\/\/zurb.us\/11lLeWh",
        "display_url" : "zurb.us\/11lLeWh"
      } ]
    },
    "geo" : { },
    "id_str" : "347044150732005376",
    "text" : "Toying with a possible new grid for Foundation 5 that builds off of existing patterns. What do you think? http:\/\/t.co\/GVTHy6tofG",
    "id" : 347044150732005376,
    "created_at" : "2013-06-18 17:32:27 +0000",
    "user" : {
      "name" : "ZURB Foundation",
      "screen_name" : "ZURBfoundation",
      "protected" : false,
      "id_str" : "360434586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740657740310142976\/2vkxYBSK_normal.jpg",
      "id" : 360434586,
      "verified" : false
    }
  },
  "id" : 348209915879374848,
  "created_at" : "2013-06-21 22:44:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Gammon",
      "screen_name" : "markgammon",
      "indices" : [ 0, 11 ],
      "id_str" : "11010622",
      "id" : 11010622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348179481141329920",
  "geo" : { },
  "id_str" : "348189949566259200",
  "in_reply_to_user_id" : 11010622,
  "text" : "@markgammon Thanks very much for your interest, it's been an interesting process so far.",
  "id" : 348189949566259200,
  "in_reply_to_status_id" : 348179481141329920,
  "created_at" : "2013-06-21 21:25:27 +0000",
  "in_reply_to_screen_name" : "markgammon",
  "in_reply_to_user_id_str" : "11010622",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ycFI1l0G4q",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/ca3b5284-9bc7-04ee-6596-a284eb3bff1e\/",
      "display_url" : "workflowy.com\/shared\/ca3b528\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "348161781513998336",
  "text" : "Week 2 of my open course building experiment\u2026 focus has been on developing the course map, w. learning objectives: https:\/\/t.co\/ycFI1l0G4q",
  "id" : 348161781513998336,
  "created_at" : "2013-06-21 19:33:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jann Kwasnicki",
      "screen_name" : "JKwasnicki",
      "indices" : [ 3, 14 ],
      "id_str" : "384908820",
      "id" : 384908820
    }, {
      "name" : "EdCamp West",
      "screen_name" : "EdCampWest",
      "indices" : [ 50, 61 ],
      "id_str" : "1099569590",
      "id" : 1099569590
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EdCampWest",
      "indices" : [ 134, 140 ]
    }, {
      "text" : "sd37",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348099382270377984",
  "text" : "RT @JKwasnicki: Time is running out! Register for @EdCampWest for Sun Jun 23 at teachdifferent.ca There is an online option, as well! #EdCa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EdCamp West",
        "screen_name" : "EdCampWest",
        "indices" : [ 34, 45 ],
        "id_str" : "1099569590",
        "id" : 1099569590
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EdCampWest",
        "indices" : [ 118, 129 ]
      }, {
        "text" : "sd37",
        "indices" : [ 130, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347917414945660928",
    "text" : "Time is running out! Register for @EdCampWest for Sun Jun 23 at teachdifferent.ca There is an online option, as well! #EdCampWest #sd37",
    "id" : 347917414945660928,
    "created_at" : "2013-06-21 03:22:30 +0000",
    "user" : {
      "name" : "Jann Kwasnicki",
      "screen_name" : "JKwasnicki",
      "protected" : false,
      "id_str" : "384908820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766105315179794433\/wawyftqe_normal.jpg",
      "id" : 384908820,
      "verified" : false
    }
  },
  "id" : 348099382270377984,
  "created_at" : "2013-06-21 15:25:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 0, 8 ],
      "id_str" : "10675",
      "id" : 10675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347896184494493697",
  "geo" : { },
  "id_str" : "347898675005116416",
  "in_reply_to_user_id" : 10675,
  "text" : "@gordonr Great seeing you tonight Gord!",
  "id" : 347898675005116416,
  "in_reply_to_status_id" : 347896184494493697,
  "created_at" : "2013-06-21 02:08:02 +0000",
  "in_reply_to_screen_name" : "gordonr",
  "in_reply_to_user_id_str" : "10675",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UXGuys",
      "screen_name" : "UXGUYS",
      "indices" : [ 0, 7 ],
      "id_str" : "23092914",
      "id" : 23092914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347850360565661696",
  "geo" : { },
  "id_str" : "347897634700271617",
  "in_reply_to_user_id" : 23092914,
  "text" : "@UXGUYS Great office warming party, thanks so much for the invite!",
  "id" : 347897634700271617,
  "in_reply_to_status_id" : 347850360565661696,
  "created_at" : "2013-06-21 02:03:54 +0000",
  "in_reply_to_screen_name" : "UXGUYS",
  "in_reply_to_user_id_str" : "23092914",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UXGuys",
      "screen_name" : "UXGUYS",
      "indices" : [ 3, 10 ],
      "id_str" : "23092914",
      "id" : 23092914
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/UXGUYS\/status\/347850360565661696\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/CddRL9yDnv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNPQD1jCAAE73Kt.jpg",
      "id_str" : "347850360569856001",
      "id" : 347850360569856001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNPQD1jCAAE73Kt.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/CddRL9yDnv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347851471213170691",
  "text" : "RT @UXGUYS: Just waiting for the world to come! UX Guys Vancouver office warming T minus 5 minutes. http:\/\/t.co\/CddRL9yDnv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/UXGUYS\/status\/347850360565661696\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/CddRL9yDnv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BNPQD1jCAAE73Kt.jpg",
        "id_str" : "347850360569856001",
        "id" : 347850360569856001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNPQD1jCAAE73Kt.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 1136
        } ],
        "display_url" : "pic.twitter.com\/CddRL9yDnv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347850360565661696",
    "text" : "Just waiting for the world to come! UX Guys Vancouver office warming T minus 5 minutes. http:\/\/t.co\/CddRL9yDnv",
    "id" : 347850360565661696,
    "created_at" : "2013-06-20 22:56:03 +0000",
    "user" : {
      "name" : "UXGuys",
      "screen_name" : "UXGUYS",
      "protected" : false,
      "id_str" : "23092914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/89260231\/Picture_2_normal.png",
      "id" : 23092914,
      "verified" : false
    }
  },
  "id" : 347851471213170691,
  "created_at" : "2013-06-20 23:00:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Currie",
      "screen_name" : "Currie",
      "indices" : [ 0, 7 ],
      "id_str" : "1282151",
      "id" : 1282151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347818418289930241",
  "geo" : { },
  "id_str" : "347820309308653568",
  "in_reply_to_user_id" : 1282151,
  "text" : "@Currie I was looking forward to seeing you too! I will soldier on and attend without you ;-) I am looking forward to seeing how it unfolds!",
  "id" : 347820309308653568,
  "in_reply_to_status_id" : 347818418289930241,
  "created_at" : "2013-06-20 20:56:38 +0000",
  "in_reply_to_screen_name" : "Currie",
  "in_reply_to_user_id_str" : "1282151",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edcampwest",
      "indices" : [ 40, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347815870669660160",
  "text" : "Looks like I will be able to make it to #edcampwest SFU this Sunday after all - hope my late registration makes it in!",
  "id" : 347815870669660160,
  "created_at" : "2013-06-20 20:39:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347770426585382913",
  "geo" : { },
  "id_str" : "347771826514042881",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Thanks Tannis, I'll share that with Steve too.",
  "id" : 347771826514042881,
  "in_reply_to_status_id" : 347770426585382913,
  "created_at" : "2013-06-20 17:43:59 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/347765761315577856\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Z8Jpcp9oFd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNODHgyCIAAwBb-.jpg",
      "id_str" : "347765761319772160",
      "id" : 347765761319772160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNODHgyCIAAwBb-.jpg",
      "sizes" : [ {
        "h" : 555,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 295,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Z8Jpcp9oFd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347765761315577856",
  "text" : "Just came across the business card for my first software company, circa 1993. Card and logo designed by Steve Priebe. http:\/\/t.co\/Z8Jpcp9oFd",
  "id" : 347765761315577856,
  "created_at" : "2013-06-20 17:19:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 67, 77 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/oHeaLIpM31",
      "expanded_url" : "http:\/\/shar.es\/xhIDl",
      "display_url" : "shar.es\/xhIDl"
    } ]
  },
  "geo" : { },
  "id_str" : "347499913220874240",
  "text" : "Tools for Mobile UX Design :: UXmatters http:\/\/t.co\/oHeaLIpM31 via @sharethis &lt;- I do more sketching and even more html prototyping myself",
  "id" : 347499913220874240,
  "created_at" : "2013-06-19 23:43:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347483695105576960",
  "text" : "UI vs. IxD design? Interaction design is the structure, behaviours, and user interactions of products, services, and systems. Thoughts?",
  "id" : 347483695105576960,
  "created_at" : "2013-06-19 22:39:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347483499164479488",
  "text" : "UI vs. IxD design? Oh boy, here we go! User interface design is the means of communication between the user and a system, while\u2026",
  "id" : 347483499164479488,
  "created_at" : "2013-06-19 22:38:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Nancy White",
      "screen_name" : "NancyWhite",
      "indices" : [ 55, 66 ],
      "id_str" : "25793",
      "id" : 25793
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 67, 82 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "Helen Lee",
      "screen_name" : "heli_tomato",
      "indices" : [ 83, 95 ],
      "id_str" : "26872162",
      "id" : 26872162
    }, {
      "name" : "Mary Burgess",
      "screen_name" : "maryeburgess",
      "indices" : [ 96, 109 ],
      "id_str" : "24827526",
      "id" : 24827526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/XINhLViLuW",
      "expanded_url" : "http:\/\/bit.ly\/11w8jST",
      "display_url" : "bit.ly\/11w8jST"
    } ]
  },
  "geo" : { },
  "id_str" : "347064800305627136",
  "text" : "RT @etug: Just in! Resources from our Spring workshop: @NancyWhite @hibbittsdesign @heli_tomato @maryeburgess and more! http:\/\/t.co\/XINhLVi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nancy White",
        "screen_name" : "NancyWhite",
        "indices" : [ 45, 56 ],
        "id_str" : "25793",
        "id" : 25793
      }, {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 57, 72 ],
        "id_str" : "15949844",
        "id" : 15949844
      }, {
        "name" : "Helen Lee",
        "screen_name" : "heli_tomato",
        "indices" : [ 73, 85 ],
        "id_str" : "26872162",
        "id" : 26872162
      }, {
        "name" : "Mary Burgess",
        "screen_name" : "maryeburgess",
        "indices" : [ 86, 99 ],
        "id_str" : "24827526",
        "id" : 24827526
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/XINhLViLuW",
        "expanded_url" : "http:\/\/bit.ly\/11w8jST",
        "display_url" : "bit.ly\/11w8jST"
      } ]
    },
    "geo" : { },
    "id_str" : "347062461976961024",
    "text" : "Just in! Resources from our Spring workshop: @NancyWhite @hibbittsdesign @heli_tomato @maryeburgess and more! http:\/\/t.co\/XINhLViLuW",
    "id" : 347062461976961024,
    "created_at" : "2013-06-18 18:45:13 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 347064800305627136,
  "created_at" : "2013-06-18 18:54:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 44, 48 ]
    }, {
      "text" : "Edu",
      "indices" : [ 95, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/yb8tsv8f6F",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/b97043aa-63e5-fa1b-3206-fc0699ea4b7d\/",
      "display_url" : "workflowy.com\/shared\/b97043a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "347022421804589056",
  "text" : "Draft high-level learning objectives for my #SFU Fall UI design course https:\/\/t.co\/yb8tsv8f6F #Edu colleagues - how might I improve these?",
  "id" : 347022421804589056,
  "created_at" : "2013-06-18 16:06:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Lee",
      "screen_name" : "heli_tomato",
      "indices" : [ 0, 12 ],
      "id_str" : "26872162",
      "id" : 26872162
    }, {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 122, 135 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345674348956381184",
  "geo" : { },
  "id_str" : "345686977313656832",
  "in_reply_to_user_id" : 26872162,
  "text" : "@heli_tomato Thanks very much for the kind mention in your #etug recap Storify! Wish I could have attended your talk with @clintlalonde too.",
  "id" : 345686977313656832,
  "in_reply_to_status_id" : 345674348956381184,
  "created_at" : "2013-06-14 23:39:32 +0000",
  "in_reply_to_screen_name" : "heli_tomato",
  "in_reply_to_user_id_str" : "26872162",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 0, 5 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345638460192870402",
  "in_reply_to_user_id" : 17102936,
  "text" : "@etug Thanks for the RT. It's really an interesting experience so far - helps raise the bar and supports earlier feedback (when available)!",
  "id" : 345638460192870402,
  "created_at" : "2013-06-14 20:26:45 +0000",
  "in_reply_to_screen_name" : "etug",
  "in_reply_to_user_id_str" : "17102936",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 0, 8 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345580921002553345",
  "geo" : { },
  "id_str" : "345589316484993024",
  "in_reply_to_user_id" : 1550251,
  "text" : "@dmitryn Perhaps #2 - let's see how that plays out. On other fronts, new MacBook Air continues to value battery life as key part of UX :-)",
  "id" : 345589316484993024,
  "in_reply_to_status_id" : 345580921002553345,
  "created_at" : "2013-06-14 17:11:28 +0000",
  "in_reply_to_screen_name" : "dmitryn",
  "in_reply_to_user_id_str" : "1550251",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmitry Nekrasovski",
      "screen_name" : "dmitryn",
      "indices" : [ 0, 8 ],
      "id_str" : "1550251",
      "id" : 1550251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345580338644398082",
  "geo" : { },
  "id_str" : "345588758017626112",
  "in_reply_to_user_id" : 1550251,
  "text" : "@dmitryn Agreed #1, but still disappointing.",
  "id" : 345588758017626112,
  "in_reply_to_status_id" : 345580338644398082,
  "created_at" : "2013-06-14 17:09:15 +0000",
  "in_reply_to_screen_name" : "dmitryn",
  "in_reply_to_user_id_str" : "1550251",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/DiYVqZijN0",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ycFI1l0G4q",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/ca3b5284-9bc7-04ee-6596-a284eb3bff1e\/",
      "display_url" : "workflowy.com\/shared\/ca3b528\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345587863750053888",
  "text" : "Week 1 of my open course building experiment\u2026 multi-device f2f course companion: http:\/\/t.co\/DiYVqZijN0 course map: https:\/\/t.co\/ycFI1l0G4q",
  "id" : 345587863750053888,
  "created_at" : "2013-06-14 17:05:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345571792167006208",
  "text" : "I've spent some time now with the iOS 7 beta, and my one word summary is \"reactive\". This is not a word I usually associate with Apple.",
  "id" : 345571792167006208,
  "created_at" : "2013-06-14 16:01:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "indices" : [ 3, 11 ],
      "id_str" : "15022225",
      "id" : 15022225
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 111, 114 ]
    }, {
      "text" : "measuringusability",
      "indices" : [ 115, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/KYeFGN1HAv",
      "expanded_url" : "http:\/\/bit.ly\/AAAdistractions",
      "display_url" : "bit.ly\/AAAdistractions"
    } ]
  },
  "geo" : { },
  "id_str" : "345230682827661312",
  "text" : "RT @NNgroup: This report may save your life: Cognitive distractions while driving (AAA) http:\/\/t.co\/KYeFGN1HAv #UX #measuringusability",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 98, 101 ]
      }, {
        "text" : "measuringusability",
        "indices" : [ 102, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/KYeFGN1HAv",
        "expanded_url" : "http:\/\/bit.ly\/AAAdistractions",
        "display_url" : "bit.ly\/AAAdistractions"
      } ]
    },
    "geo" : { },
    "id_str" : "345226769596555265",
    "text" : "This report may save your life: Cognitive distractions while driving (AAA) http:\/\/t.co\/KYeFGN1HAv #UX #measuringusability",
    "id" : 345226769596555265,
    "created_at" : "2013-06-13 17:10:50 +0000",
    "user" : {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "protected" : false,
      "id_str" : "15022225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467725885949227008\/JTT0mnp4_normal.png",
      "id" : 15022225,
      "verified" : false
    }
  },
  "id" : 345230682827661312,
  "created_at" : "2013-06-13 17:26:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344956538252836864",
  "text" : "If you are promoting mobile UX design services, and your own website is not mobile friendly in the least, then I am not sure what to think.",
  "id" : 344956538252836864,
  "created_at" : "2013-06-12 23:17:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344950216715284481",
  "text" : "Stop using hovers - they were (most often) a weak interaction technique to begin with and now with touch devices quite often useless.",
  "id" : 344950216715284481,
  "created_at" : "2013-06-12 22:51:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess McMullin",
      "screen_name" : "jessmcmullin",
      "indices" : [ 0, 13 ],
      "id_str" : "381203",
      "id" : 381203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344929008066113537",
  "geo" : { },
  "id_str" : "344930403443933184",
  "in_reply_to_user_id" : 381203,
  "text" : "@jessmcmullin Ah, indeed beta is still not in full swing. Additional non-US options could be Nomadesk or Wuala.",
  "id" : 344930403443933184,
  "in_reply_to_status_id" : 344929008066113537,
  "created_at" : "2013-06-12 21:33:11 +0000",
  "in_reply_to_screen_name" : "jessmcmullin",
  "in_reply_to_user_id_str" : "381203",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess McMullin",
      "screen_name" : "jessmcmullin",
      "indices" : [ 0, 13 ],
      "id_str" : "381203",
      "id" : 381203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/2Y8PRIfMQh",
      "expanded_url" : "http:\/\/sync.com",
      "display_url" : "sync.com"
    } ]
  },
  "in_reply_to_status_id_str" : "344924596480380928",
  "geo" : { },
  "id_str" : "344925516488400896",
  "in_reply_to_user_id" : 381203,
  "text" : "@jessmcmullin Check out http:\/\/t.co\/2Y8PRIfMQh",
  "id" : 344925516488400896,
  "in_reply_to_status_id" : 344924596480380928,
  "created_at" : "2013-06-12 21:13:46 +0000",
  "in_reply_to_screen_name" : "jessmcmullin",
  "in_reply_to_user_id_str" : "381203",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/VevBIREaHq",
      "expanded_url" : "http:\/\/lnkd.in\/jpHZPa",
      "display_url" : "lnkd.in\/jpHZPa"
    } ]
  },
  "geo" : { },
  "id_str" : "344845546042830848",
  "text" : "Digital Marketing Manager - Vancouver, Downtown - Lambda Solutions http:\/\/t.co\/VevBIREaHq",
  "id" : 344845546042830848,
  "created_at" : "2013-06-12 15:55:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/QrRmzXScU5",
      "expanded_url" : "http:\/\/sdrv.ms\/11dZ1L9",
      "display_url" : "sdrv.ms\/11dZ1L9"
    } ]
  },
  "geo" : { },
  "id_str" : "344571785339080705",
  "text" : "Looking for a proto-persona, user story, or task inventory template? Here's my #SFU Fall UI course templates (so far) http:\/\/t.co\/QrRmzXScU5",
  "id" : 344571785339080705,
  "created_at" : "2013-06-11 21:48:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    }, {
      "name" : "Nancy White",
      "screen_name" : "NancyWhite",
      "indices" : [ 12, 23 ],
      "id_str" : "25793",
      "id" : 25793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344558350316486657",
  "geo" : { },
  "id_str" : "344565233014173696",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco @NancyWhite Thanks for the share!",
  "id" : 344565233014173696,
  "in_reply_to_status_id" : 344558350316486657,
  "created_at" : "2013-06-11 21:22:07 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Burgess",
      "screen_name" : "maryeburgess",
      "indices" : [ 0, 13 ],
      "id_str" : "24827526",
      "id" : 24827526
    }, {
      "name" : "levalee",
      "screen_name" : "levalee",
      "indices" : [ 14, 22 ],
      "id_str" : "17505659",
      "id" : 17505659
    }, {
      "name" : "tinforest",
      "screen_name" : "tinforest",
      "indices" : [ 23, 33 ],
      "id_str" : "7337252",
      "id" : 7337252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344530312979681280",
  "geo" : { },
  "id_str" : "344565143935524866",
  "in_reply_to_user_id" : 24827526,
  "text" : "@maryeburgess @levalee @tinforest What a great photo!",
  "id" : 344565143935524866,
  "in_reply_to_status_id" : 344530312979681280,
  "created_at" : "2013-06-11 21:21:46 +0000",
  "in_reply_to_screen_name" : "maryeburgess",
  "in_reply_to_user_id_str" : "24827526",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344561434488872960",
  "text" : "I really want to love you new Flickr, but my heavens are you ever slow now.",
  "id" : 344561434488872960,
  "created_at" : "2013-06-11 21:07:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rudolph",
      "screen_name" : "BenThePCGuy",
      "indices" : [ 3, 15 ],
      "id_str" : "91396874",
      "id" : 91396874
    }, {
      "name" : "Lumia",
      "screen_name" : "windowsphone",
      "indices" : [ 66, 79 ],
      "id_str" : "2731428493",
      "id" : 2731428493
    }, {
      "name" : "WPCentral",
      "screen_name" : "wpcentral",
      "indices" : [ 85, 95 ],
      "id_str" : "2855624911",
      "id" : 2855624911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ios7",
      "indices" : [ 56, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/b9m2SDthDa",
      "expanded_url" : "http:\/\/www.wpcentral.com\/latest-windows-phone-incarnation-ios-7",
      "display_url" : "wpcentral.com\/latest-windows\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344251354891550720",
  "text" : "RT @BenThePCGuy: Loving this side-by-side comparison of #ios7 and @windowsphone from @wpcentral :  http:\/\/t.co\/b9m2SDthDa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lumia",
        "screen_name" : "windowsphone",
        "indices" : [ 49, 62 ],
        "id_str" : "2731428493",
        "id" : 2731428493
      }, {
        "name" : "WPCentral",
        "screen_name" : "wpcentral",
        "indices" : [ 68, 78 ],
        "id_str" : "2855624911",
        "id" : 2855624911
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ios7",
        "indices" : [ 39, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/b9m2SDthDa",
        "expanded_url" : "http:\/\/www.wpcentral.com\/latest-windows-phone-incarnation-ios-7",
        "display_url" : "wpcentral.com\/latest-windows\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "344213654826262528",
    "text" : "Loving this side-by-side comparison of #ios7 and @windowsphone from @wpcentral :  http:\/\/t.co\/b9m2SDthDa",
    "id" : 344213654826262528,
    "created_at" : "2013-06-10 22:05:05 +0000",
    "user" : {
      "name" : "Ben Rudolph",
      "screen_name" : "BenThePCGuy",
      "protected" : false,
      "id_str" : "91396874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754352166748336128\/sapM0ZmZ_normal.jpg",
      "id" : 91396874,
      "verified" : false
    }
  },
  "id" : 344251354891550720,
  "created_at" : "2013-06-11 00:34:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mat Marquis",
      "screen_name" : "wilto",
      "indices" : [ 109, 115 ],
      "id_str" : "12602932",
      "id" : 12602932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344233503581421569",
  "text" : "WOW! It is 2013 and Apple's freshly updated homepage is still mobile-hostile and weighs in at about 10MB. HT @wilto",
  "id" : 344233503581421569,
  "created_at" : "2013-06-10 23:23:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 55, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/oAW3apsRk3",
      "expanded_url" : "http:\/\/hibbittsdesign.com\/courses\/cmpt-363-133-prototype\/ux-techniques\/",
      "display_url" : "hibbittsdesign.com\/courses\/cmpt-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344191471160799232",
  "text" : "The mobile-friendly companion for my Fall UI course at #SFU will be public. UX Techniques Guide first draft http:\/\/t.co\/oAW3apsRk3 Thoughts?",
  "id" : 344191471160799232,
  "created_at" : "2013-06-10 20:36:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Windows Phone Design",
      "screen_name" : "WPdesignteam",
      "indices" : [ 3, 16 ],
      "id_str" : "125735031",
      "id" : 125735031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344169144624746497",
  "text" : "RT @WPdesignteam: Metro is a set of design principles. Not just a visual language.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344169051649622016",
    "text" : "Metro is a set of design principles. Not just a visual language.",
    "id" : 344169051649622016,
    "created_at" : "2013-06-10 19:07:50 +0000",
    "user" : {
      "name" : "Microsoft Design",
      "screen_name" : "MicrosoftDesign",
      "protected" : false,
      "id_str" : "209202416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641678298137915392\/pkgzJDbc_normal.jpg",
      "id" : 209202416,
      "verified" : true
    }
  },
  "id" : 344169144624746497,
  "created_at" : "2013-06-10 19:08:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RC Concepcion",
      "screen_name" : "aboutrc",
      "indices" : [ 3, 11 ],
      "id_str" : "15394133",
      "id" : 15394133
    }, {
      "name" : "Microsoft",
      "screen_name" : "Microsoft",
      "indices" : [ 69, 79 ],
      "id_str" : "74286565",
      "id" : 74286565
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ios7",
      "indices" : [ 42, 47 ]
    }, {
      "text" : "Windows8",
      "indices" : [ 80, 89 ]
    }, {
      "text" : "WWDC",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344159065372495872",
  "text" : "RT @aboutrc: Congratulations Apple - with #ios7 you just invented... @Microsoft #Windows8 - you should be pretty proud of that.  :)  #WWDC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Microsoft",
        "screen_name" : "Microsoft",
        "indices" : [ 56, 66 ],
        "id_str" : "74286565",
        "id" : 74286565
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ios7",
        "indices" : [ 29, 34 ]
      }, {
        "text" : "Windows8",
        "indices" : [ 67, 76 ]
      }, {
        "text" : "WWDC",
        "indices" : [ 120, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344158287740145664",
    "text" : "Congratulations Apple - with #ios7 you just invented... @Microsoft #Windows8 - you should be pretty proud of that.  :)  #WWDC",
    "id" : 344158287740145664,
    "created_at" : "2013-06-10 18:25:04 +0000",
    "user" : {
      "name" : "RC Concepcion",
      "screen_name" : "aboutrc",
      "protected" : false,
      "id_str" : "15394133",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618631185841827840\/mqpVyh0u_normal.jpg",
      "id" : 15394133,
      "verified" : false
    }
  },
  "id" : 344159065372495872,
  "created_at" : "2013-06-10 18:28:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344152777607479297",
  "text" : "RT @lukew: Apple launches death star.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344152034292924416",
    "text" : "Apple launches death star.",
    "id" : 344152034292924416,
    "created_at" : "2013-06-10 18:00:13 +0000",
    "user" : {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "protected" : false,
      "id_str" : "13889622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477610446917103616\/_cjU3_ga_normal.png",
      "id" : 13889622,
      "verified" : false
    }
  },
  "id" : 344152777607479297,
  "created_at" : "2013-06-10 18:03:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wwdc",
      "indices" : [ 31, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344143166133399552",
  "text" : "Sucks to be TotalFinder today. #wwdc",
  "id" : 344143166133399552,
  "created_at" : "2013-06-10 17:24:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunil Gunderia",
      "screen_name" : "DigitalMasala",
      "indices" : [ 3, 17 ],
      "id_str" : "70770699",
      "id" : 70770699
    }, {
      "name" : "PewResearch Internet",
      "screen_name" : "pewinternet",
      "indices" : [ 118, 130 ],
      "id_str" : "17071048",
      "id" : 17071048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344135242505916417",
  "text" : "RT @DigitalMasala: Tablet ownership up 2x in a yr to 1\/3 of US Adults. Jumps to 50% for families with minor children. @pewinternet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PewResearch Internet",
        "screen_name" : "pewinternet",
        "indices" : [ 99, 111 ],
        "id_str" : "17071048",
        "id" : 17071048
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344118669099532288",
    "text" : "Tablet ownership up 2x in a yr to 1\/3 of US Adults. Jumps to 50% for families with minor children. @pewinternet",
    "id" : 344118669099532288,
    "created_at" : "2013-06-10 15:47:38 +0000",
    "user" : {
      "name" : "Sunil Gunderia",
      "screen_name" : "DigitalMasala",
      "protected" : false,
      "id_str" : "70770699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2761664482\/14b377a9fc4cc42cbaf742ec9f10c0d7_normal.jpeg",
      "id" : 70770699,
      "verified" : false
    }
  },
  "id" : 344135242505916417,
  "created_at" : "2013-06-10 16:53:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Martin",
      "screen_name" : "Jamesco",
      "indices" : [ 3, 11 ],
      "id_str" : "885611",
      "id" : 885611
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Jamesco\/status\/344102570849087488\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/IqN3DCoa5b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMZ_dw6CEAIMQbW.jpg",
      "id_str" : "344102570861662210",
      "id" : 344102570861662210,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMZ_dw6CEAIMQbW.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1944,
        "resize" : "fit",
        "w" : 1944
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IqN3DCoa5b"
    } ],
    "hashtags" : [ {
      "text" : "WWDC",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344123940223983616",
  "text" : "RT @Jamesco: Woz shows up at #WWDC on a Segway! http:\/\/t.co\/IqN3DCoa5b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Jamesco\/status\/344102570849087488\/photo\/1",
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/IqN3DCoa5b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BMZ_dw6CEAIMQbW.jpg",
        "id_str" : "344102570861662210",
        "id" : 344102570861662210,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMZ_dw6CEAIMQbW.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1944,
          "resize" : "fit",
          "w" : 1944
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/IqN3DCoa5b"
      } ],
      "hashtags" : [ {
        "text" : "WWDC",
        "indices" : [ 16, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344102570849087488",
    "text" : "Woz shows up at #WWDC on a Segway! http:\/\/t.co\/IqN3DCoa5b",
    "id" : 344102570849087488,
    "created_at" : "2013-06-10 14:43:40 +0000",
    "user" : {
      "name" : "James Martin",
      "screen_name" : "Jamesco",
      "protected" : false,
      "id_str" : "885611",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690433055304056833\/TjrqcxI7_normal.jpg",
      "id" : 885611,
      "verified" : true
    }
  },
  "id" : 344123940223983616,
  "created_at" : "2013-06-10 16:08:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 3, 13 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/6hwCV2bhyg",
      "expanded_url" : "http:\/\/blog.slid.es\/",
      "display_url" : "blog.slid.es"
    } ]
  },
  "geo" : { },
  "id_str" : "343755909413081089",
  "text" : "RT @SlidesApp: We've added Dropbox sync, a free positioning mode and much more. http:\/\/t.co\/6hwCV2bhyg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/6hwCV2bhyg",
        "expanded_url" : "http:\/\/blog.slid.es\/",
        "display_url" : "blog.slid.es"
      } ]
    },
    "geo" : { },
    "id_str" : "343725043966169088",
    "text" : "We've added Dropbox sync, a free positioning mode and much more. http:\/\/t.co\/6hwCV2bhyg",
    "id" : 343725043966169088,
    "created_at" : "2013-06-09 13:43:31 +0000",
    "user" : {
      "name" : "Slides",
      "screen_name" : "slides",
      "protected" : false,
      "id_str" : "813740730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3613735314\/62f2063707eac3b24196d69b1b5cd5b5_normal.png",
      "id" : 813740730,
      "verified" : false
    }
  },
  "id" : 343755909413081089,
  "created_at" : "2013-06-09 15:46:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Jursa",
      "screen_name" : "IATV",
      "indices" : [ 3, 8 ],
      "id_str" : "17151314",
      "id" : 17151314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/xuwORJKiOk",
      "expanded_url" : "http:\/\/bit.ly\/12aBSxM",
      "display_url" : "bit.ly\/12aBSxM"
    }, {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/UEqnfQuPUi",
      "expanded_url" : "http:\/\/smallsurfaces.com",
      "display_url" : "smallsurfaces.com"
    } ]
  },
  "geo" : { },
  "id_str" : "343495755333500928",
  "text" : "RT @IATV: \"Thumbs-only UI? How people hold phones\" http:\/\/t.co\/xuwORJKiOk (http:\/\/t.co\/UEqnfQuPUi)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/xuwORJKiOk",
        "expanded_url" : "http:\/\/bit.ly\/12aBSxM",
        "display_url" : "bit.ly\/12aBSxM"
      }, {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/UEqnfQuPUi",
        "expanded_url" : "http:\/\/smallsurfaces.com",
        "display_url" : "smallsurfaces.com"
      } ]
    },
    "geo" : { },
    "id_str" : "343495309231525889",
    "text" : "\"Thumbs-only UI? How people hold phones\" http:\/\/t.co\/xuwORJKiOk (http:\/\/t.co\/UEqnfQuPUi)",
    "id" : 343495309231525889,
    "created_at" : "2013-06-08 22:30:38 +0000",
    "user" : {
      "name" : "Jan Jursa",
      "screen_name" : "IATV",
      "protected" : false,
      "id_str" : "17151314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466681693235982336\/4v-lZ2o2_normal.jpeg",
      "id" : 17151314,
      "verified" : false
    }
  },
  "id" : 343495755333500928,
  "created_at" : "2013-06-08 22:32:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 0, 9 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343493764716826624",
  "in_reply_to_user_id" : 93710949,
  "text" : "@BCcampus Thanks very much for the #etug mentions!",
  "id" : 343493764716826624,
  "created_at" : "2013-06-08 22:24:29 +0000",
  "in_reply_to_screen_name" : "BCcampus",
  "in_reply_to_user_id_str" : "93710949",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CGroom",
      "screen_name" : "motherbear03",
      "indices" : [ 0, 13 ],
      "id_str" : "415224493",
      "id" : 415224493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343050387806380032",
  "geo" : { },
  "id_str" : "343493094584483844",
  "in_reply_to_user_id" : 415224493,
  "text" : "@motherbear03 Thanks for the #etug mentions!",
  "id" : 343493094584483844,
  "in_reply_to_status_id" : 343050387806380032,
  "created_at" : "2013-06-08 22:21:50 +0000",
  "in_reply_to_screen_name" : "motherbear03",
  "in_reply_to_user_id_str" : "415224493",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everett McKay",
      "screen_name" : "UXDesignEdge",
      "indices" : [ 0, 13 ],
      "id_str" : "205411420",
      "id" : 205411420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343160385853075458",
  "geo" : { },
  "id_str" : "343161489533845504",
  "in_reply_to_user_id" : 205411420,
  "text" : "@UXDesignEdge My current mobile phone choice as well... let's see what next week brings iPhone-wise!",
  "id" : 343161489533845504,
  "in_reply_to_status_id" : 343160385853075458,
  "created_at" : "2013-06-08 00:24:09 +0000",
  "in_reply_to_screen_name" : "UXDesignEdge",
  "in_reply_to_user_id_str" : "205411420",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "indices" : [ 3, 17 ],
      "id_str" : "1236101",
      "id" : 1236101
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BenedictEvans\/status\/343082942848962561\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/iQwQgu3VkE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMLgHmmCEAEHeJb.png",
      "id_str" : "343082942857351169",
      "id" : 343082942857351169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMLgHmmCEAEHeJb.png",
      "sizes" : [ {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 362
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 362
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 362
      } ],
      "display_url" : "pic.twitter.com\/iQwQgu3VkE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343158780705505280",
  "text" : "RT @BenedictEvans: Looks like Android 4.x devices passed iOS in the last month (both c.400m). Some other interesting dynamics, too http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BenedictEvans\/status\/343082942848962561\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/iQwQgu3VkE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BMLgHmmCEAEHeJb.png",
        "id_str" : "343082942857351169",
        "id" : 343082942857351169,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMLgHmmCEAEHeJb.png",
        "sizes" : [ {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 362
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 362
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 362
        } ],
        "display_url" : "pic.twitter.com\/iQwQgu3VkE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343082942848962561",
    "text" : "Looks like Android 4.x devices passed iOS in the last month (both c.400m). Some other interesting dynamics, too http:\/\/t.co\/iQwQgu3VkE",
    "id" : 343082942848962561,
    "created_at" : "2013-06-07 19:12:02 +0000",
    "user" : {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "protected" : false,
      "id_str" : "1236101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544407411193163776\/vGSguvLd_normal.jpeg",
      "id" : 1236101,
      "verified" : false
    }
  },
  "id" : 343158780705505280,
  "created_at" : "2013-06-08 00:13:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343158658533818370",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Nice to reconnect (though briefly) at #etug!",
  "id" : 343158658533818370,
  "created_at" : "2013-06-08 00:12:54 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 3, 10 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 139, 140 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 12, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343154602574753792",
  "text" : "RT @brlamb: #etug is such a wonderful professional community, I offer deep thanks to all involved: organizers, volunteers, participants and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BCcampus",
        "screen_name" : "BCcampus",
        "indices" : [ 128, 137 ],
        "id_str" : "93710949",
        "id" : 93710949
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343125631351025664",
    "text" : "#etug is such a wonderful professional community, I offer deep thanks to all involved: organizers, volunteers, participants and @BCcampus.",
    "id" : 343125631351025664,
    "created_at" : "2013-06-07 22:01:40 +0000",
    "user" : {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "protected" : false,
      "id_str" : "745903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671910130498203649\/btEUG3ES_normal.jpg",
      "id" : 745903,
      "verified" : false
    }
  },
  "id" : 343154602574753792,
  "created_at" : "2013-06-07 23:56:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 34, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343153529680195585",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Great to see you again at #etug!",
  "id" : 343153529680195585,
  "created_at" : "2013-06-07 23:52:31 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 0, 12 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343142790785531904",
  "geo" : { },
  "id_str" : "343143849075548160",
  "in_reply_to_user_id" : 66913866,
  "text" : "@openroadies Awesome work, congrats!",
  "id" : 343143849075548160,
  "in_reply_to_status_id" : 343142790785531904,
  "created_at" : "2013-06-07 23:14:03 +0000",
  "in_reply_to_screen_name" : "openroadies",
  "in_reply_to_user_id_str" : "66913866",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Hunter",
      "screen_name" : "kp_h",
      "indices" : [ 0, 5 ],
      "id_str" : "104868624",
      "id" : 104868624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343107469385531392",
  "geo" : { },
  "id_str" : "343107971997396992",
  "in_reply_to_user_id" : 104868624,
  "text" : "@kp_h Thanks Kyle, great to reconnect with you!",
  "id" : 343107971997396992,
  "in_reply_to_status_id" : 343107469385531392,
  "created_at" : "2013-06-07 20:51:29 +0000",
  "in_reply_to_screen_name" : "kp_h",
  "in_reply_to_user_id_str" : "104868624",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dilyaram",
      "screen_name" : "Dilyaram",
      "indices" : [ 0, 9 ],
      "id_str" : "374046821",
      "id" : 374046821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343044368090935296",
  "geo" : { },
  "id_str" : "343107518945443840",
  "in_reply_to_user_id" : 71335023,
  "text" : "@dilyaram Thanks for the mentions Diliara - nice to meet you today too!",
  "id" : 343107518945443840,
  "in_reply_to_status_id" : 343044368090935296,
  "created_at" : "2013-06-07 20:49:41 +0000",
  "in_reply_to_screen_name" : "DiliaraN",
  "in_reply_to_user_id_str" : "71335023",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 0, 11 ],
      "id_str" : "28429477",
      "id" : 28429477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343051741404733440",
  "geo" : { },
  "id_str" : "343107032439726081",
  "in_reply_to_user_id" : 28429477,
  "text" : "@chadleaman Thanks for all the mentions Chad!",
  "id" : 343107032439726081,
  "in_reply_to_status_id" : 343051741404733440,
  "created_at" : "2013-06-07 20:47:45 +0000",
  "in_reply_to_screen_name" : "chadleaman",
  "in_reply_to_user_id_str" : "28429477",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tinforest",
      "screen_name" : "tinforest",
      "indices" : [ 0, 10 ],
      "id_str" : "7337252",
      "id" : 7337252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343050712307101696",
  "geo" : { },
  "id_str" : "343106861450530816",
  "in_reply_to_user_id" : 7337252,
  "text" : "@tinforest Thanks for the mentions!",
  "id" : 343106861450530816,
  "in_reply_to_status_id" : 343050712307101696,
  "created_at" : "2013-06-07 20:47:05 +0000",
  "in_reply_to_screen_name" : "tinforest",
  "in_reply_to_user_id_str" : "7337252",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/25s3LB5VuV",
      "expanded_url" : "https:\/\/speakerdeck.com\/hibbittsdesign\/etug-spring-2013-designing-for-touch-not-just-for-mobile-anymore",
      "display_url" : "speakerdeck.com\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343105863533350912",
  "text" : "Thanks to everyone who attended my #etug workshop on touch\/multi-device design today! The slides are now posted at https:\/\/t.co\/25s3LB5VuV",
  "id" : 343105863533350912,
  "created_at" : "2013-06-07 20:43:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jeffery",
      "screen_name" : "kenjeffery",
      "indices" : [ 0, 11 ],
      "id_str" : "91634720",
      "id" : 91634720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343052607213944832",
  "geo" : { },
  "id_str" : "343100756691406849",
  "in_reply_to_user_id" : 91634720,
  "text" : "@kenjeffery Thanks very much for the kind words, it was my pleasure!",
  "id" : 343100756691406849,
  "in_reply_to_status_id" : 343052607213944832,
  "created_at" : "2013-06-07 20:22:49 +0000",
  "in_reply_to_screen_name" : "kenjeffery",
  "in_reply_to_user_id_str" : "91634720",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342790081939136512",
  "text" : "#ETUG participants: Please bring your own touch-enabled devices to my \"Designing for Touch: Not Just for Mobile Anymore\" session tomorrow AM",
  "id" : 342790081939136512,
  "created_at" : "2013-06-06 23:48:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barish Golland",
      "screen_name" : "BarishGolland",
      "indices" : [ 3, 17 ],
      "id_str" : "32352319",
      "id" : 32352319
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UBC",
      "indices" : [ 35, 39 ]
    }, {
      "text" : "etug",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/E22zjjjxnS",
      "expanded_url" : "http:\/\/buff.ly\/15OB6pe",
      "display_url" : "buff.ly\/15OB6pe"
    } ]
  },
  "geo" : { },
  "id_str" : "342712976941391872",
  "text" : "RT @BarishGolland: Diane Goossens, #UBC ODL talking about subsystems of a Flipped Classroom: F2F+Online+Space Between+Space After.http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UBC",
        "indices" : [ 16, 20 ]
      }, {
        "text" : "etug",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/E22zjjjxnS",
        "expanded_url" : "http:\/\/buff.ly\/15OB6pe",
        "display_url" : "buff.ly\/15OB6pe"
      } ]
    },
    "geo" : { },
    "id_str" : "342706050551660545",
    "text" : "Diane Goossens, #UBC ODL talking about subsystems of a Flipped Classroom: F2F+Online+Space Between+Space After.http:\/\/t.co\/E22zjjjxnS #etug",
    "id" : 342706050551660545,
    "created_at" : "2013-06-06 18:14:24 +0000",
    "user" : {
      "name" : "Barish Golland",
      "screen_name" : "BarishGolland",
      "protected" : false,
      "id_str" : "32352319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2781080334\/edb2a707e205406bc022eedd7926198a_normal.jpeg",
      "id" : 32352319,
      "verified" : false
    }
  },
  "id" : 342712976941391872,
  "created_at" : "2013-06-06 18:41:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342635433076858880",
  "text" : "Up early for the start of the #etug Spring Workshop at SFU. A big topic on my radar for the next two days - hybrid\/blended learning!",
  "id" : 342635433076858880,
  "created_at" : "2013-06-06 13:33:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 0, 8 ],
      "id_str" : "10675",
      "id" : 10675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342412403331448835",
  "in_reply_to_user_id" : 10675,
  "text" : "@gordonr Good luck with the presentation Gord! We should do a coffee ourselves sometime soon.",
  "id" : 342412403331448835,
  "created_at" : "2013-06-05 22:47:33 +0000",
  "in_reply_to_screen_name" : "gordonr",
  "in_reply_to_user_id_str" : "10675",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342043859112583169",
  "text" : "Looking forward to #etug this week to discuss learning + technology! Presenting \"Designing for Touch: Not Just for Mobile Anymore\" on Friday",
  "id" : 342043859112583169,
  "created_at" : "2013-06-04 22:23:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/bzcHUHotal",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/b0ddae89-8156-6687-ba26-46e5bf624a52\/",
      "display_url" : "workflowy.com\/shared\/b0ddae8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342000893341859841",
  "text" : "Great feedback and discussion today w. the UX team at SAP BusinessObjects. Updated draft of multi-device principles: https:\/\/t.co\/bzcHUHotal",
  "id" : 342000893341859841,
  "created_at" : "2013-06-04 19:32:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Bacon",
      "screen_name" : "laurenbacon",
      "indices" : [ 3, 15 ],
      "id_str" : "16296154",
      "id" : 16296154
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 147, 148 ],
      "url" : "http:\/\/t.co\/ydeGAEWexR",
      "expanded_url" : "http:\/\/www.openroad.ca\/about\/careers\/",
      "display_url" : "openroad.ca\/about\/careers\/"
    } ]
  },
  "geo" : { },
  "id_str" : "341952828593549312",
  "text" : "RT @laurenbacon: Vancouver devs: OpenRoad has openings for PHP\/Drupal, Java &amp; Python\/Django developers. They're insanely smart &amp; kind. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 126, 148 ],
        "url" : "http:\/\/t.co\/ydeGAEWexR",
        "expanded_url" : "http:\/\/www.openroad.ca\/about\/careers\/",
        "display_url" : "openroad.ca\/about\/careers\/"
      } ]
    },
    "geo" : { },
    "id_str" : "334907179540815872",
    "text" : "Vancouver devs: OpenRoad has openings for PHP\/Drupal, Java &amp; Python\/Django developers. They're insanely smart &amp; kind. http:\/\/t.co\/ydeGAEWexR",
    "id" : 334907179540815872,
    "created_at" : "2013-05-16 05:44:28 +0000",
    "user" : {
      "name" : "Lauren Bacon",
      "screen_name" : "laurenbacon",
      "protected" : false,
      "id_str" : "16296154",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919583928881152\/cpdn9NIm_normal.jpg",
      "id" : 16296154,
      "verified" : false
    }
  },
  "id" : 341952828593549312,
  "created_at" : "2013-06-04 16:21:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 84, 94 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/CAZP1tqPKj",
      "expanded_url" : "http:\/\/shar.es\/w6gcM",
      "display_url" : "shar.es\/w6gcM"
    } ]
  },
  "geo" : { },
  "id_str" : "341721184544624640",
  "text" : "Three Reasons We\u2019ve Outgrown Mobile Context :: UXmatters http:\/\/t.co\/CAZP1tqPKj via @sharethis",
  "id" : 341721184544624640,
  "created_at" : "2013-06-04 01:00:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 23, 33 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/nia74O4BzN",
      "expanded_url" : "http:\/\/slid.es\/paulhibbitts\/multi-device-experience-design-questions-for-discussion",
      "display_url" : "slid.es\/paulhibbitts\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341700702038532096",
  "text" : "Thought I would tryout @SlidesApp to put together a few slides for my multi-device UX talks http:\/\/t.co\/nia74O4BzN Like what I see so far!",
  "id" : 341700702038532096,
  "created_at" : "2013-06-03 23:39:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341684032419008513",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp Also, any short-term plans to support printing? Thanks in advance.",
  "id" : 341684032419008513,
  "created_at" : "2013-06-03 22:33:16 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "SlidesApp",
      "indices" : [ 0, 10 ],
      "id_str" : "3251207217",
      "id" : 3251207217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/nia74O4BzN",
      "expanded_url" : "http:\/\/slid.es\/paulhibbitts\/multi-device-experience-design-questions-for-discussion",
      "display_url" : "slid.es\/paulhibbitts\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341661264256303105",
  "in_reply_to_user_id" : 813740730,
  "text" : "@SlidesApp I've got some stacked input fields for a few slides - how best to add some padding between them? http:\/\/t.co\/nia74O4BzN Thanks!",
  "id" : 341661264256303105,
  "created_at" : "2013-06-03 21:02:47 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/5UrOXnDu34",
      "expanded_url" : "https:\/\/workflowy.com\/shared\/ca578766-e77b-3616-0d97-90026b671147\/",
      "display_url" : "workflowy.com\/shared\/ca57876\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341643244452577280",
  "text" : "Excited to be sharing my mobile and multi-device experiences with the UX team at SAP BusinessObjects &lt;24hrs. Topics: https:\/\/t.co\/5UrOXnDu34",
  "id" : 341643244452577280,
  "created_at" : "2013-06-03 19:51:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]