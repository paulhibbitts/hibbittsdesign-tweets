Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263759797558587392",
  "text" : "Surface is definitely a strange animal",
  "id" : 263759797558587392,
  "created_at" : "2012-10-31 21:50:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 0, 8 ],
      "id_str" : "10675",
      "id" : 10675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263686372559319041",
  "geo" : { },
  "id_str" : "263687846160908289",
  "in_reply_to_user_id" : 10675,
  "text" : "@gordonr Thanks for sharing the reference!",
  "id" : 263687846160908289,
  "in_reply_to_status_id" : 263686372559319041,
  "created_at" : "2012-10-31 17:04:16 +0000",
  "in_reply_to_screen_name" : "gordonr",
  "in_reply_to_user_id_str" : "10675",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Ross",
      "screen_name" : "gordonr",
      "indices" : [ 0, 8 ],
      "id_str" : "10675",
      "id" : 10675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263658086949060608",
  "geo" : { },
  "id_str" : "263669675483881472",
  "in_reply_to_user_id" : 10675,
  "text" : "@gordonr I loved your comment 'we don't feel compelled to watch docs called 'lawyer thinking' or 'dentist thinking' :-)",
  "id" : 263669675483881472,
  "in_reply_to_status_id" : 263658086949060608,
  "created_at" : "2012-10-31 15:52:04 +0000",
  "in_reply_to_screen_name" : "gordonr",
  "in_reply_to_user_id_str" : "10675",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 3, 7 ],
      "id_str" : "1063291",
      "id" : 1063291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/Uf9xUxis",
      "expanded_url" : "http:\/\/ar.gy\/2F80",
      "display_url" : "ar.gy\/2F80"
    } ]
  },
  "geo" : { },
  "id_str" : "261982187585433602",
  "text" : "RT @UIE: Interesting read, \u201CResponsive IA: IA in the touchscreen era\u201D - Martin Belam http:\/\/t.co\/Uf9xUxis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/reach.me\" rel=\"nofollow\"\u003EReach.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/Uf9xUxis",
        "expanded_url" : "http:\/\/ar.gy\/2F80",
        "display_url" : "ar.gy\/2F80"
      } ]
    },
    "geo" : { },
    "id_str" : "261980860247597056",
    "text" : "Interesting read, \u201CResponsive IA: IA in the touchscreen era\u201D - Martin Belam http:\/\/t.co\/Uf9xUxis",
    "id" : 261980860247597056,
    "created_at" : "2012-10-27 00:01:19 +0000",
    "user" : {
      "name" : "UIE",
      "screen_name" : "UIE",
      "protected" : false,
      "id_str" : "1063291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3759116326\/19308cfcdb0b831111d4ee3fc3e6232c_normal.jpeg",
      "id" : 1063291,
      "verified" : false
    }
  },
  "id" : 261982187585433602,
  "created_at" : "2012-10-27 00:06:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/KH1EcDYI",
      "expanded_url" : "http:\/\/etug.ca\/event\/workshops-2\/",
      "display_url" : "etug.ca\/event\/workshop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261174725953339392",
  "text" : "RT @etug: ETUG Fall workshop is only a week or so away. Here's the program http:\/\/t.co\/KH1EcDYI\nRegister by Friday Oct 26 midnight!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/KH1EcDYI",
        "expanded_url" : "http:\/\/etug.ca\/event\/workshops-2\/",
        "display_url" : "etug.ca\/event\/workshop\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "261143298851364864",
    "text" : "ETUG Fall workshop is only a week or so away. Here's the program http:\/\/t.co\/KH1EcDYI\nRegister by Friday Oct 26 midnight!",
    "id" : 261143298851364864,
    "created_at" : "2012-10-24 16:33:08 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 261174725953339392,
  "created_at" : "2012-10-24 18:38:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess McMullin",
      "screen_name" : "jessmcmullin",
      "indices" : [ 0, 13 ],
      "id_str" : "381203",
      "id" : 381203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260527571035385856",
  "geo" : { },
  "id_str" : "260529545084563456",
  "in_reply_to_user_id" : 381203,
  "text" : "@jessmcmullin Good luck with your talk!",
  "id" : 260529545084563456,
  "in_reply_to_status_id" : 260527571035385856,
  "created_at" : "2012-10-22 23:54:18 +0000",
  "in_reply_to_screen_name" : "jessmcmullin",
  "in_reply_to_user_id_str" : "381203",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess McMullin",
      "screen_name" : "jessmcmullin",
      "indices" : [ 0, 13 ],
      "id_str" : "381203",
      "id" : 381203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260527571035385856",
  "geo" : { },
  "id_str" : "260529315094081536",
  "in_reply_to_user_id" : 381203,
  "text" : "@jessmcmullin Track when work makes you feel energized and use this list to help guide your pursuit of future work",
  "id" : 260529315094081536,
  "in_reply_to_status_id" : 260527571035385856,
  "created_at" : "2012-10-22 23:53:23 +0000",
  "in_reply_to_screen_name" : "jessmcmullin",
  "in_reply_to_user_id_str" : "381203",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess McMullin",
      "screen_name" : "jessmcmullin",
      "indices" : [ 0, 13 ],
      "id_str" : "381203",
      "id" : 381203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260527571035385856",
  "geo" : { },
  "id_str" : "260529196558868480",
  "in_reply_to_user_id" : 381203,
  "text" : "@jessmcmullin Don\u2019t seek credit\r\u2013 let others take it, try one new technique every project, and view it as an experiment",
  "id" : 260529196558868480,
  "in_reply_to_status_id" : 260527571035385856,
  "created_at" : "2012-10-22 23:52:55 +0000",
  "in_reply_to_screen_name" : "jessmcmullin",
  "in_reply_to_user_id_str" : "381203",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess McMullin",
      "screen_name" : "jessmcmullin",
      "indices" : [ 0, 13 ],
      "id_str" : "381203",
      "id" : 381203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260527571035385856",
  "geo" : { },
  "id_str" : "260528912558329856",
  "in_reply_to_user_id" : 381203,
  "text" : "@jessmcmullin Something we all strive for :-)  Here are a few more for you to consider\u2026 speak about your process as a toolkit",
  "id" : 260528912558329856,
  "in_reply_to_status_id" : 260527571035385856,
  "created_at" : "2012-10-22 23:51:47 +0000",
  "in_reply_to_screen_name" : "jessmcmullin",
  "in_reply_to_user_id_str" : "381203",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess McMullin",
      "screen_name" : "jessmcmullin",
      "indices" : [ 0, 13 ],
      "id_str" : "381203",
      "id" : 381203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260374949380907008",
  "geo" : { },
  "id_str" : "260526595540930560",
  "in_reply_to_user_id" : 381203,
  "text" : "@jessmcmullin How about the importance of humility?",
  "id" : 260526595540930560,
  "in_reply_to_status_id" : 260374949380907008,
  "created_at" : "2012-10-22 23:42:35 +0000",
  "in_reply_to_screen_name" : "jessmcmullin",
  "in_reply_to_user_id_str" : "381203",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/2AmKtocf",
      "expanded_url" : "http:\/\/www.paulhibbitts.com\/workshops.html#mobilelearningux",
      "display_url" : "paulhibbitts.com\/workshops.html\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260476092404613120",
  "text" : "First public mobile learning UX course at UBC is canceled due to low enrollment, but still offering private workshops! http:\/\/t.co\/2AmKtocf",
  "id" : 260476092404613120,
  "created_at" : "2012-10-22 20:21:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/ljy80ixM",
      "expanded_url" : "http:\/\/etug.ca\/2012\/10\/19\/fall-workshop-2012-schedule\/",
      "display_url" : "etug.ca\/2012\/10\/19\/fal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "259421477294727169",
  "text" : "RT @etug: As promised...it's a good one! Fall Workshop Nov. 2nd http:\/\/t.co\/ljy80ixM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/ljy80ixM",
        "expanded_url" : "http:\/\/etug.ca\/2012\/10\/19\/fall-workshop-2012-schedule\/",
        "display_url" : "etug.ca\/2012\/10\/19\/fal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "259419272219066368",
    "text" : "As promised...it's a good one! Fall Workshop Nov. 2nd http:\/\/t.co\/ljy80ixM",
    "id" : 259419272219066368,
    "created_at" : "2012-10-19 22:22:28 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 259421477294727169,
  "created_at" : "2012-10-19 22:31:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Jursa",
      "screen_name" : "IATV",
      "indices" : [ 3, 8 ],
      "id_str" : "17151314",
      "id" : 17151314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/t2Yc1JPM",
      "expanded_url" : "http:\/\/bit.ly\/Rkb9FJ",
      "display_url" : "bit.ly\/Rkb9FJ"
    } ]
  },
  "geo" : { },
  "id_str" : "259020387340410880",
  "text" : "RT @IATV: \"Windows 8 Templates for PowerPoint\" http:\/\/t.co\/t2Yc1JPM (linowski.ca)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/t2Yc1JPM",
        "expanded_url" : "http:\/\/bit.ly\/Rkb9FJ",
        "display_url" : "bit.ly\/Rkb9FJ"
      } ]
    },
    "geo" : { },
    "id_str" : "258986000066441217",
    "text" : "\"Windows 8 Templates for PowerPoint\" http:\/\/t.co\/t2Yc1JPM (linowski.ca)",
    "id" : 258986000066441217,
    "created_at" : "2012-10-18 17:40:48 +0000",
    "user" : {
      "name" : "Jan Jursa",
      "screen_name" : "IATV",
      "protected" : false,
      "id_str" : "17151314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466681693235982336\/4v-lZ2o2_normal.jpeg",
      "id" : 17151314,
      "verified" : false
    }
  },
  "id" : 259020387340410880,
  "created_at" : "2012-10-18 19:57:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "foundationzurb",
      "screen_name" : "foundationzurb",
      "indices" : [ 3, 18 ],
      "id_str" : "2394933703",
      "id" : 2394933703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/XWhwFNBj",
      "expanded_url" : "http:\/\/www.responsinator.com\/?url=foundation.zurb.com",
      "display_url" : "responsinator.com\/?url=foundatio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258640129068003330",
  "text" : "RT @foundationzurb: If you haven't seen this, it's a pretty awesome tool for checking your site on different sizes: http:\/\/t.co\/XWhwFNBj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/XWhwFNBj",
        "expanded_url" : "http:\/\/www.responsinator.com\/?url=foundation.zurb.com",
        "display_url" : "responsinator.com\/?url=foundatio\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "258635153293852672",
    "text" : "If you haven't seen this, it's a pretty awesome tool for checking your site on different sizes: http:\/\/t.co\/XWhwFNBj",
    "id" : 258635153293852672,
    "created_at" : "2012-10-17 18:26:40 +0000",
    "user" : {
      "name" : "ZURB Foundation",
      "screen_name" : "ZURBfoundation",
      "protected" : false,
      "id_str" : "360434586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740657740310142976\/2vkxYBSK_normal.jpg",
      "id" : 360434586,
      "verified" : false
    }
  },
  "id" : 258640129068003330,
  "created_at" : "2012-10-17 18:46:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Buxton",
      "screen_name" : "wasbuxton",
      "indices" : [ 0, 10 ],
      "id_str" : "57046779",
      "id" : 57046779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257887396211871745",
  "geo" : { },
  "id_str" : "257891182821126145",
  "in_reply_to_user_id" : 57046779,
  "text" : "@wasbuxton\n1. Yes\n2. No\n3. No",
  "id" : 257891182821126145,
  "in_reply_to_status_id" : 257887396211871745,
  "created_at" : "2012-10-15 17:10:24 +0000",
  "in_reply_to_screen_name" : "wasbuxton",
  "in_reply_to_user_id_str" : "57046779",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IxDA Vancouver",
      "screen_name" : "IxDAVancouver",
      "indices" : [ 3, 17 ],
      "id_str" : "23839616",
      "id" : 23839616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/RfpZSxxp",
      "expanded_url" : "http:\/\/designthinkingvancouver.eventbrite.com",
      "display_url" : "designthinkingvancouver.eventbrite.com"
    } ]
  },
  "geo" : { },
  "id_str" : "254002856301064193",
  "text" : "RT @IxDAVancouver: Join us for the Canadian premiere of 'Design &amp; Thinking' with great panel &amp; reception to follow. Tickets on s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 126, 146 ],
        "url" : "http:\/\/t.co\/RfpZSxxp",
        "expanded_url" : "http:\/\/designthinkingvancouver.eventbrite.com",
        "display_url" : "designthinkingvancouver.eventbrite.com"
      } ]
    },
    "geo" : { },
    "id_str" : "253236207646019584",
    "text" : "Join us for the Canadian premiere of 'Design &amp; Thinking' with great panel &amp; reception to follow. Tickets on sale now! http:\/\/t.co\/RfpZSxxp",
    "id" : 253236207646019584,
    "created_at" : "2012-10-02 20:53:11 +0000",
    "user" : {
      "name" : "IxDA Vancouver",
      "screen_name" : "IxDAVancouver",
      "protected" : false,
      "id_str" : "23839616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/93286946\/logo_van_normal.png",
      "id" : 23839616,
      "verified" : false
    }
  },
  "id" : 254002856301064193,
  "created_at" : "2012-10-04 23:39:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denim & Steel",
      "screen_name" : "DenimAndSteel",
      "indices" : [ 105, 119 ],
      "id_str" : "386399234",
      "id" : 386399234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Ma7Us4eM",
      "expanded_url" : "http:\/\/heyavailable.com\/",
      "display_url" : "heyavailable.com"
    } ]
  },
  "geo" : { },
  "id_str" : "254002515841007616",
  "in_reply_to_user_id" : 386399234,
  "text" : "Check out the new job board http:\/\/t.co\/Ma7Us4eM for Vancouver tech and design talent brought to you by \n@DenimAndSteel - kudos guys!",
  "id" : 254002515841007616,
  "created_at" : "2012-10-04 23:38:13 +0000",
  "in_reply_to_screen_name" : "DenimAndSteel",
  "in_reply_to_user_id_str" : "386399234",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]