Grailbird.data.tweets_2013_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406530342044958720",
  "geo" : { },
  "id_str" : "406531373894094848",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh I am more thinking about multiple (physical) store apps, multiple university campus apps, multiple bus transit apps, etc.",
  "id" : 406531373894094848,
  "in_reply_to_status_id" : 406530342044958720,
  "created_at" : "2013-11-29 21:13:27 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406512395331174400",
  "geo" : { },
  "id_str" : "406514268285054976",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh Also my experiences with multi-device web apps have led to a distaste for different UIs across multiple devices esp. task switching",
  "id" : 406514268285054976,
  "in_reply_to_status_id" : 406512395331174400,
  "created_at" : "2013-11-29 20:05:28 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406512395331174400",
  "geo" : { },
  "id_str" : "406513670894542848",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh A never-ending number of them, with overlap due to data silos. Web apps seem the way forward in most cases, especially with the IoT.",
  "id" : 406513670894542848,
  "in_reply_to_status_id" : 406512395331174400,
  "created_at" : "2013-11-29 20:03:06 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406499366682112000",
  "text" : "The whole idea of Mobile Apps seems more and more quaint to me.",
  "id" : 406499366682112000,
  "created_at" : "2013-11-29 19:06:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cmpt363",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405875999810011137",
  "text" : "Working on a possible design challenge question for my #cmpt363 final exam - in a future where Apple's iBeacon technology is ubiquitous\u2026",
  "id" : 405875999810011137,
  "created_at" : "2013-11-28 01:49:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405472422666571776",
  "text" : "Preparing my next discussion-style presentation on multi-device experiences. Just added: Is Responsive Web Design already our new 960px?",
  "id" : 405472422666571776,
  "created_at" : "2013-11-26 23:05:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/ZKIGnZJ3es",
      "expanded_url" : "http:\/\/www.cellular-news.com\/story\/63175.php",
      "display_url" : "cellular-news.com\/story\/63175.php"
    } ]
  },
  "geo" : { },
  "id_str" : "405452451760701440",
  "text" : "Touch Screen Penetration in Notebook PCs Modest, But on the Rise http:\/\/t.co\/ZKIGnZJ3es &lt;- All websites should be touch friendly these days",
  "id" : 405452451760701440,
  "created_at" : "2013-11-26 21:46:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405393334694187008",
  "text" : "Excited to be starting work on my next new course, tentatively titled \u201CDesigning the Learner Experience for a Multi-device World\u201D.",
  "id" : 405393334694187008,
  "created_at" : "2013-11-26 17:51:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thecanadacom",
      "screen_name" : "thecanadacom",
      "indices" : [ 63, 76 ],
      "id_str" : "2484737280",
      "id" : 2484737280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/JvXqgcDaNG",
      "expanded_url" : "http:\/\/o.canada.com\/business\/worlds-biggest-bookstore-toronto-closing\/",
      "display_url" : "o.canada.com\/business\/world\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "404416451030683648",
  "text" : "World's Biggest Bookstore's closing http:\/\/t.co\/JvXqgcDaNG via @thecanadacom &lt;- Where I found my first UI design book... in 1989",
  "id" : 404416451030683648,
  "created_at" : "2013-11-24 01:09:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "indices" : [ 0, 12 ],
      "id_str" : "730373",
      "id" : 730373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403701502570532864",
  "geo" : { },
  "id_str" : "403703128429568000",
  "in_reply_to_user_id" : 730373,
  "text" : "@scottjenson I loved the breadth of UPoD in combination with the visuals. Looks like I've got a few more books to check out now...",
  "id" : 403703128429568000,
  "in_reply_to_status_id" : 403701502570532864,
  "created_at" : "2013-11-22 01:55:00 +0000",
  "in_reply_to_screen_name" : "scottjenson",
  "in_reply_to_user_id_str" : "730373",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved to @kornelski",
      "screen_name" : "pornelski",
      "indices" : [ 3, 13 ],
      "id_str" : "4794878195",
      "id" : 4794878195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403181889424347137",
  "text" : "RT @pornelski: Dear mobile site designers: I do not become dumber when using a mobile device. Please don't remove functionality.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403169537144537088",
    "text" : "Dear mobile site designers: I do not become dumber when using a mobile device. Please don't remove functionality.",
    "id" : 403169537144537088,
    "created_at" : "2013-11-20 14:34:42 +0000",
    "user" : {
      "name" : "Kornel",
      "screen_name" : "kornelski",
      "protected" : false,
      "id_str" : "69655255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2553871671\/ku8xb72ymmy184y5arv7_normal.jpeg",
      "id" : 69655255,
      "verified" : false
    }
  },
  "id" : 403181889424347137,
  "created_at" : "2013-11-20 15:23:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chrome Developers",
      "screen_name" : "ChromiumDev",
      "indices" : [ 3, 15 ],
      "id_str" : "113713261",
      "id" : 113713261
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ChromiumDev\/status\/403007122415157248\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/ghi7uUW6Lg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZfE17YCAAAcwRX.jpg",
      "id_str" : "403007122423545856",
      "id" : 403007122423545856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZfE17YCAAAcwRX.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ghi7uUW6Lg"
    } ],
    "hashtags" : [ {
      "text" : "chromedevsummit",
      "indices" : [ 43, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403012464167493632",
  "text" : "RT @ChromiumDev: See you tomorrow morning. #chromedevsummit http:\/\/t.co\/ghi7uUW6Lg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ChromiumDev\/status\/403007122415157248\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/ghi7uUW6Lg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZfE17YCAAAcwRX.jpg",
        "id_str" : "403007122423545856",
        "id" : 403007122423545856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZfE17YCAAAcwRX.jpg",
        "sizes" : [ {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ghi7uUW6Lg"
      } ],
      "hashtags" : [ {
        "text" : "chromedevsummit",
        "indices" : [ 26, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403007122415157248",
    "text" : "See you tomorrow morning. #chromedevsummit http:\/\/t.co\/ghi7uUW6Lg",
    "id" : 403007122415157248,
    "created_at" : "2013-11-20 03:49:20 +0000",
    "user" : {
      "name" : "Chrome Developers",
      "screen_name" : "ChromiumDev",
      "protected" : false,
      "id_str" : "113713261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1320180647\/chromiumchrome_normal.png",
      "id" : 113713261,
      "verified" : true
    }
  },
  "id" : 403012464167493632,
  "created_at" : "2013-11-20 04:10:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amir Khella",
      "screen_name" : "amirkhella",
      "indices" : [ 3, 14 ],
      "id_str" : "7985762",
      "id" : 7985762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "us",
      "indices" : [ 65, 68 ]
    }, {
      "text" : "design",
      "indices" : [ 69, 76 ]
    }, {
      "text" : "Startup",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401091420791914496",
  "text" : "RT @amirkhella: Many people confuse good-looking UI with good UI #us #design #Startup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "us",
        "indices" : [ 49, 52 ]
      }, {
        "text" : "design",
        "indices" : [ 53, 60 ]
      }, {
        "text" : "Startup",
        "indices" : [ 61, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401089980157526016",
    "text" : "Many people confuse good-looking UI with good UI #us #design #Startup",
    "id" : 401089980157526016,
    "created_at" : "2013-11-14 20:51:17 +0000",
    "user" : {
      "name" : "Amir Khella",
      "screen_name" : "amirkhella",
      "protected" : false,
      "id_str" : "7985762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000064136776\/0459de9b955462b2a983d29d6dcd3a90_normal.png",
      "id" : 7985762,
      "verified" : false
    }
  },
  "id" : 401091420791914496,
  "created_at" : "2013-11-14 20:57:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gagan Diesh",
      "screen_name" : "diesh",
      "indices" : [ 0, 6 ],
      "id_str" : "5357662",
      "id" : 5357662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401029641911025664",
  "geo" : { },
  "id_str" : "401041480275353600",
  "in_reply_to_user_id" : 5357662,
  "text" : "@diesh Have you tried out TimeDriver?",
  "id" : 401041480275353600,
  "in_reply_to_status_id" : 401029641911025664,
  "created_at" : "2013-11-14 17:38:34 +0000",
  "in_reply_to_screen_name" : "diesh",
  "in_reply_to_user_id_str" : "5357662",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeus XXXXXX",
      "screen_name" : "EdTechEmpowers",
      "indices" : [ 3, 18 ],
      "id_str" : "17545016",
      "id" : 17545016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 66, 73 ]
    }, {
      "text" : "education",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "edtech",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400397179950362624",
  "text" : "RT @EdTechEmpowers: Adapt or stagnate (or die). For the creative, #edtech is opening very exciting new learning possibilities for EVERYONE.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 46, 53 ]
      }, {
        "text" : "education",
        "indices" : [ 120, 130 ]
      }, {
        "text" : "edtech",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400396953550221312",
    "text" : "Adapt or stagnate (or die). For the creative, #edtech is opening very exciting new learning possibilities for EVERYONE. #education #edtech",
    "id" : 400396953550221312,
    "created_at" : "2013-11-12 22:57:27 +0000",
    "user" : {
      "name" : "Brian C. Bailey",
      "screen_name" : "21stCenEducator",
      "protected" : false,
      "id_str" : "366283556",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1524228167\/P1000047__641x641__normal.JPG",
      "id" : 366283556,
      "verified" : false
    }
  },
  "id" : 400397179950362624,
  "created_at" : "2013-11-12 22:58:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Udell",
      "screen_name" : "visualrinse",
      "indices" : [ 3, 15 ],
      "id_str" : "809010",
      "id" : 809010
    }, {
      "name" : "Jane Bozarth",
      "screen_name" : "JaneBozarth",
      "indices" : [ 105, 117 ],
      "id_str" : "16026300",
      "id" : 16026300
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learn13",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400371168139411456",
  "text" : "RT @visualrinse: \"We aren't talking enough about how our learners have evolved.\" Wisdom at #learn13 from @JaneBozarth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jane Bozarth",
        "screen_name" : "JaneBozarth",
        "indices" : [ 88, 100 ],
        "id_str" : "16026300",
        "id" : 16026300
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "learn13",
        "indices" : [ 74, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400340989526962176",
    "text" : "\"We aren't talking enough about how our learners have evolved.\" Wisdom at #learn13 from @JaneBozarth",
    "id" : 400340989526962176,
    "created_at" : "2013-11-12 19:15:04 +0000",
    "user" : {
      "name" : "Chad Udell",
      "screen_name" : "visualrinse",
      "protected" : false,
      "id_str" : "809010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760175912675520515\/Zfm9Y5KI_normal.jpg",
      "id" : 809010,
      "verified" : false
    }
  },
  "id" : 400371168139411456,
  "created_at" : "2013-11-12 21:14:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "indices" : [ 0, 12 ],
      "id_str" : "730373",
      "id" : 730373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398826776001921026",
  "geo" : { },
  "id_str" : "398829495831896064",
  "in_reply_to_user_id" : 730373,
  "text" : "@scottjenson Congratulations, that makes Chrome even more promising! Always appreciated your book The Simplicity Shift as well.",
  "id" : 398829495831896064,
  "in_reply_to_status_id" : 398826776001921026,
  "created_at" : "2013-11-08 15:08:56 +0000",
  "in_reply_to_screen_name" : "scottjenson",
  "in_reply_to_user_id_str" : "730373",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Cooper",
      "screen_name" : "MrAlanCooper",
      "indices" : [ 3, 16 ],
      "id_str" : "103920270",
      "id" : 103920270
    }, {
      "name" : "Dorian Taylor",
      "screen_name" : "doriantaylor",
      "indices" : [ 105, 118 ],
      "id_str" : "15417853",
      "id" : 15417853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/JntBsUuw9E",
      "expanded_url" : "http:\/\/youtu.be\/zumdnI4EG14",
      "display_url" : "youtu.be\/zumdnI4EG14"
    } ]
  },
  "geo" : { },
  "id_str" : "398614738264809473",
  "text" : "RT @MrAlanCooper: He's exactly correct, but I just want to write some decent software for humans--&gt;RT @doriantaylor http:\/\/t.co\/JntBsUuw9E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dorian Taylor",
        "screen_name" : "doriantaylor",
        "indices" : [ 87, 100 ],
        "id_str" : "15417853",
        "id" : 15417853
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/JntBsUuw9E",
        "expanded_url" : "http:\/\/youtu.be\/zumdnI4EG14",
        "display_url" : "youtu.be\/zumdnI4EG14"
      } ]
    },
    "geo" : { },
    "id_str" : "398598214548344833",
    "text" : "He's exactly correct, but I just want to write some decent software for humans--&gt;RT @doriantaylor http:\/\/t.co\/JntBsUuw9E",
    "id" : 398598214548344833,
    "created_at" : "2013-11-07 23:49:54 +0000",
    "user" : {
      "name" : "Alan Cooper",
      "screen_name" : "MrAlanCooper",
      "protected" : false,
      "id_str" : "103920270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1470274107\/Alan_Avatar_normal.jpg",
      "id" : 103920270,
      "verified" : false
    }
  },
  "id" : 398614738264809473,
  "created_at" : "2013-11-08 00:55:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "indices" : [ 3, 15 ],
      "id_str" : "730373",
      "id" : 730373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/vL6y2LvZAB",
      "expanded_url" : "http:\/\/support.apple.com\/kb\/HT6049?viewlocale=en_US&locale=en_US",
      "display_url" : "support.apple.com\/kb\/HT6049?view\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398242414755737600",
  "text" : "RT @scottjenson: Well, it looks like Apple is listening. Announces will add dropped features back into Keynote 6: http:\/\/t.co\/vL6y2LvZAB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/vL6y2LvZAB",
        "expanded_url" : "http:\/\/support.apple.com\/kb\/HT6049?viewlocale=en_US&locale=en_US",
        "display_url" : "support.apple.com\/kb\/HT6049?view\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "398229774239154176",
    "text" : "Well, it looks like Apple is listening. Announces will add dropped features back into Keynote 6: http:\/\/t.co\/vL6y2LvZAB",
    "id" : 398229774239154176,
    "created_at" : "2013-11-06 23:25:51 +0000",
    "user" : {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "protected" : false,
      "id_str" : "730373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576892785149628416\/FiovXOSs_normal.jpeg",
      "id" : 730373,
      "verified" : true
    }
  },
  "id" : 398242414755737600,
  "created_at" : "2013-11-07 00:16:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Goodwin",
      "screen_name" : "kimgoodwin",
      "indices" : [ 3, 14 ],
      "id_str" : "16295946",
      "id" : 16295946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398201297423200256",
  "text" : "RT @kimgoodwin: Some day, \"go to full site\" links will become extinct. We will all celebrate.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398193618227195904",
    "text" : "Some day, \"go to full site\" links will become extinct. We will all celebrate.",
    "id" : 398193618227195904,
    "created_at" : "2013-11-06 21:02:11 +0000",
    "user" : {
      "name" : "Kim Goodwin",
      "screen_name" : "kimgoodwin",
      "protected" : false,
      "id_str" : "16295946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756436364929994752\/ADL0_wac_normal.jpg",
      "id" : 16295946,
      "verified" : false
    }
  },
  "id" : 398201297423200256,
  "created_at" : "2013-11-06 21:32:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/L75Q7egPT9",
      "expanded_url" : "https:\/\/developers.google.com\/chrome\/mobile\/docs\/installtohomescreen",
      "display_url" : "developers.google.com\/chrome\/mobile\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397507865725779970",
  "text" : "This course companion update also supports Web App shortcuts with the latest Chrome Beta for Android. Learn how at https:\/\/t.co\/L75Q7egPT9",
  "id" : 397507865725779970,
  "created_at" : "2013-11-04 23:37:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/2DqxykPPcv",
      "expanded_url" : "https:\/\/chrome.google.com\/webstore\/detail\/cmpt-363-fall-2013-course\/makeeghaichkhojfhcioclgdnonhecph?hl=en-US&gl=CA",
      "display_url" : "chrome.google.com\/webstore\/detai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397506612660695040",
  "text" : "Recently updated the Google Apps desktop version of my multi-device CMPT 363 course companion, available at: https:\/\/t.co\/2DqxykPPcv",
  "id" : 397506612660695040,
  "created_at" : "2013-11-04 23:32:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397430907763560448",
  "text" : "Does anyone know of a CMS\/WordPress\/Moodle plugin that drip-feeds content and provides a way for readers to \u2018skip\u2019 to next content chunk?",
  "id" : 397430907763560448,
  "created_at" : "2013-11-04 18:31:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397147701369790464",
  "text" : "Mulling over a new course companion feature: based on a topic of interest, stream specific articles grounded by a supporting narrative.",
  "id" : 397147701369790464,
  "created_at" : "2013-11-03 23:46:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/bA8uCIC3rc",
      "expanded_url" : "http:\/\/ami.responsivedesign.is\/",
      "display_url" : "ami.responsivedesign.is"
    } ]
  },
  "geo" : { },
  "id_str" : "396396908953866240",
  "text" : "Here is a very useful tool to simultaneously display a responsive web site with four different display sizes: http:\/\/t.co\/bA8uCIC3rc",
  "id" : 396396908953866240,
  "created_at" : "2013-11-01 22:02:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SD Times",
      "screen_name" : "sdtimes",
      "indices" : [ 3, 11 ],
      "id_str" : "18316059",
      "id" : 18316059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/dEWxxbeclF",
      "expanded_url" : "http:\/\/buff.ly\/1aNiozV",
      "display_url" : "buff.ly\/1aNiozV"
    } ]
  },
  "geo" : { },
  "id_str" : "396385640327421952",
  "text" : "RT @sdtimes: One size isn't always best for all. Taking a deeper look at responsive web design http:\/\/t.co\/dEWxxbeclF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/dEWxxbeclF",
        "expanded_url" : "http:\/\/buff.ly\/1aNiozV",
        "display_url" : "buff.ly\/1aNiozV"
      } ]
    },
    "geo" : { },
    "id_str" : "396339755065307136",
    "text" : "One size isn't always best for all. Taking a deeper look at responsive web design http:\/\/t.co\/dEWxxbeclF",
    "id" : 396339755065307136,
    "created_at" : "2013-11-01 18:15:35 +0000",
    "user" : {
      "name" : "SD Times",
      "screen_name" : "sdtimes",
      "protected" : false,
      "id_str" : "18316059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519216023585579008\/bnGl7Am3_normal.jpeg",
      "id" : 18316059,
      "verified" : true
    }
  },
  "id" : 396385640327421952,
  "created_at" : "2013-11-01 21:17:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "indices" : [ 3, 16 ],
      "id_str" : "35943",
      "id" : 35943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/MQcRRZGm9d",
      "expanded_url" : "http:\/\/bit.ly\/1ikvneS",
      "display_url" : "bit.ly\/1ikvneS"
    } ]
  },
  "geo" : { },
  "id_str" : "396337284338831360",
  "text" : "RT @karenmcgrane: Responsive design is a poor man's content strategy. A mere reshuffling of blobs of content is not a content strategy. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/MQcRRZGm9d",
        "expanded_url" : "http:\/\/bit.ly\/1ikvneS",
        "display_url" : "bit.ly\/1ikvneS"
      } ]
    },
    "geo" : { },
    "id_str" : "395178272432328704",
    "text" : "Responsive design is a poor man's content strategy. A mere reshuffling of blobs of content is not a content strategy. http:\/\/t.co\/MQcRRZGm9d",
    "id" : 395178272432328704,
    "created_at" : "2013-10-29 13:20:16 +0000",
    "user" : {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "protected" : false,
      "id_str" : "35943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720948130867449857\/DR8tPuqM_normal.jpg",
      "id" : 35943,
      "verified" : false
    }
  },
  "id" : 396337284338831360,
  "created_at" : "2013-11-01 18:05:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]