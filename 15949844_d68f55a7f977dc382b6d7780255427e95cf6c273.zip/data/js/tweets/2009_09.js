Grailbird.data.tweets_2009_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4533239595",
  "text" : "Practical viewpoint about Agile + UCD: \u201CCan User-Centered Design and Agile Get Along?\u201D: http:\/\/bit.ly\/1FUjQ8",
  "id" : 4533239595,
  "created_at" : "2009-10-01 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Onehub",
      "screen_name" : "onehub",
      "indices" : [ 0, 7 ],
      "id_str" : "14306280",
      "id" : 14306280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4509480743",
  "in_reply_to_user_id" : 14306280,
  "text" : "@onehub I'd be very interested! Thanks.",
  "id" : 4509480743,
  "created_at" : "2009-09-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "onehub",
  "in_reply_to_user_id_str" : "14306280",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitney Hess",
      "screen_name" : "whitneyhess",
      "indices" : [ 0, 12 ],
      "id_str" : "11963132",
      "id" : 11963132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4088234297",
  "in_reply_to_user_id" : 11963132,
  "text" : "@whitneyhess Happy to share experiences with process vs. portfolio \u2013 being able to be effective within existing processes is key as well",
  "id" : 4088234297,
  "created_at" : "2009-09-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "whitneyhess",
  "in_reply_to_user_id_str" : "11963132",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4089561131",
  "text" : "Once again reminded of the incredible value of populating a prototype with real-world data.",
  "id" : 4089561131,
  "created_at" : "2009-09-18 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]