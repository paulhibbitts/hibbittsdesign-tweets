Grailbird.data.tweets_2015_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638579590542196736",
  "text" : "RT @getgrav: I think **Grav 1.0** is fast approaching!  Grav + Admin are looking pretty solid now!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638409828788932612",
    "text" : "I think **Grav 1.0** is fast approaching!  Grav + Admin are looking pretty solid now!",
    "id" : 638409828788932612,
    "created_at" : "2015-08-31 17:55:38 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 638579590542196736,
  "created_at" : "2015-09-01 05:10:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "indices" : [ 3, 12 ],
      "id_str" : "18613",
      "id" : 18613
    }, {
      "name" : "Downes",
      "screen_name" : "Downes",
      "indices" : [ 22, 29 ],
      "id_str" : "7470932",
      "id" : 7470932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/v8xrVqhXpO",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1w39qKDxRZx8oxfhgOXDg9-XyfhKvCfE73j0kPzB3xsI\/edit",
      "display_url" : "docs.google.com\/document\/d\/1w3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638567125741756416",
  "text" : "RT @gsiemens: Reading @downes on designing a personal learning environment https:\/\/t.co\/v8xrVqhXpO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Downes",
        "screen_name" : "Downes",
        "indices" : [ 8, 15 ],
        "id_str" : "7470932",
        "id" : 7470932
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/v8xrVqhXpO",
        "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1w39qKDxRZx8oxfhgOXDg9-XyfhKvCfE73j0kPzB3xsI\/edit",
        "display_url" : "docs.google.com\/document\/d\/1w3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638545236931821568",
    "text" : "Reading @downes on designing a personal learning environment https:\/\/t.co\/v8xrVqhXpO",
    "id" : 638545236931821568,
    "created_at" : "2015-09-01 02:53:42 +0000",
    "user" : {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "protected" : false,
      "id_str" : "18613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451036825637761025\/7_0RawE8_normal.jpeg",
      "id" : 18613,
      "verified" : false
    }
  },
  "id" : 638567125741756416,
  "created_at" : "2015-09-01 04:20:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Ridden",
      "screen_name" : "EduRidden",
      "indices" : [ 3, 13 ],
      "id_str" : "9198142",
      "id" : 9198142
    }, {
      "name" : "Pragmatic Git",
      "screen_name" : "gitbook",
      "indices" : [ 68, 76 ],
      "id_str" : "24635399",
      "id" : 24635399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "authors",
      "indices" : [ 48, 56 ]
    }, {
      "text" : "book",
      "indices" : [ 95, 100 ]
    }, {
      "text" : "library",
      "indices" : [ 134, 140 ]
    }, {
      "text" : "education",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/knkvKUlMaj",
      "expanded_url" : "https:\/\/www.gitbook.com",
      "display_url" : "gitbook.com"
    } ]
  },
  "geo" : { },
  "id_str" : "638566795549405184",
  "text" : "RT @EduRidden: here is a great tool for budding #authors. Check out @gitbook, a great tool for #book writing. https:\/\/t.co\/knkvKUlMaj #libr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pragmatic Git",
        "screen_name" : "gitbook",
        "indices" : [ 53, 61 ],
        "id_str" : "24635399",
        "id" : 24635399
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "authors",
        "indices" : [ 33, 41 ]
      }, {
        "text" : "book",
        "indices" : [ 80, 85 ]
      }, {
        "text" : "library",
        "indices" : [ 119, 127 ]
      }, {
        "text" : "education",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/knkvKUlMaj",
        "expanded_url" : "https:\/\/www.gitbook.com",
        "display_url" : "gitbook.com"
      } ]
    },
    "geo" : { },
    "id_str" : "638550495892779009",
    "text" : "here is a great tool for budding #authors. Check out @gitbook, a great tool for #book writing. https:\/\/t.co\/knkvKUlMaj #library #education",
    "id" : 638550495892779009,
    "created_at" : "2015-09-01 03:14:36 +0000",
    "user" : {
      "name" : "Julian Ridden",
      "screen_name" : "EduRidden",
      "protected" : false,
      "id_str" : "9198142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755434524066971648\/AcgB4rwn_normal.jpg",
      "id" : 9198142,
      "verified" : false
    }
  },
  "id" : 638566795549405184,
  "created_at" : "2015-09-01 04:19:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bajarin",
      "screen_name" : "BenBajarin",
      "indices" : [ 3, 14 ],
      "id_str" : "14546264",
      "id" : 14546264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/KWJaQA6Gdd",
      "expanded_url" : "https:\/\/techpinions.com\/someday-all-companies-will-be-tech-companies\/41648",
      "display_url" : "techpinions.com\/someday-all-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638435957205692416",
  "text" : "RT @BenBajarin: Someday, All Companies Will Be Tech Companies\n\nhttps:\/\/t.co\/KWJaQA6Gdd\n\nMy thoughts on how tech will invade every type of b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/KWJaQA6Gdd",
        "expanded_url" : "https:\/\/techpinions.com\/someday-all-companies-will-be-tech-companies\/41648",
        "display_url" : "techpinions.com\/someday-all-co\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638434073178845185",
    "text" : "Someday, All Companies Will Be Tech Companies\n\nhttps:\/\/t.co\/KWJaQA6Gdd\n\nMy thoughts on how tech will invade every type of business.",
    "id" : 638434073178845185,
    "created_at" : "2015-08-31 19:31:59 +0000",
    "user" : {
      "name" : "Ben Bajarin",
      "screen_name" : "BenBajarin",
      "protected" : false,
      "id_str" : "14546264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679174610315677696\/Fx4qZ9iE_normal.png",
      "id" : 14546264,
      "verified" : false
    }
  },
  "id" : 638435957205692416,
  "created_at" : "2015-08-31 19:39:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 39, 49 ],
      "id_str" : "34732474",
      "id" : 34732474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/rQYOxsTECX",
      "expanded_url" : "http:\/\/igg.me\/p\/1301159\/twtr\/4833000",
      "display_url" : "igg.me\/p\/1301159\/twtr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638397241581961216",
  "text" : "Help make it happen for ProseMirror on @indiegogo http:\/\/t.co\/rQYOxsTECX",
  "id" : 638397241581961216,
  "created_at" : "2015-08-31 17:05:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gillian Shaw",
      "screen_name" : "gillianshaw",
      "indices" : [ 3, 15 ],
      "id_str" : "12003622",
      "id" : 12003622
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/gillianshaw\/status\/638030481368309760\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/TNS1Twp2zc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNq9Vq6U8AAyH1x.jpg",
      "id_str" : "638030477220179968",
      "id" : 638030477220179968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNq9Vq6U8AAyH1x.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TNS1Twp2zc"
    } ],
    "hashtags" : [ {
      "text" : "BCstorm",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638087923385044992",
  "text" : "RT @gillianshaw: Starbucks as a power station in #BCstorm http:\/\/t.co\/TNS1Twp2zc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/gillianshaw\/status\/638030481368309760\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/TNS1Twp2zc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNq9Vq6U8AAyH1x.jpg",
        "id_str" : "638030477220179968",
        "id" : 638030477220179968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNq9Vq6U8AAyH1x.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TNS1Twp2zc"
      } ],
      "hashtags" : [ {
        "text" : "BCstorm",
        "indices" : [ 32, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638030481368309760",
    "text" : "Starbucks as a power station in #BCstorm http:\/\/t.co\/TNS1Twp2zc",
    "id" : 638030481368309760,
    "created_at" : "2015-08-30 16:48:15 +0000",
    "user" : {
      "name" : "Gillian Shaw",
      "screen_name" : "gillianshaw",
      "protected" : false,
      "id_str" : "12003622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000176477394\/ff7e85daa9ae9518cd32be037bad52c7_normal.jpeg",
      "id" : 12003622,
      "verified" : true
    }
  },
  "id" : 638087923385044992,
  "created_at" : "2015-08-30 20:36:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637331800193282048",
  "text" : "A few HCI principles (aka laws) to go with those earlier UI design principles:\n\u2705Miller's Law\n\u2705Hick's Law\n\u2705Power Law of Practice\n\u2705Fitts' Law",
  "id" : 637331800193282048,
  "created_at" : "2015-08-28 18:31:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637324285875372032",
  "text" : "Core UI design principles:\n\u2705Consistency \n\u2705Engagement\n\u2705Aesthetic integrity\n\u2705Memory-load reduction \n\u2705Forgiveness \n\u2705Task suitability\n\u2705Guidance",
  "id" : 637324285875372032,
  "created_at" : "2015-08-28 18:02:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Skaliks",
      "screen_name" : "Steph_Skaliks",
      "indices" : [ 3, 17 ],
      "id_str" : "1483797253",
      "id" : 1483797253
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Steph_Skaliks\/status\/636268558184378368\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/vrRRdS9TvZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNR64e1UEAAi6_R.png",
      "id_str" : "636268558134022144",
      "id" : 636268558134022144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNR64e1UEAAi6_R.png",
      "sizes" : [ {
        "h" : 44,
        "resize" : "fit",
        "w" : 210
      }, {
        "h" : 44,
        "resize" : "fit",
        "w" : 210
      }, {
        "h" : 44,
        "resize" : "crop",
        "w" : 44
      }, {
        "h" : 44,
        "resize" : "fit",
        "w" : 210
      }, {
        "h" : 44,
        "resize" : "fit",
        "w" : 210
      } ],
      "display_url" : "pic.twitter.com\/vrRRdS9TvZ"
    } ],
    "hashtags" : [ {
      "text" : "CapitalOneDesign",
      "indices" : [ 86, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/7j5gw2S7h4",
      "expanded_url" : "http:\/\/AdaptivePath.org",
      "display_url" : "AdaptivePath.org"
    }, {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/xO5YPG0fMn",
      "expanded_url" : "http:\/\/bit.ly\/1JX9eXu",
      "display_url" : "bit.ly\/1JX9eXu"
    } ]
  },
  "geo" : { },
  "id_str" : "636665821570273281",
  "text" : "RT @Steph_Skaliks: Introducing http:\/\/t.co\/7j5gw2S7h4 - Where design meets community. #CapitalOneDesign http:\/\/t.co\/xO5YPG0fMn http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dynamicsignal.com\/\" rel=\"nofollow\"\u003EVoiceStorm\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Steph_Skaliks\/status\/636268558184378368\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/vrRRdS9TvZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNR64e1UEAAi6_R.png",
        "id_str" : "636268558134022144",
        "id" : 636268558134022144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNR64e1UEAAi6_R.png",
        "sizes" : [ {
          "h" : 44,
          "resize" : "fit",
          "w" : 210
        }, {
          "h" : 44,
          "resize" : "fit",
          "w" : 210
        }, {
          "h" : 44,
          "resize" : "crop",
          "w" : 44
        }, {
          "h" : 44,
          "resize" : "fit",
          "w" : 210
        }, {
          "h" : 44,
          "resize" : "fit",
          "w" : 210
        } ],
        "display_url" : "pic.twitter.com\/vrRRdS9TvZ"
      } ],
      "hashtags" : [ {
        "text" : "CapitalOneDesign",
        "indices" : [ 67, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/7j5gw2S7h4",
        "expanded_url" : "http:\/\/AdaptivePath.org",
        "display_url" : "AdaptivePath.org"
      }, {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/xO5YPG0fMn",
        "expanded_url" : "http:\/\/bit.ly\/1JX9eXu",
        "display_url" : "bit.ly\/1JX9eXu"
      } ]
    },
    "geo" : { },
    "id_str" : "636268558184378368",
    "text" : "Introducing http:\/\/t.co\/7j5gw2S7h4 - Where design meets community. #CapitalOneDesign http:\/\/t.co\/xO5YPG0fMn http:\/\/t.co\/vrRRdS9TvZ",
    "id" : 636268558184378368,
    "created_at" : "2015-08-25 20:07:00 +0000",
    "user" : {
      "name" : "Stephanie Skaliks",
      "screen_name" : "Steph_Skaliks",
      "protected" : false,
      "id_str" : "1483797253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636566114101764096\/-p4xeAdO_normal.jpg",
      "id" : 1483797253,
      "verified" : false
    }
  },
  "id" : 636665821570273281,
  "created_at" : "2015-08-26 22:25:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giansimon Diblas",
      "screen_name" : "giansi72",
      "indices" : [ 0, 9 ],
      "id_str" : "3230477368",
      "id" : 3230477368
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 10, 18 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "BobRockefeller",
      "screen_name" : "BobRockefeller",
      "indices" : [ 93, 108 ],
      "id_str" : "1875751",
      "id" : 1875751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636393321879994370",
  "geo" : { },
  "id_str" : "636555715235024896",
  "in_reply_to_user_id" : 3230477368,
  "text" : "@giansi72 @getgrav Thanks very much! Could not have done it without the Materialize theme by @BobRockefeller.",
  "id" : 636555715235024896,
  "in_reply_to_status_id" : 636393321879994370,
  "created_at" : "2015-08-26 15:08:03 +0000",
  "in_reply_to_screen_name" : "giansi72",
  "in_reply_to_user_id_str" : "3230477368",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "indices" : [ 3, 18 ],
      "id_str" : "12915742",
      "id" : 12915742
    }, {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 111, 119 ],
      "id_str" : "7693002",
      "id" : 7693002
    }, {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 120, 134 ],
      "id_str" : "10451462",
      "id" : 10451462
    }, {
      "name" : "Phil Denman",
      "screen_name" : "PhilSDSU",
      "indices" : [ 135, 140 ],
      "id_str" : "1906858195",
      "id" : 1906858195
    }, {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 139, 140 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/iSM6B3eOKQ",
      "expanded_url" : "http:\/\/buff.ly\/1NSCOuX",
      "display_url" : "buff.ly\/1NSCOuX"
    } ]
  },
  "geo" : { },
  "id_str" : "636314765141258241",
  "text" : "RT @whitneykilgore: SXSW Vote NOW!  LX Design: Because learning design requires UX http:\/\/t.co\/iSM6B3eOKQ with @jlknott @catspyjamasnz @Phi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jessica Knott",
        "screen_name" : "jlknott",
        "indices" : [ 91, 99 ],
        "id_str" : "7693002",
        "id" : 7693002
      }, {
        "name" : "Joyce Seitzinger",
        "screen_name" : "catspyjamasnz",
        "indices" : [ 100, 114 ],
        "id_str" : "10451462",
        "id" : 10451462
      }, {
        "name" : "Phil Denman",
        "screen_name" : "PhilSDSU",
        "indices" : [ 115, 124 ],
        "id_str" : "1906858195",
        "id" : 1906858195
      }, {
        "name" : "Myra T Travin",
        "screen_name" : "m_travin",
        "indices" : [ 129, 138 ],
        "id_str" : "837060721",
        "id" : 837060721
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/iSM6B3eOKQ",
        "expanded_url" : "http:\/\/buff.ly\/1NSCOuX",
        "display_url" : "buff.ly\/1NSCOuX"
      } ]
    },
    "geo" : { },
    "id_str" : "636303339190362112",
    "text" : "SXSW Vote NOW!  LX Design: Because learning design requires UX http:\/\/t.co\/iSM6B3eOKQ with @jlknott @catspyjamasnz @PhilSDSU and @m_travin",
    "id" : 636303339190362112,
    "created_at" : "2015-08-25 22:25:12 +0000",
    "user" : {
      "name" : "Whitney Kilgore",
      "screen_name" : "whitneykilgore",
      "protected" : false,
      "id_str" : "12915742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000153832375\/76631b48ed9d27ecbabd70d95dd77a73_normal.jpeg",
      "id" : 12915742,
      "verified" : false
    }
  },
  "id" : 636314765141258241,
  "created_at" : "2015-08-25 23:10:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A List Apart",
      "screen_name" : "alistapart",
      "indices" : [ 58, 69 ],
      "id_str" : "18776131",
      "id" : 18776131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/1iSkMXFjIv",
      "expanded_url" : "http:\/\/alistapart.com\/article\/language-of-modular-design",
      "display_url" : "alistapart.com\/article\/langua\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636277328457265152",
  "text" : "The Language of Modular Design http:\/\/t.co\/1iSkMXFjIv via @alistapart",
  "id" : 636277328457265152,
  "created_at" : "2015-08-25 20:41:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BoingBoing\/status\/636236969874472960\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/P6B9Zb7S3Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNReJzMWEAAOPec.jpg",
      "id_str" : "636236969819901952",
      "id" : 636236969819901952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNReJzMWEAAOPec.jpg",
      "sizes" : [ {
        "h" : 429,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/P6B9Zb7S3Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/wFfGtaseLl",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/08\/25\/hypertext-word-ted-nelson.html",
      "display_url" : "boingboing.net\/2015\/08\/25\/hyp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636242817648427008",
  "text" : "RT @BoingBoing: The 50th anniversary of the word 'hypertext.' We forgot to get you a card. Sorry. http:\/\/t.co\/wFfGtaseLl http:\/\/t.co\/P6B9Zb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BoingBoing\/status\/636236969874472960\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/P6B9Zb7S3Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNReJzMWEAAOPec.jpg",
        "id_str" : "636236969819901952",
        "id" : 636236969819901952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNReJzMWEAAOPec.jpg",
        "sizes" : [ {
          "h" : 429,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/P6B9Zb7S3Z"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/wFfGtaseLl",
        "expanded_url" : "http:\/\/boingboing.net\/2015\/08\/25\/hypertext-word-ted-nelson.html",
        "display_url" : "boingboing.net\/2015\/08\/25\/hyp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "636236969874472960",
    "text" : "The 50th anniversary of the word 'hypertext.' We forgot to get you a card. Sorry. http:\/\/t.co\/wFfGtaseLl http:\/\/t.co\/P6B9Zb7S3Z",
    "id" : 636236969874472960,
    "created_at" : "2015-08-25 18:01:28 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616924998226153472\/0EfZYjr2_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 636242817648427008,
  "created_at" : "2015-08-25 18:24:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 22, 30 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 98, 107 ],
      "id_str" : "180743261",
      "id" : 180743261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636230420086984705",
  "text" : "CMS workflow nirvana? @getgrav (flat-file CMS)  \u27A8 GitHub (version control &amp; collab editing) \u27A8 @deployhq (auto server deployments) \u27A8 Web host",
  "id" : 636230420086984705,
  "created_at" : "2015-08-25 17:35:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636218672164409344",
  "text" : "Thanks to clients, colleagues, teachers and students over the past 25 years. Let's keep working together to make our world better by design.",
  "id" : 636218672164409344,
  "created_at" : "2015-08-25 16:48:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636206645396156416",
  "text" : "Looks like this year marks my 25th of designing and creating software, which all started @ MacWorld Toronto in 1990 w. Exploring Multimedia.",
  "id" : 636206645396156416,
  "created_at" : "2015-08-25 16:00:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Mar\u10E7\u0308n Haverbeke",
      "screen_name" : "marijnjh",
      "indices" : [ 77, 86 ],
      "id_str" : "47585779",
      "id" : 47585779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProseMirror",
      "indices" : [ 61, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/iGc15dV4Bi",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/prosemirror\/",
      "display_url" : "indiegogo.com\/projects\/prose\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636193835668770816",
  "text" : "RT @getgrav: Hey people, let's all pull together and support #ProseMirror by @marijnjh. This would be an awesome fit for Grav! https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mar\u10E7\u0308n Haverbeke",
        "screen_name" : "marijnjh",
        "indices" : [ 64, 73 ],
        "id_str" : "47585779",
        "id" : 47585779
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ProseMirror",
        "indices" : [ 48, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/iGc15dV4Bi",
        "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/prosemirror\/",
        "display_url" : "indiegogo.com\/projects\/prose\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "636182283364401154",
    "text" : "Hey people, let's all pull together and support #ProseMirror by @marijnjh. This would be an awesome fit for Grav! https:\/\/t.co\/iGc15dV4Bi",
    "id" : 636182283364401154,
    "created_at" : "2015-08-25 14:24:10 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 636193835668770816,
  "created_at" : "2015-08-25 15:10:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Bovis",
      "screen_name" : "PaulBovis",
      "indices" : [ 0, 10 ],
      "id_str" : "1004346642",
      "id" : 1004346642
    }, {
      "name" : "Simon Fraser Univ.",
      "screen_name" : "SFU",
      "indices" : [ 11, 15 ],
      "id_str" : "8071702",
      "id" : 8071702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636001014773063681",
  "geo" : { },
  "id_str" : "636002136552116224",
  "in_reply_to_user_id" : 1004346642,
  "text" : "@PaulBovis @SFU Yes, but it was being part of a conference audience with them all around me that made me change my mind about the issue.",
  "id" : 636002136552116224,
  "in_reply_to_status_id" : 636001014773063681,
  "created_at" : "2015-08-25 02:28:20 +0000",
  "in_reply_to_screen_name" : "PaulBovis",
  "in_reply_to_user_id_str" : "1004346642",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Haw",
      "screen_name" : "andrewhawr",
      "indices" : [ 0, 11 ],
      "id_str" : "742214790",
      "id" : 742214790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635976469164879873",
  "geo" : { },
  "id_str" : "635987660431978500",
  "in_reply_to_user_id" : 742214790,
  "text" : "@andrewhawr Thanks, I might hold that option in my \"back pocket\" for possible use \uD83D\uDE00",
  "id" : 635987660431978500,
  "in_reply_to_status_id" : 635976469164879873,
  "created_at" : "2015-08-25 01:30:48 +0000",
  "in_reply_to_screen_name" : "andrewhawr",
  "in_reply_to_user_id_str" : "742214790",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Haw",
      "screen_name" : "andrewhawr",
      "indices" : [ 0, 11 ],
      "id_str" : "742214790",
      "id" : 742214790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635948537369374721",
  "geo" : { },
  "id_str" : "635970829944164352",
  "in_reply_to_user_id" : 742214790,
  "text" : "@andrewhawr Hey Andrew, thanks for sharing your experiences. Would you recommend the back row exception?",
  "id" : 635970829944164352,
  "in_reply_to_status_id" : 635948537369374721,
  "created_at" : "2015-08-25 00:23:56 +0000",
  "in_reply_to_screen_name" : "andrewhawr",
  "in_reply_to_user_id_str" : "742214790",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/3XuMT6RwqB",
      "expanded_url" : "http:\/\/getgrav.org\/blog\/grav-0.9.38-and-admin-0.4.0",
      "display_url" : "getgrav.org\/blog\/grav-0.9.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635935728602509312",
  "text" : "RT @getgrav: Grav and Admin plugin updated to 0.9.38 and 0.4.0 respectively.  Admin Multi-language + many fixes and improvements! http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/3XuMT6RwqB",
        "expanded_url" : "http:\/\/getgrav.org\/blog\/grav-0.9.38-and-admin-0.4.0",
        "display_url" : "getgrav.org\/blog\/grav-0.9.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "635928059430854656",
    "text" : "Grav and Admin plugin updated to 0.9.38 and 0.4.0 respectively.  Admin Multi-language + many fixes and improvements! http:\/\/t.co\/3XuMT6RwqB",
    "id" : 635928059430854656,
    "created_at" : "2015-08-24 21:33:58 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 635935728602509312,
  "created_at" : "2015-08-24 22:04:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Fraser Univ.",
      "screen_name" : "SFU",
      "indices" : [ 18, 22 ],
      "id_str" : "8071702",
      "id" : 8071702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635926848988250112",
  "text" : "A few experiments @SFU this Fall:\n\u2705 Objectives + Assessments approach\n\u2705 \"Flipped\" LMS\n\u2705 GitHub course companion\n\u2705 Class laptop ban (?)",
  "id" : 635926848988250112,
  "created_at" : "2015-08-24 21:29:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Dickerson",
      "screen_name" : "JosephDickerson",
      "indices" : [ 0, 16 ],
      "id_str" : "14407107",
      "id" : 14407107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635898387154477057",
  "geo" : { },
  "id_str" : "635917185420886016",
  "in_reply_to_user_id" : 14407107,
  "text" : "@JosephDickerson Sorry about that. \uD83D\uDE09",
  "id" : 635917185420886016,
  "in_reply_to_status_id" : 635898387154477057,
  "created_at" : "2015-08-24 20:50:46 +0000",
  "in_reply_to_screen_name" : "JosephDickerson",
  "in_reply_to_user_id_str" : "14407107",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/635861747388157956\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/83riuoUySP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNMI47yUwAEE8Kd.png",
      "id_str" : "635861746603835393",
      "id" : 635861746603835393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNMI47yUwAEE8Kd.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/83riuoUySP"
    } ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 62, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635861747388157956",
  "text" : "Any comments or suggested improvements for this (intro level) #UX course topic structure and design toolkit diagram? http:\/\/t.co\/83riuoUySP",
  "id" : 635861747388157956,
  "created_at" : "2015-08-24 17:10:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Grigsby, \u26014",
      "screen_name" : "grigs",
      "indices" : [ 3, 9 ],
      "id_str" : "5774462",
      "id" : 5774462
    }, {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "indices" : [ 38, 51 ],
      "id_str" : "35943",
      "id" : 35943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/LYoqJwwnDj",
      "expanded_url" : "http:\/\/responsivewebdesign.com\/podcast\/special-episode.html",
      "display_url" : "responsivewebdesign.com\/podcast\/specia\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635858159383347201",
  "text" : "RT @grigs: Oh hey! The secret is out. @karenmcgrane wrote a new book, Going Responsive. I can vouch for it. It is excellent! http:\/\/t.co\/LY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Karen McGrane",
        "screen_name" : "karenmcgrane",
        "indices" : [ 27, 40 ],
        "id_str" : "35943",
        "id" : 35943
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/LYoqJwwnDj",
        "expanded_url" : "http:\/\/responsivewebdesign.com\/podcast\/special-episode.html",
        "display_url" : "responsivewebdesign.com\/podcast\/specia\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "635824867103739904",
    "text" : "Oh hey! The secret is out. @karenmcgrane wrote a new book, Going Responsive. I can vouch for it. It is excellent! http:\/\/t.co\/LYoqJwwnDj",
    "id" : 635824867103739904,
    "created_at" : "2015-08-24 14:43:56 +0000",
    "user" : {
      "name" : "Jason Grigsby, \u26014",
      "screen_name" : "grigs",
      "protected" : false,
      "id_str" : "5774462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694573720606605312\/j_l6cQVS_normal.jpg",
      "id" : 5774462,
      "verified" : false
    }
  },
  "id" : 635858159383347201,
  "created_at" : "2015-08-24 16:56:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/uimLixIvrD",
      "expanded_url" : "http:\/\/www.asktog.com\/columns\/006intuitvsfamiliar.html",
      "display_url" : "asktog.com\/columns\/006int\u2026"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/kmYfmg8bhY",
      "expanded_url" : "https:\/\/twitter.com\/miniver\/status\/635821721501741056",
      "display_url" : "twitter.com\/miniver\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635857457604988928",
  "text" : "I often think of Bruce Tognazzini's commentary on \"intuitive\" whenever this topic comes up http:\/\/t.co\/uimLixIvrD https:\/\/t.co\/kmYfmg8bhY",
  "id" : 635857457604988928,
  "created_at" : "2015-08-24 16:53:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/tqAXQvKSxE",
      "expanded_url" : "https:\/\/twitter.com\/globe_education\/status\/634758754022633473",
      "display_url" : "twitter.com\/globe_educatio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635553768495443968",
  "text" : "To my surprise, I am considering this after attending several conferences this summer awash w. distracting screens. https:\/\/t.co\/tqAXQvKSxE",
  "id" : 635553768495443968,
  "created_at" : "2015-08-23 20:46:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/gEKvceYpZz",
      "expanded_url" : "http:\/\/Lynda.com",
      "display_url" : "Lynda.com"
    } ]
  },
  "geo" : { },
  "id_str" : "635526929513234432",
  "text" : "Hey fellow learners out there on a Sunday afternoon, any comments about the user experience of http:\/\/t.co\/gEKvceYpZz?",
  "id" : 635526929513234432,
  "created_at" : "2015-08-23 19:00:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Denman",
      "screen_name" : "PhilSDSU",
      "indices" : [ 0, 9 ],
      "id_str" : "1906858195",
      "id" : 1906858195
    }, {
      "name" : "theCatchbox",
      "screen_name" : "theCatchbox",
      "indices" : [ 10, 22 ],
      "id_str" : "610660514",
      "id" : 610660514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634506557846364160",
  "geo" : { },
  "id_str" : "634508329105104900",
  "in_reply_to_user_id" : 1906858195,
  "text" : "@PhilSDSU @theCatchbox I think a big lecture hall is an ideal use case, especially to keep the back row students alert ;-) Time will tell!",
  "id" : 634508329105104900,
  "in_reply_to_status_id" : 634506557846364160,
  "created_at" : "2015-08-20 23:32:28 +0000",
  "in_reply_to_screen_name" : "PhilSDSU",
  "in_reply_to_user_id_str" : "1906858195",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Denman",
      "screen_name" : "PhilSDSU",
      "indices" : [ 0, 9 ],
      "id_str" : "1906858195",
      "id" : 1906858195
    }, {
      "name" : "theCatchbox",
      "screen_name" : "theCatchbox",
      "indices" : [ 10, 22 ],
      "id_str" : "610660514",
      "id" : 610660514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634502972081352708",
  "geo" : { },
  "id_str" : "634504044053184512",
  "in_reply_to_user_id" : 1906858195,
  "text" : "@PhilSDSU @theCatchbox Noted Phil :-) I will be trying it out first with a class of 80 students in a lecture hall &amp; will share experiences.",
  "id" : 634504044053184512,
  "in_reply_to_status_id" : 634502972081352708,
  "created_at" : "2015-08-20 23:15:27 +0000",
  "in_reply_to_screen_name" : "PhilSDSU",
  "in_reply_to_user_id_str" : "1906858195",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theCatchbox",
      "screen_name" : "theCatchbox",
      "indices" : [ 39, 51 ],
      "id_str" : "610660514",
      "id" : 610660514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634479223126646784",
  "text" : "Getting pretty jazzed about trying out @theCatchbox this Fall! A great example of learner experience = UX + educational design + technology.",
  "id" : 634479223126646784,
  "created_at" : "2015-08-20 21:36:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634067453874716672",
  "text" : "(2\/2) By doing so students will not need to create any new accounts and after the course ends they have their OWN copy of our discussions.",
  "id" : 634067453874716672,
  "created_at" : "2015-08-19 18:20:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sameroom HQ",
      "screen_name" : "sameroomhq",
      "indices" : [ 20, 31 ],
      "id_str" : "3016611945",
      "id" : 3016611945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634067404897841152",
  "text" : "(1\/2) Thanks to the @sameroomhq team I will be offering students 1-on-1 coaching\/mentoring in CMPT 363 using their EXISTING chat clients.",
  "id" : 634067404897841152,
  "created_at" : "2015-08-19 18:20:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/633695959155773440\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/w5sVZ1L9Uv",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CMtXHeHWIAEkR1z.png",
      "id_str" : "633695958430261249",
      "id" : 633695958430261249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CMtXHeHWIAEkR1z.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/w5sVZ1L9Uv"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 40, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633695959155773440",
  "text" : "Third iteration of a design process for #SFU CMPT 363, to serve as a UX course topic structure and a design toolkit. http:\/\/t.co\/w5sVZ1L9Uv",
  "id" : 633695959155773440,
  "created_at" : "2015-08-18 17:44:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633411134209462272",
  "geo" : { },
  "id_str" : "633414578685149184",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc Thanks for the feedback Christina!",
  "id" : 633414578685149184,
  "in_reply_to_status_id" : 633411134209462272,
  "created_at" : "2015-08-17 23:06:18 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    }, {
      "name" : "Rachel Carden",
      "screen_name" : "bamadesigner",
      "indices" : [ 7, 20 ],
      "id_str" : "236673464",
      "id" : 236673464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/yUy0x7CPqR",
      "expanded_url" : "http:\/\/support.cms.ubc.ca\/cms-manual\/getting-started\/requesting-a-site\/",
      "display_url" : "support.cms.ubc.ca\/cms-manual\/get\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "633411153012629504",
  "geo" : { },
  "id_str" : "633413211358781440",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 @bamadesigner For example, lots of EDU folks would be really interested in UBC's awesome WP setup approach http:\/\/t.co\/yUy0x7CPqR",
  "id" : 633413211358781440,
  "in_reply_to_status_id" : 633411153012629504,
  "created_at" : "2015-08-17 23:00:52 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    }, {
      "name" : "Rachel Carden",
      "screen_name" : "bamadesigner",
      "indices" : [ 7, 20 ],
      "id_str" : "236673464",
      "id" : 236673464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633411153012629504",
  "geo" : { },
  "id_str" : "633412339832766464",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 @bamadesigner Definitely agree! Getting domain-specific further unifies design and technical conversations.",
  "id" : 633412339832766464,
  "in_reply_to_status_id" : 633411153012629504,
  "created_at" : "2015-08-17 22:57:24 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/aoPTILcQlk",
      "expanded_url" : "https:\/\/wordpressinhigheredconference.wordpress.com",
      "display_url" : "\u2026essinhigheredconference.wordpress.com"
    } ]
  },
  "in_reply_to_status_id_str" : "633408779682508801",
  "geo" : { },
  "id_str" : "633410569366716416",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 You might also be interested in this past conference, but it was online only https:\/\/t.co\/aoPTILcQlk",
  "id" : 633410569366716416,
  "in_reply_to_status_id" : 633408779682508801,
  "created_at" : "2015-08-17 22:50:22 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhan Patel",
      "screen_name" : "Farhanpatel",
      "indices" : [ 0, 12 ],
      "id_str" : "18129659",
      "id" : 18129659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633389537700413440",
  "geo" : { },
  "id_str" : "633391514811428865",
  "in_reply_to_user_id" : 18129659,
  "text" : "@Farhanpatel BTW, any thoughts about a re-design of GitHub for a broader audience (i.e. non-CS students) as a CMPT 363 term project? Thanks!",
  "id" : 633391514811428865,
  "in_reply_to_status_id" : 633389537700413440,
  "created_at" : "2015-08-17 21:34:39 +0000",
  "in_reply_to_screen_name" : "Farhanpatel",
  "in_reply_to_user_id_str" : "18129659",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhan Patel",
      "screen_name" : "Farhanpatel",
      "indices" : [ 0, 12 ],
      "id_str" : "18129659",
      "id" : 18129659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633389537700413440",
  "geo" : { },
  "id_str" : "633391061033984000",
  "in_reply_to_user_id" : 18129659,
  "text" : "@Farhanpatel With a backend Flat-file CMS the possibility for students to contribute both to content &amp; code are pretty exciting to consider.",
  "id" : 633391061033984000,
  "in_reply_to_status_id" : 633389537700413440,
  "created_at" : "2015-08-17 21:32:51 +0000",
  "in_reply_to_screen_name" : "Farhanpatel",
  "in_reply_to_user_id_str" : "18129659",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhan Patel",
      "screen_name" : "Farhanpatel",
      "indices" : [ 0, 12 ],
      "id_str" : "18129659",
      "id" : 18129659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633389537700413440",
  "geo" : { },
  "id_str" : "633390836995112961",
  "in_reply_to_user_id" : 18129659,
  "text" : "@Farhanpatel Hey Farhan nice to hear from you! Thanks for sharing your thoughts &amp; experience. Agree for CS students - a perfect fit I think.",
  "id" : 633390836995112961,
  "in_reply_to_status_id" : 633389537700413440,
  "created_at" : "2015-08-17 21:31:58 +0000",
  "in_reply_to_screen_name" : "Farhanpatel",
  "in_reply_to_user_id_str" : "18129659",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633386299269885953",
  "text" : "Dear Twitterverse! Quick poll: Is GitHub is a reasonable tool for any university student to learn the basics of? Y\/N and comments?",
  "id" : 633386299269885953,
  "created_at" : "2015-08-17 21:13:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633341496595353600",
  "geo" : { },
  "id_str" : "633385757399384064",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc This discussion makes me think a redesign of GitHub for a wider audience might make a good student project in my UX course?",
  "id" : 633385757399384064,
  "in_reply_to_status_id" : 633341496595353600,
  "created_at" : "2015-08-17 21:11:46 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "slides",
      "indices" : [ 0, 7 ],
      "id_str" : "813740730",
      "id" : 813740730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Ru08uba2HJ",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/home\/week-01",
      "display_url" : "cmpt-363-153.hibbittsdesign.com\/home\/week-01"
    } ]
  },
  "in_reply_to_status_id_str" : "633338526856146944",
  "geo" : { },
  "id_str" : "633344372205989888",
  "in_reply_to_user_id" : 813740730,
  "text" : "@slides Thanks again for your help! For unknown reasons renaming the deck to slides-in-progress and everything works \uD83D\uDE00http:\/\/t.co\/Ru08uba2HJ",
  "id" : 633344372205989888,
  "in_reply_to_status_id" : 633338526856146944,
  "created_at" : "2015-08-17 18:27:19 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "slides",
      "indices" : [ 0, 7 ],
      "id_str" : "813740730",
      "id" : 813740730
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/633340817504014336\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/mLNm0C1ttN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMoUHfDVEAQNOrk.png",
      "id_str" : "633340816426078212",
      "id" : 633340816426078212,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMoUHfDVEAQNOrk.png",
      "sizes" : [ {
        "h" : 49,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 28,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 81,
        "resize" : "fit",
        "w" : 984
      }, {
        "h" : 81,
        "resize" : "crop",
        "w" : 81
      }, {
        "h" : 81,
        "resize" : "fit",
        "w" : 984
      } ],
      "display_url" : "pic.twitter.com\/mLNm0C1ttN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633338526856146944",
  "geo" : { },
  "id_str" : "633340817504014336",
  "in_reply_to_user_id" : 813740730,
  "text" : "@slides Thanks! Odd as source file has it (see photo) but the rendered HTML does not! I will need to dig deeper. http:\/\/t.co\/mLNm0C1ttN",
  "id" : 633340817504014336,
  "in_reply_to_status_id" : 633338526856146944,
  "created_at" : "2015-08-17 18:13:12 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "slides",
      "indices" : [ 0, 7 ],
      "id_str" : "813740730",
      "id" : 813740730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Ru08uba2HJ",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/home\/week-01",
      "display_url" : "cmpt-363-153.hibbittsdesign.com\/home\/week-01"
    } ]
  },
  "in_reply_to_status_id_str" : "633329007531048960",
  "geo" : { },
  "id_str" : "633332307189874688",
  "in_reply_to_user_id" : 813740730,
  "text" : "@slides I must be missing something but I just can't get it to display. Here's a page with the deck in question first http:\/\/t.co\/Ru08uba2HJ",
  "id" : 633332307189874688,
  "in_reply_to_status_id" : 633329007531048960,
  "created_at" : "2015-08-17 17:39:23 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/633327747515809793\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/xaWu2sd1z3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMoIOiaUEAA0iDy.png",
      "id_str" : "633327743447339008",
      "id" : 633327743447339008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMoIOiaUEAA0iDy.png",
      "sizes" : [ {
        "h" : 465,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 793,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 880,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xaWu2sd1z3"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/633327747515809793\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/xaWu2sd1z3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMoIOZzUYAA8Bxj.png",
      "id_str" : "633327741136297984",
      "id" : 633327741136297984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMoIOZzUYAA8Bxj.png",
      "sizes" : [ {
        "h" : 465,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 880,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 793,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xaWu2sd1z3"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/633327747515809793\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/xaWu2sd1z3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMoIOs0U8AEo0Q_.png",
      "id_str" : "633327746240802817",
      "id" : 633327746240802817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMoIOs0U8AEo0Q_.png",
      "sizes" : [ {
        "h" : 465,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 880,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 793,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xaWu2sd1z3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633327747515809793",
  "text" : "Experimenting now with 1-click editing link provided within inline README file - balance of context and efficiency? http:\/\/t.co\/xaWu2sd1z3",
  "id" : 633327747515809793,
  "created_at" : "2015-08-17 17:21:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Hendricks",
      "screen_name" : "clhendricksbc",
      "indices" : [ 0, 14 ],
      "id_str" : "260919324",
      "id" : 260919324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/jpZRijE0Dn",
      "expanded_url" : "https:\/\/github.com\/paulhibbitts\/cmpt-363-153-website\/tree\/master\/user\/pages\/04.resources",
      "display_url" : "github.com\/paulhibbitts\/c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "633324322782773248",
  "geo" : { },
  "id_str" : "633325729162264576",
  "in_reply_to_user_id" : 260919324,
  "text" : "@clhendricksbc I've got it easy with Comp Sci students \uD83D\uDE00 With GitHub account 1-click editing going (via README)! https:\/\/t.co\/jpZRijE0Dn",
  "id" : 633325729162264576,
  "in_reply_to_status_id" : 633324322782773248,
  "created_at" : "2015-08-17 17:13:15 +0000",
  "in_reply_to_screen_name" : "clhendricksbc",
  "in_reply_to_user_id_str" : "260919324",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/633318032194928640\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/0D330WX0Eh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMn_ZH_UAAAsIlL.png",
      "id_str" : "633318029728677888",
      "id" : 633318029728677888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMn_ZH_UAAAsIlL.png",
      "sizes" : [ {
        "h" : 465,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 793,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 880,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0D330WX0Eh"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/633318032194928640\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/0D330WX0Eh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMn_YuvUsAA3-5n.png",
      "id_str" : "633318022950727680",
      "id" : 633318022950727680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMn_YuvUsAA3-5n.png",
      "sizes" : [ {
        "h" : 465,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 880,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 793,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0D330WX0Eh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633318032194928640",
  "text" : "Trying to lower the barrier for students to edit CMPT 363 course companion: direct GitHub edit links + inline ReadMe. http:\/\/t.co\/0D330WX0Eh",
  "id" : 633318032194928640,
  "created_at" : "2015-08-17 16:42:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/PnEKx6NtjR",
      "expanded_url" : "https:\/\/twitter.com\/scottjenson\/status\/632941302930280449",
      "display_url" : "twitter.com\/scottjenson\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633288314590621696",
  "text" : "Amen! https:\/\/t.co\/PnEKx6NtjR",
  "id" : 633288314590621696,
  "created_at" : "2015-08-17 14:44:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "indices" : [ 3, 11 ],
      "id_str" : "783092",
      "id" : 783092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EdTech",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/Alp8T90GOU",
      "expanded_url" : "http:\/\/werd.io\/2015\/what-would-it-take-to-save-edtech",
      "display_url" : "werd.io\/2015\/what-woul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633074478331748352",
  "text" : "RT @benwerd: What would it take to save #EdTech? http:\/\/t.co\/Alp8T90GOU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/werd.io\/\" rel=\"nofollow\"\u003Ewerd.io\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EdTech",
        "indices" : [ 27, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/Alp8T90GOU",
        "expanded_url" : "http:\/\/werd.io\/2015\/what-would-it-take-to-save-edtech",
        "display_url" : "werd.io\/2015\/what-woul\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633047822577696768",
    "text" : "What would it take to save #EdTech? http:\/\/t.co\/Alp8T90GOU",
    "id" : 633047822577696768,
    "created_at" : "2015-08-16 22:48:57 +0000",
    "user" : {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "protected" : false,
      "id_str" : "783092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681986174966104064\/t3BubQKk_normal.jpg",
      "id" : 783092,
      "verified" : true
    }
  },
  "id" : 633074478331748352,
  "created_at" : "2015-08-17 00:34:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633063713558294530",
  "geo" : { },
  "id_str" : "633073040889282560",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde Always good to be off the grid for a while \u263A Hope you and your family had a nice vacation!",
  "id" : 633073040889282560,
  "in_reply_to_status_id" : 633063713558294530,
  "created_at" : "2015-08-17 00:29:09 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slides",
      "screen_name" : "slides",
      "indices" : [ 0, 7 ],
      "id_str" : "813740730",
      "id" : 813740730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/bgxRiz1V99",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/cmpt-363-153-slides-placeholder#\/",
      "display_url" : "slides.com\/paulhibbitts\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633013533655994368",
  "in_reply_to_user_id" : 813740730,
  "text" : "@slides I can't seem to get the embed code for this slide deck to display, any ideas? http:\/\/t.co\/bgxRiz1V99 All others ok. Thank you!",
  "id" : 633013533655994368,
  "created_at" : "2015-08-16 20:32:41 +0000",
  "in_reply_to_screen_name" : "slides",
  "in_reply_to_user_id_str" : "813740730",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632334785227059201",
  "text" : "A learning environment that can be actively shaped by learners within that environment, who would have thunk! Can any LMS do that now?",
  "id" : 632334785227059201,
  "created_at" : "2015-08-14 23:35:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632332532134993920",
  "text" : "Core attributes for a shared learning environment so far:\n\u2705Open platform\n\u2705Collaborative\n\u2705Version-controlled content PLUS code\n\u2705Multi-device",
  "id" : 632332532134993920,
  "created_at" : "2015-08-14 23:26:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632331367599046656",
  "text" : "It's getting pretty clear to me that GitHub can serve as a foundation for co-learners to collaboratively build shared learning environments.",
  "id" : 632331367599046656,
  "created_at" : "2015-08-14 23:22:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Margaret-Anne Storey",
      "screen_name" : "margaretstorey",
      "indices" : [ 0, 15 ],
      "id_str" : "61127825",
      "id" : 61127825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632306739610648576",
  "in_reply_to_user_id" : 61127825,
  "text" : "@margaretstorey In my case with Comp Sci students at SFU, I see possibilities in terms of collaborative content and even code development.",
  "id" : 632306739610648576,
  "created_at" : "2015-08-14 21:44:09 +0000",
  "in_reply_to_screen_name" : "margaretstorey",
  "in_reply_to_user_id_str" : "61127825",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Margaret-Anne Storey",
      "screen_name" : "margaretstorey",
      "indices" : [ 0, 15 ],
      "id_str" : "61127825",
      "id" : 61127825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632306345031561216",
  "in_reply_to_user_id" : 61127825,
  "text" : "@margaretstorey Any current plans for further studies involving the student perspective?",
  "id" : 632306345031561216,
  "created_at" : "2015-08-14 21:42:34 +0000",
  "in_reply_to_screen_name" : "margaretstorey",
  "in_reply_to_user_id_str" : "61127825",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Margaret-Anne Storey",
      "screen_name" : "margaretstorey",
      "indices" : [ 0, 15 ],
      "id_str" : "61127825",
      "id" : 61127825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5Ezf5aFzpr",
      "expanded_url" : "https:\/\/github.com\/paulhibbitts\/cmpt-363-153-website",
      "display_url" : "github.com\/paulhibbitts\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632306140890554369",
  "in_reply_to_user_id" : 61127825,
  "text" : "@margaretstorey Enjoyed your paper about GitHub in Education! I will be using GitHub with my Fall CMPT course at SFU https:\/\/t.co\/5Ezf5aFzpr",
  "id" : 632306140890554369,
  "created_at" : "2015-08-14 21:41:46 +0000",
  "in_reply_to_screen_name" : "margaretstorey",
  "in_reply_to_user_id_str" : "61127825",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Klein",
      "screen_name" : "lauraklein",
      "indices" : [ 0, 11 ],
      "id_str" : "14804195",
      "id" : 14804195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "632275054269587457",
  "geo" : { },
  "id_str" : "632275934167482368",
  "in_reply_to_user_id" : 14804195,
  "text" : "@lauraklein That's a really nice scaffolding technique!",
  "id" : 632275934167482368,
  "in_reply_to_status_id" : 632275054269587457,
  "created_at" : "2015-08-14 19:41:44 +0000",
  "in_reply_to_screen_name" : "lauraklein",
  "in_reply_to_user_id_str" : "14804195",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632269440516685824",
  "text" : "A dynamic flat-file CMS and GitHub are really an awesome combination - the ability to collaboratively edit not just code but actual content.",
  "id" : 632269440516685824,
  "created_at" : "2015-08-14 19:15:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJK",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/6wHRJnXvoU",
      "expanded_url" : "http:\/\/www.solutionsiq.com\/what-is-an-empathy-map\/",
      "display_url" : "solutionsiq.com\/what-is-an-emp\u2026"
    }, {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/FoKg6kCq40",
      "expanded_url" : "http:\/\/www.tadpull.com\/usability-tools\/how-to-use-empathy-map-for-user-experience-mapping",
      "display_url" : "tadpull.com\/usability-tool\u2026"
    }, {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/uWbPd37Qx8",
      "expanded_url" : "http:\/\/www.innovationlabs.org.uk\/2014\/04\/25\/empathy-maps\/",
      "display_url" : "innovationlabs.org.uk\/2014\/04\/25\/emp\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "632260939291709440",
  "geo" : { },
  "id_str" : "632262645026959360",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim My pleasure! Here are three of my favorites: http:\/\/t.co\/6wHRJnXvoU http:\/\/t.co\/FoKg6kCq40 http:\/\/t.co\/uWbPd37Qx8",
  "id" : 632262645026959360,
  "in_reply_to_status_id" : 632260939291709440,
  "created_at" : "2015-08-14 18:48:56 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 93, 109 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/ad2mdSKvJa",
      "expanded_url" : "http:\/\/wp.me\/p2ypj1-oM",
      "display_url" : "wp.me\/p2ypj1-oM"
    } ]
  },
  "geo" : { },
  "id_str" : "632253140381732865",
  "text" : "The Emergence of GitHub as a Collaborative Platform for Education http:\/\/t.co\/ad2mdSKvJa via @wordpressdotcom",
  "id" : 632253140381732865,
  "created_at" : "2015-08-14 18:11:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/rSYNPOFy5M",
      "expanded_url" : "https:\/\/twitter.com\/amyjokim\/status\/632221634288599041",
      "display_url" : "twitter.com\/amyjokim\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632245261142638593",
  "text" : "I've found job stories combined with empathy maps a very effective approach too. https:\/\/t.co\/rSYNPOFy5M",
  "id" : 632245261142638593,
  "created_at" : "2015-08-14 17:39:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 65, 78 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETUG",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632007447314493448",
  "text" : "A big HT to the folks at the #ETUG 2013 Spring Workshop and esp. @clintlalonde who inspired me with the OER Movement - changed me forever.",
  "id" : 632007447314493448,
  "created_at" : "2015-08-14 01:54:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 89, 97 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 35, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5Ezf5aFzpr",
      "expanded_url" : "https:\/\/github.com\/paulhibbitts\/cmpt-363-153-website",
      "display_url" : "github.com\/paulhibbitts\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632002955412004865",
  "text" : "And now, the other shoe drops. The #SFU CMPT 363 course companion, built with love using @getgrav, is now on GitHub. https:\/\/t.co\/5Ezf5aFzpr",
  "id" : 632002955412004865,
  "created_at" : "2015-08-14 01:37:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 126, 134 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 13, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/V4gRb8kA5t",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "631989155287793664",
  "text" : "The site for #SFU CMPT 363 is now live at http:\/\/t.co\/V4gRb8kA5t Open platform, multi-device, and modular content courtesy of @getgrav CMS.",
  "id" : 631989155287793664,
  "created_at" : "2015-08-14 00:42:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 0, 7 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 8, 15 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631984054787661824",
  "geo" : { },
  "id_str" : "631986239932002304",
  "in_reply_to_user_id" : 745903,
  "text" : "@brlamb @tanbob This time around I am trying to create a better experience for both web-savvy instructors (call me selfish \uD83D\uDE09) and students.",
  "id" : 631986239932002304,
  "in_reply_to_status_id" : 631984054787661824,
  "created_at" : "2015-08-14 00:30:35 +0000",
  "in_reply_to_screen_name" : "brlamb",
  "in_reply_to_user_id_str" : "745903",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 0, 7 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 8, 15 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631982998297051136",
  "geo" : { },
  "id_str" : "631983654953062401",
  "in_reply_to_user_id" : 745903,
  "text" : "@brlamb @tanbob Working on a simple flipped-LMS approach this term for my course at SFU, awaiting to see how the student experience goes...",
  "id" : 631983654953062401,
  "in_reply_to_status_id" : 631982998297051136,
  "created_at" : "2015-08-14 00:20:19 +0000",
  "in_reply_to_screen_name" : "brlamb",
  "in_reply_to_user_id_str" : "745903",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/631982374943719424\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/QgDBEopVSi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMVAnwTUwAAkaZD.png",
      "id_str" : "631982374440452096",
      "id" : 631982374440452096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMVAnwTUwAAkaZD.png",
      "sizes" : [ {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      } ],
      "display_url" : "pic.twitter.com\/QgDBEopVSi"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/631982374943719424\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/QgDBEopVSi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMVAnueUcAAlUBk.png",
      "id_str" : "631982373949698048",
      "id" : 631982373949698048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMVAnueUcAAlUBk.png",
      "sizes" : [ {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 432
      } ],
      "display_url" : "pic.twitter.com\/QgDBEopVSi"
    } ],
    "hashtags" : [ {
      "text" : "LMS",
      "indices" : [ 100, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631982374943719424",
  "text" : "A reverse mullet seems to be happening... party (multi-device modular CMS ) in the front, business (#LMS) in the back http:\/\/t.co\/QgDBEopVSi",
  "id" : 631982374943719424,
  "created_at" : "2015-08-14 00:15:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "indices" : [ 3, 8 ],
      "id_str" : "12534",
      "id" : 12534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/BGitmApNmg",
      "expanded_url" : "http:\/\/republicofquality.com\/lessons-from-a-code-of-conduct\/",
      "display_url" : "republicofquality.com\/lessons-from-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631942889812029440",
  "text" : "RT @beep: \u201CCodes of conduct definitely aren\u2019t perfect or The Answer, but they\u2019re the start of a conversation that matters.\u201D \u2014 http:\/\/t.co\/B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/BGitmApNmg",
        "expanded_url" : "http:\/\/republicofquality.com\/lessons-from-a-code-of-conduct\/",
        "display_url" : "republicofquality.com\/lessons-from-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631914818249826304",
    "text" : "\u201CCodes of conduct definitely aren\u2019t perfect or The Answer, but they\u2019re the start of a conversation that matters.\u201D \u2014 http:\/\/t.co\/BGitmApNmg",
    "id" : 631914818249826304,
    "created_at" : "2015-08-13 19:46:47 +0000",
    "user" : {
      "name" : "Ethan Marcotte",
      "screen_name" : "beep",
      "protected" : false,
      "id_str" : "12534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653657521559896065\/VWzlUwPL_normal.png",
      "id" : 12534,
      "verified" : false
    }
  },
  "id" : 631942889812029440,
  "created_at" : "2015-08-13 21:38:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/631894853790494720\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/h2ymlyv9oM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMTxBUrUcAAu6Fc.jpg",
      "id_str" : "631894852771278848",
      "id" : 631894852771278848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMTxBUrUcAAu6Fc.jpg",
      "sizes" : [ {
        "h" : 287,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/h2ymlyv9oM"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/631894853790494720\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/h2ymlyv9oM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMTxBS5U8AAZ1HK.png",
      "id_str" : "631894852293160960",
      "id" : 631894852293160960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMTxBS5U8AAZ1HK.png",
      "sizes" : [ {
        "h" : 239,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 426
      } ],
      "display_url" : "pic.twitter.com\/h2ymlyv9oM"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 83, 87 ]
    }, {
      "text" : "UX",
      "indices" : [ 88, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631894853790494720",
  "text" : "Almost giddy with excitement including these 2 diagrams for discussion in my first #SFU #UX design class this Fall. http:\/\/t.co\/h2ymlyv9oM",
  "id" : 631894853790494720,
  "created_at" : "2015-08-13 18:27:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/631870973168349186\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/BFPhIJfzGp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMTbTQZUwAAZwj0.png",
      "id_str" : "631870971603894272",
      "id" : 631870971603894272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMTbTQZUwAAZwj0.png",
      "sizes" : [ {
        "h" : 497,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 497,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 497,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/BFPhIJfzGp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631870973168349186",
  "text" : "Second iteration of a UX design process - to serve as a UX course topic structure and a design toolkit guide. http:\/\/t.co\/BFPhIJfzGp",
  "id" : 631870973168349186,
  "created_at" : "2015-08-13 16:52:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "indices" : [ 3, 11 ],
      "id_str" : "15022225",
      "id" : 15022225
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Apple",
      "indices" : [ 13, 19 ]
    }, {
      "text" : "design",
      "indices" : [ 89, 96 ]
    }, {
      "text" : "UX",
      "indices" : [ 120, 123 ]
    }, {
      "text" : "usability",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/96UAYe7E92",
      "expanded_url" : "http:\/\/j.mp\/1EnmjBz",
      "display_url" : "j.mp\/1EnmjBz"
    } ]
  },
  "geo" : { },
  "id_str" : "631536075924635648",
  "text" : "RT @NNgroup: #Apple products are getting harder to use because they ignore principles of #design http:\/\/t.co\/96UAYe7E92 #UX #usability",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Apple",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "design",
        "indices" : [ 76, 83 ]
      }, {
        "text" : "UX",
        "indices" : [ 107, 110 ]
      }, {
        "text" : "usability",
        "indices" : [ 111, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/96UAYe7E92",
        "expanded_url" : "http:\/\/j.mp\/1EnmjBz",
        "display_url" : "j.mp\/1EnmjBz"
      } ]
    },
    "geo" : { },
    "id_str" : "631517928823767040",
    "text" : "#Apple products are getting harder to use because they ignore principles of #design http:\/\/t.co\/96UAYe7E92 #UX #usability",
    "id" : 631517928823767040,
    "created_at" : "2015-08-12 17:29:41 +0000",
    "user" : {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "protected" : false,
      "id_str" : "15022225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467725885949227008\/JTT0mnp4_normal.png",
      "id" : 15022225,
      "verified" : false
    }
  },
  "id" : 631536075924635648,
  "created_at" : "2015-08-12 18:41:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631521541893718016",
  "text" : "There are many ways to look at learner experience design as a teacher, including this one: it's a way to show your students that you care.",
  "id" : 631521541893718016,
  "created_at" : "2015-08-12 17:44:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/mbgghk0ewD",
      "expanded_url" : "http:\/\/getgrav.org\/blog\/grav-0.9.36-and-admin-0.3.0",
      "display_url" : "getgrav.org\/blog\/grav-0.9.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631284244338192384",
  "text" : "RT @getgrav: Grav v0.9.36 and Admin plugin v0.3.0 release with several new features and improvements.  Check it out! http:\/\/t.co\/mbgghk0ewD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/mbgghk0ewD",
        "expanded_url" : "http:\/\/getgrav.org\/blog\/grav-0.9.36-and-admin-0.3.0",
        "display_url" : "getgrav.org\/blog\/grav-0.9.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631281995922837504",
    "text" : "Grav v0.9.36 and Admin plugin v0.3.0 release with several new features and improvements.  Check it out! http:\/\/t.co\/mbgghk0ewD",
    "id" : 631281995922837504,
    "created_at" : "2015-08-12 01:52:11 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 631284244338192384,
  "created_at" : "2015-08-12 02:01:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "indices" : [ 3, 17 ],
      "id_str" : "10451462",
      "id" : 10451462
    }, {
      "name" : "Phil Denman",
      "screen_name" : "PhilSDSU",
      "indices" : [ 107, 116 ],
      "id_str" : "1906858195",
      "id" : 1906858195
    }, {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 117, 126 ],
      "id_str" : "837060721",
      "id" : 837060721
    }, {
      "name" : "Jessica Knott",
      "screen_name" : "jlknott",
      "indices" : [ 139, 140 ],
      "id_str" : "7693002",
      "id" : 7693002
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sxswedu",
      "indices" : [ 30, 38 ]
    }, {
      "text" : "lxdesign",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631256779146432512",
  "text" : "RT @catspyjamasnz: Aaaand our #sxswedu panel on #lxdesign is ready for voting. So excited to collaborate w @PhilSDSU @m_travin and the love\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Phil Denman",
        "screen_name" : "PhilSDSU",
        "indices" : [ 88, 97 ],
        "id_str" : "1906858195",
        "id" : 1906858195
      }, {
        "name" : "Myra T Travin",
        "screen_name" : "m_travin",
        "indices" : [ 98, 107 ],
        "id_str" : "837060721",
        "id" : 837060721
      }, {
        "name" : "Jessica Knott",
        "screen_name" : "jlknott",
        "indices" : [ 123, 131 ],
        "id_str" : "7693002",
        "id" : 7693002
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sxswedu",
        "indices" : [ 11, 19 ]
      }, {
        "text" : "lxdesign",
        "indices" : [ 29, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630723975451009024",
    "text" : "Aaaand our #sxswedu panel on #lxdesign is ready for voting. So excited to collaborate w @PhilSDSU @m_travin and the lovely @jlknott :-)",
    "id" : 630723975451009024,
    "created_at" : "2015-08-10 12:54:48 +0000",
    "user" : {
      "name" : "Joyce Seitzinger",
      "screen_name" : "catspyjamasnz",
      "protected" : false,
      "id_str" : "10451462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690397421499736064\/j-HGgre5_normal.jpg",
      "id" : 10451462,
      "verified" : false
    }
  },
  "id" : 631256779146432512,
  "created_at" : "2015-08-12 00:11:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631226626827616260",
  "text" : "Looks like to achieve goal my of a 100% modular structure for my CMPT 363 course companion I will have 0% of content in the LMS backend. \u2705",
  "id" : 631226626827616260,
  "created_at" : "2015-08-11 22:12:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/2Bkq9k87TY",
      "expanded_url" : "https:\/\/twitter.com\/theCatchbox\/status\/629594389828997120",
      "display_url" : "twitter.com\/theCatchbox\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630821526514741248",
  "text" : "This is a phenomenal way to enhance the participant experience in workshops and classes - planning to try one soon. https:\/\/t.co\/2Bkq9k87TY",
  "id" : 630821526514741248,
  "created_at" : "2015-08-10 19:22:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/630755643956162560\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/sA4IBD3Asf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMDk6nJUAAEfxaI.png",
      "id_str" : "630755643423457281",
      "id" : 630755643423457281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMDk6nJUAAEfxaI.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/sA4IBD3Asf"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 72, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630755643956162560",
  "text" : "Early morning sneak peek at a diagram intended to be a visual guide for #SFU CMPT 363 (UI Design) course topics. http:\/\/t.co\/sA4IBD3Asf",
  "id" : 630755643956162560,
  "created_at" : "2015-08-10 15:00:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 3, 19 ],
      "id_str" : "17462723",
      "id" : 17462723
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 54, 66 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/LwN1UDp1Qh",
      "expanded_url" : "https:\/\/www.kickstarter.com\/projects\/creativecommons\/made-with-creative-commons-a-book-on-open-business",
      "display_url" : "kickstarter.com\/projects\/creat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630081661720522756",
  "text" : "RT @creativecommons: OMG only $1000 to go to meet our @kickstarter goal. Help us get started on this book about open business models! https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kickstarter",
        "screen_name" : "kickstarter",
        "indices" : [ 33, 45 ],
        "id_str" : "16186995",
        "id" : 16186995
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/LwN1UDp1Qh",
        "expanded_url" : "https:\/\/www.kickstarter.com\/projects\/creativecommons\/made-with-creative-commons-a-book-on-open-business",
        "display_url" : "kickstarter.com\/projects\/creat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "630081210031587328",
    "text" : "OMG only $1000 to go to meet our @kickstarter goal. Help us get started on this book about open business models! https:\/\/t.co\/LwN1UDp1Qh",
    "id" : 630081210031587328,
    "created_at" : "2015-08-08 18:20:41 +0000",
    "user" : {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "protected" : false,
      "id_str" : "17462723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525970164341153792\/vbReKnbf_normal.png",
      "id" : 17462723,
      "verified" : true
    }
  },
  "id" : 630081661720522756,
  "created_at" : "2015-08-08 18:22:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Design & Content",
      "screen_name" : "dcontentconf",
      "indices" : [ 9, 22 ],
      "id_str" : "2912534023",
      "id" : 2912534023
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dcc15",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629808541222604800",
  "text" : "No doubt @dcontentconf hit the ball out of the park! Kudos to organizers, presenters, volunteers and everyone else involved. #dcc15",
  "id" : 629808541222604800,
  "created_at" : "2015-08-08 00:17:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krispian",
      "screen_name" : "krispian",
      "indices" : [ 3, 12 ],
      "id_str" : "7105802",
      "id" : 7105802
    }, {
      "name" : "Jared Spool",
      "screen_name" : "jmspool",
      "indices" : [ 77, 85 ],
      "id_str" : "849101",
      "id" : 849101
    }, {
      "name" : "Design & Content",
      "screen_name" : "dcontentconf",
      "indices" : [ 86, 99 ],
      "id_str" : "2912534023",
      "id" : 2912534023
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dcc15",
      "indices" : [ 70, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629796205090856960",
  "text" : "RT @krispian: A useful metric for UX: Count error message deliveries! #dcc15 @jmspool @dcontentconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jared Spool",
        "screen_name" : "jmspool",
        "indices" : [ 63, 71 ],
        "id_str" : "849101",
        "id" : 849101
      }, {
        "name" : "Design & Content",
        "screen_name" : "dcontentconf",
        "indices" : [ 72, 85 ],
        "id_str" : "2912534023",
        "id" : 2912534023
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dcc15",
        "indices" : [ 56, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629795897862430721",
    "text" : "A useful metric for UX: Count error message deliveries! #dcc15 @jmspool @dcontentconf",
    "id" : 629795897862430721,
    "created_at" : "2015-08-07 23:26:57 +0000",
    "user" : {
      "name" : "krispian",
      "screen_name" : "krispian",
      "protected" : false,
      "id_str" : "7105802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653308135700979712\/1IL36ZCF_normal.jpg",
      "id" : 7105802,
      "verified" : false
    }
  },
  "id" : 629796205090856960,
  "created_at" : "2015-08-07 23:28:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward McIntyre",
      "screen_name" : "twittem",
      "indices" : [ 3, 11 ],
      "id_str" : "15908477",
      "id" : 15908477
    }, {
      "name" : "Jared Spool",
      "screen_name" : "jmspool",
      "indices" : [ 60, 68 ],
      "id_str" : "849101",
      "id" : 849101
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dcc15",
      "indices" : [ 115, 121 ]
    }, {
      "text" : "analytics",
      "indices" : [ 122, 132 ]
    }, {
      "text" : "webdev",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629793769584328704",
  "text" : "RT @twittem: \"10-point scales make noise feel like science\" @jmspool on satisfaction surveys &amp; useless metrics #dcc15 #analytics #webdev",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jared Spool",
        "screen_name" : "jmspool",
        "indices" : [ 47, 55 ],
        "id_str" : "849101",
        "id" : 849101
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dcc15",
        "indices" : [ 102, 108 ]
      }, {
        "text" : "analytics",
        "indices" : [ 109, 119 ]
      }, {
        "text" : "webdev",
        "indices" : [ 120, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629793622397878272",
    "text" : "\"10-point scales make noise feel like science\" @jmspool on satisfaction surveys &amp; useless metrics #dcc15 #analytics #webdev",
    "id" : 629793622397878272,
    "created_at" : "2015-08-07 23:17:55 +0000",
    "user" : {
      "name" : "Edward McIntyre",
      "screen_name" : "twittem",
      "protected" : false,
      "id_str" : "15908477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714548105555943424\/djgj7tpn_normal.jpg",
      "id" : 15908477,
      "verified" : false
    }
  },
  "id" : 629793769584328704,
  "created_at" : "2015-08-07 23:18:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Jeff Eaton)))",
      "screen_name" : "eaton",
      "indices" : [ 3, 9 ],
      "id_str" : "2582861",
      "id" : 2582861
    }, {
      "name" : "Jared Spool",
      "screen_name" : "jmspool",
      "indices" : [ 89, 97 ],
      "id_str" : "849101",
      "id" : 849101
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/eaton\/status\/629790032212045824\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/zgmFLXnBt4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL12slfVEAAuO_C.jpg",
      "id_str" : "629790031251574784",
      "id" : 629790031251574784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL12slfVEAAuO_C.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 2448
      } ],
      "display_url" : "pic.twitter.com\/zgmFLXnBt4"
    } ],
    "hashtags" : [ {
      "text" : "dcc15",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629790241038032897",
  "text" : "RT @eaton: \u201CGoogle analytics can\u2019t tell you \u2018why.\u2019 You have to TALK to people for that.\u201D @jmspool #dcc15 http:\/\/t.co\/zgmFLXnBt4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jared Spool",
        "screen_name" : "jmspool",
        "indices" : [ 78, 86 ],
        "id_str" : "849101",
        "id" : 849101
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/eaton\/status\/629790032212045824\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/zgmFLXnBt4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL12slfVEAAuO_C.jpg",
        "id_str" : "629790031251574784",
        "id" : 629790031251574784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL12slfVEAAuO_C.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 2448
        } ],
        "display_url" : "pic.twitter.com\/zgmFLXnBt4"
      } ],
      "hashtags" : [ {
        "text" : "dcc15",
        "indices" : [ 87, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629790032212045824",
    "text" : "\u201CGoogle analytics can\u2019t tell you \u2018why.\u2019 You have to TALK to people for that.\u201D @jmspool #dcc15 http:\/\/t.co\/zgmFLXnBt4",
    "id" : 629790032212045824,
    "created_at" : "2015-08-07 23:03:39 +0000",
    "user" : {
      "name" : "(((Jeff Eaton)))",
      "screen_name" : "eaton",
      "protected" : false,
      "id_str" : "2582861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755858721373233153\/R1jV5uS6_normal.jpg",
      "id" : 2582861,
      "verified" : false
    }
  },
  "id" : 629790241038032897,
  "created_at" : "2015-08-07 23:04:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/629747629635735552\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/D81HH23QI5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL1QIWkVAAA9aJZ.jpg",
      "id_str" : "629747627328864256",
      "id" : 629747627328864256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL1QIWkVAAA9aJZ.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/D81HH23QI5"
    } ],
    "hashtags" : [ {
      "text" : "dcc15",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629747629635735552",
  "text" : "What's inside a culture of openness? #dcc15 http:\/\/t.co\/D81HH23QI5",
  "id" : 629747629635735552,
  "created_at" : "2015-08-07 20:15:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/629714972130410496\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/jWiPaPzMWc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL0ybbaUEAAQiH9.jpg",
      "id_str" : "629714969697718272",
      "id" : 629714969697718272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL0ybbaUEAAQiH9.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jWiPaPzMWc"
    } ],
    "hashtags" : [ {
      "text" : "dcc15",
      "indices" : [ 6, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629714972130410496",
  "text" : "This. #dcc15 http:\/\/t.co\/jWiPaPzMWc",
  "id" : 629714972130410496,
  "created_at" : "2015-08-07 18:05:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Armstrong",
      "screen_name" : "JoeArmstrongC4s",
      "indices" : [ 3, 19 ],
      "id_str" : "15044271",
      "id" : 15044271
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "governmentasaplatform",
      "indices" : [ 104, 126 ]
    }, {
      "text" : "dcc15",
      "indices" : [ 127, 133 ]
    }, {
      "text" : "cmvan",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629703066489503744",
  "text" : "RT @JoeArmstrongC4s: The UK Government is doing some great work around digital service design and using #governmentasaplatform #dcc15 #cmvan",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "governmentasaplatform",
        "indices" : [ 83, 105 ]
      }, {
        "text" : "dcc15",
        "indices" : [ 106, 112 ]
      }, {
        "text" : "cmvan",
        "indices" : [ 113, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629700192917295104",
    "text" : "The UK Government is doing some great work around digital service design and using #governmentasaplatform #dcc15 #cmvan",
    "id" : 629700192917295104,
    "created_at" : "2015-08-07 17:06:39 +0000",
    "user" : {
      "name" : "Joe Armstrong",
      "screen_name" : "JoeArmstrongC4s",
      "protected" : false,
      "id_str" : "15044271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488773912025505793\/McenrAYJ_normal.jpeg",
      "id" : 15044271,
      "verified" : false
    }
  },
  "id" : 629703066489503744,
  "created_at" : "2015-08-07 17:18:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ritchielee",
      "screen_name" : "ritchielee",
      "indices" : [ 3, 14 ],
      "id_str" : "14302580",
      "id" : 14302580
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dcc15",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629440578883682304",
  "text" : "RT @ritchielee: Tailoring the experience to the context of the user or device does not pay off nearly as much as simply laying down respons\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dcc15",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629439936991768576",
    "text" : "Tailoring the experience to the context of the user or device does not pay off nearly as much as simply laying down responsive design #dcc15",
    "id" : 629439936991768576,
    "created_at" : "2015-08-06 23:52:30 +0000",
    "user" : {
      "name" : "ritchielee",
      "screen_name" : "ritchielee",
      "protected" : false,
      "id_str" : "14302580",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549354134843826176\/s3gWs5Hh_normal.jpeg",
      "id" : 14302580,
      "verified" : false
    }
  },
  "id" : 629440578883682304,
  "created_at" : "2015-08-06 23:55:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaina Rozen",
      "screen_name" : "shainarozen",
      "indices" : [ 3, 15 ],
      "id_str" : "205990344",
      "id" : 205990344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dcc15",
      "indices" : [ 27, 33 ]
    }, {
      "text" : "preach",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629438723713675264",
  "text" : "RT @shainarozen: Themes of #dcc15 day 1: Trying to guess what users want is problematic. #preach",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dcc15",
        "indices" : [ 10, 16 ]
      }, {
        "text" : "preach",
        "indices" : [ 72, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629438458071638017",
    "text" : "Themes of #dcc15 day 1: Trying to guess what users want is problematic. #preach",
    "id" : 629438458071638017,
    "created_at" : "2015-08-06 23:46:37 +0000",
    "user" : {
      "name" : "Shaina Rozen",
      "screen_name" : "shainarozen",
      "protected" : false,
      "id_str" : "205990344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593888891653853184\/-ltSQRnz_normal.jpg",
      "id" : 205990344,
      "verified" : false
    }
  },
  "id" : 629438723713675264,
  "created_at" : "2015-08-06 23:47:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/629427816187039745\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/HhR2NQivaj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLwtQX_UcAAsYXU.jpg",
      "id_str" : "629427807265779712",
      "id" : 629427807265779712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLwtQX_UcAAsYXU.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HhR2NQivaj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629427816187039745",
  "text" : "There is no mobile Web, there is one Web. http:\/\/t.co\/HhR2NQivaj",
  "id" : 629427816187039745,
  "created_at" : "2015-08-06 23:04:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/629412925006942209\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/Xy8xcQ5E0G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLwft6vUAAASBcc.jpg",
      "id_str" : "629412921647300608",
      "id" : 629412921647300608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLwft6vUAAASBcc.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Xy8xcQ5E0G"
    } ],
    "hashtags" : [ {
      "text" : "dcc15",
      "indices" : [ 8, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629412925006942209",
  "text" : "Preach. #dcc15 http:\/\/t.co\/Xy8xcQ5E0G",
  "id" : 629412925006942209,
  "created_at" : "2015-08-06 22:05:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Stewart",
      "screen_name" : "jdewstewart",
      "indices" : [ 3, 15 ],
      "id_str" : "217714329",
      "id" : 217714329
    }, {
      "name" : "SaraWachterBoettcher",
      "screen_name" : "sara_ann_marie",
      "indices" : [ 103, 118 ],
      "id_str" : "14424551",
      "id" : 14424551
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dcc15",
      "indices" : [ 119, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629391024696135681",
  "text" : "RT @jdewstewart: \"Kindness is letting users define themselves. Make space for real people to exist.\" - @sara_ann_marie #dcc15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SaraWachterBoettcher",
        "screen_name" : "sara_ann_marie",
        "indices" : [ 86, 101 ],
        "id_str" : "14424551",
        "id" : 14424551
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dcc15",
        "indices" : [ 102, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629354548482703361",
    "text" : "\"Kindness is letting users define themselves. Make space for real people to exist.\" - @sara_ann_marie #dcc15",
    "id" : 629354548482703361,
    "created_at" : "2015-08-06 18:13:11 +0000",
    "user" : {
      "name" : "Jessica Stewart",
      "screen_name" : "jdewstewart",
      "protected" : false,
      "id_str" : "217714329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570448178248314880\/pH-1kwbt_normal.jpeg",
      "id" : 217714329,
      "verified" : false
    }
  },
  "id" : 629391024696135681,
  "created_at" : "2015-08-06 20:38:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 0, 15 ],
      "id_str" : "1122631",
      "id" : 1122631
    }, {
      "name" : "Design & Content",
      "screen_name" : "dcontentconf",
      "indices" : [ 16, 29 ],
      "id_str" : "2912534023",
      "id" : 2912534023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629160897265532929",
  "geo" : { },
  "id_str" : "629297998887956481",
  "in_reply_to_user_id" : 1122631,
  "text" : "@MalloryOConnor @dcontentconf You bet, hope to connect then. Cheers!",
  "id" : 629297998887956481,
  "in_reply_to_status_id" : 629160897265532929,
  "created_at" : "2015-08-06 14:28:29 +0000",
  "in_reply_to_screen_name" : "MalloryOConnor",
  "in_reply_to_user_id_str" : "1122631",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 0, 15 ],
      "id_str" : "1122631",
      "id" : 1122631
    }, {
      "name" : "Design & Content",
      "screen_name" : "dcontentconf",
      "indices" : [ 39, 52 ],
      "id_str" : "2912534023",
      "id" : 2912534023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629109572561604608",
  "in_reply_to_user_id" : 1122631,
  "text" : "@MalloryOConnor Best of luck with your @dcontentconf talk tomorrow, I know you'll do an awesome job!",
  "id" : 629109572561604608,
  "created_at" : "2015-08-06 01:59:45 +0000",
  "in_reply_to_screen_name" : "MalloryOConnor",
  "in_reply_to_user_id_str" : "1122631",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Russell",
      "screen_name" : "slightlylate",
      "indices" : [ 3, 16 ],
      "id_str" : "229237555",
      "id" : 229237555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/dMr35nlNVE",
      "expanded_url" : "http:\/\/opensignal.com\/reports\/2015\/08\/android-fragmentation\/",
      "display_url" : "opensignal.com\/reports\/2015\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629101894988730368",
  "text" : "RT @slightlylate: Hot mobile tip: the only way your app will reach all of these devices is the web: http:\/\/t.co\/dMr35nlNVE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/dMr35nlNVE",
        "expanded_url" : "http:\/\/opensignal.com\/reports\/2015\/08\/android-fragmentation\/",
        "display_url" : "opensignal.com\/reports\/2015\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629031065265410052",
    "text" : "Hot mobile tip: the only way your app will reach all of these devices is the web: http:\/\/t.co\/dMr35nlNVE",
    "id" : 629031065265410052,
    "created_at" : "2015-08-05 20:47:47 +0000",
    "user" : {
      "name" : "Alex Russell",
      "screen_name" : "slightlylate",
      "protected" : false,
      "id_str" : "229237555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636772791153377281\/zM8_BoWJ_normal.jpg",
      "id" : 229237555,
      "verified" : false
    }
  },
  "id" : 629101894988730368,
  "created_at" : "2015-08-06 01:29:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Kelly",
      "screen_name" : "brandonkelly",
      "indices" : [ 0, 13 ],
      "id_str" : "7600892",
      "id" : 7600892
    }, {
      "name" : "Craft CMS",
      "screen_name" : "CraftCMS",
      "indices" : [ 14, 23 ],
      "id_str" : "236658433",
      "id" : 236658433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629081825575440384",
  "in_reply_to_user_id" : 7600892,
  "text" : "@brandonkelly @craftcms Awesome, looking forward to it!",
  "id" : 629081825575440384,
  "created_at" : "2015-08-06 00:09:29 +0000",
  "in_reply_to_screen_name" : "brandonkelly",
  "in_reply_to_user_id_str" : "7600892",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 82, 91 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/629079657774616577\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/gANewYLbLd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLrwnVxUMAQ5JGb.png",
      "id_str" : "629079656621158404",
      "id" : 629079656621158404,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLrwnVxUMAQ5JGb.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 523
      } ],
      "display_url" : "pic.twitter.com\/gANewYLbLd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629079657774616577",
  "text" : "Learner experience design is not about roles, but design disciplines. Which ones? @m_travin and I would say these 3: http:\/\/t.co\/gANewYLbLd",
  "id" : 629079657774616577,
  "created_at" : "2015-08-06 00:00:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 44, 52 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 80, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/V4gRb8kA5t",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "629076044734009344",
  "text" : "Want to see an example of the flat-file CMS @getgrav at work? Explore my latest #SFU multi-device course companion at http:\/\/t.co\/V4gRb8kA5t",
  "id" : 629076044734009344,
  "created_at" : "2015-08-05 23:46:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Design & Content",
      "screen_name" : "dcontentconf",
      "indices" : [ 26, 39 ],
      "id_str" : "2912534023",
      "id" : 2912534023
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 125, 133 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dcc15",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629066682342846464",
  "text" : "Really looking forward to @dcontentconf tomorrow! Hope to chat about learner experience design and my favorite flat-file CMS @getgrav #dcc15",
  "id" : 629066682342846464,
  "created_at" : "2015-08-05 23:09:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629059040295792640",
  "text" : "At the same time, my goal is to make the term project for CMPT 363 something that students can show during employment interviews. Thoughts?",
  "id" : 629059040295792640,
  "created_at" : "2015-08-05 22:38:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629057465359794176",
  "text" : "Exploring the term project for CMPT 363 with a driving question format. Example: how can we improve a student's digital learning experience?",
  "id" : 629057465359794176,
  "created_at" : "2015-08-05 22:32:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valdis Krebs",
      "screen_name" : "ValdisKrebs",
      "indices" : [ 3, 15 ],
      "id_str" : "15415778",
      "id" : 15415778
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialmedia",
      "indices" : [ 67, 79 ]
    }, {
      "text" : "elsuahackstwitter",
      "indices" : [ 102, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629047904733282305",
  "text" : "RT @ValdisKrebs: For those interested in the future of Twitter and #socialmedia metrics, follow this: #elsuahackstwitter \nLots of interesti\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "socialmedia",
        "indices" : [ 50, 62 ]
      }, {
        "text" : "elsuahackstwitter",
        "indices" : [ 85, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628643541699313664",
    "text" : "For those interested in the future of Twitter and #socialmedia metrics, follow this: #elsuahackstwitter \nLots of interesting convo!",
    "id" : 628643541699313664,
    "created_at" : "2015-08-04 19:07:54 +0000",
    "user" : {
      "name" : "Valdis Krebs",
      "screen_name" : "ValdisKrebs",
      "protected" : false,
      "id_str" : "15415778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2649151529\/63ac662124a401838a48dc91798de71e_normal.png",
      "id" : 15415778,
      "verified" : false
    }
  },
  "id" : 629047904733282305,
  "created_at" : "2015-08-05 21:54:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 32, 40 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/MEo2OLSePI",
      "expanded_url" : "https:\/\/bitnami.com\/stack\/grav",
      "display_url" : "bitnami.com\/stack\/grav"
    } ]
  },
  "geo" : { },
  "id_str" : "629040007731265536",
  "text" : "I just voted for Grav! Help get @getgrav packaged by Bitnami. You can vote at https:\/\/t.co\/MEo2OLSePI",
  "id" : 629040007731265536,
  "created_at" : "2015-08-05 21:23:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629015280845369344",
  "text" : "It's true - when unmoderated usability test results start streaming in does feel like Christmas morning (to my inner nerd at least).",
  "id" : 629015280845369344,
  "created_at" : "2015-08-05 19:45:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/LoyBQQo0dX",
      "expanded_url" : "https:\/\/twitter.com\/getgrav\/status\/628719141621370880",
      "display_url" : "twitter.com\/getgrav\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628723897446195200",
  "text" : "Awesome to see! https:\/\/t.co\/LoyBQQo0dX",
  "id" : 628723897446195200,
  "created_at" : "2015-08-05 00:27:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628680874687512577",
  "text" : "Heaven help me, but I'm creating a simple design process map to help orientate CMPT 363 students, leaning towards IxD vs. UX - Twitterverse?",
  "id" : 628680874687512577,
  "created_at" : "2015-08-04 21:36:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/7VMKlOQ8I5",
      "expanded_url" : "http:\/\/www.kickerstudio.com\/2008\/12\/the-disciplines-of-user-experience\/",
      "display_url" : "kickerstudio.com\/2008\/12\/the-di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628673448009560064",
  "text" : "Working on CMPT 363, and this diagram highlights the vagueness of the job title \"UX Designer\" http:\/\/t.co\/7VMKlOQ8I5 but yet here we are.",
  "id" : 628673448009560064,
  "created_at" : "2015-08-04 21:06:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LX Design",
      "screen_name" : "lxdesignco",
      "indices" : [ 3, 14 ],
      "id_str" : "3223579116",
      "id" : 3223579116
    }, {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 55, 64 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lxdesign",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/cmSyv9T3bi",
      "expanded_url" : "http:\/\/www.lxdesign.co\/2015\/08\/lx-perspectives-a-hot-new-marriage-by-myra-travin\/",
      "display_url" : "lxdesign.co\/2015\/08\/lx-per\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628664499994624000",
  "text" : "RT @lxdesignco: LX Perspectives: A Hot New Marriage by @m_travin http:\/\/t.co\/cmSyv9T3bi #lxdesign",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Myra T Travin",
        "screen_name" : "m_travin",
        "indices" : [ 39, 48 ],
        "id_str" : "837060721",
        "id" : 837060721
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lxdesign",
        "indices" : [ 72, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/cmSyv9T3bi",
        "expanded_url" : "http:\/\/www.lxdesign.co\/2015\/08\/lx-perspectives-a-hot-new-marriage-by-myra-travin\/",
        "display_url" : "lxdesign.co\/2015\/08\/lx-per\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628499224800415744",
    "text" : "LX Perspectives: A Hot New Marriage by @m_travin http:\/\/t.co\/cmSyv9T3bi #lxdesign",
    "id" : 628499224800415744,
    "created_at" : "2015-08-04 09:34:26 +0000",
    "user" : {
      "name" : "LX Design",
      "screen_name" : "lxdesignco",
      "protected" : false,
      "id_str" : "3223579116",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603167268340543488\/3LvyLoXf_normal.png",
      "id" : 3223579116,
      "verified" : false
    }
  },
  "id" : 628664499994624000,
  "created_at" : "2015-08-04 20:31:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628656297479503872",
  "text" : "The down-side of conducting both within-subjects and between-subjects unmoderated usability tests? # of participants required &amp; test config.",
  "id" : 628656297479503872,
  "created_at" : "2015-08-04 19:58:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628652297157939200",
  "text" : "A series of unmoderated usability tests that includes both within-subjects and between-subjects can provide preference AND performance data.",
  "id" : 628652297157939200,
  "created_at" : "2015-08-04 19:42:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Hooker",
      "screen_name" : "mrhooker",
      "indices" : [ 3, 12 ],
      "id_str" : "9890872",
      "id" : 9890872
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mrhooker\/status\/628313930037919744\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/ZiAAviUMy3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLg4MHhVAAAxKPe.png",
      "id_str" : "628313928846606336",
      "id" : 628313928846606336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLg4MHhVAAAxKPe.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZiAAviUMy3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/g0xvOWgYOX",
      "expanded_url" : "http:\/\/hookedoninnovation.com\/2015\/08\/03\/up-periscope-new-rules-for-the-latest-social-media-tool",
      "display_url" : "hookedoninnovation.com\/2015\/08\/03\/up-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628347023733817344",
  "text" : "RT @mrhooker: Up Periscope? New Rules for the Latest Social Media\u00A0Tool http:\/\/t.co\/g0xvOWgYOX http:\/\/t.co\/ZiAAviUMy3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mrhooker\/status\/628313930037919744\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/ZiAAviUMy3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLg4MHhVAAAxKPe.png",
        "id_str" : "628313928846606336",
        "id" : 628313928846606336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLg4MHhVAAAxKPe.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ZiAAviUMy3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/g0xvOWgYOX",
        "expanded_url" : "http:\/\/hookedoninnovation.com\/2015\/08\/03\/up-periscope-new-rules-for-the-latest-social-media-tool",
        "display_url" : "hookedoninnovation.com\/2015\/08\/03\/up-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628313930037919744",
    "text" : "Up Periscope? New Rules for the Latest Social Media\u00A0Tool http:\/\/t.co\/g0xvOWgYOX http:\/\/t.co\/ZiAAviUMy3",
    "id" : 628313930037919744,
    "created_at" : "2015-08-03 21:18:09 +0000",
    "user" : {
      "name" : "Carl Hooker",
      "screen_name" : "mrhooker",
      "protected" : false,
      "id_str" : "9890872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447019066809532416\/gDSbHbcX_normal.jpeg",
      "id" : 9890872,
      "verified" : false
    }
  },
  "id" : 628347023733817344,
  "created_at" : "2015-08-03 23:29:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Chambers",
      "screen_name" : "WT_Chambers",
      "indices" : [ 3, 15 ],
      "id_str" : "211619016",
      "id" : 211619016
    }, {
      "name" : "Jared Spool",
      "screen_name" : "jmspool",
      "indices" : [ 125, 133 ],
      "id_str" : "849101",
      "id" : 849101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/zTuOkri1GP",
      "expanded_url" : "http:\/\/www.uie.com\/articles\/new_design_leader\/",
      "display_url" : "uie.com\/articles\/new_d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628264882173915136",
  "text" : "RT @WT_Chambers: \"The number one contributor to poor design is an inconsistent understanding of why the project exists.\" via @jmspool http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jared Spool",
        "screen_name" : "jmspool",
        "indices" : [ 108, 116 ],
        "id_str" : "849101",
        "id" : 849101
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/zTuOkri1GP",
        "expanded_url" : "http:\/\/www.uie.com\/articles\/new_design_leader\/",
        "display_url" : "uie.com\/articles\/new_d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628187854028541952",
    "text" : "\"The number one contributor to poor design is an inconsistent understanding of why the project exists.\" via @jmspool http:\/\/t.co\/zTuOkri1GP",
    "id" : 628187854028541952,
    "created_at" : "2015-08-03 12:57:10 +0000",
    "user" : {
      "name" : "Todd Chambers",
      "screen_name" : "WT_Chambers",
      "protected" : false,
      "id_str" : "211619016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2296637490\/j5t9aa491a1fepviqb85_normal.jpeg",
      "id" : 211619016,
      "verified" : false
    }
  },
  "id" : 628264882173915136,
  "created_at" : "2015-08-03 18:03:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Mansbridge",
      "screen_name" : "petermansbridge",
      "indices" : [ 3, 19 ],
      "id_str" : "36490075",
      "id" : 36490075
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/petermansbridge\/status\/628022108736647168\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/Bo94vDrmmE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLcux8PWcAAfRC2.jpg",
      "id_str" : "628022108560453632",
      "id" : 628022108560453632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLcux8PWcAAfRC2.jpg",
      "sizes" : [ {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 1836
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Bo94vDrmmE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628075420097720321",
  "text" : "RT @petermansbridge: This election stuff is all very interesting but do you think I'm in a rush to get back to the cottage? http:\/\/t.co\/Bo9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/petermansbridge\/status\/628022108736647168\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/Bo94vDrmmE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLcux8PWcAAfRC2.jpg",
        "id_str" : "628022108560453632",
        "id" : 628022108560453632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLcux8PWcAAfRC2.jpg",
        "sizes" : [ {
          "h" : 1820,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 1836
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Bo94vDrmmE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628022108736647168",
    "text" : "This election stuff is all very interesting but do you think I'm in a rush to get back to the cottage? http:\/\/t.co\/Bo94vDrmmE",
    "id" : 628022108736647168,
    "created_at" : "2015-08-03 01:58:33 +0000",
    "user" : {
      "name" : "Peter Mansbridge",
      "screen_name" : "petermansbridge",
      "protected" : false,
      "id_str" : "36490075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765543066270916608\/2q2r19sa_normal.jpg",
      "id" : 36490075,
      "verified" : true
    }
  },
  "id" : 628075420097720321,
  "created_at" : "2015-08-03 05:30:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 3, 16 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627485820635627521",
  "text" : "RT @codinghorror: You think email doesn't scale? I agree. It doesn't. But you know what scales exponentially worse? Chat.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627036826981810176",
    "text" : "You think email doesn't scale? I agree. It doesn't. But you know what scales exponentially worse? Chat.",
    "id" : 627036826981810176,
    "created_at" : "2015-07-31 08:43:23 +0000",
    "user" : {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "protected" : false,
      "id_str" : "5637652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632821853627678720\/zPKK7jql_normal.png",
      "id" : 5637652,
      "verified" : true
    }
  },
  "id" : 627485820635627521,
  "created_at" : "2015-08-01 14:27:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]