Grailbird.data.tweets_2009_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThoughtFarmer",
      "screen_name" : "thoughtfarmer",
      "indices" : [ 0, 14 ],
      "id_str" : "13743032",
      "id" : 13743032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1224214970",
  "geo" : { },
  "id_str" : "1224780972",
  "in_reply_to_user_id" : 13743032,
  "text" : "@thoughtfarmer I've been pretty happy with AccuConference + GoToMeeting for quite a while now. Happy to answer any questions you may have.",
  "id" : 1224780972,
  "in_reply_to_status_id" : 1224214970,
  "created_at" : "2009-02-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "thoughtfarmer",
  "in_reply_to_user_id_str" : "13743032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitney Quesenbery",
      "screen_name" : "whitneyq",
      "indices" : [ 11, 20 ],
      "id_str" : "16949684",
      "id" : 16949684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1200073536",
  "text" : "Retweeting @whitneyq: Nice body of knowledge on design research methods throughout a UCD process http:\/\/project.cmd.hro.nl\/cmi\/hci\/toolk ...",
  "id" : 1200073536,
  "created_at" : "2009-02-11 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1197195278",
  "text" : "When is Good http:\/\/tinyurl.com\/brq4pn via www.diigo.com\/~paulhibbitts",
  "id" : 1197195278,
  "created_at" : "2009-02-10 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1184496431",
  "text" : "Most recent design at a distance presentation &lt;http:\/\/www.paulhibbitts.com\/presentations.html&gt; Comments most welcome",
  "id" : 1184496431,
  "created_at" : "2009-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]