Grailbird.data.tweets_2011_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 112 ],
      "url" : "http:\/\/t.co\/4JWuoCS",
      "expanded_url" : "http:\/\/blog.mindjet.com\/2011\/03\/guest-post-using-mindmanager-to-plan-a-website",
      "display_url" : "blog.mindjet.com\/2011\/03\/guest-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "53188714855272449",
  "text" : "One of my favourite methods to create and collaborate on sitemaps \u2013 use a mind mapping tool! http:\/\/t.co\/4JWuoCS",
  "id" : 53188714855272449,
  "created_at" : "2011-03-30 20:15:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baldwin",
      "screen_name" : "benry",
      "indices" : [ 0, 6 ],
      "id_str" : "1969441",
      "id" : 1969441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53143889401495552",
  "geo" : { },
  "id_str" : "53161803127066624",
  "in_reply_to_user_id" : 1969441,
  "text" : "@benry Our conversation this morning was my pleasure - I greatly enjoyed it!",
  "id" : 53161803127066624,
  "in_reply_to_status_id" : 53143889401495552,
  "created_at" : "2011-03-30 18:28:56 +0000",
  "in_reply_to_screen_name" : "benry",
  "in_reply_to_user_id_str" : "1969441",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 128, 131 ]
    }, {
      "text" : "IIBA",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 127 ],
      "url" : "http:\/\/t.co\/px9oL54",
      "expanded_url" : "http:\/\/www.slideshare.net\/hibbittsdesign\/scenariobased-design-techniques-collaboratively-envisioning-the-user-experience-iiba",
      "display_url" : "slideshare.net\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "51289754272153602",
  "text" : "Slides for my Collaborative Scenario-based Design talk at IIBA Vancouver, with new example persona template http:\/\/t.co\/px9oL54 #UX #IIBA",
  "id" : 51289754272153602,
  "created_at" : "2011-03-25 14:30:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malahat hosseini",
      "screen_name" : "miivii",
      "indices" : [ 0, 7 ],
      "id_str" : "20479050",
      "id" : 20479050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "48505873382899712",
  "geo" : { },
  "id_str" : "48538657942011905",
  "in_reply_to_user_id" : 20479050,
  "text" : "@miivii True enough :-) I should try to define \"feels too early\" more specifically sometime...",
  "id" : 48538657942011905,
  "in_reply_to_status_id" : 48505873382899712,
  "created_at" : "2011-03-18 00:18:12 +0000",
  "in_reply_to_screen_name" : "miivii",
  "in_reply_to_user_id_str" : "20479050",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malahat hosseini",
      "screen_name" : "miivii",
      "indices" : [ 0, 7 ],
      "id_str" : "20479050",
      "id" : 20479050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "46675919502442496",
  "geo" : { },
  "id_str" : "48200985935495168",
  "in_reply_to_user_id" : 20479050,
  "text" : "@miivii However, when it's \"too early\" I find there is still plenty to test and more time remaining for design changes + follow-up tests",
  "id" : 48200985935495168,
  "in_reply_to_status_id" : 46675919502442496,
  "created_at" : "2011-03-17 01:56:25 +0000",
  "in_reply_to_screen_name" : "miivii",
  "in_reply_to_user_id_str" : "20479050",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malahat hosseini",
      "screen_name" : "miivii",
      "indices" : [ 0, 7 ],
      "id_str" : "20479050",
      "id" : 20479050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "46675919502442496",
  "geo" : { },
  "id_str" : "48200378390556672",
  "in_reply_to_user_id" : 20479050,
  "text" : "@miivii When everything is \"perfect\" for usability testing I find too much time for resulting design changes has already been used up...",
  "id" : 48200378390556672,
  "in_reply_to_status_id" : 46675919502442496,
  "created_at" : "2011-03-17 01:54:00 +0000",
  "in_reply_to_screen_name" : "miivii",
  "in_reply_to_user_id_str" : "20479050",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45938878175125504",
  "text" : "The time to start usability testing is when you feel it's still too early for usability testing.",
  "id" : 45938878175125504,
  "created_at" : "2011-03-10 20:07:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http:\/\/t.co\/r2UMFLz",
      "expanded_url" : "http:\/\/pttrns.com\/",
      "display_url" : "pttrns.com"
    }, {
      "indices" : [ 69, 88 ],
      "url" : "http:\/\/t.co\/NIJuSr6",
      "expanded_url" : "http:\/\/mobile-patterns.com\/",
      "display_url" : "mobile-patterns.com"
    }, {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/3nvxRsu",
      "expanded_url" : "http:\/\/www.androidpatterns.com\/wiki",
      "display_url" : "androidpatterns.com\/wiki"
    } ]
  },
  "geo" : { },
  "id_str" : "45520518106988544",
  "text" : "Two mobile UI design pattern collections for iOS http:\/\/t.co\/r2UMFLz http:\/\/t.co\/NIJuSr6 and one for Android http:\/\/t.co\/3nvxRsu",
  "id" : 45520518106988544,
  "created_at" : "2011-03-09 16:25:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Quily",
      "screen_name" : "petequily",
      "indices" : [ 3, 13 ],
      "id_str" : "13239562",
      "id" : 13239562
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vancasino",
      "indices" : [ 115, 125 ]
    }, {
      "text" : "yvrpoli",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45229438018916352",
  "text" : "RT @petequily: Vancouver Not Vegas: Peter Ladner on why a BC Place casino is bad policy video http:\/\/bit.ly\/hLpMvr #vancasino #yvrpoli",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "vancasino",
        "indices" : [ 100, 110 ]
      }, {
        "text" : "yvrpoli",
        "indices" : [ 111, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "45204927500390401",
    "text" : "Vancouver Not Vegas: Peter Ladner on why a BC Place casino is bad policy video http:\/\/bit.ly\/hLpMvr #vancasino #yvrpoli",
    "id" : 45204927500390401,
    "created_at" : "2011-03-08 19:31:09 +0000",
    "user" : {
      "name" : "Pete Quily",
      "screen_name" : "petequily",
      "protected" : false,
      "id_str" : "13239562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525195896644829184\/DRG3i_t0_normal.jpeg",
      "id" : 13239562,
      "verified" : false
    }
  },
  "id" : 45229438018916352,
  "created_at" : "2011-03-08 21:08:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brent",
      "screen_name" : "notbrent",
      "indices" : [ 0, 9 ],
      "id_str" : "17911526",
      "id" : 17911526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44854971430207488",
  "geo" : { },
  "id_str" : "44898783942807552",
  "in_reply_to_user_id" : 17911526,
  "text" : "@notbrent You're most welcome, it was my pleasure!",
  "id" : 44898783942807552,
  "in_reply_to_status_id" : 44854971430207488,
  "created_at" : "2011-03-07 23:14:38 +0000",
  "in_reply_to_screen_name" : "notbrent",
  "in_reply_to_user_id_str" : "17911526",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "customerexplabs",
      "screen_name" : "customerexplabs",
      "indices" : [ 3, 19 ],
      "id_str" : "2518659901",
      "id" : 2518659901
    }, {
      "name" : "Smashing Magazine",
      "screen_name" : "smashingmag",
      "indices" : [ 104, 116 ],
      "id_str" : "15736190",
      "id" : 15736190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44823303625510912",
  "text" : "RT @customerexplabs: Must Read for Designers --&gt; Lean UX: Getting Out Of The Deliverables Business - @Smashingmag Smashing Magazine h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Smashing Magazine",
        "screen_name" : "smashingmag",
        "indices" : [ 83, 95 ],
        "id_str" : "15736190",
        "id" : 15736190
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "44819917312241665",
    "text" : "Must Read for Designers --&gt; Lean UX: Getting Out Of The Deliverables Business - @Smashingmag Smashing Magazine http:\/\/ow.ly\/49sQ9",
    "id" : 44819917312241665,
    "created_at" : "2011-03-07 18:01:15 +0000",
    "user" : {
      "name" : "Jay Eskenazi",
      "screen_name" : "jayeskenazi",
      "protected" : false,
      "id_str" : "26104299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1405205412\/jay_mad_men_style_normal.jpg",
      "id" : 26104299,
      "verified" : false
    }
  },
  "id" : 44823303625510912,
  "created_at" : "2011-03-07 18:14:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http:\/\/t.co\/NlIuKYz",
      "expanded_url" : "http:\/\/gigaom.com\/collaboration\/skype-gotomeeting-citrix\/",
      "display_url" : "gigaom.com\/collaboration\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "42738421004894208",
  "text" : "Interesting development in the works with Skype + my long time favorite screen-sharing tool GoToMeeting http:\/\/t.co\/NlIuKYz",
  "id" : 42738421004894208,
  "created_at" : "2011-03-02 00:10:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]