Grailbird.data.tweets_2015_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daryl Claudio",
      "screen_name" : "darylclaudio",
      "indices" : [ 3, 16 ],
      "id_str" : "14256762",
      "id" : 14256762
    }, {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 105, 117 ],
      "id_str" : "66913866",
      "id" : 66913866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/2xC397i23F",
      "expanded_url" : "http:\/\/openroad.ca\/about\/careers\/",
      "display_url" : "openroad.ca\/about\/careers\/"
    } ]
  },
  "geo" : { },
  "id_str" : "561284182500864000",
  "text" : "RT @darylclaudio: Technical support engineer, polyglot developer, and business analyst positions open at @openroadies \uD83D\uDC49 http:\/\/t.co\/2xC397i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenRoad",
        "screen_name" : "openroadies",
        "indices" : [ 87, 99 ],
        "id_str" : "66913866",
        "id" : 66913866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/2xC397i23F",
        "expanded_url" : "http:\/\/openroad.ca\/about\/careers\/",
        "display_url" : "openroad.ca\/about\/careers\/"
      } ]
    },
    "geo" : { },
    "id_str" : "561283849263398912",
    "text" : "Technical support engineer, polyglot developer, and business analyst positions open at @openroadies \uD83D\uDC49 http:\/\/t.co\/2xC397i23F",
    "id" : 561283849263398912,
    "created_at" : "2015-01-30 22:04:32 +0000",
    "user" : {
      "name" : "Daryl Claudio",
      "screen_name" : "darylclaudio",
      "protected" : false,
      "id_str" : "14256762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478058900344672257\/WZfLvxKP_normal.jpeg",
      "id" : 14256762,
      "verified" : false
    }
  },
  "id" : 561284182500864000,
  "created_at" : "2015-01-30 22:05:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "indices" : [ 85, 97 ],
      "id_str" : "19812150",
      "id" : 19812150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/8dstPFppKi",
      "expanded_url" : "http:\/\/opentextbc.ca\/teachinginadigitalage\/chapter\/models-for-choosing-media-and-technologies\/",
      "display_url" : "opentextbc.ca\/teachinginadig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "561220965300846594",
  "text" : "Honoured that the Learning + Technology Development Model is making an appearance in @drtonybates upcoming book http:\/\/t.co\/8dstPFppKi",
  "id" : 561220965300846594,
  "created_at" : "2015-01-30 17:54:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/560956050816245760\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/DRgbagE0H2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8jqjkYCMAAlpLo.png",
      "id_str" : "560956050388430848",
      "id" : 560956050388430848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8jqjkYCMAAlpLo.png",
      "sizes" : [ {
        "h" : 172,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 525
      } ],
      "display_url" : "pic.twitter.com\/DRgbagE0H2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "560956050816245760",
  "text" : "It's 2015 and this is ridiculous http:\/\/t.co\/DRgbagE0H2",
  "id" : 560956050816245760,
  "created_at" : "2015-01-30 00:21:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 64, 72 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "560863907309309952",
  "text" : "@sbethm Thanks Sarah, that made me :-) Right now I am exploring @getgrav as my next platform of choice for multi-device course companions.",
  "id" : 560863907309309952,
  "created_at" : "2015-01-29 18:15:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brent Smithurst",
      "screen_name" : "brentsmi",
      "indices" : [ 0, 9 ],
      "id_str" : "22743354",
      "id" : 22743354
    }, {
      "name" : "Bernard Golden",
      "screen_name" : "bernardgolden",
      "indices" : [ 10, 24 ],
      "id_str" : "23948946",
      "id" : 23948946
    }, {
      "name" : "TimeTrade",
      "screen_name" : "timetrade",
      "indices" : [ 64, 74 ],
      "id_str" : "120119323",
      "id" : 120119323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560623557969850368",
  "geo" : { },
  "id_str" : "560625289651183617",
  "in_reply_to_user_id" : 22743354,
  "text" : "@brentsmi @bernardgolden Hey Brent, I've been pretty happy with @timetrade",
  "id" : 560625289651183617,
  "in_reply_to_status_id" : 560623557969850368,
  "created_at" : "2015-01-29 02:27:39 +0000",
  "in_reply_to_screen_name" : "brentsmi",
  "in_reply_to_user_id_str" : "22743354",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/lKNWfvAD0S",
      "expanded_url" : "http:\/\/cmpt-363-133.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-133.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "560603852659904512",
  "text" : "@sbethm I LOVED using WordPress as a LMS for a course I taught! Here is the resulting course companion (2012) http:\/\/t.co\/lKNWfvAD0S",
  "id" : 560603852659904512,
  "created_at" : "2015-01-29 01:02:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 3, 18 ],
      "id_str" : "1122631",
      "id" : 1122631
    }, {
      "name" : "Design & Content",
      "screen_name" : "dcontentconf",
      "indices" : [ 120, 133 ],
      "id_str" : "2912534023",
      "id" : 2912534023
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YVR",
      "indices" : [ 114, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/iu8IPNpUUM",
      "expanded_url" : "http:\/\/www.designcontentconf.com",
      "display_url" : "designcontentconf.com"
    } ]
  },
  "geo" : { },
  "id_str" : "560209371540357121",
  "text" : "RT @MalloryOConnor: Have you got your tickets yet? http:\/\/t.co\/iu8IPNpUUM It's happening this August in beautiful #YVR! @dcontentconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Design & Content",
        "screen_name" : "dcontentconf",
        "indices" : [ 100, 113 ],
        "id_str" : "2912534023",
        "id" : 2912534023
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YVR",
        "indices" : [ 94, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/iu8IPNpUUM",
        "expanded_url" : "http:\/\/www.designcontentconf.com",
        "display_url" : "designcontentconf.com"
      } ]
    },
    "geo" : { },
    "id_str" : "560209081474895872",
    "text" : "Have you got your tickets yet? http:\/\/t.co\/iu8IPNpUUM It's happening this August in beautiful #YVR! @dcontentconf",
    "id" : 560209081474895872,
    "created_at" : "2015-01-27 22:53:47 +0000",
    "user" : {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "protected" : false,
      "id_str" : "1122631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2261747531\/mallory_thumbnail_normal.png",
      "id" : 1122631,
      "verified" : false
    }
  },
  "id" : 560209371540357121,
  "created_at" : "2015-01-27 22:54:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eventbrite",
      "screen_name" : "eventbrite",
      "indices" : [ 91, 102 ],
      "id_str" : "5625972",
      "id" : 5625972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/PRJTRMerqd",
      "expanded_url" : "http:\/\/designcontentconf.eventbrite.com\/?aff=estw",
      "display_url" : "designcontentconf.eventbrite.com\/?aff=estw"
    } ]
  },
  "geo" : { },
  "id_str" : "558427500150132736",
  "text" : "I'm going to \"Design &amp; Content Conference\".  See you there? http:\/\/t.co\/PRJTRMerqd via @eventbrite",
  "id" : 558427500150132736,
  "created_at" : "2015-01-23 00:54:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/558416083724431360\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/Xmr2aMZZUn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7_keByCIAApkzJ.png",
      "id_str" : "558416083342729216",
      "id" : 558416083342729216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7_keByCIAApkzJ.png",
      "sizes" : [ {
        "h" : 516,
        "resize" : "fit",
        "w" : 738
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 738
      } ],
      "display_url" : "pic.twitter.com\/Xmr2aMZZUn"
    } ],
    "hashtags" : [ {
      "text" : "wordpress",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "joomla",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/uCoJtItQbl",
      "expanded_url" : "http:\/\/getgrav.org\/blog\/traditional-cms-platforms-and-grav",
      "display_url" : "getgrav.org\/blog\/tradition\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558416647803781120",
  "text" : "RT @getgrav: New blog post: How Grav differs from traditional CMS platforms such as #wordpress #joomla: http:\/\/t.co\/uCoJtItQbl http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/558416083724431360\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Xmr2aMZZUn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7_keByCIAApkzJ.png",
        "id_str" : "558416083342729216",
        "id" : 558416083342729216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7_keByCIAApkzJ.png",
        "sizes" : [ {
          "h" : 516,
          "resize" : "fit",
          "w" : 738
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 738
        } ],
        "display_url" : "pic.twitter.com\/Xmr2aMZZUn"
      } ],
      "hashtags" : [ {
        "text" : "wordpress",
        "indices" : [ 71, 81 ]
      }, {
        "text" : "joomla",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/uCoJtItQbl",
        "expanded_url" : "http:\/\/getgrav.org\/blog\/traditional-cms-platforms-and-grav",
        "display_url" : "getgrav.org\/blog\/tradition\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "558416083724431360",
    "text" : "New blog post: How Grav differs from traditional CMS platforms such as #wordpress #joomla: http:\/\/t.co\/uCoJtItQbl http:\/\/t.co\/Xmr2aMZZUn",
    "id" : 558416083724431360,
    "created_at" : "2015-01-23 00:09:03 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 558416647803781120,
  "created_at" : "2015-01-23 00:11:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLHE2015",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558393866676473856",
  "text" : "For better or worse, I just submitted my proposed session for #STLHE2015: \"From Mobile Learning to Multi-device Learning Ecologies\"",
  "id" : 558393866676473856,
  "created_at" : "2015-01-22 22:40:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 0, 5 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "557983467489611776",
  "geo" : { },
  "id_str" : "558344847786901504",
  "in_reply_to_user_id" : 15949844,
  "text" : "@etug Thanks very much for the RT, much appreciated!",
  "id" : 558344847786901504,
  "in_reply_to_status_id" : 557983467489611776,
  "created_at" : "2015-01-22 19:25:59 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 3, 12 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/m_travin\/status\/557282675325550594\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/OqDmf8YkBk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7vdo99CMAABn21.png",
      "id_str" : "557282674805452800",
      "id" : 557282674805452800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7vdo99CMAABn21.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OqDmf8YkBk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/8ANreUD1ik",
      "expanded_url" : "http:\/\/linkd.in\/17Zc5Oh",
      "display_url" : "linkd.in\/17Zc5Oh"
    } ]
  },
  "geo" : { },
  "id_str" : "558323112807116800",
  "text" : "RT @m_travin: The Wild, Wild Next. Learners, Learning and How to Get There From Here. http:\/\/t.co\/8ANreUD1ik http:\/\/t.co\/OqDmf8YkBk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/m_travin\/status\/557282675325550594\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/OqDmf8YkBk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7vdo99CMAABn21.png",
        "id_str" : "557282674805452800",
        "id" : 557282674805452800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7vdo99CMAABn21.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 309,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OqDmf8YkBk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/8ANreUD1ik",
        "expanded_url" : "http:\/\/linkd.in\/17Zc5Oh",
        "display_url" : "linkd.in\/17Zc5Oh"
      } ]
    },
    "geo" : { },
    "id_str" : "557282675325550594",
    "text" : "The Wild, Wild Next. Learners, Learning and How to Get There From Here. http:\/\/t.co\/8ANreUD1ik http:\/\/t.co\/OqDmf8YkBk",
    "id" : 557282675325550594,
    "created_at" : "2015-01-19 21:05:18 +0000",
    "user" : {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "protected" : false,
      "id_str" : "837060721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765287050069159936\/eekFNEG5_normal.jpg",
      "id" : 837060721,
      "verified" : false
    }
  },
  "id" : 558323112807116800,
  "created_at" : "2015-01-22 17:59:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GDC Canada",
      "screen_name" : "GDCNational",
      "indices" : [ 3, 15 ],
      "id_str" : "76698310",
      "id" : 76698310
    }, {
      "name" : "Jason Aiken",
      "screen_name" : "jas_aiken",
      "indices" : [ 17, 27 ],
      "id_str" : "14776451",
      "id" : 14776451
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyTimeHasValue",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "557994577211056128",
  "text" : "RT @GDCNational: @jas_aiken \u2026 design is not a commodity. People are not a commodity. Designers shouldn\u2019t have to work without being paid. #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Aiken",
        "screen_name" : "jas_aiken",
        "indices" : [ 0, 10 ],
        "id_str" : "14776451",
        "id" : 14776451
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyTimeHasValue",
        "indices" : [ 121, 136 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "557988033266323457",
    "geo" : { },
    "id_str" : "557991234305024001",
    "in_reply_to_user_id" : 14776451,
    "text" : "@jas_aiken \u2026 design is not a commodity. People are not a commodity. Designers shouldn\u2019t have to work without being paid. #MyTimeHasValue",
    "id" : 557991234305024001,
    "in_reply_to_status_id" : 557988033266323457,
    "created_at" : "2015-01-21 20:00:51 +0000",
    "in_reply_to_screen_name" : "jas_aiken",
    "in_reply_to_user_id_str" : "14776451",
    "user" : {
      "name" : "GDC Canada",
      "screen_name" : "GDCNational",
      "protected" : false,
      "id_str" : "76698310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451419037768380417\/PmpENXTU_normal.jpeg",
      "id" : 76698310,
      "verified" : false
    }
  },
  "id" : 557994577211056128,
  "created_at" : "2015-01-21 20:14:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 0, 5 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Uf8swtjhKM",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/model-learner-needs-experience-design-technology-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/model-le\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557983467489611776",
  "in_reply_to_user_id" : 17102936,
  "text" : "@etug It would be awesome to get some #etug feedback on this freshly posted Learning + Technology Development Model https:\/\/t.co\/Uf8swtjhKM",
  "id" : 557983467489611776,
  "created_at" : "2015-01-21 19:30:00 +0000",
  "in_reply_to_screen_name" : "etug",
  "in_reply_to_user_id_str" : "17102936",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/clintlalonde\/status\/557980242598305792\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/KU6LSTYdiO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B75X-rZCEAEGBEb.png",
      "id_str" : "557980138151743489",
      "id" : 557980138151743489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B75X-rZCEAEGBEb.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 757
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 757
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KU6LSTYdiO"
    } ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 21, 25 ]
    }, {
      "text" : "adoptotb",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "557981487299964928",
  "text" : "RT @clintlalonde: ND #OER slide from Paul Stacey #adoptotb http:\/\/t.co\/KU6LSTYdiO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/clintlalonde\/status\/557980242598305792\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/KU6LSTYdiO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B75X-rZCEAEGBEb.png",
        "id_str" : "557980138151743489",
        "id" : 557980138151743489,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B75X-rZCEAEGBEb.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 757
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 757
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KU6LSTYdiO"
      } ],
      "hashtags" : [ {
        "text" : "OER",
        "indices" : [ 3, 7 ]
      }, {
        "text" : "adoptotb",
        "indices" : [ 31, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "557980242598305792",
    "text" : "ND #OER slide from Paul Stacey #adoptotb http:\/\/t.co\/KU6LSTYdiO",
    "id" : 557980242598305792,
    "created_at" : "2015-01-21 19:17:11 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 557981487299964928,
  "created_at" : "2015-01-21 19:22:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sync.com",
      "screen_name" : "Sync",
      "indices" : [ 0, 5 ],
      "id_str" : "551224728",
      "id" : 551224728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "557980433669840897",
  "in_reply_to_user_id" : 551224728,
  "text" : "@Sync Lots of great features added in 2014! Any chance two-factor authentication might be supported in 2015?",
  "id" : 557980433669840897,
  "created_at" : "2015-01-21 19:17:56 +0000",
  "in_reply_to_screen_name" : "Sync",
  "in_reply_to_user_id_str" : "551224728",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 105, 110 ]
    }, {
      "text" : "proflearn",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/C5kNEJgJUN",
      "expanded_url" : "http:\/\/etug.ca\/2015\/01\/15\/2015-etug-top-5-survey-results\/",
      "display_url" : "etug.ca\/2015\/01\/15\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557684222715252737",
  "text" : "RT @etug: Results are in! What you said are the top 5 issues\/trends in post sec: http:\/\/t.co\/C5kNEJgJUN \n#etug #proflearn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 95, 100 ]
      }, {
        "text" : "proflearn",
        "indices" : [ 101, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/C5kNEJgJUN",
        "expanded_url" : "http:\/\/etug.ca\/2015\/01\/15\/2015-etug-top-5-survey-results\/",
        "display_url" : "etug.ca\/2015\/01\/15\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "557261927152226304",
    "text" : "Results are in! What you said are the top 5 issues\/trends in post sec: http:\/\/t.co\/C5kNEJgJUN \n#etug #proflearn",
    "id" : 557261927152226304,
    "created_at" : "2015-01-19 19:42:51 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 557684222715252737,
  "created_at" : "2015-01-20 23:40:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 79, 94 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/557302983479005184\/photo\/1",
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/rshvh2Bq9H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7vwHC4CMAA6dUf.png",
      "id_str" : "557302982732034048",
      "id" : 557302982732034048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7vwHC4CMAA6dUf.png",
      "sizes" : [ {
        "h" : 431,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rshvh2Bq9H"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/DhiDfGJi1H",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/model-learner-needs-experience-design-technology-paul-hibbitts",
      "display_url" : "linkedin.com\/pulse\/model-le\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557302983479005184",
  "text" : "\"A Model for Learner Needs, Experience Design &amp; Technology Development\" by @hibbittsdesign https:\/\/t.co\/DhiDfGJi1H http:\/\/t.co\/rshvh2Bq9H",
  "id" : 557302983479005184,
  "created_at" : "2015-01-19 22:26:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Unity3D",
      "indices" : [ 44, 52 ]
    }, {
      "text" : "designthinking",
      "indices" : [ 53, 68 ]
    }, {
      "text" : "SFU",
      "indices" : [ 119, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/y7EFyWUfbQ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=S0Csgx2gCok",
      "display_url" : "youtube.com\/watch?v=S0Csgx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556979202562334721",
  "text" : "MT How To Make Interactive UI Prototypes in #Unity3D #designthinking https:\/\/t.co\/y7EFyWUfbQ - great technique by past #SFU CMPT 363 student",
  "id" : 556979202562334721,
  "created_at" : "2015-01-19 00:59:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rian Van Der Merwe",
      "screen_name" : "RianVDM",
      "indices" : [ 3, 11 ],
      "id_str" : "14218310",
      "id" : 14218310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/GuUNDhXAOV",
      "expanded_url" : "http:\/\/www.teehanlax.com\/",
      "display_url" : "teehanlax.com"
    } ]
  },
  "geo" : { },
  "id_str" : "556551583324831744",
  "text" : "RT @RianVDM: \"We thought it was appropriate to try and tell the whole story.\" Except the part where 40 people lost their jobs. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/GuUNDhXAOV",
        "expanded_url" : "http:\/\/www.teehanlax.com\/",
        "display_url" : "teehanlax.com"
      } ]
    },
    "geo" : { },
    "id_str" : "556136776822046720",
    "text" : "\"We thought it was appropriate to try and tell the whole story.\" Except the part where 40 people lost their jobs. http:\/\/t.co\/GuUNDhXAOV",
    "id" : 556136776822046720,
    "created_at" : "2015-01-16 17:11:54 +0000",
    "user" : {
      "name" : "Rian Van Der Merwe",
      "screen_name" : "RianVDM",
      "protected" : false,
      "id_str" : "14218310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730497804125212673\/BgZvOkF0_normal.jpg",
      "id" : 14218310,
      "verified" : false
    }
  },
  "id" : 556551583324831744,
  "created_at" : "2015-01-17 20:40:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Rehn",
      "screen_name" : "daniel_rehn",
      "indices" : [ 3, 15 ],
      "id_str" : "4058321",
      "id" : 4058321
    }, {
      "name" : "Rich Oglesby",
      "screen_name" : "Rich_Oglesby",
      "indices" : [ 121, 134 ],
      "id_str" : "18063131",
      "id" : 18063131
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/daniel_rehn\/status\/555197719070138369\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/3lm9VFgpy3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7R1YUfCIAAgOoU.png",
      "id_str" : "555197714749595648",
      "id" : 555197714749595648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7R1YUfCIAAgOoU.png",
      "sizes" : [ {
        "h" : 583,
        "resize" : "fit",
        "w" : 770
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 770
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3lm9VFgpy3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/W5lk15JtiM",
      "expanded_url" : "http:\/\/dnlr.hn\/1wbBTuO",
      "display_url" : "dnlr.hn\/1wbBTuO"
    } ]
  },
  "geo" : { },
  "id_str" : "555399267460739074",
  "text" : "RT @daniel_rehn: The 1978 source code for Microsoft BASIC for 6502 with comments + easter eggs \u2192 http:\/\/t.co\/W5lk15JtiM \u1525@rich_oglesby http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rich Oglesby",
        "screen_name" : "Rich_Oglesby",
        "indices" : [ 104, 117 ],
        "id_str" : "18063131",
        "id" : 18063131
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/daniel_rehn\/status\/555197719070138369\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/3lm9VFgpy3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7R1YUfCIAAgOoU.png",
        "id_str" : "555197714749595648",
        "id" : 555197714749595648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7R1YUfCIAAgOoU.png",
        "sizes" : [ {
          "h" : 583,
          "resize" : "fit",
          "w" : 770
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 770
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/3lm9VFgpy3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/W5lk15JtiM",
        "expanded_url" : "http:\/\/dnlr.hn\/1wbBTuO",
        "display_url" : "dnlr.hn\/1wbBTuO"
      } ]
    },
    "geo" : { },
    "id_str" : "555197719070138369",
    "text" : "The 1978 source code for Microsoft BASIC for 6502 with comments + easter eggs \u2192 http:\/\/t.co\/W5lk15JtiM \u1525@rich_oglesby http:\/\/t.co\/3lm9VFgpy3",
    "id" : 555197719070138369,
    "created_at" : "2015-01-14 03:00:25 +0000",
    "user" : {
      "name" : "Daniel Rehn",
      "screen_name" : "daniel_rehn",
      "protected" : false,
      "id_str" : "4058321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764380231893254144\/kh3oACy9_normal.jpg",
      "id" : 4058321,
      "verified" : false
    }
  },
  "id" : 555399267460739074,
  "created_at" : "2015-01-14 16:21:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learningxproject",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554797272928501761",
  "text" : "Updated workshop touchpoints:\n1) Selection\n2) Preparation\n3) Participation\n4) Reflection\n5) Exploration\n6) Application\n#learningxproject",
  "id" : 554797272928501761,
  "created_at" : "2015-01-13 00:29:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "553714050509459457",
  "geo" : { },
  "id_str" : "553750136984064000",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 I used a similar tool (Kato) for my 80 student SFU class and was very pleased with the outcome. Students loved the real-time aspect!",
  "id" : 553750136984064000,
  "in_reply_to_status_id" : 553714050509459457,
  "created_at" : "2015-01-10 03:08:15 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Coolidge",
      "screen_name" : "acoolidge",
      "indices" : [ 3, 13 ],
      "id_str" : "17416175",
      "id" : 17416175
    }, {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 139, 140 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AdoptOTB",
      "indices" : [ 54, 63 ]
    }, {
      "text" : "oer",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/GlbgpDKvlT",
      "expanded_url" : "https:\/\/p2pu.org\/en\/courses\/2675\/adopting-open-textbooks\/",
      "display_url" : "p2pu.org\/en\/courses\/267\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "553686451531964417",
  "text" : "RT @acoolidge: 275 registrants (so far!) for the free #AdoptOTB workshop- still time to join us before we start Mon. https:\/\/t.co\/GlbgpDKvl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BCcampus",
        "screen_name" : "BCcampus",
        "indices" : [ 126, 135 ],
        "id_str" : "93710949",
        "id" : 93710949
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AdoptOTB",
        "indices" : [ 39, 48 ]
      }, {
        "text" : "oer",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/GlbgpDKvlT",
        "expanded_url" : "https:\/\/p2pu.org\/en\/courses\/2675\/adopting-open-textbooks\/",
        "display_url" : "p2pu.org\/en\/courses\/267\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "553685303597096961",
    "text" : "275 registrants (so far!) for the free #AdoptOTB workshop- still time to join us before we start Mon. https:\/\/t.co\/GlbgpDKvlT @BCcampus #oer",
    "id" : 553685303597096961,
    "created_at" : "2015-01-09 22:50:38 +0000",
    "user" : {
      "name" : "Amanda Coolidge",
      "screen_name" : "acoolidge",
      "protected" : false,
      "id_str" : "17416175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674352077020073984\/88hyOiSP_normal.jpg",
      "id" : 17416175,
      "verified" : false
    }
  },
  "id" : 553686451531964417,
  "created_at" : "2015-01-09 22:55:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/553602555951865856\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/soMFlaVSe8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B67KlykCYAA5zNf.png",
      "id_str" : "553602554790043648",
      "id" : 553602554790043648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B67KlykCYAA5zNf.png",
      "sizes" : [ {
        "h" : 848,
        "resize" : "fit",
        "w" : 477
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 848,
        "resize" : "fit",
        "w" : 477
      }, {
        "h" : 848,
        "resize" : "fit",
        "w" : 477
      } ],
      "display_url" : "pic.twitter.com\/soMFlaVSe8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "553602555951865856",
  "text" : "Considering ways to get student input to help shape upcoming workshop, Question2Answer looks promising  - any others? http:\/\/t.co\/soMFlaVSe8",
  "id" : 553602555951865856,
  "created_at" : "2015-01-09 17:21:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/kEJunnyrQW",
      "expanded_url" : "http:\/\/www.mindmeister.com\/493630729\/workshop-multi-device-course-companion-sitemap",
      "display_url" : "mindmeister.com\/493630729\/work\u2026"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/lok2o0afbA",
      "expanded_url" : "https:\/\/hibbittsdesign.mybalsamiq.com\/projects\/multi-devicelearningcourse2014\/Site%20Pages",
      "display_url" : "hibbittsdesign.mybalsamiq.com\/projects\/multi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "552958960932618240",
  "text" : "Streamlined multi-device course companion content mindmap ( incl. content types) http:\/\/t.co\/kEJunnyrQW and mockups https:\/\/t.co\/lok2o0afbA",
  "id" : 552958960932618240,
  "created_at" : "2015-01-07 22:44:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learningxproject",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/lok2o0afbA",
      "expanded_url" : "https:\/\/hibbittsdesign.mybalsamiq.com\/projects\/multi-devicelearningcourse2014\/Site%20Pages",
      "display_url" : "hibbittsdesign.mybalsamiq.com\/projects\/multi\u2026"
    }, {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/kEJunnyrQW",
      "expanded_url" : "http:\/\/www.mindmeister.com\/493630729\/workshop-multi-device-course-companion-sitemap",
      "display_url" : "mindmeister.com\/493630729\/work\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "552598039827722240",
  "text" : "Exploring content chunking for my course companions - mockups: https:\/\/t.co\/lok2o0afbA mindmap: http:\/\/t.co\/kEJunnyrQW #learningxproject",
  "id" : 552598039827722240,
  "created_at" : "2015-01-06 22:50:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/kEJunnyrQW",
      "expanded_url" : "http:\/\/www.mindmeister.com\/493630729\/workshop-multi-device-course-companion-sitemap",
      "display_url" : "mindmeister.com\/493630729\/work\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "552553543417069568",
  "geo" : { },
  "id_str" : "552578804577607681",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Here is my in-progress course companion sitemap, which might help illustrate things (a bit) better http:\/\/t.co\/kEJunnyrQW",
  "id" : 552578804577607681,
  "in_reply_to_status_id" : 552553543417069568,
  "created_at" : "2015-01-06 21:33:48 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552553543417069568",
  "geo" : { },
  "id_str" : "552576204037836801",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob Aiming for \"just-right\" content granularity for: 1) faster updating 2)  presentation options 3) more reuse 4) spaning topics +others",
  "id" : 552576204037836801,
  "in_reply_to_status_id" : 552553543417069568,
  "created_at" : "2015-01-06 21:23:28 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/mX5tvoE0Dh",
      "expanded_url" : "http:\/\/wp-types.com",
      "display_url" : "wp-types.com"
    } ]
  },
  "geo" : { },
  "id_str" : "552551631305584642",
  "text" : "In addition to multi-device presentation, I am trying out http:\/\/t.co\/mX5tvoE0Dh to help instructors better structure course companions.",
  "id" : 552551631305584642,
  "created_at" : "2015-01-06 19:45:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Peters",
      "screen_name" : "tom_peters",
      "indices" : [ 3, 14 ],
      "id_str" : "18028509",
      "id" : 18028509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551476261348843520",
  "text" : "RT @tom_peters: Whoops. So much for Millenials' unique entrepreneurial flair. Biz ownership by under 30 demographic at 24 year low, down 70\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "551470773932916736",
    "text" : "Whoops. So much for Millenials' unique entrepreneurial flair. Biz ownership by under 30 demographic at 24 year low, down 70% from '89.",
    "id" : 551470773932916736,
    "created_at" : "2015-01-03 20:10:52 +0000",
    "user" : {
      "name" : "Tom Peters",
      "screen_name" : "tom_peters",
      "protected" : false,
      "id_str" : "18028509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509454796042928128\/Db2nYm-L_normal.jpeg",
      "id" : 18028509,
      "verified" : true
    }
  },
  "id" : 551476261348843520,
  "created_at" : "2015-01-03 20:32:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rubeli",
      "screen_name" : "drubeli",
      "indices" : [ 0, 8 ],
      "id_str" : "17217620",
      "id" : 17217620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551167373277802496",
  "geo" : { },
  "id_str" : "551169399567048704",
  "in_reply_to_user_id" : 17217620,
  "text" : "@drubeli Touchpoints listed would also be a combination of in-person and digital.",
  "id" : 551169399567048704,
  "in_reply_to_status_id" : 551167373277802496,
  "created_at" : "2015-01-03 00:13:19 +0000",
  "in_reply_to_screen_name" : "drubeli",
  "in_reply_to_user_id_str" : "17217620",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rubeli",
      "screen_name" : "drubeli",
      "indices" : [ 0, 8 ],
      "id_str" : "17217620",
      "id" : 17217620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551167373277802496",
  "geo" : { },
  "id_str" : "551169173057830912",
  "in_reply_to_user_id" : 17217620,
  "text" : "@drubeli Preview\/access to multi-device course companion would be before and after the actual workshops as well. Thanks for any comments!",
  "id" : 551169173057830912,
  "in_reply_to_status_id" : 551167373277802496,
  "created_at" : "2015-01-03 00:12:25 +0000",
  "in_reply_to_screen_name" : "drubeli",
  "in_reply_to_user_id_str" : "17217620",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rubeli",
      "screen_name" : "drubeli",
      "indices" : [ 0, 8 ],
      "id_str" : "17217620",
      "id" : 17217620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551167373277802496",
  "geo" : { },
  "id_str" : "551168772296302592",
  "in_reply_to_user_id" : 17217620,
  "text" : "@drubeli Adult learners, face-to-face workshop, multi-device course companion. Now also thinking about adding Exploration item between 4 &amp; 5",
  "id" : 551168772296302592,
  "in_reply_to_status_id" : 551167373277802496,
  "created_at" : "2015-01-03 00:10:50 +0000",
  "in_reply_to_screen_name" : "drubeli",
  "in_reply_to_user_id_str" : "17217620",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learningxproject",
      "indices" : [ 109, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551129476021493761",
  "text" : "Workshop touchpoints for students?\n1) Selection\n2) Preparation\n3) Participation\n4) Reflection\n5) Application\n#learningxproject",
  "id" : 551129476021493761,
  "created_at" : "2015-01-02 21:34:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learningxproject",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551087507694030849",
  "text" : "With multi-device learning companions, content chunking is critical. We need to monitor\/update materials much more easily #learningxproject",
  "id" : 551087507694030849,
  "created_at" : "2015-01-02 18:47:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learningxproject",
      "indices" : [ 52, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550766018579406852",
  "text" : "Happy New Year! 2015 marks the official start of my #learningxproject, with a focus on better digital experiences for students &amp; instructors",
  "id" : 550766018579406852,
  "created_at" : "2015-01-01 21:30:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]