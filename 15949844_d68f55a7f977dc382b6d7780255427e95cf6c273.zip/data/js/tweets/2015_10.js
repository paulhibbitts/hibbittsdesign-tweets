Grailbird.data.tweets_2015_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flavio Copes",
      "screen_name" : "flaviocopes",
      "indices" : [ 3, 15 ],
      "id_str" : "9011502",
      "id" : 9011502
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 17, 25 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Joe LeBlanc",
      "screen_name" : "jlleblanc",
      "indices" : [ 26, 36 ],
      "id_str" : "14221308",
      "id" : 14221308
    }, {
      "name" : "James Hafner",
      "screen_name" : "jhafner",
      "indices" : [ 37, 45 ],
      "id_str" : "15152796",
      "id" : 15152796
    }, {
      "name" : "Jeremy Wilken",
      "screen_name" : "gnomeontherun",
      "indices" : [ 46, 60 ],
      "id_str" : "18979490",
      "id" : 18979490
    }, {
      "name" : "Cory Webb",
      "screen_name" : "corywebb",
      "indices" : [ 61, 70 ],
      "id_str" : "16468593",
      "id" : 16468593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/lL7jwTKMNF",
      "expanded_url" : "https:\/\/github.com\/flaviocopes\/grav-plugin-api",
      "display_url" : "github.com\/flaviocopes\/gr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660614205528215552",
  "text" : "RT @flaviocopes: @getgrav @jlleblanc @jhafner @gnomeontherun @corywebb started https:\/\/t.co\/lL7jwTKMNF, to be added as a core grav plugin w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 0, 8 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      }, {
        "name" : "Joe LeBlanc",
        "screen_name" : "jlleblanc",
        "indices" : [ 9, 19 ],
        "id_str" : "14221308",
        "id" : 14221308
      }, {
        "name" : "James Hafner",
        "screen_name" : "jhafner",
        "indices" : [ 20, 28 ],
        "id_str" : "15152796",
        "id" : 15152796
      }, {
        "name" : "Jeremy Wilken",
        "screen_name" : "gnomeontherun",
        "indices" : [ 29, 43 ],
        "id_str" : "18979490",
        "id" : 18979490
      }, {
        "name" : "Cory Webb",
        "screen_name" : "corywebb",
        "indices" : [ 44, 53 ],
        "id_str" : "16468593",
        "id" : 16468593
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/lL7jwTKMNF",
        "expanded_url" : "https:\/\/github.com\/flaviocopes\/grav-plugin-api",
        "display_url" : "github.com\/flaviocopes\/gr\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "659757982025060352",
    "geo" : { },
    "id_str" : "660516308312657920",
    "in_reply_to_user_id" : 2737573033,
    "text" : "@getgrav @jlleblanc @jhafner @gnomeontherun @corywebb started https:\/\/t.co\/lL7jwTKMNF, to be added as a core grav plugin when it's ready",
    "id" : 660516308312657920,
    "in_reply_to_status_id" : 659757982025060352,
    "created_at" : "2015-10-31 17:58:54 +0000",
    "in_reply_to_screen_name" : "getgrav",
    "in_reply_to_user_id_str" : "2737573033",
    "user" : {
      "name" : "Flavio Copes",
      "screen_name" : "flaviocopes",
      "protected" : false,
      "id_str" : "9011502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603302280243347458\/tgF_XZ_J_normal.jpg",
      "id" : 9011502,
      "verified" : false
    }
  },
  "id" : 660614205528215552,
  "created_at" : "2015-11-01 00:27:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Beauvais",
      "screen_name" : "beauvais",
      "indices" : [ 0, 9 ],
      "id_str" : "8851412",
      "id" : 8851412
    }, {
      "name" : "Richard Saunders",
      "screen_name" : "rdsaunders",
      "indices" : [ 10, 21 ],
      "id_str" : "8772682",
      "id" : 8772682
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 56, 64 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 69, 78 ],
      "id_str" : "180743261",
      "id" : 180743261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ChDmQGRhJh",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/my-dream-workflow-as-an-instructor",
      "display_url" : "hibbittsdesign.org\/blog\/my-dream-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "660134946250563584",
  "geo" : { },
  "id_str" : "660260343042605056",
  "in_reply_to_user_id" : 8851412,
  "text" : "@beauvais @rdsaunders You could just about do that with @getgrav and @deployhq. Sample workflow here: https:\/\/t.co\/ChDmQGRhJh",
  "id" : 660260343042605056,
  "in_reply_to_status_id" : 660134946250563584,
  "created_at" : "2015-10-31 01:01:47 +0000",
  "in_reply_to_screen_name" : "beauvais",
  "in_reply_to_user_id_str" : "8851412",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UXPin",
      "screen_name" : "uxpin",
      "indices" : [ 3, 9 ],
      "id_str" : "211100214",
      "id" : 211100214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RWD",
      "indices" : [ 120, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/5h3RcY1cgP",
      "expanded_url" : "http:\/\/ht.ly\/TpFJA",
      "display_url" : "ht.ly\/TpFJA"
    } ]
  },
  "geo" : { },
  "id_str" : "660196494247530496",
  "text" : "RT @uxpin: Responsive design doesn't have to be a time suck. Here are 10 timesaving strategies: https:\/\/t.co\/5h3RcY1cgP #RWD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RWD",
        "indices" : [ 109, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/5h3RcY1cgP",
        "expanded_url" : "http:\/\/ht.ly\/TpFJA",
        "display_url" : "ht.ly\/TpFJA"
      } ]
    },
    "geo" : { },
    "id_str" : "660190800136019968",
    "text" : "Responsive design doesn't have to be a time suck. Here are 10 timesaving strategies: https:\/\/t.co\/5h3RcY1cgP #RWD",
    "id" : 660190800136019968,
    "created_at" : "2015-10-30 20:25:27 +0000",
    "user" : {
      "name" : "UXPin",
      "screen_name" : "uxpin",
      "protected" : false,
      "id_str" : "211100214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741185730794409985\/WXF6SZTz_normal.jpg",
      "id" : 211100214,
      "verified" : false
    }
  },
  "id" : 660196494247530496,
  "created_at" : "2015-10-30 20:48:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "technkl (retired)",
      "screen_name" : "technkl",
      "indices" : [ 65, 73 ],
      "id_str" : "4203476904",
      "id" : 4203476904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/TEcce5Dx9Q",
      "expanded_url" : "http:\/\/www.technkl.com\/theyre-not-learners-theyre-people\/",
      "display_url" : "technkl.com\/theyre-not-lea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660143814263222272",
  "text" : "They're not learners, they're people https:\/\/t.co\/TEcce5Dx9Q via @technkl",
  "id" : 660143814263222272,
  "created_at" : "2015-10-30 17:18:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659832103736053764",
  "geo" : { },
  "id_str" : "659832535870914560",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Bingo! Your use of \"multiple perspectives\" is critical, at least in our institutional situation.",
  "id" : 659832535870914560,
  "in_reply_to_status_id" : 659832103736053764,
  "created_at" : "2015-10-29 20:41:50 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659830225669390340",
  "geo" : { },
  "id_str" : "659830712682459136",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro This might be related... in the preso I am working on I've now got experience goals for students and also for facilitators. Better?",
  "id" : 659830712682459136,
  "in_reply_to_status_id" : 659830225669390340,
  "created_at" : "2015-10-29 20:34:35 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Warren Anthony",
      "screen_name" : "wjanthony",
      "indices" : [ 3, 13 ],
      "id_str" : "5752072",
      "id" : 5752072
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 15, 30 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659830083117387777",
  "text" : "RT @wjanthony: @hibbittsdesign makes total sense. There's still a user, but with a more specific goal\/outcome.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 0, 15 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "659828188969725952",
    "geo" : { },
    "id_str" : "659829429951164416",
    "in_reply_to_user_id" : 15949844,
    "text" : "@hibbittsdesign makes total sense. There's still a user, but with a more specific goal\/outcome.",
    "id" : 659829429951164416,
    "in_reply_to_status_id" : 659828188969725952,
    "created_at" : "2015-10-29 20:29:29 +0000",
    "in_reply_to_screen_name" : "hibbittsdesign",
    "in_reply_to_user_id_str" : "15949844",
    "user" : {
      "name" : "Warren Anthony",
      "screen_name" : "wjanthony",
      "protected" : false,
      "id_str" : "5752072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569622253004795904\/htlfIG3w_normal.jpeg",
      "id" : 5752072,
      "verified" : false
    }
  },
  "id" : 659830083117387777,
  "created_at" : "2015-10-29 20:32:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659829242730045440",
  "geo" : { },
  "id_str" : "659829975185383424",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Not sure I am following... \uD83D\uDE00",
  "id" : 659829975185383424,
  "in_reply_to_status_id" : 659829242730045440,
  "created_at" : "2015-10-29 20:31:39 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659828188969725952",
  "text" : "(4\/4) So, an alternative? Perhaps \"experience design for [domain]\". From my perspective it's embedding the full-stack of UX into any domain.",
  "id" : 659828188969725952,
  "created_at" : "2015-10-29 20:24:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659828132917047296",
  "text" : "(3\/4) Learner experience design also assumes the audience in question are just learners, which is not the case (they are people).",
  "id" : 659828132917047296,
  "created_at" : "2015-10-29 20:24:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659828072426835968",
  "text" : "(2\/4) Too often people think of LX separate from, or a subset of, UX design, but this is misleading and certainly not what I have found.",
  "id" : 659828072426835968,
  "created_at" : "2015-10-29 20:24:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659828022929809408",
  "text" : "(1\/4) While I've been using the term \"learner experience (LX) design\" myself for several years, I am finding it more and more problematic.",
  "id" : 659828022929809408,
  "created_at" : "2015-10-29 20:23:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 41, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/KgGagMvEBc",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/sfu-demofest-2015-flipping-the-lms#\/",
      "display_url" : "slides.com\/paulhibbitts\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659513673157771268",
  "text" : "Sneak peek of the slides for my upcoming #SFU DEMOFest presentation on flipping the LMS. https:\/\/t.co\/KgGagMvEBc",
  "id" : 659513673157771268,
  "created_at" : "2015-10-28 23:34:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/getstencil.com\" rel=\"nofollow\"\u003EStencil App\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/659500334096629760\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/kZUvhb5EZk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CScEDz8UsAQWpv_.png",
      "id_str" : "659500333962407940",
      "id" : 659500333962407940,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CScEDz8UsAQWpv_.png",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 299,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 1089
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kZUvhb5EZk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "659500334096629760",
  "text" : "My most recent definition of a flipped-LMS approach. Live example: https:\/\/t.co\/I7fZ1cnbn3 https:\/\/t.co\/kZUvhb5EZk",
  "id" : 659500334096629760,
  "created_at" : "2015-10-28 22:41:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 31, 40 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659483132194783232",
  "text" : "On the other hand, people like @m_travin understood and appreciated what UX (then called \"UI design\") could bring to the table 20 years ago.",
  "id" : 659483132194783232,
  "created_at" : "2015-10-28 21:33:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659476856974929920",
  "text" : "From my perspective learner experience design is not new, but UX design was historically underloved and unappreciated, especially by L&amp;D. \u2764",
  "id" : 659476856974929920,
  "created_at" : "2015-10-28 21:08:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/LHQnNjb05T",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/sfu-demofest2015-presentation",
      "display_url" : "hibbittsdesign.org\/blog\/sfu-demof\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659442023473152000",
  "text" : "Love some feedback from instructors on web-savvy skills listed in this session description: https:\/\/t.co\/LHQnNjb05T Basic I &amp; maybe II?",
  "id" : 659442023473152000,
  "created_at" : "2015-10-28 18:50:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gus Hobbleton",
      "screen_name" : "GusHobbleton",
      "indices" : [ 0, 13 ],
      "id_str" : "283229695",
      "id" : 283229695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659379874314907648",
  "geo" : { },
  "id_str" : "659437459533524992",
  "in_reply_to_user_id" : 283229695,
  "text" : "@GusHobbleton Clear as mud!",
  "id" : 659437459533524992,
  "in_reply_to_status_id" : 659379874314907648,
  "created_at" : "2015-10-28 18:31:56 +0000",
  "in_reply_to_screen_name" : "GusHobbleton",
  "in_reply_to_user_id_str" : "283229695",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katherine Clark",
      "screen_name" : "RepKClark",
      "indices" : [ 3, 13 ],
      "id_str" : "2293131060",
      "id" : 2293131060
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RepKClark\/status\/659079562115063808\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/HQ59qvEZvA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWFXnjUsAAdLnY.jpg",
      "id_str" : "659079561280270336",
      "id" : 659079561280270336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWFXnjUsAAdLnY.jpg",
      "sizes" : [ {
        "h" : 776,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3300,
        "resize" : "fit",
        "w" : 2550
      }, {
        "h" : 1325,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HQ59qvEZvA"
    } ],
    "hashtags" : [ {
      "text" : "SXSW",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659167783578566657",
  "text" : "RT @RepKClark: I'm calling on #SXSW to reconsider their ill-advised decision to cancel the panel on online harassment. My letter: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RepKClark\/status\/659079562115063808\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/HQ59qvEZvA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWFXnjUsAAdLnY.jpg",
        "id_str" : "659079561280270336",
        "id" : 659079561280270336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWFXnjUsAAdLnY.jpg",
        "sizes" : [ {
          "h" : 776,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3300,
          "resize" : "fit",
          "w" : 2550
        }, {
          "h" : 1325,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HQ59qvEZvA"
      } ],
      "hashtags" : [ {
        "text" : "SXSW",
        "indices" : [ 15, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659079562115063808",
    "text" : "I'm calling on #SXSW to reconsider their ill-advised decision to cancel the panel on online harassment. My letter: https:\/\/t.co\/HQ59qvEZvA",
    "id" : 659079562115063808,
    "created_at" : "2015-10-27 18:49:47 +0000",
    "user" : {
      "name" : "Katherine Clark",
      "screen_name" : "RepKClark",
      "protected" : false,
      "id_str" : "2293131060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694975296844472321\/vPliwWX__normal.jpg",
      "id" : 2293131060,
      "verified" : true
    }
  },
  "id" : 659167783578566657,
  "created_at" : "2015-10-28 00:40:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/LHQnNjb05T",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/sfu-demofest2015-presentation",
      "display_url" : "hibbittsdesign.org\/blog\/sfu-demof\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659116055592218625",
  "text" : "Second draft for my flipped-LMS presentation at SFU DEMOFest 2015: https:\/\/t.co\/LHQnNjb05T",
  "id" : 659116055592218625,
  "created_at" : "2015-10-27 21:14:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Kluwe",
      "screen_name" : "ChrisWarcraft",
      "indices" : [ 3, 17 ],
      "id_str" : "175378976",
      "id" : 175378976
    }, {
      "name" : "SXSW",
      "screen_name" : "sxsw",
      "indices" : [ 24, 29 ],
      "id_str" : "784304",
      "id" : 784304
    }, {
      "name" : "The Cauldron",
      "screen_name" : "TheCauldron",
      "indices" : [ 60, 72 ],
      "id_str" : "254714249",
      "id" : 254714249
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ChrisWarcraft\/status\/659076051750924288\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/FeV8wHQIQg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWCLPxUwAA9V-l.jpg",
      "id_str" : "659076050203230208",
      "id" : 659076050203230208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWCLPxUwAA9V-l.jpg",
      "sizes" : [ {
        "h" : 818,
        "resize" : "fit",
        "w" : 864
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 818,
        "resize" : "fit",
        "w" : 864
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FeV8wHQIQg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/bYh8FmH7bf",
      "expanded_url" : "https:\/\/the-cauldron.com\/sxsw-s-astounding-ideals-of-cowardice-871764d3eb45#.dzcjxc02l",
      "display_url" : "the-cauldron.com\/sxsw-s-astound\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659094493853913088",
  "text" : "RT @ChrisWarcraft: Hey, @sxsw. I wrote something for you at @TheCauldron. Feel free to share with attendees. https:\/\/t.co\/bYh8FmH7bf https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SXSW",
        "screen_name" : "sxsw",
        "indices" : [ 5, 10 ],
        "id_str" : "784304",
        "id" : 784304
      }, {
        "name" : "The Cauldron",
        "screen_name" : "TheCauldron",
        "indices" : [ 41, 53 ],
        "id_str" : "254714249",
        "id" : 254714249
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ChrisWarcraft\/status\/659076051750924288\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/FeV8wHQIQg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWCLPxUwAA9V-l.jpg",
        "id_str" : "659076050203230208",
        "id" : 659076050203230208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWCLPxUwAA9V-l.jpg",
        "sizes" : [ {
          "h" : 818,
          "resize" : "fit",
          "w" : 864
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 818,
          "resize" : "fit",
          "w" : 864
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/FeV8wHQIQg"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/bYh8FmH7bf",
        "expanded_url" : "https:\/\/the-cauldron.com\/sxsw-s-astounding-ideals-of-cowardice-871764d3eb45#.dzcjxc02l",
        "display_url" : "the-cauldron.com\/sxsw-s-astound\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659076051750924288",
    "text" : "Hey, @sxsw. I wrote something for you at @TheCauldron. Feel free to share with attendees. https:\/\/t.co\/bYh8FmH7bf https:\/\/t.co\/FeV8wHQIQg",
    "id" : 659076051750924288,
    "created_at" : "2015-10-27 18:35:50 +0000",
    "user" : {
      "name" : "Chris Kluwe",
      "screen_name" : "ChrisWarcraft",
      "protected" : false,
      "id_str" : "175378976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1342280050\/Venethrax1_normal.jpg",
      "id" : 175378976,
      "verified" : true
    }
  },
  "id" : 659094493853913088,
  "created_at" : "2015-10-27 19:49:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 65, 73 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/DkDxCVmdNc",
      "expanded_url" : "https:\/\/www.sfu.ca\/tlc\/programming\/special\/demofest-2015.html",
      "display_url" : "sfu.ca\/tlc\/programmin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659090098785390593",
  "text" : "It's official! I will be presenting my flipped-LMS approach with @getgrav and #CanvasLMS at SFU DEMOFest 2015 https:\/\/t.co\/DkDxCVmdNc",
  "id" : 659090098785390593,
  "created_at" : "2015-10-27 19:31:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 75, 83 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 119, 128 ],
      "id_str" : "180743261",
      "id" : 180743261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659088302503424005",
  "text" : "Just discovered I can deploy my GitHub hosted course companion (built with @getgrav) to TWO servers automatically with @deployhq. \uD83D\uDC4D",
  "id" : 659088302503424005,
  "created_at" : "2015-10-27 19:24:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rochen",
      "screen_name" : "RochenHost",
      "indices" : [ 0, 11 ],
      "id_str" : "21796559",
      "id" : 21796559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658687569136386048",
  "geo" : { },
  "id_str" : "658833840970952704",
  "in_reply_to_user_id" : 21796559,
  "text" : "@RochenHost My site still seems to be unavailable, though it did come back for a time this afternoon. What's the status of the situation?",
  "id" : 658833840970952704,
  "in_reply_to_status_id" : 658687569136386048,
  "created_at" : "2015-10-27 02:33:22 +0000",
  "in_reply_to_screen_name" : "RochenHost",
  "in_reply_to_user_id_str" : "21796559",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Clark",
      "screen_name" : "bigmediumjosh",
      "indices" : [ 30, 44 ],
      "id_str" : "7552082",
      "id" : 7552082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/pmgGp6kJ8a",
      "expanded_url" : "https:\/\/twitter.com\/bigmediumjosh\/status\/658787016482672640",
      "display_url" : "twitter.com\/bigmediumjosh\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658788793516822529",
  "text" : "Great to see this new book by @bigmediumjosh coming out! Designing for touch is essential for mobile AND desktop. https:\/\/t.co\/pmgGp6kJ8a",
  "id" : 658788793516822529,
  "created_at" : "2015-10-26 23:34:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/fff5qjwPPr",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/facilitator-experience-design-vs-learner-experience-design",
      "display_url" : "hibbittsdesign.org\/blog\/facilitat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658778905201893376",
  "text" : "First draft of experience design goals for facilitators AND learners https:\/\/t.co\/fff5qjwPPr\n\nThoughts\/comments?",
  "id" : 658778905201893376,
  "created_at" : "2015-10-26 22:55:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rochen",
      "screen_name" : "RochenHost",
      "indices" : [ 0, 11 ],
      "id_str" : "21796559",
      "id" : 21796559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "658682122354339840",
  "in_reply_to_user_id" : 21796559,
  "text" : "@RochenHost Is there a server issue right now? My site is hosted with you and seems unavailable https:\/\/t.co\/I7fZ1cnbn3",
  "id" : 658682122354339840,
  "created_at" : "2015-10-26 16:30:30 +0000",
  "in_reply_to_screen_name" : "RochenHost",
  "in_reply_to_user_id_str" : "21796559",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 0, 8 ],
      "id_str" : "5690792",
      "id" : 5690792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658504039454392320",
  "geo" : { },
  "id_str" : "658504813718585344",
  "in_reply_to_user_id" : 5690792,
  "text" : "@draggin You will simply need to delay your departure! Countless donairs during my university days back East \u263A",
  "id" : 658504813718585344,
  "in_reply_to_status_id" : 658504039454392320,
  "created_at" : "2015-10-26 04:45:56 +0000",
  "in_reply_to_screen_name" : "draggin",
  "in_reply_to_user_id_str" : "5690792",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 0, 8 ],
      "id_str" : "5690792",
      "id" : 5690792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658501546007764992",
  "geo" : { },
  "id_str" : "658502001102209025",
  "in_reply_to_user_id" : 5690792,
  "text" : "@draggin But have you had a donair yet???",
  "id" : 658502001102209025,
  "in_reply_to_status_id" : 658501546007764992,
  "created_at" : "2015-10-26 04:34:46 +0000",
  "in_reply_to_screen_name" : "draggin",
  "in_reply_to_user_id_str" : "5690792",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Bovis",
      "screen_name" : "PaulBovis",
      "indices" : [ 0, 10 ],
      "id_str" : "1004346642",
      "id" : 1004346642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658499888469188608",
  "geo" : { },
  "id_str" : "658501495923458048",
  "in_reply_to_user_id" : 1004346642,
  "text" : "@PaulBovis Oh baby! Lol",
  "id" : 658501495923458048,
  "in_reply_to_status_id" : 658499888469188608,
  "created_at" : "2015-10-26 04:32:45 +0000",
  "in_reply_to_screen_name" : "PaulBovis",
  "in_reply_to_user_id_str" : "1004346642",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coulthard",
      "screen_name" : "gcoulthard",
      "indices" : [ 0, 11 ],
      "id_str" : "23327774",
      "id" : 23327774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658479882448465921",
  "geo" : { },
  "id_str" : "658501244307173376",
  "in_reply_to_user_id" : 23327774,
  "text" : "@gcoulthard Two out of three, pretty good \u263A Also Strange Advance, Images in Vogue, The Spoons, and Blue Peter. Fully dated myself there!",
  "id" : 658501244307173376,
  "in_reply_to_status_id" : 658479882448465921,
  "created_at" : "2015-10-26 04:31:45 +0000",
  "in_reply_to_screen_name" : "gcoulthard",
  "in_reply_to_user_id_str" : "23327774",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexey Zagalsky",
      "screen_name" : "alexeyzagalsky",
      "indices" : [ 0, 15 ],
      "id_str" : "597572114",
      "id" : 597572114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/mDJ9E4VNAs",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/",
      "display_url" : "hibbittsdesign.org"
    } ]
  },
  "geo" : { },
  "id_str" : "658436075208052736",
  "in_reply_to_user_id" : 597572114,
  "text" : "@alexeyzagalsky Just to let you know I've linked to your great post about GitHub in Education via my new blog at https:\/\/t.co\/mDJ9E4VNAs",
  "id" : 658436075208052736,
  "created_at" : "2015-10-26 00:12:48 +0000",
  "in_reply_to_screen_name" : "alexeyzagalsky",
  "in_reply_to_user_id_str" : "597572114",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/mDJ9E4VNAs",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/",
      "display_url" : "hibbittsdesign.org"
    } ]
  },
  "geo" : { },
  "id_str" : "658426337850355712",
  "text" : "I've started a little blog about my flipped-LMS approach, GitHub in education, Grav CMS, and of course UX\/LX design https:\/\/t.co\/mDJ9E4VNAs",
  "id" : 658426337850355712,
  "created_at" : "2015-10-25 23:34:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 110, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658410538196557824",
  "text" : "I am really going old school with listening to some of my favourite Canadian bands of the '80s during today's #SFU virtual office hours.",
  "id" : 658410538196557824,
  "created_at" : "2015-10-25 22:31:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 53, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/V4gRb8kA5t",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "658400783738626048",
  "text" : "Holding a few additional virtual office hours for my #SFU CMPT 363 students at https:\/\/t.co\/V4gRb8kA5t right now.",
  "id" : 658400783738626048,
  "created_at" : "2015-10-25 21:52:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Win Goodbody",
      "screen_name" : "WinGoodbody",
      "indices" : [ 3, 15 ],
      "id_str" : "741121838",
      "id" : 741121838
    }, {
      "name" : "Josh Clark",
      "screen_name" : "bigmediumjosh",
      "indices" : [ 58, 72 ],
      "id_str" : "7552082",
      "id" : 7552082
    }, {
      "name" : "A Book Apart",
      "screen_name" : "abookapart",
      "indices" : [ 90, 101 ],
      "id_str" : "106418338",
      "id" : 106418338
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/wingoodbody\/status\/658382337936220164\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/el1FNOstvR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSMLP1sUAAAmqA6.jpg",
      "id_str" : "658382337265106944",
      "id" : 658382337265106944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSMLP1sUAAAmqA6.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 3280,
        "resize" : "fit",
        "w" : 4928
      } ],
      "display_url" : "pic.twitter.com\/el1FNOstvR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/sfwpjlivAP",
      "expanded_url" : "http:\/\/bit.ly\/1kFJC6r",
      "display_url" : "bit.ly\/1kFJC6r"
    } ]
  },
  "geo" : { },
  "id_str" : "658398143592067072",
  "text" : "RT @wingoodbody: Due out momentarily. DESIGNING FOR TOUCH @bigmediumjosh, latest in great @abookapart series. https:\/\/t.co\/sfwpjlivAP https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Clark",
        "screen_name" : "bigmediumjosh",
        "indices" : [ 41, 55 ],
        "id_str" : "7552082",
        "id" : 7552082
      }, {
        "name" : "A Book Apart",
        "screen_name" : "abookapart",
        "indices" : [ 73, 84 ],
        "id_str" : "106418338",
        "id" : 106418338
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/wingoodbody\/status\/658382337936220164\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/el1FNOstvR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSMLP1sUAAAmqA6.jpg",
        "id_str" : "658382337265106944",
        "id" : 658382337265106944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSMLP1sUAAAmqA6.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 3280,
          "resize" : "fit",
          "w" : 4928
        } ],
        "display_url" : "pic.twitter.com\/el1FNOstvR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/sfwpjlivAP",
        "expanded_url" : "http:\/\/bit.ly\/1kFJC6r",
        "display_url" : "bit.ly\/1kFJC6r"
      } ]
    },
    "geo" : { },
    "id_str" : "658382337936220164",
    "text" : "Due out momentarily. DESIGNING FOR TOUCH @bigmediumjosh, latest in great @abookapart series. https:\/\/t.co\/sfwpjlivAP https:\/\/t.co\/el1FNOstvR",
    "id" : 658382337936220164,
    "created_at" : "2015-10-25 20:39:16 +0000",
    "user" : {
      "name" : "Win Goodbody",
      "screen_name" : "WinGoodbody",
      "protected" : false,
      "id_str" : "741121838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650869304443842560\/PsStR__k_normal.jpg",
      "id" : 741121838,
      "verified" : false
    }
  },
  "id" : 658398143592067072,
  "created_at" : "2015-10-25 21:42:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Github Trending",
      "screen_name" : "TrendingGithub",
      "indices" : [ 3, 18 ],
      "id_str" : "3360844691",
      "id" : 3360844691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/xfpcUADVfU",
      "expanded_url" : "https:\/\/github.com\/getgrav\/grav-learn",
      "display_url" : "github.com\/getgrav\/grav-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658064398221598720",
  "text" : "RT @TrendingGithub: getgrav\/grav-learn: Grav Learn (exhaustive grav documentation) \u260524 https:\/\/t.co\/xfpcUADVfU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/github.com\/andygrunwald\/TrendingGithub\" rel=\"nofollow\"\u003ETrendingGithub\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/xfpcUADVfU",
        "expanded_url" : "https:\/\/github.com\/getgrav\/grav-learn",
        "display_url" : "github.com\/getgrav\/grav-l\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "658061305518100480",
    "text" : "getgrav\/grav-learn: Grav Learn (exhaustive grav documentation) \u260524 https:\/\/t.co\/xfpcUADVfU",
    "id" : 658061305518100480,
    "created_at" : "2015-10-24 23:23:36 +0000",
    "user" : {
      "name" : "Github Trending",
      "screen_name" : "TrendingGithub",
      "protected" : false,
      "id_str" : "3360844691",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620263843437125632\/pklcPmRO_normal.png",
      "id" : 3360844691,
      "verified" : false
    }
  },
  "id" : 658064398221598720,
  "created_at" : "2015-10-24 23:35:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/657704093834543104\/photo\/1",
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/ZpvSLNOChJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSCiYxlUkAQUWsk.png",
      "id_str" : "657704092106526724",
      "id" : 657704092106526724,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSCiYxlUkAQUWsk.png",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZpvSLNOChJ"
    } ],
    "hashtags" : [ {
      "text" : "php",
      "indices" : [ 103, 107 ]
    }, {
      "text" : "cms",
      "indices" : [ 108, 112 ]
    }, {
      "text" : "nodb",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/M07tnaMxYS",
      "expanded_url" : "http:\/\/getgrav.org\/downloads",
      "display_url" : "getgrav.org\/downloads"
    } ]
  },
  "geo" : { },
  "id_str" : "657705605637865472",
  "text" : "RT @getgrav: HUGE NEWS!!!\n\nGrav v1.0.0-rc.1 is released! https:\/\/t.co\/M07tnaMxYS\n\n(Admin plugin too!). #php #cms #nodb https:\/\/t.co\/ZpvSLNO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/getgrav\/status\/657704093834543104\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/ZpvSLNOChJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSCiYxlUkAQUWsk.png",
        "id_str" : "657704092106526724",
        "id" : 657704092106526724,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSCiYxlUkAQUWsk.png",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ZpvSLNOChJ"
      } ],
      "hashtags" : [ {
        "text" : "php",
        "indices" : [ 90, 94 ]
      }, {
        "text" : "cms",
        "indices" : [ 95, 99 ]
      }, {
        "text" : "nodb",
        "indices" : [ 100, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/M07tnaMxYS",
        "expanded_url" : "http:\/\/getgrav.org\/downloads",
        "display_url" : "getgrav.org\/downloads"
      } ]
    },
    "geo" : { },
    "id_str" : "657704093834543104",
    "text" : "HUGE NEWS!!!\n\nGrav v1.0.0-rc.1 is released! https:\/\/t.co\/M07tnaMxYS\n\n(Admin plugin too!). #php #cms #nodb https:\/\/t.co\/ZpvSLNOChJ",
    "id" : 657704093834543104,
    "created_at" : "2015-10-23 23:44:10 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 657705605637865472,
  "created_at" : "2015-10-23 23:50:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 71, 76 ]
    }, {
      "text" : "proflearn",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ZBMxISCwrc",
      "expanded_url" : "http:\/\/bit.ly\/1NhGFoP",
      "display_url" : "bit.ly\/1NhGFoP"
    } ]
  },
  "geo" : { },
  "id_str" : "657280162304667648",
  "text" : "RT @etug: The Agora project at UdG...What's that? Find out at the Fall #etug\nhttps:\/\/t.co\/ZBMxISCwrc #proflearn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 61, 66 ]
      }, {
        "text" : "proflearn",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/ZBMxISCwrc",
        "expanded_url" : "http:\/\/bit.ly\/1NhGFoP",
        "display_url" : "bit.ly\/1NhGFoP"
      } ]
    },
    "geo" : { },
    "id_str" : "657277459503579136",
    "text" : "The Agora project at UdG...What's that? Find out at the Fall #etug\nhttps:\/\/t.co\/ZBMxISCwrc #proflearn",
    "id" : 657277459503579136,
    "created_at" : "2015-10-22 19:28:52 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 657280162304667648,
  "created_at" : "2015-10-22 19:39:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EricaJoy",
      "screen_name" : "EricaJoy",
      "indices" : [ 3, 12 ],
      "id_str" : "817083",
      "id" : 817083
    }, {
      "name" : "Christopher Biscardi",
      "screen_name" : "chrisbiscardi",
      "indices" : [ 83, 97 ],
      "id_str" : "240315182",
      "id" : 240315182
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/EricaJoy\/status\/657265327974187008\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/3XP7mOYfEs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR8TVUpUYAAz2Yf.png",
      "id_str" : "657265327659573248",
      "id" : 657265327659573248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR8TVUpUYAAz2Yf.png",
      "sizes" : [ {
        "h" : 459,
        "resize" : "fit",
        "w" : 378
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 378
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 378
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3XP7mOYfEs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/MvbiBk437Y",
      "expanded_url" : "https:\/\/42floors.com\/blog\/startups\/thirty-percent-feedback",
      "display_url" : "42floors.com\/blog\/startups\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657271763273814016",
  "text" : "RT @EricaJoy: \"Thirty Percent Feedback\": https:\/\/t.co\/MvbiBk437Y\n\nI'm a fan.\n\n(h\/t @chrisbiscardi like a year ago) https:\/\/t.co\/3XP7mOYfEs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christopher Biscardi",
        "screen_name" : "chrisbiscardi",
        "indices" : [ 69, 83 ],
        "id_str" : "240315182",
        "id" : 240315182
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/EricaJoy\/status\/657265327974187008\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/3XP7mOYfEs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR8TVUpUYAAz2Yf.png",
        "id_str" : "657265327659573248",
        "id" : 657265327659573248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR8TVUpUYAAz2Yf.png",
        "sizes" : [ {
          "h" : 459,
          "resize" : "fit",
          "w" : 378
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 378
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 378
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3XP7mOYfEs"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/MvbiBk437Y",
        "expanded_url" : "https:\/\/42floors.com\/blog\/startups\/thirty-percent-feedback",
        "display_url" : "42floors.com\/blog\/startups\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657265327974187008",
    "text" : "\"Thirty Percent Feedback\": https:\/\/t.co\/MvbiBk437Y\n\nI'm a fan.\n\n(h\/t @chrisbiscardi like a year ago) https:\/\/t.co\/3XP7mOYfEs",
    "id" : 657265327974187008,
    "created_at" : "2015-10-22 18:40:40 +0000",
    "user" : {
      "name" : "EricaJoy",
      "screen_name" : "EricaJoy",
      "protected" : false,
      "id_str" : "817083",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757008500660670465\/88MAN6uw_normal.jpg",
      "id" : 817083,
      "verified" : true
    }
  },
  "id" : 657271763273814016,
  "created_at" : "2015-10-22 19:06:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 24, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/LHQnNjb05T",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/sfu-demofest2015-presentation",
      "display_url" : "hibbittsdesign.org\/blog\/sfu-demof\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657253896696426496",
  "text" : "Draft description of my #SFU DEMOFest 2015 flipped-LMS presentation\/case study https:\/\/t.co\/LHQnNjb05T",
  "id" : 657253896696426496,
  "created_at" : "2015-10-22 17:55:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/jNiLa5XFrQ",
      "expanded_url" : "http:\/\/getgrav.org\/blog\/approaching-grav-1.0",
      "display_url" : "getgrav.org\/blog\/approachi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657026732797521920",
  "text" : "RT @getgrav: New blog post: \"Approaching Grav 1.0\" - https:\/\/t.co\/jNiLa5XFrQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/jNiLa5XFrQ",
        "expanded_url" : "http:\/\/getgrav.org\/blog\/approaching-grav-1.0",
        "display_url" : "getgrav.org\/blog\/approachi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656979668789104640",
    "text" : "New blog post: \"Approaching Grav 1.0\" - https:\/\/t.co\/jNiLa5XFrQ",
    "id" : 656979668789104640,
    "created_at" : "2015-10-21 23:45:33 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 657026732797521920,
  "created_at" : "2015-10-22 02:52:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657003468339716096",
  "geo" : { },
  "id_str" : "657003729556631552",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Nice!",
  "id" : 657003729556631552,
  "in_reply_to_status_id" : 657003468339716096,
  "created_at" : "2015-10-22 01:21:10 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657002982886739968",
  "geo" : { },
  "id_str" : "657003430687338496",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro You could \uD83D\uDE00 Are you also thinking of positioning ELMS as both a standalone LMS and also in a flipped-LMS context?",
  "id" : 657003430687338496,
  "in_reply_to_status_id" : 657002982886739968,
  "created_at" : "2015-10-22 01:19:59 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656999131727040512",
  "geo" : { },
  "id_str" : "657003030458425344",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Indeed :-) Actually, that is another aspect of my flipped-LMS approach - front-end is hosted on GitHub to enable student contribs.",
  "id" : 657003030458425344,
  "in_reply_to_status_id" : 656999131727040512,
  "created_at" : "2015-10-22 01:18:23 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/THPxz8d1zY",
      "expanded_url" : "http:\/\/canvas.sfu.ca\/",
      "display_url" : "canvas.sfu.ca"
    } ]
  },
  "in_reply_to_status_id_str" : "657000725659062272",
  "geo" : { },
  "id_str" : "657001689384267776",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro In my experience yes as course ID and others are different each year but part of the URL is constant, i.e. https:\/\/t.co\/THPxz8d1zY",
  "id" : 657001689384267776,
  "in_reply_to_status_id" : 657000725659062272,
  "created_at" : "2015-10-22 01:13:03 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/Hsoe32qVJx",
      "expanded_url" : "https:\/\/github.com\/hibbitts-design\/hibbitts-design-org\/commits\/master\/pages\/blog\/2015-10-20-flipped-lms-defined",
      "display_url" : "github.com\/hibbitts-desig\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "656997775666581504",
  "geo" : { },
  "id_str" : "656998649788952576",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro https:\/\/t.co\/Hsoe32qVJx Though Gist looks easier to view \uD83D\uDE00",
  "id" : 656998649788952576,
  "in_reply_to_status_id" : 656997775666581504,
  "created_at" : "2015-10-22 01:00:59 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/QYEZCoTAvO",
      "expanded_url" : "http:\/\/hibbittsdesign.org",
      "display_url" : "hibbittsdesign.org"
    } ]
  },
  "in_reply_to_status_id_str" : "656997775666581504",
  "geo" : { },
  "id_str" : "656998512643588096",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro An interesting idea! I've already got the https:\/\/t.co\/QYEZCoTAvO site being pushed from Git so changes could be seen there too?",
  "id" : 656998512643588096,
  "in_reply_to_status_id" : 656997775666581504,
  "created_at" : "2015-10-22 01:00:26 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656997459600650240",
  "geo" : { },
  "id_str" : "656997920563007488",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Thanks, I will check it out!",
  "id" : 656997920563007488,
  "in_reply_to_status_id" : 656997459600650240,
  "created_at" : "2015-10-22 00:58:05 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/1PYhr6HGTm",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/redefining-a-flipped-lms-approach",
      "display_url" : "hibbittsdesign.org\/blog\/redefinin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656996006790193152",
  "text" : "Continuing to refine my definition (and live example) of a flipped-LMS approach... https:\/\/t.co\/1PYhr6HGTm",
  "id" : 656996006790193152,
  "created_at" : "2015-10-22 00:50:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Masterton",
      "screen_name" : "chris_masterton",
      "indices" : [ 3, 19 ],
      "id_str" : "80641764",
      "id" : 80641764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/WGQDPLi1AW",
      "expanded_url" : "http:\/\/mastertonux.com",
      "display_url" : "mastertonux.com"
    } ]
  },
  "geo" : { },
  "id_str" : "656959053596266496",
  "text" : "RT @chris_masterton: Today I'm re-launching my user experience consulting company as Masterton UX. Check out the new website: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/WGQDPLi1AW",
        "expanded_url" : "http:\/\/mastertonux.com",
        "display_url" : "mastertonux.com"
      } ]
    },
    "geo" : { },
    "id_str" : "656903139719680000",
    "text" : "Today I'm re-launching my user experience consulting company as Masterton UX. Check out the new website: https:\/\/t.co\/WGQDPLi1AW!",
    "id" : 656903139719680000,
    "created_at" : "2015-10-21 18:41:27 +0000",
    "user" : {
      "name" : "Chris Masterton",
      "screen_name" : "chris_masterton",
      "protected" : false,
      "id_str" : "80641764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656902856654491648\/lTomWIAm_normal.jpg",
      "id" : 80641764,
      "verified" : false
    }
  },
  "id" : 656959053596266496,
  "created_at" : "2015-10-21 22:23:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deploy",
      "screen_name" : "deployhq",
      "indices" : [ 101, 110 ],
      "id_str" : "180743261",
      "id" : 180743261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656944975997898752",
  "text" : "For anyone who is looking for a low-effort way to use GitHub along with a FTP host, GitHub Desktop + @deployhq works really well, and easy!",
  "id" : 656944975997898752,
  "created_at" : "2015-10-21 21:27:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 0, 9 ],
      "id_str" : "837060721",
      "id" : 837060721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656909296626569216",
  "geo" : { },
  "id_str" : "656912471517622272",
  "in_reply_to_user_id" : 837060721,
  "text" : "@m_travin That's great news Myra, congratulations and good luck!",
  "id" : 656912471517622272,
  "in_reply_to_status_id" : 656909296626569216,
  "created_at" : "2015-10-21 19:18:32 +0000",
  "in_reply_to_screen_name" : "m_travin",
  "in_reply_to_user_id_str" : "837060721",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/1PYhr6HGTm",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/redefining-a-flipped-lms-approach",
      "display_url" : "hibbittsdesign.org\/blog\/redefinin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656892932662800384",
  "text" : "Flipped-LMS (Re)Defined https:\/\/t.co\/1PYhr6HGTm",
  "id" : 656892932662800384,
  "created_at" : "2015-10-21 18:00:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "indices" : [ 0, 11 ],
      "id_str" : "27633854",
      "id" : 27633854
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 12, 19 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656647746892509184",
  "geo" : { },
  "id_str" : "656650485546401792",
  "in_reply_to_user_id" : 27633854,
  "text" : "@JustStormy @btopro Indeed. Deep-links (that support any needed user auth) is also a must-have on the LMS side. I know CanvasLMS has that.",
  "id" : 656650485546401792,
  "in_reply_to_status_id" : 656647746892509184,
  "created_at" : "2015-10-21 01:57:30 +0000",
  "in_reply_to_screen_name" : "JustStormy",
  "in_reply_to_user_id_str" : "27633854",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 0, 8 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656639591546404864",
  "geo" : { },
  "id_str" : "656642920334782464",
  "in_reply_to_user_id" : 15949844,
  "text" : "@getgrav Thanks!",
  "id" : 656642920334782464,
  "in_reply_to_status_id" : 656639591546404864,
  "created_at" : "2015-10-21 01:27:26 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 106, 114 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/mDJ9E4VNAs",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/",
      "display_url" : "hibbittsdesign.org"
    } ]
  },
  "geo" : { },
  "id_str" : "656639591546404864",
  "text" : "Sneak peek at a blog I've started with notes, thoughts &amp; experiments about my flipped-LMS approach w. @getgrav CMS. https:\/\/t.co\/mDJ9E4VNAs",
  "id" : 656639591546404864,
  "created_at" : "2015-10-21 01:14:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George",
      "screen_name" : "georgekroner",
      "indices" : [ 0, 13 ],
      "id_str" : "9128102",
      "id" : 9128102
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 14, 21 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656632180949569536",
  "geo" : { },
  "id_str" : "656638657038647297",
  "in_reply_to_user_id" : 9128102,
  "text" : "@georgekroner @btopro Perfect!",
  "id" : 656638657038647297,
  "in_reply_to_status_id" : 656632180949569536,
  "created_at" : "2015-10-21 01:10:30 +0000",
  "in_reply_to_screen_name" : "georgekroner",
  "in_reply_to_user_id_str" : "9128102",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie Bradshaw",
      "screen_name" : "LeslieBradshaw",
      "indices" : [ 3, 18 ],
      "id_str" : "1090561",
      "id" : 1090561
    }, {
      "name" : "Made by Many",
      "screen_name" : "madebymany",
      "indices" : [ 92, 103 ],
      "id_str" : "14374075",
      "id" : 14374075
    }, {
      "name" : "HJ Kwon",
      "screen_name" : "HatcheJota",
      "indices" : [ 132, 143 ],
      "id_str" : "252904749",
      "id" : 252904749
    }, {
      "name" : "Adam Brodowski",
      "screen_name" : "Brodowski",
      "indices" : [ 143, 144 ],
      "id_str" : "14260119",
      "id" : 14260119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/xUYfZjM4ah",
      "expanded_url" : "http:\/\/www.slideshare.net\/madebymany\/how-we-research-and-prototype-at-made-by-many",
      "display_url" : "slideshare.net\/madebymany\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656573404389076992",
  "text" : "RT @LeslieBradshaw: A lotta bang for your buck in this: \"How We Research &amp; Prototype at @MadeByMany\" https:\/\/t.co\/xUYfZjM4ah (\uD83D\uDE4C @HatcheJota\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Made by Many",
        "screen_name" : "madebymany",
        "indices" : [ 72, 83 ],
        "id_str" : "14374075",
        "id" : 14374075
      }, {
        "name" : "HJ Kwon",
        "screen_name" : "HatcheJota",
        "indices" : [ 112, 123 ],
        "id_str" : "252904749",
        "id" : 252904749
      }, {
        "name" : "Adam Brodowski",
        "screen_name" : "Brodowski",
        "indices" : [ 124, 134 ],
        "id_str" : "14260119",
        "id" : 14260119
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/xUYfZjM4ah",
        "expanded_url" : "http:\/\/www.slideshare.net\/madebymany\/how-we-research-and-prototype-at-made-by-many",
        "display_url" : "slideshare.net\/madebymany\/how\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656556869243293696",
    "text" : "A lotta bang for your buck in this: \"How We Research &amp; Prototype at @MadeByMany\" https:\/\/t.co\/xUYfZjM4ah (\uD83D\uDE4C @HatcheJota @Brodowski)",
    "id" : 656556869243293696,
    "created_at" : "2015-10-20 19:45:30 +0000",
    "user" : {
      "name" : "Leslie Bradshaw",
      "screen_name" : "LeslieBradshaw",
      "protected" : false,
      "id_str" : "1090561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740579018848735237\/dp1SYjmp_normal.jpg",
      "id" : 1090561,
      "verified" : false
    }
  },
  "id" : 656573404389076992,
  "created_at" : "2015-10-20 20:51:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656571420546232320",
  "text" : "A flipped-LMS is where an open platform, in the control of instructors and students, is an alternative front-end to the institutional LMS.",
  "id" : 656571420546232320,
  "created_at" : "2015-10-20 20:43:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 132, 139 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656556857931075585",
  "text" : "A flipped-LMS not only means an instructor chosen LMS front-end, but a flip of ownership with regards to the student experience. HT @btopro",
  "id" : 656556857931075585,
  "created_at" : "2015-10-20 19:45:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656551794919776256",
  "geo" : { },
  "id_str" : "656553125235462145",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro This dialog has me feeling better about the name as time goes on \uD83D\uDE00",
  "id" : 656553125235462145,
  "in_reply_to_status_id" : 656551794919776256,
  "created_at" : "2015-10-20 19:30:37 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656551794919776256",
  "geo" : { },
  "id_str" : "656552892921307137",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Thanks! The term has been used before but I only discovered this after I had named and created my CanvasLMS implementation :-)",
  "id" : 656552892921307137,
  "in_reply_to_status_id" : 656551794919776256,
  "created_at" : "2015-10-20 19:29:42 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "George",
      "screen_name" : "georgekroner",
      "indices" : [ 8, 21 ],
      "id_str" : "9128102",
      "id" : 9128102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656551361295851520",
  "geo" : { },
  "id_str" : "656551811587796992",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @georgekroner Helpful comments. Flip can not only an alternative front-end but also choice -&gt; instructor choice with inst. back-end.",
  "id" : 656551811587796992,
  "in_reply_to_status_id" : 656551361295851520,
  "created_at" : "2015-10-20 19:25:24 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "656551277862645760",
  "text" : "#SFU CMPT 363 week 6 materials, and Oct 26th class preparations, are now available on the course companion site at https:\/\/t.co\/I7fZ1cnbn3",
  "id" : 656551277862645760,
  "created_at" : "2015-10-20 19:23:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "George",
      "screen_name" : "georgekroner",
      "indices" : [ 8, 21 ],
      "id_str" : "9128102",
      "id" : 9128102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Cf10cOeCDY",
      "expanded_url" : "https:\/\/creately.com\/diagram\/if07z6b11\/Nr85UCBXA992344HmBhg5thqg%3D",
      "display_url" : "creately.com\/diagram\/if07z6\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "656286693574574084",
  "geo" : { },
  "id_str" : "656550758523924480",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @georgekroner Updated definition &amp; simple flowchart of flipped-LMS approach (still not sure of name...) https:\/\/t.co\/Cf10cOeCDY",
  "id" : 656550758523924480,
  "in_reply_to_status_id" : 656286693574574084,
  "created_at" : "2015-10-20 19:21:13 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Bowers",
      "screen_name" : "evilpez4",
      "indices" : [ 3, 12 ],
      "id_str" : "24085638",
      "id" : 24085638
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/evilpez4\/status\/656301322552156161\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/mrD6VGAvt2",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CRumj0mXIAIZnus.png",
      "id_str" : "656301305057714178",
      "id" : 656301305057714178,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CRumj0mXIAIZnus.png",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/mrD6VGAvt2"
    } ],
    "hashtags" : [ {
      "text" : "election2015",
      "indices" : [ 31, 44 ]
    }, {
      "text" : "elx42",
      "indices" : [ 45, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656333902026375168",
  "text" : "RT @evilpez4: CANADA, TONIGHT.\n#election2015 #elx42 https:\/\/t.co\/mrD6VGAvt2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/evilpez4\/status\/656301322552156161\/photo\/1",
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/mrD6VGAvt2",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CRumj0mXIAIZnus.png",
        "id_str" : "656301305057714178",
        "id" : 656301305057714178,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CRumj0mXIAIZnus.png",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 360
        } ],
        "display_url" : "pic.twitter.com\/mrD6VGAvt2"
      } ],
      "hashtags" : [ {
        "text" : "election2015",
        "indices" : [ 17, 30 ]
      }, {
        "text" : "elx42",
        "indices" : [ 31, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656301322552156161",
    "text" : "CANADA, TONIGHT.\n#election2015 #elx42 https:\/\/t.co\/mrD6VGAvt2",
    "id" : 656301322552156161,
    "created_at" : "2015-10-20 02:50:03 +0000",
    "user" : {
      "name" : "Andy Bowers",
      "screen_name" : "evilpez4",
      "protected" : false,
      "id_str" : "24085638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762335551697645568\/ACW1HfZY_normal.jpg",
      "id" : 24085638,
      "verified" : false
    }
  },
  "id" : 656333902026375168,
  "created_at" : "2015-10-20 04:59:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brackets",
      "screen_name" : "brackets",
      "indices" : [ 3, 12 ],
      "id_str" : "531428881",
      "id" : 531428881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/yeNOnjPBVV",
      "expanded_url" : "http:\/\/blog.brackets.io\/2015\/10\/15\/go-get-brackets-1-5\/",
      "display_url" : "blog.brackets.io\/2015\/10\/15\/go-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656241941667934208",
  "text" : "RT @brackets: Brackets 1.5 is available today! http:\/\/t.co\/yeNOnjPBVV Enhancements to code folding, lots of performance tweaks, and bug fix\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/yeNOnjPBVV",
        "expanded_url" : "http:\/\/blog.brackets.io\/2015\/10\/15\/go-get-brackets-1-5\/",
        "display_url" : "blog.brackets.io\/2015\/10\/15\/go-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654773052849262594",
    "text" : "Brackets 1.5 is available today! http:\/\/t.co\/yeNOnjPBVV Enhancements to code folding, lots of performance tweaks, and bug fixes.",
    "id" : 654773052849262594,
    "created_at" : "2015-10-15 21:37:15 +0000",
    "user" : {
      "name" : "Brackets",
      "screen_name" : "brackets",
      "protected" : false,
      "id_str" : "531428881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1915279008\/brackets_512_normal.png",
      "id" : 531428881,
      "verified" : false
    }
  },
  "id" : 656241941667934208,
  "created_at" : "2015-10-19 22:54:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "indices" : [ 3, 11 ],
      "id_str" : "15022225",
      "id" : 15022225
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 19, 22 ]
    }, {
      "text" : "Deliverables",
      "indices" : [ 23, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/PNvCrWbaRJ",
      "expanded_url" : "http:\/\/j.mp\/1Lj369L",
      "display_url" : "j.mp\/1Lj369L"
    } ]
  },
  "geo" : { },
  "id_str" : "656196386703020032",
  "text" : "RT @NNgroup: Which #UX #Deliverables Are Most Commonly Created and Shared? https:\/\/t.co\/PNvCrWbaRJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 6, 9 ]
      }, {
        "text" : "Deliverables",
        "indices" : [ 10, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/PNvCrWbaRJ",
        "expanded_url" : "http:\/\/j.mp\/1Lj369L",
        "display_url" : "j.mp\/1Lj369L"
      } ]
    },
    "geo" : { },
    "id_str" : "656195444490530816",
    "text" : "Which #UX #Deliverables Are Most Commonly Created and Shared? https:\/\/t.co\/PNvCrWbaRJ",
    "id" : 656195444490530816,
    "created_at" : "2015-10-19 19:49:20 +0000",
    "user" : {
      "name" : "Nielsen Norman Group",
      "screen_name" : "NNgroup",
      "protected" : false,
      "id_str" : "15022225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467725885949227008\/JTT0mnp4_normal.png",
      "id" : 15022225,
      "verified" : false
    }
  },
  "id" : 656196386703020032,
  "created_at" : "2015-10-19 19:53:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "indices" : [ 3, 10 ],
      "id_str" : "944913038",
      "id" : 944913038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VanUXAwards",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/FJUMuYYT5d",
      "expanded_url" : "http:\/\/bit.ly\/1u2Vixj",
      "display_url" : "bit.ly\/1u2Vixj"
    } ]
  },
  "geo" : { },
  "id_str" : "656194955841400832",
  "text" : "RT @Van_UE: You told us that you need more time for your #VanUXAwards so we've extended the deadline to Oct 24 11:59pm! Enter at http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VanUXAwards",
        "indices" : [ 45, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/FJUMuYYT5d",
        "expanded_url" : "http:\/\/bit.ly\/1u2Vixj",
        "display_url" : "bit.ly\/1u2Vixj"
      } ]
    },
    "geo" : { },
    "id_str" : "655516169114267648",
    "text" : "You told us that you need more time for your #VanUXAwards so we've extended the deadline to Oct 24 11:59pm! Enter at http:\/\/t.co\/FJUMuYYT5d",
    "id" : 655516169114267648,
    "created_at" : "2015-10-17 22:50:08 +0000",
    "user" : {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "protected" : false,
      "id_str" : "944913038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2842592785\/c138e36411049b83817c208ab9149c60_normal.png",
      "id" : 944913038,
      "verified" : false
    }
  },
  "id" : 656194955841400832,
  "created_at" : "2015-10-19 19:47:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Responsive Design",
      "screen_name" : "RWD",
      "indices" : [ 3, 7 ],
      "id_str" : "348664405",
      "id" : 348664405
    }, {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "indices" : [ 32, 45 ],
      "id_str" : "35943",
      "id" : 35943
    }, {
      "name" : "net magazine",
      "screen_name" : "netmag",
      "indices" : [ 117, 124 ],
      "id_str" : "17648193",
      "id" : 17648193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/mkVjmFC8eq",
      "expanded_url" : "https:\/\/twitter.com\/karenmcgrane\/status\/656121161059848193",
      "display_url" : "twitter.com\/karenmcgrane\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656179971853979648",
  "text" : "RT @RWD: So HEY. You know about @karenmcgrane\u2019s upcoming book, \u201CGoing Responsive\u201D\u2014yes? Ask her questions about it in @netmag! https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Karen McGrane",
        "screen_name" : "karenmcgrane",
        "indices" : [ 23, 36 ],
        "id_str" : "35943",
        "id" : 35943
      }, {
        "name" : "net magazine",
        "screen_name" : "netmag",
        "indices" : [ 108, 115 ],
        "id_str" : "17648193",
        "id" : 17648193
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/mkVjmFC8eq",
        "expanded_url" : "https:\/\/twitter.com\/karenmcgrane\/status\/656121161059848193",
        "display_url" : "twitter.com\/karenmcgrane\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656179390783594496",
    "text" : "So HEY. You know about @karenmcgrane\u2019s upcoming book, \u201CGoing Responsive\u201D\u2014yes? Ask her questions about it in @netmag! https:\/\/t.co\/mkVjmFC8eq",
    "id" : 656179390783594496,
    "created_at" : "2015-10-19 18:45:32 +0000",
    "user" : {
      "name" : "Responsive Design",
      "screen_name" : "RWD",
      "protected" : false,
      "id_str" : "348664405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539462074808561664\/PgmryUKs_normal.png",
      "id" : 348664405,
      "verified" : false
    }
  },
  "id" : 656179971853979648,
  "created_at" : "2015-10-19 18:47:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/QYEZCoTAvO",
      "expanded_url" : "http:\/\/hibbittsdesign.org",
      "display_url" : "hibbittsdesign.org"
    } ]
  },
  "geo" : { },
  "id_str" : "656150397313159168",
  "text" : "Sure it's a small step, but still exciting to have registered http:\/\/t.co\/QYEZCoTAvO for hosting the open source aspects of my work.",
  "id" : 656150397313159168,
  "created_at" : "2015-10-19 16:50:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Canada",
      "screen_name" : "HuffPostCanada",
      "indices" : [ 3, 18 ],
      "id_str" : "289998339",
      "id" : 289998339
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HuffPostCanada\/status\/656110569460801536\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/yhWR6PJBr5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRr5FguWEAA-28q.jpg",
      "id_str" : "656110568814809088",
      "id" : 656110568814809088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRr5FguWEAA-28q.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yhWR6PJBr5"
    } ],
    "hashtags" : [ {
      "text" : "elxn42",
      "indices" : [ 33, 40 ]
    }, {
      "text" : "cometogether",
      "indices" : [ 41, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656114333215141888",
  "text" : "RT @HuffPostCanada: Enough said. #elxn42 #cometogether http:\/\/t.co\/yhWR6PJBr5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HuffPostCanada\/status\/656110569460801536\/photo\/1",
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/yhWR6PJBr5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRr5FguWEAA-28q.jpg",
        "id_str" : "656110568814809088",
        "id" : 656110568814809088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRr5FguWEAA-28q.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yhWR6PJBr5"
      } ],
      "hashtags" : [ {
        "text" : "elxn42",
        "indices" : [ 13, 20 ]
      }, {
        "text" : "cometogether",
        "indices" : [ 21, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656110569460801536",
    "text" : "Enough said. #elxn42 #cometogether http:\/\/t.co\/yhWR6PJBr5",
    "id" : 656110569460801536,
    "created_at" : "2015-10-19 14:12:04 +0000",
    "user" : {
      "name" : "HuffPost Canada",
      "screen_name" : "HuffPostCanada",
      "protected" : false,
      "id_str" : "289998339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736245558659194883\/TrxBx9vi_normal.jpg",
      "id" : 289998339,
      "verified" : true
    }
  },
  "id" : 656114333215141888,
  "created_at" : "2015-10-19 14:27:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 3, 9 ],
      "id_str" : "14611891",
      "id" : 14611891
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "canpoli",
      "indices" : [ 107, 115 ]
    }, {
      "text" : "elxn42",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/C5GerbTSLe",
      "expanded_url" : "https:\/\/twitter.com\/toddsmithdesign\/status\/655801309682012160",
      "display_url" : "twitter.com\/toddsmithdesig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655888111755395072",
  "text" : "RT @mor10: The world will be a better place when people understand lower taxes \u2260 better lives for everyone #canpoli #elxn42  https:\/\/t.co\/C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "canpoli",
        "indices" : [ 96, 104 ]
      }, {
        "text" : "elxn42",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/C5GerbTSLe",
        "expanded_url" : "https:\/\/twitter.com\/toddsmithdesign\/status\/655801309682012160",
        "display_url" : "twitter.com\/toddsmithdesig\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "655810263740870656",
    "text" : "The world will be a better place when people understand lower taxes \u2260 better lives for everyone #canpoli #elxn42  https:\/\/t.co\/C5GerbTSLe",
    "id" : 655810263740870656,
    "created_at" : "2015-10-18 18:18:45 +0000",
    "user" : {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "protected" : false,
      "id_str" : "14611891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764557277084782592\/wf8yMQfN_normal.jpg",
      "id" : 14611891,
      "verified" : true
    }
  },
  "id" : 655888111755395072,
  "created_at" : "2015-10-18 23:28:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mapbox",
      "screen_name" : "Mapbox",
      "indices" : [ 3, 10 ],
      "id_str" : "55236002",
      "id" : 55236002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/LkZpll7RZY",
      "expanded_url" : "https:\/\/www.mapbox.com\/blog\/open-source-code-of-conduct\/",
      "display_url" : "mapbox.com\/blog\/open-sour\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655515607064932352",
  "text" : "RT @Mapbox: We're getting more serious about your safety and comfort in our spaces: https:\/\/t.co\/LkZpll7RZY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/LkZpll7RZY",
        "expanded_url" : "https:\/\/www.mapbox.com\/blog\/open-source-code-of-conduct\/",
        "display_url" : "mapbox.com\/blog\/open-sour\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "655061184018673664",
    "text" : "We're getting more serious about your safety and comfort in our spaces: https:\/\/t.co\/LkZpll7RZY",
    "id" : 655061184018673664,
    "created_at" : "2015-10-16 16:42:11 +0000",
    "user" : {
      "name" : "Mapbox",
      "screen_name" : "Mapbox",
      "protected" : false,
      "id_str" : "55236002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614644332956549120\/W8KtsoeZ_normal.png",
      "id" : 55236002,
      "verified" : true
    }
  },
  "id" : 655515607064932352,
  "created_at" : "2015-10-17 22:47:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/GtP2KC157n",
      "expanded_url" : "https:\/\/twitter.com\/uxmag\/status\/655049369129996288",
      "display_url" : "twitter.com\/uxmag\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655166748937859073",
  "text" : "One key reason why I decided several years ago to leverage my deep domain knowledge (education) with my UX practice. https:\/\/t.co\/GtP2KC157n",
  "id" : 655166748937859073,
  "created_at" : "2015-10-16 23:41:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655148973561266177",
  "text" : "With a flipped-LMS strategy, instructors can create better experiences for students &amp; themselves today. Deep-links to LMS only requirement.",
  "id" : 655148973561266177,
  "created_at" : "2015-10-16 22:31:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan M. Pierson",
      "screen_name" : "FrugalGeek",
      "indices" : [ 3, 14 ],
      "id_str" : "254187684",
      "id" : 254187684
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 123, 131 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WordPress",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/G1Yt2oKFCw",
      "expanded_url" : "http:\/\/getgrav.org\/",
      "display_url" : "getgrav.org"
    } ]
  },
  "geo" : { },
  "id_str" : "655140752771538944",
  "text" : "RT @FrugalGeek: If you feel that #WordPress is overkill for your next project, but you need it to be simple for users, try @getgrav http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 107, 115 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WordPress",
        "indices" : [ 17, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/G1Yt2oKFCw",
        "expanded_url" : "http:\/\/getgrav.org\/",
        "display_url" : "getgrav.org"
      } ]
    },
    "geo" : { },
    "id_str" : "654679678377066496",
    "text" : "If you feel that #WordPress is overkill for your next project, but you need it to be simple for users, try @getgrav http:\/\/t.co\/G1Yt2oKFCw",
    "id" : 654679678377066496,
    "created_at" : "2015-10-15 15:26:13 +0000",
    "user" : {
      "name" : "Ryan M. Pierson",
      "screen_name" : "FrugalGeek",
      "protected" : false,
      "id_str" : "254187684",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428957932684734464\/yHsG5Voh_normal.jpeg",
      "id" : 254187684,
      "verified" : false
    }
  },
  "id" : 655140752771538944,
  "created_at" : "2015-10-16 21:58:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655129510778572800",
  "text" : "UPDATE #2, desired qualities of a flipped-LMS approach:\nOpen (Platform + Data)\nCollaborative\nChoice (Instructor\/Student)\nPliable\nNetworked",
  "id" : 655129510778572800,
  "created_at" : "2015-10-16 21:13:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/xN6nyWMSvM",
      "expanded_url" : "https:\/\/www.usertesting.com\/blog\/2015\/10\/08\/11-tweet-sized-ux-tips-from-user-experience-pros\/",
      "display_url" : "usertesting.com\/blog\/2015\/10\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655124848839036928",
  "text" : "You can't design experiences, but you can design FOR them https:\/\/t.co\/xN6nyWMSvM",
  "id" : 655124848839036928,
  "created_at" : "2015-10-16 20:55:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nilofer Merchant",
      "screen_name" : "nilofer",
      "indices" : [ 3, 11 ],
      "id_str" : "12354252",
      "id" : 12354252
    }, {
      "name" : "Susan Crawford",
      "screen_name" : "scrawford",
      "indices" : [ 36, 46 ],
      "id_str" : "5502502",
      "id" : 5502502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/klkLWeT6EC",
      "expanded_url" : "https:\/\/medium.com\/backchannel\/getting-over-uber-fdf75faf7f6e?source=tw-lo_f90fe64b058e-1445028082276",
      "display_url" : "medium.com\/backchannel\/ge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655122456001183744",
  "text" : "RT @nilofer: \u201CGetting Over Uber\u201D by @scrawford https:\/\/t.co\/klkLWeT6EC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan Crawford",
        "screen_name" : "scrawford",
        "indices" : [ 23, 33 ],
        "id_str" : "5502502",
        "id" : 5502502
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/klkLWeT6EC",
        "expanded_url" : "https:\/\/medium.com\/backchannel\/getting-over-uber-fdf75faf7f6e?source=tw-lo_f90fe64b058e-1445028082276",
        "display_url" : "medium.com\/backchannel\/ge\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "655121392581611520",
    "text" : "\u201CGetting Over Uber\u201D by @scrawford https:\/\/t.co\/klkLWeT6EC",
    "id" : 655121392581611520,
    "created_at" : "2015-10-16 20:41:26 +0000",
    "user" : {
      "name" : "Nilofer Merchant",
      "screen_name" : "nilofer",
      "protected" : false,
      "id_str" : "12354252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648184730421194753\/jRUfWr6z_normal.jpg",
      "id" : 12354252,
      "verified" : true
    }
  },
  "id" : 655122456001183744,
  "created_at" : "2015-10-16 20:45:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655116102754660352",
  "text" : "(3\/3) In this session a flipped-LMS will be demonstrated, showing significant improvements to both the student and instructor experience.",
  "id" : 655116102754660352,
  "created_at" : "2015-10-16 20:20:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655113792649478145",
  "text" : "(2\/3) A flipped-LMS is an approach where an open platform, chosen by an instructor, provides an alternative front-end to any required LMS.",
  "id" : 655113792649478145,
  "created_at" : "2015-10-16 20:11:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655113759720013824",
  "text" : "(1\/3) Instructors, does this sound of interest? \"Flipping the LMS: Benefits &amp; lessons learned of using an alternative front-end to your LMS\"",
  "id" : 655113759720013824,
  "created_at" : "2015-10-16 20:11:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wisniewski",
      "screen_name" : "garywiz",
      "indices" : [ 3, 11 ],
      "id_str" : "22225828",
      "id" : 22225828
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 80, 88 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Docker",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Z36f3lWRbE",
      "expanded_url" : "https:\/\/hub.docker.com\/r\/garywiz\/docker-grav\/",
      "display_url" : "hub.docker.com\/r\/garywiz\/dock\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655111393545334784",
  "text" : "RT @garywiz: Just released 95MB #Docker image for Grav flat-file CMS (thanks to @getgrav)\nhttps:\/\/t.co\/Z36f3lWRbE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 67, 75 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Docker",
        "indices" : [ 19, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/Z36f3lWRbE",
        "expanded_url" : "https:\/\/hub.docker.com\/r\/garywiz\/docker-grav\/",
        "display_url" : "hub.docker.com\/r\/garywiz\/dock\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654791932397268993",
    "text" : "Just released 95MB #Docker image for Grav flat-file CMS (thanks to @getgrav)\nhttps:\/\/t.co\/Z36f3lWRbE",
    "id" : 654791932397268993,
    "created_at" : "2015-10-15 22:52:16 +0000",
    "user" : {
      "name" : "Gary Wisniewski",
      "screen_name" : "garywiz",
      "protected" : false,
      "id_str" : "22225828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663856265823518720\/nTQJWPge_normal.jpg",
      "id" : 22225828,
      "verified" : false
    }
  },
  "id" : 655111393545334784,
  "created_at" : "2015-10-16 20:01:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BCcampus\/status\/655102702414860289\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/47VZMg3CqY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRdkb9GWsAATKb9.jpg",
      "id_str" : "655102702226157568",
      "id" : 655102702226157568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRdkb9GWsAATKb9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 936
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 936
      } ],
      "display_url" : "pic.twitter.com\/47VZMg3CqY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/CYWFVFUOLf",
      "expanded_url" : "http:\/\/twitter.com\/BCOpenText\/status\/655098423755087872",
      "display_url" : "twitter.com\/BCOpenText\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655103040714702848",
  "text" : "RT @BCcampus: Happy Birthday B.C. Open Textbook Project! http:\/\/t.co\/CYWFVFUOLf http:\/\/t.co\/47VZMg3CqY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BCcampus\/status\/655102702414860289\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/47VZMg3CqY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRdkb9GWsAATKb9.jpg",
        "id_str" : "655102702226157568",
        "id" : 655102702226157568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRdkb9GWsAATKb9.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 936
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 936
        } ],
        "display_url" : "pic.twitter.com\/47VZMg3CqY"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/CYWFVFUOLf",
        "expanded_url" : "http:\/\/twitter.com\/BCOpenText\/status\/655098423755087872",
        "display_url" : "twitter.com\/BCOpenText\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "655102702414860289",
    "text" : "Happy Birthday B.C. Open Textbook Project! http:\/\/t.co\/CYWFVFUOLf http:\/\/t.co\/47VZMg3CqY",
    "id" : 655102702414860289,
    "created_at" : "2015-10-16 19:27:10 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 655103040714702848,
  "created_at" : "2015-10-16 19:28:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655076450358300672",
  "text" : "Here's a crazy thought, desired qualities of flipped-LMS = with positive learning environ.?\n\u2713Open\n\u2713Collaborative\n\u2713Pliable\n\u2713Choice\n\u2713Networked",
  "id" : 655076450358300672,
  "created_at" : "2015-10-16 17:42:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 29, 36 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655064179628376065",
  "text" : "UPDATED (thanks for feedback @btopro): desired qualities of a flipped-LMS approach:\nOpen\nCollaborative\nPliable\nInstructor Choice\nNetworked",
  "id" : 655064179628376065,
  "created_at" : "2015-10-16 16:54:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655061703919538177",
  "geo" : { },
  "id_str" : "655063196932308992",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Hmmm.. how about the word Pliable?",
  "id" : 655063196932308992,
  "in_reply_to_status_id" : 655061703919538177,
  "created_at" : "2015-10-16 16:50:11 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655061703919538177",
  "geo" : { },
  "id_str" : "655063007769178112",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Thanks for your thoughts, yes I can see that and experienced it first-hand with my work with Grav - key reason actually vs. Canvas",
  "id" : 655063007769178112,
  "in_reply_to_status_id" : 655061703919538177,
  "created_at" : "2015-10-16 16:49:26 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655059607241388033",
  "text" : "Working on the desired qualities of a flipped-LMS approach, so far I've got:\nOpen\nCollaborative\nInstructor Choice\nNetworked\n\nThe Anti-LMS?",
  "id" : 655059607241388033,
  "created_at" : "2015-10-16 16:35:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/allsecretdesign\/status\/654185822607048705\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/DMG4ATWhj3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRQiignUcAAOZew.png",
      "id_str" : "654185822141313024",
      "id" : 654185822141313024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRQiignUcAAOZew.png",
      "sizes" : [ {
        "h" : 168,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 472,
        "resize" : "fit",
        "w" : 956
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 472,
        "resize" : "fit",
        "w" : 956
      } ],
      "display_url" : "pic.twitter.com\/DMG4ATWhj3"
    } ],
    "hashtags" : [ {
      "text" : "webdesign",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/VW6LN3FOsp",
      "expanded_url" : "http:\/\/bit.ly\/1Mytleo",
      "display_url" : "bit.ly\/1Mytleo"
    } ]
  },
  "geo" : { },
  "id_str" : "654879143096520704",
  "text" : "RT @allsecretdesign: Designer's guide to Bootstrap 4.0. #webdesign http:\/\/t.co\/VW6LN3FOsp http:\/\/t.co\/DMG4ATWhj3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/allsecretdesign\/status\/654185822607048705\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/DMG4ATWhj3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRQiignUcAAOZew.png",
        "id_str" : "654185822141313024",
        "id" : 654185822141313024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRQiignUcAAOZew.png",
        "sizes" : [ {
          "h" : 168,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 472,
          "resize" : "fit",
          "w" : 956
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 472,
          "resize" : "fit",
          "w" : 956
        } ],
        "display_url" : "pic.twitter.com\/DMG4ATWhj3"
      } ],
      "hashtags" : [ {
        "text" : "webdesign",
        "indices" : [ 35, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/VW6LN3FOsp",
        "expanded_url" : "http:\/\/bit.ly\/1Mytleo",
        "display_url" : "bit.ly\/1Mytleo"
      } ]
    },
    "geo" : { },
    "id_str" : "654185822607048705",
    "text" : "Designer's guide to Bootstrap 4.0. #webdesign http:\/\/t.co\/VW6LN3FOsp http:\/\/t.co\/DMG4ATWhj3",
    "id" : 654185822607048705,
    "created_at" : "2015-10-14 06:43:48 +0000",
    "user" : {
      "name" : "Mybridge Design",
      "screen_name" : "Mybridge_Design",
      "protected" : false,
      "id_str" : "2589646069",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/698689527255162880\/yztC5b3J_normal.png",
      "id" : 2589646069,
      "verified" : false
    }
  },
  "id" : 654879143096520704,
  "created_at" : "2015-10-16 04:38:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/cHAUrrGXof",
      "expanded_url" : "https:\/\/twitter.com\/lukew\/status\/654770900328251392",
      "display_url" : "twitter.com\/lukew\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654774284133380096",
  "text" : "1995: \"Let's add an introductory Flash animation\" https:\/\/t.co\/cHAUrrGXof",
  "id" : 654774284133380096,
  "created_at" : "2015-10-15 21:42:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinboard",
      "screen_name" : "Pinboard",
      "indices" : [ 3, 12 ],
      "id_str" : "55525953",
      "id" : 55525953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654756409855225856",
  "text" : "RT @Pinboard: Two steps to better mobile design: 1) Make sure that the most critical elements of the page download and render first. 2) Sto\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653718038336794624",
    "text" : "Two steps to better mobile design: 1) Make sure that the most critical elements of the page download and render first. 2) Stop right there.",
    "id" : 653718038336794624,
    "created_at" : "2015-10-12 23:45:00 +0000",
    "user" : {
      "name" : "Pinboard",
      "screen_name" : "Pinboard",
      "protected" : false,
      "id_str" : "55525953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494414965\/logo_normal.png",
      "id" : 55525953,
      "verified" : false
    }
  },
  "id" : 654756409855225856,
  "created_at" : "2015-10-15 20:31:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654713988060606464",
  "text" : "Positive learner experience goals critical for a flipped-LMS approach:\n\u2713Convenient\n\u2713Engaging\n\u2713Frictionless\n\u2713Organized\n\u2713Relevant\n\u2713Enjoyable",
  "id" : 654713988060606464,
  "created_at" : "2015-10-15 17:42:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myra T Travin",
      "screen_name" : "m_travin",
      "indices" : [ 50, 59 ],
      "id_str" : "837060721",
      "id" : 837060721
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 103, 111 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654439697020665856",
  "text" : "What inspires me these days re: LX? The open Web, @m_travin's learning ecology framework, flipped-LMS, @getgrav, GitHub &amp; multi-device UX!",
  "id" : 654439697020665856,
  "created_at" : "2015-10-14 23:32:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bluejays",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654430794224549888",
  "text" : "Ok, watching this 7th inning was time well spent. #bluejays",
  "id" : 654430794224549888,
  "created_at" : "2015-10-14 22:57:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/1YUjxYWVUM",
      "expanded_url" : "http:\/\/www.caruso.com\/work\/dm-index\/digital-media-september-1992\/apples-multimedia-lab-a-linear-history\/",
      "display_url" : "caruso.com\/work\/dm-index\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654423887191519232",
  "text" : "Those unfamiliar w. Apple's leading work in the area of education, design, &amp; technology can start to learn more at: http:\/\/t.co\/1YUjxYWVUM",
  "id" : 654423887191519232,
  "created_at" : "2015-10-14 22:29:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654420948108492801",
  "text" : "While not labeled \"learner experience design\", my initial inspirations of combining UX with ID came from Apple's Edu work in the early 1990s",
  "id" : 654420948108492801,
  "created_at" : "2015-10-14 22:18:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654419101117341697",
  "text" : "Learner experience design is the combination of UX design, educational design, and technology development. All three domains are essential.",
  "id" : 654419101117341697,
  "created_at" : "2015-10-14 22:10:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 21, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654365256773337088",
  "text" : "A few of my favorite #UX design techniques for creating better learner experiences: empathy maps, scenarios, and content-first prototyping.",
  "id" : 654365256773337088,
  "created_at" : "2015-10-14 18:36:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/654358051672080384\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xZFbkW1BuC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRS_LgqUwAAdl48.png",
      "id_str" : "654358050342486016",
      "id" : 654358050342486016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRS_LgqUwAAdl48.png",
      "sizes" : [ {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 559,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xZFbkW1BuC"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/654358051672080384\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xZFbkW1BuC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRS_LfKUAAAWTRf.png",
      "id_str" : "654358049939783680",
      "id" : 654358049939783680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRS_LfKUAAAWTRf.png",
      "sizes" : [ {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 559,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xZFbkW1BuC"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/654358051672080384\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xZFbkW1BuC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRS_LgvUsAARg22.png",
      "id_str" : "654358050363453440",
      "id" : 654358050363453440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRS_LgvUsAARg22.png",
      "sizes" : [ {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 559,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      } ],
      "display_url" : "pic.twitter.com\/xZFbkW1BuC"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/654358051672080384\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xZFbkW1BuC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRS_LjxUkAA8Y4j.png",
      "id_str" : "654358051177140224",
      "id" : 654358051177140224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRS_LjxUkAA8Y4j.png",
      "sizes" : [ {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 559,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xZFbkW1BuC"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "654358051672080384",
  "text" : "#SFU CMPT 363 course companion updated: home page layout and viewing pages within #CanvasLMS. http:\/\/t.co\/I7fZ1cnbn3 http:\/\/t.co\/xZFbkW1BuC",
  "id" : 654358051672080384,
  "created_at" : "2015-10-14 18:08:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason toal",
      "screen_name" : "draggin",
      "indices" : [ 0, 8 ],
      "id_str" : "5690792",
      "id" : 5690792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654354370297860096",
  "geo" : { },
  "id_str" : "654355295326437377",
  "in_reply_to_user_id" : 5690792,
  "text" : "@draggin What's that odd-shaped object in the lower-right? \uD83D\uDE09",
  "id" : 654355295326437377,
  "in_reply_to_status_id" : 654354370297860096,
  "created_at" : "2015-10-14 17:57:14 +0000",
  "in_reply_to_screen_name" : "draggin",
  "in_reply_to_user_id_str" : "5690792",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elxn42",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654329768481964033",
  "text" : "How does a turnout of 3.6 million voters at advance polls happen? One vote at a time, including mine. Hoping for big #'s Monday. #elxn42",
  "id" : 654329768481964033,
  "created_at" : "2015-10-14 16:15:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654072282206244864",
  "text" : "RT @lukew: User research delivers insights, not answers.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654023522386243584",
    "text" : "User research delivers insights, not answers.",
    "id" : 654023522386243584,
    "created_at" : "2015-10-13 19:58:53 +0000",
    "user" : {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "protected" : false,
      "id_str" : "13889622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477610446917103616\/_cjU3_ga_normal.png",
      "id" : 13889622,
      "verified" : false
    }
  },
  "id" : 654072282206244864,
  "created_at" : "2015-10-13 23:12:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "indices" : [ 3, 10 ],
      "id_str" : "944913038",
      "id" : 944913038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VanUXAwards",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/nfFSsdGsTb",
      "expanded_url" : "http:\/\/ow.ly\/Tjbzv",
      "display_url" : "ow.ly\/Tjbzv"
    } ]
  },
  "geo" : { },
  "id_str" : "653994477174943744",
  "text" : "RT @Van_UE: The submission deadline for the #VanUXAwards has been extended! Check out our categories and submit your solution: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VanUXAwards",
        "indices" : [ 32, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/nfFSsdGsTb",
        "expanded_url" : "http:\/\/ow.ly\/Tjbzv",
        "display_url" : "ow.ly\/Tjbzv"
      } ]
    },
    "geo" : { },
    "id_str" : "653653992656998400",
    "text" : "The submission deadline for the #VanUXAwards has been extended! Check out our categories and submit your solution: http:\/\/t.co\/nfFSsdGsTb",
    "id" : 653653992656998400,
    "created_at" : "2015-10-12 19:30:30 +0000",
    "user" : {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "protected" : false,
      "id_str" : "944913038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2842592785\/c138e36411049b83817c208ab9149c60_normal.png",
      "id" : 944913038,
      "verified" : false
    }
  },
  "id" : 653994477174943744,
  "created_at" : "2015-10-13 18:03:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Cf10cOeCDY",
      "expanded_url" : "https:\/\/creately.com\/diagram\/if07z6b11\/Nr85UCBXA992344HmBhg5thqg%3D",
      "display_url" : "creately.com\/diagram\/if07z6\u2026"
    }, {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/V4gRb8kA5t",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "653992152670711808",
  "text" : "Interested in exploring my approach to a flipped-LMS? Definition + decision flow: https:\/\/t.co\/Cf10cOeCDY Example: http:\/\/t.co\/V4gRb8kA5t",
  "id" : 653992152670711808,
  "created_at" : "2015-10-13 17:54:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 122, 137 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/TcqSaG4MuQ",
      "expanded_url" : "https:\/\/storify.com\/paulhibbitts\/flipped-lms",
      "display_url" : "storify.com\/paulhibbitts\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652605184065966081",
  "text" : "Friday afternoon sneak peek at a new Storify: Student Feedback on CMPT-363 Flipped-LMS Design https:\/\/t.co\/TcqSaG4MuQ via @hibbittsdesign",
  "id" : 652605184065966081,
  "created_at" : "2015-10-09 22:02:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 0, 15 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 16, 24 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Storify",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/O9I44GKn8a",
      "expanded_url" : "http:\/\/sfy.co\/s0y6G",
      "display_url" : "sfy.co\/s0y6G"
    } ]
  },
  "geo" : { },
  "id_str" : "652604731123216384",
  "in_reply_to_user_id" : 15949844,
  "text" : "@hibbittsdesign @getgrav You've been quoted in my #Storify story \"Student Feedback on CMPT-363 Flipped-LMS Design\" http:\/\/t.co\/O9I44GKn8a",
  "id" : 652604731123216384,
  "created_at" : "2015-10-09 22:01:07 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652579963569238016",
  "text" : "(3\/3) Mic drop.",
  "id" : 652579963569238016,
  "created_at" : "2015-10-09 20:22:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 11, 19 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/nviMejZ7YY",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/home\/week-02",
      "display_url" : "cmpt-363-153.hibbittsdesign.com\/home\/week-02"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Afxb4jmLRI",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/home\/week-02\/displaypagecontentonly:true",
      "display_url" : "cmpt-363-153.hibbittsdesign.com\/home\/week-02\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652579930702680064",
  "text" : "(2\/3) With @getgrav, it is possible to display content with global nav. http:\/\/t.co\/nviMejZ7YY or just page content http:\/\/t.co\/Afxb4jmLRI",
  "id" : 652579930702680064,
  "created_at" : "2015-10-09 20:22:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652579879628640256",
  "text" : "(1\/3) With a flipped-LMS approach who may want to repurpose content within your alternative front-end site in the LMS, but w\/o global nav.",
  "id" : 652579879628640256,
  "created_at" : "2015-10-09 20:22:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 51, 59 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/652545179824451584\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ILLR5H2YjA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ5OYaoUwAABljG.jpg",
      "id_str" : "652545177387581440",
      "id" : 652545177387581440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ5OYaoUwAABljG.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ILLR5H2YjA"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/652545179824451584\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ILLR5H2YjA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ5OYhzVEAAM6SP.jpg",
      "id_str" : "652545179312787456",
      "id" : 652545179312787456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ5OYhzVEAAM6SP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ILLR5H2YjA"
    } ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652545179824451584",
  "text" : "Great example of the simple yet powerful nature of @getgrav. Pages shown within #CanvasLMS won't include external nav http:\/\/t.co\/ILLR5H2YjA",
  "id" : 652545179824451584,
  "created_at" : "2015-10-09 18:04:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Floro",
      "screen_name" : "nickfloro",
      "indices" : [ 3, 13 ],
      "id_str" : "15578710",
      "id" : 15578710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/NIbYujeUgO",
      "expanded_url" : "http:\/\/www.wired.com\/2015\/10\/adobes-new-project-comet-start-finish-website-design-app\/",
      "display_url" : "wired.com\/2015\/10\/adobes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652306046824804352",
  "text" : "RT @nickfloro: Adobe\u2019s Project Comet Is a Start-to-Finish UX Design App http:\/\/t.co\/NIbYujeUgO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/NIbYujeUgO",
        "expanded_url" : "http:\/\/www.wired.com\/2015\/10\/adobes-new-project-comet-start-finish-website-design-app\/",
        "display_url" : "wired.com\/2015\/10\/adobes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "652304841121923072",
    "text" : "Adobe\u2019s Project Comet Is a Start-to-Finish UX Design App http:\/\/t.co\/NIbYujeUgO",
    "id" : 652304841121923072,
    "created_at" : "2015-10-09 02:09:28 +0000",
    "user" : {
      "name" : "Nick Floro",
      "screen_name" : "nickfloro",
      "protected" : false,
      "id_str" : "15578710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/130051719\/Nick-Photo-Side_0508c_normal.jpg",
      "id" : 15578710,
      "verified" : false
    }
  },
  "id" : 652306046824804352,
  "created_at" : "2015-10-09 02:14:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652294092597039104",
  "geo" : { },
  "id_str" : "652295696750514177",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde You bet! Also mulling over if I should pitch this approach\/work as a session for the unconference ahead of time \uD83D\uDE00",
  "id" : 652295696750514177,
  "in_reply_to_status_id" : 652294092597039104,
  "created_at" : "2015-10-09 01:33:07 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 0, 13 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652265023629225985",
  "geo" : { },
  "id_str" : "652276643935858689",
  "in_reply_to_user_id" : 12991032,
  "text" : "@clintlalonde With your shift in focus perhaps we could chat\/meet sometime about my flipped-LMS work with the open source CMS Grav?",
  "id" : 652276643935858689,
  "in_reply_to_status_id" : 652265023629225985,
  "created_at" : "2015-10-09 00:17:25 +0000",
  "in_reply_to_screen_name" : "clintlalonde",
  "in_reply_to_user_id_str" : "12991032",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652245059522293760",
  "text" : "A flipped-LMS approach lets us leverage the best aspects of an LMS while giving the needed freedom to create outstanding learner experiences",
  "id" : 652245059522293760,
  "created_at" : "2015-10-08 22:11:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Canvas LMS",
      "screen_name" : "CanvasLMS",
      "indices" : [ 0, 10 ],
      "id_str" : "41847236",
      "id" : 41847236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652192851124621312",
  "in_reply_to_user_id" : 41847236,
  "text" : "@CanvasLMS Hope the ability to display external links within Modules is fixed soon in Android OS version! The iOS version does a great job \uD83D\uDC4D",
  "id" : 652192851124621312,
  "created_at" : "2015-10-08 18:44:27 +0000",
  "in_reply_to_screen_name" : "CanvasLMS",
  "in_reply_to_user_id_str" : "41847236",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 0, 10 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652187883000983552",
  "geo" : { },
  "id_str" : "652189386059046912",
  "in_reply_to_user_id" : 887742962,
  "text" : "@keroleenl True enough \uD83D\uDE00. Things came together quickly, and time-based unlocking of Modules prevents URL errors before pages are available!",
  "id" : 652189386059046912,
  "in_reply_to_status_id" : 652187883000983552,
  "created_at" : "2015-10-08 18:30:41 +0000",
  "in_reply_to_screen_name" : "keroleenl",
  "in_reply_to_user_id_str" : "887742962",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/agcvv8lvSf",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/22099",
      "display_url" : "canvas.sfu.ca\/courses\/22099"
    } ]
  },
  "geo" : { },
  "id_str" : "652188732213166080",
  "text" : "That's a wrap for now. Students already in #CanvasLMS now have one-tap access to weekly materials pages. https:\/\/t.co\/agcvv8lvSf. Simple.",
  "id" : 652188732213166080,
  "created_at" : "2015-10-08 18:28:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/652181236325048320\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/jqymf80jCc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ0DYFWUsAAyxce.jpg",
      "id_str" : "652181233326141440",
      "id" : 652181233326141440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ0DYFWUsAAyxce.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jqymf80jCc"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/652181236325048320\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/jqymf80jCc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ0DYNIUYAAXdf7.jpg",
      "id_str" : "652181235414884352",
      "id" : 652181235414884352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ0DYNIUYAAXdf7.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jqymf80jCc"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/652181236325048320\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/jqymf80jCc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ0DYGZUsAAFjpR.jpg",
      "id_str" : "652181233607159808",
      "id" : 652181233607159808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ0DYGZUsAAFjpR.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jqymf80jCc"
    } ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652181236325048320",
  "text" : "When a student uses mobile #CanvasLMS App things work out pretty well too. Modules can also be set as the Home page. http:\/\/t.co\/jqymf80jCc",
  "id" : 652181236325048320,
  "created_at" : "2015-10-08 17:58:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/652178928228921344\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/KCV7vkAopm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ0BR0gUwAADcLu.png",
      "id_str" : "652178926702215168",
      "id" : 652178926702215168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ0BR0gUwAADcLu.png",
      "sizes" : [ {
        "h" : 370,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 858,
        "resize" : "fit",
        "w" : 1392
      } ],
      "display_url" : "pic.twitter.com\/KCV7vkAopm"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/652178928228921344\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/KCV7vkAopm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ0BR3AUcAABxmC.png",
      "id_str" : "652178927373283328",
      "id" : 652178927373283328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ0BR3AUcAABxmC.png",
      "sizes" : [ {
        "h" : 370,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 858,
        "resize" : "fit",
        "w" : 1392
      } ],
      "display_url" : "pic.twitter.com\/KCV7vkAopm"
    } ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652178928228921344",
  "text" : "#CanvasLMS Modules could be the way to go. Provides a pre-built infrastructure and linking to external content. http:\/\/t.co\/KCV7vkAopm",
  "id" : 652178928228921344,
  "created_at" : "2015-10-08 17:49:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652177117468229632",
  "text" : "For a flipped-LMS approach to be viable, content duplication between systems must be avoided whenever possible. Make constraints your friend",
  "id" : 652177117468229632,
  "created_at" : "2015-10-08 17:41:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652171409779634176",
  "text" : "Today's design challenge is well underway already: increase content access within the back-end LMS for students more #CanvasLMS centric.",
  "id" : 652171409779634176,
  "created_at" : "2015-10-08 17:19:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SIAT",
      "screen_name" : "SIAT_SFU",
      "indices" : [ 3, 12 ],
      "id_str" : "45701038",
      "id" : 45701038
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SIAT_SFU\/status\/652168129770983424\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/r1fxHhws7t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQz3c_dVEAAZYui.jpg",
      "id_str" : "652168123504726016",
      "id" : 652168123504726016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQz3c_dVEAAZYui.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/r1fxHhws7t"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652169000877625344",
  "text" : "RT @SIAT_SFU: Happy Graduation folks. So happy to see your faces today! Meet at the highland pub after! http:\/\/t.co\/r1fxHhws7t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SIAT_SFU\/status\/652168129770983424\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/r1fxHhws7t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQz3c_dVEAAZYui.jpg",
        "id_str" : "652168123504726016",
        "id" : 652168123504726016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQz3c_dVEAAZYui.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/r1fxHhws7t"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "652168129770983424",
    "text" : "Happy Graduation folks. So happy to see your faces today! Meet at the highland pub after! http:\/\/t.co\/r1fxHhws7t",
    "id" : 652168129770983424,
    "created_at" : "2015-10-08 17:06:13 +0000",
    "user" : {
      "name" : "SIAT",
      "screen_name" : "SIAT_SFU",
      "protected" : false,
      "id_str" : "45701038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699362551369338880\/LDhtS1hi_normal.png",
      "id" : 45701038,
      "verified" : false
    }
  },
  "id" : 652169000877625344,
  "created_at" : "2015-10-08 17:09:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Dickerson",
      "screen_name" : "JosephDickerson",
      "indices" : [ 3, 19 ],
      "id_str" : "14407107",
      "id" : 14407107
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 51, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/nH6b0Sig21",
      "expanded_url" : "http:\/\/designmodo.com\/user-stories-ux\/",
      "display_url" : "designmodo.com\/user-stories-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651950902991962112",
  "text" : "RT @JosephDickerson: User Stories and Scenarios in #UX Design http:\/\/t.co\/nH6b0Sig21",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 30, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/nH6b0Sig21",
        "expanded_url" : "http:\/\/designmodo.com\/user-stories-ux\/",
        "display_url" : "designmodo.com\/user-stories-u\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651935643073949696",
    "text" : "User Stories and Scenarios in #UX Design http:\/\/t.co\/nH6b0Sig21",
    "id" : 651935643073949696,
    "created_at" : "2015-10-08 01:42:24 +0000",
    "user" : {
      "name" : "Joseph Dickerson",
      "screen_name" : "JosephDickerson",
      "protected" : false,
      "id_str" : "14407107",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759447022348800000\/PHzlcje1_normal.jpg",
      "id" : 14407107,
      "verified" : false
    }
  },
  "id" : 651950902991962112,
  "created_at" : "2015-10-08 02:43:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 8, 16 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    }, {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/B4dLmhsJN0",
      "expanded_url" : "https:\/\/twitter.com\/getgrav\/status\/651781744190853121",
      "display_url" : "twitter.com\/getgrav\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651909801027375104",
  "text" : "Hope my @getgrav powered CMPT 363 course companion makes it in. http:\/\/t.co\/I7fZ1cnbn3 https:\/\/t.co\/B4dLmhsJN0",
  "id" : 651909801027375104,
  "created_at" : "2015-10-07 23:59:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drupal",
      "screen_name" : "drupal",
      "indices" : [ 3, 10 ],
      "id_str" : "2166341",
      "id" : 2166341
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/drupal\/status\/649693453794811904\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/XayzPUVBk2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQQsv-pXAAA44Xk.jpg",
      "id_str" : "649693449030139904",
      "id" : 649693449030139904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQQsv-pXAAA44Xk.jpg",
      "sizes" : [ {
        "h" : 167,
        "resize" : "fit",
        "w" : 291
      }, {
        "h" : 167,
        "resize" : "fit",
        "w" : 291
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 167,
        "resize" : "fit",
        "w" : 291
      }, {
        "h" : 167,
        "resize" : "fit",
        "w" : 291
      } ],
      "display_url" : "pic.twitter.com\/XayzPUVBk2"
    } ],
    "hashtags" : [ {
      "text" : "Drupal8",
      "indices" : [ 32, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651899257180413952",
  "text" : "RT @drupal: It's official -&gt; #Drupal8 has ZERO Critical Issues! &lt;- \\o\/ Amazing! https:\/\/t.co\/XayzPUVBk2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/drupal\/status\/649693453794811904\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/XayzPUVBk2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQQsv-pXAAA44Xk.jpg",
        "id_str" : "649693449030139904",
        "id" : 649693449030139904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQQsv-pXAAA44Xk.jpg",
        "sizes" : [ {
          "h" : 167,
          "resize" : "fit",
          "w" : 291
        }, {
          "h" : 167,
          "resize" : "fit",
          "w" : 291
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 167,
          "resize" : "fit",
          "w" : 291
        }, {
          "h" : 167,
          "resize" : "fit",
          "w" : 291
        } ],
        "display_url" : "pic.twitter.com\/XayzPUVBk2"
      } ],
      "hashtags" : [ {
        "text" : "Drupal8",
        "indices" : [ 20, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649693453794811904",
    "text" : "It's official -&gt; #Drupal8 has ZERO Critical Issues! &lt;- \\o\/ Amazing! https:\/\/t.co\/XayzPUVBk2",
    "id" : 649693453794811904,
    "created_at" : "2015-10-01 21:12:44 +0000",
    "user" : {
      "name" : "Drupal",
      "screen_name" : "drupal",
      "protected" : false,
      "id_str" : "2166341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660852157827166208\/G36DKwIS_normal.jpg",
      "id" : 2166341,
      "verified" : true
    }
  },
  "id" : 651899257180413952,
  "created_at" : "2015-10-07 23:17:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 14, 18 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651870206734667776",
  "text" : "Presenting at #SFU #CanvasLMS DemoFest in November. Working title: Flipping the LMS: Benefits of Using an Alternative Front-end to Canvas.",
  "id" : 651870206734667776,
  "created_at" : "2015-10-07 21:22:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 82, 90 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/V4gRb8kA5t",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "651857155667046400",
  "text" : "Positive student feedback rekindles my idea of course companion template based on @getgrav. Streamlined version of http:\/\/t.co\/V4gRb8kA5t?",
  "id" : 651857155667046400,
  "created_at" : "2015-10-07 20:30:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651849411178266624",
  "text" : "Actively exploring options to help address each of those course companion concerns; Non SFU-URL, page speed, and travel to\/from #CanvasLMS",
  "id" : 651849411178266624,
  "created_at" : "2015-10-07 19:59:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651845762058313728",
  "text" : "Some student dislikes about CMPT 363 course companion:\nNon SFU-URL, harder to remember\nSlower page loads at times\nTravel to\/from #CanvasLMS",
  "id" : 651845762058313728,
  "created_at" : "2015-10-07 19:45:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 0, 10 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651833503676542980",
  "geo" : { },
  "id_str" : "651839679474479104",
  "in_reply_to_user_id" : 887742962,
  "text" : "@keroleenl ... \"It's nicely separated from Canvas such that I can see what's happening each week\" so I know I am making some progress \uD83D\uDE00",
  "id" : 651839679474479104,
  "in_reply_to_status_id" : 651833503676542980,
  "created_at" : "2015-10-07 19:21:04 +0000",
  "in_reply_to_screen_name" : "keroleenl",
  "in_reply_to_user_id_str" : "887742962",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 0, 10 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651833503676542980",
  "geo" : { },
  "id_str" : "651839280797515776",
  "in_reply_to_user_id" : 887742962,
  "text" : "@keroleenl FYI, a few student likes of the design: \"It links everything I need on Canvas\" and...",
  "id" : 651839280797515776,
  "in_reply_to_status_id" : 651833503676542980,
  "created_at" : "2015-10-07 19:19:29 +0000",
  "in_reply_to_screen_name" : "keroleenl",
  "in_reply_to_user_id_str" : "887742962",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651838805029203968",
  "text" : "(2\/2) Things students like the most about CMPT 363 course companion:\nMobile friendly\nClean\/simple layout\nFreq. updates\nAdditional resources",
  "id" : 651838805029203968,
  "created_at" : "2015-10-07 19:17:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651838767045603328",
  "text" : "(1\/2) Things students like the most about CMPT 363 course companion:\nKey materials are up front\nImportant reminders\nLive instructor chat",
  "id" : 651838767045603328,
  "created_at" : "2015-10-07 19:17:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 0, 10 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651833503676542980",
  "geo" : { },
  "id_str" : "651837537195978752",
  "in_reply_to_user_id" : 887742962,
  "text" : "@keroleenl Indeed, designing for reduction of friction between systems is critical. There are situations where dissatisfaction can result.",
  "id" : 651837537195978752,
  "in_reply_to_status_id" : 651833503676542980,
  "created_at" : "2015-10-07 19:12:34 +0000",
  "in_reply_to_screen_name" : "keroleenl",
  "in_reply_to_user_id_str" : "887742962",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 0, 10 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651827257426710528",
  "geo" : { },
  "id_str" : "651830073398444032",
  "in_reply_to_user_id" : 887742962,
  "text" : "@keroleenl Biggest likes:\nKey materials up-front\nImport. reminders\nLive instructor chat\nMobile friendly\nClean &amp; simple layout\nFreq. updates",
  "id" : 651830073398444032,
  "in_reply_to_status_id" : 651827257426710528,
  "created_at" : "2015-10-07 18:42:54 +0000",
  "in_reply_to_screen_name" : "keroleenl",
  "in_reply_to_user_id_str" : "887742962",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 0, 10 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651827257426710528",
  "geo" : { },
  "id_str" : "651829262647824384",
  "in_reply_to_user_id" : 887742962,
  "text" : "@keroleenl There will always be a certain level of friction with the approach, but tweaks are possible to further reduce it I think.",
  "id" : 651829262647824384,
  "in_reply_to_status_id" : 651827257426710528,
  "created_at" : "2015-10-07 18:39:41 +0000",
  "in_reply_to_screen_name" : "keroleenl",
  "in_reply_to_user_id_str" : "887742962",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 0, 10 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651827257426710528",
  "geo" : { },
  "id_str" : "651828884883673088",
  "in_reply_to_user_id" : 887742962,
  "text" : "@keroleenl For example, I am exploring now using Canvas Modules to provide direct links within Canvas to weekly course companion materials.",
  "id" : 651828884883673088,
  "in_reply_to_status_id" : 651827257426710528,
  "created_at" : "2015-10-07 18:38:11 +0000",
  "in_reply_to_screen_name" : "keroleenl",
  "in_reply_to_user_id_str" : "887742962",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 0, 10 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651827257426710528",
  "geo" : { },
  "id_str" : "651828553600753664",
  "in_reply_to_user_id" : 887742962,
  "text" : "@keroleenl It really came down to having to interact with two different systems, which I have an idea or two to make a bit easier.",
  "id" : 651828553600753664,
  "in_reply_to_status_id" : 651827257426710528,
  "created_at" : "2015-10-07 18:36:52 +0000",
  "in_reply_to_screen_name" : "keroleenl",
  "in_reply_to_user_id_str" : "887742962",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651813870609170432",
  "text" : "(7\/7) Based on these results a flipped-LMS approach shows a lot of promise for both my students (and myself), but work remains to be done.",
  "id" : 651813870609170432,
  "created_at" : "2015-10-07 17:38:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651813832302596096",
  "text" : "(6\/7) 6% of CMPT-363 students were undecided with regards to the same overall course companion design being used for other courses.",
  "id" : 651813832302596096,
  "created_at" : "2015-10-07 17:38:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651813783468310528",
  "text" : "(5\/7) 12.5% of CMPT-363 students indicated they would not want to see the same overall course companion design used for other courses.",
  "id" : 651813783468310528,
  "created_at" : "2015-10-07 17:38:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651813741919506436",
  "text" : "(4\/7) 81.5% students in CMPT-363 survey indicated they would like to see the same overall course companion design used for other courses.",
  "id" : 651813741919506436,
  "created_at" : "2015-10-07 17:38:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 32, 36 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "651813709669527552",
  "text" : "(3\/7) For my CMPT-363 course at #SFU, the Grav CMS is used as an improved &amp; open front-end for the #CanvasLMS http:\/\/t.co\/I7fZ1cnbn3",
  "id" : 651813709669527552,
  "created_at" : "2015-10-07 17:37:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651813675230081024",
  "text" : "(2\/7) Given this challenge, it's critical that students (&amp; instructors!) significantly benefit from what a flipped-LMS approach can provide.",
  "id" : 651813675230081024,
  "created_at" : "2015-10-07 17:37:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651813641155538944",
  "text" : "(1\/7) The #1 flipped-LMS challenge? Friction between the systems, especially when students would naturally prefer one system for everything.",
  "id" : 651813641155538944,
  "created_at" : "2015-10-07 17:37:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "651796506618388481",
  "text" : "Getting a series of tweets ready to share about what I think is the most important aspect of student feedback on http:\/\/t.co\/I7fZ1cnbn3.",
  "id" : 651796506618388481,
  "created_at" : "2015-10-07 16:29:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "indices" : [ 3, 11 ],
      "id_str" : "783092",
      "id" : 783092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "intranet",
      "indices" : [ 108, 117 ]
    }, {
      "text" : "enterprise",
      "indices" : [ 118, 129 ]
    }, {
      "text" : "edtech",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651790077048176640",
  "text" : "RT @benwerd: If you need to integrate a community space into your intranet or LMS, I'd love to talk to you. #intranet #enterprise #edtech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/werd.io\/\" rel=\"nofollow\"\u003Ewerd.io\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "intranet",
        "indices" : [ 95, 104 ]
      }, {
        "text" : "enterprise",
        "indices" : [ 105, 116 ]
      }, {
        "text" : "edtech",
        "indices" : [ 117, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651789155974811648",
    "text" : "If you need to integrate a community space into your intranet or LMS, I'd love to talk to you. #intranet #enterprise #edtech",
    "id" : 651789155974811648,
    "created_at" : "2015-10-07 16:00:19 +0000",
    "user" : {
      "name" : "Ben Werdm\u00FCller",
      "screen_name" : "benwerd",
      "protected" : false,
      "id_str" : "783092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681986174966104064\/t3BubQKk_normal.jpg",
      "id" : 783092,
      "verified" : true
    }
  },
  "id" : 651790077048176640,
  "created_at" : "2015-10-07 16:03:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 29, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651482976325275653",
  "text" : "To help set the mood, 60% of #SFU CMPT 363 students surveyed have used a mobile device (incl. tablets) to access the 363 course companion.",
  "id" : 651482976325275653,
  "created_at" : "2015-10-06 19:43:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "651482193726844928",
  "text" : "Student surveys are nerve-wracking but always a great learning opportunity. Will soon share student feedback of http:\/\/t.co\/I7fZ1cnbn3.",
  "id" : 651482193726844928,
  "created_at" : "2015-10-06 19:40:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 3, 12 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/Q2RES4yg4j",
      "expanded_url" : "https:\/\/deardesignstudent.com\/the-secret-cost-of-research-fbe95739afdd",
      "display_url" : "deardesignstudent.com\/the-secret-cos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651476046580060160",
  "text" : "RT @mulegirl: Having trouble convincing someone to use research in their product design?\n\nRead this: \n\nhttps:\/\/t.co\/Q2RES4yg4j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/Q2RES4yg4j",
        "expanded_url" : "https:\/\/deardesignstudent.com\/the-secret-cost-of-research-fbe95739afdd",
        "display_url" : "deardesignstudent.com\/the-secret-cos\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651421428139462656",
    "text" : "Having trouble convincing someone to use research in their product design?\n\nRead this: \n\nhttps:\/\/t.co\/Q2RES4yg4j",
    "id" : 651421428139462656,
    "created_at" : "2015-10-06 15:39:05 +0000",
    "user" : {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "protected" : false,
      "id_str" : "2391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741453032399867905\/1EV8JUJY_normal.jpg",
      "id" : 2391,
      "verified" : false
    }
  },
  "id" : 651476046580060160,
  "created_at" : "2015-10-06 19:16:08 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "651437433590956032",
  "text" : "#SFU CMPT 363 week 4 materials, and Oct 19th class preparations, are now available on the course companion site at http:\/\/t.co\/I7fZ1cnbn3",
  "id" : 651437433590956032,
  "created_at" : "2015-10-06 16:42:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 19, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ozzlLBJLjl",
      "expanded_url" : "https:\/\/twitter.com\/interacting\/status\/651019541720485888",
      "display_url" : "twitter.com\/interacting\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651177702582452225",
  "text" : "Good timing for my #SFU CMPT 363 class with our current user research assignment, which starts today. https:\/\/t.co\/ozzlLBJLjl",
  "id" : 651177702582452225,
  "created_at" : "2015-10-05 23:30:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "indices" : [ 3, 15 ],
      "id_str" : "19812150",
      "id" : 19812150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/PI6LBamBne",
      "expanded_url" : "http:\/\/wp.me\/pi2SZ-2Cn",
      "display_url" : "wp.me\/pi2SZ-2Cn"
    } ]
  },
  "geo" : { },
  "id_str" : "651175725567840260",
  "text" : "RT @drtonybates: See \"Reading between the lines: the \u2018intangibles\u2019 in quality online teaching and learning\" at: http:\/\/t.co\/PI6LBamBne",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/PI6LBamBne",
        "expanded_url" : "http:\/\/wp.me\/pi2SZ-2Cn",
        "display_url" : "wp.me\/pi2SZ-2Cn"
      } ]
    },
    "geo" : { },
    "id_str" : "650830803786567681",
    "text" : "See \"Reading between the lines: the \u2018intangibles\u2019 in quality online teaching and learning\" at: http:\/\/t.co\/PI6LBamBne",
    "id" : 650830803786567681,
    "created_at" : "2015-10-05 00:32:10 +0000",
    "user" : {
      "name" : "Tony Bates",
      "screen_name" : "drtonybates",
      "protected" : false,
      "id_str" : "19812150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2563456751\/wicaixr93w2lri2wsarw_normal.jpeg",
      "id" : 19812150,
      "verified" : false
    }
  },
  "id" : 651175725567840260,
  "created_at" : "2015-10-05 23:22:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Thurrott",
      "screen_name" : "thurrott",
      "indices" : [ 0, 9 ],
      "id_str" : "14964767",
      "id" : 14964767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651135929273311232",
  "geo" : { },
  "id_str" : "651136661842104320",
  "in_reply_to_user_id" : 14964767,
  "text" : "@thurrott I hope I do not need to use Safari, like some other company I know. \uD83D\uDE09",
  "id" : 651136661842104320,
  "in_reply_to_status_id" : 651135929273311232,
  "created_at" : "2015-10-05 20:47:32 +0000",
  "in_reply_to_screen_name" : "thurrott",
  "in_reply_to_user_id_str" : "14964767",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Maeda",
      "screen_name" : "johnmaeda",
      "indices" : [ 0, 10 ],
      "id_str" : "15414807",
      "id" : 15414807
    }, {
      "name" : "Daniel Shiffman",
      "screen_name" : "shiffman",
      "indices" : [ 11, 20 ],
      "id_str" : "14587429",
      "id" : 14587429
    }, {
      "name" : "Processing",
      "screen_name" : "ProcessingOrg",
      "indices" : [ 21, 35 ],
      "id_str" : "876624356",
      "id" : 876624356
    }, {
      "name" : "Ben Fry",
      "screen_name" : "ben_fry",
      "indices" : [ 36, 44 ],
      "id_str" : "46243602",
      "id" : 46243602
    }, {
      "name" : "Casey REAS",
      "screen_name" : "REAS",
      "indices" : [ 45, 50 ],
      "id_str" : "17634892",
      "id" : 17634892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651107627410153472",
  "geo" : { },
  "id_str" : "651108338441154560",
  "in_reply_to_user_id" : 15414807,
  "text" : "@johnmaeda @shiffman @ProcessingOrg @ben_fry @REAS Reminds me of having Don Norman on your Mac desktop back in the day \uD83D\uDE00",
  "id" : 651108338441154560,
  "in_reply_to_status_id" : 651107627410153472,
  "created_at" : "2015-10-05 18:54:59 +0000",
  "in_reply_to_screen_name" : "johnmaeda",
  "in_reply_to_user_id_str" : "15414807",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "indices" : [ 0, 11 ],
      "id_str" : "27633854",
      "id" : 27633854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651099358218350593",
  "geo" : { },
  "id_str" : "651099969449914368",
  "in_reply_to_user_id" : 27633854,
  "text" : "@JustStormy I'd say great description in 120 characters \uD83D\uDE00 Thanks very much for sharing, and good luck!",
  "id" : 651099969449914368,
  "in_reply_to_status_id" : 651099358218350593,
  "created_at" : "2015-10-05 18:21:44 +0000",
  "in_reply_to_screen_name" : "JustStormy",
  "in_reply_to_user_id_str" : "27633854",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "indices" : [ 3, 14 ],
      "id_str" : "27633854",
      "id" : 27633854
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 16, 31 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651099739186827264",
  "text" : "RT @JustStormy: @hibbittsdesign Mentioned our team ran across this idea and we could run in tandem w\/the rollout of LMSx and innovate rathe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 0, 15 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "651097518952988672",
    "geo" : { },
    "id_str" : "651099207496019968",
    "in_reply_to_user_id" : 15949844,
    "text" : "@hibbittsdesign Mentioned our team ran across this idea and we could run in tandem w\/the rollout of LMSx and innovate rather than stagnate",
    "id" : 651099207496019968,
    "in_reply_to_status_id" : 651097518952988672,
    "created_at" : "2015-10-05 18:18:42 +0000",
    "in_reply_to_screen_name" : "hibbittsdesign",
    "in_reply_to_user_id_str" : "15949844",
    "user" : {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "protected" : false,
      "id_str" : "27633854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766452852248109056\/nnq9NFSH_normal.jpg",
      "id" : 27633854,
      "verified" : false
    }
  },
  "id" : 651099739186827264,
  "created_at" : "2015-10-05 18:20:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "indices" : [ 0, 11 ],
      "id_str" : "27633854",
      "id" : 27633854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651095850333171712",
  "geo" : { },
  "id_str" : "651097518952988672",
  "in_reply_to_user_id" : 27633854,
  "text" : "@JustStormy Awesome \uD83D\uDE00 Any details you could share?",
  "id" : 651097518952988672,
  "in_reply_to_status_id" : 651095850333171712,
  "created_at" : "2015-10-05 18:11:59 +0000",
  "in_reply_to_screen_name" : "JustStormy",
  "in_reply_to_user_id_str" : "27633854",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "indices" : [ 3, 14 ],
      "id_str" : "27633854",
      "id" : 27633854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/Wi90ce4Crc",
      "expanded_url" : "http:\/\/creately.com\/diagram\/example\/if07z6b11",
      "display_url" : "creately.com\/diagram\/exampl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651097382969470976",
  "text" : "RT @JustStormy: just had a conversation with an exec committee about a Flipped LMS http:\/\/t.co\/Wi90ce4Crc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/Wi90ce4Crc",
        "expanded_url" : "http:\/\/creately.com\/diagram\/example\/if07z6b11",
        "display_url" : "creately.com\/diagram\/exampl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651095850333171712",
    "text" : "just had a conversation with an exec committee about a Flipped LMS http:\/\/t.co\/Wi90ce4Crc",
    "id" : 651095850333171712,
    "created_at" : "2015-10-05 18:05:22 +0000",
    "user" : {
      "name" : "Melissa Hicks",
      "screen_name" : "JustStormy",
      "protected" : false,
      "id_str" : "27633854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766452852248109056\/nnq9NFSH_normal.jpg",
      "id" : 27633854,
      "verified" : false
    }
  },
  "id" : 651097382969470976,
  "created_at" : "2015-10-05 18:11:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 80, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Q929eWIDKV",
      "expanded_url" : "http:\/\/oncourseworkshop.com\/life-long-learning\/spunki-reading-rubric-engages-students-course-content\/",
      "display_url" : "oncourseworkshop.com\/life-long-lear\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651080731679059969",
  "text" : "I always learn from student's reflective commentary using the SPUNKI rubric for #SFU CMPT 363 weekly reading. http:\/\/t.co\/Q929eWIDKV",
  "id" : 651080731679059969,
  "created_at" : "2015-10-05 17:05:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Korman",
      "screen_name" : "miniver",
      "indices" : [ 3, 11 ],
      "id_str" : "822441",
      "id" : 822441
    }, {
      "name" : "yerbasuena",
      "screen_name" : "yerbasuena",
      "indices" : [ 106, 117 ],
      "id_str" : "168570868",
      "id" : 168570868
    }, {
      "name" : "Fredrik Matheson",
      "screen_name" : "movito",
      "indices" : [ 118, 125 ],
      "id_str" : "700593",
      "id" : 700593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650829030850101249",
  "text" : "RT @miniver: To me the key that distinguishes design from styling or art is that design solves a problem\n\n@yerbasuena @movito",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "yerbasuena",
        "screen_name" : "yerbasuena",
        "indices" : [ 93, 104 ],
        "id_str" : "168570868",
        "id" : 168570868
      }, {
        "name" : "Fredrik Matheson",
        "screen_name" : "movito",
        "indices" : [ 105, 112 ],
        "id_str" : "700593",
        "id" : 700593
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "650734220789288960",
    "geo" : { },
    "id_str" : "650735143078920193",
    "in_reply_to_user_id" : 168570868,
    "text" : "To me the key that distinguishes design from styling or art is that design solves a problem\n\n@yerbasuena @movito",
    "id" : 650735143078920193,
    "in_reply_to_status_id" : 650734220789288960,
    "created_at" : "2015-10-04 18:12:02 +0000",
    "in_reply_to_screen_name" : "yerbasuena",
    "in_reply_to_user_id_str" : "168570868",
    "user" : {
      "name" : "Jonathan Korman",
      "screen_name" : "miniver",
      "protected" : false,
      "id_str" : "822441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750157227940392960\/vB7d5cM2_normal.jpg",
      "id" : 822441,
      "verified" : false
    }
  },
  "id" : 650829030850101249,
  "created_at" : "2015-10-05 00:25:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 11, 19 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/I7fZ1cnbn3",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com\/",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5Ezf5aFzpr",
      "expanded_url" : "https:\/\/github.com\/paulhibbitts\/cmpt-363-153-website",
      "display_url" : "github.com\/paulhibbitts\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650802600481193985",
  "text" : "Updates to @getgrav course companion: auto GitHub edit links &amp; sidebar now markdown file. http:\/\/t.co\/I7fZ1cnbn3 https:\/\/t.co\/5Ezf5aFzpr",
  "id" : 650802600481193985,
  "created_at" : "2015-10-04 22:40:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jisc",
      "screen_name" : "Jisc",
      "indices" : [ 3, 8 ],
      "id_str" : "18829580",
      "id" : 18829580
    }, {
      "name" : "Usborne Publishing",
      "screen_name" : "Usborne",
      "indices" : [ 11, 19 ],
      "id_str" : "55209561",
      "id" : 55209561
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Jisc\/status\/650699904021606400\/photo\/1",
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/YCCmypOHXp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQfAHXLXAAA-yEn.jpg",
      "id_str" : "650699903891603456",
      "id" : 650699903891603456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQfAHXLXAAA-yEn.jpg",
      "sizes" : [ {
        "h" : 533,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YCCmypOHXp"
    } ],
    "hashtags" : [ {
      "text" : "coding",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/22uae4gqpy",
      "expanded_url" : "http:\/\/bit.ly\/1M6jesK",
      "display_url" : "bit.ly\/1M6jesK"
    } ]
  },
  "geo" : { },
  "id_str" : "650708374217080832",
  "text" : "RT @Jisc: .@usborne's classic children's books on #coding are to be reprogrammed for a new generation http:\/\/t.co\/22uae4gqpy http:\/\/t.co\/YC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Usborne Publishing",
        "screen_name" : "Usborne",
        "indices" : [ 1, 9 ],
        "id_str" : "55209561",
        "id" : 55209561
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Jisc\/status\/650699904021606400\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/YCCmypOHXp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQfAHXLXAAA-yEn.jpg",
        "id_str" : "650699903891603456",
        "id" : 650699903891603456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQfAHXLXAAA-yEn.jpg",
        "sizes" : [ {
          "h" : 533,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/YCCmypOHXp"
      } ],
      "hashtags" : [ {
        "text" : "coding",
        "indices" : [ 40, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/22uae4gqpy",
        "expanded_url" : "http:\/\/bit.ly\/1M6jesK",
        "display_url" : "bit.ly\/1M6jesK"
      } ]
    },
    "geo" : { },
    "id_str" : "650699904021606400",
    "text" : ".@usborne's classic children's books on #coding are to be reprogrammed for a new generation http:\/\/t.co\/22uae4gqpy http:\/\/t.co\/YCCmypOHXp",
    "id" : 650699904021606400,
    "created_at" : "2015-10-04 15:52:01 +0000",
    "user" : {
      "name" : "Jisc",
      "screen_name" : "Jisc",
      "protected" : false,
      "id_str" : "18829580",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000659448543\/e7bbeb0b7a35fc45a48bdd76b5b491fd_normal.png",
      "id" : 18829580,
      "verified" : false
    }
  },
  "id" : 650708374217080832,
  "created_at" : "2015-10-04 16:25:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "indices" : [ 3, 15 ],
      "id_str" : "730373",
      "id" : 730373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650433872476307456",
  "text" : "RT @scottjenson: So many are screaming \"the desktop is DEAD\". Yes mobile is huge, but why must desktop DIE? The world is so much more inter\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650423420790837248",
    "text" : "So many are screaming \"the desktop is DEAD\". Yes mobile is huge, but why must desktop DIE? The world is so much more interesting and subtle",
    "id" : 650423420790837248,
    "created_at" : "2015-10-03 21:33:22 +0000",
    "user" : {
      "name" : "Scott JensOn",
      "screen_name" : "scottjenson",
      "protected" : false,
      "id_str" : "730373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576892785149628416\/FiovXOSs_normal.jpeg",
      "id" : 730373,
      "verified" : true
    }
  },
  "id" : 650433872476307456,
  "created_at" : "2015-10-03 22:14:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Bajarin",
      "screen_name" : "BenBajarin",
      "indices" : [ 3, 14 ],
      "id_str" : "14546264",
      "id" : 14546264
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BenBajarin\/status\/650089341692198912\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/EejWzrjKDa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQWUz5LUEAA675G.png",
      "id_str" : "650089340467417088",
      "id" : 650089340467417088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQWUz5LUEAA675G.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 633,
        "resize" : "fit",
        "w" : 923
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 633,
        "resize" : "fit",
        "w" : 923
      } ],
      "display_url" : "pic.twitter.com\/EejWzrjKDa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650090203856502786",
  "text" : "RT @BenBajarin: Significant year for iOS historically speaking. Potentially future speaking as well. http:\/\/t.co\/EejWzrjKDa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BenBajarin\/status\/650089341692198912\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/EejWzrjKDa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQWUz5LUEAA675G.png",
        "id_str" : "650089340467417088",
        "id" : 650089340467417088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQWUz5LUEAA675G.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 923
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 923
        } ],
        "display_url" : "pic.twitter.com\/EejWzrjKDa"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650089341692198912",
    "text" : "Significant year for iOS historically speaking. Potentially future speaking as well. http:\/\/t.co\/EejWzrjKDa",
    "id" : 650089341692198912,
    "created_at" : "2015-10-02 23:25:51 +0000",
    "user" : {
      "name" : "Ben Bajarin",
      "screen_name" : "BenBajarin",
      "protected" : false,
      "id_str" : "14546264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679174610315677696\/Fx4qZ9iE_normal.png",
      "id" : 14546264,
      "verified" : false
    }
  },
  "id" : 650090203856502786,
  "created_at" : "2015-10-02 23:29:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650049634019201024",
  "geo" : { },
  "id_str" : "650051174968590336",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Indeed, once you are not faced with a monolithic container for everything so many possibilities open up.",
  "id" : 650051174968590336,
  "in_reply_to_status_id" : 650049634019201024,
  "created_at" : "2015-10-02 20:54:12 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650049110179868672",
  "geo" : { },
  "id_str" : "650050753709535232",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Thanks! I find it important to reduce friction whenever possible for students to interact with me re: chat or feedback.",
  "id" : 650050753709535232,
  "in_reply_to_status_id" : 650049110179868672,
  "created_at" : "2015-10-02 20:52:31 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft Azure",
      "screen_name" : "Azure",
      "indices" : [ 98, 104 ],
      "id_str" : "17000457",
      "id" : 17000457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/nOFDZHJMgK",
      "expanded_url" : "https:\/\/azure.microsoft.com\/en-us\/blog\/new-deploy-to-windows-azure-web-sites-from-dropbox\/",
      "display_url" : "azure.microsoft.com\/en-us\/blog\/new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650049823639404544",
  "text" : "Deploy to Windows Azure Web Sites from Dropbox | Microsoft Azure Blog https:\/\/t.co\/nOFDZHJMgK via @azure",
  "id" : 650049823639404544,
  "created_at" : "2015-10-02 20:48:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650048923172605952",
  "text" : "A flipped-LMS approach means no student data needs to be stored in the front-end, so tools like DropBox can be used without FIPPA concerns.\uD83D\uDC4F",
  "id" : 650048923172605952,
  "created_at" : "2015-10-02 20:45:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft Azure",
      "screen_name" : "Azure",
      "indices" : [ 0, 6 ],
      "id_str" : "17000457",
      "id" : 17000457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/tVzDZALsd9",
      "expanded_url" : "http:\/\/cmpt-363-153-demo.azurewebsites.net\/",
      "display_url" : "cmpt-363-153-demo.azurewebsites.net"
    } ]
  },
  "geo" : { },
  "id_str" : "650047019164106752",
  "in_reply_to_user_id" : 17000457,
  "text" : "@Azure Is the response I am seeing with http:\/\/t.co\/tVzDZALsd9 (PHP flat-file CMS) representative of the \"Shared\" plan? Thanks!",
  "id" : 650047019164106752,
  "created_at" : "2015-10-02 20:37:41 +0000",
  "in_reply_to_screen_name" : "Azure",
  "in_reply_to_user_id_str" : "17000457",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/tVzDZALsd9",
      "expanded_url" : "http:\/\/cmpt-363-153-demo.azurewebsites.net\/",
      "display_url" : "cmpt-363-153-demo.azurewebsites.net"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/AJkejLsZt9",
      "expanded_url" : "https:\/\/www.dropbox.com\/sh\/wdvoupym42e3wp0\/AAD2TQU7oLLV3Vj7bBAJX7ySa?dl=0",
      "display_url" : "dropbox.com\/sh\/wdvoupym42e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650038998983835648",
  "text" : "Exploring DropBox as a simplified GitHub repository with Azure. Website: http:\/\/t.co\/tVzDZALsd9 Pages folder: https:\/\/t.co\/AJkejLsZt9",
  "id" : 650038998983835648,
  "created_at" : "2015-10-02 20:05:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 109, 117 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649990054211776513",
  "text" : "Unsure if \"Flipped-LMS\" is the right term for approach I developed to address #CanvasLMS weaknesses by using @getgrav front-end. Thoughts?",
  "id" : 649990054211776513,
  "created_at" : "2015-10-02 16:51:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/mNGXUmHPar",
      "expanded_url" : "https:\/\/twitter.com\/The_NthDegree\/status\/531933910255403008",
      "display_url" : "twitter.com\/The_NthDegree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649988207753367553",
  "text" : "I've been doing more research on the term \"Flipped-LMS\" and have come across some helpful articles, here is another: https:\/\/t.co\/mNGXUmHPar",
  "id" : 649988207753367553,
  "created_at" : "2015-10-02 16:43:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/p9HT6vltqn",
      "expanded_url" : "https:\/\/twitter.com\/weisblatt\/status\/523899681475010561",
      "display_url" : "twitter.com\/weisblatt\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649988104623816705",
  "text" : "I've been doing more research on the term \"Flipped-LMS\" and have come across some helpful articles, here is one: https:\/\/t.co\/p9HT6vltqn",
  "id" : 649988104623816705,
  "created_at" : "2015-10-02 16:43:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gchinn",
      "screen_name" : "gchinn",
      "indices" : [ 0, 7 ],
      "id_str" : "726453",
      "id" : 726453
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 8, 15 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649959687698411520",
  "geo" : { },
  "id_str" : "649983117160136704",
  "in_reply_to_user_id" : 726453,
  "text" : "@gchinn @btopro I look forward to it! Love to learn more about the study Bryan mentioned, and happy to share more about my flipped-LMS work.",
  "id" : 649983117160136704,
  "in_reply_to_status_id" : 649959687698411520,
  "created_at" : "2015-10-02 16:23:45 +0000",
  "in_reply_to_screen_name" : "gchinn",
  "in_reply_to_user_id_str" : "726453",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "indices" : [ 3, 18 ],
      "id_str" : "1122631",
      "id" : 1122631
    }, {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "indices" : [ 139, 140 ],
      "id_str" : "944913038",
      "id" : 944913038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VanUXAwards",
      "indices" : [ 25, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/lq5h71VfeA",
      "expanded_url" : "http:\/\/www.vancouveruxawards.com",
      "display_url" : "vancouveruxawards.com"
    } ]
  },
  "geo" : { },
  "id_str" : "649799238134558720",
  "text" : "RT @MalloryOConnor: 2015 #VanUXAwards tix are now on sale. Last year was awesome (and sold out) http:\/\/t.co\/lq5h71VfeA ps: submissions are \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VanUE",
        "screen_name" : "Van_UE",
        "indices" : [ 129, 136 ],
        "id_str" : "944913038",
        "id" : 944913038
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VanUXAwards",
        "indices" : [ 5, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/lq5h71VfeA",
        "expanded_url" : "http:\/\/www.vancouveruxawards.com",
        "display_url" : "vancouveruxawards.com"
      } ]
    },
    "geo" : { },
    "id_str" : "649793268763365381",
    "text" : "2015 #VanUXAwards tix are now on sale. Last year was awesome (and sold out) http:\/\/t.co\/lq5h71VfeA ps: submissions are open too! @Van_UE",
    "id" : 649793268763365381,
    "created_at" : "2015-10-02 03:49:22 +0000",
    "user" : {
      "name" : "Mallory O'Connor",
      "screen_name" : "MalloryOConnor",
      "protected" : false,
      "id_str" : "1122631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2261747531\/mallory_thumbnail_normal.png",
      "id" : 1122631,
      "verified" : false
    }
  },
  "id" : 649799238134558720,
  "created_at" : "2015-10-02 04:13:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tamara cameron",
      "screen_name" : "CameronTamara",
      "indices" : [ 0, 14 ],
      "id_str" : "937727672",
      "id" : 937727672
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 15, 23 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649707864961871872",
  "geo" : { },
  "id_str" : "649711316911853568",
  "in_reply_to_user_id" : 937727672,
  "text" : "@CameronTamara @getgrav Yes, as WP itself requires a database. Rather than try to make Grav into a LMS I prefer using Grav along with LMS.",
  "id" : 649711316911853568,
  "in_reply_to_status_id" : 649707864961871872,
  "created_at" : "2015-10-01 22:23:43 +0000",
  "in_reply_to_screen_name" : "CameronTamara",
  "in_reply_to_user_id_str" : "937727672",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 36, 44 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649706820290768897",
  "text" : "Just asked why I left WordPress for @getgrav - no DB hassles, easy custom templates w. Twig, modular content, GitHub friendly &amp; oh so fast!",
  "id" : 649706820290768897,
  "created_at" : "2015-10-01 22:05:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MortenRandHendriksen",
      "screen_name" : "mor10",
      "indices" : [ 0, 6 ],
      "id_str" : "14611891",
      "id" : 14611891
    }, {
      "name" : "Atom Editor",
      "screen_name" : "AtomEditor",
      "indices" : [ 83, 94 ],
      "id_str" : "2339397540",
      "id" : 2339397540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649701175374163968",
  "geo" : { },
  "id_str" : "649702429026455552",
  "in_reply_to_user_id" : 14611891,
  "text" : "@mor10 I've gone through two rounds of trying them all out and ended up preferring @AtomEditor on both Mac &amp; Surface. Brackets was #2 choice",
  "id" : 649702429026455552,
  "in_reply_to_status_id" : 649701175374163968,
  "created_at" : "2015-10-01 21:48:24 +0000",
  "in_reply_to_screen_name" : "mor10",
  "in_reply_to_user_id_str" : "14611891",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Sol",
      "screen_name" : "sdlieb",
      "indices" : [ 8, 15 ],
      "id_str" : "14351853",
      "id" : 14351853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649678686988423168",
  "geo" : { },
  "id_str" : "649679993912455168",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @sdlieb #CanvasLMS works well in this context too, as it supports user auth then automatically flows through to destination link.",
  "id" : 649679993912455168,
  "in_reply_to_status_id" : 649678686988423168,
  "created_at" : "2015-10-01 20:19:15 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sol",
      "screen_name" : "sdlieb",
      "indices" : [ 0, 7 ],
      "id_str" : "14351853",
      "id" : 14351853
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 8, 15 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649652951385010176",
  "geo" : { },
  "id_str" : "649678271576064000",
  "in_reply_to_user_id" : 14351853,
  "text" : "@sdlieb @btopro A key factor I should have mentioned earlier re: flipped-LMS, critical that only one URL needs to be provided to students.",
  "id" : 649678271576064000,
  "in_reply_to_status_id" : 649652951385010176,
  "created_at" : "2015-10-01 20:12:25 +0000",
  "in_reply_to_screen_name" : "sdlieb",
  "in_reply_to_user_id_str" : "14351853",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Balsamiq",
      "screen_name" : "balsamiq",
      "indices" : [ 0, 9 ],
      "id_str" : "14361698",
      "id" : 14361698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649674345392963584",
  "geo" : { },
  "id_str" : "649676539307556864",
  "in_reply_to_user_id" : 14361698,
  "text" : "@balsamiq Thanks for the update, I can certainly appreciate that \uD83D\uDE00",
  "id" : 649676539307556864,
  "in_reply_to_status_id" : 649674345392963584,
  "created_at" : "2015-10-01 20:05:32 +0000",
  "in_reply_to_screen_name" : "balsamiq",
  "in_reply_to_user_id_str" : "14361698",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Balsamiq",
      "screen_name" : "balsamiq",
      "indices" : [ 0, 9 ],
      "id_str" : "14361698",
      "id" : 14361698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/UbxlZG0e7W",
      "expanded_url" : "http:\/\/mybalsamiq.com",
      "display_url" : "mybalsamiq.com"
    } ]
  },
  "in_reply_to_status_id_str" : "649606768981614596",
  "geo" : { },
  "id_str" : "649668435748630529",
  "in_reply_to_user_id" : 14361698,
  "text" : "@balsamiq Awesome new feature! Any timeline when this quick drawing method will be available on https:\/\/t.co\/UbxlZG0e7W?",
  "id" : 649668435748630529,
  "in_reply_to_status_id" : 649606768981614596,
  "created_at" : "2015-10-01 19:33:19 +0000",
  "in_reply_to_screen_name" : "balsamiq",
  "in_reply_to_user_id_str" : "14361698",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 90, 98 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649657120841990144",
  "geo" : { },
  "id_str" : "649657876881895424",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Always happy to help the cause \uD83D\uDE00 For that course companion I used the open source @getgrav CMS for the front-end + #CanvasLMS.",
  "id" : 649657876881895424,
  "in_reply_to_status_id" : 649657120841990144,
  "created_at" : "2015-10-01 18:51:22 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Sol",
      "screen_name" : "sdlieb",
      "indices" : [ 8, 15 ],
      "id_str" : "14351853",
      "id" : 14351853
    }, {
      "name" : "gchinn",
      "screen_name" : "gchinn",
      "indices" : [ 66, 73 ],
      "id_str" : "726453",
      "id" : 726453
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenEd",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649656099780624384",
  "geo" : { },
  "id_str" : "649657190681214976",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @sdlieb  Would love to get a chance to meet and chat with @gchinn at #OpenEd in Vancouver!",
  "id" : 649657190681214976,
  "in_reply_to_status_id" : 649656099780624384,
  "created_at" : "2015-10-01 18:48:38 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/V4gRb8kA5t",
      "expanded_url" : "http:\/\/cmpt-363-153.hibbittsdesign.com",
      "display_url" : "cmpt-363-153.hibbittsdesign.com"
    } ]
  },
  "in_reply_to_status_id_str" : "649655781902680064",
  "geo" : { },
  "id_str" : "649656587791892480",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Thanks very much! Love that description\uD83D\uDE09 Here is my current course using a flipped-LMS approach: https:\/\/t.co\/V4gRb8kA5t",
  "id" : 649656587791892480,
  "in_reply_to_status_id" : 649655781902680064,
  "created_at" : "2015-10-01 18:46:15 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Sol",
      "screen_name" : "sdlieb",
      "indices" : [ 8, 15 ],
      "id_str" : "14351853",
      "id" : 14351853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649655026739191808",
  "geo" : { },
  "id_str" : "649655772859600896",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @sdlieb Very cool sounding study, would love to learn more if possible.",
  "id" : 649655772859600896,
  "in_reply_to_status_id" : 649655026739191808,
  "created_at" : "2015-10-01 18:43:00 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649654651311259649",
  "geo" : { },
  "id_str" : "649655562125209600",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro For me, flipped-LMS is using an open source platform of instructor's choice as student front-end, with deep-link to LMS elements.",
  "id" : 649655562125209600,
  "in_reply_to_status_id" : 649654651311259649,
  "created_at" : "2015-10-01 18:42:10 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 80, 87 ],
      "id_str" : "236846178",
      "id" : 236846178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649652967746994176",
  "geo" : { },
  "id_str" : "649654208807895040",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro By \"talking in residence\" what do you mean? Keep up the great work with @elmsln, love the approach!",
  "id" : 649654208807895040,
  "in_reply_to_status_id" : 649652967746994176,
  "created_at" : "2015-10-01 18:36:48 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sol",
      "screen_name" : "sdlieb",
      "indices" : [ 0, 7 ],
      "id_str" : "14351853",
      "id" : 14351853
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 8, 15 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Olark Live Chat",
      "screen_name" : "olark",
      "indices" : [ 16, 22 ],
      "id_str" : "21672965",
      "id" : 21672965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649652951385010176",
  "geo" : { },
  "id_str" : "649653704455393280",
  "in_reply_to_user_id" : 14351853,
  "text" : "@sdlieb @btopro @olark So far, so good it seems. Also getting additional student feedback next week and will share results.",
  "id" : 649653704455393280,
  "in_reply_to_status_id" : 649652951385010176,
  "created_at" : "2015-10-01 18:34:47 +0000",
  "in_reply_to_screen_name" : "sdlieb",
  "in_reply_to_user_id_str" : "14351853",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olark Live Chat",
      "screen_name" : "olark",
      "indices" : [ 95, 101 ],
      "id_str" : "21672965",
      "id" : 21672965
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 69, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649652410135089152",
  "text" : "A flipped-LMS approach lets you use the best tool for the job. E.g., #CanvasLMS peer reviews + @olark for real-time student chat\/questions.",
  "id" : 649652410135089152,
  "created_at" : "2015-10-01 18:29:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]