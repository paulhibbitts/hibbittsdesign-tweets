Grailbird.data.tweets_2016_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/XkvASPOevV",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-05-31-grav-cms-materials-for-festival-of-learning-2016",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737782425783144448",
  "text" : "Sneak peek at my upcoming blog post 'Grav CMS Materials for the 2016 Festival of Learning': https:\/\/t.co\/XkvASPOevV",
  "id" : 737782425783144448,
  "created_at" : "2016-05-31 23:06:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 26, 34 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/tv9q3n8Pxr",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/",
      "display_url" : "hibbittsdesign.org\/blog\/"
    } ]
  },
  "geo" : { },
  "id_str" : "737753529901711360",
  "text" : "Coolio, my little blog of @getgrav and open source learning environments reached a milestone today: +900 visits\/mo.\uD83C\uDF86 https:\/\/t.co\/tv9q3n8Pxr",
  "id" : 737753529901711360,
  "created_at" : "2016-05-31 21:12:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 19, 27 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737713747398033408",
  "text" : "By the looks of it @getgrav Course Hub package is all set for the pending release of Grav 1.1, which includes a nice Admin Panel update too.",
  "id" : 737713747398033408,
  "created_at" : "2016-05-31 18:33:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/737698515070001152\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/vKRhlFnOvv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjzU4-1VEAA3x5n.jpg",
      "id_str" : "737698514386358272",
      "id" : 737698514386358272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjzU4-1VEAA3x5n.jpg",
      "sizes" : [ {
        "h" : 619,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 778
      } ],
      "display_url" : "pic.twitter.com\/vKRhlFnOvv"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 83, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737698515070001152",
  "text" : "Update of design process\/toolkit diagram for my introductory UX course CMPT 363 at #SFU, CC-licensed for all to use. https:\/\/t.co\/vKRhlFnOvv",
  "id" : 737698515070001152,
  "created_at" : "2016-05-31 17:33:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737653998593933312",
  "geo" : { },
  "id_str" : "737688492474437632",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Your 90's sounds a lot like my 80's \uD83D\uDE09",
  "id" : 737688492474437632,
  "in_reply_to_status_id" : 737653998593933312,
  "created_at" : "2016-05-31 16:53:36 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/clintlalonde\/status\/737409239858040833\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/tBDejhmEcX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjvNy9OUoAED_b1.jpg",
      "id_str" : "737409239316996097",
      "id" : 737409239316996097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjvNy9OUoAED_b1.jpg",
      "sizes" : [ {
        "h" : 402,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 686,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 686,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tBDejhmEcX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/Ff7No9LGfs",
      "expanded_url" : "http:\/\/clintlalonde.net\/2016\/05\/30\/sandstorm-apps-and-grains\/",
      "display_url" : "clintlalonde.net\/2016\/05\/30\/san\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737412327583014912",
  "text" : "RT @clintlalonde: Sandstorm Apps and\u00A0Grains https:\/\/t.co\/Ff7No9LGfs https:\/\/t.co\/tBDejhmEcX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/clintlalonde\/status\/737409239858040833\/photo\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/tBDejhmEcX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjvNy9OUoAED_b1.jpg",
        "id_str" : "737409239316996097",
        "id" : 737409239316996097,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjvNy9OUoAED_b1.jpg",
        "sizes" : [ {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 686,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 686,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tBDejhmEcX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/Ff7No9LGfs",
        "expanded_url" : "http:\/\/clintlalonde.net\/2016\/05\/30\/sandstorm-apps-and-grains\/",
        "display_url" : "clintlalonde.net\/2016\/05\/30\/san\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "737409239858040833",
    "text" : "Sandstorm Apps and\u00A0Grains https:\/\/t.co\/Ff7No9LGfs https:\/\/t.co\/tBDejhmEcX",
    "id" : 737409239858040833,
    "created_at" : "2016-05-30 22:23:57 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 737412327583014912,
  "created_at" : "2016-05-30 22:36:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Practical Dev",
      "screen_name" : "ThePracticalDev",
      "indices" : [ 3, 19 ],
      "id_str" : "2735246778",
      "id" : 2735246778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/rIeBpd3Maf",
      "expanded_url" : "https:\/\/medium.com\/@billjordan1\/the-quiet-crisis-unfolding-in-software-development-cffbdafbf450#.mbwt7vvv5",
      "display_url" : "medium.com\/@billjordan1\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737323652333506560",
  "text" : "RT @ThePracticalDev: The Quiet Crisis unfolding in Software Development https:\/\/t.co\/rIeBpd3Maf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/rIeBpd3Maf",
        "expanded_url" : "https:\/\/medium.com\/@billjordan1\/the-quiet-crisis-unfolding-in-software-development-cffbdafbf450#.mbwt7vvv5",
        "display_url" : "medium.com\/@billjordan1\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "736568757427015680",
    "text" : "The Quiet Crisis unfolding in Software Development https:\/\/t.co\/rIeBpd3Maf",
    "id" : 736568757427015680,
    "created_at" : "2016-05-28 14:44:11 +0000",
    "user" : {
      "name" : "The Practical Dev",
      "screen_name" : "ThePracticalDev",
      "protected" : false,
      "id_str" : "2735246778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729074483626151937\/V8wcTT9F_normal.jpg",
      "id" : 2735246778,
      "verified" : false
    }
  },
  "id" : 737323652333506560,
  "created_at" : "2016-05-30 16:43:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus Open",
      "screen_name" : "BCOpenText",
      "indices" : [ 3, 14 ],
      "id_str" : "3148543346",
      "id" : 3148543346
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 121, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/1guCpF7Z7W",
      "expanded_url" : "http:\/\/ow.ly\/uY6X300ABjZ",
      "display_url" : "ow.ly\/uY6X300ABjZ"
    } ]
  },
  "geo" : { },
  "id_str" : "736992857844654080",
  "text" : "RT @BCOpenText: Reminder: Registration closes today for the Festival of Learning. Register here: https:\/\/t.co\/1guCpF7Z7W #FoL16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 105, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/1guCpF7Z7W",
        "expanded_url" : "http:\/\/ow.ly\/uY6X300ABjZ",
        "display_url" : "ow.ly\/uY6X300ABjZ"
      } ]
    },
    "geo" : { },
    "id_str" : "736991832618467328",
    "text" : "Reminder: Registration closes today for the Festival of Learning. Register here: https:\/\/t.co\/1guCpF7Z7W #FoL16",
    "id" : 736991832618467328,
    "created_at" : "2016-05-29 18:45:20 +0000",
    "user" : {
      "name" : "BCcampus Open",
      "screen_name" : "BCOpenText",
      "protected" : false,
      "id_str" : "3148543346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587706251347243009\/BA0taxiM_normal.jpg",
      "id" : 3148543346,
      "verified" : false
    }
  },
  "id" : 736992857844654080,
  "created_at" : "2016-05-29 18:49:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "markdown",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/N1ByiZqH7Z",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-05-26-creating-slides-in-markdown",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736694189207883777",
  "text" : "Perhaps some light reading about using #markdown to create on-line fully responsive slides strikes your fancy? https:\/\/t.co\/N1ByiZqH7Z",
  "id" : 736694189207883777,
  "created_at" : "2016-05-28 23:02:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mehdi Medjaoui",
      "screen_name" : "medjawii",
      "indices" : [ 3, 12 ],
      "id_str" : "224653586",
      "id" : 224653586
    }, {
      "name" : "Kin Lane",
      "screen_name" : "kinlane",
      "indices" : [ 33, 41 ],
      "id_str" : "5954192",
      "id" : 5954192
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medjawii\/status\/736239997183918081\/photo\/1",
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/ekgrJLWTJ9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjemYEMVEAACUnA.jpg",
      "id_str" : "736239996470890496",
      "id" : 736239996470890496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjemYEMVEAACUnA.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/ekgrJLWTJ9"
    } ],
    "hashtags" : [ {
      "text" : "HelpAllAPIEvangelists",
      "indices" : [ 99, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736693526289731584",
  "text" : "RT @medjawii: Almost $29,000 for @kinLane, let's cross the $30,000 bar with velocity! We can do it.#HelpAllAPIEvangelists https:\/\/t.co\/ekgr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kin Lane",
        "screen_name" : "kinlane",
        "indices" : [ 19, 27 ],
        "id_str" : "5954192",
        "id" : 5954192
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medjawii\/status\/736239997183918081\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/ekgrJLWTJ9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjemYEMVEAACUnA.jpg",
        "id_str" : "736239996470890496",
        "id" : 736239996470890496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjemYEMVEAACUnA.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/ekgrJLWTJ9"
      } ],
      "hashtags" : [ {
        "text" : "HelpAllAPIEvangelists",
        "indices" : [ 85, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736239997183918081",
    "text" : "Almost $29,000 for @kinLane, let's cross the $30,000 bar with velocity! We can do it.#HelpAllAPIEvangelists https:\/\/t.co\/ekgrJLWTJ9",
    "id" : 736239997183918081,
    "created_at" : "2016-05-27 16:57:48 +0000",
    "user" : {
      "name" : "Mehdi Medjaoui",
      "screen_name" : "medjawii",
      "protected" : false,
      "id_str" : "224653586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577112958792138754\/UBS22GTX_normal.jpeg",
      "id" : 224653586,
      "verified" : false
    }
  },
  "id" : 736693526289731584,
  "created_at" : "2016-05-28 22:59:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Skelton",
      "screen_name" : "bskelton",
      "indices" : [ 0, 9 ],
      "id_str" : "644813",
      "id" : 644813
    }, {
      "name" : "Habanero",
      "screen_name" : "HabaneroConsult",
      "indices" : [ 10, 26 ],
      "id_str" : "17349291",
      "id" : 17349291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736667669739536384",
  "geo" : { },
  "id_str" : "736670677311180801",
  "in_reply_to_user_id" : 644813,
  "text" : "@bskelton @HabaneroConsult \uD83D\uDC4D Awesome, thanks for sharing your thoughts  - appreciated! BTW, 'strategy' was assumed earlier &amp; now in diagram.",
  "id" : 736670677311180801,
  "in_reply_to_status_id" : 736667669739536384,
  "created_at" : "2016-05-28 21:29:10 +0000",
  "in_reply_to_screen_name" : "bskelton",
  "in_reply_to_user_id_str" : "644813",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Skelton",
      "screen_name" : "bskelton",
      "indices" : [ 0, 9 ],
      "id_str" : "644813",
      "id" : 644813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/cNL9Xmx8xg",
      "expanded_url" : "https:\/\/twitter.com\/hibbittsdesign\/status\/736577191283036161",
      "display_url" : "twitter.com\/hibbittsdesign\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "736662969963057153",
  "geo" : { },
  "id_str" : "736664169982787584",
  "in_reply_to_user_id" : 15949844,
  "text" : "@bskelton Hey, while we are chatting any comments on this? https:\/\/t.co\/cNL9Xmx8xg Esp. putting strategy after initial research (iterative).",
  "id" : 736664169982787584,
  "in_reply_to_status_id" : 736662969963057153,
  "created_at" : "2016-05-28 21:03:19 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Skelton",
      "screen_name" : "bskelton",
      "indices" : [ 0, 9 ],
      "id_str" : "644813",
      "id" : 644813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736662418433179648",
  "geo" : { },
  "id_str" : "736662969963057153",
  "in_reply_to_user_id" : 644813,
  "text" : "@bskelton Heavy rain and quite cool... welcome to Maytober!",
  "id" : 736662969963057153,
  "in_reply_to_status_id" : 736662418433179648,
  "created_at" : "2016-05-28 20:58:33 +0000",
  "in_reply_to_screen_name" : "bskelton",
  "in_reply_to_user_id_str" : "644813",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Skelton",
      "screen_name" : "bskelton",
      "indices" : [ 0, 9 ],
      "id_str" : "644813",
      "id" : 644813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736659588687265792",
  "geo" : { },
  "id_str" : "736661809025818625",
  "in_reply_to_user_id" : 644813,
  "text" : "@bskelton You must not be in Vancouver right now \uD83D\uDE09",
  "id" : 736661809025818625,
  "in_reply_to_status_id" : 736659588687265792,
  "created_at" : "2016-05-28 20:53:56 +0000",
  "in_reply_to_screen_name" : "bskelton",
  "in_reply_to_user_id_str" : "644813",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shareaholic",
      "screen_name" : "Shareaholic",
      "indices" : [ 97, 109 ],
      "id_str" : "791635",
      "id" : 791635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/NYZTPFfWKG",
      "expanded_url" : "http:\/\/go.shr.lc\/1qSnFUl",
      "display_url" : "go.shr.lc\/1qSnFUl"
    } ]
  },
  "geo" : { },
  "id_str" : "736627741357809665",
  "text" : "The Perfect Report: How to Write It So that People Want to Read It - https:\/\/t.co\/NYZTPFfWKG via @shareaholic",
  "id" : 736627741357809665,
  "created_at" : "2016-05-28 18:38:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HFI",
      "screen_name" : "humanfactors",
      "indices" : [ 3, 16 ],
      "id_str" : "16874616",
      "id" : 16874616
    }, {
      "name" : "Anna Kulawik",
      "screen_name" : "annkulawik",
      "indices" : [ 121, 132 ],
      "id_str" : "4784411669",
      "id" : 4784411669
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 44, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/cjAf1jxYs8",
      "expanded_url" : "http:\/\/bit.ly\/1qRVa94",
      "display_url" : "bit.ly\/1qRVa94"
    } ]
  },
  "geo" : { },
  "id_str" : "736582526097989632",
  "text" : "RT @humanfactors: Great way to organize the #UX design process: a design canvas! Who knew?  https:\/\/t.co\/cjAf1jxYs8 via  @annkulawik",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anna Kulawik",
        "screen_name" : "annkulawik",
        "indices" : [ 103, 114 ],
        "id_str" : "4784411669",
        "id" : 4784411669
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 26, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/cjAf1jxYs8",
        "expanded_url" : "http:\/\/bit.ly\/1qRVa94",
        "display_url" : "bit.ly\/1qRVa94"
      } ]
    },
    "geo" : { },
    "id_str" : "736579721169899520",
    "text" : "Great way to organize the #UX design process: a design canvas! Who knew?  https:\/\/t.co\/cjAf1jxYs8 via  @annkulawik",
    "id" : 736579721169899520,
    "created_at" : "2016-05-28 15:27:45 +0000",
    "user" : {
      "name" : "HFI",
      "screen_name" : "humanfactors",
      "protected" : false,
      "id_str" : "16874616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752497708620013568\/Yk8zOZ-b_normal.jpg",
      "id" : 16874616,
      "verified" : false
    }
  },
  "id" : 736582526097989632,
  "created_at" : "2016-05-28 15:38:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/736577191283036161\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/KKHFeeEy3r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjjZDVeUgAIHfK0.jpg",
      "id_str" : "736577190402228226",
      "id" : 736577190402228226,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjjZDVeUgAIHfK0.jpg",
      "sizes" : [ {
        "h" : 619,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 778
      } ],
      "display_url" : "pic.twitter.com\/KKHFeeEy3r"
    } ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 63, 66 ]
    }, {
      "text" : "SFU",
      "indices" : [ 102, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736577191283036161",
  "text" : "Early Saturday morning sneak peek at a possible revision to my #UX design process\/toolkit diagram for #SFU CMPT 363. https:\/\/t.co\/KKHFeeEy3r",
  "id" : 736577191283036161,
  "created_at" : "2016-05-28 15:17:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Hammarberg",
      "screen_name" : "marcusoftnet",
      "indices" : [ 3, 16 ],
      "id_str" : "22898439",
      "id" : 22898439
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "markdown",
      "indices" : [ 37, 46 ]
    }, {
      "text" : "editor",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/oQUmnOtA12",
      "expanded_url" : "http:\/\/bit.ly\/1TJFDCL",
      "display_url" : "bit.ly\/1TJFDCL"
    } ]
  },
  "geo" : { },
  "id_str" : "736371653874065409",
  "text" : "RT @marcusoftnet: Typora is the best #markdown #editor I've used so far. Get it https:\/\/t.co\/oQUmnOtA12",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "markdown",
        "indices" : [ 19, 28 ]
      }, {
        "text" : "editor",
        "indices" : [ 29, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/oQUmnOtA12",
        "expanded_url" : "http:\/\/bit.ly\/1TJFDCL",
        "display_url" : "bit.ly\/1TJFDCL"
      } ]
    },
    "geo" : { },
    "id_str" : "736248665531162624",
    "text" : "Typora is the best #markdown #editor I've used so far. Get it https:\/\/t.co\/oQUmnOtA12",
    "id" : 736248665531162624,
    "created_at" : "2016-05-27 17:32:15 +0000",
    "user" : {
      "name" : "Marcus Hammarberg",
      "screen_name" : "marcusoftnet",
      "protected" : false,
      "id_str" : "22898439",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521513825539866624\/CDbFNtyk_normal.jpeg",
      "id" : 22898439,
      "verified" : false
    }
  },
  "id" : 736371653874065409,
  "created_at" : "2016-05-28 01:40:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 3, 10 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/github\/status\/736325309587296261\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/uP8kBBFOuT",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CjfzI97UkAESUui.jpg",
      "id_str" : "736324399486242817",
      "id" : 736324399486242817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CjfzI97UkAESUui.jpg",
      "sizes" : [ {
        "h" : 294,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 167,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/uP8kBBFOuT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/bVrnnSHUdy",
      "expanded_url" : "https:\/\/github.com\/blog\/2179-drag-and-drop-tasks-in-markdown-task-lists?utm_source=twitter&utm_medium=social&utm_campaign=drag-and-drop-tasks",
      "display_url" : "github.com\/blog\/2179-drag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736358382454464512",
  "text" : "RT @github: Drag and drop task list items without editing Markdown: https:\/\/t.co\/bVrnnSHUdy https:\/\/t.co\/uP8kBBFOuT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/github\/status\/736325309587296261\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/uP8kBBFOuT",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CjfzI97UkAESUui.jpg",
        "id_str" : "736324399486242817",
        "id" : 736324399486242817,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CjfzI97UkAESUui.jpg",
        "sizes" : [ {
          "h" : 294,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 167,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/uP8kBBFOuT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/bVrnnSHUdy",
        "expanded_url" : "https:\/\/github.com\/blog\/2179-drag-and-drop-tasks-in-markdown-task-lists?utm_source=twitter&utm_medium=social&utm_campaign=drag-and-drop-tasks",
        "display_url" : "github.com\/blog\/2179-drag\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "736325309587296261",
    "text" : "Drag and drop task list items without editing Markdown: https:\/\/t.co\/bVrnnSHUdy https:\/\/t.co\/uP8kBBFOuT",
    "id" : 736325309587296261,
    "created_at" : "2016-05-27 22:36:48 +0000",
    "user" : {
      "name" : "GitHub",
      "screen_name" : "github",
      "protected" : false,
      "id_str" : "13334762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616309728688238592\/pBeeJQDQ_normal.png",
      "id" : 13334762,
      "verified" : true
    }
  },
  "id" : 736358382454464512,
  "created_at" : "2016-05-28 00:48:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/clintlalonde\/status\/736348745135181828\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/h0waixZFxU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjgJSCsWkAAgArt.jpg",
      "id_str" : "736348744640270336",
      "id" : 736348744640270336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjgJSCsWkAAgArt.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/h0waixZFxU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/zptjQZUskj",
      "expanded_url" : "http:\/\/clintlalonde.net\/2016\/05\/27\/working-with-sandstorm\/",
      "display_url" : "clintlalonde.net\/2016\/05\/27\/wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736357561394286592",
  "text" : "RT @clintlalonde: Working with Sandstorm https:\/\/t.co\/zptjQZUskj https:\/\/t.co\/h0waixZFxU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/clintlalonde\/status\/736348745135181828\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/h0waixZFxU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjgJSCsWkAAgArt.jpg",
        "id_str" : "736348744640270336",
        "id" : 736348744640270336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjgJSCsWkAAgArt.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/h0waixZFxU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/zptjQZUskj",
        "expanded_url" : "http:\/\/clintlalonde.net\/2016\/05\/27\/working-with-sandstorm\/",
        "display_url" : "clintlalonde.net\/2016\/05\/27\/wor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "736348745135181828",
    "text" : "Working with Sandstorm https:\/\/t.co\/zptjQZUskj https:\/\/t.co\/h0waixZFxU",
    "id" : 736348745135181828,
    "created_at" : "2016-05-28 00:09:56 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 736357561394286592,
  "created_at" : "2016-05-28 00:44:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raymond Johnson",
      "screen_name" : "MathEdnet",
      "indices" : [ 0, 10 ],
      "id_str" : "80386465",
      "id" : 80386465
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 11, 19 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736336420202151936",
  "geo" : { },
  "id_str" : "736341946000498688",
  "in_reply_to_user_id" : 80386465,
  "text" : "@MathEdnet @getgrav Oh, well that's great to hear.\uD83D\uDE42 Please feel free to let me know if you'd like to have a Skype\/Hangout sometime.",
  "id" : 736341946000498688,
  "in_reply_to_status_id" : 736336420202151936,
  "created_at" : "2016-05-27 23:42:55 +0000",
  "in_reply_to_screen_name" : "MathEdnet",
  "in_reply_to_user_id_str" : "80386465",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 3, 17 ],
      "id_str" : "41268670",
      "id" : 41268670
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OER",
      "indices" : [ 55, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/BDe0UUho6c",
      "expanded_url" : "http:\/\/www.collinsartanddesign.com\/blog\/2016\/5\/27\/interoperable-open-education-resources-oer",
      "display_url" : "collinsartanddesign.com\/blog\/2016\/5\/27\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736283967209365504",
  "text" : "RT @_mike_collins: I wrote something interesting about #OER today. https:\/\/t.co\/BDe0UUho6c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OER",
        "indices" : [ 36, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/BDe0UUho6c",
        "expanded_url" : "http:\/\/www.collinsartanddesign.com\/blog\/2016\/5\/27\/interoperable-open-education-resources-oer",
        "display_url" : "collinsartanddesign.com\/blog\/2016\/5\/27\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "736282160630489088",
    "text" : "I wrote something interesting about #OER today. https:\/\/t.co\/BDe0UUho6c",
    "id" : 736282160630489088,
    "created_at" : "2016-05-27 19:45:21 +0000",
    "user" : {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "protected" : false,
      "id_str" : "41268670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481148655886270465\/mJBxDJQ-_normal.png",
      "id" : 41268670,
      "verified" : false
    }
  },
  "id" : 736283967209365504,
  "created_at" : "2016-05-27 19:52:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raymond Johnson",
      "screen_name" : "MathEdnet",
      "indices" : [ 0, 10 ],
      "id_str" : "80386465",
      "id" : 80386465
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 25, 33 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/tv9q3n8Pxr",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/",
      "display_url" : "hibbittsdesign.org\/blog\/"
    } ]
  },
  "in_reply_to_status_id_str" : "735841571015270404",
  "geo" : { },
  "id_str" : "736279751782895617",
  "in_reply_to_user_id" : 80386465,
  "text" : "@MathEdnet Have you seen @getgrav flat-file CMS? I've found it a good fit for the needs of an individual instructor. https:\/\/t.co\/tv9q3n8Pxr",
  "id" : 736279751782895617,
  "in_reply_to_status_id" : 735841571015270404,
  "created_at" : "2016-05-27 19:35:46 +0000",
  "in_reply_to_screen_name" : "MathEdnet",
  "in_reply_to_user_id_str" : "80386465",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Thurrott",
      "screen_name" : "thurrott",
      "indices" : [ 0, 9 ],
      "id_str" : "14964767",
      "id" : 14964767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736271137269780480",
  "geo" : { },
  "id_str" : "736271757879873537",
  "in_reply_to_user_id" : 14964767,
  "text" : "@thurrott Or, as MC Hammer would say 'U Can't Touch This'.",
  "id" : 736271757879873537,
  "in_reply_to_status_id" : 736271137269780480,
  "created_at" : "2016-05-27 19:04:01 +0000",
  "in_reply_to_screen_name" : "thurrott",
  "in_reply_to_user_id_str" : "14964767",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 15, 23 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/9PFedwpqcF",
      "expanded_url" : "https:\/\/getgrav.org\/downloads\/skeletons",
      "display_url" : "getgrav.org\/downloads\/skel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736269225078050816",
  "text" : "New release of @getgrav Course Hub now available, including an example of modular content reuse (on Syllabus page). https:\/\/t.co\/9PFedwpqcF",
  "id" : 736269225078050816,
  "created_at" : "2016-05-27 18:53:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 108, 123 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cwcon",
      "indices" : [ 85, 91 ]
    }, {
      "text" : "apereo16",
      "indices" : [ 92, 101 ]
    }, {
      "text" : "redecentralize",
      "indices" : [ 133, 144 ]
    }, {
      "text" : "edTech",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/BzVSw3Ppa3",
      "expanded_url" : "https:\/\/github.com\/elmsln\/elmsln\/issues\/922",
      "display_url" : "github.com\/elmsln\/elmsln\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736257348776251393",
  "text" : "RT @btopro: Dockerize markdown production workflows https:\/\/t.co\/BzVSw3Ppa3 combo of #cwcon #apereo16 &amp; @hibbittsdesign thoughts #redecentr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 96, 111 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cwcon",
        "indices" : [ 73, 79 ]
      }, {
        "text" : "apereo16",
        "indices" : [ 80, 89 ]
      }, {
        "text" : "redecentralize",
        "indices" : [ 121, 136 ]
      }, {
        "text" : "edTech",
        "indices" : [ 137, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/BzVSw3Ppa3",
        "expanded_url" : "https:\/\/github.com\/elmsln\/elmsln\/issues\/922",
        "display_url" : "github.com\/elmsln\/elmsln\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "736255982955794432",
    "text" : "Dockerize markdown production workflows https:\/\/t.co\/BzVSw3Ppa3 combo of #cwcon #apereo16 &amp; @hibbittsdesign thoughts #redecentralize #edTech",
    "id" : 736255982955794432,
    "created_at" : "2016-05-27 18:01:19 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 736257348776251393,
  "created_at" : "2016-05-27 18:06:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/rq0ZKPqLGz",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-04-12-local-vs-cloud-grav-development-with-github",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/cegel1X0w4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-11-using-grav-with-github",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "736253743960842244",
  "geo" : { },
  "id_str" : "736257116252430336",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro That would be awesome! Do you mean this post? https:\/\/t.co\/rq0ZKPqLGz Contains various approaches. Also https:\/\/t.co\/cegel1X0w4",
  "id" : 736257116252430336,
  "in_reply_to_status_id" : 736253743960842244,
  "created_at" : "2016-05-27 18:05:50 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/N1ByiZqH7Z",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-05-26-creating-slides-in-markdown",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736247788510420992",
  "text" : "New Post: Creating Slides in Markdown https:\/\/t.co\/N1ByiZqH7Z Markdown is fast becoming my preferred method for semantically marked-up text.",
  "id" : 736247788510420992,
  "created_at" : "2016-05-27 17:28:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 33, 41 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 67, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736245428832735232",
  "text" : "Heads-down preparing for lots of @getgrav goodness at the upcoming #FoL16. Just added modular content 'chunks' example to Grav Course Hub. \uD83D\uDE4C",
  "id" : 736245428832735232,
  "created_at" : "2016-05-27 17:19:23 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735994276866318336",
  "geo" : { },
  "id_str" : "735996130161369088",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Thanks! Thinking more about format. So far, I've got\nProblem statement\nCurrent UI flow\nProposed UI storyboard\nUsability test results",
  "id" : 735996130161369088,
  "in_reply_to_status_id" : 735994276866318336,
  "created_at" : "2016-05-27 00:48:46 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 78, 88 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/n3WAg9JNlh",
      "expanded_url" : "https:\/\/shar.es\/1dibEx",
      "display_url" : "shar.es\/1dibEx"
    } ]
  },
  "geo" : { },
  "id_str" : "735983383969308673",
  "text" : "Communicating User Research Findings :: UXmatters https:\/\/t.co\/n3WAg9JNlh via @sharethis",
  "id" : 735983383969308673,
  "created_at" : "2016-05-26 23:58:07 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/DsaiekrUo2",
      "expanded_url" : "http:\/\/designstack.io\/welcome-to-ghost\/",
      "display_url" : "designstack.io\/welcome-to-gho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735982173065334785",
  "text" : "5 Design Handoffs Your Team Will Thank You For https:\/\/t.co\/DsaiekrUo2",
  "id" : 735982173065334785,
  "created_at" : "2016-05-26 23:53:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn SlideShare",
      "screen_name" : "SlideShare",
      "indices" : [ 72, 83 ],
      "id_str" : "9676152",
      "id" : 9676152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/63m1SrZBF2",
      "expanded_url" : "http:\/\/www.slideshare.net\/EpicenterUSA\/dtal-template-empathy-map-and-problem-statement",
      "display_url" : "slideshare.net\/EpicenterUSA\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735981416069005313",
  "text" : "Template: Empathy Map and Problem Statement https:\/\/t.co\/63m1SrZBF2 via @SlideShare",
  "id" : 735981416069005313,
  "created_at" : "2016-05-26 23:50:18 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hope Miller",
      "screen_name" : "aHEMpublishing",
      "indices" : [ 3, 18 ],
      "id_str" : "1299940627",
      "id" : 1299940627
    }, {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 102, 111 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "Academic Technology",
      "screen_name" : "ATS_Douglas",
      "indices" : [ 112, 124 ],
      "id_str" : "2666730674",
      "id" : 2666730674
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 125, 130 ],
      "id_str" : "17102936",
      "id" : 17102936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 70, 76 ]
    }, {
      "text" : "design4inclusion",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/UDi5wpeslN",
      "expanded_url" : "http:\/\/sched.co\/6kgR",
      "display_url" : "sched.co\/6kgR"
    } ]
  },
  "geo" : { },
  "id_str" : "735959149117210624",
  "text" : "RT @aHEMpublishing: Don't miss our \"Design for Inclusion\" workshop at #FoL16! https:\/\/t.co\/UDi5wpeslN @bccampus @ATS_Douglas @etug #design4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BCcampus",
        "screen_name" : "BCcampus",
        "indices" : [ 82, 91 ],
        "id_str" : "93710949",
        "id" : 93710949
      }, {
        "name" : "Academic Technology",
        "screen_name" : "ATS_Douglas",
        "indices" : [ 92, 104 ],
        "id_str" : "2666730674",
        "id" : 2666730674
      }, {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 105, 110 ],
        "id_str" : "17102936",
        "id" : 17102936
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 50, 56 ]
      }, {
        "text" : "design4inclusion",
        "indices" : [ 111, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/UDi5wpeslN",
        "expanded_url" : "http:\/\/sched.co\/6kgR",
        "display_url" : "sched.co\/6kgR"
      } ]
    },
    "geo" : { },
    "id_str" : "735940543964794880",
    "text" : "Don't miss our \"Design for Inclusion\" workshop at #FoL16! https:\/\/t.co\/UDi5wpeslN @bccampus @ATS_Douglas @etug #design4inclusion",
    "id" : 735940543964794880,
    "created_at" : "2016-05-26 21:07:53 +0000",
    "user" : {
      "name" : "Hope Miller",
      "screen_name" : "aHEMpublishing",
      "protected" : false,
      "id_str" : "1299940627",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530413039602765824\/aaz5p_gf_normal.jpeg",
      "id" : 1299940627,
      "verified" : false
    }
  },
  "id" : 735959149117210624,
  "created_at" : "2016-05-26 22:21:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 74, 83 ],
      "id_str" : "890887814",
      "id" : 890887814
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 112, 119 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/N1ByiZqH7Z",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-05-26-creating-slides-in-markdown",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735949373071228928",
  "text" : "New Post: Creating Slides in Markdown (and having fun while doing it with @swipe_to) https:\/\/t.co\/N1ByiZqH7Z HT @btopro",
  "id" : 735949373071228928,
  "created_at" : "2016-05-26 21:42:58 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 48, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735940084621398017",
  "text" : "Help minimize terminology confusion... refer to #UX techniques in the format of [technique] for [domain] instead of [domain][technique].\uD83D\uDE4C",
  "id" : 735940084621398017,
  "created_at" : "2016-05-26 21:06:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NGDLE",
      "indices" : [ 28, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735936758500589568",
  "text" : "Updated list of what I feel #NGDLE should\/can be:\n\u2713Extensible\n\u2713Standards-based\n\u2713Open\n\u2713Portable\n\u2713Collaborative\n\u2713Modular\n\u2713Fast\n\u2713Enjoyable",
  "id" : 735936758500589568,
  "created_at" : "2016-05-26 20:52:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Lyons",
      "screen_name" : "lyonsinbeta",
      "indices" : [ 3, 15 ],
      "id_str" : "834529106",
      "id" : 834529106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/y7xAiJ6CHi",
      "expanded_url" : "http:\/\/lyonsinbeta.com\/2016\/5\/maine-admits-ipads-in-the-classroom-are-a-bad-idea",
      "display_url" : "lyonsinbeta.com\/2016\/5\/maine-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735929791157657600",
  "text" : "RT @lyonsinbeta: Maine Admits iPads in the Classroom Are (Mostly) a Bad Idea https:\/\/t.co\/y7xAiJ6CHi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/y7xAiJ6CHi",
        "expanded_url" : "http:\/\/lyonsinbeta.com\/2016\/5\/maine-admits-ipads-in-the-classroom-are-a-bad-idea",
        "display_url" : "lyonsinbeta.com\/2016\/5\/maine-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735927709306474497",
    "text" : "Maine Admits iPads in the Classroom Are (Mostly) a Bad Idea https:\/\/t.co\/y7xAiJ6CHi",
    "id" : 735927709306474497,
    "created_at" : "2016-05-26 20:16:53 +0000",
    "user" : {
      "name" : "David Lyons",
      "screen_name" : "lyonsinbeta",
      "protected" : false,
      "id_str" : "834529106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605967993206497280\/uxAuxLUk_normal.jpg",
      "id" : 834529106,
      "verified" : false
    }
  },
  "id" : 735929791157657600,
  "created_at" : "2016-05-26 20:25:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 29, 37 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735922470159417344",
  "text" : "One of the things that makes @getgrav so flexible is that a page can display one or more other pages. This can even be done via Markdown.\uD83D\uDC4D",
  "id" : 735922470159417344,
  "created_at" : "2016-05-26 19:56:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 64, 72 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 23, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/fXOsasWJn1",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1T_275jM2Q892ZSbUOu0l0nGsccisNNwlMcA4_gytOGo\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1T_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735909634871951360",
  "text" : "Updated handout for my #FoL16 studio Moving Beyond the LMS with @getgrav CMS, now including storing site on GitHub. https:\/\/t.co\/fXOsasWJn1",
  "id" : 735909634871951360,
  "created_at" : "2016-05-26 19:05:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735891670944747524",
  "text" : "Mulling over UX contribs to open source projects for future CMPT 363 and am looking for example UX-enhancement GitHub proj issues, know one?",
  "id" : 735891670944747524,
  "created_at" : "2016-05-26 17:53:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735854904938352641",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro On other fronts, would you have a (preferred) example GitHub PR of a proposed UX change? Mulling over options for my UX students.",
  "id" : 735854904938352641,
  "created_at" : "2016-05-26 15:27:35 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "H5P",
      "screen_name" : "H5PTechnology",
      "indices" : [ 8, 22 ],
      "id_str" : "2216405440",
      "id" : 2216405440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735842532878258180",
  "geo" : { },
  "id_str" : "735843399811485697",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @H5PTechnology I will do that, thanks!",
  "id" : 735843399811485697,
  "in_reply_to_status_id" : 735842532878258180,
  "created_at" : "2016-05-26 14:41:52 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735840181396242433",
  "geo" : { },
  "id_str" : "735840766069612544",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Would you have a sense of scope of developing a plugin for a PHP-based platform... say Grav \uD83D\uDE09 i.e. days\/weeks\/months?",
  "id" : 735840766069612544,
  "in_reply_to_status_id" : 735840181396242433,
  "created_at" : "2016-05-26 14:31:24 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/XKZdAmIBNX",
      "expanded_url" : "http:\/\/clintlalonde.net\/2016\/05\/25\/create-embeddable-html5-content-with-h5p\/",
      "display_url" : "clintlalonde.net\/2016\/05\/25\/cre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735840144666681349",
  "text" : "RT @clintlalonde: Create embeddable HTML5 content with\u00A0H5P https:\/\/t.co\/XKZdAmIBNX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/XKZdAmIBNX",
        "expanded_url" : "http:\/\/clintlalonde.net\/2016\/05\/25\/create-embeddable-html5-content-with-h5p\/",
        "display_url" : "clintlalonde.net\/2016\/05\/25\/cre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735544613386080256",
    "text" : "Create embeddable HTML5 content with\u00A0H5P https:\/\/t.co\/XKZdAmIBNX",
    "id" : 735544613386080256,
    "created_at" : "2016-05-25 18:54:36 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 735840144666681349,
  "created_at" : "2016-05-26 14:28:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735839951514783744",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro H5P looks pretty interesting! Do you gain much if there is a plugin for a platform vs. just embedding HTML code?",
  "id" : 735839951514783744,
  "created_at" : "2016-05-26 14:28:10 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 3, 11 ],
      "id_str" : "739293",
      "id" : 739293
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 121, 128 ]
    }, {
      "text" : "edchat",
      "indices" : [ 129, 136 ]
    }, {
      "text" : "eci830",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/RpKYSosGSv",
      "expanded_url" : "http:\/\/qz.com\/691180\/even-apple-is-acknowledging-that-the-ipads-in-education-fad-is-coming-to-an-end\/",
      "display_url" : "qz.com\/691180\/even-ap\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735663350428798976",
  "text" : "RT @courosa: \"Even Apple is acknowledging that the \u201CiPads in education\u201D fad is coming to an end\" https:\/\/t.co\/RpKYSosGSv #edtech #edchat #e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 108, 115 ]
      }, {
        "text" : "edchat",
        "indices" : [ 116, 123 ]
      }, {
        "text" : "eci830",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/RpKYSosGSv",
        "expanded_url" : "http:\/\/qz.com\/691180\/even-apple-is-acknowledging-that-the-ipads-in-education-fad-is-coming-to-an-end\/",
        "display_url" : "qz.com\/691180\/even-ap\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735660487484940289",
    "text" : "\"Even Apple is acknowledging that the \u201CiPads in education\u201D fad is coming to an end\" https:\/\/t.co\/RpKYSosGSv #edtech #edchat #eci830",
    "id" : 735660487484940289,
    "created_at" : "2016-05-26 02:35:02 +0000",
    "user" : {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "protected" : false,
      "id_str" : "739293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480186733221249027\/bzI2RIfo_normal.jpeg",
      "id" : 739293,
      "verified" : false
    }
  },
  "id" : 735663350428798976,
  "created_at" : "2016-05-26 02:46:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 0, 7 ],
      "id_str" : "10817782",
      "id" : 10817782
    }, {
      "name" : "Jesse Stommel",
      "screen_name" : "Jessifer",
      "indices" : [ 8, 17 ],
      "id_str" : "11702102",
      "id" : 11702102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735630857298272256",
  "geo" : { },
  "id_str" : "735631231295987713",
  "in_reply_to_user_id" : 10817782,
  "text" : "@tanbob @Jessifer Thanks for the very kind words Tannis \uD83D\uDE0A",
  "id" : 735631231295987713,
  "in_reply_to_status_id" : 735630857298272256,
  "created_at" : "2016-05-26 00:38:47 +0000",
  "in_reply_to_screen_name" : "tanbob",
  "in_reply_to_user_id_str" : "10817782",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Stommel",
      "screen_name" : "Jessifer",
      "indices" : [ 0, 9 ],
      "id_str" : "11702102",
      "id" : 11702102
    }, {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 10, 17 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735628853259972608",
  "geo" : { },
  "id_str" : "735630970645151744",
  "in_reply_to_user_id" : 11702102,
  "text" : "@Jessifer @tanbob It all depends on the problems you are trying to solve and target audience tech skills.",
  "id" : 735630970645151744,
  "in_reply_to_status_id" : 735628853259972608,
  "created_at" : "2016-05-26 00:37:45 +0000",
  "in_reply_to_screen_name" : "Jessifer",
  "in_reply_to_user_id_str" : "11702102",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Stommel",
      "screen_name" : "Jessifer",
      "indices" : [ 0, 9 ],
      "id_str" : "11702102",
      "id" : 11702102
    }, {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 10, 17 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735628853259972608",
  "geo" : { },
  "id_str" : "735630650351353856",
  "in_reply_to_user_id" : 11702102,
  "text" : "@Jessifer @tanbob I've used WordPress as well, and a fair number of other CMSs and LMSs.",
  "id" : 735630650351353856,
  "in_reply_to_status_id" : 735628853259972608,
  "created_at" : "2016-05-26 00:36:29 +0000",
  "in_reply_to_screen_name" : "Jessifer",
  "in_reply_to_user_id_str" : "11702102",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Stommel",
      "screen_name" : "Jessifer",
      "indices" : [ 0, 9 ],
      "id_str" : "11702102",
      "id" : 11702102
    }, {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 10, 17 ],
      "id_str" : "10817782",
      "id" : 10817782
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 74, 82 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735628853259972608",
  "geo" : { },
  "id_str" : "735630247530373122",
  "in_reply_to_user_id" : 11702102,
  "text" : "@Jessifer @tanbob I'd be happy to share my recent exprleriences\/work with @getgrav if you are interested.",
  "id" : 735630247530373122,
  "in_reply_to_status_id" : 735628853259972608,
  "created_at" : "2016-05-26 00:34:53 +0000",
  "in_reply_to_screen_name" : "Jessifer",
  "in_reply_to_user_id_str" : "11702102",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735627308623503360",
  "text" : "For institutions, WordPress can be a good choice esp. Multisite but for individual instructors a modern flat-file CMS is often a better fit.",
  "id" : 735627308623503360,
  "created_at" : "2016-05-26 00:23:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735564210654957568",
  "text" : "Personal observation: moving into an open source product space from a UX consulting practice brings with it both new highs and lows. Onward!",
  "id" : 735564210654957568,
  "created_at" : "2016-05-25 20:12:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/T5ysvQmc0A",
      "expanded_url" : "https:\/\/btopro.wordpress.com\/2016\/03\/18\/dont-become-what-you-hate\/",
      "display_url" : "btopro.wordpress.com\/2016\/03\/18\/don\u2026"
    }, {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/wByMgf2sr5",
      "expanded_url" : "https:\/\/twitter.com\/pep_alan\/status\/735540193550303234",
      "display_url" : "twitter.com\/pep_alan\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735547469463855104",
  "text" : "RT @btopro: Control, Control, Control. always control https:\/\/t.co\/T5ysvQmc0A :) https:\/\/t.co\/wByMgf2sr5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/T5ysvQmc0A",
        "expanded_url" : "https:\/\/btopro.wordpress.com\/2016\/03\/18\/dont-become-what-you-hate\/",
        "display_url" : "btopro.wordpress.com\/2016\/03\/18\/don\u2026"
      }, {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/wByMgf2sr5",
        "expanded_url" : "https:\/\/twitter.com\/pep_alan\/status\/735540193550303234",
        "display_url" : "twitter.com\/pep_alan\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735546075717730307",
    "text" : "Control, Control, Control. always control https:\/\/t.co\/T5ysvQmc0A :) https:\/\/t.co\/wByMgf2sr5",
    "id" : 735546075717730307,
    "created_at" : "2016-05-25 19:00:24 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 735547469463855104,
  "created_at" : "2016-05-25 19:05:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NGDLE",
      "indices" : [ 65, 71 ]
    }, {
      "text" : "apereo16",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735545895001853954",
  "text" : "(2\/2) And how about some facilitator experience design goals for #NGDLE?\n\u2713Controllable\n\u2713Pliable\n\u2713Efficient\n\u2713Enjoyable\n#apereo16",
  "id" : 735545895001853954,
  "created_at" : "2016-05-25 18:59:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NGDLE",
      "indices" : [ 58, 64 ]
    }, {
      "text" : "apereo16",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735545835824414720",
  "text" : "(1\/2) What about some student experience design goals for #NGDLE?\n\u2713Engaging\n\u2713Organized\n\u2713Relevant\n\u2713Convenient\n\u2713Enjoyable\n#apereo16",
  "id" : 735545835824414720,
  "created_at" : "2016-05-25 18:59:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 131, 139 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735543123187630080",
  "text" : "A key philosophical design goal of the Grav Course Hub is that it also represents a *starting* point for educators to benefit from @getgrav.",
  "id" : 735543123187630080,
  "created_at" : "2016-05-25 18:48:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Gadikian",
      "screen_name" : "jacobgadikian",
      "indices" : [ 0, 14 ],
      "id_str" : "5533262",
      "id" : 5533262
    }, {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 15, 24 ],
      "id_str" : "890887814",
      "id" : 890887814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735537931956322305",
  "geo" : { },
  "id_str" : "735538528008822784",
  "in_reply_to_user_id" : 15949844,
  "text" : "@jacobgadikian @swipe_to One thing I'd like to see is a 'power-user' mode where I could edit the entire Markdown file at once with previews.",
  "id" : 735538528008822784,
  "in_reply_to_status_id" : 735537931956322305,
  "created_at" : "2016-05-25 18:30:25 +0000",
  "in_reply_to_screen_name" : "hibbittsdesign",
  "in_reply_to_user_id_str" : "15949844",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Gadikian",
      "screen_name" : "jacobgadikian",
      "indices" : [ 0, 14 ],
      "id_str" : "5533262",
      "id" : 5533262
    }, {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 15, 24 ],
      "id_str" : "890887814",
      "id" : 890887814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/uVZrViV9wj",
      "expanded_url" : "https:\/\/gist.githubusercontent.com\/paulhibbitts\/528b8ac246ef75315c63fb5b92a88254\/raw\/67617ebfc6858fb2a1b773bf9728f91fc624d352\/gistfile1.txt",
      "display_url" : "gist.githubusercontent.com\/paulhibbitts\/5\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "735536670536146945",
  "geo" : { },
  "id_str" : "735537931956322305",
  "in_reply_to_user_id" : 5533262,
  "text" : "@jacobgadikian @swipe_to I've found it quite enjoyable overall, and you can share presentation content in markdown \uD83D\uDC4D https:\/\/t.co\/uVZrViV9wj",
  "id" : 735537931956322305,
  "in_reply_to_status_id" : 735536670536146945,
  "created_at" : "2016-05-25 18:28:03 +0000",
  "in_reply_to_screen_name" : "jacobgadikian",
  "in_reply_to_user_id_str" : "5533262",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 11, 20 ],
      "id_str" : "890887814",
      "id" : 890887814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/01QG69wdR4",
      "expanded_url" : "https:\/\/swipe.to\/4340n",
      "display_url" : "swipe.to\/4340n"
    } ]
  },
  "geo" : { },
  "id_str" : "735526817084252161",
  "text" : "Trying out @swipe_to to leverage my Markdown skills to create slidedecks, here is my first in-progress slide deck. https:\/\/t.co\/01QG69wdR4",
  "id" : 735526817084252161,
  "created_at" : "2016-05-25 17:43:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/qBQrIVJr2g",
      "expanded_url" : "http:\/\/ow.ly\/b9Nt300A1MH",
      "display_url" : "ow.ly\/b9Nt300A1MH"
    } ]
  },
  "geo" : { },
  "id_str" : "735523612405334016",
  "text" : "RT @BCcampus: Only a few more days to get your passes for the Festival of Learning: https:\/\/t.co\/qBQrIVJr2g #FoL16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 94, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/qBQrIVJr2g",
        "expanded_url" : "http:\/\/ow.ly\/b9Nt300A1MH",
        "display_url" : "ow.ly\/b9Nt300A1MH"
      } ]
    },
    "geo" : { },
    "id_str" : "735521302983933952",
    "text" : "Only a few more days to get your passes for the Festival of Learning: https:\/\/t.co\/qBQrIVJr2g #FoL16",
    "id" : 735521302983933952,
    "created_at" : "2016-05-25 17:21:58 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 735523612405334016,
  "created_at" : "2016-05-25 17:31:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 63, 70 ],
      "id_str" : "236846178",
      "id" : 236846178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/joBCo7gxpi",
      "expanded_url" : "https:\/\/twitter.com\/hibbittsdesign\/status\/735507342465335296",
      "display_url" : "twitter.com\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735512949897322499",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro I think a lot of what you and your team are doing with @elmsln is captured in https:\/\/t.co\/joBCo7gxpi, does list resonate with you?",
  "id" : 735512949897322499,
  "created_at" : "2016-05-25 16:48:47 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735509458525114368",
  "text" : "In comparison, I've found most LMSs to be:\n\u2713Constrained\n\u2713Proprietary\n\u2713Closed\n\u2713Stationary\n\u2713Solitary\n\u2713Slow\n\u2713Unenjoyable\n#apereo16",
  "id" : 735509458525114368,
  "created_at" : "2016-05-25 16:34:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NGDLE",
      "indices" : [ 20, 26 ]
    }, {
      "text" : "apereo16",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735507342465335296",
  "text" : "Still not sure what #NGDLE is, but feel it should be:\n\u2713Extensible\n\u2713Standards-based\n\u2713Open\n\u2713Portable\n\u2713Collaborative\n\u2713Fast\n\u2713Enjoyable\n#apereo16",
  "id" : 735507342465335296,
  "created_at" : "2016-05-25 16:26:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 12, 21 ]
    }, {
      "text" : "NGDLE",
      "indices" : [ 59, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735506890302443522",
  "text" : "RT @btopro: #apereo16 talking what ppl think about what an #NGDLE constitutes. Let\u2019s just call it Learning Ecosystem. LE is short and visio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "apereo16",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "NGDLE",
        "indices" : [ 47, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735499925023293441",
    "text" : "#apereo16 talking what ppl think about what an #NGDLE constitutes. Let\u2019s just call it Learning Ecosystem. LE is short and vision invoking",
    "id" : 735499925023293441,
    "created_at" : "2016-05-25 15:57:01 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 735506890302443522,
  "created_at" : "2016-05-25 16:24:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735500358349381633",
  "geo" : { },
  "id_str" : "735503483936243712",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro It was an awesome experience yesterday but I feel I need to further refine how I position what problems Grav solves for instructors\uD83D\uDC4D",
  "id" : 735503483936243712,
  "in_reply_to_status_id" : 735500358349381633,
  "created_at" : "2016-05-25 16:11:10 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735500101028696064",
  "text" : "Students and faculty deserve better. This sums up my view of most online learning environments, and my goal for the Grav Course Hub project.",
  "id" : 735500101028696064,
  "created_at" : "2016-05-25 15:57:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735493995711844352",
  "geo" : { },
  "id_str" : "735496132650901504",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro I'd need to think some more about that...",
  "id" : 735496132650901504,
  "in_reply_to_status_id" : 735493995711844352,
  "created_at" : "2016-05-25 15:41:57 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735493032594800640",
  "geo" : { },
  "id_str" : "735495917646663680",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Yes, something more like swipe UX-wise for sure",
  "id" : 735495917646663680,
  "in_reply_to_status_id" : 735493032594800640,
  "created_at" : "2016-05-25 15:41:06 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/ZjjQWfO0mC",
      "expanded_url" : "https:\/\/github.com\/jdan\/cleaver",
      "display_url" : "github.com\/jdan\/cleaver"
    }, {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/cEliznFoiE",
      "expanded_url" : "https:\/\/github.com\/gnab\/remark",
      "display_url" : "github.com\/gnab\/remark"
    } ]
  },
  "in_reply_to_status_id_str" : "735484463837261824",
  "geo" : { },
  "id_str" : "735490851866955776",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Actually there seems to be a number of open source markdown slide viewers... https:\/\/t.co\/ZjjQWfO0mC https:\/\/t.co\/cEliznFoiE",
  "id" : 735490851866955776,
  "in_reply_to_status_id" : 735484463837261824,
  "created_at" : "2016-05-25 15:20:58 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "indices" : [ 3, 16 ],
      "id_str" : "148593548",
      "id" : 148593548
    }, {
      "name" : "Kin Lane",
      "screen_name" : "kinlane",
      "indices" : [ 51, 59 ],
      "id_str" : "5954192",
      "id" : 5954192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/VsyzGyT1iy",
      "expanded_url" : "https:\/\/www.generosity.com\/community-fundraising\/the-most-important-api-call-for-kin-lane",
      "display_url" : "generosity.com\/community-fund\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735247328181817344",
  "text" : "RT @tressiemcphd: The most important API Call, for @kinlane. Plz consider sharing &amp; donating to public scholars who've given so much  https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kin Lane",
        "screen_name" : "kinlane",
        "indices" : [ 33, 41 ],
        "id_str" : "5954192",
        "id" : 5954192
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/VsyzGyT1iy",
        "expanded_url" : "https:\/\/www.generosity.com\/community-fundraising\/the-most-important-api-call-for-kin-lane",
        "display_url" : "generosity.com\/community-fund\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735217278007005185",
    "text" : "The most important API Call, for @kinlane. Plz consider sharing &amp; donating to public scholars who've given so much  https:\/\/t.co\/VsyzGyT1iy",
    "id" : 735217278007005185,
    "created_at" : "2016-05-24 21:13:53 +0000",
    "user" : {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "protected" : false,
      "id_str" : "148593548",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608377192331005952\/-4qqbOp2_normal.jpg",
      "id" : 148593548,
      "verified" : true
    }
  },
  "id" : 735247328181817344,
  "created_at" : "2016-05-24 23:13:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 90, 98 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/BdSSzUxf0F",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/open-apereo-2016-grav-course-hub-project#\/",
      "display_url" : "slides.com\/paulhibbitts\/o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735237734818684928",
  "text" : "Thanks to all #apereo16 Emerging Next Generation Digital Learning Environments attendees! @getgrav Course Hub slides https:\/\/t.co\/BdSSzUxf0F",
  "id" : 735237734818684928,
  "created_at" : "2016-05-24 22:35:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Hughes",
      "screen_name" : "billhughes_edu",
      "indices" : [ 3, 18 ],
      "id_str" : "705771147850358786",
      "id" : 705771147850358786
    }, {
      "name" : "Jon Mott",
      "screen_name" : "jonmott",
      "indices" : [ 20, 28 ],
      "id_str" : "14921170",
      "id" : 14921170
    }, {
      "name" : "IMS Global Learning",
      "screen_name" : "LearningImpact",
      "indices" : [ 43, 58 ],
      "id_str" : "146316919",
      "id" : 146316919
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/billhughes_edu\/status\/735220937562292224\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/xbsYC67hZH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjQHh4HVAAAjZX-.jpg",
      "id_str" : "735220917748432896",
      "id" : 735220917748432896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjQHh4HVAAAjZX-.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/xbsYC67hZH"
    } ],
    "hashtags" : [ {
      "text" : "LILI16",
      "indices" : [ 59, 66 ]
    }, {
      "text" : "edtech",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "InnovationWithoutCompromise",
      "indices" : [ 75, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735227648897515520",
  "text" : "RT @billhughes_edu: @jonmott talkin' NGDLE @LearningImpact #LILI16 #edtech #InnovationWithoutCompromise https:\/\/t.co\/xbsYC67hZH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jon Mott",
        "screen_name" : "jonmott",
        "indices" : [ 0, 8 ],
        "id_str" : "14921170",
        "id" : 14921170
      }, {
        "name" : "IMS Global Learning",
        "screen_name" : "LearningImpact",
        "indices" : [ 23, 38 ],
        "id_str" : "146316919",
        "id" : 146316919
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/billhughes_edu\/status\/735220937562292224\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/xbsYC67hZH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjQHh4HVAAAjZX-.jpg",
        "id_str" : "735220917748432896",
        "id" : 735220917748432896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjQHh4HVAAAjZX-.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/xbsYC67hZH"
      } ],
      "hashtags" : [ {
        "text" : "LILI16",
        "indices" : [ 39, 46 ]
      }, {
        "text" : "edtech",
        "indices" : [ 47, 54 ]
      }, {
        "text" : "InnovationWithoutCompromise",
        "indices" : [ 55, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735220937562292224",
    "in_reply_to_user_id" : 14921170,
    "text" : "@jonmott talkin' NGDLE @LearningImpact #LILI16 #edtech #InnovationWithoutCompromise https:\/\/t.co\/xbsYC67hZH",
    "id" : 735220937562292224,
    "created_at" : "2016-05-24 21:28:25 +0000",
    "in_reply_to_screen_name" : "jonmott",
    "in_reply_to_user_id_str" : "14921170",
    "user" : {
      "name" : "Bill Hughes",
      "screen_name" : "billhughes_edu",
      "protected" : false,
      "id_str" : "705771147850358786",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724579698043412480\/pdofigXV_normal.jpg",
      "id" : 705771147850358786,
      "verified" : false
    }
  },
  "id" : 735227648897515520,
  "created_at" : "2016-05-24 21:55:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 88, 95 ],
      "id_str" : "236846178",
      "id" : 236846178
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 96, 104 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 29, 38 ]
    }, {
      "text" : "ngdle",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735224396692869120",
  "text" : "RT @btopro: dinner soon, any #apereo16 ppls want to talk #ngdle over dinner as a group? @elmsln @getgrav tsugi and beyond",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ELMS:LN",
        "screen_name" : "elmsln",
        "indices" : [ 76, 83 ],
        "id_str" : "236846178",
        "id" : 236846178
      }, {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 84, 92 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "apereo16",
        "indices" : [ 17, 26 ]
      }, {
        "text" : "ngdle",
        "indices" : [ 45, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735209859977732097",
    "text" : "dinner soon, any #apereo16 ppls want to talk #ngdle over dinner as a group? @elmsln @getgrav tsugi and beyond",
    "id" : 735209859977732097,
    "created_at" : "2016-05-24 20:44:24 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 735224396692869120,
  "created_at" : "2016-05-24 21:42:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Appert",
      "screen_name" : "Lucyappert",
      "indices" : [ 3, 14 ],
      "id_str" : "153617129",
      "id" : 153617129
    }, {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 40, 47 ],
      "id_str" : "236846178",
      "id" : 236846178
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 136, 140 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NGDLE",
      "indices" : [ 30, 36 ]
    }, {
      "text" : "apereo16",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735196851889049600",
  "text" : "RT @Lucyappert: One vision of #NGDLE is @elmsln built on a Drupal framework at Penn State to make a modular set of services #apereo16 - @bt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ELMS:LN",
        "screen_name" : "elmsln",
        "indices" : [ 24, 31 ],
        "id_str" : "236846178",
        "id" : 236846178
      }, {
        "name" : "Bryan Ollendyke",
        "screen_name" : "btopro",
        "indices" : [ 120, 127 ],
        "id_str" : "16847370",
        "id" : 16847370
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NGDLE",
        "indices" : [ 14, 20 ]
      }, {
        "text" : "apereo16",
        "indices" : [ 108, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735185228667465729",
    "text" : "One vision of #NGDLE is @elmsln built on a Drupal framework at Penn State to make a modular set of services #apereo16 - @btopro",
    "id" : 735185228667465729,
    "created_at" : "2016-05-24 19:06:32 +0000",
    "user" : {
      "name" : "Lucy Appert",
      "screen_name" : "Lucyappert",
      "protected" : false,
      "id_str" : "153617129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000727595709\/fe3b8fbb3cd6df497f752056dde39207_normal.jpeg",
      "id" : 153617129,
      "verified" : false
    }
  },
  "id" : 735196851889049600,
  "created_at" : "2016-05-24 19:52:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Appert",
      "screen_name" : "Lucyappert",
      "indices" : [ 3, 14 ],
      "id_str" : "153617129",
      "id" : 153617129
    }, {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 44, 51 ],
      "id_str" : "236846178",
      "id" : 236846178
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 81, 88 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735196791340040196",
  "text" : "RT @Lucyappert: Can have multiple copies of @elmsln running with different specs @btopro #apereo16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ELMS:LN",
        "screen_name" : "elmsln",
        "indices" : [ 28, 35 ],
        "id_str" : "236846178",
        "id" : 236846178
      }, {
        "name" : "Bryan Ollendyke",
        "screen_name" : "btopro",
        "indices" : [ 65, 72 ],
        "id_str" : "16847370",
        "id" : 16847370
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "apereo16",
        "indices" : [ 73, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735186596153184256",
    "text" : "Can have multiple copies of @elmsln running with different specs @btopro #apereo16",
    "id" : 735186596153184256,
    "created_at" : "2016-05-24 19:11:58 +0000",
    "user" : {
      "name" : "Lucy Appert",
      "screen_name" : "Lucyappert",
      "protected" : false,
      "id_str" : "153617129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000727595709\/fe3b8fbb3cd6df497f752056dde39207_normal.jpeg",
      "id" : 153617129,
      "verified" : false
    }
  },
  "id" : 735196791340040196,
  "created_at" : "2016-05-24 19:52:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Dolphin",
      "screen_name" : "iandolphin24",
      "indices" : [ 3, 16 ],
      "id_str" : "14124670",
      "id" : 14124670
    }, {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 109, 117 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735196326057545728",
  "text" : "RT @iandolphin24: Standards are getting complex. Tsugi is here to help with scalable IMS LTI tools #apereo16 @drchuck",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "drchuck",
        "screen_name" : "drchuck",
        "indices" : [ 91, 99 ],
        "id_str" : "10185562",
        "id" : 10185562
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "apereo16",
        "indices" : [ 81, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735192750790979584",
    "text" : "Standards are getting complex. Tsugi is here to help with scalable IMS LTI tools #apereo16 @drchuck",
    "id" : 735192750790979584,
    "created_at" : "2016-05-24 19:36:25 +0000",
    "user" : {
      "name" : "Ian Dolphin",
      "screen_name" : "iandolphin24",
      "protected" : false,
      "id_str" : "14124670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638320481318404096\/51iJ7hQF_normal.jpg",
      "id" : 14124670,
      "verified" : false
    }
  },
  "id" : 735196326057545728,
  "created_at" : "2016-05-24 19:50:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Appert",
      "screen_name" : "Lucyappert",
      "indices" : [ 3, 14 ],
      "id_str" : "153617129",
      "id" : 153617129
    }, {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 109, 117 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735196258684395526",
  "text" : "RT @Lucyappert: TSUGI wants to be a model of how LTI should be used; most tools use it badly &amp; lose data @drchuck #apereo16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "drchuck",
        "screen_name" : "drchuck",
        "indices" : [ 93, 101 ],
        "id_str" : "10185562",
        "id" : 10185562
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "apereo16",
        "indices" : [ 102, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735193446487576576",
    "text" : "TSUGI wants to be a model of how LTI should be used; most tools use it badly &amp; lose data @drchuck #apereo16",
    "id" : 735193446487576576,
    "created_at" : "2016-05-24 19:39:11 +0000",
    "user" : {
      "name" : "Lucy Appert",
      "screen_name" : "Lucyappert",
      "protected" : false,
      "id_str" : "153617129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000727595709\/fe3b8fbb3cd6df497f752056dde39207_normal.jpeg",
      "id" : 153617129,
      "verified" : false
    }
  },
  "id" : 735196258684395526,
  "created_at" : "2016-05-24 19:50:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shoji Kajita",
      "screen_name" : "shojikajita",
      "indices" : [ 3, 15 ],
      "id_str" : "21551968",
      "id" : 21551968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/3FnerU0vLF",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-18-flipped-lms-using-an-open-and-collaborative-platform",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735196190665379840",
  "text" : "RT @shojikajita: \"Flipped-LMS Approach Using an Open and Collaborative Web Platform\u201D https:\/\/t.co\/3FnerU0vLF #apereo16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "apereo16",
        "indices" : [ 92, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/3FnerU0vLF",
        "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-18-flipped-lms-using-an-open-and-collaborative-platform",
        "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735194262262931457",
    "text" : "\"Flipped-LMS Approach Using an Open and Collaborative Web Platform\u201D https:\/\/t.co\/3FnerU0vLF #apereo16",
    "id" : 735194262262931457,
    "created_at" : "2016-05-24 19:42:26 +0000",
    "user" : {
      "name" : "Shoji Kajita",
      "screen_name" : "shojikajita",
      "protected" : false,
      "id_str" : "21551968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622163556490870784\/LhkF_dRb_normal.jpg",
      "id" : 21551968,
      "verified" : false
    }
  },
  "id" : 735196190665379840,
  "created_at" : "2016-05-24 19:50:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Appert",
      "screen_name" : "Lucyappert",
      "indices" : [ 3, 14 ],
      "id_str" : "153617129",
      "id" : 153617129
    }, {
      "name" : "(((Paul Hibbitts)))",
      "screen_name" : "paulhibbitts",
      "indices" : [ 111, 124 ],
      "id_str" : "18174513",
      "id" : 18174513
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735192435710525440",
  "text" : "RT @Lucyappert: Why flip LMS? Alternative frontend to LMS gives pedagogical freedom, better student experience @paulhibbitts #apereo16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "(((Paul Hibbitts)))",
        "screen_name" : "paulhibbitts",
        "indices" : [ 95, 108 ],
        "id_str" : "18174513",
        "id" : 18174513
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "apereo16",
        "indices" : [ 109, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735189580098490368",
    "text" : "Why flip LMS? Alternative frontend to LMS gives pedagogical freedom, better student experience @paulhibbitts #apereo16",
    "id" : 735189580098490368,
    "created_at" : "2016-05-24 19:23:49 +0000",
    "user" : {
      "name" : "Lucy Appert",
      "screen_name" : "Lucyappert",
      "protected" : false,
      "id_str" : "153617129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000727595709\/fe3b8fbb3cd6df497f752056dde39207_normal.jpeg",
      "id" : 153617129,
      "verified" : false
    }
  },
  "id" : 735192435710525440,
  "created_at" : "2016-05-24 19:35:10 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 127, 140 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735192159742132225",
  "text" : "RT @btopro: \u201Ctakes 30 seconds to update, and honestly it takes longer then that to just use an LMS to navigate to what I need\u201D @hibbittsdes\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 115, 130 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "apereo16",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735190997089538052",
    "text" : "\u201Ctakes 30 seconds to update, and honestly it takes longer then that to just use an LMS to navigate to what I need\u201D @hibbittsdesign #apereo16",
    "id" : 735190997089538052,
    "created_at" : "2016-05-24 19:29:27 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 735192159742132225,
  "created_at" : "2016-05-24 19:34:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 3, 10 ],
      "id_str" : "236846178",
      "id" : 236846178
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 13, 28 ],
      "id_str" : "15949844",
      "id" : 15949844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735189815096803329",
  "text" : "RT @elmsln: .@hibbittsdesign talking about flipped LMS - keeping security minded stuff in LMS but putting better student experience into an\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 1, 16 ],
        "id_str" : "15949844",
        "id" : 15949844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735189450448330752",
    "text" : ".@hibbittsdesign talking about flipped LMS - keeping security minded stuff in LMS but putting better student experience into an ecosystem!",
    "id" : 735189450448330752,
    "created_at" : "2016-05-24 19:23:18 +0000",
    "user" : {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "protected" : false,
      "id_str" : "236846178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601925668025278465\/4j0l2bWZ_normal.png",
      "id" : 236846178,
      "verified" : false
    }
  },
  "id" : 735189815096803329,
  "created_at" : "2016-05-24 19:24:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/btopro\/status\/735180789533560832\/photo\/1",
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/PtBIHN92VX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjPjB-dWEAAKSgP.jpg",
      "id_str" : "735180787276976128",
      "id" : 735180787276976128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjPjB-dWEAAKSgP.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 578
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 578
      }, {
        "h" : 602,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 578
      } ],
      "display_url" : "pic.twitter.com\/PtBIHN92VX"
    } ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 12, 21 ]
    }, {
      "text" : "ngdle",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735181140672155649",
  "text" : "RT @btopro: #apereo16 3pm room 279 come see signs of the #ngdle lms apocalypse! Err I mean future connected tools.. Ya, those https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/btopro\/status\/735180789533560832\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/PtBIHN92VX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjPjB-dWEAAKSgP.jpg",
        "id_str" : "735180787276976128",
        "id" : 735180787276976128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjPjB-dWEAAKSgP.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 578
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 578
        }, {
          "h" : 602,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 578
        } ],
        "display_url" : "pic.twitter.com\/PtBIHN92VX"
      } ],
      "hashtags" : [ {
        "text" : "apereo16",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "ngdle",
        "indices" : [ 45, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735180789533560832",
    "text" : "#apereo16 3pm room 279 come see signs of the #ngdle lms apocalypse! Err I mean future connected tools.. Ya, those https:\/\/t.co\/PtBIHN92VX",
    "id" : 735180789533560832,
    "created_at" : "2016-05-24 18:48:53 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 735181140672155649,
  "created_at" : "2016-05-24 18:50:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Appert",
      "screen_name" : "Lucyappert",
      "indices" : [ 3, 14 ],
      "id_str" : "153617129",
      "id" : 153617129
    }, {
      "name" : "Michael Feldstein",
      "screen_name" : "mfeldstein67",
      "indices" : [ 129, 140 ],
      "id_str" : "10187072",
      "id" : 10187072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735140436394663936",
  "text" : "RT @Lucyappert: \"The only thing I hate more than this LMS is having to learn a new one\" faculty reaction to coordination efforts @mfeldstei\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Feldstein",
        "screen_name" : "mfeldstein67",
        "indices" : [ 113, 126 ],
        "id_str" : "10187072",
        "id" : 10187072
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "apereo16",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735100822929956866",
    "text" : "\"The only thing I hate more than this LMS is having to learn a new one\" faculty reaction to coordination efforts @mfeldstein67 #apereo16",
    "id" : 735100822929956866,
    "created_at" : "2016-05-24 13:31:08 +0000",
    "user" : {
      "name" : "Lucy Appert",
      "screen_name" : "Lucyappert",
      "protected" : false,
      "id_str" : "153617129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000727595709\/fe3b8fbb3cd6df497f752056dde39207_normal.jpeg",
      "id" : 153617129,
      "verified" : false
    }
  },
  "id" : 735140436394663936,
  "created_at" : "2016-05-24 16:08:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Michael Feldstein",
      "screen_name" : "mfeldstein67",
      "indices" : [ 33, 46 ],
      "id_str" : "10187072",
      "id" : 10187072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 12, 21 ]
    }, {
      "text" : "cwcon",
      "indices" : [ 138, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735140306471911424",
  "text" : "RT @btopro: #apereo16 got to ask @mfeldstein67 about possible impact of adjunct-ification of faculty and skipping LMS for local ownership.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Feldstein",
        "screen_name" : "mfeldstein67",
        "indices" : [ 21, 34 ],
        "id_str" : "10187072",
        "id" : 10187072
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "apereo16",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "cwcon",
        "indices" : [ 131, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735108868636856322",
    "text" : "#apereo16 got to ask @mfeldstein67 about possible impact of adjunct-ification of faculty and skipping LMS for local ownership. woo #cwcon :)",
    "id" : 735108868636856322,
    "created_at" : "2016-05-24 14:03:06 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 735140306471911424,
  "created_at" : "2016-05-24 16:08:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "RedSoxRedShoes",
      "indices" : [ 3, 18 ],
      "id_str" : "23626294",
      "id" : 23626294
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RedSoxRedShoes\/status\/735109550035107840\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/gFJWyKtLvR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjOiO6SVEAAcCPi.jpg",
      "id_str" : "735109541239525376",
      "id" : 735109541239525376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjOiO6SVEAAcCPi.jpg",
      "sizes" : [ {
        "h" : 558,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 558,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gFJWyKtLvR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735139851784224768",
  "text" : "RT @RedSoxRedShoes: Oh. Oh, no. This sounds like a disaster. https:\/\/t.co\/gFJWyKtLvR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RedSoxRedShoes\/status\/735109550035107840\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/gFJWyKtLvR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjOiO6SVEAAcCPi.jpg",
        "id_str" : "735109541239525376",
        "id" : 735109541239525376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjOiO6SVEAAcCPi.jpg",
        "sizes" : [ {
          "h" : 558,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 558,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/gFJWyKtLvR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735109550035107840",
    "text" : "Oh. Oh, no. This sounds like a disaster. https:\/\/t.co\/gFJWyKtLvR",
    "id" : 735109550035107840,
    "created_at" : "2016-05-24 14:05:49 +0000",
    "user" : {
      "name" : "Kevin",
      "screen_name" : "RedSoxRedShoes",
      "protected" : false,
      "id_str" : "23626294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697572153475100672\/EEZRSfRV_normal.jpg",
      "id" : 23626294,
      "verified" : false
    }
  },
  "id" : 735139851784224768,
  "created_at" : "2016-05-24 16:06:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Squillace",
      "screen_name" : "bobsquill",
      "indices" : [ 0, 10 ],
      "id_str" : "246613933",
      "id" : 246613933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734888524407812096",
  "geo" : { },
  "id_str" : "734905983005134848",
  "in_reply_to_user_id" : 246613933,
  "text" : "@bobsquill Great food for thought. This principle esp. '...should lean toward using tools that are in wide use outside the academic world.'\uD83D\uDC4D",
  "id" : 734905983005134848,
  "in_reply_to_status_id" : 734888524407812096,
  "created_at" : "2016-05-24 00:36:54 +0000",
  "in_reply_to_screen_name" : "bobsquill",
  "in_reply_to_user_id_str" : "246613933",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 10, 18 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 83, 91 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/pTMPHl38lW",
      "expanded_url" : "https:\/\/www.eventsforce.net\/concentra\/frontend\/reg\/titem.csp?pageID=4607&&eventID=9",
      "display_url" : "eventsforce.net\/concentra\/fron\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734862768340246528",
  "text" : "Thanks to @drchuck, #apereo16 attendees can check out the open &amp; collaborative @getgrav Course Hub Project on Tues. https:\/\/t.co\/pTMPHl38lW",
  "id" : 734862768340246528,
  "created_at" : "2016-05-23 21:45:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734802026832351232",
  "text" : "That moment you realize you need to completely rework your workshop slides. Yes, that moment has arrived.",
  "id" : 734802026832351232,
  "created_at" : "2016-05-23 17:43:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 33, 42 ],
      "id_str" : "890887814",
      "id" : 890887814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/01QG69eCZw",
      "expanded_url" : "https:\/\/swipe.to\/4340n",
      "display_url" : "swipe.to\/4340n"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/yXr0KMDUGm",
      "expanded_url" : "https:\/\/gist.github.com\/paulhibbitts\/528b8ac246ef75315c63fb5b92a88254",
      "display_url" : "gist.github.com\/paulhibbitts\/5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734519473345077248",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Thanks again for sharing @swipe_to. Here's my test deck so far https:\/\/t.co\/01QG69eCZw and in markdown \uD83D\uDE4C https:\/\/t.co\/yXr0KMDUGm",
  "id" : 734519473345077248,
  "created_at" : "2016-05-22 23:01:03 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "indices" : [ 72, 86 ],
      "id_str" : "3296136369",
      "id" : 3296136369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/iua0pjThFK",
      "expanded_url" : "https:\/\/twitter.com\/Josh412\/status\/734474604513796097",
      "display_url" : "twitter.com\/Josh412\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734498322879119361",
  "text" : "To me, it's clearly an issue of open vs. closed. I am also liking what  @RocketChatApp is doing in this space. https:\/\/t.co\/iua0pjThFK",
  "id" : 734498322879119361,
  "created_at" : "2016-05-22 21:37:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/BdSSzUOQpf",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/open-apereo-2016-grav-course-hub-project#\/",
      "display_url" : "slides.com\/paulhibbitts\/o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734423598455230467",
  "text" : "Grav Course Hub Project slides for #apereo16, part of Emerging Next Generation Digital Learning Environments session https:\/\/t.co\/BdSSzUOQpf",
  "id" : 734423598455230467,
  "created_at" : "2016-05-22 16:40:05 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/J420wZoNmc",
      "expanded_url" : "https:\/\/twitter.com\/oldaily\/status\/734409162516402178",
      "display_url" : "twitter.com\/oldaily\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734412105038888960",
  "text" : "This has been on my mind for my open source projects, where I am creating monetization *because of* free software. https:\/\/t.co\/J420wZoNmc",
  "id" : 734412105038888960,
  "created_at" : "2016-05-22 15:54:25 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 3, 10 ],
      "id_str" : "236846178",
      "id" : 236846178
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 86, 93 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Apereo Foundation",
      "screen_name" : "ApereoOrg",
      "indices" : [ 98, 108 ],
      "id_str" : "1117619618",
      "id" : 1117619618
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ngdle",
      "indices" : [ 133, 139 ]
    }, {
      "text" : "edtech",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/8orqqkY6Jx",
      "expanded_url" : "http:\/\/www.slideshare.net\/BryanOllendyke1\/elmsln-next-generation-digital-learning-environment",
      "display_url" : "slideshare.net\/BryanOllendyke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734402049513639936",
  "text" : "RT @elmsln: New slide deck: ELMS:LN - Next Generation Digital Learning Environment by @btopro for @ApereoOrg https:\/\/t.co\/8orqqkY6Jx #ngdle\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bryan Ollendyke",
        "screen_name" : "btopro",
        "indices" : [ 74, 81 ],
        "id_str" : "16847370",
        "id" : 16847370
      }, {
        "name" : "Apereo Foundation",
        "screen_name" : "ApereoOrg",
        "indices" : [ 86, 96 ],
        "id_str" : "1117619618",
        "id" : 1117619618
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ngdle",
        "indices" : [ 121, 127 ]
      }, {
        "text" : "edtech",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/8orqqkY6Jx",
        "expanded_url" : "http:\/\/www.slideshare.net\/BryanOllendyke1\/elmsln-next-generation-digital-learning-environment",
        "display_url" : "slideshare.net\/BryanOllendyke\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "734372992516554752",
    "text" : "New slide deck: ELMS:LN - Next Generation Digital Learning Environment by @btopro for @ApereoOrg https:\/\/t.co\/8orqqkY6Jx #ngdle #edtech",
    "id" : 734372992516554752,
    "created_at" : "2016-05-22 13:19:00 +0000",
    "user" : {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "protected" : false,
      "id_str" : "236846178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601925668025278465\/4j0l2bWZ_normal.png",
      "id" : 236846178,
      "verified" : false
    }
  },
  "id" : 734402049513639936,
  "created_at" : "2016-05-22 15:14:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 8, 17 ],
      "id_str" : "890887814",
      "id" : 890887814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734106347713794048",
  "geo" : { },
  "id_str" : "734106479662268416",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @swipe_to Awesome!!!",
  "id" : 734106479662268416,
  "in_reply_to_status_id" : 734106347713794048,
  "created_at" : "2016-05-21 19:39:58 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Swipe",
      "screen_name" : "swipe_to",
      "indices" : [ 8, 17 ],
      "id_str" : "890887814",
      "id" : 890887814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734030274917498880",
  "geo" : { },
  "id_str" : "734106070159761412",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @swipe_to Looks really good, getting the sense I am going to double-down with Markdown next term...",
  "id" : 734106070159761412,
  "in_reply_to_status_id" : 734030274917498880,
  "created_at" : "2016-05-21 19:38:20 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Saffer",
      "screen_name" : "odannyboy",
      "indices" : [ 3, 13 ],
      "id_str" : "3252",
      "id" : 3252
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/odannyboy\/status\/709900748528558081\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/w5b2AGziQr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdoS-CuVAAAaZeb.jpg",
      "id_str" : "709900748356648960",
      "id" : 709900748356648960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdoS-CuVAAAaZeb.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1295,
        "resize" : "fit",
        "w" : 1295
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/w5b2AGziQr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734102928957444096",
  "text" : "RT @odannyboy: Charles and Ray Eames, handwritten notes on design (1964). Last paragraph FTW. https:\/\/t.co\/w5b2AGziQr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/odannyboy\/status\/709900748528558081\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/w5b2AGziQr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdoS-CuVAAAaZeb.jpg",
        "id_str" : "709900748356648960",
        "id" : 709900748356648960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdoS-CuVAAAaZeb.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1295,
          "resize" : "fit",
          "w" : 1295
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/w5b2AGziQr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "709900748528558081",
    "text" : "Charles and Ray Eames, handwritten notes on design (1964). Last paragraph FTW. https:\/\/t.co\/w5b2AGziQr",
    "id" : 709900748528558081,
    "created_at" : "2016-03-16 00:35:02 +0000",
    "user" : {
      "name" : "Dan Saffer",
      "screen_name" : "odannyboy",
      "protected" : false,
      "id_str" : "3252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477328081057619968\/rKaB5tsc_normal.jpeg",
      "id" : 3252,
      "verified" : true
    }
  },
  "id" : 734102928957444096,
  "created_at" : "2016-05-21 19:25:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cwcon",
      "indices" : [ 12, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/ugfJ1XdgZK",
      "expanded_url" : "https:\/\/www.swipe.to",
      "display_url" : "swipe.to"
    } ]
  },
  "geo" : { },
  "id_str" : "734044701678931968",
  "text" : "RT @btopro: #cwcon now presenters showing how to turn markdown into a slide show presentation w\/ swipe . to https:\/\/t.co\/ugfJ1XdgZK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cwcon",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/ugfJ1XdgZK",
        "expanded_url" : "https:\/\/www.swipe.to",
        "display_url" : "swipe.to"
      } ]
    },
    "geo" : { },
    "id_str" : "734030274917498880",
    "text" : "#cwcon now presenters showing how to turn markdown into a slide show presentation w\/ swipe . to https:\/\/t.co\/ugfJ1XdgZK",
    "id" : 734030274917498880,
    "created_at" : "2016-05-21 14:37:09 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 734044701678931968,
  "created_at" : "2016-05-21 15:34:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cwcon",
      "indices" : [ 12, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734043505694105602",
  "text" : "RT @btopro: #cwcon really interesting discussion of markdown and getting students to understand it",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cwcon",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "734040772975157248",
    "text" : "#cwcon really interesting discussion of markdown and getting students to understand it",
    "id" : 734040772975157248,
    "created_at" : "2016-05-21 15:18:52 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 734043505694105602,
  "created_at" : "2016-05-21 15:29:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734032890254741504",
  "geo" : { },
  "id_str" : "734042835939262464",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Platform independent course content is where it's at \uD83D\uDE4C",
  "id" : 734042835939262464,
  "in_reply_to_status_id" : 734032890254741504,
  "created_at" : "2016-05-21 15:27:04 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/aYxZbIDtbZ",
      "expanded_url" : "https:\/\/medium.com\/made-with-creative-commons\/what-is-an-open-business-model-and-how-can-you-generate-revenue-5854d2659b15#.wsshk72kz",
      "display_url" : "medium.com\/made-with-crea\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "733798835063947266",
  "geo" : { },
  "id_str" : "733801278728511488",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro True, but for longevity financial the issue to me. Following this? https:\/\/t.co\/aYxZbIDtbZ Used CC open biz model for my Grav work.",
  "id" : 733801278728511488,
  "in_reply_to_status_id" : 733798835063947266,
  "created_at" : "2016-05-20 23:27:12 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733796383694688257",
  "geo" : { },
  "id_str" : "733798622588854272",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro And let's encourage everyone to financially support open source (in some manner if they can) when they use it themselves.",
  "id" : 733798622588854272,
  "in_reply_to_status_id" : 733796383694688257,
  "created_at" : "2016-05-20 23:16:39 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 63, 71 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 76, 83 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Apereo16",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/pTMPHlkJKw",
      "expanded_url" : "https:\/\/www.eventsforce.net\/concentra\/frontend\/reg\/titem.csp?pageID=4607&&eventID=9",
      "display_url" : "eventsforce.net\/concentra\/fron\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733791732412887040",
  "text" : "Really excited to be a part of this session, virtually joining @drchuck and @btopro at #Apereo16 next Tuesday. https:\/\/t.co\/pTMPHlkJKw",
  "id" : 733791732412887040,
  "created_at" : "2016-05-20 22:49:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Intercom",
      "screen_name" : "intercom",
      "indices" : [ 3, 12 ],
      "id_str" : "274788446",
      "id" : 274788446
    }, {
      "name" : "Sian Townsend",
      "screen_name" : "intercom_uxr",
      "indices" : [ 24, 37 ],
      "id_str" : "2707893679",
      "id" : 2707893679
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/intercom\/status\/733787166627762176\/photo\/1",
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/iRRsplOX8l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci7viiSXIAAeSal.jpg",
      "id_str" : "733787165906378752",
      "id" : 733787165906378752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci7viiSXIAAeSal.jpg",
      "sizes" : [ {
        "h" : 161,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/iRRsplOX8l"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/0b9gCTQkoK",
      "expanded_url" : "http:\/\/blog.intercom.io\/jobs-to-be-done-doubter-believer\/",
      "display_url" : "blog.intercom.io\/jobs-to-be-don\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733788036950052864",
  "text" : "RT @intercom: New post: @intercom_uxr shares her journey from Jobs-to-be-Done doubter to believer https:\/\/t.co\/0b9gCTQkoK https:\/\/t.co\/iRRs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sian Townsend",
        "screen_name" : "intercom_uxr",
        "indices" : [ 10, 23 ],
        "id_str" : "2707893679",
        "id" : 2707893679
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/intercom\/status\/733787166627762176\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/iRRsplOX8l",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci7viiSXIAAeSal.jpg",
        "id_str" : "733787165906378752",
        "id" : 733787165906378752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci7viiSXIAAeSal.jpg",
        "sizes" : [ {
          "h" : 161,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 485,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 485,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 284,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/iRRsplOX8l"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/0b9gCTQkoK",
        "expanded_url" : "http:\/\/blog.intercom.io\/jobs-to-be-done-doubter-believer\/",
        "display_url" : "blog.intercom.io\/jobs-to-be-don\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733787166627762176",
    "text" : "New post: @intercom_uxr shares her journey from Jobs-to-be-Done doubter to believer https:\/\/t.co\/0b9gCTQkoK https:\/\/t.co\/iRRsplOX8l",
    "id" : 733787166627762176,
    "created_at" : "2016-05-20 22:31:08 +0000",
    "user" : {
      "name" : "Intercom",
      "screen_name" : "intercom",
      "protected" : false,
      "id_str" : "274788446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652527891700428800\/iWpbzpjL_normal.png",
      "id" : 274788446,
      "verified" : true
    }
  },
  "id" : 733788036950052864,
  "created_at" : "2016-05-20 22:34:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 108, 116 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/NSynvfQEf8",
      "expanded_url" : "https:\/\/twitter.com\/ProfHacker\/status\/733675761790529536",
      "display_url" : "twitter.com\/ProfHacker\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733754276774694912",
  "text" : "GitHub is a great collab platform for static site generators like Jekyll and dynamic flat-file CMSs such as @getgrav https:\/\/t.co\/NSynvfQEf8",
  "id" : 733754276774694912,
  "created_at" : "2016-05-20 20:20:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Anderson",
      "screen_name" : "Steve_Media",
      "indices" : [ 3, 15 ],
      "id_str" : "2099411",
      "id" : 2099411
    }, {
      "name" : "Hossein Derakhshan",
      "screen_name" : "h0d3r",
      "indices" : [ 56, 62 ],
      "id_str" : "16779204",
      "id" : 16779204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/zdWxtRVJzd",
      "expanded_url" : "https:\/\/medium.com\/@h0d3r\/bridges-mark-zuckerberg-destroyed-e005d1703216#.byfqt8q8c",
      "display_url" : "medium.com\/@h0d3r\/bridges\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733444454502137857",
  "text" : "RT @Steve_Media: \u201CBridges Mark Zuckerberg Destroyed\u201D by @h0d3r https:\/\/t.co\/zdWxtRVJzd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hossein Derakhshan",
        "screen_name" : "h0d3r",
        "indices" : [ 39, 45 ],
        "id_str" : "16779204",
        "id" : 16779204
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/zdWxtRVJzd",
        "expanded_url" : "https:\/\/medium.com\/@h0d3r\/bridges-mark-zuckerberg-destroyed-e005d1703216#.byfqt8q8c",
        "display_url" : "medium.com\/@h0d3r\/bridges\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733442520043028480",
    "text" : "\u201CBridges Mark Zuckerberg Destroyed\u201D by @h0d3r https:\/\/t.co\/zdWxtRVJzd",
    "id" : 733442520043028480,
    "created_at" : "2016-05-19 23:41:38 +0000",
    "user" : {
      "name" : "Steve Anderson",
      "screen_name" : "Steve_Media",
      "protected" : false,
      "id_str" : "2099411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653865045177176065\/EOB9LMxo_normal.jpg",
      "id" : 2099411,
      "verified" : false
    }
  },
  "id" : 733444454502137857,
  "created_at" : "2016-05-19 23:49:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733444138947878912",
  "text" : "Feeling pretty jazzed about the synergy I see with my pivot into the open source product space and future UX design courses that I may teach",
  "id" : 733444138947878912,
  "created_at" : "2016-05-19 23:48:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 30, 38 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 43, 50 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733433487533838337",
  "text" : "Move beyond your LMS by using @getgrav and @github as an open and collaborative platform with the Grav Course Hub. https:\/\/t.co\/VgQsw7bHP4",
  "id" : 733433487533838337,
  "created_at" : "2016-05-19 23:05:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 75, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/nas5yl5I6D",
      "expanded_url" : "https:\/\/workflowy.com\/s\/o8Vzx5uGCt",
      "display_url" : "workflowy.com\/s\/o8Vzx5uGCt"
    } ]
  },
  "geo" : { },
  "id_str" : "733412172961701888",
  "text" : "Draft list of course assessments for next possible offering of CMPT-363 at #SFU https:\/\/t.co\/nas5yl5I6D Thoughts fellow UX peeps\/educators?",
  "id" : 733412172961701888,
  "created_at" : "2016-05-19 21:41:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733406022954455042",
  "geo" : { },
  "id_str" : "733406258942763009",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Yes, this is key - am planning doing this via in-class 'expert' review to setup individual peer reviews of assignments",
  "id" : 733406258942763009,
  "in_reply_to_status_id" : 733406022954455042,
  "created_at" : "2016-05-19 21:17:32 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733405619311509504",
  "geo" : { },
  "id_str" : "733406043632340993",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Could do, but thinking real project more likely broader learning opps and the best reports could be volunteered to be shared \uD83D\uDE42",
  "id" : 733406043632340993,
  "in_reply_to_status_id" : 733405619311509504,
  "created_at" : "2016-05-19 21:16:41 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733404247606366208",
  "geo" : { },
  "id_str" : "733405361697214464",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Also thinking that as 1st individual assignment I pick one open source project which all students usability inspect + peer review.",
  "id" : 733405361697214464,
  "in_reply_to_status_id" : 733404247606366208,
  "created_at" : "2016-05-19 21:13:58 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733404247606366208",
  "geo" : { },
  "id_str" : "733405030942793728",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Thanks for sharing your workflow and ideas, extremely helpful! Mulling over project selection, scope, etc.",
  "id" : 733405030942793728,
  "in_reply_to_status_id" : 733404247606366208,
  "created_at" : "2016-05-19 21:12:40 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SaraWachterBoettcher",
      "screen_name" : "sara_ann_marie",
      "indices" : [ 3, 18 ],
      "id_str" : "14424551",
      "id" : 14424551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/r3DdLS5lUE",
      "expanded_url" : "https:\/\/www.surveymonkey.com\/r\/6CFRHZR",
      "display_url" : "surveymonkey.com\/r\/6CFRHZR"
    } ]
  },
  "geo" : { },
  "id_str" : "733392343894654977",
  "text" : "RT @sara_ann_marie: Have you recently\/are you currently selecting a CMS? Please take 5 minutes and tell me about it: https:\/\/t.co\/r3DdLS5lUE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/r3DdLS5lUE",
        "expanded_url" : "https:\/\/www.surveymonkey.com\/r\/6CFRHZR",
        "display_url" : "surveymonkey.com\/r\/6CFRHZR"
      } ]
    },
    "geo" : { },
    "id_str" : "733391808001118208",
    "text" : "Have you recently\/are you currently selecting a CMS? Please take 5 minutes and tell me about it: https:\/\/t.co\/r3DdLS5lUE",
    "id" : 733391808001118208,
    "created_at" : "2016-05-19 20:20:07 +0000",
    "user" : {
      "name" : "SaraWachterBoettcher",
      "screen_name" : "sara_ann_marie",
      "protected" : false,
      "id_str" : "14424551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539406496144977920\/Z7ibQxu8_normal.jpeg",
      "id" : 14424551,
      "verified" : false
    }
  },
  "id" : 733392343894654977,
  "created_at" : "2016-05-19 20:22:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 32, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733386749175562240",
  "text" : "Right now I see the process for #UX contribs to open source projects as:\n1) Research\n2) Usability test\n3) Mockup designs\n4) Usability test",
  "id" : 733386749175562240,
  "created_at" : "2016-05-19 20:00:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733378205197971458",
  "geo" : { },
  "id_str" : "733380678553763840",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro How about this process?\n1) Choose proj. + do research\n2) Conduct usability tests + share\n3) Mockup design solutions, test and share",
  "id" : 733380678553763840,
  "in_reply_to_status_id" : 733378205197971458,
  "created_at" : "2016-05-19 19:35:53 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733378205197971458",
  "geo" : { },
  "id_str" : "733379458367885314",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Love to run a few ideas by you to get your thoughts re: process outline for my students about engagement, etc.",
  "id" : 733379458367885314,
  "in_reply_to_status_id" : 733378205197971458,
  "created_at" : "2016-05-19 19:31:03 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Brumfield",
      "screen_name" : "Brumface",
      "indices" : [ 3, 12 ],
      "id_str" : "60716903",
      "id" : 60716903
    }, {
      "name" : "aj",
      "screen_name" : "n33co",
      "indices" : [ 126, 132 ],
      "id_str" : "994584506",
      "id" : 994584506
    }, {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 133, 140 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ljG66wqkmG",
      "expanded_url" : "http:\/\/labrumfield.com\/site-publisher-html-5-up\/",
      "display_url" : "labrumfield.com\/site-publisher\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733379176561016832",
  "text" : "RT @Brumface: Don't be scared of your File Manager, people! Using an HTML5 UP template is easy peasy: https:\/\/t.co\/ljG66wqkmG @n33co @Recla\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "aj",
        "screen_name" : "n33co",
        "indices" : [ 112, 118 ],
        "id_str" : "994584506",
        "id" : 994584506
      }, {
        "name" : "Reclaim Hosting",
        "screen_name" : "ReclaimHosting",
        "indices" : [ 119, 134 ],
        "id_str" : "1602053274",
        "id" : 1602053274
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/ljG66wqkmG",
        "expanded_url" : "http:\/\/labrumfield.com\/site-publisher-html-5-up\/",
        "display_url" : "labrumfield.com\/site-publisher\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733376342641811460",
    "text" : "Don't be scared of your File Manager, people! Using an HTML5 UP template is easy peasy: https:\/\/t.co\/ljG66wqkmG @n33co @ReclaimHosting",
    "id" : 733376342641811460,
    "created_at" : "2016-05-19 19:18:40 +0000",
    "user" : {
      "name" : "Lauren Brumfield",
      "screen_name" : "Brumface",
      "protected" : false,
      "id_str" : "60716903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754808496831344640\/vm6bbAnx_normal.jpg",
      "id" : 60716903,
      "verified" : false
    }
  },
  "id" : 733379176561016832,
  "created_at" : "2016-05-19 19:29:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 89, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733377759393677313",
  "text" : "Exploring integrating actual open source projects into my next 13-week long introductory #UX design course. Looks like a win-win so far...",
  "id" : 733377759393677313,
  "created_at" : "2016-05-19 19:24:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733370605857308673",
  "text" : "(4\/4) To eliminate the significant pain points for themselves and their students related to using the existing LMS alone.",
  "id" : 733370605857308673,
  "created_at" : "2016-05-19 18:55:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733370561586401281",
  "text" : "(3\/4) The CUSTOMERS of the Grav Course Hub are institutions who want to support instructors to most effectively use the Grav Course Hub and",
  "id" : 733370561586401281,
  "created_at" : "2016-05-19 18:55:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733370510373998592",
  "text" : "(2\/4) The USERS of the Grav Course Hub are tech-savvy instructors who cannot reach their pedagogical and\/or experience goals within the LMS.",
  "id" : 733370510373998592,
  "created_at" : "2016-05-19 18:55:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733370470955921409",
  "text" : "(1\/4) When creating a sustainable open source project, identify users vs. paying customers and address each group's needs. For example:",
  "id" : 733370470955921409,
  "created_at" : "2016-05-19 18:55:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danmaccarone",
      "screen_name" : "danmaccarone",
      "indices" : [ 37, 50 ],
      "id_str" : "15395679",
      "id" : 15395679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/3PXGdGOMZl",
      "expanded_url" : "https:\/\/medium.com\/@danmaccarone\/the-ux-of-learning-ux-is-broken-f972b27d3273#.595uww8mw",
      "display_url" : "medium.com\/@danmaccarone\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733124772712714240",
  "text" : "\u201CThe UX of Learning UX is Broken\u201D by @danmaccarone https:\/\/t.co\/3PXGdGOMZl",
  "id" : 733124772712714240,
  "created_at" : "2016-05-19 02:39:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JP Holecka",
      "screen_name" : "jaypiddy",
      "indices" : [ 3, 12 ],
      "id_str" : "14170236",
      "id" : 14170236
    }, {
      "name" : "Mette Maagensen",
      "screen_name" : "maagenss",
      "indices" : [ 38, 47 ],
      "id_str" : "200806908",
      "id" : 200806908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/akuwBHTqwq",
      "expanded_url" : "http:\/\/justshift.it\/1rV2fqy",
      "display_url" : "justshift.it\/1rV2fqy"
    } ]
  },
  "geo" : { },
  "id_str" : "733116846757421058",
  "text" : "RT @jaypiddy: Thanks for the reminder @maagenss - 13 Ways Designers Screw Up Client Presentations - Mule https:\/\/t.co\/akuwBHTqwq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mette Maagensen",
        "screen_name" : "maagenss",
        "indices" : [ 24, 33 ],
        "id_str" : "200806908",
        "id" : 200806908
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/akuwBHTqwq",
        "expanded_url" : "http:\/\/justshift.it\/1rV2fqy",
        "display_url" : "justshift.it\/1rV2fqy"
      } ]
    },
    "geo" : { },
    "id_str" : "733107714289729537",
    "text" : "Thanks for the reminder @maagenss - 13 Ways Designers Screw Up Client Presentations - Mule https:\/\/t.co\/akuwBHTqwq",
    "id" : 733107714289729537,
    "created_at" : "2016-05-19 01:31:14 +0000",
    "user" : {
      "name" : "JP Holecka",
      "screen_name" : "jaypiddy",
      "protected" : false,
      "id_str" : "14170236",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573368979030327296\/4IfUAHlr_normal.jpeg",
      "id" : 14170236,
      "verified" : false
    }
  },
  "id" : 733116846757421058,
  "created_at" : "2016-05-19 02:07:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "digped",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/48c3nqzndO",
      "expanded_url" : "https:\/\/twitter.com\/btopro\/status\/733082390478901253",
      "display_url" : "twitter.com\/btopro\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733083804508651520",
  "text" : "'Flipping' your LMS with an open + collaborative platform one option for instructors https:\/\/t.co\/VgQsw7bHP4 #digped https:\/\/t.co\/48c3nqzndO",
  "id" : 733083804508651520,
  "created_at" : "2016-05-18 23:56:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asheesh Laroia",
      "screen_name" : "asheeshlaroia",
      "indices" : [ 0, 14 ],
      "id_str" : "35121912",
      "id" : 35121912
    }, {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 15, 27 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    }, {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 28, 40 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733047647590719488",
  "geo" : { },
  "id_str" : "733050530302468097",
  "in_reply_to_user_id" : 35121912,
  "text" : "@asheeshlaroia @SandstormIO @grantpotter Thanks very much for the info! Will keep my fingers crossed onPowerBox development too.",
  "id" : 733050530302468097,
  "in_reply_to_status_id" : 733047647590719488,
  "created_at" : "2016-05-18 21:44:00 +0000",
  "in_reply_to_screen_name" : "asheeshlaroia",
  "in_reply_to_user_id_str" : "35121912",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "indices" : [ 3, 15 ],
      "id_str" : "66913866",
      "id" : 66913866
    }, {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "indices" : [ 41, 48 ],
      "id_str" : "944913038",
      "id" : 944913038
    }, {
      "name" : "Bryan T Robertson",
      "screen_name" : "bryantrobertson",
      "indices" : [ 117, 133 ],
      "id_str" : "17884923",
      "id" : 17884923
    }, {
      "name" : "jaybeallanson",
      "screen_name" : "jaybeallanson",
      "indices" : [ 134, 140 ],
      "id_str" : "14180317",
      "id" : 14180317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/vsvOOUVMAp",
      "expanded_url" : "http:\/\/www.meetup.com\/VancouverUE\/events\/231168217\/",
      "display_url" : "meetup.com\/VancouverUE\/ev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733043564532240384",
  "text" : "RT @openroadies: Have you registered for @Van_UE 's e-commerce ux lightning talks? https:\/\/t.co\/vsvOOUVMAp Featuring @bryantrobertson @jayb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VanUE",
        "screen_name" : "Van_UE",
        "indices" : [ 24, 31 ],
        "id_str" : "944913038",
        "id" : 944913038
      }, {
        "name" : "Bryan T Robertson",
        "screen_name" : "bryantrobertson",
        "indices" : [ 100, 116 ],
        "id_str" : "17884923",
        "id" : 17884923
      }, {
        "name" : "jaybeallanson",
        "screen_name" : "jaybeallanson",
        "indices" : [ 117, 131 ],
        "id_str" : "14180317",
        "id" : 14180317
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/vsvOOUVMAp",
        "expanded_url" : "http:\/\/www.meetup.com\/VancouverUE\/events\/231168217\/",
        "display_url" : "meetup.com\/VancouverUE\/ev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733040671754358785",
    "text" : "Have you registered for @Van_UE 's e-commerce ux lightning talks? https:\/\/t.co\/vsvOOUVMAp Featuring @bryantrobertson @jaybeallanson + more",
    "id" : 733040671754358785,
    "created_at" : "2016-05-18 21:04:50 +0000",
    "user" : {
      "name" : "OpenRoad",
      "screen_name" : "openroadies",
      "protected" : false,
      "id_str" : "66913866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554783440747237376\/HA2Svg4h_normal.png",
      "id" : 66913866,
      "verified" : false
    }
  },
  "id" : 733043564532240384,
  "created_at" : "2016-05-18 21:16:19 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asheesh Laroia",
      "screen_name" : "asheeshlaroia",
      "indices" : [ 0, 14 ],
      "id_str" : "35121912",
      "id" : 35121912
    }, {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 15, 27 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    }, {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 97, 109 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733039963642597377",
  "geo" : { },
  "id_str" : "733042372506836992",
  "in_reply_to_user_id" : 35121912,
  "text" : "@asheeshlaroia @SandstormIO Is this something I can do or need site admin? I am on the site that @grantpotter is the admin for. Thanks!",
  "id" : 733042372506836992,
  "in_reply_to_status_id" : 733039963642597377,
  "created_at" : "2016-05-18 21:11:35 +0000",
  "in_reply_to_screen_name" : "asheeshlaroia",
  "in_reply_to_user_id_str" : "35121912",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asheesh Laroia",
      "screen_name" : "asheeshlaroia",
      "indices" : [ 0, 14 ],
      "id_str" : "35121912",
      "id" : 35121912
    }, {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 15, 27 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733032660797292544",
  "geo" : { },
  "id_str" : "733033412236181504",
  "in_reply_to_user_id" : 35121912,
  "text" : "@asheeshlaroia @SandstormIO Thanks so much for your reply! Outbound hooks, so an update to repo can trigger auto deploy. Any PB timelines?",
  "id" : 733033412236181504,
  "in_reply_to_status_id" : 733032660797292544,
  "created_at" : "2016-05-18 20:35:59 +0000",
  "in_reply_to_screen_name" : "asheeshlaroia",
  "in_reply_to_user_id_str" : "35121912",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 0, 12 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733029608581255168",
  "in_reply_to_user_id" : 2476570038,
  "text" : "@SandstormIO The closest I've gotten is Gogs with Webhooks, but then my deployment server wants to also have a username and password.",
  "id" : 733029608581255168,
  "created_at" : "2016-05-18 20:20:52 +0000",
  "in_reply_to_screen_name" : "SandstormIO",
  "in_reply_to_user_id_str" : "2476570038",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 0, 12 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733028727299284992",
  "in_reply_to_user_id" : 2476570038,
  "text" : "@SandstormIO Any plans for Sandstorm.io to enable Webhooks for Git apps? I've tried all three apps and can't find one that does this. TY.",
  "id" : 733028727299284992,
  "created_at" : "2016-05-18 20:17:22 +0000",
  "in_reply_to_screen_name" : "SandstormIO",
  "in_reply_to_user_id_str" : "2476570038",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 62, 70 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 8, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/J6mvVBlMbT",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1T_275jM2Q892ZSbUOu0l0nGsccisNNwlMcA4_gytOGo\/edit#bookmark=id.ao50qefa3bl1",
      "display_url" : "docs.google.com\/document\/d\/1T_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733003939784744961",
  "text" : "Today's #FoL16 workshop prep? In one page describe how to use @getgrav with the open + collaborative service GitHub\uD83D\uDC4D https:\/\/t.co\/J6mvVBlMbT",
  "id" : 733003939784744961,
  "created_at" : "2016-05-18 18:38:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 11, 19 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/fXOsasWJn1",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1T_275jM2Q892ZSbUOu0l0nGsccisNNwlMcA4_gytOGo\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1T_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732706906200932352",
  "text" : "Handout on @getgrav CMS for 1-minute local install, adding a page, a blog, modular content, and even Markdown tips!\uD83D\uDC4D https:\/\/t.co\/fXOsasWJn1",
  "id" : 732706906200932352,
  "created_at" : "2016-05-17 22:58:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/zpQKv2BAgQ",
      "expanded_url" : "http:\/\/paulhibbitts.net\/sfu\/grav-skeleton-course-hub\/resources",
      "display_url" : "paulhibbitts.net\/sfu\/grav-skele\u2026"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/5VNWOEA554",
      "expanded_url" : "https:\/\/csil-git1.cs.surrey.sfu.ca\/paulh\/grav-skeleton-course-hub-site\/edit\/master\/user\/pages\/02.resources\/page.md",
      "display_url" : "csil-git1.cs.surrey.sfu.ca\/paulh\/grav-ske\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732681659967930368",
  "text" : "(4\/4) What might this approach look like?  \nWebpage:\nhttps:\/\/t.co\/zpQKv2BAgQ\nLinked GitLab repo (FIPPA compliant):\nhttps:\/\/t.co\/5VNWOEA554",
  "id" : 732681659967930368,
  "created_at" : "2016-05-17 21:18:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732681575322652674",
  "text" : "(3\/4) for your students with their on-line environment. Educators can also help fellow educators by directly contributing to course repos.",
  "id" : 732681575322652674,
  "created_at" : "2016-05-17 21:17:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732681536177233920",
  "text" : "(2\/4) such as GitHub\/GitLab and not only make your course content truly accessible for re-use but also enable active collaboration...",
  "id" : 732681536177233920,
  "created_at" : "2016-05-17 21:17:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 89, 97 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732681485392584705",
  "text" : "(1\/4) Here's the thing, in 2016 you can couple a modern flat-file (no database) CMS like @getgrav with an open and collaborative service...",
  "id" : 732681485392584705,
  "created_at" : "2016-05-17 21:17:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reclaim Hosting",
      "screen_name" : "ReclaimHosting",
      "indices" : [ 22, 37 ],
      "id_str" : "1602053274",
      "id" : 1602053274
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/732612115131858945\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ja1efL53Ls",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CirC1c1VEAAN0cy.jpg",
      "id_str" : "732612112929853440",
      "id" : 732612112929853440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CirC1c1VEAAN0cy.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2988,
        "resize" : "fit",
        "w" : 5312
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ja1efL53Ls"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732612115131858945",
  "text" : "Love everything about @ReclaimHosting, and this nicely put together package is the icing on the cake. https:\/\/t.co\/ja1efL53Ls",
  "id" : 732612115131858945,
  "created_at" : "2016-05-17 16:41:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732363419240808448",
  "geo" : { },
  "id_str" : "732372455713447937",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Well, maybe not...",
  "id" : 732372455713447937,
  "in_reply_to_status_id" : 732363419240808448,
  "created_at" : "2016-05-17 00:49:34 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "indices" : [ 3, 10 ],
      "id_str" : "944913038",
      "id" : 944913038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 123, 126 ]
    }, {
      "text" : "yvr",
      "indices" : [ 127, 131 ]
    }, {
      "text" : "ecommerce",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/1hd9IlhAIH",
      "expanded_url" : "http:\/\/www.meetup.com\/VancouverUE\/",
      "display_url" : "meetup.com\/VancouverUE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "732372176309911552",
  "text" : "RT @Van_UE: New Event Announced! Putting the Shopper at the Centre: E-commerce UX Lightning Talks: https:\/\/t.co\/1hd9IlhAIH #ux #yvr #ecomme\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ux",
        "indices" : [ 111, 114 ]
      }, {
        "text" : "yvr",
        "indices" : [ 115, 119 ]
      }, {
        "text" : "ecommerce",
        "indices" : [ 120, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/1hd9IlhAIH",
        "expanded_url" : "http:\/\/www.meetup.com\/VancouverUE\/",
        "display_url" : "meetup.com\/VancouverUE\/"
      } ]
    },
    "geo" : { },
    "id_str" : "732370600019156992",
    "text" : "New Event Announced! Putting the Shopper at the Centre: E-commerce UX Lightning Talks: https:\/\/t.co\/1hd9IlhAIH #ux #yvr #ecommerce",
    "id" : 732370600019156992,
    "created_at" : "2016-05-17 00:42:12 +0000",
    "user" : {
      "name" : "VanUE",
      "screen_name" : "Van_UE",
      "protected" : false,
      "id_str" : "944913038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2842592785\/c138e36411049b83817c208ab9149c60_normal.png",
      "id" : 944913038,
      "verified" : false
    }
  },
  "id" : 732372176309911552,
  "created_at" : "2016-05-17 00:48:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732363419240808448",
  "geo" : { },
  "id_str" : "732365132999708672",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Well, a better start to the game so far \uD83D\uDE0A",
  "id" : 732365132999708672,
  "in_reply_to_status_id" : 732363419240808448,
  "created_at" : "2016-05-17 00:20:29 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 33, 41 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 55, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/itVjf6ywF4",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1FIA1jXwjGkiEjvHte8CExrGGh8IuiuDoaNcEPeOuRog\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1FI\u2026"
    }, {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/sBYHaABtgF",
      "expanded_url" : "http:\/\/paulhibbitts.net\/grav\/workshop-demo-site\/",
      "display_url" : "paulhibbitts.net\/grav\/workshop-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732340752240414720",
  "text" : "Working on the materials for the @getgrav CMS table at #FoL16 Maker Faire, June 8th. https:\/\/t.co\/itVjf6ywF4 https:\/\/t.co\/sBYHaABtgF",
  "id" : 732340752240414720,
  "created_at" : "2016-05-16 22:43:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 3, 15 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opensource",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/1tdQQS76D3",
      "expanded_url" : "https:\/\/opensource.com\/life\/16\/1\/8-ways-contribute-open-source-without-writing-code",
      "display_url" : "opensource.com\/life\/16\/1\/8-wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732282821562138624",
  "text" : "RT @grantpotter: 8 non-code ways to contribute to #opensource https:\/\/t.co\/1tdQQS76D3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/known.networkeffects.ca\" rel=\"nofollow\"\u003Eknown-twitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opensource",
        "indices" : [ 33, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/1tdQQS76D3",
        "expanded_url" : "https:\/\/opensource.com\/life\/16\/1\/8-ways-contribute-open-source-without-writing-code",
        "display_url" : "opensource.com\/life\/16\/1\/8-wa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732282222091370496",
    "text" : "8 non-code ways to contribute to #opensource https:\/\/t.co\/1tdQQS76D3",
    "id" : 732282222091370496,
    "created_at" : "2016-05-16 18:51:01 +0000",
    "user" : {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "protected" : false,
      "id_str" : "6271482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639833921228640256\/S63CDenk_normal.jpg",
      "id" : 6271482,
      "verified" : false
    }
  },
  "id" : 732282821562138624,
  "created_at" : "2016-05-16 18:53:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 107, 115 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Sc2GyYkQ0W",
      "expanded_url" : "https:\/\/twitter.com\/iandolphin24\/status\/732174134709526528",
      "display_url" : "twitter.com\/iandolphin24\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732264590029918208",
  "text" : "I'll be 'beaming' in on Tues. to share an overview of flipping an LMS w. the open + collaborative platform @getgrav. https:\/\/t.co\/Sc2GyYkQ0W",
  "id" : 732264590029918208,
  "created_at" : "2016-05-16 17:40:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/732257439630786560\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/yafuTGSqX1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CimAQtjUYAALumk.jpg",
      "id_str" : "732257439018409984",
      "id" : 732257439018409984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CimAQtjUYAALumk.jpg",
      "sizes" : [ {
        "h" : 311,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 759
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 759
      } ],
      "display_url" : "pic.twitter.com\/yafuTGSqX1"
    } ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 41, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732257439630786560",
  "text" : "Getting closer now - next iteration of a #UX course outline in the form of a series of questions - comments? https:\/\/t.co\/yafuTGSqX1",
  "id" : 732257439630786560,
  "created_at" : "2016-05-16 17:12:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Skosnik",
      "screen_name" : "thinkingmaven",
      "indices" : [ 0, 14 ],
      "id_str" : "419728487",
      "id" : 419728487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732253016200351744",
  "geo" : { },
  "id_str" : "732255655906529280",
  "in_reply_to_user_id" : 419728487,
  "text" : "@thinkingmaven Very helpful feedback, thanks again Laura!",
  "id" : 732255655906529280,
  "in_reply_to_status_id" : 732253016200351744,
  "created_at" : "2016-05-16 17:05:27 +0000",
  "in_reply_to_screen_name" : "thinkingmaven",
  "in_reply_to_user_id_str" : "419728487",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Skosnik",
      "screen_name" : "thinkingmaven",
      "indices" : [ 0, 14 ],
      "id_str" : "419728487",
      "id" : 419728487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732248049582362624",
  "geo" : { },
  "id_str" : "732252085131976704",
  "in_reply_to_user_id" : 419728487,
  "text" : "@thinkingmaven Thanks for the feedback! Q2, but maybe I should tweak to 'What does a holistic user experience design process look like?'?",
  "id" : 732252085131976704,
  "in_reply_to_status_id" : 732248049582362624,
  "created_at" : "2016-05-16 16:51:16 +0000",
  "in_reply_to_screen_name" : "thinkingmaven",
  "in_reply_to_user_id_str" : "419728487",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "indices" : [ 3, 15 ],
      "id_str" : "2476570038",
      "id" : 2476570038
    }, {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 118, 127 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SandstormIO\/status\/731540509454405635\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Z0n38LKBiO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cib0N5sXEAA9TOn.jpg",
      "id_str" : "731540509156642816",
      "id" : 731540509156642816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cib0N5sXEAA9TOn.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Z0n38LKBiO"
    } ],
    "hashtags" : [ {
      "text" : "opensource",
      "indices" : [ 62, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/FuhNEg7JCU",
      "expanded_url" : "http:\/\/ow.ly\/g9ut300ccAz",
      "display_url" : "ow.ly\/g9ut300ccAz"
    } ]
  },
  "geo" : { },
  "id_str" : "731543213152993280",
  "text" : "RT @SandstormIO: Educators at BCOETC use Sandstorm to provide #opensource tools to educators: https:\/\/t.co\/FuhNEg7JCU @bccampus https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BCcampus",
        "screen_name" : "BCcampus",
        "indices" : [ 101, 110 ],
        "id_str" : "93710949",
        "id" : 93710949
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SandstormIO\/status\/731540509454405635\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/Z0n38LKBiO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cib0N5sXEAA9TOn.jpg",
        "id_str" : "731540509156642816",
        "id" : 731540509156642816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cib0N5sXEAA9TOn.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Z0n38LKBiO"
      } ],
      "hashtags" : [ {
        "text" : "opensource",
        "indices" : [ 45, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/FuhNEg7JCU",
        "expanded_url" : "http:\/\/ow.ly\/g9ut300ccAz",
        "display_url" : "ow.ly\/g9ut300ccAz"
      } ]
    },
    "geo" : { },
    "id_str" : "731540509454405635",
    "text" : "Educators at BCOETC use Sandstorm to provide #opensource tools to educators: https:\/\/t.co\/FuhNEg7JCU @bccampus https:\/\/t.co\/Z0n38LKBiO",
    "id" : 731540509454405635,
    "created_at" : "2016-05-14 17:43:43 +0000",
    "user" : {
      "name" : "Sandstorm.IO",
      "screen_name" : "SandstormIO",
      "protected" : false,
      "id_str" : "2476570038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463413707150589952\/s17ccuOO_normal.png",
      "id" : 2476570038,
      "verified" : false
    }
  },
  "id" : 731543213152993280,
  "created_at" : "2016-05-14 17:54:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Jesse Stommel",
      "screen_name" : "Jessifer",
      "indices" : [ 8, 17 ],
      "id_str" : "11702102",
      "id" : 11702102
    }, {
      "name" : "Anita R. Walz",
      "screen_name" : "ARWalz",
      "indices" : [ 18, 25 ],
      "id_str" : "2168962004",
      "id" : 2168962004
    }, {
      "name" : "Bryan Alexander",
      "screen_name" : "BryanAlexander",
      "indices" : [ 26, 41 ],
      "id_str" : "755991",
      "id" : 755991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/VgQsw7bHP4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-12-grav-course-hub-getting-started-guide",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "731273075849826304",
  "geo" : { },
  "id_str" : "731294783071649792",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @Jessifer @ARWalz @BryanAlexander More info about my flipped-LMS approach with an open + collab platform at https:\/\/t.co\/VgQsw7bHP4",
  "id" : 731294783071649792,
  "in_reply_to_status_id" : 731273075849826304,
  "created_at" : "2016-05-14 01:27:17 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 3, 7 ],
      "id_str" : "1063291",
      "id" : 1063291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/EjFA3aQThu",
      "expanded_url" : "http:\/\/ow.ly\/43jn300aU0p",
      "display_url" : "ow.ly\/43jn300aU0p"
    } ]
  },
  "geo" : { },
  "id_str" : "731206619627814913",
  "text" : "RT @UIE: Have you reconsidered what \u201Cmobile\u201D means recently? \u2022 https:\/\/t.co\/EjFA3aQThu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/EjFA3aQThu",
        "expanded_url" : "http:\/\/ow.ly\/43jn300aU0p",
        "display_url" : "ow.ly\/43jn300aU0p"
      } ]
    },
    "geo" : { },
    "id_str" : "731204933454839808",
    "text" : "Have you reconsidered what \u201Cmobile\u201D means recently? \u2022 https:\/\/t.co\/EjFA3aQThu",
    "id" : 731204933454839808,
    "created_at" : "2016-05-13 19:30:15 +0000",
    "user" : {
      "name" : "UIE",
      "screen_name" : "UIE",
      "protected" : false,
      "id_str" : "1063291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3759116326\/19308cfcdb0b831111d4ee3fc3e6232c_normal.jpeg",
      "id" : 1063291,
      "verified" : false
    }
  },
  "id" : 731206619627814913,
  "created_at" : "2016-05-13 19:36:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 3, 15 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcpse",
      "indices" : [ 17, 23 ]
    }, {
      "text" : "highered",
      "indices" : [ 24, 33 ]
    }, {
      "text" : "bcoet",
      "indices" : [ 34, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/848XLykwht",
      "expanded_url" : "http:\/\/known.networkeffects.ca\/2016\/bcpse-highered-bcoet-clusters-of-institutions-could-form-consortia-to",
      "display_url" : "known.networkeffects.ca\/2016\/bcpse-hig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731161432197234690",
  "text" : "RT @grantpotter: #bcpse #highered #bcoet \"Clusters of institutions could form consortia to set up co-ops to provide a buffet of .. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/known.networkeffects.ca\" rel=\"nofollow\"\u003Eknown-twitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bcpse",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "highered",
        "indices" : [ 7, 16 ]
      }, {
        "text" : "bcoet",
        "indices" : [ 17, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/848XLykwht",
        "expanded_url" : "http:\/\/known.networkeffects.ca\/2016\/bcpse-highered-bcoet-clusters-of-institutions-could-form-consortia-to",
        "display_url" : "known.networkeffects.ca\/2016\/bcpse-hig\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731158604657594369",
    "text" : "#bcpse #highered #bcoet \"Clusters of institutions could form consortia to set up co-ops to provide a buffet of .. https:\/\/t.co\/848XLykwht",
    "id" : 731158604657594369,
    "created_at" : "2016-05-13 16:26:10 +0000",
    "user" : {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "protected" : false,
      "id_str" : "6271482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639833921228640256\/S63CDenk_normal.jpg",
      "id" : 6271482,
      "verified" : false
    }
  },
  "id" : 731161432197234690,
  "created_at" : "2016-05-13 16:37:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Postlight",
      "screen_name" : "PostlightAgency",
      "indices" : [ 3, 19 ],
      "id_str" : "3526587448",
      "id" : 3526587448
    }, {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "indices" : [ 139, 140 ],
      "id_str" : "35943",
      "id" : 35943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/L5XYdxGGRH",
      "expanded_url" : "http:\/\/bit.ly\/1TeHdMw",
      "display_url" : "bit.ly\/1TeHdMw"
    } ]
  },
  "geo" : { },
  "id_str" : "731128229688283136",
  "text" : "RT @PostlightAgency: \"The web isn\u2019t just a glorified print document. The way we think about content needs to change.\u201D https:\/\/t.co\/L5XYdxGG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Karen McGrane",
        "screen_name" : "karenmcgrane",
        "indices" : [ 121, 134 ],
        "id_str" : "35943",
        "id" : 35943
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/L5XYdxGGRH",
        "expanded_url" : "http:\/\/bit.ly\/1TeHdMw",
        "display_url" : "bit.ly\/1TeHdMw"
      } ]
    },
    "geo" : { },
    "id_str" : "731127494863114240",
    "text" : "\"The web isn\u2019t just a glorified print document. The way we think about content needs to change.\u201D https:\/\/t.co\/L5XYdxGGRH @karenmcgrane",
    "id" : 731127494863114240,
    "created_at" : "2016-05-13 14:22:33 +0000",
    "user" : {
      "name" : "Postlight",
      "screen_name" : "PostlightAgency",
      "protected" : false,
      "id_str" : "3526587448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734758358268424192\/lQi6ojJn_normal.jpg",
      "id" : 3526587448,
      "verified" : false
    }
  },
  "id" : 731128229688283136,
  "created_at" : "2016-05-13 14:25:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 85, 93 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730928606709354496",
  "text" : "I think a Tweetstorm is brewing about why educators might want to consider using the @getgrav CMS instead of WordPress...",
  "id" : 730928606709354496,
  "created_at" : "2016-05-13 01:12:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/fnPz8xRsuC",
      "expanded_url" : "https:\/\/workflowy.com\/s\/aQeB6Kki2j",
      "display_url" : "workflowy.com\/s\/aQeB6Kki2j"
    } ]
  },
  "geo" : { },
  "id_str" : "730878230568144899",
  "text" : "The outline for my #FoL16 workshop 'Moving Beyond the LMS with Grav' is starting to come together - sneak a peek at https:\/\/t.co\/fnPz8xRsuC",
  "id" : 730878230568144899,
  "created_at" : "2016-05-12 21:52:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/730842093577342976\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/gzerx40rFi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiR5AtEVAAAdDJo.jpg",
      "id_str" : "730842092545572864",
      "id" : 730842092545572864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiR5AtEVAAAdDJo.jpg",
      "sizes" : [ {
        "h" : 394,
        "resize" : "fit",
        "w" : 781
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 781
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 303,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gzerx40rFi"
    } ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 11, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730842093577342976",
  "text" : "Hey fellow #UX peeps\/instructors, here's an updated course outline in the form of a series of questions - comments? https:\/\/t.co\/gzerx40rFi",
  "id" : 730842093577342976,
  "created_at" : "2016-05-12 19:28:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Rieger",
      "screen_name" : "bryanrieger",
      "indices" : [ 3, 15 ],
      "id_str" : "755367",
      "id" : 755367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "https:\/\/t.co\/dX86beefeg",
      "expanded_url" : "https:\/\/twitter.com\/Grady_Booch\/status\/730822562515587076",
      "display_url" : "twitter.com\/Grady_Booch\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730825759376334848",
  "text" : "RT @bryanrieger: I've been wondering how much 'UX design' work will be automated in the coming years. My gut says 'a LOT'. https:\/\/t.co\/dX8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/dX86beefeg",
        "expanded_url" : "https:\/\/twitter.com\/Grady_Booch\/status\/730822562515587076",
        "display_url" : "twitter.com\/Grady_Booch\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730823499309146112",
    "text" : "I've been wondering how much 'UX design' work will be automated in the coming years. My gut says 'a LOT'. https:\/\/t.co\/dX86beefeg",
    "id" : 730823499309146112,
    "created_at" : "2016-05-12 18:14:34 +0000",
    "user" : {
      "name" : "Bryan Rieger",
      "screen_name" : "bryanrieger",
      "protected" : false,
      "id_str" : "755367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585799440163823616\/BSJqLHgN_normal.jpg",
      "id" : 755367,
      "verified" : false
    }
  },
  "id" : 730825759376334848,
  "created_at" : "2016-05-12 18:23:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 55, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Gy7HkHzFVM",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1wMOEchgUUkN13t2i5sZFKaw7Mhavn2DslRXZKLqfXPE\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1wM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730807304363216896",
  "text" : "Thanks to feedback via LinkedIn here's an update to my #UX course outline in the form of a series of questions. https:\/\/t.co\/Gy7HkHzFVM",
  "id" : 730807304363216896,
  "created_at" : "2016-05-12 17:10:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Fitzgerald",
      "screen_name" : "andybywire",
      "indices" : [ 3, 14 ],
      "id_str" : "185064968",
      "id" : 185064968
    }, {
      "name" : "Smashing Magazine",
      "screen_name" : "smashingmag",
      "indices" : [ 120, 132 ],
      "id_str" : "15736190",
      "id" : 15736190
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Prototyping",
      "indices" : [ 133, 140 ]
    }, {
      "text" : "IA",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/FRCpv4fFBD",
      "expanded_url" : "http:\/\/bit.ly\/content-1st",
      "display_url" : "bit.ly\/content-1st"
    } ]
  },
  "geo" : { },
  "id_str" : "730786332570591232",
  "text" : "RT @andybywire: New article! How to bring content into your prototyping process from the start: https:\/\/t.co\/FRCpv4fFBD @smashingmag #Proto\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Smashing Magazine",
        "screen_name" : "smashingmag",
        "indices" : [ 104, 116 ],
        "id_str" : "15736190",
        "id" : 15736190
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Prototyping",
        "indices" : [ 117, 129 ]
      }, {
        "text" : "IA",
        "indices" : [ 130, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/FRCpv4fFBD",
        "expanded_url" : "http:\/\/bit.ly\/content-1st",
        "display_url" : "bit.ly\/content-1st"
      } ]
    },
    "geo" : { },
    "id_str" : "730377184552980480",
    "text" : "New article! How to bring content into your prototyping process from the start: https:\/\/t.co\/FRCpv4fFBD @smashingmag #Prototyping #IA",
    "id" : 730377184552980480,
    "created_at" : "2016-05-11 12:41:05 +0000",
    "user" : {
      "name" : "Andy Fitzgerald",
      "screen_name" : "andybywire",
      "protected" : false,
      "id_str" : "185064968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/496070658065846272\/Ts4rlcf8_normal.png",
      "id" : 185064968,
      "verified" : false
    }
  },
  "id" : 730786332570591232,
  "created_at" : "2016-05-12 15:46:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 0, 8 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Jennifer Marsman",
      "screen_name" : "jennifermarsman",
      "indices" : [ 9, 25 ],
      "id_str" : "14347684",
      "id" : 14347684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/62hFFKN3Bc",
      "expanded_url" : "http:\/\/www.zdnet.com\/article\/ubuntu-and-bash-arrive-on-windows-10\/",
      "display_url" : "zdnet.com\/article\/ubuntu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "730539143621529602",
  "geo" : { },
  "id_str" : "730539918577958913",
  "in_reply_to_user_id" : 10185562,
  "text" : "@drchuck @jennifermarsman I am pretty sure it were the instructions on this page that finally got it working for me https:\/\/t.co\/62hFFKN3Bc",
  "id" : 730539918577958913,
  "in_reply_to_status_id" : 730539143621529602,
  "created_at" : "2016-05-11 23:27:44 +0000",
  "in_reply_to_screen_name" : "drchuck",
  "in_reply_to_user_id_str" : "10185562",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 56, 64 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/jT8ZfNRQlK",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=XUJIbxDuPpQ",
      "display_url" : "youtube.com\/watch?v=XUJIbx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730530035690430464",
  "text" : "10-minute screencast overview (my first ever) about the @getgrav Course Hub Project. https:\/\/t.co\/jT8ZfNRQlK #GravEdu",
  "id" : 730530035690430464,
  "created_at" : "2016-05-11 22:48:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 50, 58 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/JA1D7XwNcL",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2016-02-03-why-I-chose-Grav",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730493109885227009",
  "text" : "By a factor of 3x my most popular blog post about @getgrav is 'Why I (as a Web-savvy Instructor) Chose the Grav CMS' https:\/\/t.co\/JA1D7XwNcL",
  "id" : 730493109885227009,
  "created_at" : "2016-05-11 20:21:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/sv6RRle6x6",
      "expanded_url" : "http:\/\/meetup.com",
      "display_url" : "meetup.com"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/n6yJ96DNvO",
      "expanded_url" : "http:\/\/www.meetup.com\/denver-grav-users\/",
      "display_url" : "meetup.com\/denver-grav-us\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730463594920316929",
  "text" : "RT @getgrav: In the Denver area? Want to meetup and talk about Grav? I've started a https:\/\/t.co\/sv6RRle6x6 group: https:\/\/t.co\/n6yJ96DNvO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/sv6RRle6x6",
        "expanded_url" : "http:\/\/meetup.com",
        "display_url" : "meetup.com"
      }, {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/n6yJ96DNvO",
        "expanded_url" : "http:\/\/www.meetup.com\/denver-grav-users\/",
        "display_url" : "meetup.com\/denver-grav-us\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730461040358514688",
    "text" : "In the Denver area? Want to meetup and talk about Grav? I've started a https:\/\/t.co\/sv6RRle6x6 group: https:\/\/t.co\/n6yJ96DNvO - Chat soon!",
    "id" : 730461040358514688,
    "created_at" : "2016-05-11 18:14:17 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 730463594920316929,
  "created_at" : "2016-05-11 18:24:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 0, 11 ],
      "id_str" : "217880712",
      "id" : 217880712
    }, {
      "name" : "Mike Taylor",
      "screen_name" : "tmiket",
      "indices" : [ 12, 19 ],
      "id_str" : "450953",
      "id" : 450953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730449541737156608",
  "geo" : { },
  "id_str" : "730450571694510080",
  "in_reply_to_user_id" : 217880712,
  "text" : "@jimbobtyer @tmiket Time to go undercover... offer to help them prepare by setting up a Yammer group to further discuss \uD83D\uDE1C",
  "id" : 730450571694510080,
  "in_reply_to_status_id" : 730449541737156608,
  "created_at" : "2016-05-11 17:32:42 +0000",
  "in_reply_to_screen_name" : "jimbobtyer",
  "in_reply_to_user_id_str" : "217880712",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 97, 105 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/9PFedwpqcF",
      "expanded_url" : "https:\/\/getgrav.org\/downloads\/skeletons",
      "display_url" : "getgrav.org\/downloads\/skel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730449515447091204",
  "text" : "No better way to mark the 18th year of Hibbitts Design than with a new release of my open source @getgrav Course Hub https:\/\/t.co\/9PFedwpqcF",
  "id" : 730449515447091204,
  "created_at" : "2016-05-11 17:28:30 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 0, 11 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730422649546018816",
  "geo" : { },
  "id_str" : "730449084000043008",
  "in_reply_to_user_id" : 217880712,
  "text" : "@jimbobtyer Well, if that does not speak volumes I don't know what does \u2639\uFE0F",
  "id" : 730449084000043008,
  "in_reply_to_status_id" : 730422649546018816,
  "created_at" : "2016-05-11 17:26:47 +0000",
  "in_reply_to_screen_name" : "jimbobtyer",
  "in_reply_to_user_id_str" : "217880712",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 52, 60 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 89, 97 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/pTMPHl38lW",
      "expanded_url" : "https:\/\/www.eventsforce.net\/concentra\/frontend\/reg\/titem.csp?pageID=4607&&eventID=9",
      "display_url" : "eventsforce.net\/concentra\/fron\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730442453312901120",
  "text" : "I will be 'beaming' into Open Apereo 2016 thanks to @drchuck to share an overview of the @getgrav Course Hub Project https:\/\/t.co\/pTMPHl38lW",
  "id" : 730442453312901120,
  "created_at" : "2016-05-11 17:00:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 0, 8 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 9, 16 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730439939276443649",
  "geo" : { },
  "id_str" : "730440479137890304",
  "in_reply_to_user_id" : 10185562,
  "text" : "@drchuck @btopro LOL. Context is everything as they say!",
  "id" : 730440479137890304,
  "in_reply_to_status_id" : 730439939276443649,
  "created_at" : "2016-05-11 16:52:35 +0000",
  "in_reply_to_screen_name" : "drchuck",
  "in_reply_to_user_id_str" : "10185562",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 8, 16 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/OxsKoYaekY",
      "expanded_url" : "https:\/\/getgrav.org\/media",
      "display_url" : "getgrav.org\/media"
    } ]
  },
  "in_reply_to_status_id_str" : "730426598092996608",
  "geo" : { },
  "id_str" : "730430140933496832",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @drchuck These might help too, thanks! https:\/\/t.co\/OxsKoYaekY",
  "id" : 730430140933496832,
  "in_reply_to_status_id" : 730426598092996608,
  "created_at" : "2016-05-11 16:11:30 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 8, 16 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730426598092996608",
  "geo" : { },
  "id_str" : "730429549201084416",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @drchuck It looks like I am surrounded by the ELMSLN though \uD83D\uDE1C",
  "id" : 730429549201084416,
  "in_reply_to_status_id" : 730426598092996608,
  "created_at" : "2016-05-11 16:09:09 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 8, 16 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730426598092996608",
  "geo" : { },
  "id_str" : "730429337539731459",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @drchuck Kudos, though I'd be fine with just the Grav logo for now somewhere, as I just discovered a lack of a logo for my proj. LOL",
  "id" : 730429337539731459,
  "in_reply_to_status_id" : 730426598092996608,
  "created_at" : "2016-05-11 16:08:19 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730428116343001088",
  "text" : "This month Hibbitts Design marks 18 yrs. as my vehicle to learn, explore &amp; practice design. Thanks to all who have been part of the journey.",
  "id" : 730428116343001088,
  "created_at" : "2016-05-11 16:03:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Trent Tucker",
      "screen_name" : "ProfTucker",
      "indices" : [ 0, 11 ],
      "id_str" : "21151922",
      "id" : 21151922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730210442627457025",
  "geo" : { },
  "id_str" : "730212792628740096",
  "in_reply_to_user_id" : 21151922,
  "text" : "@ProfTucker That's why it's more of a discipline than a role \u263A",
  "id" : 730212792628740096,
  "in_reply_to_status_id" : 730210442627457025,
  "created_at" : "2016-05-11 01:47:51 +0000",
  "in_reply_to_screen_name" : "ProfTucker",
  "in_reply_to_user_id_str" : "21151922",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730209157794516993",
  "text" : "Any definition of 'learner experience design' should account for the full-stack of UX design, educational design and technology development.",
  "id" : 730209157794516993,
  "created_at" : "2016-05-11 01:33:24 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/Owq9lEVe2B",
      "expanded_url" : "http:\/\/www.downes.ca\/post\/65065#.VzKB38EJQqk.twitter",
      "display_url" : "downes.ca\/post\/65065#.Vz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730198427267522563",
  "text" : "OLDaily: Personal and Personalized Learning https:\/\/t.co\/Owq9lEVe2B",
  "id" : 730198427267522563,
  "created_at" : "2016-05-11 00:50:46 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "indices" : [ 3, 9 ],
      "id_str" : "914061",
      "id" : 914061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730162389606273024",
  "text" : "RT @levie: For 30+ years IT strategy was about architectures, and UX was a consequence. Now UX is the strategy, and architectures are the c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "586265289748307969",
    "text" : "For 30+ years IT strategy was about architectures, and UX was a consequence. Now UX is the strategy, and architectures are the consequence.",
    "id" : 586265289748307969,
    "created_at" : "2015-04-09 20:31:52 +0000",
    "user" : {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "protected" : false,
      "id_str" : "914061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1626898956\/twitter_normal.png",
      "id" : 914061,
      "verified" : true
    }
  },
  "id" : 730162389606273024,
  "created_at" : "2016-05-10 22:27:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/QYEZCoTAvO",
      "expanded_url" : "http:\/\/hibbittsdesign.org",
      "display_url" : "hibbittsdesign.org"
    } ]
  },
  "geo" : { },
  "id_str" : "730158684639133696",
  "text" : "Achievement Unlocked: searching for 'Grav CMS in education\" in Google displays my https:\/\/t.co\/QYEZCoTAvO blog as the first search result. \uD83D\uDC4D",
  "id" : 730158684639133696,
  "created_at" : "2016-05-10 22:12:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 3, 10 ],
      "id_str" : "236846178",
      "id" : 236846178
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 68, 76 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Op7ytzQKbf",
      "expanded_url" : "https:\/\/github.com\/elmsln\/elmsln\/issues\/878#issuecomment-218265797",
      "display_url" : "github.com\/elmsln\/elmsln\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730139761118076928",
  "text" : "RT @elmsln: interesting thread emerging as faculty using elmsln and @getgrav  discuss automated git sites to sustain beyond 2020 https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 56, 64 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Op7ytzQKbf",
        "expanded_url" : "https:\/\/github.com\/elmsln\/elmsln\/issues\/878#issuecomment-218265797",
        "display_url" : "github.com\/elmsln\/elmsln\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730118967625449473",
    "text" : "interesting thread emerging as faculty using elmsln and @getgrav  discuss automated git sites to sustain beyond 2020 https:\/\/t.co\/Op7ytzQKbf",
    "id" : 730118967625449473,
    "created_at" : "2016-05-10 19:35:01 +0000",
    "user" : {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "protected" : false,
      "id_str" : "236846178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601925668025278465\/4j0l2bWZ_normal.png",
      "id" : 236846178,
      "verified" : false
    }
  },
  "id" : 730139761118076928,
  "created_at" : "2016-05-10 20:57:39 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Beattie",
      "screen_name" : "ehbeattie",
      "indices" : [ 3, 13 ],
      "id_str" : "1222070773",
      "id" : 1222070773
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/UU0zrMAWXs",
      "expanded_url" : "https:\/\/twitter.com\/BCcampus\/status\/730097664977686528",
      "display_url" : "twitter.com\/BCcampus\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730139082144153600",
  "text" : "RT @ehbeattie: Shout out to the amazing people working tirelessly behind-the-scenes to bring you the Festival of Learning!! #FoL16 https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 109, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/UU0zrMAWXs",
        "expanded_url" : "https:\/\/twitter.com\/BCcampus\/status\/730097664977686528",
        "display_url" : "twitter.com\/BCcampus\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730138897846546432",
    "text" : "Shout out to the amazing people working tirelessly behind-the-scenes to bring you the Festival of Learning!! #FoL16 https:\/\/t.co\/UU0zrMAWXs",
    "id" : 730138897846546432,
    "created_at" : "2016-05-10 20:54:13 +0000",
    "user" : {
      "name" : "Erin Beattie",
      "screen_name" : "ehbeattie",
      "protected" : false,
      "id_str" : "1222070773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763746532763967488\/AaXvvhCl_normal.jpg",
      "id" : 1222070773,
      "verified" : false
    }
  },
  "id" : 730139082144153600,
  "created_at" : "2016-05-10 20:54:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 3, 14 ],
      "id_str" : "2384071",
      "id" : 2384071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730131213902450688",
  "text" : "RT @timoreilly: \"You're either getting better or you're getting worse. If you think you're staying the same, you're getting worse.\" Francis\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730130250596814848",
    "text" : "\"You're either getting better or you're getting worse. If you think you're staying the same, you're getting worse.\" Francis Maude",
    "id" : 730130250596814848,
    "created_at" : "2016-05-10 20:19:51 +0000",
    "user" : {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "protected" : false,
      "id_str" : "2384071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2823681988\/f4f6f2bed8ab4d5a48dea4b9ea85d5f1_normal.jpeg",
      "id" : 2384071,
      "verified" : true
    }
  },
  "id" : 730131213902450688,
  "created_at" : "2016-05-10 20:23:41 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 8, 15 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 18, 32 ],
      "id_str" : "41268670",
      "id" : 41268670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730126147158056960",
  "text" : "I'd say @btopro + @_mike_collins are thinking the right way about productive student portfolios: focus on ownership\/access AFTER graduation.",
  "id" : 730126147158056960,
  "created_at" : "2016-05-10 20:03:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InVision",
      "screen_name" : "InVisionApp",
      "indices" : [ 3, 15 ],
      "id_str" : "256093789",
      "id" : 256093789
    }, {
      "name" : "Jane Portman",
      "screen_name" : "uibreakfast",
      "indices" : [ 91, 103 ],
      "id_str" : "1020639606",
      "id" : 1020639606
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/InVisionApp\/status\/730081040467955712\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/7mt5Ai83ax",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiHE1mnXAAACgSp.jpg",
      "id_str" : "730081039788474368",
      "id" : 730081039788474368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiHE1mnXAAACgSp.jpg",
      "sizes" : [ {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7mt5Ai83ax"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/95OYq7zp0g",
      "expanded_url" : "http:\/\/invs.io\/1qbKzpi",
      "display_url" : "invs.io\/1qbKzpi"
    } ]
  },
  "geo" : { },
  "id_str" : "730091052535709696",
  "text" : "RT @InVisionApp: The Essential Usability Checklist For Web Apps https:\/\/t.co\/95OYq7zp0g by @uibreakfast https:\/\/t.co\/7mt5Ai83ax",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jane Portman",
        "screen_name" : "uibreakfast",
        "indices" : [ 74, 86 ],
        "id_str" : "1020639606",
        "id" : 1020639606
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/InVisionApp\/status\/730081040467955712\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/7mt5Ai83ax",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiHE1mnXAAACgSp.jpg",
        "id_str" : "730081039788474368",
        "id" : 730081039788474368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiHE1mnXAAACgSp.jpg",
        "sizes" : [ {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/7mt5Ai83ax"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/95OYq7zp0g",
        "expanded_url" : "http:\/\/invs.io\/1qbKzpi",
        "display_url" : "invs.io\/1qbKzpi"
      } ]
    },
    "geo" : { },
    "id_str" : "730081040467955712",
    "text" : "The Essential Usability Checklist For Web Apps https:\/\/t.co\/95OYq7zp0g by @uibreakfast https:\/\/t.co\/7mt5Ai83ax",
    "id" : 730081040467955712,
    "created_at" : "2016-05-10 17:04:18 +0000",
    "user" : {
      "name" : "InVision",
      "screen_name" : "InVisionApp",
      "protected" : false,
      "id_str" : "256093789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593893225045200896\/r9uL4jWU_normal.png",
      "id" : 256093789,
      "verified" : false
    }
  },
  "id" : 730091052535709696,
  "created_at" : "2016-05-10 17:44:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 20, 28 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730077898107801601",
  "text" : "The open source CMS @getgrav is open x 2: open source codebase plus content remains open as individual files as compared to locked in a DB.\uD83D\uDE4C",
  "id" : 730077898107801601,
  "created_at" : "2016-05-10 16:51:49 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 11, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Gy7HkHzFVM",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1wMOEchgUUkN13t2i5sZFKaw7Mhavn2DslRXZKLqfXPE\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1wM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730075441826926594",
  "text" : "Hey fellow #UX peeps\/instructors I am working on a course outline in the form of a series of questions - comments? https:\/\/t.co\/Gy7HkHzFVM",
  "id" : 730075441826926594,
  "created_at" : "2016-05-10 16:42:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/9PFedwpqcF",
      "expanded_url" : "https:\/\/getgrav.org\/downloads\/skeletons",
      "display_url" : "getgrav.org\/downloads\/skel\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "730071331329421312",
  "geo" : { },
  "id_str" : "730072066754416641",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Also check out the RTFM skeleton at https:\/\/t.co\/9PFedwpqcF Checkmarking is handled automatically via theme code",
  "id" : 730072066754416641,
  "in_reply_to_status_id" : 730071331329421312,
  "created_at" : "2016-05-10 16:28:39 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/M5zcJwWEpt",
      "expanded_url" : "https:\/\/github.com\/getgrav\/grav-theme-learn2",
      "display_url" : "github.com\/getgrav\/grav-t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "730071331329421312",
  "geo" : { },
  "id_str" : "730071757139234816",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro A slightly modified version of the Learn2 theme https:\/\/t.co\/M5zcJwWEpt",
  "id" : 730071757139234816,
  "in_reply_to_status_id" : 730071331329421312,
  "created_at" : "2016-05-10 16:27:25 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 47, 55 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730069704832749568",
  "text" : "In which educational contexts is the flat-file @getgrav CMS a natural for?\n\u2713Individual instructor course hubs\n\u2713Student e-portfolios\n#GravEdu",
  "id" : 730069704832749568,
  "created_at" : "2016-05-10 16:19:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 3, 10 ],
      "id_str" : "236846178",
      "id" : 236846178
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 43, 58 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 90, 98 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/CNXeQk12sR",
      "expanded_url" : "https:\/\/github.com\/elmsln\/elmsln\/issues\/878",
      "display_url" : "github.com\/elmsln\/elmsln\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730069454860648448",
  "text" : "RT @elmsln: we get off the island \/ invite @hibbittsdesign to offer feedback on automated @getgrav sites for student portfolios https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 31, 46 ],
        "id_str" : "15949844",
        "id" : 15949844
      }, {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 78, 86 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/CNXeQk12sR",
        "expanded_url" : "https:\/\/github.com\/elmsln\/elmsln\/issues\/878",
        "display_url" : "github.com\/elmsln\/elmsln\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730041443335733248",
    "text" : "we get off the island \/ invite @hibbittsdesign to offer feedback on automated @getgrav sites for student portfolios https:\/\/t.co\/CNXeQk12sR",
    "id" : 730041443335733248,
    "created_at" : "2016-05-10 14:26:58 +0000",
    "user" : {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "protected" : false,
      "id_str" : "236846178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601925668025278465\/4j0l2bWZ_normal.png",
      "id" : 236846178,
      "verified" : false
    }
  },
  "id" : 730069454860648448,
  "created_at" : "2016-05-10 16:18:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 3, 11 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/Vk0zUiX9Z9",
      "expanded_url" : "https:\/\/getgrav.org\/downloads",
      "display_url" : "getgrav.org\/downloads"
    } ]
  },
  "geo" : { },
  "id_str" : "729849806567317504",
  "text" : "RT @getgrav: Grav and Admin Plugin both updated to 1.1.0-beta.4 today.  Nothing major, just bug fixes :)\n\nhttps:\/\/t.co\/Vk0zUiX9Z9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/Vk0zUiX9Z9",
        "expanded_url" : "https:\/\/getgrav.org\/downloads",
        "display_url" : "getgrav.org\/downloads"
      } ]
    },
    "geo" : { },
    "id_str" : "729849420527767552",
    "text" : "Grav and Admin Plugin both updated to 1.1.0-beta.4 today.  Nothing major, just bug fixes :)\n\nhttps:\/\/t.co\/Vk0zUiX9Z9",
    "id" : 729849420527767552,
    "created_at" : "2016-05-10 01:43:56 +0000",
    "user" : {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "protected" : false,
      "id_str" : "2737573033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529127267394260992\/W__oOPP5_normal.png",
      "id" : 2737573033,
      "verified" : false
    }
  },
  "id" : 729849806567317504,
  "created_at" : "2016-05-10 01:45:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pedago.me",
      "screen_name" : "pedagome",
      "indices" : [ 3, 12 ],
      "id_str" : "707149866095345664",
      "id" : 707149866095345664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lxdesign",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/T1DiVtr1js",
      "expanded_url" : "https:\/\/twitter.com\/SandstormIO\/status\/729472496941076480",
      "display_url" : "twitter.com\/SandstormIO\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729836937016578049",
  "text" : "RT @pedagome: #lxdesign toolkit\n https:\/\/t.co\/T1DiVtr1js",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lxdesign",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/T1DiVtr1js",
        "expanded_url" : "https:\/\/twitter.com\/SandstormIO\/status\/729472496941076480",
        "display_url" : "twitter.com\/SandstormIO\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "729733705229570048",
    "text" : "#lxdesign toolkit\n https:\/\/t.co\/T1DiVtr1js",
    "id" : 729733705229570048,
    "created_at" : "2016-05-09 18:04:07 +0000",
    "user" : {
      "name" : "pedago.me",
      "screen_name" : "pedagome",
      "protected" : false,
      "id_str" : "707149866095345664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756141627161182208\/8R-s8dnN_normal.jpg",
      "id" : 707149866095345664,
      "verified" : false
    }
  },
  "id" : 729836937016578049,
  "created_at" : "2016-05-10 00:54:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/dL1ybgVZoS",
      "expanded_url" : "https:\/\/twitter.com\/hibbittsdesign\/status\/729819977348321280",
      "display_url" : "twitter.com\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729820739877019648",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro I thought you would dig this tweet \uD83D\uDE09 https:\/\/t.co\/dL1ybgVZoS",
  "id" : 729820739877019648,
  "created_at" : "2016-05-09 23:49:58 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729819977348321280",
  "text" : "The Grav CMS frees your content from the confines of a database while making it possible to share your content openly with GitHub. #GravEdu",
  "id" : 729819977348321280,
  "created_at" : "2016-05-09 23:46:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Baker",
      "screen_name" : "andbkr",
      "indices" : [ 3, 10 ],
      "id_str" : "107056787",
      "id" : 107056787
    }, {
      "name" : "Mike McGrail",
      "screen_name" : "mike_mcgrail",
      "indices" : [ 12, 25 ],
      "id_str" : "16204755",
      "id" : 16204755
    }, {
      "name" : "Sketch",
      "screen_name" : "sketchapp",
      "indices" : [ 51, 61 ],
      "id_str" : "50280181",
      "id" : 50280181
    }, {
      "name" : "InVision",
      "screen_name" : "InVisionApp",
      "indices" : [ 68, 80 ],
      "id_str" : "256093789",
      "id" : 256093789
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 157, 158 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729818127094030336",
  "text" : "RT @andbkr: @mike_mcgrail we use\u2026\n\nStatic WFs &gt; @sketchapp &amp; @InVisionApp\n\nInteractive WFs &amp; Prototypes &gt; built in HTML\/CSS &amp; modularised i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike McGrail",
        "screen_name" : "mike_mcgrail",
        "indices" : [ 0, 13 ],
        "id_str" : "16204755",
        "id" : 16204755
      }, {
        "name" : "Sketch",
        "screen_name" : "sketchapp",
        "indices" : [ 39, 49 ],
        "id_str" : "50280181",
        "id" : 50280181
      }, {
        "name" : "InVision",
        "screen_name" : "InVisionApp",
        "indices" : [ 56, 68 ],
        "id_str" : "256093789",
        "id" : 256093789
      }, {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 147, 155 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "729771347396710400",
    "geo" : { },
    "id_str" : "729777893136543744",
    "in_reply_to_user_id" : 16204755,
    "text" : "@mike_mcgrail we use\u2026\n\nStatic WFs &gt; @sketchapp &amp; @InVisionApp\n\nInteractive WFs &amp; Prototypes &gt; built in HTML\/CSS &amp; modularised in @getgrav",
    "id" : 729777893136543744,
    "in_reply_to_status_id" : 729771347396710400,
    "created_at" : "2016-05-09 20:59:42 +0000",
    "in_reply_to_screen_name" : "mike_mcgrail",
    "in_reply_to_user_id_str" : "16204755",
    "user" : {
      "name" : "Andrew Baker",
      "screen_name" : "andbkr",
      "protected" : false,
      "id_str" : "107056787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751567172112093184\/7nfnGlui_normal.jpg",
      "id" : 107056787,
      "verified" : false
    }
  },
  "id" : 729818127094030336,
  "created_at" : "2016-05-09 23:39:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Buley",
      "screen_name" : "leahbuley",
      "indices" : [ 3, 13 ],
      "id_str" : "8144522",
      "id" : 8144522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/JVdGtbniK5",
      "expanded_url" : "http:\/\/leahbuley.com\/",
      "display_url" : "leahbuley.com"
    } ]
  },
  "geo" : { },
  "id_str" : "729815797363703808",
  "text" : "RT @leahbuley: Leah Buley is now Leah Buley Co. Open for business at https:\/\/t.co\/JVdGtbniK5.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/JVdGtbniK5",
        "expanded_url" : "http:\/\/leahbuley.com\/",
        "display_url" : "leahbuley.com"
      } ]
    },
    "geo" : { },
    "id_str" : "723530691976130561",
    "text" : "Leah Buley is now Leah Buley Co. Open for business at https:\/\/t.co\/JVdGtbniK5.",
    "id" : 723530691976130561,
    "created_at" : "2016-04-22 15:15:34 +0000",
    "user" : {
      "name" : "Leah Buley",
      "screen_name" : "leahbuley",
      "protected" : false,
      "id_str" : "8144522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3477188697\/00c2bc36f8084b0c6329b4ec7bcf1f77_normal.jpeg",
      "id" : 8144522,
      "verified" : false
    }
  },
  "id" : 729815797363703808,
  "created_at" : "2016-05-09 23:30:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SourceLair",
      "screen_name" : "sourcelair",
      "indices" : [ 13, 24 ],
      "id_str" : "244491121",
      "id" : 244491121
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 72, 80 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/lBfwDRLOES",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=MjvzxFCDL8c",
      "display_url" : "youtube.com\/watch?v=MjvzxF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729804526446739456",
  "text" : "How fast can @sourcelair setup and run an online development server for @getgrav from a GitHub repo? &lt;1 minute! https:\/\/t.co\/lBfwDRLOES",
  "id" : 729804526446739456,
  "created_at" : "2016-05-09 22:45:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 3, 12 ],
      "id_str" : "93710949",
      "id" : 93710949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HigherEd",
      "indices" : [ 91, 100 ]
    }, {
      "text" : "FoL16",
      "indices" : [ 147, 148 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 148 ],
      "url" : "https:\/\/t.co\/Y2u7uKe2tx",
      "expanded_url" : "http:\/\/ow.ly\/4no7sI",
      "display_url" : "ow.ly\/4no7sI"
    } ]
  },
  "geo" : { },
  "id_str" : "729792290479202304",
  "text" : "RT @BCcampus: Share the news! Festival of Learning: Celebrating Teaching &amp; Learning in #HigherEd. Share, RT &amp; register https:\/\/t.co\/Y2u7uKe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HigherEd",
        "indices" : [ 77, 86 ]
      }, {
        "text" : "FoL16",
        "indices" : [ 137, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/Y2u7uKe2tx",
        "expanded_url" : "http:\/\/ow.ly\/4no7sI",
        "display_url" : "ow.ly\/4no7sI"
      } ]
    },
    "geo" : { },
    "id_str" : "729778332011663360",
    "text" : "Share the news! Festival of Learning: Celebrating Teaching &amp; Learning in #HigherEd. Share, RT &amp; register https:\/\/t.co\/Y2u7uKe2tx #FoL16",
    "id" : 729778332011663360,
    "created_at" : "2016-05-09 21:01:27 +0000",
    "user" : {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "protected" : false,
      "id_str" : "93710949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744969116579049473\/njo2AazL_normal.jpg",
      "id" : 93710949,
      "verified" : false
    }
  },
  "id" : 729792290479202304,
  "created_at" : "2016-05-09 21:56:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/rNuSAJNjD9",
      "expanded_url" : "http:\/\/Rocket.Chat",
      "display_url" : "Rocket.Chat"
    } ]
  },
  "geo" : { },
  "id_str" : "729776109756121089",
  "text" : "My open source toolkit is taking shape for my next CMPT-363 offering:\n\u2713Grav CMS Course Hub\n\u2713https:\/\/t.co\/rNuSAJNjD9 Livechat\n\u2713Sandstorm.io \uD83D\uDE4C",
  "id" : 729776109756121089,
  "created_at" : "2016-05-09 20:52:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 9, 17 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 28, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/itVjf6ywF4",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1FIA1jXwjGkiEjvHte8CExrGGh8IuiuDoaNcEPeOuRog\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1FI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729729205882097664",
  "text" : "My draft @getgrav guide for #FoL16 Maker Faire w. one-minute install, no database, Markdown, modular content, oh my! https:\/\/t.co\/itVjf6ywF4",
  "id" : 729729205882097664,
  "created_at" : "2016-05-09 17:46:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA Goddard Images",
      "screen_name" : "NASAGoddardPix",
      "indices" : [ 3, 18 ],
      "id_str" : "104201057",
      "id" : 104201057
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NASAGoddardPix\/status\/729711460222373888\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/77Fk6RxP7a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiB0tHvWsAAOHmW.jpg",
      "id_str" : "729711458154622976",
      "id" : 729711458154622976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiB0tHvWsAAOHmW.jpg",
      "sizes" : [ {
        "h" : 805,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1144,
        "resize" : "fit",
        "w" : 1456
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 471,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/77Fk6RxP7a"
    } ],
    "hashtags" : [ {
      "text" : "mondaymotivation",
      "indices" : [ 33, 50 ]
    }, {
      "text" : "mercurytransit",
      "indices" : [ 78, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/Mz3bR5q8rL",
      "expanded_url" : "https:\/\/flic.kr\/p\/GS9g1N",
      "display_url" : "flic.kr\/p\/GS9g1N"
    } ]
  },
  "geo" : { },
  "id_str" : "729712532429017088",
  "text" : "RT @NASAGoddardPix: Needing some #mondaymotivation? This dramatic view of the #mercurytransit may just do it: https:\/\/t.co\/Mz3bR5q8rL https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASAGoddardPix\/status\/729711460222373888\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/77Fk6RxP7a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiB0tHvWsAAOHmW.jpg",
        "id_str" : "729711458154622976",
        "id" : 729711458154622976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiB0tHvWsAAOHmW.jpg",
        "sizes" : [ {
          "h" : 805,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1144,
          "resize" : "fit",
          "w" : 1456
        }, {
          "h" : 267,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 471,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/77Fk6RxP7a"
      } ],
      "hashtags" : [ {
        "text" : "mondaymotivation",
        "indices" : [ 13, 30 ]
      }, {
        "text" : "mercurytransit",
        "indices" : [ 58, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/Mz3bR5q8rL",
        "expanded_url" : "https:\/\/flic.kr\/p\/GS9g1N",
        "display_url" : "flic.kr\/p\/GS9g1N"
      } ]
    },
    "geo" : { },
    "id_str" : "729711460222373888",
    "text" : "Needing some #mondaymotivation? This dramatic view of the #mercurytransit may just do it: https:\/\/t.co\/Mz3bR5q8rL https:\/\/t.co\/77Fk6RxP7a",
    "id" : 729711460222373888,
    "created_at" : "2016-05-09 16:35:44 +0000",
    "user" : {
      "name" : "NASA Goddard Images",
      "screen_name" : "NASAGoddardPix",
      "protected" : false,
      "id_str" : "104201057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579415786994839552\/aE3uhPPr_normal.jpg",
      "id" : 104201057,
      "verified" : true
    }
  },
  "id" : 729712532429017088,
  "created_at" : "2016-05-09 16:39:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "indices" : [ 61, 75 ],
      "id_str" : "3296136369",
      "id" : 3296136369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/DO6RS570U6",
      "expanded_url" : "https:\/\/rocket.chat\/docs\/installation\/rocket-chat-cloud\/",
      "display_url" : "rocket.chat\/docs\/installat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729694073720737793",
  "text" : "Are you an educator interested in trying out the open source @RocketChatApp messaging\/livechat app? Beta details at https:\/\/t.co\/DO6RS570U6",
  "id" : 729694073720737793,
  "created_at" : "2016-05-09 15:26:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "indices" : [ 9, 23 ],
      "id_str" : "3296136369",
      "id" : 3296136369
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 71, 79 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/kcu6xJKDnl",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/demos\/cmpt-363-153\/",
      "display_url" : "hibbittsdesign.org\/demos\/cmpt-363\u2026"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ampaEqt9Co",
      "expanded_url" : "https:\/\/twitter.com\/RocketChatApp\/status\/729499900174606337",
      "display_url" : "twitter.com\/RocketChatApp\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729692979032555521",
  "text" : "Kudos to @RocketChatApp for making Canadian hosting available! Demo w. @getgrav course site https:\/\/t.co\/kcu6xJKDnl https:\/\/t.co\/ampaEqt9Co",
  "id" : 729692979032555521,
  "created_at" : "2016-05-09 15:22:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Pass",
      "screen_name" : "jeffpass",
      "indices" : [ 3, 12 ],
      "id_str" : "17518550",
      "id" : 17518550
    }, {
      "name" : "U.S. Digital Service",
      "screen_name" : "USDS",
      "indices" : [ 14, 19 ],
      "id_str" : "2983206962",
      "id" : 2983206962
    }, {
      "name" : "18F",
      "screen_name" : "18F",
      "indices" : [ 22, 26 ],
      "id_str" : "2366194867",
      "id" : 2366194867
    }, {
      "name" : "DigitalGov",
      "screen_name" : "Digital_Gov",
      "indices" : [ 139, 140 ],
      "id_str" : "137454693",
      "id" : 137454693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729477281240875008",
  "text" : "RT @jeffpass: @USDS \/ @18F Design Standards webinar quote: in designing, developing \u201CMake the best (most important) thing the easiest thing\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Digital Service",
        "screen_name" : "USDS",
        "indices" : [ 0, 5 ],
        "id_str" : "2983206962",
        "id" : 2983206962
      }, {
        "name" : "18F",
        "screen_name" : "18F",
        "indices" : [ 8, 12 ],
        "id_str" : "2366194867",
        "id" : 2366194867
      }, {
        "name" : "DigitalGov",
        "screen_name" : "Digital_Gov",
        "indices" : [ 128, 140 ],
        "id_str" : "137454693",
        "id" : 137454693
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659784926426869761",
    "in_reply_to_user_id" : 2983206962,
    "text" : "@USDS \/ @18F Design Standards webinar quote: in designing, developing \u201CMake the best (most important) thing the easiest thing.\u201D @Digital_Gov",
    "id" : 659784926426869761,
    "created_at" : "2015-10-29 17:32:39 +0000",
    "in_reply_to_screen_name" : "USDS",
    "in_reply_to_user_id_str" : "2983206962",
    "user" : {
      "name" : "Jeff Pass",
      "screen_name" : "jeffpass",
      "protected" : false,
      "id_str" : "17518550",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1894660440\/JRP-SM-Thumb_normal.JPG",
      "id" : 17518550,
      "verified" : false
    }
  },
  "id" : 729477281240875008,
  "created_at" : "2016-05-09 01:05:11 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Maeda",
      "screen_name" : "johnmaeda",
      "indices" : [ 3, 13 ],
      "id_str" : "15414807",
      "id" : 15414807
    }, {
      "name" : "Roger Schank",
      "screen_name" : "rogerschank",
      "indices" : [ 97, 109 ],
      "id_str" : "183026344",
      "id" : 183026344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/HsLG26qoTK",
      "expanded_url" : "https:\/\/www.edge.org\/3rd_culture\/schank\/schank_p1.html",
      "display_url" : "edge.org\/3rd_culture\/sc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729460486995988480",
  "text" : "RT @johnmaeda: \u201CLearning happens when someone wants to learn, not when someone wants to teach.\u201D \u2014@RogerSchank https:\/\/t.co\/HsLG26qoTK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Roger Schank",
        "screen_name" : "rogerschank",
        "indices" : [ 82, 94 ],
        "id_str" : "183026344",
        "id" : 183026344
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/HsLG26qoTK",
        "expanded_url" : "https:\/\/www.edge.org\/3rd_culture\/schank\/schank_p1.html",
        "display_url" : "edge.org\/3rd_culture\/sc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "729459588253241344",
    "text" : "\u201CLearning happens when someone wants to learn, not when someone wants to teach.\u201D \u2014@RogerSchank https:\/\/t.co\/HsLG26qoTK",
    "id" : 729459588253241344,
    "created_at" : "2016-05-08 23:54:53 +0000",
    "user" : {
      "name" : "John Maeda",
      "screen_name" : "johnmaeda",
      "protected" : false,
      "id_str" : "15414807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749782211054952448\/_qeErSoY_normal.jpg",
      "id" : 15414807,
      "verified" : true
    }
  },
  "id" : 729460486995988480,
  "created_at" : "2016-05-08 23:58:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elan Morgan",
      "screen_name" : "schmutzie",
      "indices" : [ 3, 13 ],
      "id_str" : "775861",
      "id" : 775861
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/schmutzie\/status\/729103129803784192\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/IXuTTsqXw6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch5Lbr9UUAAKidY.jpg",
      "id_str" : "729103128709058560",
      "id" : 729103128709058560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch5Lbr9UUAAKidY.jpg",
      "sizes" : [ {
        "h" : 496,
        "resize" : "fit",
        "w" : 1454
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 116,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IXuTTsqXw6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729398375473283072",
  "text" : "RT @schmutzie: I'm often asked about Wix for building websites. I will not use it, because they don't let you export your content: https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/schmutzie\/status\/729103129803784192\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/IXuTTsqXw6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch5Lbr9UUAAKidY.jpg",
        "id_str" : "729103128709058560",
        "id" : 729103128709058560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch5Lbr9UUAAKidY.jpg",
        "sizes" : [ {
          "h" : 496,
          "resize" : "fit",
          "w" : 1454
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 116,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/IXuTTsqXw6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729103129803784192",
    "text" : "I'm often asked about Wix for building websites. I will not use it, because they don't let you export your content: https:\/\/t.co\/IXuTTsqXw6",
    "id" : 729103129803784192,
    "created_at" : "2016-05-08 00:18:26 +0000",
    "user" : {
      "name" : "Elan Morgan",
      "screen_name" : "schmutzie",
      "protected" : false,
      "id_str" : "775861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666165060213997568\/nfJ7oepQ_normal.jpg",
      "id" : 775861,
      "verified" : false
    }
  },
  "id" : 729398375473283072,
  "created_at" : "2016-05-08 19:51:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729352431289679872",
  "geo" : { },
  "id_str" : "729355429457731584",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro I actually had a dream about open source last night, LOL. The conclusion: open source represents amazing learning opportunities. \u2764",
  "id" : 729355429457731584,
  "in_reply_to_status_id" : 729352431289679872,
  "created_at" : "2016-05-08 17:00:59 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Fogel",
      "screen_name" : "kfogel",
      "indices" : [ 3, 10 ],
      "id_str" : "17465603",
      "id" : 17465603
    }, {
      "name" : "Ben Balter",
      "screen_name" : "benbalter",
      "indices" : [ 57, 67 ],
      "id_str" : "16211142",
      "id" : 16211142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opensource",
      "indices" : [ 110, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "https:\/\/t.co\/dOntOykLW8",
      "expanded_url" : "https:\/\/github.com\/WhiteHouse\/source-code-policy\/issues\/90#issuecomment-207820011",
      "display_url" : "github.com\/WhiteHouse\/sou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729121141856477184",
  "text" : "RT @kfogel: Massive, and massively clueful, comment from @benbalter on why publicly-funded software should be #opensource: https:\/\/t.co\/dOn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Balter",
        "screen_name" : "benbalter",
        "indices" : [ 45, 55 ],
        "id_str" : "16211142",
        "id" : 16211142
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opensource",
        "indices" : [ 98, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/dOntOykLW8",
        "expanded_url" : "https:\/\/github.com\/WhiteHouse\/source-code-policy\/issues\/90#issuecomment-207820011",
        "display_url" : "github.com\/WhiteHouse\/sou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719919771190370305",
    "text" : "Massive, and massively clueful, comment from @benbalter on why publicly-funded software should be #opensource: https:\/\/t.co\/dOntOykLW8",
    "id" : 719919771190370305,
    "created_at" : "2016-04-12 16:07:03 +0000",
    "user" : {
      "name" : "Karl Fogel",
      "screen_name" : "kfogel",
      "protected" : false,
      "id_str" : "17465603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1318460362\/kfogel-dolores-park-sf-2007-informal-twitter_normal.jpg",
      "id" : 17465603,
      "verified" : false
    }
  },
  "id" : 729121141856477184,
  "created_at" : "2016-05-08 01:30:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilary Marsh",
      "screen_name" : "hilarymarsh",
      "indices" : [ 3, 15 ],
      "id_str" : "3572901",
      "id" : 3572901
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ias16",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/7FBaSx5Kx1",
      "expanded_url" : "http:\/\/www.slideshare.net\/hilarymarsh\/content-types-the-glue-between-content-strategy-user-experience-design-and-technology",
      "display_url" : "slideshare.net\/hilarymarsh\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729056604545527808",
  "text" : "RT @hilarymarsh: Download the slides from my session on content types: https:\/\/t.co\/7FBaSx5Kx1  #ias16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ias16",
        "indices" : [ 79, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/7FBaSx5Kx1",
        "expanded_url" : "http:\/\/www.slideshare.net\/hilarymarsh\/content-types-the-glue-between-content-strategy-user-experience-design-and-technology",
        "display_url" : "slideshare.net\/hilarymarsh\/co\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "729032037429092352",
    "text" : "Download the slides from my session on content types: https:\/\/t.co\/7FBaSx5Kx1  #ias16",
    "id" : 729032037429092352,
    "created_at" : "2016-05-07 19:35:57 +0000",
    "user" : {
      "name" : "Hilary Marsh",
      "screen_name" : "hilarymarsh",
      "protected" : false,
      "id_str" : "3572901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63183834\/hmarsh_realtor.org_767be3ff_normal.jpg",
      "id" : 3572901,
      "verified" : false
    }
  },
  "id" : 729056604545527808,
  "created_at" : "2016-05-07 21:13:34 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Whalin",
      "screen_name" : "TimothyWhalin",
      "indices" : [ 3, 17 ],
      "id_str" : "153285489",
      "id" : 153285489
    }, {
      "name" : "Stuart Maxwell",
      "screen_name" : "stumax",
      "indices" : [ 32, 39 ],
      "id_str" : "730423",
      "id" : 730423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ias16",
      "indices" : [ 40, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729038341060976640",
  "text" : "RT @TimothyWhalin: Summary from @stumax #ias16\n\n1 Use mixed-methoded research\n2 Involve everyone in everything\n3 Foster empathy by focusing\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stuart Maxwell",
        "screen_name" : "stumax",
        "indices" : [ 13, 20 ],
        "id_str" : "730423",
        "id" : 730423
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ias16",
        "indices" : [ 21, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729037644458541057",
    "text" : "Summary from @stumax #ias16\n\n1 Use mixed-methoded research\n2 Involve everyone in everything\n3 Foster empathy by focusing on people, not %s",
    "id" : 729037644458541057,
    "created_at" : "2016-05-07 19:58:13 +0000",
    "user" : {
      "name" : "Timothy Whalin",
      "screen_name" : "TimothyWhalin",
      "protected" : false,
      "id_str" : "153285489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477881479498694656\/trx5NmKI_normal.jpeg",
      "id" : 153285489,
      "verified" : false
    }
  },
  "id" : 729038341060976640,
  "created_at" : "2016-05-07 20:01:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coding ALL Wrongs",
      "screen_name" : "CodingItWrong",
      "indices" : [ 14, 28 ],
      "id_str" : "1964883696",
      "id" : 1964883696
    }, {
      "name" : "PHP Community",
      "screen_name" : "phpc",
      "indices" : [ 29, 34 ],
      "id_str" : "17997273",
      "id" : 17997273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729001860615409664",
  "text" : "RT @PHPDevOp: @CodingItWrong @phpc I would simply check out GetGrav, it's amazing, light weight, and easy. Build a website in less then a d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Coding ALL Wrongs",
        "screen_name" : "CodingItWrong",
        "indices" : [ 0, 14 ],
        "id_str" : "1964883696",
        "id" : 1964883696
      }, {
        "name" : "PHP Community",
        "screen_name" : "phpc",
        "indices" : [ 15, 20 ],
        "id_str" : "17997273",
        "id" : 17997273
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "728949221349412864",
    "geo" : { },
    "id_str" : "728990667926581249",
    "in_reply_to_user_id" : 1964883696,
    "text" : "@CodingItWrong @phpc I would simply check out GetGrav, it's amazing, light weight, and easy. Build a website in less then a day. Perfect CMS",
    "id" : 728990667926581249,
    "in_reply_to_status_id" : 728949221349412864,
    "created_at" : "2016-05-07 16:51:33 +0000",
    "in_reply_to_screen_name" : "CodingItWrong",
    "in_reply_to_user_id_str" : "1964883696",
    "user" : {
      "name" : "YoungWebRebelz",
      "screen_name" : "YoungWebRebelz",
      "protected" : false,
      "id_str" : "4867252667",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694947936539668480\/t86pjpFE_normal.jpg",
      "id" : 4867252667,
      "verified" : false
    }
  },
  "id" : 729001860615409664,
  "created_at" : "2016-05-07 17:36:02 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Programming Wisdom",
      "screen_name" : "CodeWisdom",
      "indices" : [ 3, 14 ],
      "id_str" : "396238794",
      "id" : 396238794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728991497916289024",
  "text" : "RT @CodeWisdom: \"The most important single aspect of software development is to be clear about what you are trying to build.\" - Bjarne Stro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728672498364076032",
    "text" : "\"The most important single aspect of software development is to be clear about what you are trying to build.\" - Bjarne Stroustrup",
    "id" : 728672498364076032,
    "created_at" : "2016-05-06 19:47:16 +0000",
    "user" : {
      "name" : "Programming Wisdom",
      "screen_name" : "CodeWisdom",
      "protected" : false,
      "id_str" : "396238794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705003311083229184\/qTBCIxpk_normal.jpg",
      "id" : 396238794,
      "verified" : false
    }
  },
  "id" : 728991497916289024,
  "created_at" : "2016-05-07 16:54:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728238801018073088",
  "geo" : { },
  "id_str" : "728733808577499138",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Would be very interested in hearing your 'top 3' reasons for that verdict \uD83D\uDE42",
  "id" : 728733808577499138,
  "in_reply_to_status_id" : 728238801018073088,
  "created_at" : "2016-05-06 23:50:53 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 3, 10 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 40, 48 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "ELMS:LN",
      "screen_name" : "elmsln",
      "indices" : [ 125, 132 ],
      "id_str" : "236846178",
      "id" : 236846178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728730558872715265",
  "text" : "RT @btopro: 30 seconds after installing @getgrav impression: this is a wordpress killer and we need a site factory for it in @elmsln for po\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grav",
        "screen_name" : "getgrav",
        "indices" : [ 28, 36 ],
        "id_str" : "2737573033",
        "id" : 2737573033
      }, {
        "name" : "ELMS:LN",
        "screen_name" : "elmsln",
        "indices" : [ 113, 120 ],
        "id_str" : "236846178",
        "id" : 236846178
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728238801018073088",
    "text" : "30 seconds after installing @getgrav impression: this is a wordpress killer and we need a site factory for it in @elmsln for portfolios",
    "id" : 728238801018073088,
    "created_at" : "2016-05-05 15:03:54 +0000",
    "user" : {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "protected" : false,
      "id_str" : "16847370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666258162950004736\/fYeJgTOQ_normal.jpg",
      "id" : 16847370,
      "verified" : false
    }
  },
  "id" : 728730558872715265,
  "created_at" : "2016-05-06 23:37:59 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/0j6Nuh5WAN",
      "expanded_url" : "https:\/\/youtu.be\/XUJIbxDuPpQ",
      "display_url" : "youtu.be\/XUJIbxDuPpQ"
    } ]
  },
  "geo" : { },
  "id_str" : "728669363910238208",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Here's the first-pass of my Grav Course Hub recording incl. Admin Panel, running time 9 mins. 34 seconds \uD83D\uDE42  https:\/\/t.co\/0j6Nuh5WAN",
  "id" : 728669363910238208,
  "created_at" : "2016-05-06 19:34:49 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 0, 8 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/0j6Nuh5WAN",
      "expanded_url" : "https:\/\/youtu.be\/XUJIbxDuPpQ",
      "display_url" : "youtu.be\/XUJIbxDuPpQ"
    } ]
  },
  "geo" : { },
  "id_str" : "728666624115376128",
  "in_reply_to_user_id" : 10185562,
  "text" : "@drchuck Here's the first-pass of my Grav Course Hub Project recording for you, coming in at 9 minutes 34 seconds \uD83D\uDE42  https:\/\/t.co\/0j6Nuh5WAN",
  "id" : 728666624115376128,
  "created_at" : "2016-05-06 19:23:55 +0000",
  "in_reply_to_screen_name" : "drchuck",
  "in_reply_to_user_id_str" : "10185562",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 100, 108 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 32, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728656485325021184",
  "text" : "Looks like I may be part of the #FoL16 Maker Faire, where in just a few minutes you can try out the @getgrav Course Hub on your own laptop.",
  "id" : 728656485325021184,
  "created_at" : "2016-05-06 18:43:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/rNuSAJNjD9",
      "expanded_url" : "http:\/\/Rocket.Chat",
      "display_url" : "Rocket.Chat"
    } ]
  },
  "in_reply_to_status_id_str" : "728651034587992065",
  "geo" : { },
  "id_str" : "728652299627683840",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro If https:\/\/t.co\/rNuSAJNjD9 Livechat JS embed into my base Twig file or in Markdown file e.g. site sidebar, otherwise link.",
  "id" : 728652299627683840,
  "in_reply_to_status_id" : 728651034587992065,
  "created_at" : "2016-05-06 18:27:00 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/rNuSAJNjD9",
      "expanded_url" : "http:\/\/Rocket.Chat",
      "display_url" : "Rocket.Chat"
    } ]
  },
  "in_reply_to_status_id_str" : "728638330590629889",
  "geo" : { },
  "id_str" : "728639619168768002",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Also possible to run https:\/\/t.co\/rNuSAJNjD9 in Sandstorm but due to security issues cannot use Livechat right now in that config",
  "id" : 728639619168768002,
  "in_reply_to_status_id" : 728638330590629889,
  "created_at" : "2016-05-06 17:36:37 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728638330590629889",
  "geo" : { },
  "id_str" : "728639046155575296",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro No, I've been working with RC team to get a Canadian server locale and they have done that. You can move data hosted-&gt;own server too",
  "id" : 728639046155575296,
  "in_reply_to_status_id" : 728638330590629889,
  "created_at" : "2016-05-06 17:34:20 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "indices" : [ 28, 42 ],
      "id_str" : "3296136369",
      "id" : 3296136369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/kcu6xJKDnl",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/demos\/cmpt-363-153\/",
      "display_url" : "hibbittsdesign.org\/demos\/cmpt-363\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728634860038840325",
  "text" : "FIPPA heaven? Thanks to the @RocketChatApp team I've got Livechat going on a Course Hub with data stored in Canada \uD83D\uDC4D https:\/\/t.co\/kcu6xJKDnl",
  "id" : 728634860038840325,
  "created_at" : "2016-05-06 17:17:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "indices" : [ 8, 22 ],
      "id_str" : "3296136369",
      "id" : 3296136369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/rNuSAJNjD9",
      "expanded_url" : "http:\/\/Rocket.Chat",
      "display_url" : "Rocket.Chat"
    } ]
  },
  "in_reply_to_status_id_str" : "728627700202655744",
  "geo" : { },
  "id_str" : "728628428342104064",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @RocketChatApp Plus https:\/\/t.co\/rNuSAJNjD9 can be even hosted on your own server \uD83D\uDE42",
  "id" : 728628428342104064,
  "in_reply_to_status_id" : 728627700202655744,
  "created_at" : "2016-05-06 16:52:09 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "indices" : [ 8, 22 ],
      "id_str" : "3296136369",
      "id" : 3296136369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728627700202655744",
  "geo" : { },
  "id_str" : "728628294145351680",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @RocketChatApp To closed (requires GitHub account) but now they also support Twitter accounts. Also, no account needed for livechat.",
  "id" : 728628294145351680,
  "in_reply_to_status_id" : 728627700202655744,
  "created_at" : "2016-05-06 16:51:37 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "indices" : [ 22, 36 ],
      "id_str" : "3296136369",
      "id" : 3296136369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728626657318318081",
  "geo" : { },
  "id_str" : "728627427316879360",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Have you seen @RocketChatApp as well? It also supports embeded Livechat within a course website which my students LOVED.",
  "id" : 728627427316879360,
  "in_reply_to_status_id" : 728626657318318081,
  "created_at" : "2016-05-06 16:48:10 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Buxton",
      "screen_name" : "wasbuxton",
      "indices" : [ 3, 13 ],
      "id_str" : "57046779",
      "id" : 57046779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/cCQwKZbRXN",
      "expanded_url" : "https:\/\/channel9.msdn.com\/Events\/Build\/2016\/B865",
      "display_url" : "channel9.msdn.com\/Events\/Build\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728613357666721792",
  "text" : "RT @wasbuxton: I love the Windows 10 team for supporting simultaneous pen+touch, unleashing the potential of bimanual interaction: https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/cCQwKZbRXN",
        "expanded_url" : "https:\/\/channel9.msdn.com\/Events\/Build\/2016\/B865",
        "display_url" : "channel9.msdn.com\/Events\/Build\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728605672078749696",
    "text" : "I love the Windows 10 team for supporting simultaneous pen+touch, unleashing the potential of bimanual interaction: https:\/\/t.co\/cCQwKZbRXN",
    "id" : 728605672078749696,
    "created_at" : "2016-05-06 15:21:43 +0000",
    "user" : {
      "name" : "Bill Buxton",
      "screen_name" : "wasbuxton",
      "protected" : false,
      "id_str" : "57046779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1295268556\/Bill_TN_normal.jpg",
      "id" : 57046779,
      "verified" : false
    }
  },
  "id" : 728613357666721792,
  "created_at" : "2016-05-06 15:52:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 30, 38 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    }, {
      "name" : "Olivier Raggi",
      "screen_name" : "orx57",
      "indices" : [ 103, 109 ],
      "id_str" : "306351869",
      "id" : 306351869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/EIm1OYelYi",
      "expanded_url" : "https:\/\/github.com\/orx57\/grav-plugin-feed-us",
      "display_url" : "github.com\/orx57\/grav-plu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728612432080314368",
  "text" : "Super excited to see this new @getgrav RSS feed plugin be released: https:\/\/t.co\/EIm1OYelYi. Thank you @orx57.",
  "id" : 728612432080314368,
  "created_at" : "2016-05-06 15:48:35 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriela K Hajduk",
      "screen_name" : "AmidstScience",
      "indices" : [ 0, 14 ],
      "id_str" : "78420357",
      "id" : 78420357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/5YbJIEv9gr",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/grav-cms-for-educators",
      "display_url" : "slides.com\/paulhibbitts\/g\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "728496209837559808",
  "geo" : { },
  "id_str" : "728601589074694144",
  "in_reply_to_user_id" : 78420357,
  "text" : "@AmidstScience You might also find these slides helpful https:\/\/t.co\/5YbJIEv9gr",
  "id" : 728601589074694144,
  "in_reply_to_status_id" : 728496209837559808,
  "created_at" : "2016-05-06 15:05:30 +0000",
  "in_reply_to_screen_name" : "AmidstScience",
  "in_reply_to_user_id_str" : "78420357",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/7CZyoRmFrT",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/open-apereo-2016-grav-course-hub-project#\/16",
      "display_url" : "slides.com\/paulhibbitts\/o\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "728376940521005056",
  "geo" : { },
  "id_str" : "728589186115100673",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Thanks again for your very helpful feedback, the Admin Panel will now make a brief appearance... https:\/\/t.co\/7CZyoRmFrT",
  "id" : 728589186115100673,
  "in_reply_to_status_id" : 728376940521005056,
  "created_at" : "2016-05-06 14:16:13 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriela K Hajduk",
      "screen_name" : "AmidstScience",
      "indices" : [ 0, 14 ],
      "id_str" : "78420357",
      "id" : 78420357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728496209837559808",
  "geo" : { },
  "id_str" : "728588389977489409",
  "in_reply_to_user_id" : 78420357,
  "text" : "@AmidstScience Please let me know what you think once you review the post I sent you. More questions are welcome as well \uD83D\uDE42",
  "id" : 728588389977489409,
  "in_reply_to_status_id" : 728496209837559808,
  "created_at" : "2016-05-06 14:13:03 +0000",
  "in_reply_to_screen_name" : "AmidstScience",
  "in_reply_to_user_id_str" : "78420357",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriela K Hajduk",
      "screen_name" : "AmidstScience",
      "indices" : [ 0, 14 ],
      "id_str" : "78420357",
      "id" : 78420357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728496209837559808",
  "geo" : { },
  "id_str" : "728588086469271554",
  "in_reply_to_user_id" : 78420357,
  "text" : "@AmidstScience Using Grav on a server very easy, but using it with GitHub plus staging\/production server requires more effort to setup.",
  "id" : 728588086469271554,
  "in_reply_to_status_id" : 728496209837559808,
  "created_at" : "2016-05-06 14:11:50 +0000",
  "in_reply_to_screen_name" : "AmidstScience",
  "in_reply_to_user_id_str" : "78420357",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriela K Hajduk",
      "screen_name" : "AmidstScience",
      "indices" : [ 0, 14 ],
      "id_str" : "78420357",
      "id" : 78420357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728491712629383168",
  "geo" : { },
  "id_str" : "728587182210883584",
  "in_reply_to_user_id" : 78420357,
  "text" : "@AmidstScience As you will see setup takes a bit of effort but once set up site updates can be done with one single click in GitHub Desktop",
  "id" : 728587182210883584,
  "in_reply_to_status_id" : 728491712629383168,
  "created_at" : "2016-05-06 14:08:15 +0000",
  "in_reply_to_screen_name" : "AmidstScience",
  "in_reply_to_user_id_str" : "78420357",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriela K Hajduk",
      "screen_name" : "AmidstScience",
      "indices" : [ 0, 14 ],
      "id_str" : "78420357",
      "id" : 78420357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/cegel1X0w4",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-11-using-grav-with-github",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "728491712629383168",
  "geo" : { },
  "id_str" : "728587016376483840",
  "in_reply_to_user_id" : 78420357,
  "text" : "@AmidstScience I have a how-to guide about how to host a Grav site on GitHub along with staging\/production server https:\/\/t.co\/cegel1X0w4",
  "id" : 728587016376483840,
  "in_reply_to_status_id" : 728491712629383168,
  "created_at" : "2016-05-06 14:07:35 +0000",
  "in_reply_to_screen_name" : "AmidstScience",
  "in_reply_to_user_id_str" : "78420357",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 124, 132 ],
      "id_str" : "10185562",
      "id" : 10185562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728376940521005056",
  "geo" : { },
  "id_str" : "728398676595343360",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro I cut it out trying to keep my slides under 10 mins. Perhaps I will try to add it back and buy an extra minute from @drchuck \uD83D\uDE09",
  "id" : 728398676595343360,
  "in_reply_to_status_id" : 728376940521005056,
  "created_at" : "2016-05-06 01:39:12 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rhuk",
      "screen_name" : "rhuk",
      "indices" : [ 3, 8 ],
      "id_str" : "14436881",
      "id" : 14436881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/E32HLz6yIf",
      "expanded_url" : "http:\/\/disq.us\/9mxupk",
      "display_url" : "disq.us\/9mxupk"
    } ]
  },
  "geo" : { },
  "id_str" : "728371714292207616",
  "text" : "RT @rhuk: Gantry Inheritance Progress https:\/\/t.co\/E32HLz6yIf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/E32HLz6yIf",
        "expanded_url" : "http:\/\/disq.us\/9mxupk",
        "display_url" : "disq.us\/9mxupk"
      } ]
    },
    "geo" : { },
    "id_str" : "728371628480987137",
    "text" : "Gantry Inheritance Progress https:\/\/t.co\/E32HLz6yIf",
    "id" : 728371628480987137,
    "created_at" : "2016-05-05 23:51:43 +0000",
    "user" : {
      "name" : "rhuk",
      "screen_name" : "rhuk",
      "protected" : false,
      "id_str" : "14436881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459132737320792064\/vPalYA0W_normal.jpeg",
      "id" : 14436881,
      "verified" : false
    }
  },
  "id" : 728371714292207616,
  "created_at" : "2016-05-05 23:52:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/BdSSzUxf0F",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/open-apereo-2016-grav-course-hub-project#\/",
      "display_url" : "slides.com\/paulhibbitts\/o\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "728038018389520388",
  "geo" : { },
  "id_str" : "728370983589969920",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Thanks again for the feedback. I've expanded the GitHub\/GitLab content a bit https:\/\/t.co\/BdSSzUxf0F and I am still within 10 mins \uD83D\uDE42",
  "id" : 728370983589969920,
  "in_reply_to_status_id" : 728038018389520388,
  "created_at" : "2016-05-05 23:49:09 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/HXxK1h6LEv",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=BK8guP9ov2U",
      "display_url" : "youtube.com\/watch?v=BK8guP\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "728250709699764224",
  "geo" : { },
  "id_str" : "728251913909600256",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Ok, just tested and YouTube plugin seems to work for me: [plugin:youtube](https:\/\/t.co\/HXxK1h6LEv)",
  "id" : 728251913909600256,
  "in_reply_to_status_id" : 728250709699764224,
  "created_at" : "2016-05-05 15:56:01 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728249013259128832",
  "geo" : { },
  "id_str" : "728249592605614081",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Try mediaembed plug in?",
  "id" : 728249592605614081,
  "in_reply_to_status_id" : 728249013259128832,
  "created_at" : "2016-05-05 15:46:47 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728247146592403456",
  "geo" : { },
  "id_str" : "728247529549103104",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Fastest way to get going for sure",
  "id" : 728247529549103104,
  "in_reply_to_status_id" : 728247146592403456,
  "created_at" : "2016-05-05 15:38:35 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    }, {
      "name" : "Michael Collins",
      "screen_name" : "_mike_collins",
      "indices" : [ 8, 22 ],
      "id_str" : "41268670",
      "id" : 41268670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728246854580723713",
  "geo" : { },
  "id_str" : "728247286610857986",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro @_mike_collins Awesome! Portability and version control make Grav an excellent publishing platform for students.",
  "id" : 728247286610857986,
  "in_reply_to_status_id" : 728246854580723713,
  "created_at" : "2016-05-05 15:37:37 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/xky1rbWLdt",
      "expanded_url" : "http:\/\/hibbittsdesign.org\/blog\/posts\/2015-12-07-using-grav-as-a-simple-open-publishing-tool",
      "display_url" : "hibbittsdesign.org\/blog\/posts\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "728243835986305024",
  "geo" : { },
  "id_str" : "728246966266699776",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro This post might be helpful for others to 'git' it \uD83D\uDE09 https:\/\/t.co\/xky1rbWLdt",
  "id" : 728246966266699776,
  "in_reply_to_status_id" : 728243835986305024,
  "created_at" : "2016-05-05 15:36:21 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728243835986305024",
  "geo" : { },
  "id_str" : "728244003783643137",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro LOVE IT",
  "id" : 728244003783643137,
  "in_reply_to_status_id" : 728243835986305024,
  "created_at" : "2016-05-05 15:24:35 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728243715056095233",
  "geo" : { },
  "id_str" : "728243912616218625",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro Oh, sounds very interesting!",
  "id" : 728243912616218625,
  "in_reply_to_status_id" : 728243715056095233,
  "created_at" : "2016-05-05 15:24:13 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 0, 7 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728235654467993600",
  "geo" : { },
  "id_str" : "728242254188449794",
  "in_reply_to_user_id" : 16847370,
  "text" : "@btopro What are you contemplating to do? The server-only install is pretty quick \uD83D\uDE42",
  "id" : 728242254188449794,
  "in_reply_to_status_id" : 728235654467993600,
  "created_at" : "2016-05-05 15:17:38 +0000",
  "in_reply_to_screen_name" : "btopro",
  "in_reply_to_user_id_str" : "16847370",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "indices" : [ 3, 16 ],
      "id_str" : "91939908",
      "id" : 91939908
    }, {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 83, 88 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "BCcampus",
      "screen_name" : "BCcampus",
      "indices" : [ 97, 106 ],
      "id_str" : "93710949",
      "id" : 93710949
    }, {
      "name" : "Brenna Clarke Gray",
      "screen_name" : "brennacgray",
      "indices" : [ 118, 130 ],
      "id_str" : "14109848",
      "id" : 14109848
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/davidnwright\/status\/728086612274335744\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/8wiqcPcoSM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chqu6LDU4AA0wHn.jpg",
      "id_str" : "728086604196143104",
      "id" : 728086604196143104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chqu6LDU4AA0wHn.jpg",
      "sizes" : [ {
        "h" : 531,
        "resize" : "fit",
        "w" : 455
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 455
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 455
      } ],
      "display_url" : "pic.twitter.com\/8wiqcPcoSM"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/davidnwright\/status\/728086612274335744\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/8wiqcPcoSM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chqu6c6U4AA0yih.jpg",
      "id_str" : "728086608990232576",
      "id" : 728086608990232576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chqu6c6U4AA0yih.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 535
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 535
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 535
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8wiqcPcoSM"
    } ],
    "hashtags" : [ {
      "text" : "FoL16",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728091805460275200",
  "text" : "RT @davidnwright: A few more views of a computer reading a book. This\u2019ll be in the @etug session @BCcampus  #FoL16 w\/ @brennacgray https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "etug",
        "screen_name" : "etug",
        "indices" : [ 65, 70 ],
        "id_str" : "17102936",
        "id" : 17102936
      }, {
        "name" : "BCcampus",
        "screen_name" : "BCcampus",
        "indices" : [ 79, 88 ],
        "id_str" : "93710949",
        "id" : 93710949
      }, {
        "name" : "Brenna Clarke Gray",
        "screen_name" : "brennacgray",
        "indices" : [ 100, 112 ],
        "id_str" : "14109848",
        "id" : 14109848
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/davidnwright\/status\/728086612274335744\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/8wiqcPcoSM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Chqu6LDU4AA0wHn.jpg",
        "id_str" : "728086604196143104",
        "id" : 728086604196143104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chqu6LDU4AA0wHn.jpg",
        "sizes" : [ {
          "h" : 531,
          "resize" : "fit",
          "w" : 455
        }, {
          "h" : 531,
          "resize" : "fit",
          "w" : 455
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 531,
          "resize" : "fit",
          "w" : 455
        } ],
        "display_url" : "pic.twitter.com\/8wiqcPcoSM"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/davidnwright\/status\/728086612274335744\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/8wiqcPcoSM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Chqu6c6U4AA0yih.jpg",
        "id_str" : "728086608990232576",
        "id" : 728086608990232576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chqu6c6U4AA0yih.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 535
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 535
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 535
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8wiqcPcoSM"
      } ],
      "hashtags" : [ {
        "text" : "FoL16",
        "indices" : [ 90, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728086612274335744",
    "text" : "A few more views of a computer reading a book. This\u2019ll be in the @etug session @BCcampus  #FoL16 w\/ @brennacgray https:\/\/t.co\/8wiqcPcoSM",
    "id" : 728086612274335744,
    "created_at" : "2016-05-05 04:59:10 +0000",
    "user" : {
      "name" : "David N. Wright",
      "screen_name" : "davidnwright",
      "protected" : false,
      "id_str" : "91939908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000388128638\/0a05619f6295cf44230a317aea475ef1_normal.jpeg",
      "id" : 91939908,
      "verified" : false
    }
  },
  "id" : 728091805460275200,
  "created_at" : "2016-05-05 05:19:48 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drchuck",
      "screen_name" : "drchuck",
      "indices" : [ 100, 108 ],
      "id_str" : "10185562",
      "id" : 10185562
    }, {
      "name" : "Bryan Ollendyke",
      "screen_name" : "btopro",
      "indices" : [ 109, 116 ],
      "id_str" : "16847370",
      "id" : 16847370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apereo16",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/BdSSzUxf0F",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/open-apereo-2016-grav-course-hub-project#\/",
      "display_url" : "slides.com\/paulhibbitts\/o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727986749440282624",
  "text" : "Draft slides for 'Emerging Next Generation Digital Learning Environments' #apereo16 talk along with @drchuck @btopro https:\/\/t.co\/BdSSzUxf0F",
  "id" : 727986749440282624,
  "created_at" : "2016-05-04 22:22:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RocketChat",
      "screen_name" : "RocketChatApp",
      "indices" : [ 18, 32 ],
      "id_str" : "3296136369",
      "id" : 3296136369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727985789255094272",
  "text" : "The great team at @RocketChatApp are cooking up an awesome feature for my fellow Canadian educators - I will be sharing more news soon! \uD83D\uDCE3",
  "id" : 727985789255094272,
  "created_at" : "2016-05-04 22:18:32 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 3, 15 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "highered",
      "indices" : [ 17, 26 ]
    }, {
      "text" : "bcpse",
      "indices" : [ 27, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/w0Tv2ihsfR",
      "expanded_url" : "http:\/\/known.networkeffects.ca\/2016\/highered-bcpse-you-have-the-power-to-take-back-control",
      "display_url" : "known.networkeffects.ca\/2016\/highered-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727923663937273856",
  "text" : "RT @grantpotter: #highered #bcpse \"You have the power to take back control of your data, but we need a community to take back the .. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/known.networkeffects.ca\" rel=\"nofollow\"\u003Eknown-twitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "highered",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "bcpse",
        "indices" : [ 10, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/w0Tv2ihsfR",
        "expanded_url" : "http:\/\/known.networkeffects.ca\/2016\/highered-bcpse-you-have-the-power-to-take-back-control",
        "display_url" : "known.networkeffects.ca\/2016\/highered-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "727910107716161539",
    "text" : "#highered #bcpse \"You have the power to take back control of your data, but we need a community to take back the .. https:\/\/t.co\/w0Tv2ihsfR",
    "id" : 727910107716161539,
    "created_at" : "2016-05-04 17:17:48 +0000",
    "user" : {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "protected" : false,
      "id_str" : "6271482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639833921228640256\/S63CDenk_normal.jpg",
      "id" : 6271482,
      "verified" : false
    }
  },
  "id" : 727923663937273856,
  "created_at" : "2016-05-04 18:11:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727632316462305280",
  "text" : "(8\/8) Existing LMSs\/CMSs often prevent content from being globally searched and replaced by authors. Content as FILES removes this issue.",
  "id" : 727632316462305280,
  "created_at" : "2016-05-03 22:53:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727632263001690113",
  "text" : "(7\/8) Existing LMSs\/CMSs often require IT involvement for content or server migration, while a flat-file CMS only needs simple FILE COPYING.",
  "id" : 727632263001690113,
  "created_at" : "2016-05-03 22:53:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727632229367611392",
  "text" : "(6\/8) Existing LMSs\/CMSs can often only be edited by pre-defined interfaces. A flat-file CMS gives authors and contributors tool CHOICE.",
  "id" : 727632229367611392,
  "created_at" : "2016-05-03 22:53:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727632189790167041",
  "text" : "(5\/8) Existing LMSs\/CMSs are often database-driven which can impact PERFORMANCE with even the simplest content presentation tasks.",
  "id" : 727632189790167041,
  "created_at" : "2016-05-03 22:53:27 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727632148941824000",
  "text" : "(4\/8) Existing LMSs\/CMSs are often blob-based, where each page is a single blog of content rather than modular\/reusable CONTENT CHUNKS.",
  "id" : 727632148941824000,
  "created_at" : "2016-05-03 22:53:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727632113218953216",
  "text" : "(3\/8) Existing LMSs\/CMSs most only support limited collaborative editing. Content and logic are BOTH editable collaboratively (i.e. GitHub).",
  "id" : 727632113218953216,
  "created_at" : "2016-05-03 22:53:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727632076531335168",
  "text" : "(2\/8) Existing LMSs\/CMSs controlled by IT are often locked down. A site built with a flat-file CMS enables easier HTML\/CSS CUSTOMIZATIONS.",
  "id" : 727632076531335168,
  "created_at" : "2016-05-03 22:53:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 38, 46 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727632035741732864",
  "text" : "(1\/8) Here are the top 7 problems the @getgrav flat-file (no database) CMS has solved for me as an educator trying to move beyond the LMS:",
  "id" : 727632035741732864,
  "created_at" : "2016-05-03 22:52:50 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 0, 11 ],
      "id_str" : "185375498",
      "id" : 185375498
    }, {
      "name" : "Grant Potter",
      "screen_name" : "grantpotter",
      "indices" : [ 12, 24 ],
      "id_str" : "6271482",
      "id" : 6271482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/bzKRP4p30w",
      "expanded_url" : "http:\/\/paulhibbitts.net",
      "display_url" : "paulhibbitts.net"
    } ]
  },
  "in_reply_to_status_id_str" : "727579463219875841",
  "geo" : { },
  "id_str" : "727609648245678080",
  "in_reply_to_user_id" : 185375498,
  "text" : "@timmmmyboy @grantpotter Super nice Tim, I've already replaced my default homepage for https:\/\/t.co\/bzKRP4p30w \uD83D\uDC4D",
  "id" : 727609648245678080,
  "in_reply_to_status_id" : 727579463219875841,
  "created_at" : "2016-05-03 21:23:53 +0000",
  "in_reply_to_screen_name" : "timmmmyboy",
  "in_reply_to_user_id_str" : "185375498",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "indices" : [ 3, 14 ],
      "id_str" : "185375498",
      "id" : 185375498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/ktvhKU4Iqj",
      "expanded_url" : "https:\/\/blog.timowens.io\/site-publisher-for-cpanel\/",
      "display_url" : "blog.timowens.io\/site-publisher\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727609441793638400",
  "text" : "RT @timmmmyboy: Site Publisher for cPanel https:\/\/t.co\/ktvhKU4Iqj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/ktvhKU4Iqj",
        "expanded_url" : "https:\/\/blog.timowens.io\/site-publisher-for-cpanel\/",
        "display_url" : "blog.timowens.io\/site-publisher\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 38.22434212590836, -77.4903339728218 ]
    },
    "id_str" : "727579463219875841",
    "text" : "Site Publisher for cPanel https:\/\/t.co\/ktvhKU4Iqj",
    "id" : 727579463219875841,
    "created_at" : "2016-05-03 19:23:56 +0000",
    "user" : {
      "name" : "Tim Owens",
      "screen_name" : "timmmmyboy",
      "protected" : false,
      "id_str" : "185375498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568657249413767168\/lnu_2bhL_normal.jpeg",
      "id" : 185375498,
      "verified" : false
    }
  },
  "id" : 727609441793638400,
  "created_at" : "2016-05-03 21:23:03 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 109, 117 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727528864587505664",
  "text" : "An instructor asked if content could be shared between multiple Grav Course Hubs, and thanks to the power of @getgrav indeed it can be.",
  "id" : 727528864587505664,
  "created_at" : "2016-05-03 16:02:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Irwin DeVries",
      "screen_name" : "IrwinDev",
      "indices" : [ 3, 12 ],
      "id_str" : "120194872",
      "id" : 120194872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/CW9jaPGLOY",
      "expanded_url" : "http:\/\/wp.me\/pXLSb-aj",
      "display_url" : "wp.me\/pXLSb-aj"
    } ]
  },
  "geo" : { },
  "id_str" : "727271927853674496",
  "text" : "RT @IrwinDev: New blog post: A slacker\u2019s guide to OER. https:\/\/t.co\/CW9jaPGLOY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/CW9jaPGLOY",
        "expanded_url" : "http:\/\/wp.me\/pXLSb-aj",
        "display_url" : "wp.me\/pXLSb-aj"
      } ]
    },
    "geo" : { },
    "id_str" : "726913337842241536",
    "text" : "New blog post: A slacker\u2019s guide to OER. https:\/\/t.co\/CW9jaPGLOY",
    "id" : 726913337842241536,
    "created_at" : "2016-05-01 23:16:59 +0000",
    "user" : {
      "name" : "Irwin DeVries",
      "screen_name" : "IrwinDev",
      "protected" : false,
      "id_str" : "120194872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718662718132064258\/jmAsqZvL_normal.jpg",
      "id" : 120194872,
      "verified" : false
    }
  },
  "id" : 727271927853674496,
  "created_at" : "2016-05-02 23:01:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grav",
      "screen_name" : "getgrav",
      "indices" : [ 57, 65 ],
      "id_str" : "2737573033",
      "id" : 2737573033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GravEdu",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727201605838217217",
  "text" : "Exploring adding support for multiple courses within one @getgrav Course Hub install for sharing content _between_ courses. #GravEdu",
  "id" : 727201605838217217,
  "created_at" : "2016-05-02 18:22:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]