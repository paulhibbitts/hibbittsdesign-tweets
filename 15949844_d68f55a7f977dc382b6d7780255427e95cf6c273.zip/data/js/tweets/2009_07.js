Grailbird.data.tweets_2009_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2879970480",
  "text" : "Expression Blend 3 Resources for Designers, including tutorials. http:\/\/bit.ly\/jxPQd",
  "id" : 2879970480,
  "created_at" : "2009-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Balsamiq",
      "screen_name" : "balsamiq",
      "indices" : [ 54, 63 ],
      "id_str" : "14361698",
      "id" : 14361698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2694842601",
  "text" : "This can apply to initial usability tests as well. RT @balsamiq: \"If you're not embarrassed by your v.1, you've waited too long to ship\"",
  "id" : 2694842601,
  "created_at" : "2009-07-17 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SketchFlow",
      "indices" : [ 50, 61 ]
    }, {
      "text" : "HyperCard",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2640602305",
  "text" : "Old school meets new school - MS Expression Blend #SketchFlow brings back fond memories of Apple's #HyperCard",
  "id" : 2640602305,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuebo Wang",
      "screen_name" : "yuebwang",
      "indices" : [ 0, 9 ],
      "id_str" : "16090692",
      "id" : 16090692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2562402825",
  "geo" : { },
  "id_str" : "2572997324",
  "in_reply_to_user_id" : 16090692,
  "text" : "@yuebwang Yes, you need to be a IEEE member or pay to get the article. If you're an ACM member a follow-up article is at http:\/\/is.gd\/1tTi8",
  "id" : 2572997324,
  "in_reply_to_status_id" : 2562402825,
  "created_at" : "2009-07-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "yuebwang",
  "in_reply_to_user_id_str" : "16090692",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PowerPoint",
      "indices" : [ 22, 33 ]
    }, {
      "text" : "SketchFlow",
      "indices" : [ 61, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2574317073",
  "text" : "Music to my ears that #PowerPoint decks can be imported into #SketchFlow RC1. http:\/\/is.gd\/1tYuY Possibilities are expanding every day.",
  "id" : 2574317073,
  "created_at" : "2009-07-10 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2558028878",
  "text" : "An older article (IEEE), but an intriguing view of how usability, functionality, and experience can relate to each other. http:\/\/is.gd\/1sHJT",
  "id" : 2558028878,
  "created_at" : "2009-07-09 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2535681443",
  "text" : "Kudos to 37signals for SSL secure encryption on all Basecamp accounts. http:\/\/is.gd\/1rgZh",
  "id" : 2535681443,
  "created_at" : "2009-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2444994688",
  "text" : "Nielsen (http:\/\/is.gd\/1lRTr) missed an important scenario \u2013 password creation can benefit greatly from unmasking to ensure expected results.",
  "id" : 2444994688,
  "created_at" : "2009-07-02 00:00:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]