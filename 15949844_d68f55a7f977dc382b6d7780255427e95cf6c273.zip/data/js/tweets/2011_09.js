Grailbird.data.tweets_2011_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119113513372352512",
  "text" : "Being able to reframe problems is an essential interaction design skill, and will deliver more value than any amount of wireframing.",
  "id" : 119113513372352512,
  "created_at" : "2011-09-28 18:17:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118436457080832000",
  "text" : "I am still favouring different experiences on different platforms (e.g. using a plugin such as WPTouch Pro for WordPress projects) Comments?",
  "id" : 118436457080832000,
  "created_at" : "2011-09-26 21:27:06 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118433976254857216",
  "text" : "In terms of UX I like the idea of responsive web design, but from a workload perspective things look less ideal Any first-hand experiences?",
  "id" : 118433976254857216,
  "created_at" : "2011-09-26 21:17:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenneth",
      "screen_name" : "KennethWong_",
      "indices" : [ 0, 13 ],
      "id_str" : "76891284",
      "id" : 76891284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117283483398848513",
  "geo" : { },
  "id_str" : "117289789371322369",
  "in_reply_to_user_id" : 76891284,
  "text" : "@KennethWong_ Thanks for letting me know, that's good to see",
  "id" : 117289789371322369,
  "in_reply_to_status_id" : 117283483398848513,
  "created_at" : "2011-09-23 17:30:39 +0000",
  "in_reply_to_screen_name" : "KennethWong_",
  "in_reply_to_user_id_str" : "76891284",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/FtCQzMYb",
      "expanded_url" : "http:\/\/jobsprout.ca\/jobs\/243\/user-experience-web-designer",
      "display_url" : "jobsprout.ca\/jobs\/243\/user-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "117289483744976897",
  "text" : "University of British Columbia is hiring a User Experience \/ Web Designer at http:\/\/t.co\/FtCQzMYb",
  "id" : 117289483744976897,
  "created_at" : "2011-09-23 17:29:26 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cnn",
      "indices" : [ 37, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/7D0Ytsp0",
      "expanded_url" : "http:\/\/www.cnn.com\/2011\/09\/22\/opinion\/rushkoff-facebook-changes\/index.html",
      "display_url" : "cnn.com\/2011\/09\/22\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "117053937709883394",
  "text" : "Does Facebook really care about you? #cnn http:\/\/t.co\/7D0Ytsp0 &lt;- People are the product indeed!",
  "id" : 117053937709883394,
  "created_at" : "2011-09-23 01:53:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/K0Rg0z3O",
      "expanded_url" : "http:\/\/www.fastcodesign.com\/1665022\/why-does-interaction-design-matter-lets-look-at-the-evolving-credit-card-swipe",
      "display_url" : "fastcodesign.com\/1665022\/why-do\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "115908174346858496",
  "text" : "Why Does Interaction Design Matter? Let's Look At The Evolving Subway Experience | Co. Design http:\/\/t.co\/K0Rg0z3O",
  "id" : 115908174346858496,
  "created_at" : "2011-09-19 22:00:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Cohn",
      "screen_name" : "mikewcohn",
      "indices" : [ 3, 13 ],
      "id_str" : "55573320",
      "id" : 55573320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/MJ8H5MUa",
      "expanded_url" : "http:\/\/bit.ly\/ogeFS8",
      "display_url" : "bit.ly\/ogeFS8"
    } ]
  },
  "geo" : { },
  "id_str" : "115097834562400257",
  "text" : "RT @mikewcohn: Interesting article saying Facebook is already fading, with comparisons to Yahoo: http:\/\/t.co\/MJ8H5MUa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/MJ8H5MUa",
        "expanded_url" : "http:\/\/bit.ly\/ogeFS8",
        "display_url" : "bit.ly\/ogeFS8"
      } ]
    },
    "geo" : { },
    "id_str" : "115095735401316352",
    "text" : "Interesting article saying Facebook is already fading, with comparisons to Yahoo: http:\/\/t.co\/MJ8H5MUa",
    "id" : 115095735401316352,
    "created_at" : "2011-09-17 16:12:16 +0000",
    "user" : {
      "name" : "Mike Cohn",
      "screen_name" : "mikewcohn",
      "protected" : false,
      "id_str" : "55573320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753667616317673472\/mCz4R6dl_normal.jpg",
      "id" : 55573320,
      "verified" : false
    }
  },
  "id" : 115097834562400257,
  "created_at" : "2011-09-17 16:20:36 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mann",
      "screen_name" : "kevinmannn",
      "indices" : [ 0, 11 ],
      "id_str" : "23169896",
      "id" : 23169896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114784919632347136",
  "geo" : { },
  "id_str" : "114820505646800896",
  "in_reply_to_user_id" : 23169896,
  "text" : "@kevinmannn Thanks for the followup!",
  "id" : 114820505646800896,
  "in_reply_to_status_id" : 114784919632347136,
  "created_at" : "2011-09-16 21:58:36 +0000",
  "in_reply_to_screen_name" : "kevinmannn",
  "in_reply_to_user_id_str" : "23169896",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Mann",
      "screen_name" : "kevinmannn",
      "indices" : [ 0, 11 ],
      "id_str" : "23169896",
      "id" : 23169896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114433169738043393",
  "geo" : { },
  "id_str" : "114760083208011776",
  "in_reply_to_user_id" : 23169896,
  "text" : "@kevinmannn Thanks for sharing your thoughts. Is the lack of a tactile keyboard the issue to you?",
  "id" : 114760083208011776,
  "in_reply_to_status_id" : 114433169738043393,
  "created_at" : "2011-09-16 17:58:30 +0000",
  "in_reply_to_screen_name" : "kevinmannn",
  "in_reply_to_user_id_str" : "23169896",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114428840486518784",
  "text" : "Observation: While tablets are the current hype, student laptops are still very rampant here at University of British Columbia (UBC)",
  "id" : 114428840486518784,
  "created_at" : "2011-09-15 20:02:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113690985736847360",
  "text" : "Great to be teaching UI design once again at SFU - looking forward to an entire term of learning and teaching with my 75 students!",
  "id" : 113690985736847360,
  "created_at" : "2011-09-13 19:10:17 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Brown",
      "screen_name" : "brownorama",
      "indices" : [ 126, 137 ],
      "id_str" : "1761051",
      "id" : 1761051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111872910926422017",
  "text" : "Need to display a mobile device's screen? I am impressed so far with IPEVO Point 2 View USB Document Camera - w mirroring! HT @brownorama",
  "id" : 111872910926422017,
  "created_at" : "2011-09-08 18:45:55 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Jursa",
      "screen_name" : "IATV",
      "indices" : [ 3, 8 ],
      "id_str" : "17151314",
      "id" : 17151314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/39PHr3W",
      "expanded_url" : "http:\/\/mobxcon.org",
      "display_url" : "mobxcon.org"
    } ]
  },
  "geo" : { },
  "id_str" : "110802054485782528",
  "text" : "RT @IATV: New, upcoming and hotter than two goats in a pepper patch: \"MobX - Mobile Experience Design. Meet the Experts!\" http:\/\/t.co\/39 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 131 ],
        "url" : "http:\/\/t.co\/39PHr3W",
        "expanded_url" : "http:\/\/mobxcon.org",
        "display_url" : "mobxcon.org"
      } ]
    },
    "geo" : { },
    "id_str" : "110661459733782528",
    "text" : "New, upcoming and hotter than two goats in a pepper patch: \"MobX - Mobile Experience Design. Meet the Experts!\" http:\/\/t.co\/39PHr3W",
    "id" : 110661459733782528,
    "created_at" : "2011-09-05 10:32:02 +0000",
    "user" : {
      "name" : "Jan Jursa",
      "screen_name" : "IATV",
      "protected" : false,
      "id_str" : "17151314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466681693235982336\/4v-lZ2o2_normal.jpeg",
      "id" : 17151314,
      "verified" : false
    }
  },
  "id" : 110802054485782528,
  "created_at" : "2011-09-05 19:50:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]