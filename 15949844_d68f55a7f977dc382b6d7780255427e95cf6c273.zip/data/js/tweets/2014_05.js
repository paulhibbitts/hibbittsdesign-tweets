Grailbird.data.tweets_2014_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Dickerson",
      "screen_name" : "JosephDickerson",
      "indices" : [ 0, 16 ],
      "id_str" : "14407107",
      "id" : 14407107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472555223610040320",
  "geo" : { },
  "id_str" : "472558180451745792",
  "in_reply_to_user_id" : 14407107,
  "text" : "@JosephDickerson Hope your ok, take care.",
  "id" : 472558180451745792,
  "in_reply_to_status_id" : 472555223610040320,
  "created_at" : "2014-05-31 02:00:24 +0000",
  "in_reply_to_screen_name" : "JosephDickerson",
  "in_reply_to_user_id_str" : "14407107",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UBC Robson Square",
      "screen_name" : "UBCRobsonSquare",
      "indices" : [ 98, 114 ],
      "id_str" : "210914069",
      "id" : 210914069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/D9mjvVvlPU",
      "expanded_url" : "http:\/\/www.cstudies.ubc.ca\/a\/Course\/Designing-Multi-device-Learning-Experiences\/IY103\/",
      "display_url" : "cstudies.ubc.ca\/a\/Course\/Desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "472150961860136960",
  "text" : "Interested in multi-device learning experiences? Space is still available in my June 5th Workshop @UBCRobsonSquare http:\/\/t.co\/D9mjvVvlPU",
  "id" : 472150961860136960,
  "created_at" : "2014-05-29 23:02:16 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/uXBCz5vlVH",
      "expanded_url" : "http:\/\/www.slideshare.net\/hibbittsdesign\/wordpress-in-higher-ed-designing-a-multidevice-wordpress-course-site-a-case-study",
      "display_url" : "slideshare.net\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "472142895667871744",
  "text" : "Thanks to everyone involved in the WordPress In Higher Education Virtual Conference. Great discussion and questions! http:\/\/t.co\/uXBCz5vlVH",
  "id" : 472142895667871744,
  "created_at" : "2014-05-29 22:30:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "indices" : [ 3, 14 ],
      "id_str" : "28429477",
      "id" : 28429477
    }, {
      "name" : "Lambda Solutions",
      "screen_name" : "lambdasolutions",
      "indices" : [ 30, 46 ],
      "id_str" : "86378776",
      "id" : 86378776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moodle",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/l8HAt9vz2q",
      "expanded_url" : "http:\/\/ow.ly\/xnH37",
      "display_url" : "ow.ly\/xnH37"
    } ]
  },
  "geo" : { },
  "id_str" : "472058470469210112",
  "text" : "RT @chadleaman: Join me for a @lambdasolutions #moodle webinar.  Greatest hits and what's new in 2.7.  Starting at 10 today http:\/\/t.co\/l8H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lambda Solutions",
        "screen_name" : "lambdasolutions",
        "indices" : [ 14, 30 ],
        "id_str" : "86378776",
        "id" : 86378776
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "moodle",
        "indices" : [ 31, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/l8HAt9vz2q",
        "expanded_url" : "http:\/\/ow.ly\/xnH37",
        "display_url" : "ow.ly\/xnH37"
      } ]
    },
    "geo" : { },
    "id_str" : "472056058207567872",
    "text" : "Join me for a @lambdasolutions #moodle webinar.  Greatest hits and what's new in 2.7.  Starting at 10 today http:\/\/t.co\/l8HAt9vz2q",
    "id" : 472056058207567872,
    "created_at" : "2014-05-29 16:45:09 +0000",
    "user" : {
      "name" : "Chad Leaman",
      "screen_name" : "chadleaman",
      "protected" : false,
      "id_str" : "28429477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529010906080894976\/Ij-z3nNd_normal.png",
      "id" : 28429477,
      "verified" : false
    }
  },
  "id" : 472058470469210112,
  "created_at" : "2014-05-29 16:54:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curtiss Grymala",
      "screen_name" : "cgrymala",
      "indices" : [ 3, 12 ],
      "id_str" : "24093368",
      "id" : 24093368
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WordPress",
      "indices" : [ 64, 74 ]
    }, {
      "text" : "HigherEd",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/LQKT8VoMng",
      "expanded_url" : "http:\/\/wordpressinhigheredconference.wordpress.com\/",
      "display_url" : "\u2026essinhigheredconference.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "472007418063646720",
  "text" : "RT @cgrymala: In about an hour, I'll be helping to kick off the #WordPress in #HigherEd virtual conference. Tix still available http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WordPress",
        "indices" : [ 50, 60 ]
      }, {
        "text" : "HigherEd",
        "indices" : [ 64, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/LQKT8VoMng",
        "expanded_url" : "http:\/\/wordpressinhigheredconference.wordpress.com\/",
        "display_url" : "\u2026essinhigheredconference.wordpress.com"
      } ]
    },
    "geo" : { },
    "id_str" : "471991321029533696",
    "text" : "In about an hour, I'll be helping to kick off the #WordPress in #HigherEd virtual conference. Tix still available http:\/\/t.co\/LQKT8VoMng",
    "id" : 471991321029533696,
    "created_at" : "2014-05-29 12:27:54 +0000",
    "user" : {
      "name" : "Curtiss Grymala",
      "screen_name" : "cgrymala",
      "protected" : false,
      "id_str" : "24093368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539031680611131392\/6JNGxlph_normal.jpeg",
      "id" : 24093368,
      "verified" : false
    }
  },
  "id" : 472007418063646720,
  "created_at" : "2014-05-29 13:31:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft Office",
      "screen_name" : "Office",
      "indices" : [ 0, 7 ],
      "id_str" : "22209176",
      "id" : 22209176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471801973143265280",
  "geo" : { },
  "id_str" : "471820943455571968",
  "in_reply_to_user_id" : 22209176,
  "text" : "@Office Thanks for the follow-up, I've posted some more details at the URL you sent. Thank you, and I will keep my fingers crossed :-)",
  "id" : 471820943455571968,
  "in_reply_to_status_id" : 471801973143265280,
  "created_at" : "2014-05-29 01:10:53 +0000",
  "in_reply_to_screen_name" : "Office",
  "in_reply_to_user_id_str" : "22209176",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ExplorationsofStyle",
      "screen_name" : "explorstyle",
      "indices" : [ 3, 15 ],
      "id_str" : "356850668",
      "id" : 356850668
    }, {
      "name" : "Chris Long",
      "screen_name" : "cplong",
      "indices" : [ 22, 29 ],
      "id_str" : "769099",
      "id" : 769099
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 33, 40 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/uVhK5vdfyG",
      "expanded_url" : "http:\/\/ow.ly\/xlCN8",
      "display_url" : "ow.ly\/xlCN8"
    } ]
  },
  "geo" : { },
  "id_str" : "471766326130655232",
  "text" : "RT @explorstyle: From @cplong, a @medium post on the art of live-blogging in an academic setting: http:\/\/t.co\/uVhK5vdfyG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Long",
        "screen_name" : "cplong",
        "indices" : [ 5, 12 ],
        "id_str" : "769099",
        "id" : 769099
      }, {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 16, 23 ],
        "id_str" : "571202103",
        "id" : 571202103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/uVhK5vdfyG",
        "expanded_url" : "http:\/\/ow.ly\/xlCN8",
        "display_url" : "ow.ly\/xlCN8"
      } ]
    },
    "geo" : { },
    "id_str" : "471729020753936385",
    "text" : "From @cplong, a @medium post on the art of live-blogging in an academic setting: http:\/\/t.co\/uVhK5vdfyG",
    "id" : 471729020753936385,
    "created_at" : "2014-05-28 19:05:37 +0000",
    "user" : {
      "name" : "ExplorationsofStyle",
      "screen_name" : "explorstyle",
      "protected" : false,
      "id_str" : "356850668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539534943508893696\/areF8fnm_normal.jpeg",
      "id" : 356850668,
      "verified" : false
    }
  },
  "id" : 471766326130655232,
  "created_at" : "2014-05-28 21:33:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 3, 13 ],
      "id_str" : "887742962",
      "id" : 887742962
    }, {
      "name" : "Teaching & Learning",
      "screen_name" : "SFUteachlearn",
      "indices" : [ 135, 140 ],
      "id_str" : "153597392",
      "id" : 153597392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 42, 46 ]
    }, {
      "text" : "tophat",
      "indices" : [ 48, 55 ]
    }, {
      "text" : "iclicker",
      "indices" : [ 56, 65 ]
    }, {
      "text" : "polleverywhere",
      "indices" : [ 66, 81 ]
    }, {
      "text" : "turningpoint",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471755929914863616",
  "text" : "RT @keroleenl: Considering using a SRS at #SFU? #tophat #iclicker #polleverywhere #turningpoint Contact learntech for more information @SFU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Teaching & Learning",
        "screen_name" : "SFUteachlearn",
        "indices" : [ 120, 134 ],
        "id_str" : "153597392",
        "id" : 153597392
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SFU",
        "indices" : [ 27, 31 ]
      }, {
        "text" : "tophat",
        "indices" : [ 33, 40 ]
      }, {
        "text" : "iclicker",
        "indices" : [ 41, 50 ]
      }, {
        "text" : "polleverywhere",
        "indices" : [ 51, 66 ]
      }, {
        "text" : "turningpoint",
        "indices" : [ 67, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471750007939268608",
    "text" : "Considering using a SRS at #SFU? #tophat #iclicker #polleverywhere #turningpoint Contact learntech for more information @SFUteachlearn",
    "id" : 471750007939268608,
    "created_at" : "2014-05-28 20:29:01 +0000",
    "user" : {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "protected" : false,
      "id_str" : "887742962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515581656686546944\/Q76DpwVe_normal.png",
      "id" : 887742962,
      "verified" : false
    }
  },
  "id" : 471755929914863616,
  "created_at" : "2014-05-28 20:52:33 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft Office",
      "screen_name" : "Office",
      "indices" : [ 0, 7 ],
      "id_str" : "22209176",
      "id" : 22209176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471743423247319040",
  "in_reply_to_user_id" : 22209176,
  "text" : "@Office It is 2014, and unbelievably Mac PowerPoint still has issues when  printing slide text in black and white! Will this ever be fixed?",
  "id" : 471743423247319040,
  "created_at" : "2014-05-28 20:02:51 +0000",
  "in_reply_to_screen_name" : "Office",
  "in_reply_to_user_id_str" : "22209176",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keroleen",
      "screen_name" : "keroleenl",
      "indices" : [ 0, 10 ],
      "id_str" : "887742962",
      "id" : 887742962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471732908894334976",
  "geo" : { },
  "id_str" : "471736741020188673",
  "in_reply_to_user_id" : 887742962,
  "text" : "@keroleenl Hi Kar-On! Yes, but I am more drawn to the freeform nature of a stream of student comments and\/or questions during the session...",
  "id" : 471736741020188673,
  "in_reply_to_status_id" : 471732908894334976,
  "created_at" : "2014-05-28 19:36:18 +0000",
  "in_reply_to_screen_name" : "keroleenl",
  "in_reply_to_user_id_str" : "887742962",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Zaru",
      "screen_name" : "yes",
      "indices" : [ 0, 4 ],
      "id_str" : "40108817",
      "id" : 40108817
    }, {
      "name" : "Kato.im",
      "screen_name" : "kato_im",
      "indices" : [ 30, 38 ],
      "id_str" : "1026990656",
      "id" : 1026990656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471708005264674816",
  "geo" : { },
  "id_str" : "471709908694335488",
  "in_reply_to_user_id" : 40108817,
  "text" : "@yes You should also checkout @kato_im",
  "id" : 471709908694335488,
  "in_reply_to_status_id" : 471708005264674816,
  "created_at" : "2014-05-28 17:49:40 +0000",
  "in_reply_to_screen_name" : "yes",
  "in_reply_to_user_id_str" : "40108817",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/U9qk7zzBM0",
      "expanded_url" : "https:\/\/blog.hipchat.com\/2014\/05\/27\/hipchat-is-now-free-for-unlimited-users\/",
      "display_url" : "blog.hipchat.com\/2014\/05\/27\/hip\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "471706875906756608",
  "text" : "HipChat is another real-time messaging tool suitable for 1-to-1 mentoring, and it is now FREE for UNLIMITED users https:\/\/t.co\/U9qk7zzBM0",
  "id" : 471706875906756608,
  "created_at" : "2014-05-28 17:37:37 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kato.im",
      "screen_name" : "kato_im",
      "indices" : [ 17, 25 ],
      "id_str" : "1026990656",
      "id" : 1026990656
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/xXLuhlCQ5V",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/16304\/",
      "display_url" : "canvas.sfu.ca\/courses\/16304\/"
    } ]
  },
  "geo" : { },
  "id_str" : "471698466863722496",
  "text" : "Along with using @kato_im for 1-to-1 mentoring, I am exploring real-time commentary during class, all via #CanvasLMS https:\/\/t.co\/xXLuhlCQ5V",
  "id" : 471698466863722496,
  "created_at" : "2014-05-28 17:04:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Ridden",
      "screen_name" : "EduRidden",
      "indices" : [ 0, 10 ],
      "id_str" : "9198142",
      "id" : 9198142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ER2iG4zZfT",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/16304",
      "display_url" : "canvas.sfu.ca\/courses\/16304"
    } ]
  },
  "in_reply_to_status_id_str" : "471491599369662464",
  "geo" : { },
  "id_str" : "471500125810851840",
  "in_reply_to_user_id" : 9198142,
  "text" : "@EduRidden Thanks very much Julian! Always happy to share my experiences to help make Canvas better. Prototype is at https:\/\/t.co\/ER2iG4zZfT",
  "id" : 471500125810851840,
  "in_reply_to_status_id" : 471491599369662464,
  "created_at" : "2014-05-28 03:56:04 +0000",
  "in_reply_to_screen_name" : "EduRidden",
  "in_reply_to_user_id_str" : "9198142",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/471380413215027201\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/WaezAsJAPk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Boqt_LNIgAA8Edk.png",
      "id_str" : "471380411864875008",
      "id" : 471380411864875008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Boqt_LNIgAA8Edk.png",
      "sizes" : [ {
        "h" : 1932,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1132,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1940,
        "resize" : "fit",
        "w" : 1028
      }, {
        "h" : 642,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WaezAsJAPk"
    } ],
    "hashtags" : [ {
      "text" : "CanvasLMS",
      "indices" : [ 37, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471380413215027201",
  "text" : "Second iteration of student-centered #CanvasLMS front page, which also supports graceful degradation w. mobile apps. http:\/\/t.co\/WaezAsJAPk",
  "id" : 471380413215027201,
  "created_at" : "2014-05-27 20:00:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "will engle",
      "screen_name" : "infology",
      "indices" : [ 3, 12 ],
      "id_str" : "93031146",
      "id" : 93031146
    }, {
      "name" : "Hibbitts Design",
      "screen_name" : "hibbittsdesign",
      "indices" : [ 90, 105 ],
      "id_str" : "15949844",
      "id" : 15949844
    }, {
      "name" : "novak rogic",
      "screen_name" : "supernova_k",
      "indices" : [ 112, 124 ],
      "id_str" : "3446221",
      "id" : 3446221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EdTech",
      "indices" : [ 14, 21 ]
    }, {
      "text" : "OpenEd",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/hzSFJ77EmV",
      "expanded_url" : "http:\/\/bcopened.org\/bc-open-open-ed-chats\/archives\/",
      "display_url" : "bcopened.org\/bc-open-open-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "471322879494062080",
  "text" : "RT @infology: #EdTech approaches to support #OpenEd? Archived BC Open Education Chat with @hibbittsdesign &amp; @supernova_k now up at http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hibbitts Design",
        "screen_name" : "hibbittsdesign",
        "indices" : [ 76, 91 ],
        "id_str" : "15949844",
        "id" : 15949844
      }, {
        "name" : "novak rogic",
        "screen_name" : "supernova_k",
        "indices" : [ 98, 110 ],
        "id_str" : "3446221",
        "id" : 3446221
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EdTech",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "OpenEd",
        "indices" : [ 30, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/hzSFJ77EmV",
        "expanded_url" : "http:\/\/bcopened.org\/bc-open-open-ed-chats\/archives\/",
        "display_url" : "bcopened.org\/bc-open-open-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "471068358511566848",
    "text" : "#EdTech approaches to support #OpenEd? Archived BC Open Education Chat with @hibbittsdesign &amp; @supernova_k now up at http:\/\/t.co\/hzSFJ77EmV",
    "id" : 471068358511566848,
    "created_at" : "2014-05-26 23:20:23 +0000",
    "user" : {
      "name" : "will engle",
      "screen_name" : "infology",
      "protected" : false,
      "id_str" : "93031146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1598136377\/icon_normal.jpg",
      "id" : 93031146,
      "verified" : false
    }
  },
  "id" : 471322879494062080,
  "created_at" : "2014-05-27 16:11:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/471024149083586560\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/PLs37M8mZl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bolp94jCcAAMlIb.png",
      "id_str" : "471024147909210112",
      "id" : 471024147909210112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bolp94jCcAAMlIb.png",
      "sizes" : [ {
        "h" : 669,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2024,
        "resize" : "fit",
        "w" : 1029
      }, {
        "h" : 2014,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1180,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/PLs37M8mZl"
    } ],
    "hashtags" : [ {
      "text" : "SFU",
      "indices" : [ 19, 23 ]
    }, {
      "text" : "CanvasLMS",
      "indices" : [ 24, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/xXLuhlCQ5V",
      "expanded_url" : "https:\/\/canvas.sfu.ca\/courses\/16304\/",
      "display_url" : "canvas.sfu.ca\/courses\/16304\/"
    } ]
  },
  "geo" : { },
  "id_str" : "471024149083586560",
  "text" : "Exploring what the #SFU #CanvasLMS can do. First iteration of a student-centered front page. https:\/\/t.co\/xXLuhlCQ5V http:\/\/t.co\/PLs37M8mZl",
  "id" : 471024149083586560,
  "created_at" : "2014-05-26 20:24:43 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hart",
      "screen_name" : "canvassupport",
      "indices" : [ 0, 14 ],
      "id_str" : "743537932577845249",
      "id" : 743537932577845249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469261317409222657",
  "text" : "@canvassupport OK, thanks for the info and I appreciate the quick reply!",
  "id" : 469261317409222657,
  "created_at" : "2014-05-21 23:39:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hart",
      "screen_name" : "canvassupport",
      "indices" : [ 0, 14 ],
      "id_str" : "743537932577845249",
      "id" : 743537932577845249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469221431914418176",
  "text" : "@canvassupport Is there any way to embed a responsive YouTube video in a Canvas page? i.e. resizes as the Browser window is resized? Thanks!",
  "id" : 469221431914418176,
  "created_at" : "2014-05-21 21:01:21 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "etug",
      "screen_name" : "etug",
      "indices" : [ 3, 8 ],
      "id_str" : "17102936",
      "id" : 17102936
    }, {
      "name" : "Langara College",
      "screen_name" : "langaracollege",
      "indices" : [ 126, 140 ],
      "id_str" : "19388112",
      "id" : 19388112
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etug",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469214269251137536",
  "text" : "RT @etug: Learn about maker culture, open ed practices, social media in the classroom, moblile learning at the #etug workshop @langaracolle\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Langara College",
        "screen_name" : "langaracollege",
        "indices" : [ 116, 131 ],
        "id_str" : "19388112",
        "id" : 19388112
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "etug",
        "indices" : [ 101, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469212605303648256",
    "text" : "Learn about maker culture, open ed practices, social media in the classroom, moblile learning at the #etug workshop @langaracollege",
    "id" : 469212605303648256,
    "created_at" : "2014-05-21 20:26:17 +0000",
    "user" : {
      "name" : "etug",
      "screen_name" : "etug",
      "protected" : false,
      "id_str" : "17102936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674362028899753988\/M7xIIhcd_normal.png",
      "id" : 17102936,
      "verified" : false
    }
  },
  "id" : 469214269251137536,
  "created_at" : "2014-05-21 20:32:54 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly MacDonald",
      "screen_name" : "sparkandco",
      "indices" : [ 0, 11 ],
      "id_str" : "47105948",
      "id" : 47105948
    }, {
      "name" : "Kato.im",
      "screen_name" : "kato_im",
      "indices" : [ 12, 20 ],
      "id_str" : "1026990656",
      "id" : 1026990656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469167888020955136",
  "geo" : { },
  "id_str" : "469169571941732352",
  "in_reply_to_user_id" : 47105948,
  "text" : "@sparkandco @kato_im Always happy to chat Holly! Please email me and we can take things from there.",
  "id" : 469169571941732352,
  "in_reply_to_status_id" : 469167888020955136,
  "created_at" : "2014-05-21 17:35:17 +0000",
  "in_reply_to_screen_name" : "sparkandco",
  "in_reply_to_user_id_str" : "47105948",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kato.im",
      "screen_name" : "kato_im",
      "indices" : [ 107, 115 ],
      "id_str" : "1026990656",
      "id" : 1026990656
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/469165523666624512\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/gIRXQpnRze",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoLPjoKIIAATnOP.png",
      "id_str" : "469165522182217728",
      "id" : 469165522182217728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoLPjoKIIAATnOP.png",
      "sizes" : [ {
        "h" : 794,
        "resize" : "fit",
        "w" : 1212
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gIRXQpnRze"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469165523666624512",
  "text" : "Second iteration of a coaching\/mentoring space to complement f2f SFU course, using real-time messaging app @kato_im http:\/\/t.co\/gIRXQpnRze",
  "id" : 469165523666624512,
  "created_at" : "2014-05-21 17:19:12 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Lidwell",
      "screen_name" : "williamlidwell",
      "indices" : [ 3, 18 ],
      "id_str" : "97539641",
      "id" : 97539641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468941216688926721",
  "text" : "RT @williamlidwell: Minimum viable product (MVP) focuses on the wrong problem(s). Better to think in terms of minimum viable experience (MV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "468842018073223169",
    "text" : "Minimum viable product (MVP) focuses on the wrong problem(s). Better to think in terms of minimum viable experience (MVE).",
    "id" : 468842018073223169,
    "created_at" : "2014-05-20 19:53:42 +0000",
    "user" : {
      "name" : "William Lidwell",
      "screen_name" : "williamlidwell",
      "protected" : false,
      "id_str" : "97539641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707963992497455104\/W6Mtv8Mm_normal.jpg",
      "id" : 97539641,
      "verified" : false
    }
  },
  "id" : 468941216688926721,
  "created_at" : "2014-05-21 02:27:53 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Schwartz",
      "screen_name" : "uxisthepoint",
      "indices" : [ 3, 16 ],
      "id_str" : "16665508",
      "id" : 16665508
    }, {
      "name" : "Gigaom",
      "screen_name" : "gigaom",
      "indices" : [ 103, 110 ],
      "id_str" : "2893971",
      "id" : 2893971
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Google",
      "indices" : [ 22, 29 ]
    }, {
      "text" : "Chrome",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/y9ZuGe6BZw",
      "expanded_url" : "http:\/\/buff.ly\/1mTkXbM",
      "display_url" : "buff.ly\/1mTkXbM"
    } ]
  },
  "geo" : { },
  "id_str" : "468922310989471745",
  "text" : "RT @uxisthepoint: How #Google plans to rule the computing world through #Chrome http:\/\/t.co\/y9ZuGe6BZw @gigaom Me: Really very important",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gigaom",
        "screen_name" : "gigaom",
        "indices" : [ 85, 92 ],
        "id_str" : "2893971",
        "id" : 2893971
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Google",
        "indices" : [ 4, 11 ]
      }, {
        "text" : "Chrome",
        "indices" : [ 54, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/y9ZuGe6BZw",
        "expanded_url" : "http:\/\/buff.ly\/1mTkXbM",
        "display_url" : "buff.ly\/1mTkXbM"
      } ]
    },
    "geo" : { },
    "id_str" : "468919375366733824",
    "text" : "How #Google plans to rule the computing world through #Chrome http:\/\/t.co\/y9ZuGe6BZw @gigaom Me: Really very important",
    "id" : 468919375366733824,
    "created_at" : "2014-05-21 01:01:05 +0000",
    "user" : {
      "name" : "Jon Schwartz",
      "screen_name" : "uxisthepoint",
      "protected" : false,
      "id_str" : "16665508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1186859761\/70756_694955928_3593625_n_normal.jpg",
      "id" : 16665508,
      "verified" : false
    }
  },
  "id" : 468922310989471745,
  "created_at" : "2014-05-21 01:12:45 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft OneNote",
      "screen_name" : "msonenote",
      "indices" : [ 0, 10 ],
      "id_str" : "23735316",
      "id" : 23735316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/hn09v0sg90",
      "expanded_url" : "http:\/\/answers.microsoft.com\/en-us\/office\/forum\/office_onenote-onenote_devices\/section-links-not-working-as-expected\/bc1a7889-1cad-429d-b177-dfa868399d70?tm=1400557095462",
      "display_url" : "answers.microsoft.com\/en-us\/office\/f\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "468463853245038592",
  "geo" : { },
  "id_str" : "468597424479797248",
  "in_reply_to_user_id" : 23735316,
  "text" : "@msonenote Thanks for the follow-up. I've posted details on the issue at http:\/\/t.co\/hn09v0sg90",
  "id" : 468597424479797248,
  "in_reply_to_status_id" : 468463853245038592,
  "created_at" : "2014-05-20 03:41:46 +0000",
  "in_reply_to_screen_name" : "msonenote",
  "in_reply_to_user_id_str" : "23735316",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UIE",
      "screen_name" : "UIE",
      "indices" : [ 3, 7 ],
      "id_str" : "1063291",
      "id" : 1063291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/2WWmbiokYu",
      "expanded_url" : "http:\/\/ar.gy\/5ohu",
      "display_url" : "ar.gy\/5ohu"
    } ]
  },
  "geo" : { },
  "id_str" : "468121596054364161",
  "text" : "RT @UIE: OnDemand content from the last 6 UIE conferences now in All You Can Learn http:\/\/t.co\/2WWmbiokYu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/reach.me\" rel=\"nofollow\"\u003EReach.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/2WWmbiokYu",
        "expanded_url" : "http:\/\/ar.gy\/5ohu",
        "display_url" : "ar.gy\/5ohu"
      } ]
    },
    "geo" : { },
    "id_str" : "468081102016774144",
    "text" : "OnDemand content from the last 6 UIE conferences now in All You Can Learn http:\/\/t.co\/2WWmbiokYu",
    "id" : 468081102016774144,
    "created_at" : "2014-05-18 17:30:05 +0000",
    "user" : {
      "name" : "UIE",
      "screen_name" : "UIE",
      "protected" : false,
      "id_str" : "1063291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3759116326\/19308cfcdb0b831111d4ee3fc3e6232c_normal.jpeg",
      "id" : 1063291,
      "verified" : false
    }
  },
  "id" : 468121596054364161,
  "created_at" : "2014-05-18 20:11:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Cooper",
      "screen_name" : "MrAlanCooper",
      "indices" : [ 3, 16 ],
      "id_str" : "103920270",
      "id" : 103920270
    }, {
      "name" : "Jonathan Korman",
      "screen_name" : "miniver",
      "indices" : [ 28, 36 ],
      "id_str" : "822441",
      "id" : 822441
    }, {
      "name" : "Patrick Neeman",
      "screen_name" : "usabilitycounts",
      "indices" : [ 64, 80 ],
      "id_str" : "14340145",
      "id" : 14340145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/7yVUGQcNM0",
      "expanded_url" : "https:\/\/storify.com\/miniver\/on-the-challenge-of-cultivating-junior-designers-f?awesm=sfy.co_tVny&utm_medium=sfy.co-twitter&utm_source=t.co&utm_campaign=&utm_content=storify-pingback",
      "display_url" : "storify.com\/miniver\/on-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "467667369192882176",
  "text" : "RT @MrAlanCooper: Thanks to @miniver, we can read the wisdom of @usabilitycounts on creating journeymen UX designers: https:\/\/t.co\/7yVUGQcN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Korman",
        "screen_name" : "miniver",
        "indices" : [ 10, 18 ],
        "id_str" : "822441",
        "id" : 822441
      }, {
        "name" : "Patrick Neeman",
        "screen_name" : "usabilitycounts",
        "indices" : [ 46, 62 ],
        "id_str" : "14340145",
        "id" : 14340145
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/7yVUGQcNM0",
        "expanded_url" : "https:\/\/storify.com\/miniver\/on-the-challenge-of-cultivating-junior-designers-f?awesm=sfy.co_tVny&utm_medium=sfy.co-twitter&utm_source=t.co&utm_campaign=&utm_content=storify-pingback",
        "display_url" : "storify.com\/miniver\/on-the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "467666398764732416",
    "text" : "Thanks to @miniver, we can read the wisdom of @usabilitycounts on creating journeymen UX designers: https:\/\/t.co\/7yVUGQcNM0",
    "id" : 467666398764732416,
    "created_at" : "2014-05-17 14:02:12 +0000",
    "user" : {
      "name" : "Alan Cooper",
      "screen_name" : "MrAlanCooper",
      "protected" : false,
      "id_str" : "103920270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1470274107\/Alan_Avatar_normal.jpg",
      "id" : 103920270,
      "verified" : false
    }
  },
  "id" : 467667369192882176,
  "created_at" : "2014-05-17 14:06:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2014",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/YgPGmwdTcL",
      "expanded_url" : "http:\/\/www.slideshare.net\/hibbittsdesign\/imoot-2014-designing-a-multidevice-moodle-course-site-a-case-study",
      "display_url" : "slideshare.net\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "467449475502325760",
  "text" : "Really enjoyed the Q&amp;A with my last #iMoot2014 session! Slides for designing multi-device Moodle course sites are at http:\/\/t.co\/YgPGmwdTcL",
  "id" : 467449475502325760,
  "created_at" : "2014-05-16 23:40:14 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Bragg",
      "screen_name" : "ChemBragg",
      "indices" : [ 3, 13 ],
      "id_str" : "420018941",
      "id" : 420018941
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imoot2014",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467427327115145216",
  "text" : "RT @ChemBragg: Awesome session by Floyd Saner on LTI\/External Tools in Moodle. #imoot2014",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "imoot2014",
        "indices" : [ 64, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467425125449871360",
    "text" : "Awesome session by Floyd Saner on LTI\/External Tools in Moodle. #imoot2014",
    "id" : 467425125449871360,
    "created_at" : "2014-05-16 22:03:28 +0000",
    "user" : {
      "name" : "Joshua Bragg",
      "screen_name" : "ChemBragg",
      "protected" : false,
      "id_str" : "420018941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761393491435986944\/D2Of_dCL_normal.jpg",
      "id" : 420018941,
      "verified" : false
    }
  },
  "id" : 467427327115145216,
  "created_at" : "2014-05-16 22:12:13 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Official imoot news",
      "screen_name" : "imootonline",
      "indices" : [ 3, 15 ],
      "id_str" : "235030875",
      "id" : 235030875
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imoot2014",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467424818740994048",
  "text" : "RT @imootonline: Coming up: \"Designing a Multi-device Moodle Course Site: A Case Study\" Paul Hibbitts #imoot2014",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "imoot2014",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467424558761263106",
    "text" : "Coming up: \"Designing a Multi-device Moodle Course Site: A Case Study\" Paul Hibbitts #imoot2014",
    "id" : 467424558761263106,
    "created_at" : "2014-05-16 22:01:13 +0000",
    "user" : {
      "name" : "Official imoot news",
      "screen_name" : "imootonline",
      "protected" : false,
      "id_str" : "235030875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430291211224502272\/OqJeyJEL_normal.png",
      "id" : 235030875,
      "verified" : false
    }
  },
  "id" : 467424818740994048,
  "created_at" : "2014-05-16 22:02:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Elliott",
      "screen_name" : "ikawhero",
      "indices" : [ 0, 9 ],
      "id_str" : "15014149",
      "id" : 15014149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467335133486264320",
  "geo" : { },
  "id_str" : "467340900876562432",
  "in_reply_to_user_id" : 15014149,
  "text" : "@ikawhero AWESOME idea, very helpful!",
  "id" : 467340900876562432,
  "in_reply_to_status_id" : 467335133486264320,
  "created_at" : "2014-05-16 16:28:48 +0000",
  "in_reply_to_screen_name" : "ikawhero",
  "in_reply_to_user_id_str" : "15014149",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Usabilla",
      "screen_name" : "usabilla",
      "indices" : [ 3, 12 ],
      "id_str" : "16601140",
      "id" : 16601140
    }, {
      "name" : "Jennifer Aldrich",
      "screen_name" : "jma245",
      "indices" : [ 66, 73 ],
      "id_str" : "32696488",
      "id" : 32696488
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/usabilla\/status\/467303578538102784\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/ZDP8BaBStJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnwyIPGIcAAVDDC.jpg",
      "id_str" : "467303578412281856",
      "id" : 467303578412281856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnwyIPGIcAAVDDC.jpg",
      "sizes" : [ {
        "h" : 655,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZDP8BaBStJ"
    } ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 74, 77 ]
    }, {
      "text" : "mobile",
      "indices" : [ 78, 85 ]
    }, {
      "text" : "design",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467306260790910977",
  "text" : "RT @usabilla: Mobile UX: User Expectations have shifted [pic] via @jma245 #ux #mobile #design http:\/\/t.co\/ZDP8BaBStJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jennifer Aldrich",
        "screen_name" : "jma245",
        "indices" : [ 52, 59 ],
        "id_str" : "32696488",
        "id" : 32696488
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/usabilla\/status\/467303578538102784\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/ZDP8BaBStJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnwyIPGIcAAVDDC.jpg",
        "id_str" : "467303578412281856",
        "id" : 467303578412281856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnwyIPGIcAAVDDC.jpg",
        "sizes" : [ {
          "h" : 655,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 655,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ZDP8BaBStJ"
      } ],
      "hashtags" : [ {
        "text" : "ux",
        "indices" : [ 60, 63 ]
      }, {
        "text" : "mobile",
        "indices" : [ 64, 71 ]
      }, {
        "text" : "design",
        "indices" : [ 72, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467303578538102784",
    "text" : "Mobile UX: User Expectations have shifted [pic] via @jma245 #ux #mobile #design http:\/\/t.co\/ZDP8BaBStJ",
    "id" : 467303578538102784,
    "created_at" : "2014-05-16 14:00:29 +0000",
    "user" : {
      "name" : "Usabilla",
      "screen_name" : "usabilla",
      "protected" : false,
      "id_str" : "16601140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555698253535010816\/Ln3de7fV_normal.png",
      "id" : 16601140,
      "verified" : false
    }
  },
  "id" : 467306260790910977,
  "created_at" : "2014-05-16 14:11:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2014",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467131576556351488",
  "text" : "Super impressed by all the folks from BigBlueButton who are always ready to help out with each and every #iMoot2014 presentation I've given!",
  "id" : 467131576556351488,
  "created_at" : "2014-05-16 02:37:01 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2014",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/PMmT80QwPy",
      "expanded_url" : "http:\/\/www.slideshare.net\/hibbittsdesign\/imoot-2014-developing-a-course-in-the-open-a-case-study",
      "display_url" : "slideshare.net\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "467111616186572800",
  "text" : "A big thank you to everyone who attended my #iMoot2014 presentation on developing a course in the open today! Slides: http:\/\/t.co\/PMmT80QwPy",
  "id" : 467111616186572800,
  "created_at" : "2014-05-16 01:17:42 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MC&C Media",
      "screen_name" : "MCandC",
      "indices" : [ 3, 10 ],
      "id_str" : "321370799",
      "id" : 321370799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mobileengage",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467045216449339392",
  "text" : "RT @MCandC: Google predicting December 4th when mobile search overtakes desktop. Display and video moving in that direction too. #mobileeng\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mobileengage",
        "indices" : [ 117, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 51.511082351, -0.1018115494 ]
    },
    "id_str" : "466880591267651584",
    "text" : "Google predicting December 4th when mobile search overtakes desktop. Display and video moving in that direction too. #mobileengage",
    "id" : 466880591267651584,
    "created_at" : "2014-05-15 09:59:41 +0000",
    "user" : {
      "name" : "MC&C Media",
      "screen_name" : "MCandC",
      "protected" : false,
      "id_str" : "321370799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491208237497077760\/-xvBpX6z_normal.jpeg",
      "id" : 321370799,
      "verified" : false
    }
  },
  "id" : 467045216449339392,
  "created_at" : "2014-05-15 20:53:51 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jean-Marc Doucet",
      "screen_name" : "jmd87fr",
      "indices" : [ 0, 8 ],
      "id_str" : "84863141",
      "id" : 84863141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467042899495256064",
  "geo" : { },
  "id_str" : "467043302840492032",
  "in_reply_to_user_id" : 84863141,
  "text" : "@jmd87fr Thank you, my pleasure!",
  "id" : 467043302840492032,
  "in_reply_to_status_id" : 467042899495256064,
  "created_at" : "2014-05-15 20:46:15 +0000",
  "in_reply_to_screen_name" : "jmd87fr",
  "in_reply_to_user_id_str" : "84863141",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2014",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/YgPGmwdTcL",
      "expanded_url" : "http:\/\/www.slideshare.net\/hibbittsdesign\/imoot-2014-designing-a-multidevice-moodle-course-site-a-case-study",
      "display_url" : "slideshare.net\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "467035727708954624",
  "text" : "Slides for my #iMoot2014 session about designing multi-device Moodle course sites http:\/\/t.co\/YgPGmwdTcL (corrected link)",
  "id" : 467035727708954624,
  "created_at" : "2014-05-15 20:16:09 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2014",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/wNJdw5lMhL",
      "expanded_url" : "http:\/\/iy103-w14.hibbittsdesign.com\/",
      "display_url" : "iy103-w14.hibbittsdesign.com"
    } ]
  },
  "geo" : { },
  "id_str" : "466968739121201152",
  "text" : "Finalizing my #iMoot2014 session about designing a multi-device Moodle course site. Explore the case study site at http:\/\/t.co\/wNJdw5lMhL",
  "id" : 466968739121201152,
  "created_at" : "2014-05-15 15:49:57 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Official imoot news",
      "screen_name" : "imootonline",
      "indices" : [ 3, 15 ],
      "id_str" : "235030875",
      "id" : 235030875
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imoot2014",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/hzDRKehN8H",
      "expanded_url" : "http:\/\/grooveshark.com\/#!\/vinnystocker\/broadcast",
      "display_url" : "grooveshark.com\/#!\/vinnystocke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466772706118340608",
  "text" : "RT @imootonline: Radio iMoot - waiting for your song suggestions http:\/\/t.co\/hzDRKehN8H #imoot2014",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "imoot2014",
        "indices" : [ 71, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/hzDRKehN8H",
        "expanded_url" : "http:\/\/grooveshark.com\/#!\/vinnystocker\/broadcast",
        "display_url" : "grooveshark.com\/#!\/vinnystocke\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "466769249491357696",
    "text" : "Radio iMoot - waiting for your song suggestions http:\/\/t.co\/hzDRKehN8H #imoot2014",
    "id" : 466769249491357696,
    "created_at" : "2014-05-15 02:37:15 +0000",
    "user" : {
      "name" : "Official imoot news",
      "screen_name" : "imootonline",
      "protected" : false,
      "id_str" : "235030875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430291211224502272\/OqJeyJEL_normal.png",
      "id" : 235030875,
      "verified" : false
    }
  },
  "id" : 466772706118340608,
  "created_at" : "2014-05-15 02:51:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cloud Counter",
      "screen_name" : "cloud_counter",
      "indices" : [ 0, 14 ],
      "id_str" : "95126331",
      "id" : 95126331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466752123620044800",
  "geo" : { },
  "id_str" : "466752575518154753",
  "in_reply_to_user_id" : 95126331,
  "text" : "@cloud_counter Thanks very much, glad you found it informative!",
  "id" : 466752575518154753,
  "in_reply_to_status_id" : 466752123620044800,
  "created_at" : "2014-05-15 01:31:00 +0000",
  "in_reply_to_screen_name" : "cloud_counter",
  "in_reply_to_user_id_str" : "95126331",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2014",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/IrBAiFOrGv",
      "expanded_url" : "http:\/\/www.slideshare.net\/hibbittsdesign\/imoot-2014-developing-a-course-in-the-open-a-case-study",
      "display_url" : "slideshare.net\/hibbittsdesign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466749789204660225",
  "text" : "Thanks to everyone who participated in my #iMoot2014 session about developing courses in the open! Slides are at http:\/\/t.co\/IrBAiFOrGv",
  "id" : 466749789204660225,
  "created_at" : "2014-05-15 01:19:56 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2014",
      "indices" : [ 65, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466692996583669761",
  "text" : "Wow, it is 2014 and here we all are with audio troubles still... #iMoot2014",
  "id" : 466692996583669761,
  "created_at" : "2014-05-14 21:34:15 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kato.im",
      "screen_name" : "kato_im",
      "indices" : [ 104, 112 ],
      "id_str" : "1026990656",
      "id" : 1026990656
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hibbittsdesign\/status\/466636438902026240\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/gMZFuWsJCs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnnTXghIYAAcdt1.png",
      "id_str" : "466636437228904448",
      "id" : 466636437228904448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnnTXghIYAAcdt1.png",
      "sizes" : [ {
        "h" : 808,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 944,
        "resize" : "fit",
        "w" : 1197
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gMZFuWsJCs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466636438902026240",
  "text" : "Prototype coaching\/mentoring space to complement F2F course, using the flexible real-time messaging app @kato_im http:\/\/t.co\/gMZFuWsJCs",
  "id" : 466636438902026240,
  "created_at" : "2014-05-14 17:49:31 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2014",
      "indices" : [ 89, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/B5jHWJomaR",
      "expanded_url" : "http:\/\/2014.imoot.org\/course\/view.php?id=29",
      "display_url" : "2014.imoot.org\/course\/view.ph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466620070383587328",
  "text" : "Really looking forward to sharing lessons learned when developing courses in the open at #iMoot2014 today! http:\/\/t.co\/B5jHWJomaR",
  "id" : 466620070383587328,
  "created_at" : "2014-05-14 16:44:28 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Landry",
      "screen_name" : "inkbase",
      "indices" : [ 0, 8 ],
      "id_str" : "746683",
      "id" : 746683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466396893002870785",
  "geo" : { },
  "id_str" : "466439350616870912",
  "in_reply_to_user_id" : 746683,
  "text" : "@inkbase It is quite shocking on how many fronts Apple seems so far behind on... Touch-enabled Macs come to mind as one example.",
  "id" : 466439350616870912,
  "in_reply_to_status_id" : 466396893002870785,
  "created_at" : "2014-05-14 04:46:21 +0000",
  "in_reply_to_screen_name" : "inkbase",
  "in_reply_to_user_id_str" : "746683",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brent Smithurst",
      "screen_name" : "brentsmi",
      "indices" : [ 0, 9 ],
      "id_str" : "22743354",
      "id" : 22743354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Xrrrn0LpJV",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=qEuMPAP3sdU&feature=kp",
      "display_url" : "youtube.com\/watch?v=qEuMPA\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "466421086855647233",
  "geo" : { },
  "id_str" : "466423748783255553",
  "in_reply_to_user_id" : 22743354,
  "text" : "@brentsmi It's quite a rare tune, only available on a multi-group compilation album. Here's the tune itself https:\/\/t.co\/Xrrrn0LpJV",
  "id" : 466423748783255553,
  "in_reply_to_status_id" : 466421086855647233,
  "created_at" : "2014-05-14 03:44:22 +0000",
  "in_reply_to_screen_name" : "brentsmi",
  "in_reply_to_user_id_str" : "22743354",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "indices" : [ 3, 16 ],
      "id_str" : "12991032",
      "id" : 12991032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/7dDOCoBiI0",
      "expanded_url" : "http:\/\/wordpressinhigheredconference.wordpress.com\/",
      "display_url" : "\u2026essinhigheredconference.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "466420135512006656",
  "text" : "RT @clintlalonde: Using WordPress In Higher Education Virtual Conference May 29th http:\/\/t.co\/7dDOCoBiI0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/7dDOCoBiI0",
        "expanded_url" : "http:\/\/wordpressinhigheredconference.wordpress.com\/",
        "display_url" : "\u2026essinhigheredconference.wordpress.com"
      } ]
    },
    "geo" : { },
    "id_str" : "464067562985123840",
    "text" : "Using WordPress In Higher Education Virtual Conference May 29th http:\/\/t.co\/7dDOCoBiI0",
    "id" : 464067562985123840,
    "created_at" : "2014-05-07 15:41:43 +0000",
    "user" : {
      "name" : "Clint Lalonde",
      "screen_name" : "clintlalonde",
      "protected" : false,
      "id_str" : "12991032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684895821846855680\/6EEV4DlG_normal.jpg",
      "id" : 12991032,
      "verified" : false
    }
  },
  "id" : 466420135512006656,
  "created_at" : "2014-05-14 03:30:00 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brent Smithurst",
      "screen_name" : "brentsmi",
      "indices" : [ 0, 9 ],
      "id_str" : "22743354",
      "id" : 22743354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466418399003033601",
  "geo" : { },
  "id_str" : "466419740983164930",
  "in_reply_to_user_id" : 22743354,
  "text" : "@brentsmi Awesome! Christmas Is Coming by the Payolas one of my favorite Xmas songs too :-)",
  "id" : 466419740983164930,
  "in_reply_to_status_id" : 466418399003033601,
  "created_at" : "2014-05-14 03:28:26 +0000",
  "in_reply_to_screen_name" : "brentsmi",
  "in_reply_to_user_id_str" : "22743354",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FUCCI SHAUGHNESSY",
      "screen_name" : "fucci",
      "indices" : [ 0, 6 ],
      "id_str" : "4615698701",
      "id" : 4615698701
    }, {
      "name" : "Kato.im",
      "screen_name" : "kato_im",
      "indices" : [ 115, 123 ],
      "id_str" : "1026990656",
      "id" : 1026990656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466390101795569664",
  "text" : "@fucci Hi Frank! Thanks but for the approach in mind they don\u2019t seem to offer the mix of private and public space. @kato_im looks promising.",
  "id" : 466390101795569664,
  "created_at" : "2014-05-14 01:30:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "farhan putrananda",
      "screen_name" : "FarhanP",
      "indices" : [ 0, 8 ],
      "id_str" : "2705034932",
      "id" : 2705034932
    }, {
      "name" : "Kato.im",
      "screen_name" : "kato_im",
      "indices" : [ 25, 33 ],
      "id_str" : "1026990656",
      "id" : 1026990656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466382455952650241",
  "geo" : { },
  "id_str" : "466384388574687232",
  "in_reply_to_user_id" : 18129659,
  "text" : "@Farhanp FYI - right now @kato_im looks like the most promising tool to use for this purpose.",
  "id" : 466384388574687232,
  "in_reply_to_status_id" : 466382455952650241,
  "created_at" : "2014-05-14 01:07:57 +0000",
  "in_reply_to_screen_name" : "Farhanpatel",
  "in_reply_to_user_id_str" : "18129659",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "farhan putrananda",
      "screen_name" : "FarhanP",
      "indices" : [ 0, 8 ],
      "id_str" : "2705034932",
      "id" : 2705034932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466382455952650241",
  "geo" : { },
  "id_str" : "466384061985222656",
  "in_reply_to_user_id" : 18129659,
  "text" : "@Farhanp This vision builds upon my opinion that in this age of information abundance, instructor accessibility is a key value proposition.",
  "id" : 466384061985222656,
  "in_reply_to_status_id" : 466382455952650241,
  "created_at" : "2014-05-14 01:06:40 +0000",
  "in_reply_to_screen_name" : "Farhanpatel",
  "in_reply_to_user_id_str" : "18129659",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "farhan putrananda",
      "screen_name" : "FarhanP",
      "indices" : [ 0, 8 ],
      "id_str" : "2705034932",
      "id" : 2705034932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466382455952650241",
  "geo" : { },
  "id_str" : "466383654386946048",
  "in_reply_to_user_id" : 18129659,
  "text" : "@Farhanp Thanks for the feedback Farhan! Nothing finalized yet, but I will likely be teaching CMPT 363 this Fall at the Vancouver campus.",
  "id" : 466383654386946048,
  "in_reply_to_status_id" : 466382455952650241,
  "created_at" : "2014-05-14 01:05:02 +0000",
  "in_reply_to_screen_name" : "Farhanpatel",
  "in_reply_to_user_id_str" : "18129659",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466376796360163329",
  "text" : "Goal of my next course: provide a real-time\/multi-device\/persistent messaging space for *each* student for private consultation &amp; mentoring.",
  "id" : 466376796360163329,
  "created_at" : "2014-05-14 00:37:47 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ville Saarinen",
      "screen_name" : "vsaarinen",
      "indices" : [ 135, 140 ],
      "id_str" : "22366053",
      "id" : 22366053
    }, {
      "name" : "Flowdock",
      "screen_name" : "flowdock",
      "indices" : [ 139, 140 ],
      "id_str" : "42834380",
      "id" : 42834380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/bwcLes1cXE",
      "expanded_url" : "http:\/\/buff.ly\/1jxIFtc",
      "display_url" : "buff.ly\/1jxIFtc"
    } ]
  },
  "geo" : { },
  "id_str" : "466288533817540608",
  "text" : "RT @maqtoobtools: \"We create more value by having conversations in public instead of behind closed doors.\" \nhttp:\/\/t.co\/bwcLes1cXE via @vsa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ville Saarinen",
        "screen_name" : "vsaarinen",
        "indices" : [ 117, 127 ],
        "id_str" : "22366053",
        "id" : 22366053
      }, {
        "name" : "Flowdock",
        "screen_name" : "flowdock",
        "indices" : [ 128, 137 ],
        "id_str" : "42834380",
        "id" : 42834380
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/bwcLes1cXE",
        "expanded_url" : "http:\/\/buff.ly\/1jxIFtc",
        "display_url" : "buff.ly\/1jxIFtc"
      } ]
    },
    "geo" : { },
    "id_str" : "466232458409951232",
    "text" : "\"We create more value by having conversations in public instead of behind closed doors.\" \nhttp:\/\/t.co\/bwcLes1cXE via @vsaarinen @flowdock",
    "id" : 466232458409951232,
    "created_at" : "2014-05-13 15:04:14 +0000",
    "user" : {
      "name" : "MAQTOOB",
      "screen_name" : "maqtoob",
      "protected" : false,
      "id_str" : "2199594092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453852120110731264\/-pHIS4ko_normal.png",
      "id" : 2199594092,
      "verified" : false
    }
  },
  "id" : 466288533817540608,
  "created_at" : "2014-05-13 18:47:04 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enterprising Josh",
      "screen_name" : "JoshDeax",
      "indices" : [ 0, 9 ],
      "id_str" : "784554709",
      "id" : 784554709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466118468815712256",
  "geo" : { },
  "id_str" : "466236523940040705",
  "in_reply_to_user_id" : 784554709,
  "text" : "@JoshDeax Thanks for the info, I will check it out!",
  "id" : 466236523940040705,
  "in_reply_to_status_id" : 466118468815712256,
  "created_at" : "2014-05-13 15:20:24 +0000",
  "in_reply_to_screen_name" : "JoshDeax",
  "in_reply_to_user_id_str" : "784554709",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stuart lamour",
      "screen_name" : "stuartlamour",
      "indices" : [ 3, 16 ],
      "id_str" : "8075672",
      "id" : 8075672
    }, {
      "name" : "Paolo Oprandi",
      "screen_name" : "paolo_oprandi",
      "indices" : [ 114, 128 ],
      "id_str" : "14798789",
      "id" : 14798789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moodle",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/q4dQ2jWjdw",
      "expanded_url" : "http:\/\/blogs.sussex.ac.uk\/elearningteam\/2014\/05\/08\/recommendations-for-moodle-hq\/",
      "display_url" : "blogs.sussex.ac.uk\/elearningteam\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466215696733437953",
  "text" : "RT @stuartlamour: #moodle recommendations for hq: focus on improving moodles core functionality - a must read via @paolo_oprandi http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paolo Oprandi",
        "screen_name" : "paolo_oprandi",
        "indices" : [ 96, 110 ],
        "id_str" : "14798789",
        "id" : 14798789
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "moodle",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/q4dQ2jWjdw",
        "expanded_url" : "http:\/\/blogs.sussex.ac.uk\/elearningteam\/2014\/05\/08\/recommendations-for-moodle-hq\/",
        "display_url" : "blogs.sussex.ac.uk\/elearningteam\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "466212862814605312",
    "text" : "#moodle recommendations for hq: focus on improving moodles core functionality - a must read via @paolo_oprandi http:\/\/t.co\/q4dQ2jWjdw",
    "id" : 466212862814605312,
    "created_at" : "2014-05-13 13:46:22 +0000",
    "user" : {
      "name" : "stuart lamour",
      "screen_name" : "stuartlamour",
      "protected" : false,
      "id_str" : "8075672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684922682886995968\/GvEbcsPG_normal.jpg",
      "id" : 8075672,
      "verified" : false
    }
  },
  "id" : 466215696733437953,
  "created_at" : "2014-05-13 13:57:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atlassian HipChat",
      "screen_name" : "HipChat",
      "indices" : [ 0, 8 ],
      "id_str" : "17810599",
      "id" : 17810599
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465992050530213888",
  "in_reply_to_user_id" : 17810599,
  "text" : "@HipChat Really enjoying checking out HipChat! With a paid subscription, can I have private chat with Guests? Exploring educational uses...",
  "id" : 465992050530213888,
  "created_at" : "2014-05-12 23:08:57 +0000",
  "in_reply_to_screen_name" : "HipChat",
  "in_reply_to_user_id_str" : "17810599",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hall",
      "screen_name" : "hall",
      "indices" : [ 0, 5 ],
      "id_str" : "60144640",
      "id" : 60144640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465909439057645568",
  "geo" : { },
  "id_str" : "465988635141996545",
  "in_reply_to_user_id" : 60144640,
  "text" : "@hall Is it possible to make a room open to the public, and have private (or group) conversations with visitors?",
  "id" : 465988635141996545,
  "in_reply_to_status_id" : 465909439057645568,
  "created_at" : "2014-05-12 22:55:22 +0000",
  "in_reply_to_screen_name" : "hall",
  "in_reply_to_user_id_str" : "60144640",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 0, 11 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465975492634370048",
  "geo" : { },
  "id_str" : "465981387116666882",
  "in_reply_to_user_id" : 217880712,
  "text" : "@jimbobtyer I appreciate that, thanks James. Get in touch whenever you  feel like another coffee chat too!",
  "id" : 465981387116666882,
  "in_reply_to_status_id" : 465975492634370048,
  "created_at" : "2014-05-12 22:26:34 +0000",
  "in_reply_to_screen_name" : "jimbobtyer",
  "in_reply_to_user_id_str" : "217880712",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tyer",
      "screen_name" : "jimbobtyer",
      "indices" : [ 0, 11 ],
      "id_str" : "217880712",
      "id" : 217880712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465969376252788736",
  "in_reply_to_user_id" : 217880712,
  "text" : "@jimbobtyer Your shared Calendar post got me going today, thanks for that :-) Looking forward to diving into Jane's book as well!",
  "id" : 465969376252788736,
  "created_at" : "2014-05-12 21:38:51 +0000",
  "in_reply_to_screen_name" : "jimbobtyer",
  "in_reply_to_user_id_str" : "217880712",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2014",
      "indices" : [ 17, 27 ]
    }, {
      "text" : "showyourwork",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/o9QeLyDQYA",
      "expanded_url" : "http:\/\/slides.com\/paulhibbitts\/imoot-2014-developing-a-course-in-the-open-a-case-study",
      "display_url" : "slides.com\/paulhibbitts\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465967570944667648",
  "text" : "Draft slides for #iMoot2014 talk \"Developing a Course in the Open\" http:\/\/t.co\/o9QeLyDQYA Documents my experiences with #showyourwork",
  "id" : 465967570944667648,
  "created_at" : "2014-05-12 21:31:40 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kato.im",
      "screen_name" : "kato_im",
      "indices" : [ 11, 19 ],
      "id_str" : "1026990656",
      "id" : 1026990656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465934771898437632",
  "text" : "Looks like @kato_im also has some promising features for student group and individual real-time messaging. It could enhance Canvas nicely.",
  "id" : 465934771898437632,
  "created_at" : "2014-05-12 19:21:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slack",
      "screen_name" : "SlackHQ",
      "indices" : [ 10, 18 ],
      "id_str" : "1305940272",
      "id" : 1305940272
    }, {
      "name" : "Hall",
      "screen_name" : "hall",
      "indices" : [ 23, 28 ],
      "id_str" : "60144640",
      "id" : 60144640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465903697759698944",
  "text" : "Exploring @slackHQ and @Hall for group\/individual real-time messaging platforms for upcoming courses. Any other recommendations?",
  "id" : 465903697759698944,
  "created_at" : "2014-05-12 17:17:52 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UBC Robson Square",
      "screen_name" : "UBCRobsonSquare",
      "indices" : [ 98, 114 ],
      "id_str" : "210914069",
      "id" : 210914069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/QAZDgXiHWw",
      "expanded_url" : "http:\/\/www.cstudies.ubc.ca\/a\/Course\/Designing-Multi-device-Learning-Experiences\/IY103\/",
      "display_url" : "cstudies.ubc.ca\/a\/Course\/Desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465896266388357120",
  "text" : "Interested in multi-device learning experiences? Space is still available in my June 5th Workshop @UBCRobsonSquare http:\/\/t.co\/QAZDgXiHWw",
  "id" : 465896266388357120,
  "created_at" : "2014-05-12 16:48:20 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Harris",
      "screen_name" : "Harris_Bryan",
      "indices" : [ 1, 14 ],
      "id_str" : "16635335",
      "id" : 16635335
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Harris_Bryan\/status\/460549783099547648\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/rxZG2aYiis",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmQzlmaIEAA2Z9o.jpg",
      "id_str" : "460549782956937216",
      "id" : 460549782956937216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmQzlmaIEAA2Z9o.jpg",
      "sizes" : [ {
        "h" : 394,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rxZG2aYiis"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464559212442693632",
  "text" : "\"@Harris_Bryan: This is really cool. The best way to learn something? Teach it. http:\/\/t.co\/rxZG2aYiis\" Sums up my career development...",
  "id" : 464559212442693632,
  "created_at" : "2014-05-09 00:15:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMoot2014",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/9dawkLzJBe",
      "expanded_url" : "http:\/\/2014.imoot.org",
      "display_url" : "2014.imoot.org"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/OheNR5VnCO",
      "expanded_url" : "http:\/\/2014.imoot.org\/mod\/data\/view.php?d=2&advanced=0&paging&page=2",
      "display_url" : "2014.imoot.org\/mod\/data\/view.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464457574809473024",
  "text" : "Looking forward to being part of #iMoot2014 starting May 15th. Conference info: http:\/\/t.co\/9dawkLzJBe My sessions: http:\/\/t.co\/OheNR5VnCO",
  "id" : 464457574809473024,
  "created_at" : "2014-05-08 17:31:29 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinny Stocker",
      "screen_name" : "vinnystocker",
      "indices" : [ 3, 16 ],
      "id_str" : "168094459",
      "id" : 168094459
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vinnystocker\/status\/464218596634525697\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/0pCCgxjm8A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnE8WoMIAAMcfJa.png",
      "id_str" : "464218596038934531",
      "id" : 464218596038934531,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnE8WoMIAAMcfJa.png",
      "sizes" : [ {
        "h" : 595,
        "resize" : "fit",
        "w" : 842
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 595,
        "resize" : "fit",
        "w" : 842
      } ],
      "display_url" : "pic.twitter.com\/0pCCgxjm8A"
    } ],
    "hashtags" : [ {
      "text" : "iMoot2014",
      "indices" : [ 36, 46 ]
    }, {
      "text" : "Moodle",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464230641354043392",
  "text" : "RT @vinnystocker: We're all set for #iMoot2014 #Moodle conference. One week to go, great sessions lined up, competition ready. Join in\u2026 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vinnystocker\/status\/464218596634525697\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/0pCCgxjm8A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnE8WoMIAAMcfJa.png",
        "id_str" : "464218596038934531",
        "id" : 464218596038934531,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnE8WoMIAAMcfJa.png",
        "sizes" : [ {
          "h" : 595,
          "resize" : "fit",
          "w" : 842
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 595,
          "resize" : "fit",
          "w" : 842
        } ],
        "display_url" : "pic.twitter.com\/0pCCgxjm8A"
      } ],
      "hashtags" : [ {
        "text" : "iMoot2014",
        "indices" : [ 18, 28 ]
      }, {
        "text" : "Moodle",
        "indices" : [ 29, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "464218596634525697",
    "text" : "We're all set for #iMoot2014 #Moodle conference. One week to go, great sessions lined up, competition ready. Join in\u2026 http:\/\/t.co\/0pCCgxjm8A",
    "id" : 464218596634525697,
    "created_at" : "2014-05-08 01:41:52 +0000",
    "user" : {
      "name" : "Vinny Stocker",
      "screen_name" : "vinnystocker",
      "protected" : false,
      "id_str" : "168094459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566128010433011712\/MKrSVPFf_normal.jpeg",
      "id" : 168094459,
      "verified" : false
    }
  },
  "id" : 464230641354043392,
  "created_at" : "2014-05-08 02:29:44 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 0, 7 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "Tannis Morgan",
      "screen_name" : "tanbob",
      "indices" : [ 8, 15 ],
      "id_str" : "10817782",
      "id" : 10817782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464076831826522112",
  "geo" : { },
  "id_str" : "464083025307766784",
  "in_reply_to_user_id" : 745903,
  "text" : "@brlamb @tanbob The quote \"The less time I need to spend with the system, the better off I am.\" was the most disheartening for me.",
  "id" : 464083025307766784,
  "in_reply_to_status_id" : 464076831826522112,
  "created_at" : "2014-05-07 16:43:10 +0000",
  "in_reply_to_screen_name" : "brlamb",
  "in_reply_to_user_id_str" : "745903",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "indices" : [ 3, 13 ],
      "id_str" : "18983561",
      "id" : 18983561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moodle",
      "indices" : [ 20, 27 ]
    }, {
      "text" : "Bootstrap",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/hRjggdTypj",
      "expanded_url" : "http:\/\/dev.sonsbeekmedia.nl",
      "display_url" : "dev.sonsbeekmedia.nl"
    } ]
  },
  "geo" : { },
  "id_str" : "462682161066168320",
  "text" : "RT @basbrands: Test #moodle 2.7 #Bootstrap 3 themes and bootswatches on http:\/\/t.co\/hRjggdTypj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "moodle",
        "indices" : [ 5, 12 ]
      }, {
        "text" : "Bootstrap",
        "indices" : [ 17, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/hRjggdTypj",
        "expanded_url" : "http:\/\/dev.sonsbeekmedia.nl",
        "display_url" : "dev.sonsbeekmedia.nl"
      } ]
    },
    "geo" : { },
    "id_str" : "462655393328791552",
    "text" : "Test #moodle 2.7 #Bootstrap 3 themes and bootswatches on http:\/\/t.co\/hRjggdTypj",
    "id" : 462655393328791552,
    "created_at" : "2014-05-03 18:10:16 +0000",
    "user" : {
      "name" : "Bas Brands",
      "screen_name" : "basbrands",
      "protected" : false,
      "id_str" : "18983561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570499815742521344\/KPZ0dxP5_normal.png",
      "id" : 18983561,
      "verified" : false
    }
  },
  "id" : 462682161066168320,
  "created_at" : "2014-05-03 19:56:38 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/QAZDgXiHWw",
      "expanded_url" : "http:\/\/www.cstudies.ubc.ca\/a\/Course\/Designing-Multi-device-Learning-Experiences\/IY103\/",
      "display_url" : "cstudies.ubc.ca\/a\/Course\/Desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461919823555870720",
  "text" : "Open source tools like WordPress and Moodle can provide great multi-device learning experiences. Learn more at http:\/\/t.co\/QAZDgXiHWw",
  "id" : 461919823555870720,
  "created_at" : "2014-05-01 17:27:22 +0000",
  "user" : {
    "name" : "Hibbitts Design",
    "screen_name" : "hibbittsdesign",
    "protected" : false,
    "id_str" : "15949844",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468154432\/7a3c08c22328e62ca9f18c47acb685c6_normal.png",
    "id" : 15949844,
    "verified" : false
  }
} ]