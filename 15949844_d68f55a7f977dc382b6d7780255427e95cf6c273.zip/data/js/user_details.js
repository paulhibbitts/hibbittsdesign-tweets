var user_details =  {
  "screen_name" : "hibbittsdesign",
  "location" : "Vancouver, BC, CANADA",
  "full_name" : "Hibbitts Design",
  "bio" : "Educator\/interaction designer creating better learning experiences for our connected world. Learning changes you. CMPT 363 Course Hub: https:\/\/t.co\/W3rpoJGjh6",
  "id" : "15949844",
  "created_at" : "2008-08-22 20:33:59 +0000"
}